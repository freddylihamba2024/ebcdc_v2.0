<?php
namespace App\Database\Oracle;

class Connection extends \CodeIgniter\Database\OCI8\Connection
{
    public function __construct(array $params)
    {
        parent::__construct($params);
        $this->DBDriver = 'OCI8';
    }

    /** A recovered NULL constraint must not poison an otherwise valid transaction. */
    public function retryMissingRequiredValues(callable $write, callable $retry): bool
    {
        $debug = $this->DBDebug;
        $previousStatus = $this->transStatus;
        // BaseConnection would otherwise automatically roll back on the first error.
        $this->DBDebug = false;
        try {
            if ($write()) return true;
            $error = $this->error();
            if (!in_array((int) ($error['code'] ?? 0), [1400, 1407], true)) return false;
            if (!$retry()) return false;
            $this->transStatus = $previousStatus;
            return true;
        } finally {
            $this->DBDebug = $debug;
        }
    }

    public function escapeIdentifiers($item)
    {
        if (is_array($item)) {
            return array_map([$this, 'escapeIdentifiers'], $item);
        }
        // Existing schemas use ordinary uppercase Oracle identifiers. Preserve SQL literals.
        if (is_string($item) && preg_match('/^[a-zA-Z_][a-zA-Z0-9_$#]*(?:\.[a-zA-Z_*][a-zA-Z0-9_$#]*)*$/D', $item)) {
            $item = strtoupper($item);
        }
        return parent::escapeIdentifiers($item);
    }

    public function connect(bool $persistent = false)
    {
        if ($this->DSN === '' || $this->username === '' || $this->password === '') {
            throw new \RuntimeException('Oracle DSN and credentials must be configured.');
        }
        $connection = parent::connect($persistent);
        if ($connection) {
            $statement = oci_parse($connection, "ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS' NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS'");
            try {
                if (!$statement || !oci_execute($statement)) {
                    throw new \RuntimeException('Cannot initialize Oracle date formats.');
                }
            } finally {
                if ($statement) oci_free_statement($statement);
            }
        }
        return $connection;
    }
}
