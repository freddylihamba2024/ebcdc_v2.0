<?php
namespace App\Database\Oracle;
class Builder extends \CodeIgniter\Database\OCI8\Builder {}
