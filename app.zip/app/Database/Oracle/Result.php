<?php
namespace App\Database\Oracle;

class Result extends \CodeIgniter\Database\OCI8\Result
{
    protected function fetchAssoc()
    {
        $row = parent::fetchAssoc();
        if (!$row) return $row;
        // CodeIgniter's countAll/countAllResults read the lowercase numrows alias.
        if (array_key_exists('NUMROWS', $row)) $row['numrows'] = $row['NUMROWS'];
        foreach ($row as $key => $value) {
            if ($value instanceof \OCILob) {
                $value = $value->load();
                $row[$key] = $value;
            }
            // Keep native aliases and expose the historic Logiref column spelling.
            if (preg_match('/^[A-Z][A-Z0-9_]*_[0-9]+$/D', $key)) {
                $row[ucfirst(strtolower($key))] = $value;
            }
        }
        return $row;
    }

    protected function fetchObject(string $className = 'stdClass')
    {
        $row = $this->fetchAssoc();
        if (!$row) return false;
        if (is_subclass_of($className, \CodeIgniter\Entity\Entity::class)) {
            return (new $className())->setAttributes($row);
        }
        $instance = new $className();
        foreach ($row as $key => $value) $instance->{$key} = $value;
        return $instance;
    }
}
