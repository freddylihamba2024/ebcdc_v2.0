<?php
namespace App\Database\Oracle;
class PreparedQuery extends \CodeIgniter\Database\OCI8\PreparedQuery {}
