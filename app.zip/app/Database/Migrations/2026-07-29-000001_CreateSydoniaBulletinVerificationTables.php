<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSydoniaBulletinVerificationTables extends Migration
{
    protected $DBGroup = 'ikwook_logiref_transactions';

    public function up()
    {
        $this->forge->addField([
            'Id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'AccountId' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'null' => true,
            ],
            'UserId' => [
                'type' => 'INT',
                'constraint' => 11,
                'null' => true,
            ],
            'Reference_1' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => false,
            ],
            'FileName_2' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true,
            ],
            'TotalBulletins_3' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'ProcessedBulletins_4' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'ValidBulletins_5' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'AlreadyPaidBulletins_6' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'FailedBulletins_7' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'Status_8' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'default' => 'PENDING',
            ],
            'VerificationStatus_9' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'default' => 'PENDING',
            ],
            'SydoniaBatchStatus_10' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'null' => true,
            ],
            'CreatedAt_11' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'StartedAt_12' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'FinishedAt_13' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'ErrorMessage_14' => [
                'type' => 'TEXT',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('Id', true);
        $this->forge->createTable('logiref_sydonia_bulletin_verifications', true);

        $this->forge->addField([
            'Id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'VerificationId' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'Year_1' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
                'null' => true,
            ],
            'Serial_2' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
                'null' => true,
            ],
            'Number_3' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'null' => true,
            ],
            'Amount_4' => [
                'type' => 'DECIMAL',
                'constraint' => '18,2',
                'null' => true,
            ],
            'BulletinReference_5' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => true,
            ],
            'VerificationStatus_6' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'default' => 'PENDING',
            ],
            'SydoniaResponse_7' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'SydoniaMessage_8' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'AttemptNumber_9' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 0,
            ],
            'LastVerificationDate_10' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'CreatedAt_11' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'UpdatedAt_12' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('Id', true);
        $this->forge->addKey('VerificationId');
        $this->forge->createTable('logiref_sydonia_bulletin_verification_details', true);

        $this->forge->addField([
            'Id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'VerificationId' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
            ],
            'VerificationDetailId' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'null' => true,
            ],
            'RequestType_1' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'null' => true,
            ],
            'RequestReference_2' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => true,
            ],
            'RequestData_3' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'ResponseData_4' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'ResponseStatus_5' => [
                'type' => 'VARCHAR',
                'constraint' => 30,
                'null' => true,
            ],
            'AttemptNumber_6' => [
                'type' => 'INT',
                'constraint' => 11,
                'default' => 1,
            ],
            'CreatedAt_7' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'CompletedAt_8' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('Id', true);
        $this->forge->addKey('VerificationId');
        $this->forge->addKey('VerificationDetailId');
        $this->forge->createTable('logiref_sydonia_bulletin_verification_logs', true);
    }

    public function down()
    {
        $this->forge->dropTable('logiref_sydonia_bulletin_verification_logs', true);
        $this->forge->dropTable('logiref_sydonia_bulletin_verification_details', true);
        $this->forge->dropTable('logiref_sydonia_bulletin_verifications', true);
    }
}
