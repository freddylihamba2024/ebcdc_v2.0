<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddMetadataToSydoniaBulletinVerificationTables extends Migration
{
    protected $DBGroup = 'ikwook_logiref_transactions';

    public function up()
    {
        $this->forge->addColumn('logiref_sydonia_bulletin_verifications', [
            'OfficeCode_15' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'ErrorMessage_14'],
            'BankCode_16' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'OfficeCode_15'],
            'ClientAccount_17' => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true, 'after' => 'BankCode_16'],
            'ClientAccountName_18' => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true, 'after' => 'ClientAccount_17'],
            'Declarant_19' => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true, 'after' => 'ClientAccountName_18'],
            'Nif_20' => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true, 'after' => 'Declarant_19'],
            'Guichet_21' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'Nif_20'],
            'Mode_22' => ['type' => 'VARCHAR', 'constraint' => 10, 'null' => true, 'after' => 'Guichet_21'],
            'Currency_23' => ['type' => 'VARCHAR', 'constraint' => 10, 'null' => true, 'after' => 'Mode_22'],
            'BranchCode_24' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'Currency_23'],
            'Designation_25' => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true, 'after' => 'BranchCode_24'],
        ]);

        $this->forge->addColumn('logiref_sydonia_bulletin_verification_details', [
            'OfficeCode_13' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'UpdatedAt_12'],
            'BankCode_14' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'OfficeCode_13'],
            'ClientAccount_15' => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true, 'after' => 'BankCode_14'],
            'Declarant_16' => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true, 'after' => 'ClientAccount_15'],
            'Nif_17' => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true, 'after' => 'Declarant_16'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('logiref_sydonia_bulletin_verifications', [
            'OfficeCode_15',
            'BankCode_16',
            'ClientAccount_17',
            'ClientAccountName_18',
            'Declarant_19',
            'Nif_20',
            'Guichet_21',
            'Mode_22',
            'Currency_23',
            'BranchCode_24',
            'Designation_25',
        ]);

        $this->forge->dropColumn('logiref_sydonia_bulletin_verification_details', [
            'OfficeCode_13',
            'BankCode_14',
            'ClientAccount_15',
            'Declarant_16',
            'Nif_17',
        ]);
    }
}
