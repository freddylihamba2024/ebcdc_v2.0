-- =============================================================================
-- ACTIVATION EXTERNAL AUTH (LDAP / LDAPS / GATEWAY) — Logiref v4
-- =============================================================================
-- Remplacez ACCOUNT_ID par la valeur main_authorizations.Bankid_7.
-- =============================================================================

-- ÉTAPE 1 : Activer ext_auth dans main_authorizations
UPDATE main_authorizations
SET Functionnalities_9 = JSON_SET(
    JSON_REMOVE(COALESCE(Functionnalities_9, '{}'), '$.ALL.ldap_auth'),
    '$.ALL.ext_auth',
    JSON_OBJECT('enabled', true, 'driver', 'ldap')
)
WHERE Bankid_7 = 'ACCOUNT_ID';

-- ÉTAPE 2 : Nettoyer les anciennes options puis insérer ext_auth_config
DELETE FROM logiref_options
WHERE Object_7 IN ('ldap_config', 'ext_auth_config')
  AND Beneficiaire_9 = 'ACCOUNT_ID';

-- Exemple LDAP
INSERT INTO logiref_options (Date_1, Status_2, Object_7, Values_8, Beneficiaire_9, Description_10)
VALUES
    (NOW(), 1, 'ext_auth_config', 'enabled',              'ACCOUNT_ID', '1'),
    (NOW(), 1, 'ext_auth_config', 'driver',               'ACCOUNT_ID', 'ldap'),
    (NOW(), 1, 'ext_auth_config', 'ldap_server',          'ACCOUNT_ID', 'ldap://mon-domaine.local'),
    (NOW(), 1, 'ext_auth_config', 'ldap_port',            'ACCOUNT_ID', '389'),
    (NOW(), 1, 'ext_auth_config', 'ldap_basedn',          'ACCOUNT_ID', 'DC=mon-domaine,DC=local'),
    (NOW(), 1, 'ext_auth_config', 'ldap_username_format', 'ACCOUNT_ID', 'upn');

-- Exemple LDAPS
-- UPDATE main_authorizations
-- SET Functionnalities_9 = JSON_SET(COALESCE(Functionnalities_9, '{}'), '$.ALL.ext_auth', JSON_OBJECT('enabled', true, 'driver', 'ldaps'))
-- WHERE Bankid_7 = 'ACCOUNT_ID';
-- INSERT INTO logiref_options (Date_1, Status_2, Object_7, Values_8, Beneficiaire_9, Description_10) VALUES
--     (NOW(), 1, 'ext_auth_config', 'enabled',              'ACCOUNT_ID', '1'),
--     (NOW(), 1, 'ext_auth_config', 'driver',               'ACCOUNT_ID', 'ldaps'),
--     (NOW(), 1, 'ext_auth_config', 'ldap_server',          'ACCOUNT_ID', 'ldaps://dc.bank.local'),
--     (NOW(), 1, 'ext_auth_config', 'ldap_port',            'ACCOUNT_ID', '636'),
--     (NOW(), 1, 'ext_auth_config', 'ldap_basedn',          'ACCOUNT_ID', 'DC=bank,DC=local'),
--     (NOW(), 1, 'ext_auth_config', 'ldap_username_format', 'ACCOUNT_ID', 'upn'),
--     (NOW(), 1, 'ext_auth_config', 'ldap_tls_cacert',      'ACCOUNT_ID', '/etc/ssl/certs/bank-ca.crt');

-- Exemple Gateway
-- UPDATE main_authorizations
-- SET Functionnalities_9 = JSON_SET(COALESCE(Functionnalities_9, '{}'), '$.ALL.ext_auth', JSON_OBJECT('enabled', true, 'driver', 'gateway'))
-- WHERE Bankid_7 = 'ACCOUNT_ID';
-- INSERT INTO logiref_options (Date_1, Status_2, Object_7, Values_8, Beneficiaire_9, Description_10) VALUES
--     (NOW(), 1, 'ext_auth_config', 'enabled',                   'ACCOUNT_ID', '1'),
--     (NOW(), 1, 'ext_auth_config', 'driver',                    'ACCOUNT_ID', 'gateway'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_base_url',          'ACCOUNT_ID', 'https://gateway.bank.com'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_country_id',        'ACCOUNT_ID', '01'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_validate_endpoint', 'ACCOUNT_ID', '/api/v1/user/validate-user'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_userinfo_endpoint', 'ACCOUNT_ID', '/api/v1/user/get-user-details'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_timeout',           'ACCOUNT_ID', '10'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_ssl_verify',        'ACCOUNT_ID', '1'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_appid',             'ACCOUNT_ID', 'ENCRYPTED_APPID'),
--     (NOW(), 1, 'ext_auth_config', 'gateway_appkey',            'ACCOUNT_ID', 'ENCRYPTED_APPKEY');

-- Désactivation
-- UPDATE main_authorizations
-- SET Functionnalities_9 = JSON_REMOVE(COALESCE(Functionnalities_9, '{}'), '$.ALL.ext_auth')
-- WHERE Bankid_7 = 'ACCOUNT_ID';
-- DELETE FROM logiref_options
-- WHERE Object_7 = 'ext_auth_config' AND Beneficiaire_9 = 'ACCOUNT_ID';
