<?php

        use CodeIgniter\Database\BaseConnection;

        if (!function_exists('treat_single_license'))
        {
                function treat_single_license($licenseVal, $licenceModel)
                {
                        $declaration = $licenceModel->get_license_exists($licenseVal->licence);
                        if (!is_null($declaration)) return null;

                        $arrayCodetypeIsys = explode("-", $licenseVal->license_id);
                        $codetype_isys = $licenceModel->get_codetype_isys($licenseVal->license_type, end($arrayCodetypeIsys));
                        if (!$codetype_isys) return null;

                        $Category_20 = $codetype_isys->Codetype_1;
                        if (!in_array($Category_20, ["IS", "ES", "RC"]))
                        {
                                $Category_20 .= $codetype_isys->Licensetype_2;
                        }

                        $amount = floatval($licenseVal->difference_amount) + floatval($licenseVal->total_fees);
                        $amount_paid = floatval($licenseVal->total_fees);
                        $amount_remaining = floatval($amount) - floatval($amount_paid);

                        /* if($amount_remaining < 0)
                        {
                                $amount = $amount_paid;
                                $amount_remaining = 0;
                        } */

                        $initial_expiration = \DateTime::createFromFormat('d/m/Y', $licenseVal->expiry_date)?->format("Y-m-d") ?? null;
                        $initial_date = \DateTime::createFromFormat('d/m/Y', $licenseVal->validation_date)?->format("Y-m-d") ?? null;
                        $remise_force = 0;

                        if (in_array($Category_20, ["IS", "ES", "RC"]))
                        {
                                if (strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                {
                                        $status_2 = $amount_remaining == 0 ? 7 : ($amount_remaining > 0 ? 4 : 2);

                                        $labels = [
                                                7 => "Licence est apuré",
                                                4 => "Licence partielle, paiement(s) en attente",
                                                2 => "Licence en cours de validité"
                                        ];

                                        $Intitule_8 = $labels[$status_2];
                                }
                                else {
                                        $status_2 = $amount_remaining > 0 ? 8 : 7;
                                        $Intitule_8 = $status_2 == 8 ? "Licence est expiré" : "Licence est apuré";
                                }
                                $is_complete_27 = 1;
                        }
                        else {
                                if (strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                {
                                        if ($remise_force == 1)
                                        {
                                                $Intitule_8 = "Licence remise en force";
                                                $status_2 = 6;
                                        }
                                        else {
                                                if ($amount_remaining == 0)
                                                {
                                                        $Intitule_8 = "Licence est total";
                                                        $status_2 = 9;
                                                }
                                                elseif ($amount_remaining > 0 && $amount > $amount_remaining)
                                                {
                                                        $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                        $status_2 = 4;
                                                }
                                                else {
                                                        $Intitule_8 = "Licence en cours de validité";
                                                        $status_2 = 2;
                                                }
                                        }
                                }
                                else {
                                        if ($amount_remaining == 0)
                                        {
                                                $Intitule_8 = "Licence incomplète, document(s) non présenté";
                                                $status_2 = 3;
                                        }
                                        else {
                                                $Intitule_8 = "Licence expiré, paiement(s) non soldé";
                                                $status_2 = 8;
                                        }
                                }

                                $is_complete_27 = 0;
                        }

                        if ($licenseVal->status == "Apurée")
                        {
                                $Intitule_8 =  "Licence est apuré";
                                $status_2 = 7;
                                $is_complete_27 = 1;
                        }

                        $Categorie = $licenceModel->get_categorie_by_object($Category_20);
                        if (!$Categorie) return null;

                        $history_licence_isys = $licenceModel->licenses_history($licenseVal->license_id);
                        $currency_mapping = $licenceModel->get_currency_mapping($licenseVal->currency);
                        $currency_isys = $currency_mapping?->Currency_2 ?? 'USD';
                        $Results_36 = '';

                        if (count($history_licence_isys) > 0)
                        {
                                $input = [];
                                $history_licence_isys = array_reverse($history_licence_isys);
                                $increment = 1;
                                $remaining = $amount;
                                $amount_payed = 0;

                                foreach ($history_licence_isys as $history)
                                {
                                        $total_fees = floatval($history->total_fees);

                                        if ($total_fees > 0 && $remaining > 0 && ($total_fees - $amount_payed) > 0 && ($total_fees - $amount_payed) <= $remaining)
                                        {
                                                $date = new \DateTime($history->updated_date);

                                                $amountpaids = $total_fees - $amount_payed;
                                                $input['Accounts'][$increment] = '';
                                                $input['Accountnames'][$increment] = '';
                                                $input['Currency'][$increment] = $currency_isys;
                                                $input['Date_paids'][$increment] = $date->format('Y-m-d');
                                                $input['Amounts'][$increment] = $amountpaids;
                                                $input['Camounts'][$increment] = $currency_isys;
                                                $input['Comments'][$increment] = '';
                                                $input['Delays'][$increment] = $Categorie->Document_delay_11;
                                                $input['Expirations'][$increment] = $date->modify("+{$Categorie->Document_delay_11} days")->format("Y-m-d");
                                                $input['Status'][$increment] = ($remaining > 0 && $licenseVal->status != "Apurée") ? 4 : 9;
                                                $remaining -= $amountpaids;
                                                $amount_payed += $amountpaids;

                                                $increment++;
                                        }
                                }

                                $Results_36 = json_encode($input);
                        }

                        $elicense = array();
                        $elicense['Id_0'] = null;
                        $elicense['Date_1'] = gmdate('Y-m-d H:i:s');
                        $elicense['Status_2'] = $status_2;
                        $elicense['Account_3'] = 45;
                        $elicense['Creator_4'] = 12072;
                        $elicense['Designation_9'] = $licenseVal->customer_name;
                        $elicense['Code_importers_13'] = $licenseVal->client_code;
                        $elicense['Date_initial_14'] = $initial_date;
                        $elicense['Category_20'] = $Category_20;
                        $elicense['Amountpaid_21'] = $amount_paid;
                        $elicense['Devise_22'] = $currency_isys;
                        $elicense['Amountdue_23'] = $amount;
                        $elicense['Devise_24'] = $currency_isys;
                        $elicense['Initial_expiration_25'] = $initial_expiration;
                        $elicense['Force_26'] = $remise_force;
                        $elicense['is_complete_27'] = $is_complete_27;
                        $elicense['Amountremaining_33'] = $amount_remaining;
                        $elicense['Devise_34'] = $currency_isys;
                        $elicense['Licence_35'] = $licenseVal->license_id;
                        $elicense['Results_36'] = $Results_36;
                        $elicense['Documents_37'] = "";
                        $elicense['AmountPrefinance_39'] = 0;

                        return $elicense;
                }
        }