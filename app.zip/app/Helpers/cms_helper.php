<?php 

// if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Add the title in the title bar in the browser
function add_meta_title($string)
{
	$CI =& get_instance();
	$CI->data['meta_title'] = stripslashes($string). ' - ' . $CI->data['meta_title']; 
}

function _push_file($path, $name, $unlink = FALSE)
{
	// make sure it's a file before doing anything!
	//if(is_file($path))
	if(file_exists($path))
	{
		// required for IE
		if(ini_get('zlib.output_compression')) { ini_set('zlib.output_compression', 'Off'); }
		
		// Build the headers to push out the file properly.
		header('Pragma: public');     // required
		header('Expires: 0');         // no cache
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($path)).' GMT');
		header('Cache-Control: private',false);
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.basename($name).'.csv"');  // Add the file name
		header('Content-Transfer-Encoding: binary');
		header('Content-Length: '.filesize($path)); // provide file size
		header('Connection: close');
		readfile($path); // push it out
		if($unlink) unlink($path);
		exit();
	}
}