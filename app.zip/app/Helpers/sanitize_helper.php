<?php

/**
 * Sanitize Helper
 *
 * Fournit des fonctions globales pour nettoyer et formater les données
 * (chaînes et montants) dans CodeIgniter 4.
 *
 * Logique :
 * - sanitize_string : supprime les espaces superflus et normalise les chaînes.
 * - sanitize_amount : nettoie et formate les montants en nombre flottant
 *   avec deux décimales.
 *
 * @author  Alain Malengo
 */

if (!function_exists('sanitize_string')) 
{
    /**
     * Nettoie une chaîne de caractères
     * Supprime les espaces superflus et normalise la chaîne.
     *
     * @param string|null $data Chaîne à nettoyer
     * @return string Chaîne nettoyée
     */
    function sanitize_string(?string $data): string
    {
        return trim(preg_replace('/\s+/', ' ', $data ?? ""));
    }
}

if (!function_exists('sanitize_amount')) 
{
    /**
     * Nettoie et formate un montant
     * Supprime les espaces, remplace les virgules par des points,
     * force la valeur en float et formate avec 2 décimales.
     *
     * @param string|float|null $data Montant à nettoyer
     * @return string Montant formaté (2 décimales)
     */
    function sanitize_amount($data): string
    {
        $clean = str_replace([' ', ','], ['', '.'], $data ?? "");
        return is_numeric($clean) ? number_format((float)$clean, 2, '.', '') : "0.00";
    }
}
