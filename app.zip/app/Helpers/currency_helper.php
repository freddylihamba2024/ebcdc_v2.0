<?php

if (!function_exists('format_currency')) {

    /**
     * Format an amount depending on currency and add HTML style.
     *
     * @param float|int $amount
     * @param string $currency ('USD' or 'CDF')
     * @param bool $withBadge Add colored badge for styling
     * @return string
     */
    function format_currency($amount, $currency = 'CDF', $withBadge = true)
    {
        $currency = strtoupper($currency);

        switch ($currency) {
            case 'USD':
                $symbol = '$';
                $formatted = number_format($amount, 2, '.', ','); // 1,234.56
                $colorClass = 'text-blue-600'; // couleur USD
                break;

            case 'CDF':
            default:
                $symbol = 'FC';
                $formatted = number_format($amount, 0, '', ','); // 1,234
                $colorClass = 'text-red-600'; // couleur CDF
                break;
        }

        $display = $symbol . ' ' . $formatted;

        if ($withBadge) {
            // Retourne un span stylé
            return '<span class="' . $colorClass . ' font-semibold">' . $display . '</span>';
        }

        return $display;
    }
}
