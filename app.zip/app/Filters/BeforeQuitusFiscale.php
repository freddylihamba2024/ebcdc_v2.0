<?php
        namespace App\Filters;

        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use CodeIgniter\Filters\FilterInterface;
        use Modules\Quitus\Models\UserQuitusModel;
        use Modules\Main\Models\MainModel;
        use Modules\Quitus\Models\RatesModel;
        use App\Libraries\Chtml;
        use Modules\Admin\Models\UserModel;

        class BeforeQuitusFiscale implements FilterInterface
        {
                public $userQuitusModel;
                public $session;
                public $mainModel;
                public $ratesModel;
                public $userModel;
                public $uri;
                public $data;
                public $module;
                public $options;
                public $core_banking;
                public $igor;
                public $bsqr;
                public $fibridge;
                public $finacle_standardbank;
                public $amplitude_solidairebanque;

                public function before(RequestInterface $request, $arguments = null)
                {
                        // Initialisation de ta librairie
                        $this->session = \Config\Services::session();
                        $this->userQuitusModel = new UserQuitusModel();
                        $this->data = array();
                        $this->uri = service('uri');
                        $this->data['chtml'] = new Chtml();
                        $this->userModel = new UserModel();
                        $this->mainModel=new MainModel();
                        $this->ratesModel = new RatesModel();
                        $this->mainModel = new MainModel();

                        if(!is_null($this->session->get('Logiref_role')) && !empty($_SESSION['userdata']) && $_SESSION['userdata']['user_type'] != '100'){

                                $this->options = json_decode($_SESSION['userdata']['options'] ?? '{}', true) ?: [];
                                $userType = $_SESSION['userdata']['user_type'] ?? '';
                                $isExternalAuth = !empty($this->options['ALL']['ext_auth']['enabled'])
                                                  && !in_array($userType, ['100', '200']);

                                $profile = $this->mainModel->get_profile_infos($this->session->userdata["user_id"]);
                                $this->ratesModel->get_exchange_rates();

                                if(!$isExternalAuth && $profile->Statutdefaultpwd_31 != 1)
                                {
                                        $path = explode("/",$this->uri->getPath());
                                        if ($this->uri->getPath() !== '/admin/users/set/password' && $this->uri->getPath() !== '/admin/users/display/password')
                                        {
                                                if (!preg_match('#^/admin/users/save/password(?:/\d+)?$#', $this->uri->getPath()))
                                                {
                                                        return redirect()->to(base_url("admin/users/set/password"));
                                                }
                                        }

                                }

                                if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                                {
                                        if (isset($this->options['ALL']['manuel-input-exchange-rate']) || (!isset($this->options['ALL']['manuel-input-exchange-rate']) && !isset($this->options['ALL']['auto-fetch-exchange-rate'])))
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                        else
                                        {
                                                /*
                                                * ------------------------------------------------
                                                * Initialization
                                                * ------------------------------------------------
                                                */

                                                $usd = '';
                                                $pound = '';
                                                $eur = '';
                                                $rand = '';

                                                $data['from_currency'] = 'USD';
                                                $data['to_currency'] = 'CDF';
                                                $data['type'] = 'TTB';
                                                $data['language'] = 'P';

                                                # Nom du core banking
                                                $core_banking = strtolower($this->core_banking);

                                                $this->amplitude_solidairebanque = new \Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque();
                                                $this->igor = new \Modules\Services\Igor\Controllers\Igor();
                                                $this->bsqr = new \Modules\Services\Bsqr\Controllers\Bsqr();
                                                $this->finacle_standardbank = new \Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank();
                                                $this->fibridge = new \Modules\Services\FIBridge\Controllers\FIBridge();

                                                # Vérifier si la mÃ©thode get_exchange_rate existe dans la classe
                                                if (property_exists($this, $core_banking) && method_exists($this->{$core_banking}, 'get_exchange_rate'))
                                                {
                                                        $return = $this->{$core_banking}->get_exchange_rate($data);

                                                        $return = json_decode($return, true);

                                                        if($return['code'] == '200')
                                                        {
                                                                if (isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $data['from_currency'] = 'EUR';
                                                                        $data['to_currency'] = 'CDF';

                                                                        $return = $this->{$core_banking}->get_exchange_rate($data);

                                                                        $return = json_decode($return, true);

                                                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                        $dollar = str_replace(' ','',$usd);
                                                                        $dollar = str_replace(',','.',$dollar);

                                                                        if($eur !="")
                                                                        {
                                                                                $euro = str_replace(' ','',$eur);
                                                                                $euro = str_replace(',','.',$euro);
                                                                                $data1['Euro_5']     =   $euro;
                                                                        }

                                                                        $data1['Date_1']     =   gmdate('Y-m-d H:i:s');
                                                                        $data1['Status_2']   =   1;
                                                                        $data1['Account_3']  =   $this->session->userdata['account_id'];
                                                                        $data1['Dollar_4']   =   $dollar;
                                                                        $data1['Agence_8']   =   $_SESSION['Logiref_agence'];
                                                                        $data1['Day_9']      =   gmdate('Y-m-d');
                                                                        $data1['Checkerid_11']='0001';
                                                                        $data1['Makerid_10']='0002';

                                                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                        $this->ratesModel->save_taux($data1, NULL);

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                                elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                                                {
                                                                        foreach ($return['ExchangeRateList'] as $row)
                                                                        {
                                                                        if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                                        {
                                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                                        {
                                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                                        {
                                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                                        {
                                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        }

                                                                        if ($usd != "" && $eur != "") {

                                                                                $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                                $dollar = str_replace(' ','',$usd);
                                                                                $dollar = str_replace(',','.',$dollar);

                                                                                if($eur !="")
                                                                                {
                                                                                        $euro = str_replace(' ','',$eur);
                                                                                        $euro = str_replace(',','.',$euro);
                                                                                        $data['Euro_5']     =   $euro;
                                                                                }

                                                                                $data['Date_1']         =   gmdate('Y-m-d H:i:s');
                                                                                $data['Status_2']       =   1;
                                                                                $data['Account_3']      =   $this->session->userdata['account_id'];
                                                                                $data['Dollar_4']       =   $dollar;
                                                                                $data['Agence_8']       =   $_SESSION['Logiref_agence'];
                                                                                $data['Day_9']          =   gmdate('Y-m-d');
                                                                                $data['Checkerid_11']   =   '0001';
                                                                                $data['Makerid_10']     =   '0002';

                                                                                $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                                $this->ratesModel->save_taux($data, NULL);

                                                                                $this->ratesModel->get_exchange_rates();
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $this->ratesModel->get_exchange_rates();
                                                                }

                                                        }
                                                        else{
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                                else
                                                {
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                }

                                // Appel de la méthode de vérification
                                $this->userQuitusModel->get_privilegies();

                        }
                        elseif(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return true;
                        }
                        else{
                                return redirect()->to(base_url('main/denied'));
                        }
                }

                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        // Code exécuté après le contrôleur (optionnel)
                }
        }