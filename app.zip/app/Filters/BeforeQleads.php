<?php
        namespace App\Filters;

        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use CodeIgniter\Filters\FilterInterface;
        use Modules\Admin\Models\UserQleadModel;

        class BeforeQleads implements FilterInterface
        {
                public $userQleadModel;
                public $session;

                public function before(RequestInterface $request, $arguments = null)
                {
                        // Initialisation de ta librairie
                        $this->session = \Config\Services::session();
                        $this->userQleadModel = new UserQleadModel();

                        if(!is_null($this->session->get('Logiref_role')) && !empty($_SESSION['userdata']) && $_SESSION['userdata']['user_type'] != '100'){

                                // Appel de la méthode de vérification
                                $this->userQleadModel->get_privilegies();

                        }
                        elseif(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return true;
                        }
                        else{
                                return redirect()->to(base_url('main/denied'));
                        }
                }

                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        // Code exécuté après le contrôleur (optionnel)
                }
        }