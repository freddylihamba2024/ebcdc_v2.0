<?php

        namespace App\Filters;

        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use CodeIgniter\Filters\FilterInterface;
        use App\Libraries\Chtml;
        use Modules\Admin\Models\UserModel;
        use Modules\Main\Models\MainModel;
        use Modules\Branch\Models\RatesModel;

        class BeforeLogiref implements FilterInterface
        {
                public $userModel;
                public $session;
                public $uri;
                public $data;
                public $ratesModel;
                public $mainModel;
                public $module;
                public $options;
                public $core_banking;
                public $igor;
                public $bsqr;
                public $fibridge;
                public $finacle_standardbank;
                public $finacle;
                public $amplitude_solidairebanque;

                public function before(RequestInterface $request, $arguments = null)
                {
                        // Initialisation de la librairie
                        $this->session = \Config\Services::session();
                        $this->data = array();
                        $this->uri = service('uri');
                        $this->data['chtml'] = new Chtml();
                        $this->userModel = new UserModel();
                        $this->mainModel = new MainModel();
                        $this->ratesModel = new RatesModel();
                        $this->mainModel = new MainModel();
                        $this->core_banking = isset($this->session->userdata["account_cbs"])?$this->session->userdata["account_cbs"]:"";

                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->options = array();
                        }

                        /*if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
                                if(is_null($this->session->get("Logiref_role"))){
                                       return redirect()->to(base_url('main/signin'));
                                }
                        }*/

                        $userid = isset($this->session->userdata['user_id'])?$this->session->userdata['user_id']:"";
                        $user = $this->mainModel->get_profile_by_id($userid);
                        $ipaddress = $_SERVER['REMOTE_ADDR'];

                        $userAgent = $request->getHeaderLine('User-Agent')."_".$ipaddress."_".$request->getHeaderLine("Cookie");

                        if(!$this->session->has("userdata"))
                        {
                                if ($request instanceof \CodeIgniter\HTTP\IncomingRequest && $request->isAJAX())
                                {

                                        $data['Lastsession_23'] = "";
                                        $data['Useragent_30'] = "";
                                        $data['Deviceipaddress_32'] = "";

                                        $this->mainModel->save_profile($data, $userid);

                                        return service('response')->setJSON([
                                            'status' => 'error',
                                            'message' => 'Votre session a expiré. Veuillez vous reconnecter.',
                                            'redirect_url' => base_url('main/signin') // URL vers laquelle rediriger
                                        ])->setStatusCode(401); // Statut HTTP 401 : Non autorisé

                                }
                        }

                        if(!empty($_SESSION['Logiref_role']) && !empty($_SESSION['userdata']) && $_SESSION['userdata']['user_type'] != '100')
                        {
                                $profile = $this->mainModel->get_profile_infos($this->session->userdata["user_id"]);
                                
                                $this->ratesModel->get_exchange_rates();
                             
                                $currentPath = '/' . trim($this->uri->getPath(), '/');

                                $allowedPwdRoutes = ['/admin/users/set/password','/admin/users/display/password'];

                                $userType = $_SESSION['userdata']['user_type'] ?? '';
                                $isExternalAuth = !empty($this->options['ALL']['ext_auth']['enabled'])
                                                  && !in_array($userType, ['100', '200']);

                                if (!$isExternalAuth && !empty($profile) && $profile->Statutdefaultpwd_31 != 1) {

                                        if (!in_array($currentPath, $allowedPwdRoutes) && !preg_match('#^/admin/users/save/password(?:/\d+)?$#', $currentPath))
                                        {
                                                if ($request->isAJAX()) {
                                                        return service('response')
                                                                ->setJSON([
                                                                        'status' => 'error',
                                                                        'message' => 'Vous devez définir un mot de passe avant de continuer.',
                                                                        'redirect_url' => base_url('admin/users/set/password')
                                                                ])
                                                                ->setStatusCode(403);
                                                }

                                                return redirect()->to(base_url('admin/users/set/password'));
                                        }

                                        return true;
                                }
                               
                                if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                                {
                                        
                                        if (isset($this->options['ALL']['manuel-input-exchange-rate']) || (!isset($this->options['ALL']['manuel-input-exchange-rate']) && !isset($this->options['ALL']['auto-fetch-exchange-rate'])))
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                        else
                                        {
                                                /*
                                                * ------------------------------------------------
                                                * Initialization
                                                * ------------------------------------------------
                                                */

                                                $usd = '';
                                                $pound = '';
                                                $eur = '';
                                                $rand = '';

                                                $data['from_currency'] = 'USD';
                                                $data['to_currency'] = 'CDF';
                                                $data['type'] = 'TTB';
                                                $data['language'] = 'P';

                                                # Nom du core banking
                                                $core_banking = strtolower($this->core_banking);

                                                $this->amplitude_solidairebanque = new \Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque();
                                                $this->igor = new \Modules\Services\Igor\Controllers\Igor();
                                                $this->bsqr = new \Modules\Services\Bsqr\Controllers\Bsqr();
                                                $this->finacle_standardbank = new \Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank();
                                                $this->fibridge = new \Modules\Services\FIBridge\Controllers\FIBridge();
                                                $this->finacle = new \Modules\Services\Finacle\Controllers\Finacle();

                                                # Vérifier si la mÃ©thode get_exchange_rate existe dans la classe
                                                if (property_exists($this, $core_banking) && method_exists($this->{$core_banking}, 'get_exchange_rate'))
                                                {

                                                        if($this->core_banking == "Finacle")
                                                        {
                                                                $return = $this->{$core_banking}->get_exchange_rate_v2($data);
                                                        }
                                                        else
                                                        {
                                                        $return = $this->{$core_banking}->get_exchange_rate($data);
                                                        }

                                                        $return = json_decode($return, true);

                                                        if($return['code'] == '200')
                                                        {
                                                                if (isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $data['from_currency'] = 'EUR';
                                                                        $data['to_currency'] = 'CDF';

                                                                        if($this->core_banking == "Finacle")
                                                                        {
                                                                                $return = $this->{$core_banking}->get_exchange_rate_v2($data);
                                                                        }
                                                                        else
                                                                        {
                                                                                $return = $this->{$core_banking}->get_exchange_rate($data);
                                                                        }

                                                                        $return = json_decode($return, true);

                                                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                        $dollar = str_replace(' ','',$usd);
                                                                        $dollar = str_replace(',','.',$dollar);

                                                                        if($eur !="")
                                                                        {
                                                                                $euro = str_replace(' ','',$eur);
                                                                                $euro = str_replace(',','.',$euro);
                                                                                $data1['Euro_5']     =   $euro;
                                                                        }

                                                                        $data1['Date_1']     =   gmdate('Y-m-d H:i:s');
                                                                        $data1['Status_2']   =   1;
                                                                        $data1['Account_3']  =   $this->session->userdata['account_id'];
                                                                        $data1['Dollar_4']   =   $dollar;
                                                                        $data1['Agence_8']   =   $_SESSION['Logiref_agence'];
                                                                        $data1['Day_9']      =   gmdate('Y-m-d');
                                                                        $data1['Checkerid_11']='0001';
                                                                        $data1['Makerid_10']='0002';

                                                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                        $this->ratesModel->save_taux($data1, NULL);

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                                elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                                                {
                                                                        foreach ($return['ExchangeRateList'] as $row)
                                                                        {
                                                                        if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                                        {
                                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                                        {
                                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                                        {
                                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                                        {
                                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        }

                                                                        if ($usd != "" && $eur != "") {

                                                                                $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                                $dollar = str_replace(' ','',$usd);
                                                                                $dollar = str_replace(',','.',$dollar);

                                                                                if($eur !="")
                                                                                {
                                                                                        $euro = str_replace(' ','',$eur);
                                                                                        $euro = str_replace(',','.',$euro);
                                                                                        $data['Euro_5']     =   $euro;
                                                                                }

                                                                                $data['Date_1']         =   gmdate('Y-m-d H:i:s');
                                                                                $data['Status_2']       =   1;
                                                                                $data['Account_3']      =   $this->session->userdata['account_id'];
                                                                                $data['Dollar_4']       =   $dollar;
                                                                                $data['Agence_8']       =   $_SESSION['Logiref_agence'];
                                                                                $data['Day_9']          =   gmdate('Y-m-d');
                                                                                $data['Checkerid_11']   =   '0001';
                                                                                $data['Makerid_10']     =   '0002';

                                                                                $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                                $this->ratesModel->save_taux($data, NULL);

                                                                                $this->ratesModel->get_exchange_rates();
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $this->ratesModel->get_exchange_rates();
                                                                }

                                                        }
                                                        else{
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                                else
                                                {
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                }

                                // Reinitialisation des valeurs de la session
                                $this->userModel->get_privilegies();

                                if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && in_array($_SESSION['Logiref_role'],[3,4]))
                                {
                                        $path = explode("/",$this->uri->getPath());

                                        if(isset($this->options['ALL']['Enabling_rate_publishing_users']))
                                        {
                                                if($this->uri->getPath() !== '/main/published')
                                                {
                                                        if ($request->isAJAX()) {
                                                                return service('response')
                                                                        ->setJSON([
                                                                                'status' => 'error',
                                                                                'message' => 'Vous devez définir un mot de passe avant de continuer.',
                                                                                'redirect_url' => base_url('main/published')
                                                                        ])
                                                                        ->setStatusCode(403);
                                                        }

                                                        return redirect()->to(base_url('main/published'));
                                                }
                                        }
                                        else
                                        {
                                                if ($this->uri->getPath() !== '/branch/taxrates/set/taux' && $this->uri->getPath() !== '/branch/taxrates/display/taux')
                                                {
                                                        if (!preg_match('#^/branch/taxrates/save/taux(?:/\d+)?$#', $this->uri->getPath()) && !in_array("overview", $path))
                                                        {
                                                                return redirect()->to(base_url("branch/taxrates/set/taux"));
                                                        }

                                                }
                                        }

                                        return true;

                                }
                        }
                        elseif(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return true;
                        }
                        else
                        {
                                if(!empty($_SESSION['otp_user_connected']))
                                {
                                        return redirect()->to(base_url('main/authentification'));
                                }
                                else{
                                        return redirect()->to(base_url('main/denied'));
                                }
                        }

                }

                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        // Code exécuté après le contrôleur (optionnel)
                }

        }