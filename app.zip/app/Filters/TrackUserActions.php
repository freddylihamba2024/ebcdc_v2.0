<?php

        namespace App\Filters;

        use CodeIgniter\Filters\FilterInterface;
        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use Modules\Main\Models\MainModel;
        class TrackUserActions implements FilterInterface
        {

                /**
                 * Do whatever processing this filter needs to do.
                 * By default it should not return anything during
                 * normal execution. However, when an abnormal state
                 * is found, it should return an instance of
                 * CodeIgniter\HTTP\Response. If it does, script
                 * execution will end and that Response will be
                 * sent back to the client, allowing for error pages,
                 * redirects, etc.
                 *
                 * @param RequestInterface $request
                 * @param array|null       $arguments
                 *
                 * @return mixed
                 */

                private $mainModel;

                public function before(RequestInterface $request, $arguments = null)
                {

                }

                /**
                 * Allows After filters to inspect and modify the response
                 * object as needed. This method does not allow any way
                 * to stop execution of other after filters, short of
                 * throwing an Exception or Error.
                 *
                 * @param RequestInterface  $request
                 * @param ResponseInterface $response
                 * @param array|null        $arguments
                 *
                 * @return mixed
                 */
                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        $uri = $request->getUri()->getPath();
                        $this->mainModel = new MainModel();

                        $action = '';

                        $headers = [
                                "date"          => "DATE",
                                "account"       => "ACCOUNT",
                                "user"          => "USER",
                                "ip_address"    => "IP ADDRESS",
                                "action"        => "ACTION",
                                "uri_path"      => "URI"
                        ];

                        $widths = [
                                "date"          => 20,
                                "account"       => 20,
                                "user"          => 40,
                                "ip_address"    => 35,
                                "action"        => 80,
                                "uri_path"      => 150
                        ];

                        if($request->getUri()->getSegment(2) == "login")
                        {
                                $auth_user = $this->mainModel->verifyLogin($_POST['identifiant'], $_POST['passcode']);

                                if($auth_user !== false)
                                {
                                        $userdata = $this->mainModel->get_user_data($auth_user);

                                        $data['date']       = date('Y-m-d H:i:s');
                                        $data['account']    = isset($userdata) ? $userdata['account_pageid']:"";
                                        $data['user']       = isset($userdata) ? $userdata['user_fname']." ".$userdata['user_sname']." ".$userdata['user_nname']:"";
                                        $data['ip_address'] = $request->getIPAddress();
                                        $data['action']     = 'Connexion à l\'application';
                                        $data['uri_path']  = base_url()."/".$uri;

                                        $this->save_log("login", $data, $widths, $headers);

                                        $this->log_action(json_encode($data));
                                }
                        }
                        elseif($request->getUri()->getSegment(2) == "validate_otp")
                        {
                                $data['date']       = date('Y-m-d H:i:s');
                                $data['account']    = isset($_SESSION['userdata']) ? $_SESSION['userdata']['account_pageid']:"";
                                $data['user']       = isset($_SESSION['userdata']) ? $_SESSION['userdata']['user_fname']." ".$_SESSION['userdata']['user_sname']." ".$_SESSION['userdata']['user_nname']:"";
                                $data['ip_address'] = $request->getIPAddress();
                                $data['action']     = 'Validation ou vérification de l\'OTP';
                                $data['uri_path']  = base_url()."/".$uri;

                                $this->save_log("validate_otp", $data, $widths, $headers);

                                $this->log_action(json_encode($data));
                        }
                        elseif($request->getUri()->getSegment(2) == "signout")
                        {
                                $user = $this->get_user_by_ip($request->getIPAddress());

                                $data['date']       = date('Y-m-d H:i:s');
                                $data['account']    = $user ? $user['account'] : "";
                                $data['user']       = $user ? $user['user'] : "";
                                $data['ip_address'] = $request->getIPAddress();
                                $data['action']     = 'Deconnexion à l\'application';
                                $data['uri_path']  = base_url()."/".$uri;

                                $this->save_log("logout", $data, $widths, $headers);

                                $this->log_action(json_encode($data));
                        }
                        else{
                                if($request->getUri()->getSegment(3)=='save')
                                {
                                        if($request->getUri()->getSegment(3)=='save' && $request->getUri()->getSegment(4)=="taux")
                                        {
                                                $action = "Publication du taux";
                                        }
                                        else
                                        {
                                                $action = 'Save '.$request->getUri()->getSegment(4);
                                        }
                                }
                                else
                                {
                                        $action = $this->get_action($request->getUri()->getSegment(2),$request->getUri()->getSegment(3),$request->getUri()->getSegment(4));
                                }

                                if($action != "")
                                {
                                        $data['date']       = date('Y-m-d H:i:s');
                                        $data['account']    = isset($_SESSION['userdata']) ? $_SESSION['userdata']['account_pageid']:"";
                                        $data['user']       = isset($_SESSION['userdata']) ? $_SESSION['userdata']['user_fname']." ".$_SESSION['userdata']['user_sname']." ".$_SESSION['userdata']['user_nname']:"";
                                        $data['ip_address'] = $request->getIPAddress();
                                        $data['action']     = $action;
                                        $data['uri_path']   = base_url()."/".$uri;

                                        $this->save_log("other", $data, $widths, $headers);

                                        $this->log_action(json_encode($data));
                                }
                        }

                }

                public function get_action($controller,$action=null,$obj=null)
                {
                        $controllers_actions = [
                        $controller => [
                                        'save'      => "Enregistrement de ".$obj,
                                        'display'   => "Affichage de ".$obj,
                                        'set'       => "Affichage de ".$obj
                                ]
                        ];
                        $action_message=null;
                        foreach ($controllers_actions as $controller_key=>$controller_action)
                        {
                                if($controller == strtolower($controller_key))
                                {
                                        foreach ($controller_action as $key=>$value)
                                        {
                                                if($key==$action)
                                                {
                                                        $action_message=$value;
                                                }
                                        }
                                }
                        }
                        return $action_message;

                }

                public function log_action($data)
                {
                        $mainModel=new \Modules\Main\Models\MainModel();
                        $mainModel->save_log($data,'audit_log');
                }

                public function get_user_by_ip($ip_address)
                {
                        $logFile = ROOTPATH . "drive/logs/services/Logiref/" . gmdate('Y-m-d') . "_audit_log.logs";

                        if (!file_exists($logFile))
                        {
                                return null;
                        }

                        $handle = fopen($logFile, 'r');
                        if (!$handle) {
                                return null;
                        }

                        while (($line = fgets($handle)) !== false) {
                                $line = trim($line, ";\n");
                                $data = json_decode($line, true);

                                if (isset($data['ip_address']) && $data['ip_address'] === $ip_address && !empty($data['user'])) {
                                        fclose($handle);
                                        return [
                                                'account' => $data['account'] ?? '',
                                                'user' => $data['user'] ?? ''
                                        ];
                                }
                        }

                        fclose($handle);
                        return null;
                }

                public function save_log($log_name, $data, $widths, $headers)
                {
                        $log = (object) $data;

                        if (isset($log->date) && strtotime($log->date)) {
                                $logDate = date('Y-m-d', strtotime($log->date));
                        } else {
                                $logDate = date('Y-m-d');
                        }

                        $month = date('m', strtotime($logDate));
                        $year = date('Y', strtotime($logDate));

                        $path = ROOTPATH . "/drive/logs/AuditLog/{$month}{$year}/{$log_name}";

                        if (!is_dir($path)) {
                                mkdir($path, 0777, true);
                        }

                        $filename = $path . "/{$logDate}_" . strtolower($log_name) . ".txt";

                        $isNew = !file_exists($filename);
                        $file = fopen($filename, "a+");

                        if ($isNew) {
                                fwrite($file, $this->formatLine($headers, $widths));
                                $totalWidth = array_sum($widths) + (count($widths) * 3) + 1;
                                fwrite($file, str_repeat('-', $totalWidth) . "\n");
                        }

                        $lineData = [];
                        foreach ($headers as $key => $value) {
                                $lineData[$key] = $log->$key ?? '';
                        }

                        fwrite($file, $this->formatLine($lineData, $widths));
                        fclose($file);
                }

                private function formatLine($fields, $widths)
                {
                        $line = '';
                        foreach ($fields as $key => $value) {
                                $line .= '| ' . str_pad($value, $widths[$key]) . ' ';
                        }
                        $line .= "|\n";
                        return $line;
                }

        }
