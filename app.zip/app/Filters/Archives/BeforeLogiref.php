<?php

        namespace App\Filters;

        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use CodeIgniter\Filters\FilterInterface;
        use App\Libraries\Chtml;
        use Modules\Admin\Models\UserModel;
        use Modules\Branch\Models\RatesModel;
        use Modules\Main\Models\MainModel;

        class BeforeLogiref implements FilterInterface
        {
                public $userModel;
                public $session;
                public $uri;
                public $data;
                public $ratesModel;
                public $module;
                public $options;
                public $core_banking;
                public $mainModel;
                public $igor;

                public function before(RequestInterface $request, $arguments = null)
                {
                        // Initialisation de la librairie
                        $this->session = \Config\Services::session();
                        $this->data = array();
                        $this->uri = service('uri');
                        $this->data['chtml'] = new Chtml();
                        $this->userModel = new UserModel();
                        $this->ratesModel = new RatesModel();
                        $this->mainModel = new MainModel();
                        $this->core_banking = $this->session->userdata["account_cbs"];

                        if (isset($_SESSION['userdata']['options'])) {
                                $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->options = array();
                        }

                        /*if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
                                if(is_null($this->session->get("Logiref_role"))){
                                       return redirect()->to(base_url('main/signin'));
                                }
                        }*/

                        if(!$this->session->has("userdata")){
                                if ($request instanceof \CodeIgniter\HTTP\IncomingRequest && $request->isAJAX()) {
                                        return service('response')->setJSON([
                                            'status' => 'error',
                                            'message' => 'Votre session a expiré. Veuillez vous reconnecter.',
                                            'redirect_url' => base_url('main/signin') // URL vers laquelle rediriger
                                        ])->setStatusCode(401); // Statut HTTP 401 : Non autorisé
                                }
                        }

                        if(!empty($_SESSION['Logiref_role']) && !empty($_SESSION['userdata']) && $_SESSION['userdata']['user_type'] != '100'){

                                $profile = $this->mainModel->get_profile_infos($this->session->userdata["user_id"]);

                                if($profile->Statutdefaultpwd != 1)
                                {
                                        $path = explode("/",$this->uri->getPath());
                                        if ($this->uri->getPath() !== '/admin/users/set/password' && $this->uri->getPath() !== '/admin/users/display/password') {

                                                if (!preg_match('#^/admin/users/save/password(?:/\d+)?$#', $this->uri->getPath())) {

                                                        return redirect()->to(base_url("admin/users/set/password"));
                                                }

                                        }

                                }
                                else{
                                        $this->session->remove("Exchange_rates");

                                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0)
                                        {
                                                unset($_SESSION['Exchange_rates']);
                                        }

                                        if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                                        {
                                                if (isset($this->options['ALL']['manuel-input-exchange-rate']))
                                                {
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                                else
                                                {
                                                        /*
                                                        * ------------------------------------------------
                                                        * Initialization
                                                        * ------------------------------------------------
                                                        */

                                                        $usd = '';
                                                        $pound = '';
                                                        $eur = '';
                                                        $rand = '';

                                                        $data['from_currency'] = 'USD';
                                                        $data['to_currency'] = 'CDF';
                                                        $data['type'] = 'TTB';
                                                        $data['language'] = 'P';

                                                        # Nom du core banking
                                                        $core_banking = strtolower($this->core_banking);

                                                        $this->igor = new \Modules\Services\Igor\Controllers\Igor();

                                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                                        if (method_exists($this->{$core_banking}, 'get_exchange_rate')) 
                                                        {
                                                                if($this->core_banking=='Finacle')
                                                                {
                                                                        $return = $this->{$core_banking}->get_exchange_rate_v2($data);
                                                                }
                                                                else
                                                                {
                                                                        $return = $this->{$core_banking}->get_exchange_rate($data);
                                                                }
                                                                

                                                        }
                                                        else
                                                        {
                                                                $result['code'] = '407';
                                                                echo json_encode($result);
                                                                die;
                                                        }

                                                        $return = json_decode($return, true);

                                                        if (isset($return['exchange_rate']) && $return['exchange_rate'] != "") {
                                                                
                                                                $usd = $return['exchange_rate'];

                                                                $data['from_currency'] = 'EUR';
                                                                $data['to_currency'] = 'CDF';

                                                                if($this->core_banking == 'Finacle')
                                                                {
                                                                        $return = $this->{$core_banking}->get_exchange_rate_v2($data);
                                                                }
                                                                else
                                                                {
                                                                        $return = $this->{$core_banking}->get_exchange_rate($data);
                                                                }

                                                                $return = json_decode($return, true);

                                                                $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                $_POST['usd'] = $usd;
                                                                $_POST['eur'] = $eur;
                                                                $_POST['rand'] = "";
                                                                $_POST['pound'] = "";

                                                                $dollar = str_replace(' ','',$_POST['usd']);
                                                                $dollar = str_replace(',','.',$dollar);

                                                                if($_POST['eur'] !="")
                                                                {
                                                                        $euro = str_replace(' ','',$_POST['eur']);
                                                                        $euro = str_replace(',','.',$euro);
                                                                        $data1['Euro_5']     =   $euro;
                                                                }

                                                                $data1['Date_1']     =   gmdate('Y-m-d H:i:s');
                                                                $data1['Status_2']   =   1;
                                                                $data1['Account_3']  =   $this->session->userdata['account_id'];
                                                                $data1['Dollar_4']   =   $dollar;
                                                                $data1['Agence_8']   =   $_SESSION['Logiref_agence'];
                                                                $data1['Day_9']      =   gmdate('Y-m-d');
                                                                $data1['Checkerid_11']='0001';
                                                                $data1['Makerid_10']='0002';

                                                                $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                $this->ratesModel->save_taux($data1, NULL);

                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                        elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "") 
                                                        {
                                                                foreach ($return['ExchangeRateList'] as $row) 
                                                                {
                                                                if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP') 
                                                                {
                                                                        $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                } 
                                                                elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR') 
                                                                {
                                                                        $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                } 
                                                                elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD') 
                                                                {
                                                                        $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                } 
                                                                elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR') 
                                                                {
                                                                        $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                }
                                                                }

                                                                if ($usd != "" && $eur != "") {
                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = $rand;
                                                                        $_POST['pound'] = $pound;

                                                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = "";
                                                                        $_POST['pound'] = "";

                                                                        $dollar = str_replace(' ','',$_POST['usd']);
                                                                        $dollar = str_replace(',','.',$dollar);

                                                                        if($_POST['eur'] !="")
                                                                        {
                                                                                $euro = str_replace(' ','',$_POST['eur']);
                                                                                $euro = str_replace(',','.',$euro);
                                                                                $data['Euro_5']     =   $euro;
                                                                        }

                                                                        $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                                                                        $data['Status_2']   =   1;
                                                                        $data['Account_3']  =   $this->session->userdata['account_id'];
                                                                        $data['Dollar_4']   =   $dollar;
                                                                        $data['Agence_8']   =   $_SESSION['Logiref_agence'];
                                                                        $data['Day_9']      =   gmdate('Y-m-d');
                                                                        $data['Checkerid_11']='0001';
                                                                        $data['Makerid_10']='0002';

                                                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                                                                        $this->ratesModel->save_taux($data, NULL);

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                        }

                                        // Reinitialisation des valeurs de la session
                                        $this->userModel->get_privilegies();

                                        if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && in_array($_SESSION['Logiref_role'],[3,4]))
                                        {
                                                $path = explode("/",$this->uri->getPath());

                                                if ($this->uri->getPath() !== '/branch/taxrates/set/taux' && $this->uri->getPath() !== '/branch/taxrates/display/taux') {

                                                        if (!preg_match('#^/branch/taxrates/save/taux(?:/\d+)?$#', $this->uri->getPath()) && !in_array("overview", $path)) {

                                                                //return redirect()->to(base_url("branch/taxrates/set/taux"));
                                                                $this->module = $this->session->get("Logiref_module");
                                                                foreach($this->module as $value)
                                                                {
                                                                        if($value == "logiref"){
                                                                                return redirect()->to(base_url('branch/taxdashboards/set/overview'));
                                                                        }
                                                                        elseif($value == "elicense"){
                                                                                return redirect()->to(base_url('elicense/dashboards/set/overview'));
                                                                        }
                                                                        elseif($value == "eximtrade"){
                                                                                return redirect()->to(base_url('eximtrade/dashboards/set/overview'));
                                                                        }
                                                                }
                                                        }

                                                }

                                        }
                                }

                        }
                        elseif(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return true;
                        }
                        else{
                                return redirect()->to(base_url('main/denied'));
                        }
                }

                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        // Code exécuté après le contrôleur (optionnel)
                }
        }