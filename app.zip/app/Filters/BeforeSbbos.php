<?php

        namespace App\Filters;

        use CodeIgniter\HTTP\RequestInterface;
        use CodeIgniter\HTTP\ResponseInterface;
        use CodeIgniter\Filters\FilterInterface;
        use App\Libraries\Chtml;
        use Modules\Admin\Models\EtollUsersModel;
        use Modules\Admin\Models\EtollRatesModel;
        use Modules\Admin\Models\EtollCaisseModel;

        class BeforeSbbos implements FilterInterface
        {
                public $etollUsersModel;
                public $etollRatesModel;
                public $session;
                public $data;
                public $uri;
                public $etollCaissesModel;

                public function before(RequestInterface $request, $arguments = null)
                {
                        // Initialisation de la librairie
                        $this->etollUsersModel = new EtollUsersModel();
                        $this->etollRatesModel = new EtollRatesModel();
                        $this->etollCaissesModel = new EtollCaisseModel();
                        $this->session = \Config\Services::session();
                        $this->data = array();
                        $this->uri = service('uri');
                        $this->data['chtml'] = new Chtml();

                        if(!empty($_SESSION['Logiref_role']) && !empty($_SESSION['userdata']) && $_SESSION['userdata']['user_type'] != '100'){

                                $this->etollRatesModel->get_exchange_rates();

                                // Reinitialisation des valeurs de la session
                                $this->etollUsersModel->get_privilegies();

                                if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && in_array($_SESSION['Logiref_role'],[3,4]))
                                {
                                        $path = explode("/",$this->uri->getPath());

                                        if ($this->uri->getPath() !== '/etoll/rates/set/taux' && $this->uri->getPath() !== '/etoll/rates/display/taux' && $this->uri->getPath() !== '/etoll/rates/display/taux2') {

                                                if (!preg_match('#^/etoll/rates/save/taux(?:/\d+)?$#', $this->uri->getPath()) && !preg_match('#^/etoll/rates/save/taux2(?:/\d+)?$#', $this->uri->getPath()) && !in_array("overview", $path)) {

                                                        //return redirect()->to(base_url("etoll/rates/set/taux"));
                                                        return redirect()->to(base_url('etoll/dashboards/set/overview'));
                                                }

                                        }

                                }
                        }
                        elseif(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return true;
                        }
                        else{
                                return redirect()->to(base_url('main/denied'));
                        }
                }

                public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
                {
                        // Code exécuté après le contrôleur (optionnel)
                }
        }