<?php

namespace App\Filters;

use CodeIgniter\Config\Services;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Security\Exceptions\SecurityException;

class DisableCSRF implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null) 
    {
        
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No post-processing required
    }
}
