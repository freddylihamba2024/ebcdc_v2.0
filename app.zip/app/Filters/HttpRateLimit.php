<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

class HttpRateLimit implements FilterInterface
{
        /**
         * Do whatever processing this filter needs to do.
         * By default it should not return anything during
         * normal execution. However, when an abnormal state
         * is found, it should return an instance of
         * CodeIgniter\HTTP\Response. If it does, script
         * execution will end and that Response will be
         * sent back to the client, allowing for error pages,
         * redirects, etc.
         *
         * @param RequestInterface $request
         * @param array|null       $arguments
         *
         * @return mixed
         */
        
        // max requests allowed per minute
        private $limit = 60;
        private $period = 60; // seconds

        public function before(RequestInterface $request, $arguments = null)
        {
                $cache = Services::cache();
                $ip = $request->getIPAddress();
                $key = "ratelimit_" . md5($ip);

                $data = $cache->get($key);

                if (!$data) {
                        $data = [
                                'requests' => 1,
                                'expires'  => time() + $this->period
                        ];
                        $cache->save($key, $data, $this->period);
                } else {
                        if ($data['requests'] >= $this->limit) {
                                // Limit exceeded
                                $reset = $data['expires'];
                                return service('response')
                                        ->setStatusCode(429)
                                        ->setHeader('Retry-After', $reset - time())
                                        ->setBody('Too Many Requests');
                        }
                        $data['requests']++;
                        $cache->save($key, $data, $this->period);
                }

                // Add headers for client visibility
                $remaining = $this->limit - $data['requests'];
                service('response')
                        ->setHeader('X-Rate-Limit-Limit', $this->limit)
                        ->setHeader('X-Rate-Limit-Remaining', max(0, $remaining))
                        ->setHeader('X-Rate-Limit-Reset', $data['expires']);
        }
        /**
         * Allows After filters to inspect and modify the response
         * object as needed. This method does not allow any way
         * to stop execution of other after filters, short of
         * throwing an Exception or Error.
         *
         * @param RequestInterface  $request
         * @param ResponseInterface $response
         * @param array|null        $arguments
         *
         * @return mixed
         */
        public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
        {
                //
        }
}
