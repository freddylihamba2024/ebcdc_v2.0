


<!-- APPLICATIONS ------------------------------------------------------------------------------------------------------------------>
<script src="<?php echo base_url('ikwook_bootstraps/v5/'); ?>/js/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/plugins/dataTables/datatables.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/iframeResizer.contentWindow.min.js'); ?>" type="text/javascript"></script>

<input type="hidden" value='0' id="count_reload">
<!-- *End ---->        

<script>

$(document).ready(function() {
	
	var userid_session = '<?php echo $uid; ?>';

    var incCount = localStorage.getItem("incCount");
    
    if(isNaN(incCount))
    {
        localStorage.setItem("incCount", '0');
    }
     
    var count_reload = localStorage.getItem("incCount");

    verify_navigation_data();
    
    function verify_navigation_data(){
        $('#modal').modal('show');
        
        var url = '<?php echo base_url($module.'/rbo/data/verify_navigation_data'); ?>/'+userid_session;

        $.ajax({    
                type        : 'GET', 
                url         : url, 
                dataType    : 'json', 
                encode      : true,
                success: function(data){
                    
                    if(data.result != '0')
                    {
                        localStorage.setItem("customer_code", data.customer_code);
                        localStorage.setItem("customer_login", data.customer_login);
                        localStorage.setItem("customer_id", data.customer_id);
                        
                        display(data.customer_code);
                    }
                    else
                    {
                        if(count_reload >= 2)
                        {
                            $('#modal').modal('hide');
                        }
                        else
                        {   
                            count_reload = parseFloat(count_reload);
                            count_reload += 1;
                            localStorage.setItem("incCount", count_reload);
                            window.location.reload();
                        }
                    }
                },
                error:function(error){
                    $('#modal').modal('hide');
                }
        });
    }
    
    function display(customer_code){
        $('#modal').modal('show');
        var url = '<?php echo base_url($module.'/rbo/display/view'); ?>/'+customer_code;
        $.get(url, function(data, status){
            $('#modal').removeClass('fade');
            $('#modal').modal('hide');
            $("#container").html(data);
        });
    }
});
	
</script>        


    
    
