<!-- ===== LOADER (masqué par défaut) ===== -->
<div id="loaderOverlay" class="d-none">
    <div class="text-center">
        <i class="fa fa-spinner fa-spin fa-2x mb-3"></i><br>
        <span id="loaderText">Chargement...</span>
    </div>
</div>


<!-- Mainly scripts -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.1.1.min.js'); ?>"></script>

<!-- Popper js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/popper.min.js'); ?>"></script>

<!-- Bootstrap 4 js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>

<!-- DATA DATEPICKER JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/clockpicker/clockpicker.js"></script>

<!-- DATA TABLES JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dataTables/datatables.min.js'); ?>"></script>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/footable/footable.all.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/pace/pace.min.js'); ?>"></script>

<!-- DROPZONE JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dropzone/dropzone.js'); ?>"></script>

<!-- iCheck -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/iCheck/icheck.min.js'); ?>"></script>

<!-- Select2 -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/select2/select2.full.min.js'); ?>"></script>

<!-- Sweetalert JS-->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

<!-- Peity demo -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/demo/peity-demo.js'); ?>"></script>

<script>
    $(document).ready(function() {

        /** iCheck configuration */
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });

        $(".select2").select2({
            theme: 'bootstrap4',
            // placeholder: "Select a state",
            allowClear: true
        });

    });
</script>

<!-- page script -->
<script type="text/javascript">

    $(document).ready(function() {

        var role = '<?= isset($role) ? $role : ""; ?>'

        <?php if (isset($deny) && $deny == true): ?>

            call("<?php echo base_url($module . '/' . $application . '/display/deny'); ?>", "containers");

        <?php else : ?>
            /* DASHBOARDS  -----------------------------------------------------------------*/
            <?php if ($module == 'branchless' && $uri->getSegment(2) == 'main') : ?>

                call("<?php echo base_url($module . '/dashboards/display/overview'); ?>", "containers");

            <?php endif; ?>

            /* APPLICATIONS - RULES  --*/
            <?php $liste_applications = array('main', 'page', 'admin', 'accounts', 'fees', 'settings', 'stakeholders', 'branches', 'account', 'dashboards', 'admin', 'dashboard', 'users', 'pos', 'caisses', 'partners', 'events', 'cashbooks', 'counters', 'guichets', 'categories', 'qleads', 'categories', 'queue', 'equipments', 'logiref', 'etoll', 'referentiel', 'eximtrade', 'elicense','quitus') ?>
            /* APPLICATIONS - RULES  -------------------------------------------------------------------------------------------------------------------*/

            <?php
                if ($module != '' && $uri->getSegment(3) == 'set'  && $uri->getSegment(4) != '') : 

                    if($uri->getSegment(5) != ''):
            ?>
                        call("<?php echo base_url($module . "/" . $application . "/display/".$uri->getSegment(4)."/".$uri->getSegment(5)); ?>", "containers");
            <?php
                    else :
            ?>
                        call("<?php echo base_url($module . "/" . $application . "/display/".$uri->getSegment(4)); ?>", "containers");
            <?php
                    endif;

                endif;
            ?>

        <?php endif; ?>
    });

    function call(url, containers) {
      
        $("#loaderOverlay").css("background", "rgba(73, 80, 87, 0.9)").removeClass("d-none").addClass("active");
        $("#loaderText").text("Chargement...");

        $("#" + containers).html("");
        $.get(url, function(data, status) {
            $("#loaderOverlay").addClass("d-none").removeClass("active");
            $("#" + containers).html(data);
           
        });
    }

    function view(url) {
        $("#loader").html('<div class="spinner-border text-secondary text-center mt-5" role="status"><span class="sr-only">Loading...</span></div>');
        $("#containers").html("");
        $.get(url, function(data, status) {
            $("#containers").html(data);
            $("#loader").html('');
        });
    }

    function get_csrf() {
        $.ajax({
                url:"<?php echo base_url('services/generate_csrf') ?>",
                type:"GET",
                enctype:"multipart/form-data",
                dataType: 'json',
                data:false,
                headers: {
                    'accept': 'application/json',
                    'User-Agent': "Etoll"
                },
                processData:false,
                contentType:false,
                success:function(response){
                    var read = JSON.parse(JSON.stringify(response, null, 2));
                    $("input[name=csrf_name]").val(read.message);
                },
                error: function(xhr, status, error) {
                    console.log(err);
                }
        });
    }

    /* ---------- Redirection automatique si le système constate l'inactivité de l'utilisateur ---------- */

    let inactivityTimer;

    function resetInactivity() {
        clearTimeout(inactivityTimer); // Reset du timer
        inactivityTimer = setTimeout(checkSession, 600000); // 10 minutes (600000 ms)
    }

    function checkSession() {
        $.ajax({
            url: "<?= base_url("branchless/main/checksession") ?>",
            method: "GET",
            dataType: "json",
            success: function(response)
            {
                if (response.redirect)
                {
                    window.location.href = response.redirect;
                }
            }
        });
    }

    // Réinitialise le timer dès qu'il y a une action utilisateur
    $(document).on('mousemove keypress click scroll', resetInactivity);

    // Démarre le timer dès le chargement de la page
    resetInactivity();

</script>