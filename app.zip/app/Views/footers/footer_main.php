<!-- Popper js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/popper.min.js'); ?>"></script>

<!-- Bootstrap 4 js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>

<!-- DATA DATEPICKER JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/clockpicker/clockpicker.js"></script>

<!-- DATA TABLES JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dataTables/datatables.min.js'); ?>"></script>

<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/footable/footable.all.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/pace/pace.min.js'); ?>"></script>

<!-- DROPZONE JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dropzone/dropzone.js'); ?>"></script>

<!-- iCheck -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/iCheck/icheck.min.js'); ?>"></script>

<!-- Select2 -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/select2/select2.full.min.js'); ?>"></script>

<!-- Sweetalert JS-->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

<!-- Toastr JS -->
<script src="<?php echo base_url('ikwook_bootstraps/librairies/toastr/toastr.min.js'); ?>"></script>

<script>
    $(document).ready(function() {

        /** iCheck configuration */
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });

        $(".select2").select2({
            theme: 'bootstrap4',
            // placeholder: "Select a state",
            allowClear: true
        });

    });

    function showAlert(message, type) {
        // ✅ Toastr options
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-top-right", // top-right, top-left, bottom-right, bottom-left
            "preventDuplicates": true,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "4000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };

        if (type === 'success') {
            toastr.success(message)
        }
        else if(type === 'warning') {
            toastr.warning(message)
        }
        else if(type === 'error') {
            toastr.error(message)
        }

    }
</script>

<!-- Tabs scripts -->
<script type="text/javascript">
    function openTab(tabId) {
        const tabs = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.tab-btn');

        tabs.forEach(tab => tab.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        document.getElementById(tabId).classList.add('active');
        event.target.classList.add('active');
    }
</script>

<!-- page script -->
<script type="text/javascript">
    $(document).ready(function() {

        deactivateAutocompletion();

        var role = '<?= isset($role) ? $role : ""; ?>'

        <?php if (isset($deny) && $deny == true): ?>

            call("<?php echo base_url($module . '/' . $application . '/display/deny'); ?>", "container");

        <?php else : ?>
            /* DASHBOARDS  -----------------------------------------------------------------*/
            <?php if ($module == 'admin' && $application == 'accounts'  && $uri->getSegment(3) == '') : ?>

                call("<?php echo base_url($module . '/accounts/display/dashboard'); ?>", "container");

            <?php endif; ?>

            /* APPLICATIONS - RULES  --*/
            <?php $liste_applications = array('main', 'page', 'admin', 'accounts', 'fees', 'settings', 'stakeholders', 'branches', 'account', 'dashboards', 'admin', 'dashboard', 'users', 'pos', 'caisses', 'partners', 'events', 'cashbooks', 'counters', 'guichets', 'categories', 'qleads', 'categories', 'queue', 'equipments', 'logiref', 'etoll', 'referentiel', 'eximtrade', 'elicense', 'quitus', 'payroll','immatriculation') ?>
            /* APPLICATIONS - RULES  -------------------------------------------------------------------------------------------------------------------*/

            <?php if (($module == 'admin' || $module == 'page') && in_array($application, $liste_applications) && $uri->getSegment(3) != '' && $uri->getSegment(4) != '') : ?>
                call("<?php echo base_url($module . "/" . $application . "/display/" . $uri->getSegment(4)); ?>", "container");
            <?php endif; ?>

            <?php
            if ($module != '' && $uri->getSegment(3) == 'set'  && $uri->getSegment(4) != '') :

                if ($uri->getSegment(6) != ''):
            ?>
                    call("<?php echo base_url($module . "/" . $application . "/display/" . $uri->getSegment(4) . "/" . $uri->getSegment(5) . "/" . $uri->getSegment(6)); ?>", "container");
                <?php
                elseif ($uri->getSegment(5) != ''):
                ?>
                    call("<?php echo base_url($module . "/" . $application . "/display/" . $uri->getSegment(4) . "/" . $uri->getSegment(5)); ?>", "container");
                <?php
                else :
                ?>
                    call("<?php echo base_url($module . "/" . $application . "/display/" . $uri->getSegment(4)); ?>", "container");
            <?php
                endif;

            endif;
            ?>

            <?php if ($module == 'branchless') : ?>

                call("<?php echo base_url($module . '/' . $application . '/display/' . $uri->getSegment(2)); ?>", "container");

            <?php endif; ?>

            <?php

            if ($module == 'main' && $uri->getSegment(2) == 'overview') :

                $page = $_SESSION['Logiref_module'];

                if (in_array("quitusfiscal", $page)) {
            ?>
                    callWithRedirect("<?php echo base_url("quitus/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("elicense", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("elicense/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("qleads", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("qleads/qleadsdashboard/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("payroll", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("payroll/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                }
                 elseif(in_array("immatriculation",$page))
                {
                 ?>
                    callWithRedirect("<?php echo base_url("immatriculation/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("eximtrade", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("eximtrade/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("etoll", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("etoll/dashboards/display/" . $uri->getSegment(2)); ?>", "container");
                <?php
                } elseif (in_array("logiref", $page)) {
                ?>
                    callWithRedirect("<?php echo base_url("branch/taxdashboards/display/" . $uri->getSegment(2)); ?>", "container");
            <?php
                }
            endif;

            ?>

        <?php endif; ?>
    });

    function callWithRedirect(url, container) {
        $("#loader").html('<div class="spinner-border text-secondary text-center mt-5" role="status"><span class="sr-only">Loading...</span></div>');
        $("#" + container).html("");

        $.get(url)
            .done(function(data, status, xhr) {
                if (typeof data === "object" && data.redirect_url) {
                    window.location.href = data.redirect_url;
                    return;
                }
                $("#" + container).html(data);
            })
            .fail(function(xhr) {
                try {
                    const json = JSON.parse(xhr.responseText);
                    if (json.redirect_url) {
                        window.location.href = json.redirect_url;
                        return;
                    }
                    $("#" + container).html(json.message || xhr.responseText);
                } catch (e) {
                    $("#" + container).html(xhr.responseText);
                }
            })
            .always(function() {
                $("#loader").html('');
            });
    }

    function call(url, container) {
        $("#loader").html('<div class="spinner-border text-secondary text-center mt-5" role="status"><span class="sr-only">Loading...</span></div>');
        $("#" + container).html("");
        $.get(url, function(data, status) {
            $("#" + container).html(data);
            $("#loader").html('');
        });
    }

    function view(url) {
        $("#loader").html('<div class="spinner-border text-secondary text-center mt-5" role="status"><span class="sr-only">Loading...</span></div>');
        $("#container").html("");
        $.get(url, function(data, status) {
            $("#container").html(data);
            $("#loader").html('');
        });
    }

    function get_csrf() {
        $.ajax({
            url: "<?php echo base_url('services/generate_csrf') ?>",
            type: "GET",
            enctype: "multipart/form-data",
            dataType: 'json',
            data: false,
            headers: {
                'accept': 'application/json',
                'User-Agent': "Etoll"
            },
            processData: false,
            contentType: false,
            success: function(response) {
                var read = JSON.parse(JSON.stringify(response, null, 2));
                $("input[name=csrf_name]").val(read.message);
            },
            error: function(xhr, status, error) {
                console.log(err);
            }
        });
    }

    /* ---------- Redirection automatique si le système constate l'inactivité de l'utilisateur ---------- */

    let inactivityTimer;

    function resetInactivity() {
        clearTimeout(inactivityTimer); // Reset du timer
        inactivityTimer = setTimeout(checkSession, 600000); // 10 minutes (600000 ms)
    }

    function checkSession() {
        $.ajax({
            url: "<?= base_url("main/checksession") ?>",
            method: "GET",
            dataType: "json",
            success: function(response) {
                if (response.redirect) {
                    window.location.href = response.redirect;
                }
            }
        });
    }



    // Réinitialise le timer dès qu'il y a une action utilisateur
    $(document).on('mousemove keypress click scroll', resetInactivity);

    // Démarre le timer dès le chargement de la page
    resetInactivity();

    function deactivateAutocompletion()
    {
        $('form, input, select, textarea').attr('autocomplete', 'off');
    }
</script>