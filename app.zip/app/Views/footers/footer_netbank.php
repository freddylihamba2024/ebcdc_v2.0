<!-- APPLICATIONS ------------------------------------------------------------------------------------------------------------------>
<!-- <script src="<?php echo base_url('ikwook_bootstraps/v5/'); ?>/js/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/plugins/dataTables/datatables.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v5/js/iframeResizer.contentWindow.min.js'); ?>" type="text/javascript"></script> -->

<!-- Popper js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/popper.min.js'); ?>"></script>

<!-- Bootstrap 4 js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/metisMenu/jquery.metisMenu.js'); ?>"></script>

<!-- Metis Menu js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>"></script>

<!-- DATA DATEPICKER JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/clockpicker/clockpicker.js"></script>

<!-- DATA TABLES JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dataTables/datatables.min.js'); ?>"></script>

<!-- FooTable -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/footable/footable.all.min.js'); ?>"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/inspinia.js'); ?>"></script>
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/pace/pace.min.js'); ?>"></script>

<!-- DROPZONE JS -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/dropzone/dropzone.js'); ?>"></script>

<!-- iCheck -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/iCheck/icheck.min.js'); ?>"></script>

<!-- Select2 -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/select2/select2.full.min.js'); ?>"></script>

<!-- Sweetalert JS-->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/plugins/sweetalert/sweetalert.min.js'); ?>"></script>



<!-- page script -->
<script type="text/javascript">

    var userid_session = '<?php echo $uid; ?>';
    verify_navigation_data();
    
    function verify_navigation_data(){
        $('#modal').modal('show');
        
        var url = '<?php echo base_url($module.'/tmb/main/data/verify_navigation_data'); ?>/'+userid_session;
        $.ajax({    
                type        : 'GET', 
                url         : url, 
                dataType    : 'json', 
                encode      : true,
                success: function(data){
                    
                    if(data.result != '0')
                    {
                        localStorage.setItem("customer_code", data.customer_code);
                        localStorage.setItem("customer_login", data.customer_login);
                        localStorage.setItem("customer_id", data.customer_id);
                        
                        display(data.customer_code);
                    }
                    else
                    {
                            //window.location.reload();
                    }
                },
                error:function(error){
                    $('#modal').modal('hide');
                }
        });
    }
    
    // function display(customer_code){
    //     $('#modal').modal('show');
    //     var url = '<?php //echo base_url($module.'/rbo/display/view'); ?>/'+customer_code;
    //     $.get(url, function(data, status){
    //         $('#modal').removeClass('fade');
    //         $('#modal').modal('hide');
    //         $("#container").html(data);
    //     });
    // }

    //display();

    function display(customer_code){
        $('#modal').modal('show');
        //var url = '<?php //echo base_url($module.'/tmb/main/display/overview'); ?>/'+customer_code;
        var url = '<?php echo base_url($module.'/tmb/main/display/view'); ?>/'+customer_code;
        $.get(url, function(data, status){
            $('#modal').removeClass('fade');
            $('#modal').modal('hide');
            $("#container").html(data);
        });
    }
</script>