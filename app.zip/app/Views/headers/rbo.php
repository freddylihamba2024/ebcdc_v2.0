<head>
    <meta charset="ISO-8859-1">
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
    <title>iKwook Logiref</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

    <link href="<?php echo base_url('ikwook_bootstraps/v5/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/font-awesome.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/webBootstrap.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/bootstrap-select.min.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/webMainAboV6.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/webSpecifAbo.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/style2.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/datepicker.css'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('ikwook_bootstraps/v5/css/rawbank4.css'); ?>" rel="stylesheet" type="text/css" />
</head>
