<!-- Navbar -->
<div class="row border-bottom">
    <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0; background-color: #fff;">
        <div class="navbar-header d-flex align-items-center pl-3">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary d-none" href="#"><i class="fa fa-bars"></i> </a>
            <img width="120" src="<?php echo base_url('ikwook_files/logos/logo.png'); ?>" class="img-fluid" />

        </div>
        <ul class="nav navbar-top-links navbar-right padding">
            <div class="alert-box">
                <div class="alert-box-icon">
                    <span class="counter"><?= count($bl_alerts) ?></span>
                    <span class="icon fa fa-bell fa-2x"></span>
                </div>
                <div class="alert-container hide-alert-container">
                    <div class="alert-container-header">
                        Notifications
                    </div>
                    <div class="alert-container-body">
                        <?php
                        if (!empty($bl_alerts)) :
                            foreach ($bl_alerts as $row) :
                                $bl_info = json_decode($row->Bulletin_9);
                                ?>

                                <div class="timeline-item">
                                    <div class="message">
                                        <div class="d-flex justify-content-between">
                                            <?php if ($row->Type_13 == 'batch') : ?>
                                                <p><strong>Bulletin en lot </strong></p>
                                            <?php else: ?>
                                                <p><strong>Paiement BL <?= isset($bl_info->serial) ? $bl_info->serial . '' . $bl_info->number : ""; ?></strong></p>
                                            <?php endif; ?>
                                            <?php if ($row->Lock_12 == 0) : ?>
                                                <?php if ($row->Type_13 == 'batch') : ?>
                                                    <a href="#" onclick="edit_alert_batch(<?php echo $row->Paiementid_11; ?>)"><i class='fa fa-edit fa-1x'></i></a>
                                                <?php else: ?>
                                                    <a href="#" onclick="edit_alert(<?php echo $row->Id_0; ?>)"><i class='fa fa-edit fa-1x'></i></a>
                                                <?php endif; ?>

                                            <?php else: ?>
                                                <?php if ($row->Lock_12 == $user_id) : ?>
                                                    <?php if ($row->Type_13 == 'batch') : ?>
                                                        <a href="#" onclick="edit_alert_batch(<?php echo $row->Paiementid_11; ?>)"><i class='fa fa-edit fa-1x'></i></a>
                                                    <?php else: ?>
                                                        <a href="#" onclick="edit_alert(<?php echo $row->Id_0; ?>)"><i class='fa fa-edit fa-1x'></i></a>
                                                    <?php endif; ?>
                                                <?php else : ?>
                                                    <span><a class="cursor-pointer" onclick="" href="#"><i class="fa fa-lock font-action-edit text-yellow f18"></i></a></span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>

                                        <p><?php echo $row->Message_7; ?></p>

                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="hour"><i class='fa fa-file-text'></i>&nbsp;

                                                <?php
                                                $s = $row->Date_1;
                                                $dt = new DateTime($s);

                                                $date = $dt->format('d-m-Y');
                                                $time = $dt->format('h:i:s');

                                                echo $time;
                                                ?>

                                            </span>

                                            <span class="hour">
                                                <?php
                                                $now = gmdate('Y-m-d H:i:s');

                                                $current_date_time_sec = strtotime($row->Date_1);
                                                $future_date_time_sec = strtotime($now);

                                                $difference = $future_date_time_sec - $current_date_time_sec;

                                                $seconds = ($difference % 60);
                                                $seconds = (int) $seconds;

                                                $minutes = ($difference / 60 % 60);
                                                $minutes = (int) $minutes;

                                                $hours = ($difference / 3600);
                                                $hours = (int) $hours;

                                                $days = ($hours / 24);
                                                $days = (int) $days;

                                                if ($minutes < 1) :
                                                    if ($seconds == 1)
                                                        echo "Il y a " . $seconds . " seconde";
                                                    else
                                                        echo "Il y a " . $seconds . " secondes";
                                                elseif ($hours < 1) :
                                                    if ($minutes == 1)
                                                        echo "Il y a " . $minutes . " minute";
                                                    else
                                                        echo "Il y a " . $minutes . " minutes";
                                                elseif ($days < 1) :
                                                    if ($hours == 1)
                                                        echo "Il y a " . $hours . " heure";
                                                    else
                                                        echo "Il y a " . $hours . " heures";
                                                else :
                                                    if ($days == 1)
                                                        echo "Il y a " . $days . " jour";
                                                    else
                                                        echo "Il y a " . $days . " jours";
                                                endif;
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <div>
                                <span class='text-gray f16 '>Aucune alerte trouv&eacute;e !<br /><br /></span>
                            </div>
                        <?php endif; ?>


                    </div>
                </div>
            </div>
            <li class="dropdown">
                <a class="" href="<?php echo base_url('main/overview'); ?>">

                    <span class="text-blue">
                        <i class="fa fa-th fa-2x"></i>
                    </span>

                </a>
            </li>

            <li class="dropdown">
                <a class="dropdown-toggle count-info" data-toggle="dropdown" href="">
                    <span class="text-blue"><?= $session->userdata['user_fname'] ?> <?= $session->userdata['user_sname'] ?> <b class="caret"></b></span>
                    <img  class="img-circle" alt="image"   src="<?php echo base_url('ikwook_files'); ?>/profiles/avatar.png" width="30" height="30">
                </a>
                <ul class="dropdown-menu dropdown-alerts">
                    <li class="center">
                        <div class="col-sm-12 col-xs-12">
                            <a href="<?php echo base_url('project'); ?>" class="bg-default ">
                                <img src="<?php echo base_url('ikwook_files'); ?>/profiles/avatar.png" width="100" height="100" class="img-circle" />
                            </a>
                        </div>
                        <div class="col-sm-12 col-xs-12">
                            <span class="text-blue"><br/><?php echo $session->userdata['account_business']; ?><br/></span>
                            <span class="text-gray">Account ID: <?php echo $session->userdata['account_id']; ?><br/></span>
                        </div>
                    </li>
                    <li class="dropdown-divider"></li>
                    <li  class="">
                        <a class="dropdown-item" href="<?= base_url('/admin/users/set/password') ?>">
                            <div>
                                <i class="fa fa-user text-green f16"></i>&nbsp;&nbsp; Initialisation mot de passe
                            </div>
                        </a>
                    </li>
                    <li class="dropdown-divider"></li>
                    <li  class="">
                        <a class="dropdown-item" href="<?= base_url('/branch/taxusers/set/accountsydonia') ?>">
                            <div>
                                <i class="fa fa-globe text-black f16"></i>&nbsp;&nbsp;Configuration accès SYDONIA
                            </div>
                        </a>
                    </li>
                    <li class="dropdown-divider"></li>
                    <li  class="">
                        <a href="<?= base_url('/admin/users/set/profile') ?>" class="dropdown-item">
                            <div>
                                <i class="fa fa-cogs text-aqua f16"></i>&nbsp;&nbsp Informations personnelles
                            </div>
                        </a>
                    </li>
                    <?php if (isset($_SESSION['Logiref_role']) && (int) $_SESSION['Logiref_role'] === 7) : ?>
                    <li class="dropdown-divider"></li>
                    <li class="">
                        <a href="<?= base_url('/admin/users/change-guichet') ?>" class="dropdown-item">
                            <div>
                                <i class="fa fa-random text-blue f16"></i>&nbsp;&nbsp Changer de guichet
                            </div>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="dropdown-divider"></li>
                    <li  class="">
                        <a href="<?php echo base_url("/main/signout"); ?>" class="dropdown-item">
                            <div>
                                <i class="fa fa-sign-out text-red f16"></i>&nbsp;&nbsp; 
                                Se d&eacute;connecter
                            </div>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>

    </nav>
</div>
<!-- /.navbar -->
<script type="text/javascript">
    $(document).ready(function () {

    });

    $('.alert-box').click(function (e) {
        $('.alert-container').toggleClass('hide-alert-container');
    });

    $(window).click(function (e) {
        if (e.target.offsetParent.className !== 'alert-box') {
            $('.alert-container').addClass('hide-alert-container');
        }
    });

    function edit_alert(id) {
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        //var url = '<?php echo base_url('branch/taxbulletin/display/step_1_process'); ?>/' + id;

        var url = '<?php echo base_url('branch/taxbulletin/display/step_1_branchless'); ?>/' + id;

        $.get(url, function (data, status) {
            if (data == '0') {
                $("#loader").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
            } else {
                $("#loader").html('');
                $("#container").html(data);
            }
        });
    }

    function edit_alert_batch(id) {

        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif') ?>" />');

        var url = '<?php echo base_url('branch/taxbulletin/display/batch_step_1_process'); ?>/' + id;

        $.get(url, function (data, status) {

            if (data == '0') {
                $("#loader").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-d-none="true" class="pull-left">x</button>Le bulletin n\'\existe pas, impossible de proc&eacute;der au traitement.</div>');
            } else {
                $("#loader").html('');
                $("#container").html(data);
            }
        });
    }

</script>
