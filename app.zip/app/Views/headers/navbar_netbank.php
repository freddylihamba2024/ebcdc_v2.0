<div class="row border-bottom" style="border: 1px solid #d7352c; padding: 10px; background-color: #d7352c;">
    <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0; background-color: #d7352c;">
        <!-- Logo on the left -->
        <div style="display: flex; align-items: center;">
            <!-- <a href="<?php //echo base_url('main/overview'); ?>" style="padding-right: 10px; color:white;"><i class="fa fa-bars fa-4x"></i></a> -->
            <img width="100" src="<?php echo base_url('ikwook_files/logos/tmb_netbank.png'); ?>" style="display: block;" />
        </div>
        <!-- Texts on the right -->
        <div style="display: flex; align-items: center;">
            <span style="display: flex; align-items: center; padding-right: 20px;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>support@ikwook.cd</span> -->
            </span>
            <span style="display: flex; align-items: center;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>+243 850 600 500</span> -->
            </span>
        </div>
    </nav>
</div>

