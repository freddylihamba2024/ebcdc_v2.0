<head>
    <title><?php echo isset($title) ? $title : "iKwook" ?></title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui, width=device-width, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="iKwook" />

    <!-- Favicon icon -->
    <!-- <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon"> -->

    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" type="text/css" />
  
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome'); ?>/css/font-awesome.css">

    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/iCheck/custom.css'); ?>" type="text/css" />
    
    <!-- Data table -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/dataTables/datatables.min.css'); ?>" type="text/css" />
    
    <!-- Datapicker -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/datapicker/datepicker3.css'); ?>" type="text/css" />

    <!-- Clockpicker -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/clockpicker/clockpicker.css'); ?>" type="text/css" />

    
    <!-- Sweetalert -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/sweetalert/sweetalert.css'); ?>"  type="text/css"  />
    
    <!-- Select2 js -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2.min.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2-bootstrap4.min.css'); ?>" type="text/css" />

    <!-- Animate css -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" type="text/css" />

    <!-- Inspinia css -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" type="text/css" />

    <!-- Custome css  -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-netbank.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" type="text/css" />

    
    <!-- jQuery -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.1.1.min.js'); ?>"></script>

    <!-- Full Calendar Moment -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/moment.min.js"></script>

    <!-- Full Calendar -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/fullcalendar.min.js"></script>

    <!-- Data table -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/dataTables/datatables.min.js"></script>
    
    <!-- Sweetalert -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/sweetalert/sweetalert.min.js"></script>
    
</head>