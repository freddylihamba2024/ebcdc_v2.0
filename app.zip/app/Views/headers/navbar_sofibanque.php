<div class="row border-bottom" style="border-bottom: 3px solid #F8C00F !important;  padding: 10px; background-color: #ff0000;">
    <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0; background-color: #ff0000; ">

        <div class="col-md-2"></div>

        <div class="col-md-8">
        <!-- Logo on the left -->
        <div style="display: flex; align-items: center;">
            <!-- <a href="<?php //echo base_url('main/overview'); ?>" style="padding-right: 10px; color:white;"><i class="fa fa-bars fa-4x"></i></a> -->
            <img width="160" src="<?php echo base_url('ikwook_files/logos/logo_sofibanque.png'); ?>" style="display: block;" />
        </div>
        <!-- Texts on the right -->
        <div style="display: flex; align-items: center;">
            <span style="display: flex; align-items: center; padding-right: 20px;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>support@ikwook.cd</span> -->
            </span>
            <span style="display: flex; align-items: center;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>+243 850 600 500</span> -->
            </span>
        </div>
        </div>

        <div class="col-md-2"></div>

    </nav>
</div>

