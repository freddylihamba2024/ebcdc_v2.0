<nav class="navbar navbar-expand-lg navbar-dark auth-navbar" style="padding-top: 0.2rem ; padding-bottom: 0.2rem !important; min-height: 20px !important;">
    <div class="header">
        <div class="container-fluid d-flex justify-between align-items-center">
            <!-- Logo -->
            <div class="logo">
                <div class="navbar-header d-flex align-items-center p-3">
                    <!-- <a class="navbar-minimalize minimalize-styl-2 btn btn-primary d-none" href="#">
                        <i class="fa fa-bars"></i>
                    </a> -->
                    <img width="120" src="<?php echo base_url('ikwook_files/logos/Standard_bank_rdc_logo.png'); ?>" class="img-fluid" />
                </div>
            </div>

            <!-- Bloc navigation (menu + profil utilisateur) aligné à droite -->
            <div class="d-flex align-items-center ms-auto">
                <!-- Profil utilisateur -->
                <?php 
                    $username = $session->userdata['user_fname']. " ". $session->userdata['user_sname'];
                    $words = explode(" ", $username);

                    $initials = "";
                    foreach ($words as $word) 
                    {
                        $initials .= strtoupper($word[0]);
                    }
                ?>
                <div id="userInfo" class="items-center space-x-3 bLeft" style="display: flex;">
                    <div class="relative">
                        <button onclick="toggle_dropdown('userDropdown')" class="flex items-center space-x-3 hover:bg-gray-50 rounded-lg p-2 transition-colors">
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-900" id="userName"><?= $username?></p>
                                <p class="text-xs text-gray-500" id="userRole">Opérateur</p>
                            </div>
                            <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                                <span class="text-white text-sm font-medium"><?= $initials; ?></span>
                            </div>
                            <i class="fa fa-chevron-down text-gray-400 text-xs"></i>
                        </button>
                        <div id="userDropdown" class="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50" style="display: none;">
                            <div class="p-3 border-b border-gray-100 text-center">
                                <p class="font-medium text-gray-900"><?= $username ?></p>
                                <p class="text-sm text-gray-500"><?= "Login : ". $session->userdata['user_login'] ?> </p>
                            </div>
                            <div class="py-2">
                                <a href="#" onclick="showProfileModal()" class="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fa fa-user mr-3 text-gray-400"></i>Mon profil
                                </a>
                                <a href="#" onclick="showSettingsModal()" class="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fa fa-cog mr-3 text-gray-400"></i>Paramètres
                                </a>
                                <a href="#" onclick="showPasswordModal()" class="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fa fa-key mr-3 text-gray-400"></i>Changer mot de passe
                                </a>
                                <a href="#" onclick="showNotificationSettings()" class="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fa fa-bell mr-3 text-gray-400"></i>Notifications
                                </a>
                                <div class="border-t border-gray-100 mt-2 pt-2">
                                    <button onclick="logout()" class="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                        <i class="fa fa-sign-out-alt mr-3"></i>Se déconnecter
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- Fin bloc navigation -->
        </div>
    </div>
</nav>

<!-- Bootstrap 4 js -->
<script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>
<script>
    // Fermer les dropdowns quand on clique à l'extérieur
    $(document).on('click', function(e) {
        const $target = $(e.target);
        const isDropdownButton = $target.closest('[onclick*="toggle_dropdown"]').length > 0;

        if (!isDropdownButton) {
            $('[id$="Dropdown"]').each(function() {
                $(this)
                    .hide()
                    .removeClass('opacity-100')
                    .addClass('opacity-0 invisible');
            });
        }
    });

    // Fonction toggle du dropdown
    function toggle_dropdown(dropdownId) {
        const $dropdown = $('#' + dropdownId);
        const isVisible = $dropdown.css('display') === 'block';

        // Fermer tous les dropdowns
        $('[id$="Dropdown"]').each(function() {
            $(this)
                .hide()
                .removeClass('opacity-100')
                .addClass('opacity-0 invisible');
        });

        // Afficher seulement le bon dropdown
        if (!isVisible) {
            $dropdown.show();
            setTimeout(function() {
                $dropdown
                    .removeClass('opacity-0 invisible')
                    .addClass('opacity-100');
            }, 10);
        }
    }
</script>