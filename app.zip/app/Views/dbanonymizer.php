<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>DBAnonymizer</title>
        <!-- Favicon icon -->
        <!-- <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon"> -->

        <!-- bootstrap css -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" type="text/css" />

        <!-- Font Awesome Icons -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome'); ?>/css/font-awesome.css">

        <!-- iCheck -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/iCheck/custom.css'); ?>" type="text/css" />

        <!-- Data table -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/dataTables/datatables.min.css'); ?>" type="text/css" />

        <!-- Datapicker -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/datapicker/datepicker3.css'); ?>" type="text/css" />

        <!-- Clockpicker -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/clockpicker/clockpicker.css'); ?>" type="text/css" />


        <!-- Sweetalert -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/sweetalert/sweetalert.css'); ?>" type="text/css" />

        <!-- Select2 js -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2.min.css'); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2-bootstrap4.min.css'); ?>" type="text/css" />

        <!-- Animate css -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" type="text/css" />

        <!-- Inspinia css -->
        <!-- <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" type="text/css" /> -->

        <!-- Custome css  -->
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-style.css'); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" type="text/css" />
        <style>
            .anonymizer-wrapper {
                padding: 20px;
            }
        </style>
    </head>

    <body>
        <div class="anonymizer-wrapper">
            <form class="form" id="dbanonymizer-form" action="">
                <div class="dbanonymizer_header">
                    <h2>DBAnonymizer</h2>
                    <br />

                    <div class="form-group">
                        <div class="input-group input-group-sm">
                            <select class="form-select" name="db_select" id="db-select">
                                <option value="">------ Veuillez selectionner une base des données ------</option>
                                <option value="ikwook_conciliation_test">iKwook Conciliation Test</option>
                                <option value="ikwook_logiref_etoll">iKwook Logiref Etoll</option>
                                <option value="ikwook_logiref_main">iKwook Logiref Main</option>
                                <option value="ikwook_logiref_qleads">iKwook Logiref QLeads</option>
                                <option value="ikwook_logiref_transactions">iKwook Logiref Transactions</option>
                            </select>
                            <button class="btn btn-primary" id="btn-search"><i class="fa fa-search"></i>&nbsp;&nbsp;Rechercher</button>
                        </div>
                    </div>

                </div>
                <br />
                <div class="form-group">
                    <table class="table table-bordered table-striped table-hovered">
                        <thead>
                            <tr>
                                <th><i class="fa fa-check"></i></th>
                                <th>Tables</th>
                                <th>Fields</th>
                            </tr>
                        </thead>
                        <tbody id="tbody_db_table">
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <button type="submit" id="btn-anonymize" disabled class="btn btn-dark"><i class="fa fa-user-secret"></i>
                    &nbsp;&nbsp;Anonymize Data</button>

            </form>

        </div>

        <!-- jQuery -->
        <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>

        <!-- Full Calendar Moment -->
        <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/moment.min.js"></script>

        <!-- Full Calendar -->
        <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/fullcalendar.min.js"></script>

        <!-- Data table -->
        <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/dataTables/datatables.min.js"></script>

        <!-- Sweetalert -->
        <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/sweetalert/sweetalert.min.js"></script>

        <script type="text/javascript">
            var dataset = new Array();

            $(document).ready(function () {

            });

            $("#btn-search").on('click', function () {
                var data = $("#db-select").val();
                var url = 'dbanonymizer/action/search_tables/' + data;

                $("#tbody_db_table").html("");
                $("#btn-search").html('<i class="fa fa-spinner fa-spin"></i>&nbsp; Recherche en cours...')
                $("#btn-search").attr('disabled', 'disabled');
                $("#btn-anonymize").attr('disabled', 'disabled');
                $.get(url, function (response) {
                    if (response !== null) {
                        $("#btn-search").html('<i class="fa fa-search"></i>&nbsp;&nbsp;Rechercher');
                        $("#btn-search").removeAttr('disabled');
                        $("#btn-anonymize").removeAttr('disabled');
                        var data = response;

                        var table_tr = '';
                        $.each(data, function (index, value) {

                            table_tr += `<tr>
                            <td><input type='checkbox' class='form-control' name='table_name[]' value='${value.table.table_name}'/></td>
                            <td style='width:auto;'>${value.table.table_name}</td>
                            <td>${get_table_fields(value.table)}</td>
                            </tr>`
                        })
                        $("#tbody_db_table").html(table_tr);
                    }
                }).fail(function (err) {
                    alert("Une erreur est survenue lors de la connexion");
                    $("#btn-search").html('<i class="fa fa-search"></i>&nbsp;&nbsp;Rechercher');
                    $("#btn-search").removeAttr('disabled');
                })

            });

            $("#dbanonymizer-form").on('submit', function (e) {
                e.preventDefault();
                var data = $(this).serialize();

                var url = 'dbanonymizer/action/crypter';

                $.post(url, data, function (response) {
                    alert(response.message);
                }).fail(function (err) {
                    alert("Erreur survenue au moment de l'opération");
                    console.log(err);
                });
            });

            function get_table_fields(table) {
                var fields = '';
                $.each(table.fields, function (index, value) {
                    fields += `<input type='checkbox' name='fields_${table.table_name}[]' value='${value}'/>&nbsp;${value}` + '<br/>';
                });
                return fields;
            }
        </script>

    </body>

</html>