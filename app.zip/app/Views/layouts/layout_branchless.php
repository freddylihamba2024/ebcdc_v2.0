<!DOCTYPE html>
<html lang="en" class="dark">

<head>
  <!-- metas -->
  <meta charset="utf-8">
  <meta name="author" content="ikwook" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="description" content="" />
  <!-- title -->
  <title>Logiref</title>
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">

  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" rel="stylesheet">
  <!-- Ionic Icons -->
  <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css'); ?>/ionicons.css" rel="stylesheet">
  <!-- jQuery -->

  <!-- Custome css  -->
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-style.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-home-netbank.css'); ?>" type="text/css" />

  <!-- Tailwind local -->
  <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css/tailwind.min.css'); ?>" rel="stylesheet">

  <!-- Font Awesome local -->
  <link href="<?php echo base_url('ikwook_bootstraps/fontawesome/css/all.min.css'); ?> assets/fontawesome/css/all.min.css" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-auth-netbank.css'); ?>" type="text/css" />

  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>
</head>
<style>
.logo-img {max-height: 40px; width: auto;object-fit: contain;}
.logo-subtitle {font-size: 11px;color: #9ca3af;line-height: 1;}
</style>
<body class="gray-bg">
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark auth-navbar">
      <div class="header">
          <div class="container-fluid d-flex justify-content-between align-items-center">
            <div class="logo d-flex align-items-center">
                <img 
                    src="<?php echo base_url('ikwook_files/logos/Standard_bank_rdc_logo.png'); ?>" 
                    alt="Standard Bank"
                    class="logo-img img-fluid"
                >
            </div>
            <!-- Texte à droite -->
            <div>
                <span class="text-muted">
                    <i class="fas fa-shield-alt"></i> Connexion sécurisée SSL
                </span>
            </div>
          </div>
      </div>
  </nav>

  <!-- Main -->
  <?php echo view($subview); ?>
  <!-- End Main -->

  <!-- Footer -->
  <div class="footer f14" style="width:100%;font-family:Cambria;">
        <div class="container-fluid d-flex justify-content-between align-items-center">
          <!-- Texte à gauche -->
          <div class="text-muted">
              <small>&copy; 2024 StandardBank. Tous droits réservés.</small>
          </div>
          <!-- Support à droite -->
          <div class="text-muted">
              <small>
                  <i class="fa fa-phone"></i> Support: +243 XXX XXX XXX |
                  <i class="fa fa-envelope"></i> support@standardbank.cd
              </small>
          </div>
      </div>
  </div>
  
  <!-- Bootstrap 4 js -->
  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>
</body>

</html>