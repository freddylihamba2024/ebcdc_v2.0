<?php //header('Content-type: text/html; charset=ISO-8859-1'); ?>
<?php 
/*
 * Value 1: layout-boxed
 * Value 2: wysihtml5-supported fixed pace-done
 * 'dashboard' + 'project',  'project' + 'summary', 'project' + 'customize', 'project' + 'members', 'project' + 'taskagile', 'todos' + 'checklist' + 'profile', 'todos' + 'archives', 'todos' +'routines'
 */
?>
<!DOCTYPE html>
<html>
<?php  echo view('headers/rbo'); ?>
<body class="body" >        
    <!-- header logo: style can be found in header.less -->
    <div class="">
        <?php echo view($subview); ?>
    </div><!-- ./wrapper -->  
    <?php echo view('footers/rbo'); ?>  
</body>
</html>
