<!DOCTYPE html>
<html lang="en" class="dark">

<head>
  <!-- metas -->
  <meta charset="utf-8">
  <meta name="author" content="ikwook" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="description" content="" />
  <!-- title -->
  <title>Logiref</title>

    <!-- bootstrap css -->
    <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">

    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/iCheck/custom.css'); ?>" type="text/css" />
    
    <!-- Data table -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/dataTables/datatables.min.css'); ?>" type="text/css" />
    
    <!-- Datapicker -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/datapicker/datepicker3.css'); ?>" type="text/css" />

    <!-- Clockpicker -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/clockpicker/clockpicker.css'); ?>" type="text/css" />

    <!-- Sweetalert -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/sweetalert/sweetalert.css'); ?>"  type="text/css"  />
    
    <!-- Select2 js -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2.min.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/inspinia/css/plugins/select2/select2-bootstrap4.min.css'); ?>" type="text/css" />

    <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" rel="stylesheet">

    <!-- Ionic Icons -->
    <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css'); ?>/ionicons.css" rel="stylesheet">
 

    <!-- Custome css  -->
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-style-branchless.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-home-netbank.css'); ?>" type="text/css" />

    <!-- Tailwind local -->
    <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css/tailwind.min.css'); ?>" rel="stylesheet">

    <!-- Font Awesome local -->
    <link href="<?php echo base_url('ikwook_bootstraps/fontawesome/css/all.min.css'); ?> assets/fontawesome/css/all.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-auth-netbank.css'); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form-branchless.css'); ?>" type="text/css" />

    <!-- jQuery -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>

    <!-- Full Calendar Moment -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/moment.min.js"></script>

    <!-- Full Calendar -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/fullcalendar/fullcalendar.min.js"></script>

    <!-- Data table -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/dataTables/datatables.min.js"></script>

    <!-- Sweetalert -->
    <script src="<?php echo base_url('ikwook_bootstraps/inspinia'); ?>/js/plugins/sweetalert/sweetalert.min.js"></script>
</head>

<body class="gray-bg">
    <!-- NAV BAR SECTION ****************--->
    <?= view('headers/navbar_branchless'); ?>

    <!-- Main -->
    <?php echo view($subview); ?>
    <!-- End Main -->

    <!-- Footer -->
    <div class="footer f14" style="width:100%;font-family:Cambria; margin-top: 20px !important; ">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <!-- Texte à gauche -->
            <div class="text-muted">
                <small>&copy; 2024 NetBanking. Tous droits réservés.</small>
            </div>
            <!-- Support à droite -->
            <div class="text-muted">
                <small>
                    <i class="fa fa-phone"></i> Support: +243 XXX XXX XXX |
                    <i class="fa fa-envelope"></i> support@netbanking.cd
                </small>
            </div>
        </div>
    </div>

    <!-- Footer section-->
    <?php  echo view('footers/footer_branchless'); ?>
</body>
</html>