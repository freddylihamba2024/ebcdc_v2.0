<!DOCTYPE html>
<html>
    <?php echo view('headers/header_branchless');  ?>

    <body class="top-navigation">
        <div id="wrapper">
            <div id="page-wrapper" class="gray-bg">
            
                <!-- NAV BAR SECTION ****************--->
                <?php
                    $data['bl_alerts'] = isset($alerts) ? $alerts : array();
                    echo view('headers/navbar_branchless',$data); 
                ?>
                <!-- END NAV BAR SECTION ****************--->

                <!--************ SUBVIEW CONTENT ******************** -->
                <!-- Content Wrapper. Contains page content -->
                <div class="wrapper wrapper-content">
                    <?php echo view($subview); ?>
                </div>
                <!--************ SUBVIEW CONTENT ******************** -->

                <!-- FOOTER -->
                <div class="footer">
                    <div class="float-right">
                        10GB of <strong>250GB</strong> Free.
                    </div>
                    <div>
                        <strong>Copyright</strong> Example Company &copy; 2014-2018
                    </div>
                </div>

            </div>
        </div>

        <!-- Footer section-->
        <?php echo view('footers/footer_branchless'); ?>
    </body>
</html>