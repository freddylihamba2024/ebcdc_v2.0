<?php $account_id = isset($_SESSION["userdata"]["account_id"]) ? $_SESSION["userdata"]["account_id"] : "" ?>
<!DOCTYPE html>
<html>

<?php echo view('headers/header_netbank');?>

<body class="pace-done gray-bg">
        
        <!-- NAV BAR SECTION ****************--->
        <div class="pl-2 pr-3">
                <?php 
                        if (isset($account) && $account != ""):
                                if ($account == "tmb"):
                                        echo view('headers/navbar_netbank');
                                elseif ($account == 'sofibank'):
                                        echo view('headers/navbar_sofibanque');
                                endif;
                        else:

                        endif;
                ?>
        </div>
        <!-- END NAV BAR SECTION ****************--->


        <!--************ SUBVIEW CONTENT ******************** -->
        <!-- Content Wrapper. Contains page content -->
        <div class="wrapper wrapper-content" style="padding: 0px !important;">
                <?php echo view($subview); ?>
        </div>
        <!--************ SUBVIEW CONTENT ******************** -->

        <!-- Footer section-->
        <?php  
                if (isset($account_id) && $account_id != ""):
                        if ($account_id == "45"):
                                echo view('footers/footer_netbank'); 
                        elseif ($account_id == '9084'):
                                echo view('footers/footer_sofibanque'); 
                        endif;
                else:
                        echo view('footers/footer_main'); 
                endif;
        ?>
</body>

</html>