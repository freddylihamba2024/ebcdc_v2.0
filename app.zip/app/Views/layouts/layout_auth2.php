<!DOCTYPE html>
<html lang="en" class="dark">

<head>
  <!-- metas -->
  <meta charset="utf-8">
  <meta name="author" content="ikwook" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="description" content="" />
  <!-- title -->
  <title>Logiref</title>
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">

  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" rel="stylesheet">
  <!-- Ionic Icons -->
  <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css'); ?>/ionicons.css" rel="stylesheet">
  <!-- jQuery -->

  <!-- Custome css  -->
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-style.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />


  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.7.1.min.js'); ?>"></script>

</head>

<body class="gray-bg">
  <nav class="navbar navbar-expand-lg navbar-dark auth-navbar">
    <a class="navbar-brand" href="<?= base_url("main/signin") ?>">
      <img class="img-fluid" width="10%" src="<?php echo base_url('ikwook_files/logos/logo_firstbank.png'); ?>" alt="Rawbank">
    </a>
  </nav>
  <!-- Main -->
  <?php echo view($subview); ?>
  <!-- End Main -->

  <!-- Bootstrap 4 js -->
  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>
</body>

</html>