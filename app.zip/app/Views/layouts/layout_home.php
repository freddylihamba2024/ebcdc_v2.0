    <!DOCTYPE html>
    <html lang="en" class="dark">

    <head>
      <!-- metas -->
      <meta charset="utf-8">
      <meta name="author" content="ikwook" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="description" content="" />
      <!-- title -->
      <title>iKwook.com</title>
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/img/favicon.ico">
      <!-- CSS Template -->
      <link href="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/css/theme.css" rel="stylesheet">

      <!-- Font Awesome Icons -->
      <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/admin_themes/inspinia/font-awesome'); ?>/css/font-awesome.css">
    </head>

    <body>
      <!-- Skippy & Prload -->
      <!-- skippy -->
      <a id="skippy" class="skippy visually-hidden-focusable overflow-hidden" href="#content">
        <div class="container">
          <span class="u-skiplink-text">Skip to main content</span>
        </div>
      </a>
      <!-- End skippy -->
      <!-- Preload -->
      <div id="loading" class="loading-preloader">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>
      <!-- End Preload -->
      <!-- Edn Skippy & Prload -->
      <!-- 
        ========================
            Wrapper 
        ========================
        -->
      <div class="wrapper">


        <!-- Header -->
        <header class="main-header main-header-01 headroom navbar-light fixed-top fixed-dark navbar-transparent header-height" style="background-color: #fff !important">
          <nav class="navbar navbar-expand-lg" style="padding: 10px !important;" >
            <div class="container">
              <!-- Logo -->
              <a class="navbar-brand header-navbar-brand" href="<?php echo base_url() ?>">
                <img class="logo-dark" width="130" src="<?php echo base_url('ikwook_files/logos'); ?>/logo.png" title="" alt="">
                <img class="logo-light" width="130" src="<?php echo base_url('ikwook_files/logos'); ?>/logo.png" title="" alt="">
              </a>
              <!-- Logo -->
              <!-- Mobile Toggle -->
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="toggler-icon"></span>
              </button>
              <!-- End Mobile Toggle -->
              <!-- Menu -->
              <div class="collapse navbar-collapse" id="navbarSupportedContent">

              </div>
              <!-- End Menu -->
              <div class="nav flex-column flex-lg-row d-none d-lg-flex">
                <ul class="navbar-nav ms-auto align-items-center">
                  <li class="nav-item">
                    <a href="<?= base_url('main/signin') ?>" class="btn btn-sm btn-primary text-nowrap btn-radius-0">Se connecter</a>
                  </li>
                  <li class="nav-item">
                    <a href="<?= base_url('main/signup') ?>" class="btn btn-sm btn-warning text-nowrap btn-radius-0">Créer un compte</a>
                  </li>
                  <li class="nav-item pt-1">
                    <a style="color: #777" href="<?= base_url('main/services') ?>" class="mb-0 p-2"><i class='fa fa-th fa-2x ms-2'></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </header>
        <!-- End Header -->




        <!-- Main -->
        <main>
          <?php echo view($subview); ?>

        </main>
        <!-- End Main -->


        <!-- Footer -->
        <footer class="bg-white footer border-top">
          <div class="py-7 py-md-8 py-lg-10">
            <div class="container">
              <div class="row gy-5">
                <div class="col-lg-3 me-auto">
                  <div class="pb-4">
                    <img style="margin-left: -20px;" width="150" src="<?php echo base_url('ikwook_files/logos'); ?>/logo.png" title="" alt="">
                  </div>
                  <p class="m-0" style="font-size: 0.9em;">Exploitant le meilleur des nouvelles technologies, nous avons pour mission de diffuser les dividendes numériques à tous. Nous offrons aux entreprises des solutions qui leur permettent de gérer efficacement leurs activités de partout.</p>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-5 col-12">
                  <h5 class="footer-title-02">Nos solutions</h5>
                  <div class="row">
                    <div class="col">
                      <ul class="list-unstyled footer-link-01 m-0">
                        <li>
                          <a class="text-reset" href="#">iKwook Page</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Logiref</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Logistique</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwoop Pay</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Cloud</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul class="list-unstyled footer-link-01 m-0">
                        <li>
                          <a class="text-reset" href="#">iKwook Page</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Logiref</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Logistique</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwoop Pay</a>
                        </li>
                        <li>
                          <a class="text-reset" href="#">iKwook Cloud</a>
                        </li>
                      </ul>
                    </div>
                  </div>

                </div>
                <div class="col-lg-3 col-12">
                  <h6 class="footer-title-02">
                    Information
                  </h6>
                  <address>
                    <p class="mb-2">Kinshasa DRC,<br> -----------</p>
                    <p class="mb-2"><a class="text-secondary border-bottom border-secondary" href="mailto:support@domain.com">contact@ikwook.com</a></p>
                    <p class="mb-2"><a class="text-secondary border-bottom border-secondary" href="tel:820-885-3321">(00243) 8XX-XXX-XXX</a></p>
                  </address>
                  <div class="nav pt-3">
                    <a class="icon-sm bg-secondary text-white me-2" href="#">
                      <i class="bi-twitter"></i>
                    </a>
                    <a class="icon-sm bg-secondary text-white me-2" href="#">
                      <i class="bi-instagram"></i>
                    </a>
                    <a class="icon-sm bg-secondary text-white me-2" href="#">
                      <i class="bi-linkedin"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <hr class="m-0">
          <div class="container">
            <div class="row py-3 gy-3 align-items-center">
              <div class="col-md-6">
                <ul class="nav justify-content-center justify-content-md-start my-2 small list-unstyled footer-link-01 m-0">
                  <li class="p-0 mx-3 ms-md-0 me-md-3"><a href="<?= base_url(("main/cgi")) ?>" class="text-reset">Sécurité</a></li>
                  <li class="p-0 mx-3 ms-md-0 me-md-3"><a href="<?= base_url(("main/cgi")) ?>" class="text-reset">Confidentialité</a></li>
                  <li class="p-0 mx-3 ms-md-0 me-md-3"><a href="<?= base_url(("main/cgi")) ?>" class="text-reset">CGI</a></li>
                </ul>
              </div>
              <div class="col-md-6 text-center text-md-end">
                <p class="small m-0">© 2022 | Hello from Kinshasa</p>
              </div>
            </div>
          </div>
        </footer>
        <!-- End Footer -->
      </div>
      <!-- 
        ========================
           End Wrapper 
        ========================
        -->
      <!-- script start -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/particles/particles.min.js"></script>
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/particles/particles-app.js"></script>
      <!-- Theme JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/js/jquery-3.5.1.min.js"></script>
      <!--bootstrap-->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- headroom JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/headroom/headroom.min.js"></script>
      <!-- swiper JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
      <!-- purecounter JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/purecounter/purecounter_vanilla.js"></script>
      <!-- isotope JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/isotope/isotope.pkgd.min.js"></script>
      <!-- magnific JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/magnific/jquery.magnific-popup.min.js"></script>
      <!-- magnific JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/highlight/highlight.min.js"></script>
      <!-- magnific JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/typed/typed.js"></script>
      <!-- svginjector JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/svginjector/svg-injector.min.js"></script>
      <!-- wow JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/wow/wow.min.js"></script>
      <!-- wow JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/easy-pie-chart/jquery.easypiechart.min.js"></script>
      <!-- countdown JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/count-down/jquery.countdown.min.js"></script>
      <!-- one-page JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/one-page/scrollIt.min.js"></script>
      <!-- working form -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/mail/js/form.min.js"></script>
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/vendor/mail/js/script.js"></script>
      <!-- Theme JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/js/theme-jquery.js"></script>
      <!-- Theme JS -->
      <script src="<?php echo base_url('ikwook_bootstraps/front_themes/ikwook'); ?>/assets/js/theme.js"></script>
      <!-- End script start -->
    </body>

    </html>