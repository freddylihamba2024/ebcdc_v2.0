<!DOCTYPE html>
<html lang="en" class="dark">

<head>
  <!-- metas -->
  <meta charset="utf-8">
  <meta name="author" content="ikwook" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="description" content="" />
  <!-- title -->
  <title>Logiref</title>
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">

  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/animate.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/inspinia/css/style.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('ikwook_bootstraps/styles/app.css'); ?>" rel="stylesheet">
  <!-- Ionic Icons -->
  <link href="<?php echo base_url('ikwook_bootstraps/librairies/ionicons/css'); ?>/ionicons.css" rel="stylesheet">
  <!-- jQuery -->
  
    <!-- Custome css  -->
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-style.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-form.css'); ?>" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('ikwook_bootstraps/styles/custom-box.css'); ?>" type="text/css" />
</head>

<body class="gray-bg">
  <div style="border: 1px solid #d7352c; padding: 10px; background-color: #d7352c;">
    <nav style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0;">
        <!-- Logo on the left -->
        <div style="display: flex; align-items: center;">
            <a href="#" style="padding-right: 10px; color:white;"><i class="fa fa-bars fa-4x"></i></a>
            <img width="100" src="<?php echo base_url('ikwook_files/logos/tmb_netbank.png'); ?>" style="display: block;" />
        </div>
        <!-- Texts on the right -->
        <div style="display: flex; align-items: center;">
            <span style="display: flex; align-items: center; padding-right: 20px;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>support@ikwook.cd</span> -->
            </span>
            <span style="display: flex; align-items: center;">
                <!-- <span class="fa fa-picture-o" style="padding-right: 5px;"></span> -->
                <!-- <span>+243 850 600 500</span> -->
            </span>
        </div>
    </nav>
  </div>

  <!-- Main -->
  <?php echo view($subview); ?>
  <!-- End Main -->

  <!-- Bootstrap 4 js -->
  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/jquery-3.1.1.min.js'); ?>"></script>
  <script src="<?php echo base_url('ikwook_bootstraps/inspinia/js/bootstrap.js'); ?>"></script>
</body>

</html>