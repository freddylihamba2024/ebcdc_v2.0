<!DOCTYPE html>
<html>

                <?php echo view('headers/header_main');  ?>

    <body class="pace-done <?php echo isset($layout_type) ? $layout_type : ''; ?> <?= $sidebar == "" ? "gray-bg" : "" ?> ">

        <?php if ($layout_type !== 'top-navigation') { ?>    
            <?php if ($sidebar != "") { ?>

                <!-- NAV BAR SECTION ****************--->

                <div class="pl-2 pr-3"><?php
                 $data['bl_alerts'] = isset($alerts) ? $alerts : array();
                 
                echo view('headers/navbar_main',$data); ?></div>
                <!-- END NAV BAR SECTION ****************--->

                <div id="wrapper">

                    <!--***************************************** -->
                    <!--************ SIDEBAR ******************** -->
                    <nav class="navbar-default navbar-static-side" role="navigation">
                        <!--************ SIDEBAR CONTENT ******************** -->
                        <?php echo $sidebar ?>
                        <!--************ SIDEBAR CONTENT ******************** -->
                    </nav>
                    <!--************ END SIDEBAR ******************** -->
                    <!--************ ******************************** -->

                    <div id="page-wrapper" class="gray-bg">


                        <!--************ SUBVIEW CONTENT ******************** -->
                        <!-- Content Wrapper. Contains page content -->
                        <div class="wrapper wrapper-content" style=" padding: 0px !important; ">
                            <?php echo view($subview); ?>
                        </div>
                        <!--************ SUBVIEW CONTENT ******************** -->



                        <!-- FOOTER -->
                        <div class="footer">
                            <div class="float-right">
                                Autre <strong>Notification</strong>
                            </div>
                            <div>
                                <strong>Copyright</strong> iKwook.com &copy; 2022
                            </div>
                        </div>

                    </div>
                </div>

            <?php } else { ?>

                <!-- NAV BAR SECTION ****************--->
                <div class="pl-2 pr-3">
                    <?php
                    $data['bl_alerts'] = isset($alerts) ? $alerts : array();

                    echo view('headers/navbar_main',$data);
                    
                    ?></div>
                <!-- END NAV BAR SECTION ****************--->


                <!--************ SUBVIEW CONTENT ******************** -->
                <!-- Content Wrapper. Contains page content -->
                <div class="wrapper wrapper-content" style="padding: 0px !important;">
                    <?php echo view($subview); ?>
                </div>
                <!--************ SUBVIEW CONTENT ******************** -->

            <?php } ?>
        <?php } ?>
        <!-- Footer section-->
        <?php echo view('footers/footer_main'); ?>
    </body>

</html>