    <head>
        <style>
            .btn.btn-primary{
                padding:.425rem .55rem;
                border-radius: 0 3px 3px 0;
                background-color: #3c8dbc;
                border-color: #3c8dbc;
            }
        </style>
    </head>

    <div class="middle-box text-center animated fadeInDown">
        <h1>404</h1>
        <h3 class="font-bold">Page Non Trouvée</h3>

        <div class="error-desc">
            Désolé, mais la page que vous recherchez n'a pas été trouvée. Essayez de vérifier l'URL pour détecter toute erreur, puis appuyez sur le bouton d'actualisation de votre navigateur ou essayez de trouver autre chose dans notre application.
            <form class="form-inline m-t justify-content-center" role="form">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Rechercher une page">
                </div>
                <button type="submit" class="btn btn-primary">Rechercher</button>
            </form>
        </div>
    </div>