<?php

namespace Modules\Quitus\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Quitus\Models\QuitusModel;
use Modules\Logiref\Models\LogirefModel;

class Reports extends BaseController
{
        /*
        * Presentation:
        * Last update:
        * By Donald on the 25.03.2025
        * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('client_fiscal','quitus_current','quitus_expire');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'quitus';
        public $folder = 'reports';
        public $data = [];
        public $mainModel;
        public $quitusModel;
        public $logirefModel;
        public $branchModel;
        public $userModel;
        public $stakeholderModel;
        public $curlModel;

        public function __construct()
        {
                parent::__construct();
                /*
                * Module is project
                * Submodule or application is activities
                * function will be set within display function
                * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->quitusModel = new QuitusModel();
                $this->logirefModel = new LogirefModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['deny'] = false;

                $this->data['sidebar'] = $this->sidebars->logiref_quitus($_SESSION['Logiref_role']);

                /*
                * Control user access to this module
                * If string is empty, then access denied
                * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect('main/signin', 'refresh');
                }

                $this->data("expire");
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Quitus\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }


        /*
        * Manages sidebar menu
        * Must match de third section of the URL
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {

                $this->index();

                }
        }

        /*
        * Manages all the views
        * View calls are made here
        * * PS: A personnaliser !!
        * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "quitus_current")
                {
                        $this->data['customers'] = $this->quitusModel->get_dropdown('customers');
                        $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                        //$this->data['quitus_currents'] = $this->quitusModel->get_quitus_currents();
                        echo view('\Modules\Quitus\\' . $this->folder . '\quitus_current', $this->data);
                }
                elseif ($obj == "client_fiscal")
                {
                        $this->data["legalstatus"] = $this->quitusModel->legalstatus;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['clients_fiscal'] = $this->quitusModel->get_clients_fiscal();
                        echo view('\Modules\Quitus\\' . $this->folder . '\client_fiscal', $this->data);
                }
                elseif ($obj == "filter_quituscurrent")
                {
                        $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                        $this->data['filter_quituscurrents'] = $this->quitusModel->get_filter_quitus_currents($_POST);
                        echo view('\Modules\Quitus\\' . $this->folder . '\_filter_quituscurrent', $this->data);
                }
                elseif ($obj == "quitus_expire")
                {
                        $this->data['customers'] = $this->quitusModel->get_dropdown('customers');
                        $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                        //$this->data['quitus_expires'] = $this->quitusModel->get_quitus_expires();
                        echo view('\Modules\Quitus\\' . $this->folder . '\quitus_expire', $this->data);
                }
                elseif ($obj == "filter_quitusexpire")
                {
                        $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                        $this->data['filter_quitusexpires'] = $this->quitusModel->get_filter_quitus_expires($_POST);
                        echo view('\Modules\Quitus\\' . $this->folder . '\_filter_quitusexpire', $this->data);
                }
                elseif ($obj == "quitus_fiscal")
                {
                        $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                        $this->data["quitusfiscal"] = $this->quitusModel->get_quitus_fiscal_info($id);
                        $html = view('\Modules\Quitus\\' . $this->folder . '\_attestation_quitusfiscal', $this->data);

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        $this->mpdf->Output("drive/quitusfiscal/attestation.pdf", 'I');
                        exit;
                }
                #Default
                elseif ($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];

                        echo view('\Modules\Quitus\Views\fr_denial', $this->data);
                }
        }

        /*
        * Manages additional data manipuations
        * Arguments could of any type, arrays or strings
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "expire")
                {
                        $currents  = $this->quitusModel->get_all_quitus();
                        $data = array();
                        $date = date("Y-m-d");
                        foreach($currents as $current){
                                if(strtotime($date) > strtotime($current->Expiration_12)){
                                        $data["Status_2"] = 3;
                                        $this->quitusModel->save_quitus($data,$current->Id_0);
                                }
                        }
                }
        }
}