<?php

namespace Modules\Quitus\Controllers;

use App\Controllers\BaseController;
use Modules\logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Quitus\Models\QuitusModel;
use Modules\Admin\Models\BranchModel;
use Modules\Quitus\Models\RatesModel;

class Dashboards extends BaseController
{
        /*
         * Presentation: Gestion des tableaux de bord
         * Last update:
         * By Donald on the 25.03.2025
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('quitus', 'overview');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $role;
        public $module = 'quitus';
        public $folder = 'dashboards';
        public $core_banking;
        public $options;
        private $logirefModel = null;
        private $branchesModel;
        private $mainModel;
        public $quitusModel;
        public $ratesModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->logirefModel = new LogirefModel();
                $this->mainModel = new MainModel();
                $this->quitusModel = new QuitusModel();
                $this->branchesModel = new BranchModel();
                $this->ratesModel = new RatesModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->logiref_quitus($_SESSION['Logiref_role']);

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else {

                        return redirect()->to(base_url($this->module));
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Quitus\Views\container';
                if ($_SESSION['Logiref_role'] == 1) {
                        echo view('layouts/layout_admin', $this->data);
                }
                else {
                        echo view('layouts/layout_main', $this->data);
                }
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {

                        if($needle == "overview"){

                                if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') {

                                        if(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                                        {
                                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                        }
                                        else
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if(!isset($_SESSION['Exchange_rates']))
                                                {
                                                        $this->display("set_exchange_rates");
                                                }

                                                $this->data['sidebar'] = '';
                                                $this->data['subview'] = '\Modules\Eximtrade\Views\container';

                                                echo view('layouts/layout_main', $this->data);
                                        }
                                }

                        }
                        else{

                            $this->index();

                        }

                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                ############################ Menu Operateur ################
                if ($obj == "quitus")
                {
                        $this->data['all_quitus'] = ($this->quitusModel->get_count_quitus_current()) + ($this->quitusModel->get_count_quitus_expire());
                        $this->data['quitus_current'] = $this->quitusModel->get_count_quitus_current();
                        $this->data['quitus_expire'] = $this->quitusModel->get_count_quitus_expire();
                        $this->data['all_taxpayer'] = $this->quitusModel->get_count_quitus_client();

                        echo view('\Modules\Quitus\Views\\' . $this->folder . '\summary', $this->data);

                }
                elseif($obj == "overview")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                        $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')])?$this->data['guichets'][$this->session->get('Logiref_guichet')]:"";
                        $this->data['agence']= isset($this->data['agences'][$this->session->get('Logiref_agence')])?$this->data['agences'][$this->session->get('Logiref_agence')]:"";
                        $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                        $this->data['region'] = (!is_null($region))?$region->Nom_7:'';
                        $this->data['role_user'] = (!empty($_SESSION['roles_banks']))?$_SESSION['roles_banks'][$this->session->get('Logiref_role')]:"";

                        $this->data['paiement_cdf'] = $paiement_cdf = array();
                        $this->data['paiement_usd'] = $paiement_usd = array();
                        $this->data['paiement_regie'] = array();
                        $this->data['paiement'] = array();
                        $this->data['pie_situation_cdf'] = array();
                        $this->data['pie_situation_usd'] = array();
                        $this->data['right_side']= $id;
                        $this->data['beneficiaires'] = array();
                        $this->data['encaissements'] = array();
                        $this->data['guichets'] = array();

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Main\Views\overview', $this->data);

                }
                elseif ($obj == "set_exchange_rates")
                {
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];
                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                        {
                                if (isset($this->options['ALL']['auto-fetch-exchange-rate']))
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Initialization
                                        * ------------------------------------------------
                                        */

                                        $usd = '';
                                        $pound = '';
                                        $eur = '';
                                        $rand = '';

                                        $data['from_currency'] = 'USD';
                                        $data['to_currency'] = 'CDF';
                                        $data['type'] = 'TTB';
                                        $data['language'] = 'P';

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (property_exists($this, $core_banking) && method_exists($this->{$core_banking}, 'get_exchange_rate'))
                                        {
                                                $return = $this->{$core_banking}->get_exchange_rate($data);

                                                $return = json_decode($return, true);

                                                if($return['code'] == '200')
                                                {
                                                        if (isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                                        {
                                                                if($core_banking == 'bsqr')
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $usd;
                                                                        $_POST['rand'] = "";
                                                                        $_POST['pound'] = "";
                                                                }
                                                                else
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $data['from_currency'] = 'EUR';
                                                                        $data['to_currency'] = 'CDF';

                                                                        $return = $this->{$core_banking}->get_exchange_rate($data);

                                                                        $return = json_decode($return, true);

                                                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = "";
                                                                        $_POST['pound'] = "";
                                                                }

                                                                $this->save('taux');

                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                        elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                                        {
                                                                foreach ($return['ExchangeRateList'] as $row)
                                                                {
                                                                        if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                                        {
                                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                                        {
                                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                                        {
                                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                                        {
                                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                }

                                                                if ($usd != "" && $eur != "")
                                                                {
                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = $rand;
                                                                        $_POST['pound'] = $pound;

                                                                        $this->save('taux');

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                                else{
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                        else
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                }
                        }
                }
                #Default
                elseif ($obj == "deny") {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Quitus\Views\\' . $this->lang . '_denial', $this->data);
                }
        }


        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                ################################################################################
                # Dashboard Pie chart
                ################################################################################
                if ($obj == "pie-chart") {
                        if ($arg == 'commission') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00C6F3",highlight:"green"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                } elseif ($obj == "pie-chart_operator") {
                        if ($arg == 'paiement_situation_cdf') {
                                $stats = $data;
                                //var_dump($stats); die;
                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement_situation_usd') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" USD",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" USD",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" USD",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                }
                elseif ($obj == "OBJ ") {

                }
                elseif ($obj == "OBJ ") {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */