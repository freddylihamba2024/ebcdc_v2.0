<?php

        namespace Modules\Quitus\Controllers;

        use Modules\Main\Models\MainModel;
        use App\Controllers\BaseController;
        use Modules\Quitus\Models\QuitusModel;
        use Modules\Logiref\Models\LogirefModel;

        class Quitus extends BaseController
        {
                /*
                * Presentation:
                * Last update:
                * By Donald on the 25.03.2025
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('quitus_fiscal', 'client_fiscal', 'nvalidated');
                public $roles = '5';
                public $role = '';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'quitus';
                public $folder = 'quitus';
                public $data = [];
                public $mainModal;
                public $quitusModel;
                public $logirefModel;
                public $branchModel;
                public $userModel;
                public $stakeholderModel;
                public $curlModel;

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */
                        $this->mainModal = new MainModel();
                        $this->quitusModel = new QuitusModel();
                        $this->logirefModel = new LogirefModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'quitus';
                        $this->data['function'] = '';
                        $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['i'] = 0;
                        $user_roles = $this->session->userdata['user_roles'];
                        $this->data['deny'] = false;

                        $this->data['sidebar'] = $this->sidebars->logiref_quitus($_SESSION['Logiref_role']);

                        /*
                        * Control user access to this module
                        * If string is empty, then access denied
                        * A garder si uniquement c'est necessaire !!
                        */
                        if (!isset($_SESSION['Logiref_privileges']))
                        {
                                $this->data("set_privilegies");
                        }
                        elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                        {
                                $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                        }
                        elseif ($this->session->userdata['user_type'] == "400") {
                                #$this->display('deny');
                        }

                        //Group - A garder si uniquement c'est necessaire !!
                        if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                        {
                                $this->group = $_SESSION['Logiref_groupe'];
                                $this->role = $_SESSION['Logiref_role'];
                        }
                        else
                        {
                                redirect('main/signin', 'refresh');
                        }
                }


                public function index()
                {
                        $this->data['subview'] = '\Modules\Quitus\Views\container';
                        echo view('layouts/layout_admin', $this->data);
                }


                /*
                * Manages sidebar menu
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */
                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {

                                $this->index();
                        }
                }

                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "quitus_fiscal")
                        {
                                $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                                $this->data['customers'] = $this->quitusModel->get_dropdown('customers');
                                $this->data["legalstatus"] = $this->quitusModel->legalstatus;
                                $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                                $this->data["quitusfiscal"] = $this->quitusModel->get_quitus_fiscal_info($id);
                                echo view('\Modules\Quitus\\' . $this->folder . '\quitus_fiscal', $this->data);
                        }
                        elseif ($obj == "nvalidated")
                        {
                                $this->data["services"] = $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                                $this->data['taxpayer'] = $this->quitusModel->get_dropdown('taxpayer');
                                $this->data["nvalidated"] = $this->quitusModel->get_quitus_fiscal_nvalidated();
                                $this->data["validated"] = $this->quitusModel->get_quitus_fiscal_validated();
                                echo view('\Modules\Quitus\\' . $this->folder . '\\'.$obj, $this->data);
                        }
                        elseif ($obj == "client_fiscal")
                        {
                                $this->data["legalstatus"] = $this->quitusModel->legalstatus;
                                $this->data["clientfiscal"] = $this->quitusModel->get_client_fiscal_info($id);
                                echo view('\Modules\Quitus\\' . $this->folder . '\client_fiscal', $this->data);
                        }
                        elseif($obj == "viewpdf")
                        {
                                $filePath = ROOTPATH . 'drive/quitusfiscal/' . $id;

                                if (file_exists($filePath)) {

                                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                        $mimeType = finfo_file($finfo, $filePath);
                                        finfo_close($finfo);

                                        $MimeTypes = [
                                                'application/pdf',
                                                'image/jpeg',
                                                'image/png',
                                        ];

                                        if (in_array($mimeType, $MimeTypes)) {
                                                return $this->response->setHeader('Content-Type', $mimeType)
                                                        ->setHeader('Content-Disposition', 'inline; filename="' . basename($id) . '"')
                                                        ->setBody(file_get_contents($filePath));
                                        }
                                        else {
                                                return redirect()->to(base_url("404"));
                                        }
                                }
                                else {
                                        return redirect()->to(base_url("404"));
                                }

                        }
                        #Default
                        elseif ($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                $this->data['country'] = $this->session->userdata['account_country'];

                                echo view('\Modules\Quitus\Views\fr_denial', $this->data);
                        }
                }


                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "quitus_fiscal")
                        {
                                $data = array();
                                $data['Id_0'] = $Id_0 = (!empty($this->request->getPost("Id_0")))?$this->request->getPost("Id_0"):NULL;
                                $dateissue = $this->request->getPost("Dateissue_11");
                                $action = $this->request->getPost("action");
                                $date = date("Y-m-d");
                                $expiration = $this->request->getPost("Expiration_12");

                                if(strtotime($date) < strtotime($expiration))
                                {
                                        if($action == "validate"){
                                                $Status_2 = 2;
                                        }
                                        elseif($action == "save"){
                                                $Status_2 = 1;
                                        }

                                        $file = $this->request->getFile('Filequitus_14');
                                        $error = (!is_null($Id_0))?false:true;

                                        if ($file->isValid() && !$file->hasMoved()) {
                                                $MimeTypes = [
                                                        'application/pdf',
                                                        'image/png',
                                                        'image/jpeg'
                                                ];

                                                if (in_array($file->getMimeType(), $MimeTypes)) {
                                                        $filequitus = $file->getRandomName();
                                                        $path = 'drive/quitusfiscal';

                                                        if (!is_dir($path)) {
                                                                mkdir($path, 0777, true);
                                                        }

                                                        if ($file->move($path, $filequitus)) {
                                                                $data['Filequitus_14'] = $filequitus;

                                                                if (!is_null($Id_0)) {
                                                                        $quitusfiscal = $this->quitusModel->get_quitus_fiscal_info($Id_0);
                                                                        if (isset($quitusfiscal->Filequitus_14) && $quitusfiscal->Filequitus_14 != "") {
                                                                                @unlink(ROOTPATH . "drive/quitusfiscal/" . $quitusfiscal->Filequitus_14);
                                                                        }
                                                                }

                                                                $error = false;
                                                        }
                                                }
                                                else {
                                                        $error = true;
                                                }
                                        }

                                        if(!$error)
                                        {
                                                if(is_null($Id_0)){
                                                        $data['Date_1'] = $date;
                                                        $data['Makerid_4'] = $this->session->userdata['user_id'];
                                                }
                                                else{
                                                        $data['Changer_5'] = $this->session->userdata['user_id'];
                                                        $data['Changes_6'] = $date;
                                                }
                                                $data['Account_3'] = $this->session->userdata['account_id'];
                                                $data['Status_2'] = $Status_2;
                                                $data['Taxpayer_7'] = $Nif_7 = $this->request->getPost("Taxpayer_7");
                                                $data['Guichet_8'] = $_SESSION['Logiref_guichet'];
                                                $data['Agence_9'] = $_SESSION['Logiref_agence'];
                                                $data['Reference_10'] = $this->request->getPost("Reference_10");
                                                $data['Dateissue_11'] = $dateissue;
                                                $data['Expiration_12'] = $expiration;
                                                $data['Comment_13'] = $this->request->getPost("Comment_13");
                                                $data['Regie_15'] = $this->request->getPost("Regie_15");
                                                $data['Service_16'] = $this->request->getPost("Service_16");
                                                $data['Validity_17'] = $this->request->getPost("Validity_17");

                                                $id = $this->quitusModel->save_quitus($data,$Id_0);

                                                if($id){

                                                        $taxpayer = $this->quitusModel->get_client_by_taxpayer($Nif_7);

                                                        $taxpayerid = (!is_null($taxpayer))?$taxpayer->Id_0:NULL;

                                                        $data = array();
                                                        $data['Date_1'] = $date =  date("Y-m-d H:i:s");
                                                        if(is_null($taxpayerid)){
                                                                $data['Makerid_4'] = $this->session->userdata['user_id'];
                                                                $data['Status_2'] = 1;
                                                        }
                                                        else{
                                                                $data['Changer_5'] = $this->session->userdata['user_id'];
                                                                $data['Changes_6'] = $date;
                                                        }
                                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                                        $data['Nif_7'] = $Nif_7;
                                                        $data['Designation_8'] = $this->request->getPost("Designation");
                                                        $data['Email_9'] = $this->request->getPost("Email");
                                                        $data['Phone_10'] = $this->request->getPost("Phone");
                                                        $data['Address_11'] = $this->request->getPost("Address");
                                                        $data['Legalstatus_12'] = $this->request->getPost("Legalstatus");
                                                        $data['Cbs_id_13'] = $this->request->getPost("CbsId");

                                                        $this->quitusModel->save_client($data, $taxpayerid);

                                                        echo json_encode(array("code" => "E200","id" => $id));
                                                }
                                                else{
                                                        echo json_encode(array("code" => "E500",));
                                                }
                                        }
                                        else{
                                                echo json_encode(array("code" => "E501"));
                                        }
                                }
                                else{
                                        echo json_encode(array("code" => "E502"));
                                }
                        }
                        elseif ($obj == "client_fiscal")
                        {
                                $Id_0 = (!empty($this->request->getPost("Id_0")))?$this->request->getPost("Id_0"):NULL;
                                $data = array();
                                if(is_null($Id_0)){
                                        $data['Date_1'] = $date =  date("Y-m-d H:i:s");
                                        $data['Makerid_4'] = $this->session->userdata['user_id'];
                                }
                                else{
                                        $data['Changer_5'] = $date =  date("Y-m-d H:i:s");
                                        $data['Changes_6'] = $this->session->userdata['user_id'];
                                }
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Nif_7'] = $this->request->getPost("Nif_7");
                                $data['Designation_8'] = $this->request->getPost("Designation_8");
                                $data['Email_9'] = $this->request->getPost("Email_9");
                                $data['Phone_10'] = $this->request->getPost("Phone_10");
                                $data['Address_11'] = $this->request->getPost("Address_11");
                                $data['Legalstatus_12'] = $this->request->getPost("Legalstatus_12");
                                $data['Cbs_id_13'] = $this->request->getPost("Cbs_id_13");

                                $id = $this->quitusModel->save_client($data,$Id_0);

                                if($id){
                                        echo json_encode(array("code" => "E200","id" => $id));
                                }
                                else{
                                        echo json_encode(array("code" => "E500",));
                                }
                        }
                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "client_fiscal")
                        {
                                $Nif_7 = $this->request->getPost("taxpayer");
                                $taxpayer = $this->quitusModel->get_client_by_taxpayer($Nif_7);

                                if(!is_null($taxpayer))
                                {
                                        echo json_encode(array(
                                                "code" => "200",
                                                "Designation" => $taxpayer->Designation_8,
                                                "Email" => $taxpayer->Email_9,
                                                "Phone" => $taxpayer->Phone_10,
                                                "Address" => $taxpayer->Address_11,
                                                "Legalstatus" => $taxpayer->Legalstatus_12,
                                                "CbsId" => $taxpayer->Cbs_id_13
                                        ));
                                }
                                else{
                                        $taxpayer = $this->quitusModel->get_taxpayer_by_nif($Nif_7);

                                        if(!is_null($taxpayer))
                                        {
                                                echo json_encode(array(
                                                        "code" => "200",
                                                        "Designation" => $taxpayer->Designation_5,
                                                        "Email" => $taxpayer->Email_7,
                                                        "Phone" => $taxpayer->Phone_6,
                                                        "Address" => "",
                                                        "Legalstatus" => "",
                                                        "CbsId" => ""
                                                ));
                                        }
                                        else{
                                                echo json_encode(array("code" => "500"));
                                        }
                                }
                        }
                }
        }

        /* End of file welcome.php  */
        /* Location: /project/activities  */