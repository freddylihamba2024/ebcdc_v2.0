<?php
namespace Modules\Quitus\Models;

use stdClass;
use App\Models\MY_Quitus;

class quitusModel extends MY_Quitus {

        /* Presentation:
         * Last update
         * By Rocquia on the 24.03.2025
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';

        public $bank;

        public $banks = array(
                        ''=>'',
                        '44' => 'Rawbank',
                        '45' => 'Tmb',
                        '46' => 'Ebcdc',
                        '9082'=> 'Boa',
                        '9083' => 'Solidaire',
                        '9084' => 'Sofibank'
                );
        public $legalstatus = array(
                        "" => "",
                        "1" => "Personne morale",
                        "2" => "Personne physique"
                );

	public function __construct()
	{
		parent::__construct();

                $this->bank = isset($this->session->userdata["account_pageid"])?$this->session->userdata["account_pageid"]:"";

                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank = ucfirst($this->bank);
                }
	}

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}

        public function get_quitus_fiscal_info($id = NULL)
        {
                if ($id == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Makerid_4 = '';
                        $obj->Changer_5 = '';
                        $obj->Changes_6 = '';
                        $obj->Taxpayer_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Agence_9 = '';
                        $obj->Reference_10 = '';
                        $obj->Dateissue_11 = '';
                        $obj->Expiration_12 = '';
                        $obj->Comment_13 = '';
                        $obj->Filequitus_14 ='';
                        $obj->Regie_15 ='';
                        $obj->Service_16 ='';
                        $obj->Validity_17 ='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_quitus_fiscal q', 'q.Id_0', 'q.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_client_fiscal_info($id = NULL)
        {
                if ($id == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Makerid_4 = '';
                        $obj->Changer_5 = '';
                        $obj->Changes_6 = '';
                        $obj->Nif_7 = '';
                        $obj->Designation_8 = '';
                        $obj->Email_9 = '';
                        $obj->Phone_10 = '';
                        $obj->Address_11 = '';
                        $obj->Legalstatus_12 = '';
                        $obj->Cbs_id_13 = '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_quitus_client clt', 'clt.Id_0', 'clt.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL)
        {
                if($item=="taxpayer")
                {
                        $st = " Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('logiref_quitus_client')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        foreach ($query->getResult() as $row)
                        {
                               $ddmenu[$row->Nif_7]["Nif_7"] = $row->Nif_7;
                               $ddmenu[$row->Nif_7]["Designation_8"] = $row->Designation_8;
                               $ddmenu[$row->Nif_7]["Email_9"] = $row->Email_9;
                               $ddmenu[$row->Nif_7]["Phone_10"] = $row->Phone_10;
                               $ddmenu[$row->Nif_7]["Address_11"] = $row->Address_11;
                               $ddmenu[$row->Nif_7]["Legalstatus_12"] = $row->Legalstatus_12;
                               $ddmenu[$row->Nif_7]["Cbs_id_13"] = $row->Cbs_id_13;
                        }
                        return $ddmenu;
                }
                elseif($item=="customers")
                {
                        $st = " Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('logiref_quitus_client')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResult() as $row)
                        {
                               $ddmenu[$row->Nif_7] = $row->Designation_8;
                        }
                        return $ddmenu;
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_clients_fiscal($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $query = $this->db->table('logiref_quitus_client')
                                ->select('logiref_quitus_client.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }

        public function get_quitus_fiscal_nvalidated()
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }

        public function get_quitus_fiscal_validated()
        {
                $st = "Status_2<>'1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }

        public function get_all_quitus($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_quitus_currents($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Status_2='2' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_filter_quitus_currents()
	{
                $data = $_POST;
                $where = "Status_2='1'";
                if(isset($data['Taxpayer_7']) && $data['Taxpayer_7'] !='') $where .= " AND (Nif_7 LIKE '%".$data['Taxpayer_7']."%' OR Designation_8 LIKE '%".$data['Taxpayer_7']."%')";

                if(isset($data['ClientID']) && $data['ClientID'] !='') $where .= " AND Cbs_id_13 LIKE '%".$data['ClientID']."%'";

                $search = $this->db->table("logiref_quitus_client")
                                ->where($where)
                                ->orderBy('Date_1','ASC')
                                ->get();
                $contribuable = $search->getRow();

                $st = "Status_2='2' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                #Filtre d'affichage
                if (!is_null($contribuable)) $st .= " AND Taxpayer_7='" . $contribuable->Nif_7. "'";

                if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
                    $st .= " AND Dateissue_11  BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_quitus_expires($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Status_2='3' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_filter_quitus_expires()
	{
                $data = $_POST;
                $where = "Status_2='1'";
                if(isset($data['Taxpayer_7']) && $data['Taxpayer_7'] !='') $where .= " AND (Nif_7 LIKE '%".$data['Taxpayer_7']."%' OR Designation_8 LIKE '%".$data['Taxpayer_7']."%')";

                if(isset($data['ClientID']) && $data['ClientID'] !='') $where .= " AND Cbs_id_13 LIKE '%".$data['ClientID']."%'";

                $search = $this->db->table("logiref_quitus_client")
                                ->where($where)
                                ->orderBy('Date_1','ASC')
                                ->get();
                $contribuable = $search->getRow();

                $st = "Status_2='3' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                #Filtre d'affichage
                if (!is_null($contribuable)) $st .= " AND Taxpayer_7='" . $contribuable->Nif_7. "'";

                if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
                    $st .= " AND Dateissue_11  BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

                $query = $this->db->table('logiref_quitus_fiscal')
                                ->select('logiref_quitus_fiscal.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_count_quitus_current()
        {
                $st = "Status_2='2' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $count = $this->db->table('logiref_quitus_fiscal')
                        ->where($st)
                        ->countAllResults();
                return $count;
        }

        public function get_count_quitus_expire()
        {
                $st = "Status_2='3' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $count = $this->db->table('logiref_quitus_fiscal')
                        ->where($st)
                        ->countAllResults();
                return $count;
        }

        public function get_count_quitus_client()
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $count = $this->db->table('logiref_quitus_client')
                        ->where($st)
                        ->countAllResults();
                return $count;
        }

        public function get_client_by_taxpayer($Nif_7)
        {
                $st = "Status_2='1' AND Nif_7 ='".$Nif_7."'";

                $query = $this->db->table('logiref_quitus_client')
                        ->select('logiref_quitus_client.*')
                        ->where($st)
                        ->get();
                return $query->getRow();
        }

        public function get_client_by_codeclt($CodeCLT)
        {
                $st = "Status_2='1' AND Codeclt_14 ='".$CodeCLT."'";

                $query = $this->db->table('logiref_quitus_client')
                        ->select('logiref_quitus_client.*')
                        ->where($st)
                        ->get();
                return $query->getRow();
        }

        public function get_taxpayer_by_nif($Nif_7)
        {
                $st = "Status_2='1' AND Nif_4 ='".$Nif_7."'";
                $db = \Config\Database::connect('ikwook_logiref_main');
                $query = $db->table('logiref_nifs')
                        ->select('logiref_nifs.*')
                        ->where($st)
                        ->get();
                return $query->getRow();
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        public function save_quitus($data, $id)
        {
                $this->set_table('logiref_quitus_fiscal', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_client($data, $id)
        {
                $this->set_table('logiref_quitus_client', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}