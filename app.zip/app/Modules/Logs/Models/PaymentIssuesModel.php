<?php

namespace Modules\Logs\Models;

use Config\Database;

class PaymentIssuesModel
{
    private \CodeIgniter\Database\BaseConnection $db;
    private string $table = 'logiref_payment_issues';
    private string $activityTable = 'logiref_payment_issue_activities';
    private array $columnDefinitions = [
        'Id_0' => 'int(11) NOT NULL AUTO_INCREMENT',
        'IssueCode_1' => 'varchar(100) DEFAULT NULL',
        'Channel_2' => 'varchar(50) DEFAULT NULL',
        'Module_3' => 'varchar(100) DEFAULT NULL',
        'Stage_4' => 'varchar(100) DEFAULT NULL',
        'Severity_5' => 'varchar(30) DEFAULT NULL',
        'Status_6' => 'varchar(30) DEFAULT NULL',
        'Title_7' => 'varchar(255) NOT NULL',
        'Description_8' => 'longtext DEFAULT NULL',
        'Reference_9' => 'varchar(100) DEFAULT NULL',
        'PaymentId_10' => 'bigint(20) DEFAULT NULL',
        'NoteReference_11' => 'text DEFAULT NULL',
        'CustomerEmail_12' => 'varchar(150) DEFAULT NULL',
        'CustomerName_13' => 'varchar(255) DEFAULT NULL',
        'PaymentMode_14' => 'varchar(50) DEFAULT NULL',
        'TransactionReference_15' => 'varchar(150) DEFAULT NULL',
        'ContextPayload_16' => 'longtext DEFAULT NULL',
        'SupportNoticeStatus_17' => 'varchar(30) DEFAULT NULL',
        'SupportNoticeLogId_18' => 'int(11) DEFAULT NULL',
        'SupportNoticeMessageId_19' => 'varchar(150) DEFAULT NULL',
        'CreatedAt_20' => 'datetime DEFAULT CURRENT_TIMESTAMP',
        'UpdatedAt_21' => 'datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
        'AssignedUserId_22' => 'int(11) DEFAULT NULL',
        'AssignedUserCode_23' => 'varchar(100) DEFAULT NULL',
        'AssignedUserName_24' => 'varchar(255) DEFAULT NULL',
        'AssignedUserEmail_25' => 'varchar(150) DEFAULT NULL',
        'ReporterUserCode_26' => 'varchar(100) DEFAULT NULL',
        'ReporterUserName_27' => 'varchar(255) DEFAULT NULL',
        'Priority_28' => 'varchar(30) DEFAULT NULL',
        'Category_29' => 'varchar(50) DEFAULT NULL',
        'ResolutionNote_30' => 'longtext DEFAULT NULL',
        'AssignedAt_31' => 'datetime DEFAULT NULL',
        'StartedAt_32' => 'datetime DEFAULT NULL',
        'ResolvedAt_33' => 'datetime DEFAULT NULL',
        'ClosedAt_34' => 'datetime DEFAULT NULL',
        'LastActivityAt_35' => 'datetime DEFAULT NULL',
    ];
    private array $activityColumnDefinitions = [
        'Id_0' => 'int(11) NOT NULL AUTO_INCREMENT',
        'IssueId_1' => 'int(11) NOT NULL',
        'ActionType_2' => 'varchar(50) DEFAULT NULL',
        'OldValue_3' => 'longtext DEFAULT NULL',
        'NewValue_4' => 'longtext DEFAULT NULL',
        'Note_5' => 'longtext DEFAULT NULL',
        'ActorUserCode_6' => 'varchar(100) DEFAULT NULL',
        'ActorUserName_7' => 'varchar(255) DEFAULT NULL',
        'ActorUserEmail_8' => 'varchar(150) DEFAULT NULL',
        'CreatedAt_9' => 'datetime DEFAULT CURRENT_TIMESTAMP',
    ];

    public function __construct()
    {
        $this->db = Database::connect('ikwook_logiref_main');
        $this->ensure_tables_exist();
    }

    public function create_issue(array $data): int|false
    {
        $this->ensure_tables_exist();

        $actor = is_array($data['actor'] ?? null) ? $data['actor'] : [];
        $now = date('Y-m-d H:i:s');
        $severity = $this->normalize_severity((string) $this->get_data_value($data, ['Severity_5', 'Severity'], 'HIGH'));
        $status = $this->normalize_status((string) $this->get_data_value($data, ['Status_6', 'Status'], 'OPEN'));

        $payload = [
            'IssueCode_1' => $this->limit((string) $this->get_data_value($data, ['IssueCode_1', 'IssueCode'], ''), 100) ?: $this->generate_issue_code(),
            'Channel_2' => $this->limit((string) $this->get_data_value($data, ['Channel_2', 'Channel'], 'passport'), 50) ?: 'passport',
            'Module_3' => $this->limit((string) $this->get_data_value($data, ['Module_3', 'Module'], 'LOGIREF_PASSPORT_PAYMENT'), 100) ?: 'LOGIREF_PASSPORT_PAYMENT',
            'Stage_4' => $this->limit((string) $this->get_data_value($data, ['Stage_4', 'Stage'], 'payment_issue'), 100),
            'Severity_5' => $severity,
            'Status_6' => $status,
            'Title_7' => $this->limit((string) $this->get_data_value($data, ['Title_7', 'Title'], 'Incident de paiement'), 255),
            'Description_8' => (string) $this->get_data_value($data, ['Description_8', 'Description'], ''),
            'Reference_9' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['Reference_9', 'Reference_2'], ''), 100)),
            'PaymentId_10' => is_numeric($this->get_data_value($data, ['PaymentId_10', 'PaymentId_14'])) ? (int) $this->get_data_value($data, ['PaymentId_10', 'PaymentId_14']) : null,
            'NoteReference_11' => $this->nullable_string((string) $this->get_data_value($data, ['NoteReference_11', 'NoteReference_15'], '')),
            'CustomerEmail_12' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['CustomerEmail_12', 'CustomerEmail_16'], ''), 150)),
            'CustomerName_13' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['CustomerName_13', 'CustomerName_17'], ''), 255)),
            'PaymentMode_14' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['PaymentMode_14', 'PaymentMode_18'], ''), 50)),
            'TransactionReference_15' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['TransactionReference_15', 'TransactionReference_19'], ''), 150)),
            'ContextPayload_16' => $this->normalize_payload($this->get_data_value($data, ['ContextPayload_16', 'ContextPayload_20'])),
            'SupportNoticeStatus_17' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['SupportNoticeStatus_17', 'SupportNoticeStatus_21'], ''), 30)),
            'SupportNoticeLogId_18' => is_numeric($this->get_data_value($data, ['SupportNoticeLogId_18', 'SupportNoticeLogId_22'])) ? (int) $this->get_data_value($data, ['SupportNoticeLogId_18', 'SupportNoticeLogId_22']) : null,
            'SupportNoticeMessageId_19' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['SupportNoticeMessageId_19', 'SupportNoticeMessageId_23'], ''), 150)),
            'ReporterUserCode_26' => $this->nullable_string($this->limit((string) ($actor['code'] ?? $this->get_data_value($data, ['ReporterUserCode_26'], 'SYSTEM')), 100)),
            'ReporterUserName_27' => $this->nullable_string($this->limit((string) ($actor['name'] ?? $this->get_data_value($data, ['ReporterUserName_27'], 'Support Logiref')), 255)),
            'Priority_28' => $this->normalize_priority((string) $this->get_data_value($data, ['Priority_28', 'Priority'], $severity)),
            'Category_29' => $this->nullable_string($this->limit((string) $this->get_data_value($data, ['Category_29', 'Category'], 'PAYMENT'), 50)),
            'ResolutionNote_30' => $this->nullable_string((string) $this->get_data_value($data, ['ResolutionNote_30', 'ResolutionNote'], '')),
            'AssignedAt_31' => null,
            'StartedAt_32' => in_array($status, ['IN_PROGRESS', 'WAITING_PROVIDER', 'WAITING_CUSTOMER', 'BLOCKED'], true) ? $now : null,
            'ResolvedAt_33' => in_array($status, ['RESOLVED', 'CLOSED'], true) ? $now : null,
            'ClosedAt_34' => $status === 'CLOSED' ? $now : null,
            'LastActivityAt_35' => $now,
        ];

        $inserted = $this->db->table($this->table)->insert($payload);
        if (!$inserted) {
            return false;
        }

        $issue_id = (int) $this->db->insertID();
        $this->append_activity($issue_id, 'CREATED', null, $payload, 'Issue créée automatiquement.', $actor);
        $this->append_issue_log([
            'action' => 'CREATED',
            'issue_id' => $issue_id,
            'payload' => $payload,
        ]);

        return $issue_id;
    }

    public function get_filtered_issues(array $filters = [], int $limit = 200): array
    {
        $this->ensure_tables_exist();

        $builder = $this->db->table($this->table);
        $this->apply_filters($builder, $filters);

        return $builder
            ->orderBy('LastActivityAt_35', 'DESC')
            ->orderBy('Id_0', 'DESC')
            ->limit(max(1, $limit))
            ->get()
            ->getResultArray();
    }

    public function get_issues_summary(array $filters = []): array
    {
        $rows = $this->get_filtered_issues($filters, 5000);
        $summary = [
            'total' => count($rows),
            'open' => 0,
            'assigned' => 0,
            'in_progress' => 0,
            'resolved' => 0,
            'critical' => 0,
            'unassigned' => 0,
        ];

        foreach ($rows as $row) {
            $status = strtoupper(trim((string) ($row['Status_6'] ?? '')));
            $priority = strtoupper(trim((string) ($row['Priority_28'] ?? '')));
            $assigned_user = trim((string) ($row['AssignedUserCode_23'] ?? ''));

            if ($status === 'OPEN') {
                $summary['open']++;
            }

            if ($status === 'ASSIGNED') {
                $summary['assigned']++;
            }

            if (in_array($status, ['IN_PROGRESS', 'WAITING_PROVIDER', 'WAITING_CUSTOMER', 'BLOCKED'], true)) {
                $summary['in_progress']++;
            }

            if (in_array($status, ['RESOLVED', 'CLOSED'], true)) {
                $summary['resolved']++;
            }

            if ($priority === 'CRITICAL') {
                $summary['critical']++;
            }

            if ($assigned_user === '') {
                $summary['unassigned']++;
            }
        }

        return $summary;
    }

    public function get_filter_options(): array
    {
        return [
            'statuses' => $this->get_status_options(),
            'severities' => ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'],
            'priorities' => $this->get_priority_options(),
            'stages' => $this->get_distinct_values('Stage_4'),
            'channels' => $this->get_distinct_values('Channel_2'),
            'modules' => $this->get_distinct_values('Module_3'),
            'assignees' => $this->get_assignable_users(),
        ];
    }

    public function get_issue_by_id(int $id): ?array
    {
        return $this->db->table($this->table)
            ->where('Id_0', $id)
            ->get()
            ->getRowArray() ?: null;
    }

    public function get_issue_ticket(int $id): ?array
    {
        $issue = $this->get_issue_by_id($id);
        if ($issue === null) {
            return null;
        }

        return [
            'issue' => $issue,
            'activities' => $this->get_issue_activities($id),
            'status_options' => $this->get_status_options(),
            'priority_options' => $this->get_priority_options(),
            'assignable_users' => $this->get_assignable_users(),
        ];
    }

    public function update_issue_ticket(int $id, array $payload, array $actor = []): array
    {
        $issue = $this->get_issue_by_id($id);
        if ($issue === null) {
            return ['ok' => false, 'message' => 'Issue not found.'];
        }

        $old = $issue;
        $update = [];
        $note = trim((string) ($payload['note'] ?? ''));
        $now = date('Y-m-d H:i:s');

        $status = trim((string) ($payload['status'] ?? ''));
        if ($status !== '') {
            $status = $this->normalize_status($status);
            $update['Status_6'] = $status;

            if ($status === 'IN_PROGRESS' && empty($issue['StartedAt_32'])) {
                $update['StartedAt_32'] = $now;
            }

            if ($status === 'ASSIGNED' && empty($issue['AssignedAt_31'])) {
                $update['AssignedAt_31'] = $now;
            }

            if ($status === 'RESOLVED') {
                $update['ResolvedAt_33'] = $now;
            }

            if ($status === 'CLOSED') {
                $update['ClosedAt_34'] = $now;
                if (empty($issue['ResolvedAt_33'])) {
                    $update['ResolvedAt_33'] = $now;
                }
            }
        }

        $priority = trim((string) ($payload['priority'] ?? ''));
        if ($priority !== '') {
            $update['Priority_28'] = $this->normalize_priority($priority);
        }

        $resolution_note = trim((string) ($payload['resolution_note'] ?? ''));
        if ($resolution_note !== '') {
            $update['ResolutionNote_30'] = $resolution_note;
        }

        $assigned_user_id = trim((string) ($payload['assigned_user_id'] ?? ''));
        if ($assigned_user_id !== '') {
            $assignee = $this->find_assignable_user((int) $assigned_user_id);
            if ($assignee !== null) {
                $update['AssignedUserId_22'] = (int) ($assignee['Id_0'] ?? 0);
                $update['AssignedUserCode_23'] = $this->nullable_string((string) ($assignee['Userid_13'] ?? ''));
                $update['AssignedUserName_24'] = $this->nullable_string((string) ($assignee['DisplayName'] ?? $assignee['Userid_13'] ?? ''));
                $update['AssignedUserEmail_25'] = $this->nullable_string((string) ($assignee['Login_17'] ?? ''));
                $update['AssignedAt_31'] = $now;

                if (empty($update['Status_6']) && in_array(strtoupper(trim((string) ($issue['Status_6'] ?? 'OPEN'))), ['OPEN', 'TRIAGED'], true)) {
                    $update['Status_6'] = 'ASSIGNED';
                }
            }
        } elseif (array_key_exists('assigned_user_id', $payload) && $payload['assigned_user_id'] === '') {
            $update['AssignedUserId_22'] = null;
            $update['AssignedUserCode_23'] = null;
            $update['AssignedUserName_24'] = null;
            $update['AssignedUserEmail_25'] = null;
        }

        if ($update === [] && $note === '') {
            return ['ok' => false, 'message' => 'No ticket change provided.'];
        }

        $update['LastActivityAt_35'] = $now;
        $this->db->table($this->table)->where('Id_0', $id)->update($update);
        $fresh = $this->get_issue_by_id($id);

        $action = 'UPDATED';
        if (isset($update['AssignedUserId_22'])) {
            $action = $update['AssignedUserId_22'] ? 'ASSIGNED' : 'UNASSIGNED';
        }
        if (isset($update['Status_6'])) {
            $action = 'STATUS_CHANGED';
        }

        $this->append_activity($id, $action, $old, $fresh, $note, $actor);
        $this->append_issue_log([
            'action' => $action,
            'issue_id' => $id,
            'actor' => $actor,
            'changes' => $update,
            'note' => $note,
        ]);

        return [
            'ok' => true,
            'message' => 'Ticket updated successfully.',
            'issue' => $fresh,
        ];
    }

    public function add_issue_comment(int $id, string $comment, array $actor = []): array
    {
        $issue = $this->get_issue_by_id($id);
        if ($issue === null) {
            return ['ok' => false, 'message' => 'Issue not found.'];
        }

        $comment = trim($comment);
        if ($comment === '') {
            return ['ok' => false, 'message' => 'Comment is required.'];
        }

        $now = date('Y-m-d H:i:s');
        $this->db->table($this->table)
            ->where('Id_0', $id)
            ->update(['LastActivityAt_35' => $now]);

        $this->append_activity($id, 'COMMENT', null, null, $comment, $actor);
        $this->append_issue_log([
            'action' => 'COMMENT',
            'issue_id' => $id,
            'actor' => $actor,
            'note' => $comment,
        ]);

        return [
            'ok' => true,
            'message' => 'Comment added successfully.',
            'activities' => $this->get_issue_activities($id),
        ];
    }

    public function get_issue_realtime_logs(int $tailLines = 50): array
    {
        $logDir = ROOTPATH . 'drive/logs/logiref/issues';
        if (!is_dir($logDir)) {
            return [];
        }

        $files = glob($logDir . '/*payment_issues.logs') ?: [];
        rsort($files, SORT_STRING);

        $items = [];
        foreach ($files as $file) {
            if (!is_file($file)) {
                continue;
            }

            $items[] = [
                'name' => basename($file),
                'path' => $file,
                'size' => filesize($file) ?: 0,
                'modifiedAt' => date('c', (int) filemtime($file)),
                'tail' => $this->tail_file($file, $tailLines),
            ];
        }

        return $items;
    }

    public function get_status_options(): array
    {
        return [
            'OPEN',
            'TRIAGED',
            'ASSIGNED',
            'IN_PROGRESS',
            'WAITING_PROVIDER',
            'WAITING_CUSTOMER',
            'BLOCKED',
            'RESOLVED',
            'CLOSED',
            'REJECTED',
        ];
    }

    public function get_priority_options(): array
    {
        return ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
    }

    public function get_assignable_users(): array
    {
        $builder = $this->db->table('logiref_users')
            ->select('Id_0, Userid_13, Code_12, Login_17, Role_4, Status_2');

        if (!empty($_SESSION['userdata']['account_id'])) {
            $builder->where('Account_3', $_SESSION['userdata']['account_id']);
        }

        $rows = $builder
            ->where('Status_2', 1)
            ->orderBy('Userid_13', 'ASC')
            ->get()
            ->getResultArray();

        return array_map(function (array $row): array {
            $display = trim((string) ($row['Userid_13'] ?? ''));
            $code = trim((string) ($row['Code_12'] ?? ''));
            if ($code !== '') {
                $display .= ' (' . $code . ')';
            }

            return $row + ['DisplayName' => $display !== '' ? $display : ('Utilisateur #' . (int) ($row['Id_0'] ?? 0))];
        }, $rows);
    }

    private function get_issue_activities(int $issueId): array
    {
        return $this->db->table($this->activityTable)
            ->where('IssueId_1', $issueId)
            ->orderBy('Id_0', 'DESC')
            ->get()
            ->getResultArray();
    }

    private function find_assignable_user(int $id): ?array
    {
        foreach ($this->get_assignable_users() as $user) {
            if ((int) ($user['Id_0'] ?? 0) === $id) {
                return $user;
            }
        }

        return null;
    }

    private function ensure_tables_exist(): void
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . $this->table . '` (
            `Id_0` int(11) NOT NULL AUTO_INCREMENT,
            `IssueCode_1` varchar(100) DEFAULT NULL,
            `Channel_2` varchar(50) DEFAULT NULL,
            `Module_3` varchar(100) DEFAULT NULL,
            `Stage_4` varchar(100) DEFAULT NULL,
            `Severity_5` varchar(30) DEFAULT NULL,
            `Status_6` varchar(30) DEFAULT NULL,
            `Title_7` varchar(255) NOT NULL,
            `Description_8` longtext DEFAULT NULL,
            `Reference_9` varchar(100) DEFAULT NULL,
            `PaymentId_10` bigint(20) DEFAULT NULL,
            `NoteReference_11` text DEFAULT NULL,
            `CustomerEmail_12` varchar(150) DEFAULT NULL,
            `CustomerName_13` varchar(255) DEFAULT NULL,
            `PaymentMode_14` varchar(50) DEFAULT NULL,
            `TransactionReference_15` varchar(150) DEFAULT NULL,
            `ContextPayload_16` longtext DEFAULT NULL,
            `SupportNoticeStatus_17` varchar(30) DEFAULT NULL,
            `SupportNoticeLogId_18` int(11) DEFAULT NULL,
            `SupportNoticeMessageId_19` varchar(150) DEFAULT NULL,
            `CreatedAt_20` datetime DEFAULT CURRENT_TIMESTAMP,
            `UpdatedAt_21` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            `AssignedUserId_22` int(11) DEFAULT NULL,
            `AssignedUserCode_23` varchar(100) DEFAULT NULL,
            `AssignedUserName_24` varchar(255) DEFAULT NULL,
            `AssignedUserEmail_25` varchar(150) DEFAULT NULL,
            `ReporterUserCode_26` varchar(100) DEFAULT NULL,
            `ReporterUserName_27` varchar(255) DEFAULT NULL,
            `Priority_28` varchar(30) DEFAULT NULL,
            `Category_29` varchar(50) DEFAULT NULL,
            `ResolutionNote_30` longtext DEFAULT NULL,
            `AssignedAt_31` datetime DEFAULT NULL,
            `StartedAt_32` datetime DEFAULT NULL,
            `ResolvedAt_33` datetime DEFAULT NULL,
            `ClosedAt_34` datetime DEFAULT NULL,
            `LastActivityAt_35` datetime DEFAULT NULL,
            PRIMARY KEY (`Id_0`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';

        $activitySql = 'CREATE TABLE IF NOT EXISTS `' . $this->activityTable . '` (
            `Id_0` int(11) NOT NULL AUTO_INCREMENT,
            `IssueId_1` int(11) NOT NULL,
            `ActionType_2` varchar(50) DEFAULT NULL,
            `OldValue_3` longtext DEFAULT NULL,
            `NewValue_4` longtext DEFAULT NULL,
            `Note_5` longtext DEFAULT NULL,
            `ActorUserCode_6` varchar(100) DEFAULT NULL,
            `ActorUserName_7` varchar(255) DEFAULT NULL,
            `ActorUserEmail_8` varchar(150) DEFAULT NULL,
            `CreatedAt_9` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`Id_0`),
            KEY `IssueId_1` (`IssueId_1`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';

        $this->db->query($sql);
        $this->db->query($activitySql);
        $this->migrate_legacy_columns();
        $this->ensure_extra_columns();
    }

    private function ensure_extra_columns(): void
    {
        $fields = array_flip($this->db->getFieldNames($this->table));
        foreach ($this->columnDefinitions as $column => $definition) {
            if (isset($fields[$column])) {
                continue;
            }

            $this->db->query('ALTER TABLE `' . $this->table . '` ADD COLUMN `' . $column . '` ' . $definition);
        }

        $activityFields = array_flip($this->db->getFieldNames($this->activityTable));
        foreach ($this->activityColumnDefinitions as $column => $definition) {
            if (isset($activityFields[$column])) {
                continue;
            }

            $this->db->query('ALTER TABLE `' . $this->activityTable . '` ADD COLUMN `' . $column . '` ' . $definition);
        }
    }

    private function apply_filters(\CodeIgniter\Database\BaseBuilder $builder, array $filters): void
    {
        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $builder->groupStart()
                ->like('IssueCode_1', $q)
                ->orLike('Title_7', $q)
                ->orLike('Description_8', $q)
                ->orLike('Reference_9', $q)
                ->orLike('CustomerEmail_12', $q)
                ->orLike('AssignedUserName_24', $q)
                ->groupEnd();
        }

        foreach ([
            'status' => 'Status_6',
            'severity' => 'Severity_5',
            'priority' => 'Priority_28',
            'stage' => 'Stage_4',
            'channel' => 'Channel_2',
            'module' => 'Module_3',
        ] as $filterKey => $column) {
            $value = trim((string) ($filters[$filterKey] ?? ''));
            if ($value !== '') {
                $builder->where($column, $value);
            }
        }

        $reference = trim((string) ($filters['reference'] ?? ''));
        if ($reference !== '') {
            $builder->like('Reference_9', $reference);
        }

        $customer_email = trim((string) ($filters['customer_email'] ?? ''));
        if ($customer_email !== '') {
            $builder->like('CustomerEmail_12', $customer_email);
        }

        $assigned_user = trim((string) ($filters['assigned_user'] ?? ''));
        if ($assigned_user !== '') {
            $builder->where('AssignedUserId_22', (int) $assigned_user);
        }

        $date_from = trim((string) ($filters['date_from'] ?? ''));
        if ($date_from !== '') {
            $builder->where('DATE(CreatedAt_20) >=', $date_from);
        }

        $date_to = trim((string) ($filters['date_to'] ?? ''));
        if ($date_to !== '') {
            $builder->where('DATE(CreatedAt_20) <=', $date_to);
        }
    }

    private function migrate_legacy_columns(): void
    {
        $legacyMap = [
            'Id' => 'Id_0',
            'IssueCode' => 'IssueCode_1',
            'Channel' => 'Channel_2',
            'Module' => 'Module_3',
            'Stage' => 'Stage_4',
            'Severity' => 'Severity_5',
            'Status' => 'Status_6',
            'Title' => 'Title_7',
            'Description' => 'Description_8',
            'Reference_2' => 'Reference_9',
            'PaymentId_14' => 'PaymentId_10',
            'NoteReference_15' => 'NoteReference_11',
            'CustomerEmail_16' => 'CustomerEmail_12',
            'CustomerName_17' => 'CustomerName_13',
            'PaymentMode_18' => 'PaymentMode_14',
            'TransactionReference_19' => 'TransactionReference_15',
            'ContextPayload_20' => 'ContextPayload_16',
            'SupportNoticeStatus_21' => 'SupportNoticeStatus_17',
            'SupportNoticeLogId_22' => 'SupportNoticeLogId_18',
            'SupportNoticeMessageId_23' => 'SupportNoticeMessageId_19',
            'CreatedAt_24' => 'CreatedAt_20',
            'UpdatedAt_25' => 'UpdatedAt_21',
        ];

        $fields = array_flip($this->db->getFieldNames($this->table));
        foreach ($legacyMap as $old => $new) {
            if (!isset($fields[$old]) || isset($fields[$new]) || !isset($this->columnDefinitions[$new])) {
                continue;
            }

            $this->db->query(
                'ALTER TABLE `' . $this->table . '` CHANGE COLUMN `' . $old . '` `' . $new . '` ' . $this->columnDefinitions[$new]
            );
        }
    }

    private function append_activity(int $issueId, string $actionType, ?array $old, ?array $new, string $note, array $actor): void
    {
        $this->db->table($this->activityTable)->insert([
            'IssueId_1' => $issueId,
            'ActionType_2' => $actionType,
            'OldValue_3' => $this->normalize_payload($old),
            'NewValue_4' => $this->normalize_payload($new),
            'Note_5' => $note !== '' ? $note : null,
            'ActorUserCode_6' => $this->nullable_string($this->limit((string) ($actor['code'] ?? 'SYSTEM'), 100)),
            'ActorUserName_7' => $this->nullable_string($this->limit((string) ($actor['name'] ?? 'System'), 255)),
            'ActorUserEmail_8' => $this->nullable_string($this->limit((string) ($actor['email'] ?? ''), 150)),
            'CreatedAt_9' => date('Y-m-d H:i:s'),
        ]);
    }

    private function append_issue_log(array $payload): void
    {
        $logDir = ROOTPATH . 'drive/logs/logiref/issues';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0775, true);
        }

        $file = $logDir . '/' . date('Y-m-d') . '_payment_issues.logs';
        $line = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($line !== false) {
            @file_put_contents($file, $line . PHP_EOL, FILE_APPEND);
        }
    }

    private function get_distinct_values(string $column): array
    {
        return array_values(array_filter(array_map(
            static fn(array $row): string => trim((string) ($row[$column] ?? '')),
            $this->db->table($this->table)
                ->select($column)
                ->where($column . ' IS NOT NULL', null, false)
                ->where($column . ' <>', '')
                ->groupBy($column)
                ->orderBy($column, 'ASC')
                ->get()
                ->getResultArray()
        )));
    }

    private function tail_file(string $file, int $tailLines): array
    {
        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        return is_array($lines) ? array_slice($lines, -max(1, $tailLines)) : [];
    }

    private function generate_issue_code(): string
    {
        return 'PAY-ISSUE-' . date('YmdHis') . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
    }

    private function normalize_payload($payload): ?string
    {
        if ($payload === null || $payload === '') {
            return null;
        }

        if (is_string($payload)) {
            return $payload;
        }

        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        return $encoded === false ? null : $encoded;
    }

    private function normalize_status(string $status): string
    {
        $status = strtoupper(trim($status));
        return in_array($status, $this->get_status_options(), true) ? $status : 'OPEN';
    }

    private function normalize_priority(string $priority): string
    {
        $priority = strtoupper(trim($priority));
        return in_array($priority, $this->get_priority_options(), true) ? $priority : 'MEDIUM';
    }

    private function normalize_severity(string $severity): string
    {
        $severity = strtoupper(trim($severity));
        return in_array($severity, ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'], true) ? $severity : 'HIGH';
    }

    private function nullable_string(string $value): ?string
    {
        $value = trim($value);
        return $value === '' ? null : $value;
    }

    private function limit(string $value, int $length): string
    {
        return mb_substr(trim($value), 0, $length);
    }

    private function get_data_value(array $data, array $keys, $default = null)
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $data)) {
                return $data[$key];
            }
        }

        return $default;
    }
}
