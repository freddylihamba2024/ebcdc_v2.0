<?php

namespace Modules\Logs\Models;

class ExternalApiLogsModel
{
    public function get_all_external_api_logs(): array
    {
        $directories = [
            ROOTPATH . 'drive/logs/services',
            ROOTPATH . 'drive/logs/curl',
        ];

        $items = [];
        foreach ($directories as $directory) {
            $items[] = [
                'root' => $directory,
                'entries' => $this->scan_root($directory, 20),
            ];
        }

        return $items;
    }

    private function scan_root(string $root, int $maxFilesPerDirectory): array
    {
        if (!is_dir($root)) {
            return [];
        }

        $children = glob($root . '/*') ?: [];
        sort($children, SORT_STRING);
        $entries = [];

        foreach ($children as $child) {
            if (is_dir($child)) {
                $files = array_filter(glob($child . '/*') ?: [], 'is_file');
                rsort($files, SORT_STRING);

                $entries[] = [
                    'name' => basename($child),
                    'path' => $child,
                    'type' => 'directory',
                    'files' => array_map(
                        fn (string $file): array => [
                            'name' => basename($file),
                            'path' => $file,
                            'size' => filesize($file) ?: 0,
                            'modifiedAt' => date('c', (int) filemtime($file)),
                        ],
                        array_slice($files, 0, $maxFilesPerDirectory)
                    ),
                ];
                continue;
            }

            $entries[] = [
                'name' => basename($child),
                'path' => $child,
                'type' => 'file',
                'size' => filesize($child) ?: 0,
                'modifiedAt' => date('c', (int) filemtime($child)),
            ];
        }

        return $entries;
    }
}
