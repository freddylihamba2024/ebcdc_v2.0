<?php

namespace Modules\Logs\Models;

class IntegrationLogsModel
{
    private array $sources;

    public function __construct()
    {
        $this->sources = $this->discover_sources();
    }

    public function get_filtered_integration_logs(array $filters = [], int $limit = 200): array
    {
        $items = [];

        foreach ($this->sources as $source) {
            if (!$this->matches_source_filter($source['key'], $filters)) {
                continue;
            }

            if (!is_dir($source['path'])) {
                continue;
            }

            $files = array_filter(glob($source['path'] . '/*.logs') ?: [], 'is_file');
            rsort($files, SORT_STRING);

            foreach ($files as $file) {
                $item = $this->build_log_item($file, $source);
                if ($item === null || !$this->matches_filters($item, $filters)) {
                    continue;
                }

                $items[] = $item;
            }
        }

        usort($items, static function (array $left, array $right): int {
            return strcmp((string) ($right['modifiedAt'] ?? ''), (string) ($left['modifiedAt'] ?? ''));
        });

        return array_slice($items, 0, max(1, $limit));
    }

    public function get_summary(array $filters = []): array
    {
        $rows = $this->get_filtered_integration_logs($filters, 5000);
        $summary = [
            'total' => count($rows),
            'sources' => 0,
            'drive_sources' => 0,
            'errors' => 0,
        ];

        $usedSources = [];
        $usedDriveSources = [];

        foreach ($rows as $row) {
            $source = (string) ($row['sourceKey'] ?? '');
            $usedSources[$source] = true;

            if (($row['sourceFamily'] ?? '') === 'drive') {
                $usedDriveSources[$source] = true;
            }

            if (($row['logType'] ?? '') === 'ERROR') {
                $summary['errors']++;
            }
        }

        $summary['sources'] = count($usedSources);
        $summary['drive_sources'] = count($usedDriveSources);

        return $summary;
    }

    public function get_filter_options(): array
    {
        $prefixes = [];
        foreach ($this->get_filtered_integration_logs([], 5000) as $row) {
            $prefix = trim((string) ($row['prefix'] ?? ''));
            if ($prefix !== '') {
                $prefixes[$prefix] = $prefix;
            }
        }

        ksort($prefixes, SORT_STRING);

        return [
            'sources' => array_map(static fn(array $source): array => [
                'key' => $source['key'],
                'label' => $source['label'],
            ], $this->sources),
            'prefixes' => array_values($prefixes),
            'log_types' => ['REQUEST', 'RESPONSE', 'ERROR', 'EVENT', 'DATA'],
            'channels' => $this->get_detected_channels(),
            'status_hints' => ['SUCCESS', 'ERROR', 'UNKNOWN'],
        ];
    }

    public function get_log_detail(string $ref): ?array
    {
        $path = $this->decode_log_ref($ref);
        if ($path === null || !is_file($path)) {
            return null;
        }

        $source = $this->resolve_source_by_path($path);
        if ($source === null) {
            return null;
        }

        $item = $this->build_log_item($path, $source);
        if ($item === null) {
            return null;
        }

        $item['content'] = $this->read_file_excerpt($path, 400);
        $item['tail'] = $this->tail_file($path, 120);
        $item['entries'] = $this->parse_log_entries($path);
        $item['humanTitle'] = $this->build_human_title($item);
        $item['humanSummary'] = $this->build_human_summary($item, $item['entries']);

        return $item;
    }

    private function build_log_item(string $file, array $source): ?array
    {
        $basename = basename($file);
        $date = '';
        $prefix = '';

        if (preg_match('/^(\d{4}-\d{2}-\d{2})_(.*)\.logs$/', $basename, $matches)) {
            $date = $matches[1];
            $prefix = trim($matches[2]);
        }

        $analysis = $this->analyze_log_file($file, $prefix);

        return [
            'ref' => $this->encode_log_ref($file),
            'name' => $basename,
            'path' => $file,
            'sourceKey' => $source['key'],
            'sourceLabel' => $source['label'],
            'sourceFamily' => $source['family'],
            'date' => $date,
            'prefix' => $prefix !== '' ? $prefix : '(sans prefixe)',
            'size' => filesize($file) ?: 0,
            'modifiedAt' => date('Y-m-d H:i:s', (int) filemtime($file)),
            'preview' => $analysis['preview'],
            'logType' => $analysis['logType'],
            'channel' => $analysis['channel'],
            'statusHint' => $analysis['statusHint'],
            'humanLabel' => $this->build_human_label($analysis['logType'], $analysis['channel'], $analysis['statusHint']),
        ];
    }

    private function matches_source_filter(string $sourceKey, array $filters): bool
    {
        $filter = trim((string) ($filters['source'] ?? ''));
        return $filter === '' || $filter === $sourceKey;
    }

    private function discover_sources(): array
    {
        $sources = [];

        foreach ($this->discover_directories(ROOTPATH . 'drive/logs/services') as $directory) {
            $basename = basename($directory);
            $sources[] = [
                'key' => 'drive_' . $this->slugify($basename),
                'label' => $this->beautify_label($basename),
                'path' => $directory,
                'family' => 'drive',
            ];
        }

        usort($sources, static function (array $left, array $right): int {
            return strcmp($left['label'], $right['label']);
        });

        return $sources;
    }

    private function discover_directories(string $basePath): array
    {
        if (!is_dir($basePath)) {
            return [];
        }

        $directories = array_filter(glob($basePath . '/*') ?: [], 'is_dir');
        sort($directories, SORT_STRING);

        return array_values($directories);
    }

    private function slugify(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/', '_', $value) ?? $value;
        return trim($value, '_');
    }

    private function beautify_label(string $value): string
    {
        $value = str_replace(['_', '-'], ' ', trim($value));
        return ucwords($value);
    }

    private function matches_filters(array $item, array $filters): bool
    {
        $q = mb_strtolower(trim((string) ($filters['q'] ?? '')));
        if ($q !== '') {
            $haystack = mb_strtolower(implode(' ', [
                (string) ($item['name'] ?? ''),
                (string) ($item['prefix'] ?? ''),
                (string) ($item['sourceLabel'] ?? ''),
                (string) ($item['preview'] ?? ''),
            ]));

            if (!str_contains($haystack, $q)) {
                return false;
            }
        }

        $prefix = trim((string) ($filters['prefix'] ?? ''));
        if ($prefix !== '') {
            $itemPrefix = (string) ($item['prefix'] ?? '');
            if ($itemPrefix !== $prefix && trim($itemPrefix, '()') !== $prefix) {
                return false;
            }
        }

        $logType = trim((string) ($filters['log_type'] ?? ''));
        if ($logType !== '' && strtoupper((string) ($item['logType'] ?? '')) !== strtoupper($logType)) {
            return false;
        }

        $channel = trim((string) ($filters['channel'] ?? ''));
        if ($channel !== '' && strtoupper((string) ($item['channel'] ?? '')) !== strtoupper($channel)) {
            return false;
        }

        $statusHint = trim((string) ($filters['status_hint'] ?? ''));
        if ($statusHint !== '' && strtoupper((string) ($item['statusHint'] ?? '')) !== strtoupper($statusHint)) {
            return false;
        }

        $dateFrom = trim((string) ($filters['date_from'] ?? ''));
        if ($dateFrom !== '' && (string) ($item['date'] ?? '') < $dateFrom) {
            return false;
        }

        $dateTo = trim((string) ($filters['date_to'] ?? ''));
        if ($dateTo !== '' && (string) ($item['date'] ?? '') > $dateTo) {
            return false;
        }

        return true;
    }

    private function resolve_source_by_path(string $path): ?array
    {
        $realPath = realpath($path);
        if ($realPath === false) {
            return null;
        }

        foreach ($this->sources as $source) {
            $sourcePath = realpath($source['path']);
            if ($sourcePath !== false && str_starts_with($realPath, $sourcePath)) {
                return $source;
            }
        }

        return null;
    }

    private function encode_log_ref(string $path): string
    {
        return rtrim(strtr(base64_encode($path), '+/', '-_'), '=');
    }

    private function decode_log_ref(string $ref): ?string
    {
        $decoded = base64_decode(strtr($ref, '-_', '+/') . str_repeat('=', (4 - strlen($ref) % 4) % 4), true);
        if ($decoded === false) {
            return null;
        }

        return $this->resolve_source_by_path($decoded) !== null ? $decoded : null;
    }

    private function tail_preview(string $file): string
    {
        $tail = $this->tail_file($file, 8);
        $text = trim(implode(' ', $tail));
        $text = preg_replace('/\s+/', ' ', $text) ?? $text;

        return mb_substr($text, 0, 180) . (mb_strlen($text) > 180 ? '...' : '');
    }

    private function analyze_log_file(string $file, string $prefix): array
    {
        $preview = $this->tail_preview($file);
        $sample = $this->read_file_excerpt($file, 40);
        $haystack = strtoupper(trim($prefix . ' ' . $preview . ' ' . $sample));

        $logType = 'EVENT';
        if (str_contains($haystack, 'REQUEST') || str_contains($haystack, '<FIXML')) {
            $logType = 'REQUEST';
        }
        if (str_contains($haystack, 'RESPONSE') || str_contains($haystack, 'RESULTAT FINAL') || str_contains($haystack, '"RESPONSE"')) {
            $logType = 'RESPONSE';
        }
        if (str_contains($haystack, 'ERREUR') || str_contains($haystack, 'ERROR') || str_contains($haystack, 'EXCEPTION') || str_contains($haystack, 'MISSING')) {
            $logType = 'ERROR';
        }
        if (str_contains($haystack, 'DATA_RECEIVED') || str_contains($haystack, 'SIMULATION') || str_contains($haystack, 'DETAILS')) {
            $logType = 'DATA';
        }

        $channel = 'GENERAL';
        foreach ([
            'PASSPORT' => ['PASSPORT'],
            'PREPAYMENT' => ['PREPAYMENT'],
            'VIREMENT' => ['VIREMENT'],
            'RESERVATION' => ['RESERVATION', 'LIEN'],
            'ACCOUNT' => ['ACCOUNT_INFO', 'ACCOUNT'],
            'EXCHANGE_RATE' => ['EXCHANGE_RATE'],
            'VERIFICATION' => ['VERIFICATION', 'VERIFY_TRANSACTION'],
            'BULLETIN' => ['BULLETIN'],
        ] as $label => $needles) {
            foreach ($needles as $needle) {
                if (str_contains($haystack, $needle)) {
                    $channel = $label;
                    break 2;
                }
            }
        }

        $statusHint = 'UNKNOWN';
        if (str_contains($haystack, 'SUCCESS') || str_contains($haystack, '"CODE":200') || str_contains($haystack, '"RESPONSE":200')) {
            $statusHint = 'SUCCESS';
        }
        if (str_contains($haystack, 'ERREUR') || str_contains($haystack, 'ERROR') || str_contains($haystack, 'EXCEPTION') || str_contains($haystack, 'FAILED')) {
            $statusHint = 'ERROR';
        }

        return [
            'preview' => $preview,
            'logType' => $logType,
            'channel' => $channel,
            'statusHint' => $statusHint,
        ];
    }

    private function parse_log_entries(string $file): array
    {
        $content = @file_get_contents($file);
        if ($content === false || trim($content) === '') {
            return [];
        }

        $parts = preg_split('/(?=\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s*-+)/m', $content) ?: [];
        $entries = [];

        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }

            $timestamp = '';
            $body = $part;
            if (preg_match('/^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s*-+\s*(.*)$/s', $part, $matches)) {
                $timestamp = trim($matches[1]);
                $body = trim($matches[2]);
            }

            $entries[] = [
                'timestamp' => $timestamp,
                'body' => $body,
                'human_text' => $this->humanize_entry_body($body),
            ];
        }

        return $entries;
    }

    private function get_detected_channels(): array
    {
        $channels = [];
        foreach ($this->get_filtered_integration_logs([], 5000) as $row) {
            $channel = trim((string) ($row['channel'] ?? ''));
            if ($channel !== '') {
                $channels[$channel] = $channel;
            }
        }

        ksort($channels, SORT_STRING);

        return array_values($channels);
    }

    private function tail_file(string $file, int $tailLines): array
    {
        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        return is_array($lines) ? array_slice($lines, -max(1, $tailLines)) : [];
    }

    private function read_file_excerpt(string $file, int $maxLines): string
    {
        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        if (!is_array($lines)) {
            return '';
        }

        return implode(PHP_EOL, array_slice($lines, -max(1, $maxLines)));
    }

    private function build_human_label(string $logType, string $channel, string $statusHint): string
    {
        $typeLabel = match (strtoupper($logType)) {
            'REQUEST' => 'Requete envoyee',
            'RESPONSE' => 'Reponse recue',
            'ERROR' => 'Erreur detectee',
            'DATA' => 'Donnees techniques',
            default => 'Evenement technique',
        };

        $channelLabel = match (strtoupper($channel)) {
            'PASSPORT' => 'sur le canal passport',
            'PREPAYMENT' => 'sur le canal prepayment',
            'VIREMENT' => 'sur le canal virement',
            'RESERVATION' => 'sur le canal reservation',
            'ACCOUNT' => 'sur la consultation de compte',
            'EXCHANGE_RATE' => 'sur le taux de change',
            'VERIFICATION' => 'sur la verification',
            'BULLETIN' => 'sur le canal bulletin',
            default => 'sur le service CBS',
        };

        $statusLabel = match (strtoupper($statusHint)) {
            'SUCCESS' => 'avec un resultat positif',
            'ERROR' => 'avec un incident',
            default => 'avec un statut a verifier',
        };

        return trim($typeLabel . ' ' . $channelLabel . ' ' . $statusLabel . '.');
    }

    private function build_human_title(array $item): string
    {
        return match (strtoupper((string) ($item['logType'] ?? 'EVENT'))) {
            'REQUEST' => 'Requete CBS envoyee',
            'RESPONSE' => 'Reponse CBS recue',
            'ERROR' => 'Incident d integration CBS',
            'DATA' => 'Donnees d integration CBS',
            default => 'Activite d integration CBS',
        };
    }

    private function build_human_summary(array $item, array $entries): string
    {
        $summary = (string) ($item['humanLabel'] ?? '');
        $firstEntry = $entries[0]['human_text'] ?? '';

        if ($firstEntry !== '') {
            $summary .= ' ' . $firstEntry;
        }

        return trim($summary);
    }

    private function humanize_entry_body(string $body): string
    {
        $body = trim($body);
        if ($body === '') {
            return 'Aucun detail supplementaire.';
        }

        $json = json_decode($body, true);
        if (is_array($json)) {
            return $this->humanize_array($json);
        }

        if (str_starts_with($body, '<')) {
            return 'Un message XML technique a ete enregistre pour cette operation.';
        }

        $body = preg_replace('/\s+/', ' ', $body) ?? $body;
        $body = str_replace(['Resultat final:', 'Erreur des donnes invalides:', 'Erreur des données invalides:'], '', $body);
        $body = trim($body);

        return $body !== '' ? mb_substr($body, 0, 220) . (mb_strlen($body) > 220 ? '...' : '') : 'Detail technique disponible.';
    }

    private function humanize_array(array $payload): string
    {
        if (isset($payload['response']) && (string) $payload['response'] === '200') {
            return 'Le service indique un traitement abouti avec un code de retour 200.';
        }

        if (isset($payload['Header']['ResponseHeader']['HostTransaction']['Status'])) {
            $status = (string) $payload['Header']['ResponseHeader']['HostTransaction']['Status'];
            return 'Le CBS a retourne le statut ' . $status . '.';
        }

        if (isset($payload['Reference_32']) || isset($payload['Compte_33'])) {
            $reference = (string) ($payload['Reference_32'] ?? '');
            $account = (string) ($payload['Compte_33'] ?? '');
            return 'Des donnees de verification ont ete recues'
                . ($reference !== '' ? ' pour la reference ' . $reference : '')
                . ($account !== '' ? ' et le compte ' . $account : '')
                . '.';
        }

        if (isset($payload['code'])) {
            return 'Le log contient un code de retour ' . (string) $payload['code'] . '.';
        }

        return 'Des donnees structurees ont ete enregistrees pour cette operation CBS.';
    }
}
