<?php

namespace Modules\Logs\Models;

use Config\Database;

class MailLogsModel
{
    private \CodeIgniter\Database\BaseConnection $db;
    private string $table = 'logiref_email_logs';

    public function __construct()
    {
        $this->db = Database::connect('ikwook_logiref_main');
    }

    public function get_all_mail_logs(): array
    {
        if (!$this->db->tableExists($this->table)) {
            return [];
        }

        return $this->db->table($this->table)
            ->orderBy('Id', 'DESC')
            ->get()
            ->getResultArray();
    }

    public function get_filtered_mail_logs(array $filters = [], int $limit = 200): array
    {
        if (!$this->db->tableExists($this->table)) {
            return [];
        }

        $limit = max(1, min($limit, 1000));
        $builder = $this->apply_filters($this->db->table($this->table), $filters);

        return $builder
            ->orderBy('Id', 'DESC')
            ->limit($limit)
            ->get()
            ->getResultArray();
    }

    public function get_mail_logs_summary(array $filters = []): array
    {
        if (!$this->db->tableExists($this->table)) {
            return [
                'total' => 0,
                'sent' => 0,
                'delivered' => 0,
                'undelivered' => 0,
                'failed' => 0,
                'pending' => 0,
            ];
        }

        $builder = $this->apply_filters($this->db->table($this->table), $filters);
        $rows = $builder
            ->select('Status_8, COUNT(*) as total')
            ->groupBy('Status_8')
            ->get()
            ->getResultArray();

        $summary = [
            'total' => 0,
            'sent' => 0,
            'delivered' => 0,
            'undelivered' => 0,
            'failed' => 0,
            'pending' => 0,
        ];

        foreach ($rows as $row) {
            $count = (int) ($row['total'] ?? 0);
            $status = strtoupper(trim((string) ($row['Status_8'] ?? 'PENDING')));
            $summary['total'] += $count;

            if ($status === 'SENT') {
                $summary['sent'] += $count;
            } elseif ($status === 'DELIVERED') {
                $summary['delivered'] += $count;
            } elseif ($status === 'UNDELIVERED') {
                $summary['undelivered'] += $count;
            } elseif ($status === 'FAILED') {
                $summary['failed'] += $count;
            } else {
                $summary['pending'] += $count;
            }
        }

        return $summary;
    }

    public function get_filter_options(): array
    {
        if (!$this->db->tableExists($this->table)) {
            return [
                'statuses' => [],
                'providers' => [],
                'modules' => [],
            ];
        }

        return [
            'statuses' => $this->get_distinct_values('Status_8'),
            'providers' => $this->get_distinct_values('Provider_6'),
            'modules' => $this->get_distinct_values('Module_1'),
        ];
    }

    public function get_mail_log_by_id(int $id): ?array
    {
        if (!$this->db->tableExists($this->table)) {
            return null;
        }

        $row = $this->db->table($this->table)
            ->where('Id', $id)
            ->get()
            ->getRowArray();

        return $row ?: null;
    }

    public function get_infobip_cli_logs(int $tailLines = 50): array
    {
        $logDir = ROOTPATH . 'drive/logs/logiref/cli/spark';
        if (!is_dir($logDir)) {
            return [];
        }

        $files = glob($logDir . '/*infobip_email_reports*.logs') ?: [];
        rsort($files, SORT_STRING);

        $items = [];
        foreach ($files as $file) {
            if (!is_file($file)) {
                continue;
            }

            $items[] = [
                'name' => basename($file),
                'path' => $file,
                'size' => filesize($file) ?: 0,
                'modifiedAt' => date('c', (int) filemtime($file)),
                'tail' => $this->tail_file($file, $tailLines),
            ];
        }

        return $items;
    }

    private function tail_file(string $file, int $tailLines): array
    {
        $tailLines = max(1, $tailLines);
        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        if (!is_array($lines)) {
            return [];
        }

        return array_slice($lines, -$tailLines);
    }

    private function apply_filters(\CodeIgniter\Database\BaseBuilder $builder, array $filters): \CodeIgniter\Database\BaseBuilder
    {
        $status = trim((string) ($filters['status'] ?? ''));
        $provider = trim((string) ($filters['provider'] ?? ''));
        $module = trim((string) ($filters['module'] ?? ''));
        $recipient = trim((string) ($filters['recipient'] ?? ''));
        $reference = trim((string) ($filters['reference'] ?? ''));
        $messageId = trim((string) ($filters['message_id'] ?? ''));
        $dateFrom = trim((string) ($filters['date_from'] ?? ''));
        $dateTo = trim((string) ($filters['date_to'] ?? ''));
        $q = trim((string) ($filters['q'] ?? ''));

        if ($status !== '') {
            $builder->where('Status_8', $status);
        }

        if ($provider !== '') {
            $builder->where('Provider_6', $provider);
        }

        if ($module !== '') {
            $builder->where('Module_1', $module);
        }

        if ($recipient !== '') {
            $builder->like('RecipientEmail_3', $recipient);
        }

        if ($reference !== '') {
            $builder->like('Reference_2', $reference);
        }

        if ($messageId !== '') {
            $builder->like('ProviderMessageId_7', $messageId);
        }

        if ($dateFrom !== '') {
            $builder->where('DATE(COALESCE(SentAt_11, CreatedAt_12)) >=', $dateFrom);
        }

        if ($dateTo !== '') {
            $builder->where('DATE(COALESCE(SentAt_11, CreatedAt_12)) <=', $dateTo);
        }

        if ($q !== '') {
            $builder->groupStart()
                ->like('RecipientEmail_3', $q)
                ->orLike('Subject_4', $q)
                ->orLike('Reference_2', $q)
                ->orLike('ProviderMessageId_7', $q)
                ->orLike('ErrorMessage_9', $q)
                ->groupEnd();
        }

        return $builder;
    }

    private function get_distinct_values(string $field): array
    {
        $rows = $this->db->table($this->table)
            ->select($field)
            ->where($field . ' IS NOT NULL', null, false)
            ->where($field . ' !=', '')
            ->groupBy($field)
            ->orderBy($field, 'ASC')
            ->get()
            ->getResultArray();

        return array_values(array_filter(array_map(
            static fn (array $row): string => trim((string) ($row[$field] ?? '')),
            $rows
        ), static fn (string $value): bool => $value !== ''));
    }
}
