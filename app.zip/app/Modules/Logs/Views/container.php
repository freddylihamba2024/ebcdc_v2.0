<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper" style="min-height: 100vh">
    <div class="w-100 d-flex justify-content-center align-items-center mt-3"></div>
    <div class="container-fluid" id="container" style="margin-top: 30px"></div>
</div>

<script>
    $(function () {
        var displayUrl = <?php echo json_encode($logs_display_url ?? base_url('monitoring/logs/mails/display')); ?>;
        var queryString = <?php echo json_encode($logs_query_string ?? ''); ?>;
        var targetUrl = displayUrl + (queryString ? ('?' + queryString) : '');

        $("#container").load(targetUrl);
    });
</script>
