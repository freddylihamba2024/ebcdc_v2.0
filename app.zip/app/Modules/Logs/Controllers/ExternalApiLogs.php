<?php

namespace Modules\Logs\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use Modules\Logs\Models\ExternalApiLogsModel;

class ExternalApiLogs extends BaseController
{
    private ExternalApiLogsModel $externalApiLogsModel;

    public function __construct()
    {
        $this->externalApiLogsModel = new ExternalApiLogsModel();
    }

    public function index(): ResponseInterface
    {
        return $this->response->setJSON([
            'status' => 'success',
            'type' => 'external_api_logs',
            'data' => $this->externalApiLogsModel->get_all_external_api_logs(),
        ]);
    }
}
