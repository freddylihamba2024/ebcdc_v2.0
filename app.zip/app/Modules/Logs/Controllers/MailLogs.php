<?php

namespace Modules\Logs\Controllers;

use App\Controllers\BaseController;
use App\Libraries\MailLib;
use CodeIgniter\HTTP\ResponseInterface;
use Modules\Logs\Models\MailLogsModel;

class MailLogs extends BaseController
{
    public string $module = 'logs';
    public string $folder = 'mail_logs';
    public string $group = 'banks';
    private MailLogsModel $mailLogsModel;

    public function __construct()
    {
        parent::__construct();
        $this->mailLogsModel = new MailLogsModel();
        $this->data['module'] = $this->module;
        $this->data['application'] = 'mail_logs';
        $this->data['function'] = '';
        $this->data['folder'] = $this->folder;
        $this->data['group'] = $this->group;
        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
        $this->data['deny'] = false;
        $this->data['sidebar'] = isset($_SESSION['Logiref_role'])
            ? $this->sidebars->admin_logiref()
            : '';
    }

    public function index()
    {
        $this->data['subview'] = '\Modules\Logs\Views\container';
        $this->data['logs_display_url'] = base_url('monitoring/logs/mails/display');
        $this->data['logs_query_string'] = (string) $this->request->getServer('QUERY_STRING');

        echo view('layouts/layout_main', $this->data);
    }

    public function display($obj = null)
    {
        $obj = $obj ?? 'mails';

        if ($obj === 'mails') {
            $filters = $this->resolve_filters();
            $limit = (int) ($this->request->getGet('limit') ?? 200);

            echo view('\Modules\Logs\Views\\' . $this->folder . '\index', [
                'title' => 'Logs des mails',
                'chtml' => $this->chtml,
                'filters' => $filters,
                'summary' => $this->mailLogsModel->get_mail_logs_summary($filters),
                'filterOptions' => $this->mailLogsModel->get_filter_options(),
                'databaseLogs' => $this->mailLogsModel->get_filtered_mail_logs($filters, $limit),
                'limit' => $limit,
                'jsonUrl' => base_url('monitoring/logs/mails'),
                'detailBaseUrl' => base_url('monitoring/logs/mails'),
                'displayUrl' => base_url('monitoring/logs/mails/display'),
            ]);

            return;
        }

        if ($obj === 'deny') {
            $this->data['denied'] = true;
            $this->data['country'] = $this->session->userdata['account_country'] ?? '';
            echo view('\Modules\Branch\Views\fr_denial', $this->data);
        }
    }

    public function data($obj = null, $id = null): ResponseInterface
    {
        if (($obj ?? '') === 'filter') {
            $filters = $this->resolve_filters();
            $limit = (int) ($this->request->getGet('limit') ?? 200);

            return $this->response->setBody(view('\Modules\Logs\Views\\' . $this->folder . '\_filter', [
                'databaseLogs' => $this->mailLogsModel->get_filtered_mail_logs($filters, $limit),
                'detailBaseUrl' => base_url('monitoring/logs/mails'),
            ]));
        }

        if (($obj ?? '') === 'mails') {
            $filters = $this->resolve_filters();
            $limit = (int) ($this->request->getGet('limit') ?? 200);

            return $this->response->setJSON([
                'status' => 'success',
                'type' => 'mail_logs',
                'filters' => $filters,
                'summary' => $this->mailLogsModel->get_mail_logs_summary($filters),
                'database_logs' => $this->mailLogsModel->get_filtered_mail_logs($filters, $limit),
            ]);
        }

        if (($obj ?? '') === 'mail' && $id !== null) {
            return $this->show((int) $id);
        }

        return $this->response->setStatusCode(404)->setJSON([
            'status' => 'failed',
            'message' => 'Logs data not found.',
        ]);
    }

    public function show(int $id): ResponseInterface
    {
        $log = $this->mailLogsModel->get_mail_log_by_id($id);
        if ($log === null) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON([
                    'status' => 'failed',
                    'message' => 'Mail log not found.',
                ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'type' => 'mail_log_detail',
            'data' => $log,
        ]);
    }

    public function resend(int $id): ResponseInterface
    {
        $log = $this->mailLogsModel->get_mail_log_by_id($id);
        if ($log === null) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'failed',
                'message' => 'Mail log not found.',
            ]);
        }

        $status = strtoupper(trim((string) ($log['Status_8'] ?? '')));
        $attachment_path = (string) ($log['AttachmentPath_16'] ?? '');

        if (!in_array($status, ['FAILED', 'UNDELIVERED'], true)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'failed',
                'message' => 'Only FAILED or UNDELIVERED mails can be resent.',
            ]);
        }

        if ($attachment_path === '' || !is_file($attachment_path) || !is_readable($attachment_path)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'failed',
                'message' => 'Attachment file is missing or unreadable.',
            ]);
        }

        $mail_lib = new MailLib();
        $result = $mail_lib->resend_logged_mail($log);

        return $this->response->setJSON([
            'status' => !empty($result['ok']) ? 'success' : 'failed',
            'message' => !empty($result['ok'])
                ? 'Mail resend launched successfully.'
                : ($result['message'] ?? 'Unable to resend this mail.'),
            'data' => $result,
        ]);
    }

    private function resolve_filters(): array
    {
        $date_from = trim((string) $this->request->getGet('date_from'));
        $date_to = trim((string) $this->request->getGet('date_to'));

        if ($date_from === '' && $date_to === '') {
            $date_from = date('Y-m-d');
            $date_to = date('Y-m-d');
        }

        return [
            'q' => trim((string) $this->request->getGet('q')),
            'status' => trim((string) $this->request->getGet('status')),
            'provider' => trim((string) $this->request->getGet('provider')),
            'module' => trim((string) $this->request->getGet('module')),
            'recipient' => trim((string) $this->request->getGet('recipient')),
            'reference' => trim((string) $this->request->getGet('reference')),
            'message_id' => trim((string) $this->request->getGet('message_id')),
            'date_from' => $date_from,
            'date_to' => $date_to,
        ];
    }
}
