<?php

namespace Modules\Logs\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use Modules\Logs\Models\IntegrationLogsModel;

class IntegrationLogs extends BaseController
{
    public string $module = 'logs';
    public string $folder = 'integration_logs';
    public string $group = 'banks';
    private IntegrationLogsModel $integrationLogsModel;

    public function __construct()
    {
        parent::__construct();
        $this->integrationLogsModel = new IntegrationLogsModel();
        $this->data['module'] = $this->module;
        $this->data['application'] = 'integration_logs';
        $this->data['function'] = '';
        $this->data['folder'] = $this->folder;
        $this->data['group'] = $this->group;
        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
        $this->data['deny'] = false;
        $this->data['sidebar'] = isset($_SESSION['Logiref_role']) ? $this->sidebars->admin_logiref() : '';
    }

    public function index()
    {
        $this->data['subview'] = '\Modules\Logs\Views\container';
        $this->data['logs_display_url'] = base_url('monitoring/logs/integrations/display');
        $this->data['logs_query_string'] = (string) $this->request->getServer('QUERY_STRING');

        echo view('layouts/layout_main', $this->data);
    }

    public function display($obj = null)
    {
        if (($obj ?? 'finacle') !== 'finacle') {
            return;
        }

        $filters = $this->resolve_filters();
        $limit = (int) ($this->request->getGet('limit') ?? 200);

        echo view('\Modules\Logs\Views\\' . $this->folder . '\index', [
            'chtml' => $this->chtml,
            'filters' => $filters,
            'summary' => $this->integrationLogsModel->get_summary($filters),
            'filterOptions' => $this->integrationLogsModel->get_filter_options(),
            'logs' => $this->integrationLogsModel->get_filtered_integration_logs($filters, $limit),
            'shouldShowLogs' => $this->should_show_logs($filters),
            'limit' => $limit,
            'displayUrl' => base_url('monitoring/logs/integrations/display'),
        ]);
    }

    public function data($obj = null): ResponseInterface
    {
        $filters = $this->resolve_filters();
        $limit = (int) ($this->request->getGet('limit') ?? 200);

        if (($obj ?? '') === 'filter') {
            return $this->response->setBody(view('\Modules\Logs\Views\\' . $this->folder . '\_filter', [
                'logs' => $this->integrationLogsModel->get_filtered_integration_logs($filters, $limit),
                'filters' => $filters,
                'shouldShowLogs' => $this->should_show_logs($filters),
            ]));
        }

        return $this->response->setJSON([
            'status' => 'success',
            'summary' => $this->integrationLogsModel->get_summary($filters),
            'data' => $this->integrationLogsModel->get_filtered_integration_logs($filters, $limit),
        ]);
    }

    public function show(string $ref): ResponseInterface
    {
        $detail = $this->integrationLogsModel->get_log_detail($ref);
        if ($detail === null) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'failed',
                'message' => 'Integration log file not found.',
            ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $detail,
        ]);
    }

    private function resolve_filters(): array
    {
        return [
            'q' => trim((string) $this->request->getGet('q')),
            'source' => trim((string) $this->request->getGet('source')),
            'prefix' => trim((string) $this->request->getGet('prefix')),
            'log_type' => trim((string) $this->request->getGet('log_type')),
            'channel' => trim((string) $this->request->getGet('channel')),
            'status_hint' => trim((string) $this->request->getGet('status_hint')),
            'date_from' => trim((string) $this->request->getGet('date_from')),
            'date_to' => trim((string) $this->request->getGet('date_to')),
        ];
    }

    private function should_show_logs(array $filters): bool
    {
        return trim((string) ($filters['source'] ?? '')) !== ''
            || trim((string) ($filters['q'] ?? '')) !== ''
            || trim((string) ($filters['prefix'] ?? '')) !== ''
            || trim((string) ($filters['log_type'] ?? '')) !== ''
            || trim((string) ($filters['channel'] ?? '')) !== ''
            || trim((string) ($filters['status_hint'] ?? '')) !== ''
            || trim((string) ($filters['date_from'] ?? '')) !== ''
            || trim((string) ($filters['date_to'] ?? '')) !== '';
    }
}
