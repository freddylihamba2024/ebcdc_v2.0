<?php

namespace Modules\Logs\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use Modules\Logs\Models\PaymentIssuesModel;

class PaymentIssues extends BaseController
{
    public string $module = 'logs';
    public string $folder = 'payment_issues';
    public string $group = 'banks';
    private PaymentIssuesModel $paymentIssuesModel;

    public function __construct()
    {
        parent::__construct();
        $this->paymentIssuesModel = new PaymentIssuesModel();
        $this->data['module'] = $this->module;
        $this->data['application'] = 'payment_issues';
        $this->data['function'] = '';
        $this->data['folder'] = $this->folder;
        $this->data['group'] = $this->group;
        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
        $this->data['deny'] = false;
        $this->data['sidebar'] = isset($_SESSION['Logiref_role']) ? $this->sidebars->admin_logiref() : '';
    }

    public function index()
    {
        $this->data['subview'] = '\Modules\Logs\Views\container';
        $this->data['logs_display_url'] = base_url('monitoring/logs/payment-issues/display');
        $this->data['logs_query_string'] = (string) $this->request->getServer('QUERY_STRING');

        echo view('layouts/layout_main', $this->data);
    }

    public function display($obj = null)
    {
        if (($obj ?? 'issues') !== 'issues') {
            return;
        }

        $filters = $this->resolve_filters();
        $limit = (int) ($this->request->getGet('limit') ?? 200);

        echo view('\Modules\Logs\Views\\' . $this->folder . '\index', [
            'chtml' => $this->chtml,
            'filters' => $filters,
            'summary' => $this->paymentIssuesModel->get_issues_summary($filters),
            'filterOptions' => $this->paymentIssuesModel->get_filter_options(),
            'databaseIssues' => $this->paymentIssuesModel->get_filtered_issues($filters, $limit),
            'realtimeLogs' => $this->paymentIssuesModel->get_issue_realtime_logs(),
            'statusOptions' => $this->paymentIssuesModel->get_status_options(),
            'priorityOptions' => $this->paymentIssuesModel->get_priority_options(),
            'assignableUsers' => $this->paymentIssuesModel->get_assignable_users(),
            'limit' => $limit,
            'displayUrl' => base_url('monitoring/logs/payment-issues/display'),
        ]);
    }

    public function data($obj = null): ResponseInterface
    {
        $filters = $this->resolve_filters();
        $limit = (int) ($this->request->getGet('limit') ?? 200);

        if (($obj ?? '') === 'filter') {
            return $this->response->setBody(view('\Modules\Logs\Views\\' . $this->folder . '\_filter', [
                'databaseIssues' => $this->paymentIssuesModel->get_filtered_issues($filters, $limit),
            ]));
        }

        return $this->response->setJSON([
            'status' => 'success',
            'summary' => $this->paymentIssuesModel->get_issues_summary($filters),
            'database_issues' => $this->paymentIssuesModel->get_filtered_issues($filters, $limit),
            'realtime_logs' => $this->paymentIssuesModel->get_issue_realtime_logs(),
        ]);
    }

    public function show(int $id): ResponseInterface
    {
        $ticket = $this->paymentIssuesModel->get_issue_ticket($id);
        if ($ticket === null) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'failed',
                'message' => 'Payment issue not found.',
            ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $ticket,
        ]);
    }

    public function update_ticket(int $id): ResponseInterface
    {
        $payload = [
            'status' => (string) $this->request->getPost('status'),
            'priority' => (string) $this->request->getPost('priority'),
            'assigned_user_id' => (string) $this->request->getPost('assigned_user_id'),
            'resolution_note' => (string) $this->request->getPost('resolution_note'),
            'note' => (string) $this->request->getPost('note'),
        ];

        $result = $this->paymentIssuesModel->update_issue_ticket($id, $payload, $this->resolve_actor());

        return $this->response->setStatusCode(!empty($result['ok']) ? 200 : 400)->setJSON([
            'status' => !empty($result['ok']) ? 'success' : 'failed',
            'message' => $result['message'] ?? 'Unable to update ticket.',
            'data' => $result,
        ]);
    }

    public function add_comment(int $id): ResponseInterface
    {
        $result = $this->paymentIssuesModel->add_issue_comment(
            $id,
            (string) $this->request->getPost('comment'),
            $this->resolve_actor()
        );

        return $this->response->setStatusCode(!empty($result['ok']) ? 200 : 400)->setJSON([
            'status' => !empty($result['ok']) ? 'success' : 'failed',
            'message' => $result['message'] ?? 'Unable to add comment.',
            'data' => $result,
        ]);
    }

    private function resolve_filters(): array
    {
        return [
            'q' => trim((string) $this->request->getGet('q')),
            'status' => trim((string) $this->request->getGet('status')),
            'severity' => trim((string) $this->request->getGet('severity')),
            'priority' => trim((string) $this->request->getGet('priority')),
            'stage' => trim((string) $this->request->getGet('stage')),
            'channel' => trim((string) $this->request->getGet('channel')),
            'module' => trim((string) $this->request->getGet('module')),
            'reference' => trim((string) $this->request->getGet('reference')),
            'customer_email' => trim((string) $this->request->getGet('customer_email')),
            'assigned_user' => trim((string) $this->request->getGet('assigned_user')),
            'date_from' => trim((string) $this->request->getGet('date_from')),
            'date_to' => trim((string) $this->request->getGet('date_to')),
        ];
    }

    private function resolve_actor(): array
    {
        $userId = (string) ($_SESSION['userdata']['user_id'] ?? $_SESSION['Logiref_user'] ?? 'SYSTEM');
        $name = (string) ($_SESSION['userdata']['user_name'] ?? $userId);
        $email = (string) ($_SESSION['userdata']['email'] ?? '');

        return [
            'code' => $userId !== '' ? $userId : 'SYSTEM',
            'name' => $name !== '' ? $name : 'System',
            'email' => $email,
        ];
    }
}
