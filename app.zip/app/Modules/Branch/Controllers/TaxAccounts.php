<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\CurlModel;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

class TaxAccounts extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Alvin on the 28.08.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('comptes', 'prepayments', 'dashboard');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'accounts';
        public $data = [];
        public $mainModal;
        public $accountModel;
        public $logirefModel;
        public $branchModel;
        public $userModel;
        public $stakeholderModel;

        public $prepaymentsModel;
        public $curlModel;
        public $bank;
        public $options;
        public $core_banking;
        public $temenos;
        public $amplitude;
        public $synergies;
        public $igor;
        public $bsqr;
        public $finacle;
        public $finacle_standardbank;
        public $amplitude_solidairebanque;
        public $fibridge;
        public $integrationModel;
        public $flexcube;
        public $comptabilisation;
        public $cyclone;
        public $temenoscrdb;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModal = new MainModel();
                $this->accountModel = new AccountModel();
                $this->logirefModel = new LogirefModel();
                $this->branchModel = new BranchModel();
                $this->userModel = new UserModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->integrationModel = new IntegrationModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->curlModel = new CurlModel();
                $this->synergies = new Synergies();
                $this->amplitude = new Amplitude();
                $this->igor = new Igor();
                $this->bsqr = new Bsqr();
                $this->finacle = new Finacle();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->comptabilisation = new Comptabilisation();
                $this->cyclone = new Cyclone();
                $this->temenoscrdb = new TemenosCrdb();


                $this->folder = 'accounts';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxaccounts';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['usertype'] = $this->session->userdata["user_type"];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];
                $this->data['deny'] = false;

                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank_uppercase = ucfirst($this->bank);
                }

                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if(isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
        }

	public function index()
	{
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}


        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }


        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['agences'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['comptes'] = $this->accountModel->get_comptes("cptes");

                                $this->data['lastestComptes'] = $this->accountModel->get_latest_validated_accounts();
                        } else {
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                                $this->data['comptes'] = $this->accountModel->get_comptes();
                        }
                        echo view('\Modules\Branch\Views\accounts\comptes', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/comptes', $this->data);
                }
                elseif ($obj == "filter")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountModel->get_filtered_accounts($_POST);
                        echo view('\Modules\Branch\Views\accounts\_comptes', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_comptes', $this->data);
                } 
                elseif ($obj == "compte") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['service_types'] =$this->accountModel->type_service;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['services_direction'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['banque'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['compte'] = $this->accountModel->get_compte_info($id);
                        $this->data['banques'] = $this->accountModel->get_dropdown("beneficiaire");
                        #var_dump($this->data['beneficiaire']);die;
                        echo view('\Modules\Branch\Views\accounts\_compte', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_compte', $this->data);
                } 
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "compte")
                {
                        #Save compte
                        # Validate compte form

                        if ($_POST['Compte_6'] == '0' || $_POST['Compte_6'] == ''  || $_POST['Devise_8'] == ''  || ($_POST['Beneficiaires1'] == '' && $_POST['Beneficiaires2'] == '' && $_POST['Beneficiaires3'] == '')  || $_POST['Type_4'] == '') 
                        {
                                echo '<div class="w-100 alert alert-danger">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        }

                        if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '')
                        {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Makerid_9'] = $this->session->userdata['user_id'];
                                //$data['Checkerid_11'] = $this->session->userdata['user_id'];
                        }

                        if ($_SESSION['Logiref_role'] == 1)
                        {

                                $data['Type_4'] = $_POST['Type_4'];

                                if ($data['Type_4'] === "CPI" || $data['Type_4'] === "CPB" || $data['Type_4'] === "CPO" || $data['Type_4'] === "CFC" || $data['Type_4'] === "CTC") 
                                {
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires1'];
                                }
                                elseif ($data['Type_4'] === "CPT" || $data['Type_4'] === "CGU" || $data['Type_4'] === "CSC") 
                                {
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires3'];
                                }
                                else
                                {
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires2'];
                                }

                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '')
                                {

                                        $devise = $this->request->getPost("Devise_8");
                                        $type = $this->request->getPost("Type_4");
                                        $agence = $this->request->getPost("agence");
                                        $compte = $this->request->getPost("Compte_6");

                                        $beneficiaire = $data['Beneficiaires_5'];
                                        $recette = $service  = NULL;

                                        if ($agence == "" || $agence == '0')
                                        {
                                                echo '<div class="w-100 alert alert-warning">Vous devez s&eacute;l&eacute;ctionner une agance !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;

                                        }

                                        if (isset($_POST['service']) && $_POST['service'] != "") $service = $this->request->getPost("service");
                                        elseif(isset($_POST['service_dir1']) && $_POST['service_dir1'] != "") $service = $this->request->getPost("service_dir1");
                                        elseif(isset($_POST['service_dir2']) && $_POST['service_dir2'] != "") $service = $this->request->getPost("service_dir2");
                                        elseif(isset($_POST['service_dir3']) && $_POST['service_dir3'] != "") $service = $this->request->getPost("service_dir3");

                                        if (isset($_POST['recette']) && $_POST['recette'] == "") $recette = $this->request->getPost("recette");
                                        elseif(isset($_POST['recette1']) && $_POST['recette1'] != "") $recette = $this->request->getPost("recette1");
                                        elseif(isset($_POST['recette2']) && $_POST['recette2'] != "") $recette = $this->request->getPost("recette2");
                                        elseif(isset($_POST['recette3']) && $_POST['recette3'] != "") $recette = $this->request->getPost("recette3");

                                        $comptes = $this->accountModel->get_comptes_by_parameters($compte, $devise, $type, $beneficiaire, $agence, $recette, $service);

                                        if (!empty($comptes))
                                        {
                                                echo '<div class="w-100 alert alert-danger">D&eacute;sol&eacute;, il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                }

                                if (isset($_POST['nivellement']) && $_POST['nivellement'] != "") $data['Nivellement_20 '] = $_POST['nivellement'];
                                if (isset($_POST['banque']) && $_POST['banque'] != "") $data['Bank_21'] = $_POST['banque'];

                                #Optional keys
                                $data['Compte_6'] = $_POST['Compte_6'];

                                #Devise par defaut
                                if ($data['Type_4'] == 'CPU') $data['Devise_8'] = 'USD';
                                elseif ($data['Type_4'] == 'TVA') $data['Devise_8'] = 'CDF';
                                #elseif($data['Type_4']=='CFB') $data['Devise_8']= 'CDF';
                                elseif ($data['Type_4'] == 'CCV') $data['Devise_8'] = 'CDF';
                                else $data['Devise_8'] = $_POST['Devise_8'];
                                #Validation section

                                if (isset($_POST['agence']))
                                {
                                        $data['Agence_12'] = $_POST['agence'];
                                }

                                if (isset($_POST['recette']) && $_POST['recette'] != "") $data['Recette_13'] = $_POST['recette'];
                                if (isset($_POST['recette1']) && $_POST['recette1'] != "") $data['Recette_13'] = $_POST['recette1'];
                                if (isset($_POST['recette2']) && $_POST['recette2'] != "") $data['Recette_13'] = $_POST['recette2'];
                                if (isset($_POST['recette3']) && $_POST['recette3'] != "") $data['Recette_13'] = $_POST['recette3'];

                                if(isset($_POST['service1']) && $_POST['service1'] != "")
                                {
                                        if($_POST['Beneficiaires3'] == "DGI")
                                        {
                                                $data['Category_22'] = $_POST['service1'];
                                        }
                                }

                                if (isset($_POST['service']) && $_POST['service'] != "") $data['Serviceid_16'] = $_POST['service'];
                                if (isset($_POST['service_dir1']) && $_POST['service_dir1'] != "") $data['Serviceid_16'] = $_POST['service_dir1'];
                                if (isset($_POST['service_dir2']) && $_POST['service_dir2'] != "") $data['Serviceid_16'] = $_POST['service_dir2'];
                                if (isset($_POST['service_dir3']) && $_POST['service_dir3'] != "") $data['Serviceid_16'] = $_POST['service_dir3'];

                                if (isset($_POST['nif']) && $_POST['nif'] != "")  $data['Nif_17'] = $_POST['nif'];
                                if (isset($_POST['comptesydonia']) && $_POST['comptesydonia'] != "") $data['Comptesydonia_18'] = $_POST['comptesydonia'];
                                if (isset($_POST['clt']) && $_POST['clt'] != "") $data['Numimportateur_19'] = $_POST['clt'];

                                $data['Agenceid_15'] = $_POST['Agenceid_15'];

                                $data['Validation_10'] = '0000-00-00';
                                $data['Checkerid_11']=0;
                        }
                        else
                        {
                                $data['Validation_10'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11'] = $this->session->userdata['user_id'];
                        }

                        #Database
                        $cid = $this->accountModel->save_compte($data, $id);
                        if ($cid) :
                                echo '<div class="w-100 alert alert-success">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "OBJ ")
                {

                }
        }


        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "get_users")
                {
                        $members = $this->userModel->get_members();
                        $type = $this->session->userdata['user_type'];

                        if (empty($members) && $type == 200) {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Role_4'] = 3;
                                $data['Province_5'] = 0;
                                $data['Ville_6'] = 0;
                                $data['Agence_7'] = 0;
                                $data['Guichet_8'] = 0;
                                $data['Privileges_10'] = 0;
                                $data['Regies_11'] = '';
                                $data['Code_12'] = 0;
                                $data['Userid_13'] = $this->session->userdata['user_id'];
                                $cid = $this->userModel->save_users($data, NULL);
                                if ($cid) $members = $this->userModel->get_members();
                        }
                        return $members;
                }
                elseif ($obj == "get_accountname")
                {
                        $data = array();

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        if($core_banking == 'igor')
                        {
                                # Extraire les 11 digits dans la chaine
                                $compte = explode('-', $_POST['compte']);

                                $data['Compte_33'] = isset($compte[1]) ? $compte[1] : '';
                                $data['Devise_34'] = $_POST['devise'];
                        }
                        else
                        {
                                $data['Compte_33'] = $_POST['compte'];
                                $data['Devise_34'] = $_POST['devise'];
                                $data['agence'] = $_SESSION['Guichet_code'];
                                $data['account_id'] = $_SESSION['userdata']['account_id'] ?? null;
                        }

                        $return = $this->{$core_banking}->account_info($data);

                        if(isset($return['code']) && $return['code'] == '404' || $return['code'] == '406' || $return['code'] == '405')
                        {
                                echo json_encode($return);
                        }
                        else
                        {
                                if(isset($return['account_name']) && $return['account_name'] != "")
                                {
                                        $return = json_encode($return);

                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo '404';
                                }
                        }
                }
                elseif ($obj == "get_customeraccounts")
                {
                        $data = array();

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        $data['customerNumber'] = $_POST['customer_number'];

                        $return = $this->{$core_banking}->customer_accounts($data);

                        if(isset($return['code']) && $return['code'] == '404' || $return['code'] == '406' || $return['code'] == '405')
                        {
                                echo json_encode($return);
                        }
                        else
                        {
                                if (isset($return[0]['accountNumber']) && $return[0]['accountNumber'] != '')
                                {
                                        $return = json_encode($return);

                                        # return data in json format.
                                        echo $return;
                                }
                                else
                                {
                                        echo '404';
                                }
                        }
                }
                elseif ($obj == "get_accountinternal")
                {
                        $return = [];

                        $agence = $_SESSION['Logiref_guichet'];
                        $devise = isset($_POST['devise']) ? $_POST['devise'] : "";
                        $beneficiary = isset($_POST['regie']) ? $_POST['regie'] : "";

                        $comptes = $this->comptabilisation->get_comptes_array_for_banks("'MAD'", "'$beneficiary'", $agence, $devise);

                        if (!empty($comptes))
                        {
                                $return['account'] = isset($comptes['MAD']["account"]) ? $comptes['MAD']["account"] : "";
                                $return['currency'] = isset($comptes['MAD']["currency"]) ? $comptes['MAD']["currency"] : "";

                                $return = json_encode($return);

                                # return data in json format : account, devise.
                                echo $return;
                        }
                        else
                        {
                                echo '405';
                        }
                }
                elseif($obj == "get_accountname_internal")
                {
                        $data = array();
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Devise_34'] = $_POST['devise'];
                        $data['agence'] = $_SESSION['Guichet_code'];

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        $return = $this->{$core_banking}->account_internal_info($data);

                        if(isset($return['code']) && $return['code'] == '404' || $return['code'] == '406' || $return['code'] == '405')
                        {
                                echo json_encode($return);
                        }
                        else
                        {
                                if(isset($return) && $return != "")
                                {
                                        $reponse_tax = $this->{$core_banking}->tax_exempt($data);

                                        $response['account_name'] = $return['account_name'];
                                        $response['currency'] = $return['currency'];
                                        $response['tax_info'] = $reponse_tax['code'];

                                        $return = json_encode($response);

                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo '405';
                                }
                        }
                }
                elseif ($obj == "get_account_balance")
                {
                        if (isset($_POST['montant']) && isset($_POST['commission']) && isset($_POST['compte']) && isset($_POST['devise'])) 
                        {

                                // Relire le solde fictif : le formulaire peut conserver une ancienne valeur.
                                if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                        && \Modules\Services\Temenos\Crdbbank\Helpers\SimulationHelper::enabled()) {
                                        $simulatedAccount = (new \Modules\Services\Temenos\Crdbbank\Helpers\TemenosApiHelper())->request(
                                                'account',
                                                ['AccountId' => (string) $_POST['compte']],
                                                null,
                                                ['currency' => $_POST['devise_compte'] ?? '']
                                        );
                                        $simulatedBalance = $simulatedAccount['data']['AvailableBalance'] ?? null;
                                        if (!empty($simulatedAccount['error']) || !is_numeric($simulatedBalance)) {
                                                echo '411';
                                                return;
                                        }
                                        $_POST['balance'] = $simulatedBalance;
                                }

                                if(isset($_POST['balance']) && ($_POST['balance'] != "" || !empty($_POST['balance']))) 
                                {

                                        $amount = str_replace(' ', '', $_POST['montant']);
                                        $amount = str_replace(',', '.', $amount);

                                        $commission = str_replace(' ', '', $_POST['commission']);
                                        $commission = str_replace(',', '.', $commission);

                                        $result = json_decode($_SESSION['Bank_rates'], true);
                                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 1;

                                        if($_POST['devise'] == 'USD')
                                        {
                                                $amount = $amount * $taux;
                                        }

                                        if($_POST['devise_commission'] == 'USD')
                                        {
                                                $commission = $commission * $taux;
                                                $tva = $commission * 0.16;
                                        }
                                        else
                                        {
                                                $tva = $commission * 0.16;
                                        }

                                        $amount_to_pay = $amount + $tva + $commission;

                                        $data = array();

                                        $data['bank_account'] = $_POST['compte'];
                                        $data['devise_account'] = $_POST['devise_compte'];
                                        $data['amount'] = $amount_to_pay;

                                        //$return = $this->curlModel->call_bank_checkbalance($data);
                                        if ($this->bank == '@rawbank' || $this->bank == '@firstbank'):
                                                $response = $this->amplitude->check_balance($data);
                                        else:

                                                if($_POST['devise_compte'] == 'USD')
                                                {
                                                        $_POST['balance'] = $_POST['balance'] * $taux;
                                                }

                                                $response['code'] = ($_POST['balance'] >= $data['amount']) ? '200': '300';
                                        endif;
                                }
                                else
                                {
                                        $response['code'] = '200';    
                                }

                                if (isset($response['code']) && $response['code'] == 200 || $response['code'] == 300)
                                {
                                        echo $response['code'];
                                }
                                else
                                {
                                        echo '411';
                                        die;
                                }
                        }
                        else
                        {
                                echo '405';
                                die;
                        }
                }
                elseif ($obj == "get_account_balance_inv")
                {
                        if (isset($_POST['montant']) && isset($_POST['commission']) && isset($_POST['compte']) && isset($_POST['devise']))
                        {
                                $amount = str_replace(' ', '', $_POST['montant']);
                                $amount = str_replace(',', '.', $amount);

                                $commission = str_replace(' ', '', $_POST['commission']);
                                $commission = str_replace(',', '.', $commission);

                                $result = json_decode($_SESSION['Bank_rates'], true);
                                $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 1;
                                $tva = $commission * 0.16;

                                if($_POST['devise_compte'] == 'CDF' && $_POST['devise'] == 'USD')
                                {
                                        $amount = $amount * $taux;
                                }
                                elseif($_POST['devise_compte'] == 'USD' && $_POST['devise'] == 'CDF')
                                {
                                        $amount = $amount / $taux;
                                }

                                if($_POST['devise_compte'] == 'CDF' && $_POST['devise_commission'] == 'USD')
                                {
                                        $commission = $commission * $taux;
                                        $tva = $commission * 0.16;
                                }
                                elseif($_POST['devise_compte'] == 'USD' && $_POST['devise_commission'] == 'CDF')
                                {
                                        $commission = $commission / $taux;
                                        $tva = $commission * 0.16;
                                }

                                $amount_to_pay = $amount + $tva + $commission;

                                $data = array();

                                $data['bank_account'] = $_POST['compte'];
                                $data['devise_account'] = $_POST['devise_compte'];
                                $data['amount'] = $amount_to_pay;

                                if ($this->bank == 'rawbank'):

                                        $response = $this->amplitude->check_balance($data);
                                else:

                                        if($_POST['devise_compte'] == 'USD')
                                        {
                                                $_POST['balance'] = $_POST['balance'] * $taux;
                                        }

                                        $response['code'] = ($_POST['balance'] >= $data['amount']) ? '200': '300';

                                endif;

                                if (isset($response['code']) && $response['code'] == 200 || $response['code'] == 300)
                                {
                                        echo $response['code'];
                                }
                                else
                                {
                                        echo '411';
                                        die;
                                }
                        }
                        else
                        {
                                echo '405';
                                die;
                        }
                }
                elseif ($obj == "get_account_exemption")
                {
                        $account  = trim($_POST['compte'] ?? '');
                        $currency = trim($_POST['devise'] ?? '');


                        if ($account == '' || $currency == '') 
                        {
                                echo json_encode(['code'=>'400','message'=>'Missing params']); die;
                        }

                        $response = [
                                'code' => '404',
                                'comm'=> '',
                                'tva'=>'',
                                'fbc'=>''
                        ];

                        $result   = $this->accountModel->get_customer_exemption_by_account($account, $currency);
                        $result = current($result);

                        if ($result && !empty($result->Infos_14))
                        {
                                $infos = json_decode($result->Infos_14);

                                if (json_last_error() !== JSON_ERROR_NONE)
                                {
                                        echo json_encode(['code'=>'500','message'=>'Invalid JSON']); 
                                        die;
                                }

                                $amount = (float)($result->Montant_11 ?? 0);
                                $comm   = (isset($infos->fb) && (string)$infos->fb == '1') ? max(0, $amount) : '';
                                $tva    = (isset($infos->tva) && (string)$infos->tva == '1') ? 0 : $comm * 0.16;
                                $fbc    = (isset($infos->fraisbcc) && (string)$infos->fraisbcc == '1') ? 0 : '';

                                $response = [
                                        'code' => '200',
                                        'comm' => $comm,
                                        'tva'  => $tva,
                                        'fbc'  => $fbc
                                ];
                        }

                        echo json_encode($response); die;

                }
                elseif($obj == "get_reservation")
                {
                        $result= array();
                        $infos = array();

                        $logiref_id = "";

                        switch ($_POST['object'] ?? "") 
                        {
                                case 'batch':
                                        $ref_op = $_POST['refop'] ?? "";
                                        $bulletin = $this->integrationModel->check_batch_bulletin_sydonia($ref_op);
                                        
                                        if(isset($bulletin[0]->Id_0) && $bulletin[0]->Id_0 !="")
                                        {
                                                $infos = json_decode($bulletin[0]->Reservation_35, true);
                                                $logiref_id = $bulletin[0]->Lot_14;
                                        }

                                        break; 
                                case 'single':
                                        $bulletin = $this->integrationModel->check_bulletin_sydonia();
                                        if(isset($bulletin[0]->Id_0) && $bulletin[0]->Id_0 !="") 
                                        {
                                                $infos = json_decode($bulletin[0]->Reservation_43, true);
                                                $logiref_id = $bulletin[0]->Logirefid_34;
                                        }

                                        break;
                                default:
                                        $bulletin = "";
                                        break;
                        }

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);
                        
                        if(isset($infos['lien_id']) && $infos['lien_id'] !="")
                        {
                                $id = $bulletin[0]->Id_0;
                                //$logiref_id = $bulletin[0]->Logirefid_34;

                                $_SESSION['lien_id'] = isset($infos['lien_id']) ? $infos['lien_id'] : "";
                                $_SESSION['date_lien'] = isset($infos['date_lien']) ? $infos['date_lien'] : "";

                                $result['code'] = 'E500';
                                $result['id'] = $id;
                                $result['reference'] = $logiref_id;
                                echo json_encode($result);
                        }
                        else
                        {
                                if($core_banking == 'synergies')
                                {
                                        $api_data['compte'] = $_POST['devise'].$_POST['compte'];
                                }
                                else
                                {
                                        $api_data['compte'] = $_POST['compte'];
                                }

                                $api_data['devise'] = $_POST['devise'];
                                $api_data['montant'] = $_POST['montant'];

                                $api_data['montant'] = str_replace(' ','',$api_data['montant']);
                                $api_data['montant'] = str_replace(',','.',$api_data['montant']);
                                $api_data['identifier'] = date("YmdHis");

                                if(isset($this->options['DGDA']['funds-reservation-with-instructions']))
                                {
                                        # Especially for this bank, there will not be an API invocation at this step
                                        # The script calls this bloc just to keep the same process with others banks
                                        # All the more so as we need to have one instance of logiref

                                        $result['lien_id'] = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                                        $result['date_lien'] = gmdate('Y-m-d');
                                        $result['code'] = '200';

                                        echo json_encode($result);
                                }
                                else
                                {
                                        # Vérifier si la méthode reservation existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'reservation'))
                                        {
                                                $response = $this->{$core_banking}->reservation($api_data);
                                        }
                                        else
                                        {
                                                $result['code'] = '407';
                                                echo json_encode($result); die;
                                        }

                                        $return = json_decode($response, true);

                                        if(isset($return['code']) && $return['code']=='200')
                                        {
                                                if(isset($_POST['bulletin_id']) && $_POST['bulletin_id'] !="")
                                                {
                                                        # If the payment has already been saved before the blocking (pre-saved)
                                                        $infos['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                        $infos['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                        if (($_POST['object'] ?? "") == "single")
                                                        {
                                                                $bl_data['Reservation_43'] = json_encode($infos);
                                                                $bl = $this->integrationModel->update_bulletin($bl_data, $_POST['bulletin_id']);
                                                        }
                                                        elseif (($_POST['object'] ?? "") == "batch")
                                                        {
                                                                $bl_data['Reservation_35'] = json_encode($infos);
                                                                $bl = $this->integrationModel->update_batch_bulletin($bl_data, $_POST['bulletin_id']);
                                                        }

                                                        $result['code'] = '200';

                                                        echo json_encode($result);
                                                }
                                                else
                                                {
                                                        # If the payment will be saved after the blocking (post-saved)
                                                        $result['lien_id'] = $return['lien'];
                                                        $result['date_lien'] = $return['date'];
                                                        $result['code'] = '200';

                                                        echo json_encode($result);
                                                }
                                        }
                                        elseif(isset($return['code']) && $return['code'] != "")
                                        {
                                                $result['code'] = $return['code'];

                                                $result['error_message'] = '<div class="alert alert-warning text-white">'.$return['message'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $result['code'] = 'E411';

                                                echo json_encode($result);
                                        }
                                }
                        }
                }
                elseif($obj == "cancel_reservation")
                {
                        $compte   = "";
                        $devise   = "";
                        $infos    = [];
                        $api_data = [];

                      
                        switch ($_POST['object'] ?? "") 
                        {
                                case 'batch':
                                        $bulletin = $this->integrationModel->get_bulletin_batch_info($_POST['batchid'] ?? "");
                                        if(!empty($bulletin))
                                        {
                                                $infos    = json_decode($bulletin->Reservation_35 ?? '{}', true);
                                                $account  = $bulletin->Account_16 ?? "";
                                                $currency = $bulletin->Devise_17 ?? "";
                                                $amount   = $bulletin->Amount_11 ?? "";
                                        }

                                        break; 
                                case 'single':
                                        $bulletin = $this->integrationModel->get_paiement_sydonia($_POST['bulletin_id'] ?? "");
                                        if(isset($bulletin->Id_0) && $bulletin->Id_0 !="")
                                        {
                                                $account  = $bulletin->Account_28 ?? "";
                                                $currency = $bulletin->Devise_29 ?? "";
                                                $amount   = $bulletin->Amount_12 ?? "";
                                                $infos    = json_decode($bulletin->Reservation_43 ?? '{}', true);
                                        }

                                        break;
                                case 'prepayment':
                                        $bulletin = $this->prepaymentsModel->get_prepayments_treated_by_id($_POST['id'] ?? "");
                                        
                                        if(isset($bulletin->Id_0) && $bulletin->Id_0 !="")
                                        {
                                                $account  = $bulletin->Account_15 ?? "";
                                                $currency = "CDF";
                                                $amount   = $bulletin->Amout_12 ?? "";
                                                $infos    = json_decode($bulletin->Reservation_20 ?? '{}', true);
                                        }

                                        break;
                                default:
                                        $bulletin = "";
                                        break;
                        }

                        $amount_treat = str_replace(' ','',$amount);
                        $amount_treat = str_replace(',','.',$amount_treat);

                        $api_data['account']   = $account ?? "";
                        $api_data['lien_id']   = $infos['lien_id'] ?? "";
                        $api_data['date_lien'] = $infos['date_lien'] ?? "";
                        $api_data['devise']    = $currency ?? "";
                        $api_data['montant']   = $amount_treat ?? "";

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode cancel_reservation existe dans la classe
                        if (method_exists($this->{$core_banking}, 'cancel_reservation'))
                        {
                                $response = $this->{$core_banking}->cancel_reservation($api_data);
                        }
                        else
                        {
                                $result['code'] = '407';
                                echo json_encode($result); die;
                        }
                     
                        // $return = json_decode($response, true);

                        $return['code']='200';
                      
                        if($return['code']=='200')
                        {
                                $infos['lien_id'] = "";
                                $infos['date_lien'] = "";
                                
                                if (($_POST['object'] ?? "") == "single")
                                {
                                        $bl_data['Reservation_43'] = json_encode($infos);
                                        $this->integrationModel->save_bulletin($bl_data, $_POST['bulletin_id']);
                                }
                                elseif (($_POST['object'] ?? "") == "batch")
                                {
                                        $bl_data['Reservation_35'] = json_encode($infos);
                                        $this->integrationModel->update_batch_bulletin($bl_data, $_POST['batchid']);
                                }
                                elseif (($_POST['object'] ?? "") == "prepayment")
                                {
                                       
                                        $bl_data['Reservation_20'] = '';
                                        $this->prepaymentsModel->save_traitement($bl_data, $_POST['id']);
                                }

                                $result['code'] = '200';
                                echo json_encode($result);
                        }
                        elseif(isset($return['code']) && $return['code'] != "")
                        {
                                $result['code'] = $return['code'];
                                $result['error_message'] = '<div class="alert alert-warning text-white">'.$return['msg'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = 'E411';

                                echo json_encode($result);
                        }
                }
                elseif($obj == "get_trans_details")
                {
                        $data['Reference_32'] = $_POST['transID'] ?? "";
                        $data['transDate'] = $_POST['transDate'] ?? "";
                        $data['Compte_33'] = $_POST['compte'] ?? "";

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        $response = $this->{$core_banking}->transaction_details($data);
                        
                        if(isset($response['response']) && $response['response'] != "")
                        {
                                $result['code'] = $response['response'] ?? '';
                                $result['message'] = $response['message'] ?? '';
                                $result['data'] = $response['data'] ?? [];
                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = 'E409';
                                $result['message'] = '<div class="alert alert-warning text-white">No response returned from the CBS.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $result['error_message'] = '<div class="alert alert-warning text-white">No response returned from the CBS.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                echo json_encode($result);
                        }
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
