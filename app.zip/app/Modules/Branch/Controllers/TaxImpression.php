<?php 

namespace Modules\Branch\Controllers;

use Data_model;
use App\Libraries\MailLib;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\PngWriter;
use Modules\Branch\Models\DataModel;
use Endroid\QrCode\Encoding\Encoding;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\AccountModel;
use Modules\Branch\Models\ReportsModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\PasseportModel;


use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ImmatriculationModel;
use Modules\Branch\Models\ComptabilisationModel;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Modules\Services\Immatriculation\Models\ImmatriculationModel as ServiceImmatriculationModel;

class TaxImpression extends BaseController {
        /*
         * Presentation: gestion des impression(production des documents PDF)
         * Last update:
         * By Glodi on the 20.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'Branch';
        public $folder = 'impression';
        public $bank;
        public $integrationModel;
        public $logirefModel;
        public $reportsModel;
        public $accountModel;
        public $comptabilisationModel;
        public $usersModel;
        public $mainModel;
        public $branchModel;
        public $encaissementModel;
        public $stakeholderModel;
        public $immatriculationModel;

        public $passportModel;

        public $dataModel=null;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->reportsModel = new ReportsModel();
                $this->accountModel = new AccountModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new MainModel();
                $this->branchModel = new BranchModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->immatriculationModel=new ImmatriculationModel();
                $this->passportModel = new PasseportModel();
                $this->dataModel=new DataModel();

                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['account_business'] = $this->session->userdata['account_business'];
                $this->data['account_logo'] = $this->session->userdata['account_logo'];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->session->userdata["account_cbs"];
                $this->data['deny'] = false;

                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
	}

	public function index()
	{

	}

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{

	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                /*if($obj == "filetext")
                {
                    $filename = "VIRMUL_LGIREF.txt";
                    $path = "./drive/logiref/".$filename;
                    $virmul = array(
                        array('2AXVHI','BENEFICIAIRE','RAWBANK','051000510102000041046','23','557075300706B 2023L10797 RET A0905460W'),
                        array('2AXVHI','BENEFICIAIRE','RAWBANK','051000510102000041046','23','557075300706B 2023L10797 RET A0905460W')
                    );
                    $file = fopen($path, 'w');
                    if($file){
                        if(flock($file, LOCK_EX)) {
                           foreach ($virmul as $value) {
                                $content = implode("         ", $value) . PHP_EOL;
                                fwrite($file, $content);
                           }
                           flock($file, LOCK_UN);
                            echo json_encode(array("write" => True,"message" => "Le contenu a été ajouté avec succès."));
                        } 
                        else {
                            echo json_encode(array("write" => False, "message" => "Impossible d'obtenir le verrou pour ajouter au fichier."));
                        }

                        fclose($file);
                    } 
                    else 
                    {
                        echo json_encode(array("write" => False, "message" => "Impossible d'ouvrir le fichier."));
                    }
                }
                elseif($obj= "downloadvirmul")
                {
                    $filename = "./drive/logiref/VIRMUL_LGIREF.txt";
                    if(file_exists($filename)) {
                        header('Content-Description: File Transfer');
                        header('Content-Type: application/octet-stream');
                        header('Content-Disposition: attachment; filename="'.basename($filename).'"');
                        header('Expires: 0');
                        header('Cache-Control: must-revalidate');
                        header('Pragma: public');
                        header('Content-Length: ' . filesize($filename));
                        flush(); 
                        readfile($filename);
                        echo "Le fichier est téléchargé.";
                        exit;
                    } 
                    else{
                        echo "Le fichier n'existe pas.";
                    }
                }*/
                if($obj == "export_gu") 
                {  
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'",$agence);
                        $encaissements  = $this->integrationModel->get_sucess_instructions_dgda($day);
                        $events = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $users = $this->mainModel->get_dropdown('users_array');
                        $cgu = isset($comptes['DGDA']['CGU']['CDF'])? $comptes['DGDA']['CGU']['CDF']: "";
                          
                        $regie = 'DGDA';
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_gu');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date comptant","Date validation","Operateur","Validateur","Numéro événement","Code opération", "Libellé","Débit","Crédit");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        foreach($encaissements as $row)
                        {
                                # Montant paye
                                
                                if($row->Compte_13 == $cgu || $row->Compte_9 == $cgu)
                                {
                                        if($row->Compte_13 == $cgu)
                                        {
                                                $credit= $row->Montant_10;
                                                $debit= "";
                                        }
                                        else
                                        {
                                                $debit= $row->Montant_10;
                                                $credit="";
                                        }
                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                
                                        if(isset($events[$row->Paiementid_4][$row->Id_0]['Num_evenement'])? $references[$row->Id_0] = $events[$row->Paiementid_4][$row->Id_0]['Num_evenement'] : $references[$row->Id_0] = '');
                                        if(isset($users[$row->Makerid_16])? $users[$row->Makerid_16] : $users[$row->Makerid_16]="" );
                                        if(isset($users[$row->Checkerid_17])? $users[$row->Checkerid_17] : $users[$row->Checkerid_17]="" );

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Validation_18);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $users[$row->Makerid_16]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $users[$row->Checkerid_17]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $references[$row->Id_0]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, "147");
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Libelle_12);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $debit);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $credit);

                                        if($i != $array_length)
                                        {   
                                            $erow++;
                                        }
                                        $i++;

                                }
                                
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => \PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_report_gu_'.time().'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/reportings';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                                //save the file on the server's HD
                                $objWriter->save($path);
                        }
                        
                        //download the file in the browser
                        $objWriter->save('php://output');

                }
                elseif($obj == "export_commission")
                {
                        $paiements = $this->encaissementModel->get_paiements();
                        $equivalence = 0;
                        $calcul = 0;
                        $tva = 0.16;
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_commissions');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date","Client","Commission","TVA","Agence");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiements);
                        foreach($paiements as $row)
                        {
                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $calcul = $row->Commission_23*$tva;

                                if($row->Devise_24 == "USD")
                                {
                                        $equivalence = $row->Commission_23*$usd;
                                }
                                else
                                {
                                        $equivalence = $row->Commission_23;
                                }
                                #var_dump($equivalence);die;

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $equivalence);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $calcul);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => \PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_commissions_'.time().'.xlsx';
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-commission';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                }
                elseif ($obj == "export_report_dgi")
                {
                        // Dropdowns
                        $beneficiaires                  = $this->reportsModel->regies;
                        $encaissements_immatriculation  = $this->reportsModel->get_paiements_dgi_immatriculation();
                        $encaissements                  = $this->reportsModel->get_paiements_dgi();
                        $guichets                       = $this->branchModel->get_dropdown("guichets");
                        $recettes                       = $this->logirefModel->get_dropdown("recettes");

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[6]; // colonne G

                        // Worksheet
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report_dgi');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                        'bold'  => true,
                                        'color' => ['rgb' => '000000'],
                                        'size'  => 12,
                                        'name'  => 'Book Antiqua',
                                ],
                        ];

                        // Colonnes
                        $table_columns = ["Date", "Regie", "Service", "Client", "Montant", "Commissions", "Agences"];
                        foreach ($table_columns as $i => $columnName) {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        // Boucle
                        $erow = 2;
                        $i = 0;
                        $array_length = count($encaissements) + count($encaissements_immatriculation);

                        foreach ($encaissements as $row) {
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, number_format($row->Contrevaleur_22, 2, ",", " "));
                                $worksheet->setCellValue('F'.$erow, number_format($row->Commission_23, 2, ",", " "));
                                $worksheet->setCellValue('G'.$erow, $guichets[$row->Guichet_21] ?? '-');

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        foreach ($encaissements_immatriculation as $row) {
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, number_format($row->Montant_11, 2, ",", " "));
                                $worksheet->setCellValue('F'.$erow, number_format($row->Commission_23, 2, ",", " "));
                                $worksheet->setCellValue('G'.$erow, $guichets[$row->Guichet_21] ?? '-');

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Bordures
                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleBorders);

                        // Sauvegarde
                        $user_id    = $this->session->userdata['user_id'];
                        $filename   = $user_id.'_DGI'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path       = "./drive/logiref/".$account_id."/".date('Y-m').'/report';

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $path = $path."/".$filename;
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        // Téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        readfile($path);
                        exit;
                }
                elseif ($obj == "export_report_dgrad")
                {
                        // Dropdowns
                        $beneficiaires = $this->reportsModel->regies;
                        $encaissements = $this->reportsModel->get_paiements_dgrad(); // méthode unifiée
                        $guichets      = $this->branchModel->get_dropdown("guichets");
                        $recettes      = $this->logirefModel->get_dropdown("recettes");

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[6]; // colonne G

                        // Worksheet
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report_dgi');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                'bold'  => true,
                                'color' => ['rgb' => '000000'],
                                'size'  => 12,
                                'name'  => 'Book Antiqua',
                                ],
                        ];

                        // Colonnes
                        $table_columns = ["Date", "Regie", "Service", "Client", "Montant", "Commissions", "Agences"];
                        foreach ($table_columns as $i => $columnName) 
                        {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        // Boucle
                        $erow = 2;
                        $i = 0;
                        $array_length = count($encaissements);

                        foreach ($encaissements as $row) 
                        {
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, number_format($row->Contrevaleur_22, 2, ",", " "));
                                $worksheet->setCellValue('F'.$erow, number_format($row->Commission_23, 2, ",", " "));
                                $worksheet->setCellValue('G'.$erow, $guichets[$row->Guichet_21] ?? '-');

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Bordures
                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleBorders);

                        // Sauvegarde
                        $user_id    = $this->session->userdata['user_id'];
                        $filename   = $user_id.'_DGRAD'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path       = "./drive/logiref/".$account_id."/".date('Y-m').'/report';

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $path = $path."/".$filename;
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        // Téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        readfile($path);
                        exit;
                }
                elseif ($obj == "export_reports_dgda")
                {
                        // Dropdowns
                        $services  = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $guichets  = $this->branchModel->get_dropdown("guichets");
                        $users     = $this->mainModel->get_dropdown('users_array');
                        $status    = ['1'=>'Initié', '2'=>'En attente', '3'=>'Validé','4'=>'Reversé', '5'=>'À Régulariser'];

                        // Données
                        $bulletins = $this->integrationModel->get_reports_bls(); // méthode unifiée

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[8]; // colonne I

                        // Worksheet
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report-dgda');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                'bold'  => true,
                                'color' => ['rgb' => '000000'],
                                'size'  => 12,
                                'name'  => 'Book Antiqua',
                                ],
                        ];

                        // Colonnes
                        $table_columns = ["Date", "Service", "BL", "Quittance", "Client", "Montant", "Agence", "Saisi", "Status"];
                        foreach ($table_columns as $i => $columnName) 
                        {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        // Boucle
                        $erow = 2;
                        $i = 0;
                        $array_length = count($bulletins);

                        foreach ($bulletins as $row) 
                        {
                                $results   = json_decode($row->Results_13);
                                $recieptDate   = isset($results->receiptDate) ? explode("/", $results->receiptDate) : [null, null, date('Y')];
                                $receiptNumber = $results->receiptNumber ?? "";
                                $receiptSerial = $results->receiptSerial ?? "";
                                $nodeid        = $recieptDate[2] . $receiptSerial . $receiptNumber;

                                $operateur = $users[$row->User_15] ?? ' - ';

                                $worksheet->setCellValue('A'.$erow, $row->Integration_16);
                                $worksheet->setCellValue('B'.$erow, $services['DGDA'][$row->Office_6] ?? '');
                                $worksheet->setCellValue('C'.$erow, 'L'.$row->Number_8);
                                $worksheet->setCellValue('D'.$erow, $nodeid);
                                $worksheet->setCellValue('E'.$erow, $row->Designation_23 == "" 
                                                                ? "Bulletin de liquidation / ".$row->Nif_9 
                                                                : $row->Designation_23);
                                $worksheet->setCellValue('F'.$erow, number_format($row->Amount_12, 2, ",", " "));
                                $worksheet->setCellValue('G'.$erow, $guichets[$row->Agence_32] ?? '-');
                                $worksheet->setCellValue('H'.$erow, $operateur);
                                $worksheet->setCellValue('I'.$erow, $status[$row->Status_2] ?? $row->Status_2);

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Bordures
                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleBorders);

                        // Sauvegarde
                        $user_id    = $this->session->userdata['user_id'];
                        $filename   = $user_id.'reportdgda'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path       = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgda';

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $path = $path."/".$filename;
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        // Téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        readfile($path);
                        exit;
                }
                elseif ($obj == "export_deleted_dgda")
                {
                        // Dropdowns
                        $services  = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $guichets  = $this->branchModel->get_dropdown("guichets");
                        $users     = $this->mainModel->get_dropdown('users_array');
                        $status    = ['1'=>'Initié', '2'=>'En attente', '3'=>'Validé','4'=>'Reversé', '5'=>'À Régulariser'];

                        # Données (méthode unifiée)
                        $bulletins = $this->integrationModel->get_reports_deleted_bls(); 

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[8]; // colonne I

                        // Worksheet
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report-dgda');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                'bold'  => true,
                                'color' => ['rgb' => '000000'],
                                'size'  => 12,
                                'name'  => 'Book Antiqua',
                                ],
                        ];

                        # Colonnes
                        $table_columns = ["Date", "Service", "BL", "Client", "Montant", "Agence", "Saisi", "Supprimé"];
                        foreach ($table_columns as $i => $columnName) 
                        {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        // Boucle
                        $erow = 2;
                        $i = 0;
                        $array_length = count($bulletins);

                        foreach ($bulletins as $row) 
                        {
                                $results   = json_decode($row->Results_13);
                                $recieptDate   = isset($results->receiptDate) ? explode("/", $results->receiptDate) : [null, null, date('Y')];
                                $receiptNumber = $results->receiptNumber ?? "";
                                $receiptSerial = $results->receiptSerial ?? "";
                                $nodeid        = $recieptDate[2] . $receiptSerial . $receiptNumber;

                                $operateur = $users[$row->User_15] ?? ' - ';

                                $worksheet->setCellValue('A'.$erow, $row->Deletion_48);
                                $worksheet->setCellValue('B'.$erow, $services['DGDA'][$row->Office_6] ?? '');
                                $worksheet->setCellValue('C'.$erow, 'L'.$row->Number_8);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_23 == "" 
                                                                ? "Bulletin de liquidation / ".$row->Nif_9 
                                                                : $row->Designation_23);
                                $worksheet->setCellValue('E'.$erow, number_format($row->Amount_12, 2, ",", " "));
                                $worksheet->setCellValue('F'.$erow, $guichets[$row->Agence_32] ?? '-');
                                $worksheet->setCellValue('G'.$erow, $operateur);
                                $worksheet->setCellValue('H'.$erow, ($users[$row->Deletedby_49] ?? ' - '));

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Bordures
                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleBorders);

                        // Sauvegarde
                        $user_id    = $this->session->userdata['user_id'];
                        $filename   = $user_id.'reportdgda'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path       = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgda';

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $path = $path."/".$filename;
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        // Téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        readfile($path);
                        exit;
                }
                elseif ($obj == "export_gu_paiements_tresor")
                {
                        $services      = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $guichets      = $this->branchModel->get_dropdown("guichets");
                        $encaissements = $this->reportsModel->get_paiements_tresor_gu();

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[9];

                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report_paiement_tresor');

                        $styleHeader = [
                                'font' => [
                                'bold'  => true,
                                'color' => ['rgb' => '000000'],
                                'size'  => 12,
                                'name'  => 'Book Antiqua',
                                ],
                        ];

                        $table_columns = [
                                "Date", "Numero BL", "Régie", "Service", "Recette",
                                "Importateur", "Quittance", "Bordereau",
                                "Montant BL", "Montant Taxe"
                        ];

                        foreach ($table_columns as $i => $columnName) {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        $erow = 2;

                        foreach ($encaissements as $row)
                        {
                                $Infos     = json_decode($row->Notereference_30, true);
                                $quittance = $Infos['quittanceid'] ?? '';

                                // DONNÉES COMMUNES
                                $worksheet->setCellValue('A' . $erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B' . $erow, $row->Noteid_26);
                                $worksheet->setCellValue('C' . $erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D' . $erow, $services[$row->Service_16] ?? '');
                                $worksheet->setCellValue('E' . $erow, $row->Typerecette_17);
                                $worksheet->setCellValue('F' . $erow, $row->Designation_14);

                                if ($row->Sydonia_44 != 0)
                                {
                                $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);
                                $worksheet->setCellValue('G' . $erow, $quittance);
                                $worksheet->setCellValue('H' . $erow, $row->Reference_32);
                                $worksheet->setCellValue('I' . $erow, number_format($sydonia->Amount_12, 2, ",", " "));
                                }
                                elseif ($row->Sydonia_49 != 0)
                                {
                                $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                $worksheet->setCellValue('G' . $erow, '');
                                $worksheet->setCellValue('H' . $erow, $prepaiements->Accountholder_29);
                                $worksheet->setCellValue('I' . $erow, number_format($prepaiements->Amount_18, 2, ",", " "));
                                }

                                $worksheet->setCellValue('J' . $erow, number_format($row->Montant_11, 2, ",", " "));
                                $erow++;
                        }

                        // AUTO SIZE
                        $highestColumn = $worksheet->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) {
                                $worksheet->getColumnDimension($col)->setAutoSize(true);
                        }

                        // BORDURES
                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleBorders);

                        // NOM DU FICHIER
                        $user_id  = $this->session->userdata['user_id'];
                        $filename = $user_id . '_reportdgdatresor_' . time() . '.xlsx';

                        // CHEMIN SUR LE SERVEUR
                        $account_id = $this->session->userdata['account_id'];
                        $path = "./drive/logiref/" . $account_id . "/" . date('Y-m') . "/report-paiement_tresor";

                        if (!is_dir($path)) {
                                mkdir($path, 0777, true);
                        }

                        $fullPath = $path . "/" . $filename;

                        //  Enregistrer sur le serveur
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($fullPath);

                        // Envoyer le fichier pour téléchargement immédiat
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment; filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');
                        readfile($fullPath);
                        exit;
                }
                elseif ($obj == "export_gu_paiements_propres")
                {
                        $services      = $this->logirefModel->get_dropdown("services");
                        $guichets      = $this->branchModel->get_dropdown("guichets");
                        $encaissements = $this->reportsModel->get_paiements_propres_gu();

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[9];

                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report_paiement_propres');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                        'bold'  => true,
                                        'color' => ['rgb' => '000000'],
                                        'size'  => 12,
                                        'name'  => 'Book Antiqua',
                                ],
                        ];

                        $table_columns = [
                                "Date", "Numero BL", "Régie", "Service", "Recette",
                                "Importateur", "Quittance", "Bordereau", "Montant BL", "Montant Taxe"
                        ];

                        foreach ($table_columns as $i => $columnName) 
                        {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        $erow = 2;
                        $array_length = count($encaissements);
                        $i = 0;

                        foreach ($encaissements as $row) 
                        {
                                $Infos     = json_decode($row->Notereference_30, true);
                                $quittance = $Infos['quittanceid'] ?? '';

                                // Données communes
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $services[$row->Service_16] ?? '');
                                $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                $worksheet->setCellValue('F'.$erow, $row->Designation_14);

                                // Montants
                                if ($row->Sydonia_44 != 0) 
                                {
                                        $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);
                                        $worksheet->setCellValue('G'.$erow, $quittance);
                                        $worksheet->setCellValue('H'.$erow, $row->Reference_32);
                                        $worksheet->setCellValue('I'.$erow, number_format($sydonia->Amount_12, 2, ",", " "));
                                } 
                                elseif ($row->Sydonia_49 != 0) 
                                {
                                        $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                        $worksheet->setCellValue('G'.$erow, '');
                                        $worksheet->setCellValue('H'.$erow, $prepaiements->Accountholder_29);
                                        $worksheet->setCellValue('I'.$erow, number_format($prepaiements->Amount_18, 2, ",", " "));
                                }

                                $worksheet->setCellValue('J'.$erow, number_format($row->Montant_11, 2, ",", " "));

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size & bordures
                        $highestColumn = $worksheet->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $worksheet->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];

                        $worksheet->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleBorders);

                        // Sauvegarde et téléchargement
                        $user_id  = $this->session->userdata['user_id'];
                        $filename = $user_id.'reportdgdatpropre'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path = "./drive/logiref/".$account_id."/".date('Y-m')."/report-paiement_propres";

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $fullPath = $path."/".$filename;
                        $objWriter = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($fullPath);

                        // Envoi du fichier pour téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment; filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        readfile($fullPath);
                        exit;
                }
                elseif ($obj == "export_fonds_propres")
                {
                        $services      = $this->logirefModel->get_dropdown("services");
                        $guichets      = $this->branchModel->get_dropdown("guichets");
                        $encaissements = $this->reportsModel->get_fond_propres();
                        $encaissements_immatriculation = $this->reportsModel->get_fond_propres_immatriculation();

                        $alphas = range('A', 'Z');
                        $atoz   = $alphas[8];

                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('report_paiement_propres');

                        // Style header
                        $styleHeader = [
                                'font' => [
                                        'bold'  => true,
                                        'color' => ['rgb' => '000000'],
                                        'size'  => 12,
                                        'name'  => 'Book Antiqua',
                                ],
                        ];

                        $table_columns = [
                                "Date", "Numero BL", "Régie", "Service", "Recette",
                                "Designation", "Quittance", "Montant BL", "Montant Taxe"
                        ];

                        foreach ($table_columns as $i => $columnName)
                        {
                                $worksheet->setCellValue($alphas[$i] . '1', $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleHeader);

                        $erow = 2;
                        $array_length = count($encaissements) + count($encaissements_immatriculation);
                        $i = 0;

                        foreach ($encaissements as $row)
                        {
                                $Infos     = json_decode($row->Notereference_30, true);
                                $quittance = $Infos['quittanceid'] ?? '';

                                // Données communes
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $services[$row->Service_16] ?? '');
                                $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                $worksheet->setCellValue('F'.$erow, $row->Designation_14);

                                // Montants
                                if ($row->Sydonia_44 != 0)
                                {
                                        $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);
                                        $worksheet->setCellValue('G'.$erow, $quittance);
                                        $worksheet->setCellValue('H'.$erow, number_format($sydonia->Amount_12, 2, ",", " "));
                                }
                                elseif ($row->Sydonia_49 != 0)
                                {
                                        $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                        $worksheet->setCellValue('G'.$erow, '');
                                        $worksheet->setCellValue('H'.$erow, number_format($prepaiements->Amount_18, 2, ",", " "));
                                }

                                $worksheet->setCellValue('I'.$erow, number_format($row->Montant_11, 2, ",", " "));

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        foreach ($encaissements_immatriculation as $row)
                        {
                                $Infos     = json_decode($row->Notereference_30, true);
                                $quittance = $Infos['quittanceid'] ?? '';

                                // Données communes
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $services[$row->Service_16] ?? '');
                                $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                $worksheet->setCellValue('F'.$erow, $row->Designation_14);

                                // Montants
                                if ($row->Sydonia_44 != 0)
                                {
                                        $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);
                                        $worksheet->setCellValue('G'.$erow, $quittance);
                                        $worksheet->setCellValue('H'.$erow, number_format($sydonia->Amount_12, 2, ",", " "));
                                }
                                elseif ($row->Sydonia_49 != 0)
                                {
                                        $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                        $worksheet->setCellValue('G'.$erow, '');
                                        $worksheet->setCellValue('H'.$erow, number_format($prepaiements->Amount_18, 2, ",", " "));
                                }

                                $worksheet->setCellValue('I'.$erow, number_format($row->Montant_11, 2, ",", " "));

                                if ($i != $array_length) $erow++;
                                $i++;
                        }

                        // Auto size & bordures
                        $highestColumn = $worksheet->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $worksheet->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleBorders = [
                                'borders' => [
                                'allBorders' => [
                                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                        'color' => ['argb' => '000000'],
                                ],
                                ],
                        ];

                        $worksheet->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleBorders);

                        // Sauvegarde et téléchargement
                        $user_id  = $this->session->userdata['user_id'];
                        $filename = $user_id.'reportdgdatpropre'.time().'.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path = "./drive/logiref/".$account_id."/".date('Y-m')."/report-paiement_propres";

                        if (!is_dir($path)) mkdir($path, 0777, true);

                        $fullPath = $path."/".$filename;
                        $objWriter = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($fullPath);

                        // Envoi du fichier pour téléchargement direct
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment; filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        readfile($fullPath);
                        exit;
                }
                elseif($obj == "penalitie_dgda")
                {
                        $penalite=0;
                        $beneficiaires = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $encaissements = $this->encaissementModel->get_paiements('penalities');
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8];
                        //load our new PHPExcel library
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('retard_reversement');

                        //set cell A1 content with some text
                             
                        $styleArray = [
                                'font' => [
                                    'bold' => true,
                                    'color' => ['rgb' => '000000'],
                                    'size' => 12,
                                    'name' => 'Book Antiqua',
                                ],
                        ]; 

                        
                        $table_columns = array("Date","Client","Beneficiaire","Service", "Recette", "Montant", "Retard", "Penalité", "Agences");
                        $column = 0;
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        
                        $array_length = count($encaissements);
                        
                        
                        foreach($encaissements as $row)
                        {

                               #Trouver le nombre de jour/mois/annee entre les dates
                                $date1 = $row->Datevaleur_31;
                                $date2 = gmdate('Y-m-d');
                                $diff = abs(strtotime($date2) - strtotime($date1));
                                $years = floor($diff / (365*60*60*24));
                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                
                                $penalite =$row->Montant_11*0.03*$days; 

                                //$dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+60 day",$date));
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $row->Service_16);
                                if($row->Beneficaire_15 =="DGRAD")$worksheet->setCellValue('E'.$erow, $row->Typerecette_17." ".$row->Noteid_26);  
                                else $worksheet->setCellValue('E'.$erow, $row->Typerecette_17); 
                                $worksheet->setCellValue('F'.$erow, $row->Montant_11);
                                $worksheet->setCellValue('G'.$erow, $days." "."jours");
                                $worksheet->setCellValue('H'.$erow, $penalite);
                                $worksheet->setCellValue('I'.$erow, $guichets[$row->Guichet_21]);

                                    
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;

                        }
                         //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'noreverse'.time().'.xlsx';
                         #var_dump($filename);die;

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/noreverse';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                        
                        
                }
                elseif($obj == "export_comptes") 
                {  
                        $comptes = $this->accountModel->get_export_comptes();
                        $types = $this->logirefModel->get_dropdown("types","Compte");
                        $users = $this->mainModel->get_dropdown('users_array');
                        $agences = $this->branchModel->get_dropdown("guichets");
                        $services =$this->logirefModel->get_dropdown("services");
                        $recettes = $this->logirefModel->get_dropdown("recettes");
                        $villes = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_comptes');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Agence","Type","Taxe","Comptes","Devise","Bénéficiaire");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($comptes);
                      
                        foreach($comptes as $row)
                        {
                                $compte = isset($guichets[$row->Agence_12])? $guichets[$row->Agence_12] : "";
                                
                                $worksheet->setCellValue('A'.$erow, $compte);
                                $worksheet->setCellValue('A'.$erow, $row->Type_4);
                                $worksheet->setCellValue('B'.$erow, $row->Recette_13);
                                $worksheet->setCellValue('C'.$erow, $row->Agenceid_15.'-'.$row->Compte_6.'-'.$row->Clef_7.' ');
                                $worksheet->setCellValue('D'.$erow, $row->Devise_8);
                                $worksheet->setCellValue('E'.$erow, $row->Beneficiaires_5);
                                 
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_comptes'.time().'.xlsx';
                         #var_dump($filename);die;

                                                
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                }
                elseif($obj == "export_agences")
                {
                        $beneficiaires = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $guichets = $this->branchModel->get_dropdown("guichets");
			$users = $this->mainModel->get_dropdown('users_array');
                        
                        if (isset($_SESSION['payment_agence']) && $_SESSION['payment_agence'] != '')
                        {
                            $encaissements = $_SESSION['payment_agence'];
                        }
                        else
                        {
                            $encaissements = [];
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_payment_agence');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Date","Désignation","Bénéficiaire","Recette","Montant", "Commissions", "Opérateur", "Agence");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($encaissements);
                      
                        foreach($encaissements as $row)
                        {
                                                        var_dump($encaissements);die;

                                $worksheet->setCellValue('A'.$erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                $worksheet->setCellValue('A'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('B'.$erow, $row->Recette_13);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $row->Devise_12.' '.number_format($row->Montant_11,2,","," "));
                                $worksheet->setCellValue('E'.$erow, $row->Devise_24.' '.number_format($row->Commission_23,2,","," "));
                                $worksheet->setCellValue('F'.$erow, (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ');
                                $worksheet->setCellValue('G'.$erow, (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ');
                                 
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_payment'.time().'.xlsx';
                         #var_dump($filename);die;

                                                
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                        
                        
                        unset($_SESSION['payment_agence']);
                        
                }
                elseif($obj == "schema")
                {
                        // Les schémas DGRK utilisent leur propre table et leur
                        // propre chemin de compatibilité. Le paramètre dgrk=1
                        // ne doit pas tomber dans le flux générique (DGDA).
                        if ((string) ($_GET['dgrk'] ?? '') === '1') {
                                return redirect()->to(base_url($this->module . '/taximpression/display/schema_dgnk/' . $id));
                        }
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        //get instuctions
                        if($encaissement->Beneficaire_15 == "DGI"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGRAD"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGDA"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgda($encaissement->Sydonia_44);

                        endif;

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $imagePath = base_url('ikwook_files/images/solidairebanque/bordereau.jpg');
                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schema_passeport")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->passportModel->get_paiement_info($id);

                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        //get instuctions
                        if($encaissement->Beneficaire_15 == "DGRAD"):

                                $instrcutions = $this->comptabilisationModel->get_instructions_passeport($encaissement->Logirefid_4);

                        endif;

                        # Retours Core Banking DGRK depuis la table dédiée.
                        $dgrkFinacleModel = new \Modules\Services\Finacle\Models\FinacleModel();
                        $cbs_return = [];
                        foreach ($dgrkFinacleModel->get_cbs_returns_dgrk_by_paiementid($id) as $returnRow) {
                                $decoded = json_decode($returnRow['Result_6'] ?? '', true);
                                if (is_array($decoded)) {
                                        foreach ($instrcutions as $instruction) {
                                                $cbs_return[$instruction->Id_0] = $decoded;
                                        }
                                }
                        }
                        $this->data['cbs_return'] = $cbs_return;

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $imagePath = base_url('ikwook_files/images/solidairebanque/bordereau.jpg');
                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj=="schema_immatriculation")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $note=$this->immatriculationModel->get_integration_immatriculation($id);

                        $this->data['encaissement'] = $encaissement = $this->immatriculationModel->immatriculation_migrate_note($note->Id_0);

                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($note->Guichet_32);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_immatriculation_by_id($encaissement->Id_0);

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->immatriculationModel->get_cbs_returns_immatriculation($encaissement->Id_0);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema_immatriculation', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $imagePath = base_url('ikwook_files/images/solidairebanque/bordereau.jpg');
                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schema_batch")
                {
                        $logirefid = $id;

                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');

                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $beneficiaires;
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiements_batch_by_logirefid($logirefid);

                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Montant_13, $encaissement->Devise_14);
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_25);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        //get instuctions
                        if($encaissement->Beneficaire_7 == "DGI"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgi($logirefid);

                        elseif($encaissement->Beneficaire_7 == "DGRAD"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($logirefid);

                        endif;

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema_batch', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $imagePath = base_url('ikwook_files/images/solidairebanque/bordereau.jpg');

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schema_permis")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_permis_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        $instrcutions = $this->comptabilisationModel->get_instructions_permis($encaissement->Logirefid_4);

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schema_dgnk")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                        if ($encaissement) {
                                $encaissement->Beneficaire_15 = $encaissement->Beneficaire_10 ?? 'DGRK';
                                $encaissement->Logirefid_4 = $encaissement->Logirefid_9 ?? '';
                                $encaissement->Contrevaleur_22 = $encaissement->Contrevaleur_19 ?? 0;
                                $encaissement->Guichet_21 = $encaissement->Guichet_28 ?? '';
                                $encaissement->Reference_32 = $encaissement->Reference_22 ?? '';
                                $encaissement->Montant_11 = $encaissement->Montant_15 ?? 0;
                                $encaissement->Devise_12 = $encaissement->Devise_16 ?? '';
                                $encaissement->Commission_23 = $encaissement->Commission_17 ?? 0;
                                $encaissement->Devise_24 = $encaissement->Devise_18 ?? '';
                                $encaissement->Makerid_9 = $encaissement->Makerid_7 ?? '';
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');

                        if($encaissement->Beneficaire_15 == "DGRK"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrk($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGPEK"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgpek($encaissement->Logirefid_4);

                        endif;

                        // Retour CBS DGRK : utiliser exclusivement la table dédiée.
                        $dgrkFinacleModel = new \Modules\Services\Finacle\Models\FinacleModel();
                        $cbs_return = [];
                        foreach ($dgrkFinacleModel->get_cbs_returns_dgrk_by_paiementid($id) as $returnRow) {
                                $decoded = json_decode($returnRow['Result_6'] ?? '', true);
                                if (is_array($decoded)) {
                                        $cbs_return = array_replace($cbs_return, $decoded);
                                }
                        }
                        $this->data['cbs_return'] = $cbs_return;

                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne

                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schemabl")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        
                        //var_dump($this->data['users']); die;
                        
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_paiement_tresor_bl($id);
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_paiement_propres_bl($id);
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');
                        
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);
                        
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;  
                }
                if($obj == "schema_prepayment")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_prepaiement_tresor_bl($id);
                        
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_prepaiement_propres_bl($id);  
                        }
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_prepayments_cbs_returns($id);
                        //var_dump($cbs_return); die;
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['lines'] = $instrcutions;
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');
                        
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema_prepayment', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "attestation")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $months=  $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        if ($arg == "dgrk")
                        {
                                // Les paiements DGRK résident dans leur table dédiée.
                                $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                if ($encaissement) {
                                        $encaissement->Beneficaire_15 = 'DGRK';
                                        $encaissement->Reference_32 = $encaissement->Reference_22 ?? '';
                                        $encaissement->Logirefid_4 = $encaissement->Logirefid_9 ?? '';
                                        $encaissement->Montant_11 = $encaissement->Montant_15 ?? 0;
                                        $encaissement->Devise_12 = $encaissement->Devise_16 ?? '';
                                        $encaissement->Contrevaleur_22 = $encaissement->Contrevaleur_19 ?? 0;
                                        $encaissement->Guichet_21 = $encaissement->Guichet_28 ?? '';
                                        $encaissement->Datevaleur_31 = $encaissement->Datevaleur_23 ?? $encaissement->Date_1 ?? '';
                                        $encaissement->Noteid_26 = $encaissement->Declarationid_20 ?? '';
                                        $encaissement->Service_16 = $encaissement->Service_11 ?? '';
                                        $encaissement->Typerecette_17 = $encaissement->Typerecette_12 ?? '';
                                        $encaissement->Notereference_30 = $encaissement->File_32 ?? '';
                                }
                                $this->data['encaissement'] = $encaissement;
                                $this->data['instrcutions'] = $encaissement
                                        ? $this->comptabilisationModel->get_instructions_dgrk($encaissement->Logirefid_4)
                                        : [];
                                $this->data['number_letter'] = $encaissement
                                        ? $this->data('number_letter', $encaissement->Contrevaleur_22, 'CDF') : '';
                        }
                        elseif ($arg == "batch")
                        {
                                $batch_lines = $this->encaissementModel->get_paiement_batch_info($id);

                                $notes = json_decode($batch_lines->Paiements_23, true);

                                $i = 1;
                                for($i=1; $i<=count($notes['references']); $i++)
                                {
                                        $note = new \stdClass();

                                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $note->recette = $notes['recettes'][$i];
                                        $note->reference = $notes['references'][$i];
                                        $note->devise = $notes['devises'][$i];
                                        $note->amount = $amount;

                                        $tables[] = $note;
                                }

                                $logirefid = $batch_lines->Lot_24;

                                $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($logirefid);

                                $encaissement = $this->encaissementModel->get_paiement_tresor_by_logirefid($logirefid);
                                $this->data['encaissement'] = $encaissement;
                                $this->data['number_letter'] = $this->data('number_letter',$batch_lines->Montant_13, $batch_lines->Devise_14);

                                $this->data['batch_lines'] = $batch_lines;
                                $this->data['failds'] = $tables;
                        }
                        elseif ($arg != "dgrk")
                        {
                                $this->data['failds'] = [];
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                $this->data['number_letter'] = $this->data('number_letter',$encaissement->Montant_11, $encaissement->Devise_12);
                        }


                         //get instuctions
                        if ($arg == "dgrk"):
                            $instrcutions = $this->data['instrcutions'] ?? [];
                        elseif($encaissement->Beneficaire_15 == "DGI"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGRAD" &&  $arg != "batch"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGDA"):

                            $instrcutions = $this->comptabilisationModel->get_instructions_dgda($encaissement->Sydonia_44);

                        endif;

                        $this->data['instrcutions'] = $instrcutions;

                        # Suite numerique
                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                        $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;
                        }

                        //$agence = $this->branchModel->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        $this->data['recettes'] = $recettes = $this->logirefModel->get_dropdown('recettes');
                        $this->data['services'] = $services = $this->logirefModel->get_dropdown('services');
                        $service_type = $this->data['service_type'] =$this->logirefModel->get_dropdown("type_services");
                        $commune_services =$this->logirefModel->get_dropdown("commune_services");

                        # Treatment of information returned by the CBS
                        //$comptes_dgi = $this->integrationModel->get_instructions_dgis();
                        //$comptes_dgrad = $this->comptabilisationModel->get_instructions_dgrad();

                        # Treatment of information returned by the CBS
                        $cbs_return = ($arg == "dgrk") ? [] : (($arg == "batch") ?
                                $this->integrationModel->get_cbs_returns($batch_lines->Lot_24)
                                : $this->integrationModel->get_cbs_returns($id));

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        # Génération du QR Code
                        $qrcode_data = [];
                        $qrcode_data[] = "N° Attestation : ".$number. "/DGI/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y',strtotime($encaissement->Date_1));
                        $qrcode_data[] = "Référence de paiement : "
                                        . (isset($cbs_return[$instrcutions[0]->Id_0]['Num_evenement'])
                                                ? $cbs_return[$instrcutions[0]->Id_0]['Num_evenement']
                                                : "");

                        $qrcode_data[] = "Designation : ".$encaissement->Designation_14;
                        $qrcode_data[] = "Bénéficiaire : ".$encaissement->Beneficaire_15;
                        if ($encaissement->Beneficaire_15 == "DGI")
                        {
                                $infos = json_decode($encaissement->Notereference_30, true);
                                $date = explode('-', $infos["standard"] ?? "");
                                if (count($date) == 3):
                                        $periode_mois = $date[1];
                                        $periode_annee = $date[0];
                                elseif (count($date) == 2):
                                        $periode_mois = $date[0];
                                        $periode_annee = $date[1];
                                else:
                                        $periode_mois = "";
                                        $periode_annee = "";
                                endif;
                                $qrcode_data[] = "Période : ". $months[$periode_mois].'  '.$periode_annee ;
                                $qrcode_data[] = "Recette : ". $recettes["DGI"][$encaissement->Typerecette_17] ?? "..................."; 
                        }

                        if ($encaissement->Beneficaire_15 == "DGRAD")
                                $qrcode_data[] = "Recette : ". $recettes["DGRAD"][$encaissement->Typerecette_17] ?? "...................";

                        $qrcode_data[] = "Service : ". $services[$encaissement->Service_16] ?? "...................";

                        if ($arg == "batch"):
                                $qrcode_data[] = "Montant : ".$batch_lines->Devise_14.' '.number_format($batch_lines->Montant_13,2,","," ");
                                $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$batch_lines->Montant_13, $batch_lines->Devise_14);
                        else:
                                $qrcode_data[] = "Montant : ".$encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," ");
                                $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        endif;

                        $qrcode_data = implode("\n", $qrcode_data);

                        # Créer un QR Code sans label
                        $result = Builder::create()
                                ->writer(new PngWriter())
                                ->writerOptions([])
                                ->data($qrcode_data)
                                ->encoding(new Encoding('UTF-8'))
                                //->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                                ->size(180)
                                ->margin(10)
                                //->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                                ->build();

                        # Obtenir l'image du QR code
                        $qrCodeImageString = $result->getString();

                        # Encodage en base64 de l'image du QR code
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');

                        if($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27022470")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name .'\_attestation_taxegardienage', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27421600")
                        {
                                $modes = $this->encaissementModel->modes;
                                // Données à envoyer
                                $data_params['passport_number'] = $encaissement->Typerecette_17;
                                $data_params['requester_name'] = $encaissement->Designation_14;
                                $data_params['request_reference'] = $encaissement->Noteid_26;
                                $data_params['payment_date'] = $encaissement->Date_1;
                                $data_params['payment_method'] = isset($modes[$encaissement->Mode_19]) ? $modes[$encaissement->Mode_19]:"";

                                $encrypted_data = json_encode($data_params);

                                // Conversion en JSON avant chiffrement
                                $return_data = $this->data('encrypt_data', $encrypted_data);

                                // Génération de l'URL sécurisée
                                $url = "http://34.133.93.180/qrcode/equitybcdc/preview.php?data=" . urlencode($return_data);
                                //$params['data'] = $url;

                                //$params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
                                $params['data'] = $encaissement->Designation_14. ' '.$encaissement->Montant_11. ' USD ' .$encaissement->Noteid_26. ' ' .$encaissement->Datevaleur_31;
                                $params['level'] = 'H';
                                $params['size'] = '4';
                                $this->data['qrcode'] = $params['savename'] = $dir.$this->data['encaissement']->Logirefid_4.'.png';

                                $qrcode_data = implode("\n", $qrcode_data);

                                # Créer un QR Code sans label
                                $result = Builder::create()
                                        ->writer(new PngWriter())
                                        ->writerOptions([])
                                        ->data($qrcode_data)
                                        ->encoding(new Encoding('UTF-8'))
                                        //->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                                        ->size(180)
                                        ->margin(10)
                                        //->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                                        ->build();

                                # Obtenir l'image du QR code
                                $qrCodeImageString = $result->getString();

                                # Encodage en base64 de l'image du QR code
                                $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                                $this->data['qrcode'] = $qrCodeHtml;

                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_passport_agence', $this->data, true);
                        }
                        elseif($arg == "dgrk")
                        {
                                $bank_name = ltrim($this->bank, '@');
                                $bankDgrkView = APPPATH . 'Modules/Branch/Views/impression/' . $bank_name . '/_attestation_dgrk.php';
                                $html = file_exists($bankDgrkView)
                                        ? view('\\Modules\\Branch\\Views\\impression\\' . $bank_name . '\\_attestation_dgrk', $this->data)
                                        : view('\\Modules\\Branch\\Views\\impression\\_attestation_dgrk', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGRAD" && ($encaissement->IsBatchflag_59 ?? '' == "1"))
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_batch_dgrad', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGRAD")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgrad', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGDA")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgda', $this->data);
                        }
                        elseif ($encaissement->Beneficaire_15 == "DGI")
                        {

                                $service = $service_type[$encaissement->Service_16] ?? "";
                                $type    = $encaissement->Typerecette_17 ?? "";

                                /*
                                |--------------------------------------------------------------------------
                                | CAS AMRA
                                |--------------------------------------------------------------------------
                                */
                                if ($type == "AMRA")
                                {
                                        $view_path = APPPATH . "Modules/Branch/Views/impression/{$bank_name}/_attestation_dge_amra.php";

                                        if (file_exists($view_path) && $service != "CIS")
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dge_amra", $this->data);
                                        }
                                        else
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dgi_amra", $this->data);
                                        }
                                }
                                /*
                                |--------------------------------------------------------------------------
                                | CAS IPRIER / IRPPDR11
                                |--------------------------------------------------------------------------
                                */
                                elseif ($type == "IPRIER" || $type == "IRPPDR11")
                                {

                                        if ($service == "DGE" || $service == "CDI")
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_cdi", $this->data);
                                        }
                                        elseif ($service == "CIS")
                                        {
                                                if (($_SESSION['userdata']['account_id'] ?? "") === "36")
                                                {
                                                        $infos = json_decode($encaissement->Notereference_30, true);
                                                        $infos = is_array($infos) ? $infos : [];

                                                        $hasDGI  = !empty($infos['QuotasDGI']);
                                                        $hasINPP = !empty($infos['QuotasINPP']);
                                                        $hasINSS = !empty($infos['QuotasINSS']);
                                                        $hasONEM = !empty($infos['QuotasONEM']);

                                                        if (($hasDGI + $hasINPP + $hasINSS + $hasONEM) === 1)
                                                        {
                                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dgi_iprier", $this->data);
                                                        }
                                                        else
                                                        {
                                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_cdi", $this->data);
                                                        }
                                                }
                                                else
                                                {
                                                        $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dgi_iprier", $this->data);
                                                }
                                        }
                                }
                                /*
                                |--------------------------------------------------------------------------
                                | AUTRES RECETTES
                                |--------------------------------------------------------------------------
                                */
                                else
                                {
                                        if ($service == "DGE")
                                        {
                                                if ($type == "TVA")
                                                {
                                                        $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dge", $this->data);
                                                }
                                                else
                                                {
                                                        $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dge_htva", $this->data);
                                                }
                                        }
                                        elseif ($service == "CDI")
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_cdi", $this->data);
                                        }
                                        elseif ($service == "CIS")
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_cis_amra", $this->data);
                                        }
                                        else
                                        {
                                                $html = view("\Modules\Branch\Views\impression\\{$bank_name}\_attestation_dgi", $this->data);
                                        }
                                }
                        }

                        #$html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        // $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        // Chemin complet du fichier
                        $pdfDir      = "./drive/logiref/" . $account_id . "/attestation/";
                        $pdfFilePath = $pdfDir . $id . "_" . $user_id . "_" . time() . ".pdf";

                        /* $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file
                        $path = $baseDir . "/drive/logs/services/Finacle_standardbank"; */

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        // if ( $bank_name  == "standardbank")
                        // {
                        //         // Chemin absolu correct pour Windows + Linux
                        //         $filename_attest = ($arg == "DUP") ? "attestation_dup.png" : "attestation.png";
                        //         $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "standardbank" . DIRECTORY_SEPARATOR . $filename_attest;

                        //         // mPDF va lire l'image correctement
                        //         $this->mpdf->SetWatermarkImage($imagePath);
                        //         $this->mpdf->showWatermarkImage = true;
                        //         $this->mpdf->watermarkImageAlpha = 0.5; // Transparence de l'image (valeur entre 0 et 1)
                        // }

                        if ( $bank_name  == "rawbank")
                        {
                                // Chemin absolu correct pour Windows + Linux
                                $filename_attest = "attestation.png";
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "rawbank" . DIRECTORY_SEPARATOR . $filename_attest;

                                // mPDF va lire l'image correctement
                                $this->mpdf->SetWatermarkImage($imagePath);
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 1;
                        }

                        //actually, you can pass mPDF parameter on this load() function
                        // Chemin vers votre image à utiliser comme arrière-plan
                        //$imagePath = base_url('ikwook_files/images/solidairebanque/attestation.jpg');

                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119);
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        # Génération + Sauvegarde
                        $this->mpdf->Output($pdfFilePath, 'F');

                        # Vérification + Mise à jour
                        if (file_exists($pdfFilePath))
                        {
                                if ($arg == "batch")
                                {
                                        $print_attestation = ($batch_lines->Printattestation_35) ? (int) $batch_lines->Printattestation_35 : 0;
                                        $print_attestation++;

                                        $print_data['Printattestation_35']  = $print_attestation;
                                        $this->encaissementModel->save_payment_tresor_batch($print_data, $id);
                                }
                                else
                                {
                                        # Récupère la valeur actuelle de Printattestation_57, ou 0 si elle n'est pas définie
                                        $print_attestation = isset($encaissement->Printattestation_57) ? (int) $encaissement->Printattestation_57 : 0;

                                        // Incrémente le compteur d'attestations imprimées
                                        $print_attestation++;

                                        $print_data['Printattestation_57']  = $print_attestation;

                                        // Met à jour le paiement dans la base de données
                                        $this->encaissementModel->update_payment_tresor($print_data, $id);
                                }

                                # Envoi au navigateur
                                $this->mpdf->Output($pdfFilePath, 'I');
                                exit;
                        }
                        else
                        {
                                // log_message('error', "Échec génération attestation paiement ID {$id} par user {$user_id}");
                                // show_error("Erreur lors de la génération du fichier PDF. Veuillez réessayer.", 500);
                        }
                }
                elseif($obj == "attestation_passeport")
                {


                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $months=  $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
    
                         # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');

                        $encaissement = $this->passportModel->get_paiement_info($id);
                        $this->data["encaissement"] = $encaissement;

                        $modes = $this->encaissementModel->modes;
                        // Données à envoyer
                        $data_params['passport_number'] = $encaissement->Typerecette_17;
                        $data_params['requester_name'] = $encaissement->Designation_14;
                        $data_params['request_reference'] = $encaissement->Noteid_26;
                        $data_params['payment_date'] = $encaissement->Date_1;
                        $data_params['payment_method'] = isset($modes[$encaissement->Mode_19]) ? $modes[$encaissement->Mode_19]:"";

                        $encrypted_data = json_encode($data_params);

                        // Conversion en JSON avant chiffrement
                        $return_data = $this->data('encrypt_data', $encrypted_data);


                        # Suite numerique
                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                        $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;
                        }

                        //$agence = $this->branchModel->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        $this->data['recettes'] = $recettes = $this->logirefModel->get_dropdown('recettes');
                        $this->data['services'] = $services = $this->logirefModel->get_dropdown('services');
                        $service_type = $this->data['service_type'] =$this->logirefModel->get_dropdown("type_services");
                        $commune_services =$this->logirefModel->get_dropdown("commune_services");

                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Montant_11,$encaissement->Devise_12);

                        // Génération de l'URL sécurisée
                        $url = "http://34.133.93.180/qrcode/equitybcdc/preview.php?data=" . urlencode($return_data);
                        //$params['data'] = $url;

                        //$params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
                        $params['data'] = $encaissement->Designation_14. ' '.$encaissement->Montant_11. ' USD ' .$encaissement->Noteid_26. ' ' .$encaissement->Datevaleur_31;
                        $params['level'] = 'H';
                        $params['size'] = '4';


                        // $this->data['qrcode'] = $params['savename'] = $dir.$this->data['encaissement']->Logirefid_4.'.png';

                        // $qrcode_data = implode("\n", $qrcode_data);

                        # Créer un QR Code sans label
                        $result = Builder::create()
                                ->writer(new PngWriter())
                                ->writerOptions([])
                                ->data($return_data)
                                ->encoding(new Encoding('UTF-8'))
                                //->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                                ->size(180)
                                ->margin(10)
                                //->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                                ->build();

                        # Obtenir l'image du QR code
                        $qrCodeImageString = $result->getString();

                        # Encodage en base64 de l'image du QR code
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_passport_agence', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        // $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        // Chemin complet du fichier
                        $pdfDir      = "./drive/logiref/" . $account_id . "/attestation/";
                        $pdfFilePath = $pdfDir . $id . "_" . $user_id . "_" . time() . ".pdf";

                        /* $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file
                        $path = $baseDir . "/drive/logs/services/Finacle_standardbank"; */

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119);
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        # Génération + Sauvegarde
                        $this->mpdf->Output($pdfFilePath, 'F');

                        # Vérification + Mise à jour
                        if (file_exists($pdfFilePath))
                        {
                                # Envoi au navigateur
                                $this->mpdf->Output($pdfFilePath, 'I');
                                exit;
                        }
                        else
                        {
                                log_message('error', "Echec generation attestation passeport ID {$id} par user {$user_id}");
                        }

                }
                elseif ($obj == "email_passport")
                {
                        $account_id = $this->session->userdata['account_id'];
                        $dir        = "./drive/logiref/{$account_id}/passeport/";

                        # Création du dossier si nécessaire
                        if (!is_dir($dir)) mkdir($dir, 0777, true);

                        #Recherche du fichier PDF
                        $files = glob($dir . $id . "_*_passeport.pdf");
                        $pdfFilePath = !empty($files) ? $files[0] : $this->display('attestation', $id, "passport_agence");

                        # Récupération des infos paiement
                        $paiement = $this->encaissementModel->get_paiement_info($id);

                        $date          = strftime('%d/%m/%Y', strtotime($paiement->Datevaleur_31));
                        $email_address = $paiement->Email_54;
                        $customer      = $paiement->Designation_14;
                        $amount        = $paiement->Montant_11;
                        $commission    = $paiement->Commission_23;
                        $currency      = $paiement->Devise_12;
                        $ref_note      = $paiement->Noteid_26;
						$canal         = $paiement->Type_56;

                        # Envoi de l’email
                        $return = $this->mail->mail_send_proof_agence(
                                $email_address, $customer, 'fr',
                                $pdfFilePath, 'DGRAD_PASSPORT',
                                $amount, $commission, $currency,
                                $ref_note, $date, $canal
                        );

                        //echo $return;

                        #Réponse JSON propre
                        echo json_encode([
                                 'status' => $return ? 1 : 0,
                                 'file'   => $pdfFilePath,
                                 'error'  => $return ? null : 'Échec de l’envoi du mail'
                        ]);

                        exit;
                }
		elseif($obj == "export_passport")
                {
                        # Charger les modèles nécessaires
                        $modes = $this->logirefModel->modes;
                        $users = $this->mainModel->get_dropdown('users');
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        $status_list = $this->reportsModel->status;

                        # On détecte s’il y a un filtrage (POST) ou pas
                        $isFiltered = !empty($_POST['Status_2']) || !empty($_POST['start']) || !empty($_POST['Noteid_26']);

                        if ($isFiltered)
                        {
                                # Obtenir les paiements filtrés
                                $encaissements = $this->reportsModel->get_paiements_passport_dgrad();
                        }
                        else
                        {
                                $_POST['start'] = gmdate('Y-m-d');
                                $_POST['end']   = gmdate('Y-m-d');

                                # Obtenir les paiements filtrés
                                $encaissements  = $this->reportsModel->get_paiements_passport_dgrad();
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[11];

                        # load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        $objPHPExcel->setActiveSheetIndex(0);
                        $objPHPExcel->getActiveSheet()->setTitle('report_passport');

                        $style4Array = [
                                'font'  => [
                                        'bold'  => true,
                                        'color' => ['rgb' => '000000'],
                                        'size'  => 12,
                                        'name'  => 'Book Antiqua'
                                ]
                        ];

                        $table_columns = ["Date Paiement","Status","Regie","Recette","Client","Email","Note","Montant","Commission","Agence","Operateur"];
                        $column = 0;
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:K1')->applyFromArray($style4Array);

                        $erow = 2;
                        $paiements = 0;

                        foreach($encaissements as $row)
                        {
                                $infos = json_decode($row->Notereference_30);
                                $operateur = isset($users[$row->Makerid_9]) ? $users[$row->Makerid_9] : '-';
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, isset($status_list[$row->Status_2]) ? $status_list[$row->Status_2] : "-");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, (isset($row->Email_54) && $row->Email_54 != "") ? $row->Email_54 : (isset($infos->Email) ? $infos->Email : ''));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Noteid_26);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Devise_12.' '.number_format($row->Notemontant_28, 2, ",", " "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $row->Devise_12.' '.number_format($row->Commission_23, 2, ",", " "));
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, $operateur);

                                $paiements += $row->Notemontant_28;
                                $erow++;
                        }

                        // Ligne total
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "Montant général");
                        $objPHPExcel->getActiveSheet()->mergeCells("A{$erow}:F{$erow}");
                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, "USD ".number_format($paiements, 2, ",", " "));

                        for ($col = 'A'; $col <= 'K'; $col++) {
                                $objPHPExcel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Envoi du fichier
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="paiements_passport.xlsx"');
                        header('Cache-Control: max-age=0');
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        $objWriter->save('php://output');
                }
                elseif($obj == "attestation_immatriculation")
                {
                        $this->invLogirefModel = new \Modules\Logiref\Models\InvLogirefModel();
                        $this->invComptabilisationModel = new \Modules\Services\Comptabilisation\Models\InvComptabilisationModel();

                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $months = $this->invComptabilisationModel->months;
                        $this->data['months_abrv'] = $this->invComptabilisationModel->months_abrv;

                        $integration = $this->immatriculationModel->get_integration_immatriculation($id);

                        if($this->is_license_plate_web_service_validation_enabled()
                                && (empty($integration)
                                        || !$this->immatriculationModel->check_print_attestation($integration->Logirefid_31)))
                        {
                                return $this->response
                                        ->setStatusCode(403)
                                        ->setBody('La preuve de paiement sera disponible après l’intégration complète des deux séquences.');
                        }

                        $this->data['encaissement'] = $encaissement = $this->immatriculationModel->immatriculation_migrate_note($integration->Id_0);
                        $this->data['number_letter'] = $this->data('number_letter', $encaissement->Notemontant_28, $encaissement->Notedevise_29);

                        $instrcutions = $this->invComptabilisationModel->get_instructions_immatriculation_by_id($integration->Id_0);

                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $this->data['instrcutions'] = $instrcutions;

                        if ($id != '') {
                                $number = '';
                                $nb = strlen($id);
                                $iteration = 10 - $nb;

                                for ($i = 1; $i <= $iteration; $i++) {
                                        $number .= '0';
                                }
                                $number .= $id;

                                $this->data['number'] = $number;
                        }

                        $agences = $this->invLogirefModel->get_guichet_info($integration->Guichet_32);

                        $this->data['ville'] = ($agences->Ville_7 ?? '') ?: '...................';
                        $this->data['agences'] = ($agences->Nom_4 ?? '') ?: '...................';

                        //$this->data['recettes'] = $recettes = $this->logirefModel->get_dropdown('recettes');
                        $this->data['recettes'] = $recettes = $this->invLogirefModel->get_recettes_immatric($this->session->userdata['account_id']);
                        $this->data['services'] = $services = $this->invLogirefModel->get_dropdown('services');

                        $cbs_return = $this->immatriculationModel->get_cbs_returns_immatriculation($id);

                        if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        // QR CODE
                        $qrcode_data = [];

                        $qrcode_data[] = "N° Attestation : ".$number."/DGI/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y', strtotime($encaissement->Date_1));

                        $qrcode_data[] = "Référence de paiement : "
                                . ($cbs_return[$instrcutions[0]->Id_0]['Num_evenement'] ?? "");

                        if ($encaissement->Beneficaire_15 == "DGI") {
                                $qrcode_data[] = "Recette : "
                                . ($recettes["DGI"][$encaissement->Typerecette_17] ?? "...................");
                        }

                        $qrcode_data[] = "Montant : ".$encaissement->Devise_12.' '
                                .number_format($encaissement->Montant_11,2,","," ");

                        $qrcode_data[] = "Montant (en lettre) : "
                                .$this->data('number_letter',$encaissement->Notemontant_28, $encaissement->Notedevise_29);

                        $qrcode_data[] = "Designation : ".$encaissement->Designation_14;
                        $qrcode_data[] = "Bénéficiaire : ".$encaissement->Beneficaire_15;

                        $qrcode_data = implode("\n", $qrcode_data);

                        $result = Builder::create()
                                ->writer(new PngWriter())
                                ->data($qrcode_data)
                                ->encoding(new Encoding('UTF-8'))
                                ->size(180)
                                ->margin(10)
                                ->build();

                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($result->getString()) . '">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        $bank_name = ltrim($this->bank, '@');

                        $html = view(
                                '\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_immatriculation',
                                $this->data
                        );

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];

                        $pdfDir = "./drive/logiref/" . $account_id . "/attestation/";

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        $pdfFilePath = $path . $id . "_" . $user_id . "_" . time() . ".pdf";

                        $this->mpdf->SetMargins(10, 10, 10);

                        /*
                        ======================================================
                        PAGE 1 : AVEC IMAGE DE FOND
                        ======================================================
                        */
                        $this->mpdf->AddPage();

                        if ($bank_name == "standardbank" || $bank_name == "rawbank") {

                                $filename_attest = "Attestation.jpg";

                                if ($bank_name == "standardbank" && isset($arg) && $arg == "DUP") {
                                        $filename_attest = "attestation_dup.png";
                                }

                                if ($bank_name == "rawbank") {
                                        $filename_attest = "Attestation.png";
                                }

                                $imagePath = FCPATH . "ikwook_files/images/$bank_name/$filename_attest";

                                $this->mpdf->SetWatermarkImage($imagePath);
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = ($bank_name == "standardbank") ? 0.5 : 0.4;
                                $this->mpdf->watermarkImgBehind = true;
                        }
                        elseif($bank_name == "equitybcdc")
                        {
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR
                                        . "images" . DIRECTORY_SEPARATOR
                                        . "equitybcdc" . DIRECTORY_SEPARATOR
                                        . "attestation-online.png";

                                $this->mpdf->SetWatermarkImage($imagePath, 1, 'P', 'P');
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 1;
                                $this->mpdf->watermarkImgBehind = true;
                        }

                        $this->mpdf->WriteHTML($html, 2);

                        /*
                        ======================================================
                        PAGE 2 : SONAS SANS IMAGE DE FOND EQUITYBCDC
                        ======================================================
                        */
                        $Notereference_30 = json_decode($encaissement->Notereference_30, true);
                        $beneficiaires = $Notereference_30['beneficiaries'];

                        $beneficiarie = [];

                        foreach ($beneficiaires as $beneficiary)
                        {
                                if ($beneficiary['beneficiary_code'] == "SONAS")
                                {
                                        $beneficiarie[] = $beneficiary;
                                }
                        }

                        if (!empty($beneficiarie)) {

                                $this->mpdf->AddPage();

                                $this->mpdf->showWatermarkImage = false;
                                $this->mpdf->SetWatermarkImage('');

                                $vehicule = $Notereference_30['vehicule'] ?? [];

                                $data = [
                                        "Numero_note" => $encaissement->Noteid_26,
                                        "Marque_vehicule" => $vehicule['Brand_10'] ?? "__",
                                        "Modele_vehicule" => $vehicule['Model_11'] ?? "__",
                                        "Numero_chassis" => $vehicule['ChassisNumber_8'] ?? "__",
                                        "Couleur_vehicule" => $vehicule['Color_14'] ?? "__",
                                        "Designation" => $encaissement->Designation_14,
                                        "qrcode" => $this->data['qrcode']
                                ];

                                $qrcode_data = [];
                                $qrcode_data[] = "Date : ".strftime('%d-%m-%Y', strtotime($encaissement->Date_1));
                                $qrcode_data[] = "Numéro de la note : ".$data["Numero_note"];
                                $qrcode_data[] = "Bénéficiaire : SONAS";

                                $result = Builder::create()
                                        ->writer(new PngWriter())
                                        ->data(implode("\n", $qrcode_data))
                                        ->encoding(new Encoding('UTF-8'))
                                        ->size(180)
                                        ->margin(10)
                                        ->build();

                                $data['qrcode'] = '<img src="data:image/png;base64,' . base64_encode($result->getString()) . '">';

                                $html_sonas = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_sonas',$data);

                                $this->mpdf->WriteHTML($html_sonas, 2);
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "email_immatriculation")
                {
                        $this->invLogirefModel = new \Modules\Logiref\Models\InvLogirefModel();
                        $this->invComptabilisationModel = new \Modules\Services\Comptabilisation\Models\InvComptabilisationModel();

                        $integration = $this->immatriculationModel->get_integration_immatriculation($id);

                        if($this->is_license_plate_web_service_validation_enabled()
                                && (empty($integration)
                                        || !$this->immatriculationModel->check_print_attestation($integration->Logirefid_31)))
                        {
                                return $this->response->setStatusCode(403)->setJSON([
                                        'code' => 403,
                                        'error' => 'La preuve de paiement sera disponible après l’intégration complète des deux séquences.'
                                ]);
                        }

                        $this->immatriculationModel->save_log("Début envoi email | noteId: $integration->Reference_6", "send_email");

                        $data = array();
                        $data['typeDoc'] = $this->invLogirefModel->documents;
                        $data['devises'] = $this->invLogirefModel->devises;
                        $data['modes']   = $this->encaissementModel->modes;
                        $data['months']  = $months =  $this->invComptabilisationModel->months;
                        $data['months_abrv'] = $this->invComptabilisationModel->months_abrv;
                        $data['users']       = $this->invLogirefModel->get_users_immatric($this->session->userdata['account_id']);
                        $beneficiaires       = $data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $data['encaissement'] = $encaissement = $this->immatriculationModel->immatriculation_migrate_note($integration->Id_0);
                        $data['number_letter'] = $this->data('number_letter', $encaissement->Notemontant_28, $encaissement->Notedevise_29);

                        //get instuctions
                        $instrcutions = $this->invComptabilisationModel->get_instructions_immatriculation_by_id($integration->Id_0);

                        $data['instrcutions'] = $instrcutions;

                        # Suite numerique
                        if($integration->Reference_6 !='')
                        {
                                $number = '';
                                $nb = strlen($integration->Reference_6);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                        $number .= '0';
                                }
                                $number = $number.$integration->Reference_6;

                                $data['number'] = $number;
                        }

                        $agences = $this->invLogirefModel->get_guichet_info($integration->Guichet_32);

                        $data['ville']    = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $data['agences']  = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        $data['recettes'] = $recettes = $this->invLogirefModel->get_recettes_immatric($this->session->userdata['account_id']);
                        $data['services'] = $services = $this->invLogirefModel->get_dropdown('services');
                        $data['service_type'] = $this->logirefModel->get_dropdown("type_services");
                        $data['account_business'] = $this->session->userdata['account_business'];

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->immatriculationModel->get_cbs_returns_immatriculation($integration->Reference_6);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $data['cbs_return'] = $cbs_return;
                        }

                        # Génération du QR Code
                        $qrcode_data = [];
                        $qrcode_data[] = "N° Attestation : ".$number. "/DGI/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y',strtotime($encaissement->Date_1));
                        $qrcode_data[] = "Référence de paiement : "
                                        . (isset($cbs_return[$instrcutions[0]->Id_0]['Num_evenement'])
                                                ? $cbs_return[$instrcutions[0]->Id_0]['Num_evenement']
                                                : "");

                        if ($encaissement->Beneficaire_15 == "DGI")
                        {
                                $qrcode_data[] = "Recette : ". $recettes["DGI"][$encaissement->Typerecette_17] ?? "...................";
                        }

                        $qrcode_data[] = "N° Attestation : ".$number. "/".$encaissement->Beneficaire_15."/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y',strtotime($encaissement->Date_1));
                        $qrcode_data[] = "Référence de paiement : ".(isset($cbs_return[$instrcutions[0]->Id_0]['Num_evenement'])?$cbs_return[$instrcutions[0]->Id_0]['Num_evenement']:"") ?? "";
                        $qrcode_data[] = "Designation : ".$encaissement->Designation_14;
                        $qrcode_data[] = "Bénéficiaire : ".$encaissement->Beneficaire_15;
                        $qrcode_data[] = "Service : ". $services[$encaissement->Service_16] ?? "...................";
                        $qrcode_data[] = "Montant : ".$encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," ");
                        $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$encaissement->Notemontant_28, $encaissement->Notedevise_29);

                        $qrcode_data = implode("\n", $qrcode_data);

                        # Créer un QR Code sans label
                        $result = Builder::create()
                                ->writer(new PngWriter())
                                ->writerOptions([])
                                ->data($qrcode_data)
                                ->encoding(new Encoding('UTF-8'))
                                //->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                                ->size(180)
                                ->margin(10)
                                //->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                                ->build();

                        # Obtenir l'image du QR code
                        $qrCodeImageString = $result->getString();

                        # Encodage en base64 de l'image du QR code
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $data['qrcode'] = $qrCodeHtml;

                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');

                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_immatriculation', $data);

                        // Chemin complet du fichier
                        $pdfDir      = "./drive/logiref/" . $this->session->userdata['account_id'] . "/attestation/";
                        $pdfFilePath = $pdfDir . $integration->Reference_6 . "_" . $this->session->userdata['user_id'] . "_" . time() . ".pdf";

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        $this->mpdf->SetMargins(10, 10, 10);

                        $this->mpdf->AddPage();

                        if ($this->session->userdata['account_id'] == 44 && $bank_name != "equitybcdc")
                        {
                                // Chemin absolu correct pour Windows + Linux
                                $filename_attest = "Attestation.png";
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "rawbank" . DIRECTORY_SEPARATOR . $filename_attest;

                                // mPDF va lire l'image correctement
                                $this->mpdf->SetWatermarkImage($imagePath);
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 0.4;
                                $this->mpdf->watermarkImgBehind = true;
                        }
                        elseif($bank_name == "equitybcdc")
                        {
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR
                                        . "images" . DIRECTORY_SEPARATOR
                                        . "equitybcdc" . DIRECTORY_SEPARATOR
                                        . "attestation-online.png";

                                $this->mpdf->SetWatermarkImage($imagePath, 1, 'P', 'P');
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 1;
                                $this->mpdf->watermarkImgBehind = true;
                        }

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        if (!is_dir($pdfDir)) {
                                mkdir($pdfDir, 0777, true);
                        }

                        $pdfFilePath = $pdfDir . $integration->Reference_6 . "_" . $this->session->userdata['user_id'] . "_" . time() . ".pdf";

                        $this->mpdf->WriteHTML($html, 2);

                        /* =========================
                        PAGE 2 - SONAS SANS IMAGE DE FOND EQUITYBCDC
                        ========================= */

                        $beneficiarie = [];

                        $Notereference_30 = json_decode($encaissement->Notereference_30, true);
                        $beneficiaires = $Notereference_30['beneficiaries'] ?? [];

                        foreach($beneficiaires as $b) {
                                if($b['beneficiary_code'] == "SONAS") {
                                        $beneficiarie[] = $b;
                                }
                        }

                        if(!empty($beneficiarie))
                        {
                                $this->mpdf->AddPage();

                                $this->mpdf->showWatermarkImage = false;
                                $this->mpdf->SetWatermarkImage('');

                                $vehicule = $Notereference_30['vehicule'] ?? [];

                                $data2 = [
                                        "Numero_note" => $encaissement->Noteid_26,
                                        "Marque_vehicule" => $vehicule['Brand_10'] ?? "__",
                                        "Modele_vehicule" => $vehicule['Model_11'] ?? "__",
                                        "Numero_chassis" => $vehicule['ChassisNumber_8'] ?? "__",
                                        "Couleur_vehicule" => $vehicule['Color_14'] ?? "__",
                                        "Designation" => $encaissement->Designation_14,
                                        "qrcode" => $data['qrcode']
                                ];

                                $html_sonas = view('\Modules\Branch\Views\impression\\'.$bank_name.'\_attestation_sonas', $data2);

                                $this->mpdf->WriteHTML($html_sonas, 2);
                        }

                        /* =========================
                        SAVE PDF
                        ========================= */
                        $this->mpdf->Output($pdfFilePath, 'F');

                        $this->immatriculationModel->save_log("PDF généré: $pdfFilePath", "send_email");

                        if (!$integration)
                        {
                                $this->immatriculationModel->save_log("Erreur: données introuvables pour noteId: $integration->Reference_6","send_email");

                                echo json_encode([
                                        'status' => 0,
                                        'error'  => 'Informations introuvables',
                                ]);

                                exit;
                        }

                        $customerObj = json_decode($integration->Applicant_12);

                        $date          = strftime('%d/%m/%Y', strtotime($customerObj->Date_1));
                        $email_address = $customerObj->Email_16;
                        $customer      = $integration->Requerant_9;
                        $amount        = $integration->Amount_10;
                        $commission    = $integration->Commission_14;
                        $currency      = $integration->Devise_11;
                        $ref_note      = $integration->Reference_6;
                        $canal         = $integration->Type_38;

                        $this->immatriculationModel->save_log("Préparation email | email: $email_address | ref: $ref_note | montant: $amount $currency","send_email");

                        $return = $this->mail->mail_send_proof_agence($email_address, $customer, 'fr', $pdfFilePath, 'DGI_INV', $amount, $commission, $currency, $ref_note, $date, $canal);

                        if ($return) {
                                $this->immatriculationModel->save_log("Succès envoi email | noteId: $integration->Reference_6","send_email");
                        }
                        else {
                                $this->immatriculationModel->save_log("Echec envoi email | noteId: $integration->Reference_6","send_email");
                        }

                        $data = [
                                'Date_1'          => date("Y-m-d H:i:s"),
                                'Status_2'        => 1,
                                'Account_3'       => $this->session->userdata['account_id'],
                                'Noteid_4'        => $integration->Reference_6,
                                'Reference_5'     => $ref_note,
                                'Email_6'         => $email_address,
                                'Customer_7'      => $customer,
                                'Amount_8'        => $amount,
                                'Commission_9'    => $commission,
                                'Currency_10'     => $currency,
                                'Canal_11'        => $canal,
                                'Pdfpath_12'      => $pdfFilePath,
                                'Status_13'       => $return ? 1 : 0,
                                'ErrorMessage_14' => $return ? null : 'Echec envoi email'
                        ];

                        $this->immatriculationModel->save_email_log($data);

                        echo json_encode([
                                'status' => $return ? 1 : 0
                        ]);

                        exit;
                }
                elseif($obj == "attestation_dgnk")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;

                        $this->data['months'] = $months=  $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        if ($arg == "batch")
                        {
                                $batch_lines = $this->encaissementModel->get_paiement_batch_info($id);

                                $notes = json_decode($batch_lines->Paiements_23, true);

                                $i = 1;
                                for($i=1; $i<=count($notes['references']); $i++)
                                {
                                        $note = new \stdClass();

                                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $note->recette = $notes['recettes'][$i];
                                        $note->reference = $notes['references'][$i];
                                        $note->devise = $notes['devises'][$i];
                                        $note->amount = $amount;

                                        $tables[] = $note;
                                }

                                $logirefid = $batch_lines->Lot_24;

                                $encaissement = $this->encaissementModel->get_paiement_tresor_by_logirefid($logirefid);
                                $this->data['encaissement'] = $encaissement;
                                $this->data['number_letter'] = $this->data('number_letter',$batch_lines->Montant_13, $batch_lines->Devise_14);

                                $this->data['batch_lines'] = $batch_lines;
                                $this->data['failds'] = $tables;
                        }
                        else
                        {
                                // $integration = $this->integrationModel->get_integration_immatriculation($id);
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                                $this->data['number_letter'] = $this->data('number_letter',$encaissement->Montant_11, $encaissement->Devise_12);
                        }
                         //get instuctions
                        // $instrcutions = $this->comptabilisationModel->get_instructions_immatriculation_by_id($integration->Id_0);

                        $this->data['months'] = $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);

                        //$this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Montant_11, $encaissement->Devise_12);

                         //get instuctions
                        if($encaissement->Beneficaire_15 == "DGRK"):

                            $instructions = $this->comptabilisationModel->get_instructions_dgrk($encaissement->Logirefid_4);

                        elseif($encaissement->Beneficaire_15 == "DGPEK"):

                            $instructions = $this->comptabilisationModel->get_instructions_dgpek($encaissement->Logirefid_4);

                        endif;

                
                        $this->data['instrcutions'] = $instructions;

                        # Suite numerique
                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                        $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;
                        }

                        //$agence = $this->branchModel->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        $this->data['recettes'] = $recettes = $this->logirefModel->get_dropdown('recettes');
                        $this->data['services'] = $services = $this->logirefModel->get_dropdown('services');
                        $service_type = $this->data['service_type'] =$this->logirefModel->get_dropdown("type_services");
                        $commune_services =$this->logirefModel->get_dropdown("commune_services");

                        # Treatment of information returned by the CBS
                        //$comptes_dgi = $this->integrationModel->get_instructions_dgis();
                        //$comptes_dgrad = $this->comptabilisationModel->get_instructions_dgrad();

                        # Treatment of information returned by the CBS
                        $cbs_return = ($arg == "batch") ?
                                $this->integrationModel->get_cbs_returns($batch_lines->Lot_24)
                                : $this->integrationModel->get_cbs_returns($id);

                        $cbs_return = $this->integrationModel->get_cbs_returns($id);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }


                        # Génération du QR Code
                        $qrcode_data = [];

                        $qrcode_data[] = "N° Attestation : ".$number. "/DGI/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y',strtotime($encaissement->Date_1));
                        $qrcode_data[] = "Référence de paiement : "
                                        . (isset($cbs_return[$instructions[0]->Id_0]['Num_evenement'])
                                                ? $cbs_return[$instructions[0]->Id_0]['Num_evenement']
                                                : "");

                        $qrcode_data[] = "Designation : ".$encaissement->Designation_14;
                        $qrcode_data[] = "Bénéficiaire : ".$encaissement->Beneficaire_15;
                        if ($encaissement->Beneficaire_15 == "DGI")
                        {
                                $infos = json_decode($encaissement->Notereference_30, true);
                                $date = explode('-', $infos["standard"] ?? "");
                                if (count($date) == 3):
                                        $periode_mois = $date[1];
                                        $periode_annee = $date[0];
                                elseif (count($date) == 2):
                                        $periode_mois = $date[0];
                                        $periode_annee = $date[1];
                                else:
                                        $periode_mois = "";
                                        $periode_annee = "";
                                endif;
                                $qrcode_data[] = "Période : ". $months[$periode_mois].'  '.$periode_annee ;
                                $qrcode_data[] = "Recette : ". $recettes["DGI"][$encaissement->Typerecette_17] ?? "..................."; 
                        }

                        if ($encaissement->Beneficaire_15 == "DGRAD")
                                $qrcode_data[] = "Recette : ". $recettes["DGRAD"][$encaissement->Typerecette_17] ?? "...................";

                        $qrcode_data[] = "Service : ". $services[$encaissement->Service_16] ?? "...................";

                        if ($arg == "batch"):
                                $qrcode_data[] = "Montant : ".$batch_lines->Devise_14.' '.number_format($batch_lines->Montant_13,2,","," ");
                                $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$batch_lines->Montant_13, $batch_lines->Devise_14);
                        else:
                                $qrcode_data[] = "Montant : ".$encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," ");
                                $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        endif;

                        $qrcode_data[] = "N° Attestation : ".$number. "/".$encaissement->Beneficaire_15."/".gmdate("Y");
                        $qrcode_data[] = "Date : ".strftime('%d-%m-%Y',strtotime($encaissement->Date_1));
                        $qrcode_data[] = "Référence de paiement : ".($cbs_return[$instructions[0]->Id_0]['Num_evenement']) ?? "";
                        $qrcode_data[] = "Designation : ".$encaissement->Designation_14;
                        $qrcode_data[] = "Bénéficiaire : ".$encaissement->Beneficaire_15;

                        if ($encaissement->Beneficaire_15 == "DGRK")
                                $qrcode_data[] = "Recette : ". $recettes["DGRK"][$encaissement->Typerecette_17] ?? "...................";
                        if ($encaissement->Beneficaire_15 == "DGPEK")
                                $qrcode_data[] = "Recette : ". $recettes["DGPEK"][$encaissement->Typerecette_17] ?? "...................";
                        $qrcode_data[] = "Service : ". $services[$encaissement->Service_16] ?? "...................";
                        $qrcode_data[] = "Montant : ".$encaissement->Devise_12.' '.number_format($encaissement->Montant_11,2,","," ");
                        $qrcode_data[] = "Montant (en lettre) : ".$this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');

                        $qrcode_data = implode("\n", $qrcode_data);

                        # Créer un QR Code sans label
                        $result = Builder::create()
                                ->writer(new PngWriter())
                                ->writerOptions([])
                                ->data($qrcode_data)
                                ->encoding(new Encoding('UTF-8'))
                                //->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                                ->size(180)
                                ->margin(10)
                                //->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                                ->build();

                        # Obtenir l'image du QR code
                        $qrCodeImageString = $result->getString();

                        # Encodage en base64 de l'image du QR code
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');


                        if($encaissement->Beneficaire_15 == "DGRK")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgrk', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGPEK")
                        {
                               $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgpek', $this->data);
                        }

                        var_dump($html);die;

                        #$html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        // $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        // Chemin complet du fichier
                        $pdfDir      = "./drive/logiref/" . $account_id . "/attestation/";
                        $pdfFilePath = $pdfDir . $id . "_" . $user_id . "_" . time() . ".pdf";


                        /* $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file
                        $path = $baseDir . "/drive/logs/services/Finacle_standardbank"; */

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        // if ( $bank_name  == "standardbank")
                        // {
                        //         // Chemin absolu correct pour Windows + Linux
                        //         $filename_attest = ($arg == "DUP") ? "attestation_dup.png" : "attestation.png";
                        //         $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "standardbank" . DIRECTORY_SEPARATOR . $filename_attest;

                        //         // mPDF va lire l'image correctement
                        //         $this->mpdf->SetWatermarkImage($imagePath);
                        //         $this->mpdf->showWatermarkImage = true;
                        //         $this->mpdf->watermarkImageAlpha = 0.5; // Transparence de l'image (valeur entre 0 et 1)
                        // }

                        if ( $bank_name  == "standardbank")
                        {
                                // Chemin absolu correct pour Windows + Linux
                                $filename_attest = ($arg == "DUP") ? "attestation_dup.png" : "attestation.jpg";
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "standardbank" . DIRECTORY_SEPARATOR . $filename_attest;

                                // mPDF va lire l'image correctement
                                $this->mpdf->SetWatermarkImage($imagePath);
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 0.5; // Transparence de l'image (valeur entre 0 et 1)
                        }

                        if ( $bank_name  == "rawbank")
                        {
                                // Chemin absolu correct pour Windows + Linux
                                $filename_attest = "attestation.png";
                                $imagePath = FCPATH . "ikwook_files" . DIRECTORY_SEPARATOR . "images" . DIRECTORY_SEPARATOR  . "rawbank" . DIRECTORY_SEPARATOR . $filename_attest;

                                // mPDF va lire l'image correctement
                                $this->mpdf->SetWatermarkImage($imagePath);
                                $this->mpdf->showWatermarkImage = true;
                                $this->mpdf->watermarkImageAlpha = 1;
                        }


                        //actually, you can pass mPDF parameter on this load() function
                        // Chemin vers votre image à utiliser comme arrière-plan
                        //$imagePath = base_url('ikwook_files/images/solidairebanque/attestation.jpg');

                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119);

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        # Génération + Sauvegarde
                        $this->mpdf->Output($pdfFilePath, 'F');

                        # Vérification + Mise à jour
                        if (file_exists($pdfFilePath))
                        {
                                # Récupère la valeur actuelle de Printattestation_57, ou 0 si elle n'est pas définie
                                $print_attestation = isset($encaissement->Printattestation_56) ? (int) $encaissement->Printattestation_56 : 0;

                                // Incrémente le compteur d'attestations imprimées
                                $print_attestation++;

                                $print_data['Printattestation_56']  = $print_attestation;

                                // Met à jour le paiement dans la base de données
                                $this->encaissementModel->update_payment_propres($print_data, $encaissement->Logirefid_4);

                                # Envoi au navigateur
                                $this->mpdf->Output($pdfFilePath, 'I');
                                exit;
                        }
                        else
                        {
                                // log_message('error', "Échec génération attestation paiement ID {$id} par user {$user_id}");
                                // show_error("Erreur lors de la génération du fichier PDF. Veuillez réessayer.", 500);
                        }

                }
                elseif($obj=="attestationbl")
                {
                        //var_dump("Oui");die;
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['villes'] = $this->logirefModel->get_dropdown('parameter', 'VILLE');
                        $this->data['users'] = $this->logirefModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $encaissement = $this->encaissementModel->get_paiement_tresor_bl($id);
                      
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_paiement_propres_bl($id);
                        }

                        //$encaissement->Beneficaire_15 = 'DGDA';
                        //$encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        //$this->data['encaissement'] = $encaissement;
                        //$guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        //$this->data['ville'] = ($guichet->Ville_7!="")? $guichet->Ville_7 :'.................';
                        //$this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        //creation de qrcode
                        //$dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        //if(is_dir($dir)==false)
                        //{
                                //mkdir($dir,0777,true);
                        //}

                        //$link = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['services'] = $this->logirefModel->get_dropdown('services');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $this->data['encaissements'] = $encaissement;
                
                        // var_dump($encaissement);die;
                        $this->data['number_letter'] = $this->data('number_letter',$bulletin->Amount_12, 'CDF');

                        # Suite numerique
                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                                $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;

                        }
                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Agence_32);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);
                       $num_evenement = '';
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;

                                foreach ($cbs_return as $values)
                                {
                                    if(isset($values["Num_evenement"]))
                                    $num_evenement = $values["Num_evenement"];
                                }
                        }
                        $this->data['num_evenement'] = $num_evenement;

                        $link = 'www.ikwook.com/logiref/code/';

                        // Créer un QR Code
                        $qrCode = $this->qrCodeBuilder
                            ->data($link)
                            ->encoding($this->qrCodeEncoding)
                            ->size(256)
                            ->margin(10)
                            ->build();
                        $qrCodeImageString = '';

                        $image = $qrCode->getImage();
                        if ($image instanceof \GdImage) {
                            ob_start();
                            imagepng($image);
                            $qrCodeImageString = ob_get_clean();
                        }

                        // Encodage en base64 si la chaîne de caractères de l'image est disponible
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        //$html = view('\Modules\Branch\Views\impression\_quittance', $this->data);
                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgda', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];

                        // Chemin complet du fichier
                        $pdfDir      = "./drive/logiref/" . $account_id . "/attestation/";
                        $pdfFilePath = $pdfDir . $id . "_" . $user_id . "_" . time() . ".pdf";
                        //$pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        // Normalize path slashes for Windows
                        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $pdfDir);

                        // Vérifier que le dossier existe, sinon le créer
                        if (!is_dir($path))
                        {
                                mkdir($path, 0777, true); // true = création récursive
                        }

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        # Génération + Sauvegarde
                        $this->mpdf->Output($pdfFilePath, 'F');

                        # Vérification + Mise à jour
                        if (file_exists($pdfFilePath)) 
                        {
                                # Récupère la valeur actuelle de Printattestation_57, ou 0 si elle n'est pas définie
                                $print_attestation = isset($bulletin->Printattestation_47) ? (int) $bulletin->Printattestation_47 : 0;

                                // Incrémente le compteur d'attestations imprimées
                                $print_attestation++;

                                $print_data['Printattestation_47']  = $print_attestation;

                                // Met à jour le paiement dans la base de données
                                $this->integrationModel->update_bulletin($print_data, $id);

                                # Envoi au navigateur
                                $this->mpdf->Output($pdfFilePath, 'I');
                                exit;
                        } 
                        else 
                        {
                                // log_message('error', "Échec génération attestation paiement ID {$id} par user {$user_id}");
                                // show_error("Erreur lors de la génération du fichier PDF. Veuillez réessayer.", 500);
                        }
                }
                elseif($obj == "attestation_permis")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_permis_info($id);

                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');

                        if($id !='')
                        {
                                $number = '';
                                $nb = strlen($id);

                                $iteration = 10 - $nb;

                                for($i=1; $i<=$iteration; $i++)
                                {
                                        $number .= '0';
                                }
                                $number = $number.$id;

                                $this->data['number'] = $number;
                        }

                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['services'] = $this->logirefModel->get_dropdown('services');
                        $service_type= $this->data['service_type'] =$this->logirefModel->get_dropdown("type_services");
                        $commune_services =$this->logirefModel->get_dropdown("commune_services");

                        $cbs_return = $this->integrationModel->get_cbs_returns($id);

                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }

                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';

                        $bank_name = ltrim($this->bank, '@');

                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgrad', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];

                        $pdfDir      = "./drive/logiref/" . $account_id . "/attestation/";
                        $pdfFilePath = $pdfDir . $id . "_" . $user_id . "_" . time() . ".pdf";

                        if (!is_dir($pdfDir))
                        {
                                mkdir($pdfDir, 0777, true);
                        }

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, 'F');
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'F');

                        if (file_exists($pdfFilePath))
                        {
                                $print_attestation = isset($encaissement->Printattestation_57) ? (int) $encaissement->Printattestation_57 : 0;

                                $print_attestation++;

                                $print_data['Printattestation_57']  = $print_attestation;

                                $this->encaissementModel->update_payment_tresor_permis($print_data, $id);

                                $this->mpdf->Output($pdfFilePath, 'I');
                                exit;
                        }
                }
                elseif($obj=="print_users")
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();

                        if(isset($_POST['members']) && $_POST['members'] !="")
                        {
                                $this->data['members'] = json_decode($_POST['members']);
                        }
                        else
                        {
                                $this->data['members'] = array();
                        }

                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);

                        $this->data['roles'] = $this->usersModel->role;

                        $this->load->model('MY_Main');
                        $this->load->model('main/mainModel');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_users', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;
                }

                elseif($obj=="print_client")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);

                        if(isset($_POST['encaissements']) && $_POST['encaissements'] !="")
                        {
                                $this->data['encaissements'] = json_decode($_POST['encaissements']);
                        }
                        else
                        {
                                $this->data['encaissements'] = array();
                        }

                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->load->model('MY_Main');
                        $this->load->model('main/mainModel');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_client', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;
                }
                elseif($obj=="print_gu_paiements_tresor")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_gu_paiements_tresor', $this->data, true);
                        
                        
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                } 
                elseif($obj=="print_others_taxes")
                {       
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $beneficiaries = $this->accountModel->get_dropdown("beneficiary_tax_others_banks");
                        
                        $instructions = $_SESSION['taxes_others_banks'];

                        $taxes = [];
                        
                        foreach($instructions as $row)
                        {
                                $taxes[$row->Codetaxe_28][] = $row;
                        }
                        
                        $this->data['taxes'] = $taxes;
                        $this->data['beneficiaries'] = $beneficiaries;
                        $this->data['comptes'] = $comptes;

                        
                        $html = view('\Modules\Branch\Views\impression\_print_others_taxes', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function

                        $this->mpdf->WriteHTML('', 1);
                        // La première page existe déjà : réserver l’espace de l’en-tête CRDB.
                        if (ltrim((string) $this->bank, '@') === 'crdbbank'
                                && strpos($html, 'name="crdbHeader"') !== false) {
                                // Même cadre pour le corps, les en-têtes et les pages suivantes.
                                $this->mpdf->DeflMargin = $this->mpdf->DefrMargin = 25.4;
                                $this->mpdf->orig_lMargin = $this->mpdf->orig_rMargin = 25.4;
                                $this->mpdf->SetMargins(25.4, 25.4, 38);
                                // SetMargins ne recalcule pas la largeur utile de la page déjà créée.
                                $this->mpdf->pgwidth = $this->mpdf->w - $this->mpdf->lMargin - $this->mpdf->rMargin;
                                $this->mpdf->SetAutoPageBreak(true, 25.4);
                                $this->mpdf->margin_header = 8;
                                $this->mpdf->margin_footer = 9;
                                $this->mpdf->SetY(38);
                        }
                        // Les modèles CRDB contiennent leur CSS dans <style>.
                        $this->mpdf->WriteHTML($html, ltrim((string) $this->bank, '@') === 'crdbbank'
                                ? \Mpdf\HTMLParserMode::DEFAULT_MODE
                                : \Mpdf\HTMLParserMode::HTML_BODY);

                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                      
                }
                elseif($obj=="print_gu_paiements_propres")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_gu_paiements_propres', $this->data, true);
                        
                        
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_paiements_gu")
                {
                        $this->data['office'] = $_POST['Office'];
                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                        {
                                
                                $bls = implode(',', $_POST['paiements']);
                                $this->data['bulletins'] = $this->integrationModel->get_bulletins_by_lot($bls);
                               
                                
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_paiements_gu', $this->data, true);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_bl")
                {
                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                        {
                                $this->data['bulletins'] = json_decode($_POST['bulletins']);
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_bl', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }

                elseif($obj=="print_commissions")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        if(isset($_POST['commissions']) && $_POST['commissions'] !="")
                        {
                                $p = $this->data['paiements'] = json_decode($_POST['commissions']);
                        }
                        else
                        {
                                $this->data['paiements'] = array();
                        }

                        $html = $this->load->view($this->module.'/banks/taximpression/_print_commissions', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);

                        $pdf->WriteHTML($html);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
                elseif($obj == "print_regles")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        if(isset($_POST['regles']) && $_POST['regles'] !="")
                        {
                                $this->data['regles'] = json_decode($_POST['regles']);
                        }
                        else
                        {
                                $this->data['regles'] = array();
                        }
                        
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_regles', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                       
                      
                        if(isset($_POST['comptes']) && $_POST['comptes'] !="")
                        {
                            
                                $this->data['comptes'] = json_decode($_POST['comptes']);
                                
                        }
                        else
                        {
                                $this->data['comptes'] = array();
                        }
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_comptes', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_penalites")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                       
                        $this->data['encaissements'] = (isset($_POST['encaissements']) && $_POST['encaissements'] !="")? json_decode($_POST['encaissements']) : array();
                        $this->data['bulletins'] = (isset($_POST['bulletins']) && $_POST['bulletins'] !="")?json_decode($_POST['bulletins']) : array();
                        
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_penalites', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_recettes")
                {
                        $this->data['agence'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchModel->get_branches();
                        if(isset($_POST['data']) && $_POST['data'] !="")
                        {
                               $this->data['data'] = json_decode($_POST['data'], true);
                        }
                        else
                        {
                                $this->data['data'] = array();
                        }
                        
                        $html = view('\Modules\Branch\Views\reports\report_agence\_print_recettes', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "number_letter")
                {
                        $value = $this->number_letter->converter($data, $arg);

                        return $value;
                }
                elseif($obj == "encrypt_data")
                {
                        // Définition de la clé et du IV pour le chiffrement
                        define("ENCRYPTION_KEY", "MaCléSecrète12345");
                        define("ENCRYPTION_IV", "1234567890123456");
                        
                        return openssl_encrypt($data, "AES-256-CBC", ENCRYPTION_KEY, 0, ENCRYPTION_IV);
                }
        }

        public function deliver_regularized_immatriculation_attestation($id)
        {
                $result = [
                        'ok' => false,
                        'proof' => null,
                        'email' => null,
                        'whatsapp' => null,
                ];

                if(!$this->is_license_plate_web_service_validation_enabled())
                {
                        $result['message'] = 'La validation des plaques par web-service est désactivée.';
                        return $result;
                }

                $integration = $this->immatriculationModel->get_integration_immatriculation($id);
                if(empty($integration)
                        || !$this->immatriculationModel->check_print_attestation($integration->Logirefid_31))
                {
                        $result['message'] = 'Toutes les instructions des deux séquences ne sont pas intégrées.';
                        return $result;
                }

                try
                {
                        $attestationModel = new ServiceImmatriculationModel();
                        $sessionData = (array) $this->session->userdata;
                        $pdfFilePath = $attestationModel->attestation($integration->Reference_6, $sessionData);

                        if(!is_string($pdfFilePath) || !is_file($pdfFilePath) || !is_readable($pdfFilePath))
                        {
                                throw new \RuntimeException('L’attestation n’a pas pu être générée.');
                        }

                        $relativePath = ltrim(str_replace('\\', '/', $pdfFilePath), './');
                        $infobipConfig = config('Infobip');
                        $publicBaseUrl = trim((string) ($infobipConfig->publicAttestationBaseUrl ?? ''));
                        if($publicBaseUrl === '')
                        {
                                $publicBaseUrl = base_url();
                        }
                        $publicUrl = rtrim($publicBaseUrl, '/') . '/' . $relativePath;

                        $result['proof'] = [
                                'path' => $pdfFilePath,
                                'url' => $publicUrl,
                        ];

                        $customer = json_decode((string) $integration->Applicant_12, true);
                        $customer = is_array($customer) ? $customer : [];
                        $email = trim((string) ($customer['Email_16'] ?? ''));
                        $phone = trim((string) ($customer['Phone_17'] ?? ''));
                        $mail = new MailLib();
                        $bankName = strtolower(ltrim((string) ($sessionData['account_pageid'] ?? 'equitybcdc'), '@')) === 'equitybcdc'
                                ? 'EquityBCDC'
                                : (string) ($sessionData['account_business'] ?? 'Rawbank');

                        $emailModule = 'LOGIREF_IMMATRICULATION_REGULARIZATION_EMAIL';
                        if($email !== '' && $mail->was_delivery_sent($emailModule, $integration->Reference_6, $email))
                        {
                                $result['email'] = ['ok' => true, 'skipped' => true, 'message' => 'Attestation déjà envoyée par e-mail.'];
                        }
                        else
                        {
                                $result['email'] = $mail->send_immatriculation_payment_proof([
                                        'to' => $email,
                                        'customer_name' => $integration->Requerant_9,
                                        'attachment_path' => $pdfFilePath,
                                        'amount' => $integration->Amount_10,
                                        'commission' => $integration->Commission_14,
                                        'currency' => $integration->Devise_11,
                                        'note_reference' => $integration->Reference_6,
                                        'date' => date('d/m/Y', strtotime((string) ($customer['Date_1'] ?? $integration->Date_1))),
                                        'payment_channel' => $integration->Type_38 ?? '',
                                        'payment_id' => $integration->Id_0,
                                        'module' => $emailModule,
                                        'auto_track' => false,
                                        'bank_name' => $bankName,
                                        'from_name' => $bankName . ' - Immatriculation',
                                ]);
                        }

                        $normalizedPhone = $mail->normalize_whatsapp_recipient($phone);
                        $whatsappModule = 'LOGIREF_IMMATRICULATION_REGULARIZATION_WHATSAPP';
                        if($normalizedPhone !== null
                                && $mail->was_delivery_sent($whatsappModule, $integration->Reference_6, $normalizedPhone))
                        {
                                $result['whatsapp'] = ['ok' => true, 'skipped' => true, 'message' => 'Attestation déjà envoyée par WhatsApp.'];
                        }
                        else
                        {
                                $result['whatsapp'] = $mail->send_immatriculation_payment_proof_whatsapp([
                                        'to' => $phone,
                                        'customer_name' => $integration->Requerant_9,
                                        'note_reference' => $integration->Reference_6,
                                        'document_url' => $publicUrl,
                                        'filename' => 'attestation-' . $integration->Reference_6 . '.pdf',
                                        'attachment_path' => $pdfFilePath,
                                        'payment_id' => $integration->Id_0,
                                        'module' => $whatsappModule,
                                ]);
                        }

                        $result['ok'] = !empty($result['email']['ok']) && !empty($result['whatsapp']['ok']);
                        $this->immatriculationModel->save_log(
                                'Diffusion attestation après régularisation | noteId: ' . $integration->Reference_6
                                . ' | email: ' . (!empty($result['email']['ok']) ? 'SUCCESS' : 'FAILED')
                                . ' | whatsapp: ' . (!empty($result['whatsapp']['ok']) ? 'SUCCESS' : 'FAILED'),
                                'regularization_attestation'
                        );
                }
                catch(\Throwable $exception)
                {
                        $result['message'] = $exception->getMessage();
                        $this->immatriculationModel->save_log(
                                'Echec diffusion attestation après régularisation | paiementId: ' . $id
                                . ' | erreur: ' . $exception->getMessage(),
                                'regularization_attestation'
                        );
                }

                return $result;
        }

        private function is_license_plate_web_service_validation_enabled()
        {
                $options = $_SESSION['userdata']['options'] ?? array();

                if(is_string($options))
                {
                        $options = json_decode($options, true);
                }

                return is_array($options)
                        && (isset($options['ALL']['license-plate-payment-validation-by-web-service'])
                                || isset($options['DGI']['license-plate-payment-validation-by-web-service']));
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
