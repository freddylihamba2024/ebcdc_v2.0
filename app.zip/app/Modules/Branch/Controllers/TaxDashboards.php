<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\UserModel;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Branch\Models\EncaissementModel;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

class TaxDashboards extends BaseController {
    /*
     * Presentation: Gestion des tableaux de bord
     * Last update:
     * By Glodi on the 06.10.2023
     * *  *************************************************************************************************************************SECTION 1
     */

        public $menus = array('overview', 'menus', 'etax', '');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $role;
        public $bank;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'dashboards';
        public $core_banking;
        public $temenos;
        public $options;
        public $encaissementModel;
        public $usersModel;
        public $ratesModel;
        public $dataModel;
        public $mainModel;
        public $logirefModel;
        public $igor;
        public $flexcube;
        public $userModel;
        public $accountModel;
        public $feesModel;
        public $integrationModel;
        public $branchModel;
        public $synergies;
        public $bsqr;
        public $finacle_standardbank;
        public $ratesmodel;
        public $amplitude;
        public $amplitude_solidairebanque;
        public $fibridge;
        public $finacle;
        public $cyclone;
        public $temenoscrdb;

        public function __construct()
        {
                parent::__construct();

                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                 */

                $this->encaissementModel = new EncaissementModel();
                $this->ratesModel = new RatesModel();
                $this->integrationModel = new IntegrationModel();
                $this->usersModel = new UsersModel();
                $this->dataModel = new DataModel();
                $this->mainModel = new MainModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->amplitude = new Amplitude();
                $this->synergies = new Synergies();
                $this->igor = new Igor();
                $this->bsqr = new Bsqr();
                $this->finacle_standardbank=new FinacleStandardBank();
                $this->userModel = new UserModel();
                $this->accountModel = new AccountModel();
                $this->feesModel = new FeesModel();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->finacle = new Finacle();
                $this->cyclone = new Cyclone();
                $this->temenoscrdb = new TemenosCrdb();
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxdashboards';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];

                if ($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                else
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }


                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['devises'] = $this->encaissementModel->devises;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                 */

                if (!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400")
                {
                    #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) 
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        header("Location: " . base_url($this->module));
                        exit;
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Branch\Views\container';

                if ($_SESSION['Logiref_role'] == 1)
                {
                        echo view('layouts/layout_admin', $this->data);
                }
                else
                {
                        echo view('layouts/layout_main', $this->data);
                }
        }

        /*
        * Manages sidebar menu
        * Must match de third section of the URL
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 2
        */

        public function set($needle)
        {

                if (in_array($needle, $this->menus))
                {
                        if ($needle == "overview")
                        {
                                if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') 
                                {

                                        if (isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100') 
                                        {
                                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                        }
                                        else
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if (!isset($_SESSION['Exchange_rates']))
                                                {
                                                        $this->display("set_exchange_rates");
                                                }

                                                $this->data['sidebar'] = "";
                                                $this->data['subview'] = '\Modules\Branch\Views\container';

                                                echo view('layouts/layout_main', $this->data);
                                        }
                                }
                        }
                        else
                        {
                                $this->index();
                        }
                }
        }

        /*
        * Manages all the views
        * View calls are made here
        * * PS: A personnaliser !!
        * *  *************************************************************************************************************************SECTION 3
        */

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "etax")
                {
                        if ($_SESSION['Logiref_role'] == 1)
                        {
                                $this->data["count_users"] = count($this->userModel->get_members_array());
                                $this->data["count_compte_bancaire"] = $this->accountModel->get_count_comptes();
                                $this->data["count_frais_bancaire"] = count($this->feesModel->get_regles("rgle"));
                                $this->data["count_agence"] = count($this->branchModel->get_guichets("Guichet"));
                                $this->data["agences"] = $this->branchModel->get_guichets("Guichet");
                                foreach ($this->data["agences"] as $value)
                                {
                                        $value->Users_inactif = count($this->userModel->get_users_inactif($value->Id_0));
                                        $value->Users_actif = count($this->userModel->get_users_actif($value->Id_0));
                                        $value->Count_compte = count($this->accountModel->get_compte_parametrer($value->Id_0));
                                }
                                echo view('\Modules\Admin\Views\logiref\dashboard\dashboard', $this->data);
                        }
                        elseif ($_SESSION['Logiref_role'] == 2)
                        {
                                # Dashboard for the operations manager
                                $this->data['commission'] = $this->encaissementModel->get_stats("commission");
                                $this->data['paiement'] = $this->encaissementModel->get_stats("paiement");
                                $this->data['penalties'] = $this->dataModel->get_penalites();
                                $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                                $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                                $this->data['agences'] = $agences = $this->branchModel->get_guichets("Guichet");
                                $this->data['DGI_CDF'] = 0;
                                $this->data['DGI_USD'] = 0;
                                $this->data['DGRAD_CDF'] = 0;
                                $this->data['DGRAD_USD'] = 0;
                                $this->data['DGDA_CDF'] = 0;
                                $this->data['DGRK_CDF'] = 0;
                                $this->data['DGRK_USD'] = 0;
                                $this->data['show_provincial_taxes'] = array_key_exists('provincial_tax_payments', $this->options['ALL'] ?? []);

                                foreach ($agences as $agence)
                                {
                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, "DGRAD", "CDF");
                                        $agence->DGRAD_CDF = !empty($tab) ? $tab['Montant'] : 0;
                                        $agence->DGRAD_CDF_ToT = !empty($tab) ? $tab['Total'] : 0;
                                        $this->data['DGRAD_CDF'] += $agence->DGRAD_CDF;
                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, "DGRAD", "USD");
                                        $agence->DGRAD_USD = !empty($tab) ? $tab['Montant'] : 0;
                                        $this->data['DGRAD_USD'] += $agence->DGRAD_USD;
                                        $agence->DGRAD_USD_ToT = !empty($tab) ? $tab['Total'] : 0;

                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, "DGI", "CDF");
                                        $agence->DGI_CDF = !empty($tab) ? $tab['Montant'] : 0;
                                        $this->data['DGI_CDF'] += $agence->DGI_CDF;
                                        $agence->DGI_CDF_ToT = !empty($tab) ? $tab['Total'] : 0;
                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, "DGI", "USD");
                                        $agence->DGI_USD = !empty($tab) ? $tab['Montant'] : 0;
                                        $this->data['DGI_USD'] += $agence->DGI_USD;
                                        $agence->DGI_USD_ToT = !empty($tab) ? $tab['Total'] : 0;

                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, "DGDA", "CDF");
                                        $agence->DGDA_CDF = !empty($tab) ? $tab['Montant'] : 0;
                                        $this->data['DGDA_CDF'] += $agence->DGDA_CDF;
                                        $agence->DGDA_CDF_ToT = !empty($tab) ? $tab['Total'] : 0;
                                        if ($this->data['show_provincial_taxes']) {
                                                foreach (['CDF', 'USD'] as $currency) {
                                                        $tab = $this->encaissementModel->get_payement_regie_agence($agence->Id_0, 'DGRK', $currency);
                                                        $field = 'DGRK_' . $currency;
                                                        $agence->{$field} = !empty($tab) ? $tab['Montant'] : 0;
                                                        $this->data[$field] += $agence->{$field};
                                                        $agence->{$field . '_ToT'} = !empty($tab) ? $tab['Total'] : 0;
                                                }
                                        }
                                }

                                echo view('\Modules\Branch\Views\dashboards\_superviseur', $this->data);
                        }
                        elseif ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 5)
                        {
                                # Dashboard for the super user

                                $this->data['commission'] = $this->encaissementModel->get_stats("commission");
                                $this->data['penalties'] = $this->dataModel->get_penalites();
                                $this->data['paiement'] = $this->encaissementModel->get_stats("paiement");
                                $this->data['pie_commission'] = "300,50,100"; //$this->data("pie-chart", $this->data['commission'], "commission");
                                $this->data['pie_paiement'] = "300,140,200"; //$this->data("pie-chart", $this->data['paiement'], "paiement");

                                $this->data['guichets'] = $this->branchModel->get_branches();

                                $data = array();

                                foreach ($this->data['guichets'] as $row)
                                {
                                        $data[$row->Id_0] = $row->Nom_4;
                                }
                                $this->data['guichets'] = $data;
                                $this->data['operators'] = $this->encaissementModel->get_stats("dash_operators");
                                $this->data['stats'] = $this->encaissementModel->get_stats("dash_stats");
                                $this->data['show_provincial_taxes'] = array_key_exists(
                                        'provincial_tax_payments',
                                        $this->options['ALL'] ?? []
                                );
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\dashboards\_validateur', $this->data);
                        }
                        elseif ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 6 || $_SESSION['Logiref_role'] == 7 || $_SESSION['Logiref_role'] == 11 || $_SESSION['Logiref_role'] == 8) 
                        {
                                $this->data['alerts'] = array();
                                $this->data['menus'] = $this->logirefModel->get_menus();

                                echo view('\Modules\Branch\Views\dashboards\_' . $obj, $this->data);
                        }
                        elseif($_SESSION['Logiref_role'] == 9 || $_SESSION['Logiref_role'] == 10)
                        {
                                # Dashboard for the rate operator and validator
                                //$this->data['rates'] = $this->ratesModel->get_rates();

                                echo view('\Modules\Branch\Views\dashboards\_taux', $this->data);
                        }
                }
                elseif ($obj == "summary")
                {
                        # Dashboard for the operations manager

                        $this->data['commission'] = $this->encaissementModel->get_stats("commission");
                        $this->data['paiement'] = $this->encaissementModel->get_stats("paiement");
                        $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                        $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                        $this->data['agences'] = $this->encaissementModel->get_agences();

                        foreach ($this->data['agences'] as $row) {
                        $data[$row->Id_0] = $this->encaissementModel->get_paiements_stats("agence", $row->Id_0);
                        }
                        $this->data['data'] = $data;

                        echo view('\Modules\Branch\Views\dashboards\\' . $obj, $this->data);
                }
                elseif ($obj == "overview")
                {

                        if ($_SESSION['Logiref_privileges'] != 0)
                        {

                                if (($_SESSION['Exchange_rates'] == 0 || $_SESSION['Exchange_rates'] == 1) && in_array($_SESSION['Logiref_role'], [3, 4])) {
                                        $this->display("default_values_new_taux");
                                        $this->display("set_exchange_rates");

                                        $this->data['module'] = 'branch';
                                        echo view('\Modules\Branch\Views\rates\_taux', $this->data);
                                }
                                else
                                {
                                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                        $this->data['agences'] = $this->branchModel->get_dropdown('agences');
                                        $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')]) ? $this->data['guichets'][$this->session->get('Logiref_guichet')] : "";
                                        $this->data['agence'] = isset($this->data['agences'][$this->session->get('Logiref_agence')]) ? $this->data['agences'][$this->session->get('Logiref_agence')] : "";
                                        $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                                        $this->data['region'] = (!is_null($region)) ? $region->Nom_7 : '';
                                       
                                        $this->data['role_user'] = (!empty($_SESSION['roles_banks'])) ? $_SESSION['roles_banks'][$this->session->get('Logiref_role')] : "";

                                        $this->data['paiement_cdf'] = $paiement_cdf = array(); //$this->encaissementModel->get_stats("paiement_situation_cdf");
                                        $this->data['paiement_usd'] = $paiement_usd = array(); //$this->encaissementModel->get_stats("paiement_situation_usd");
                                        $this->data['paiement_regie'] = array(); //$this->encaissementModel->get_stats("paiement_situation_regie");
                                        $this->data['paiement'] = array(); //$this->encaissementModel->get_stats("paiement");
                                        $this->data['pie_situation_cdf'] = array(); //$this->data("pie-chart_operator", $paiement_cdf, "paiement_situation_cdf");
                                        $this->data['pie_situation_usd'] = array(); //$this->data("pie-chart_operator", $paiement_usd, "paiement_situation_usd");
                                        $this->data['right_side'] = $id;
                                        $this->data['beneficiaires'] = array(); //$this->logirefModel->get_dropdown("services", $service=NULL);
                                        $this->data['encaissements'] = array(); //$this->encaissementModel->get_paiements('penalities');
                                        $this->data['guichets'] = array(); //$this->encaissementModel->get_dropdown("guichets");

                                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                        $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                                        echo view('\Modules\Main\Views\overview', $this->data);
                                }
                        }
                }
                elseif ($obj == "set_exchange_rates")
                {
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];

                        $this->ratesModel->get_exchange_rates();

                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                        {
                                if (isset($this->options['ALL']['auto-fetch-exchange-rate']))
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Initialization
                                        * ------------------------------------------------
                                        */

                                        $usd = '';
                                        $pound = '';
                                        $eur = '';
                                        $rand = '';

                                        $data['from_currency'] = 'USD';
                                        $data['to_currency'] = 'CDF';
                                        $data['type'] = 'TTB';
                                        $data['language'] = 'P';

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (property_exists($this, $core_banking) && method_exists($this->{$core_banking}, 'get_exchange_rate'))
                                        {
                                                                         
                                                if($this->core_banking == "Finacle")
                                                {
                                                       $return = $this->{$core_banking}->get_exchange_rate_v2($data); 
                                                }
                                                else
                                                {
                                                       $return = $this->{$core_banking}->get_exchange_rate($data); 
                                                }
                                                
                                                $return = json_decode($return, true);

                                                if($return['code'] == '200')
                                                {
                                                        if (($return['exchange_rate'] ?? "") != "")
                                                        {

                                                                $usd = $return['exchange_rate'];

                                                                $_POST['usd'] = $usd;
                                                                $_POST['eur'] = $usd;
                                                                $_POST['rand'] = "";
                                                                $_POST['pound'] = "";

                                                                $this->save('taux');

                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                        elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                                        {
                                                                foreach ($return['ExchangeRateList'] as $row)
                                                                {
                                                                        if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                                        {
                                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                                        {
                                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                                        {
                                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                                        {
                                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                }

                                                                if ($usd != "" && $eur != "")
                                                                {
                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = $rand;
                                                                        $_POST['pound'] = $pound;

                                                                        $this->save('taux');

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                                else{
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                        else
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                }
                        }
                }
                # Exchange rates
                #
                ################################################################################
                elseif ($obj == "default_values_new_taux")
                {
                        if (isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0) 
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                if (!empty($bank['Dollar_4'])) 
                                {
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                        $this->data['id'] = $bank['Id_0'];
                                        $this->data['key'] = (!empty($bank['Id_2'])) ? $bank['Id_2'] : '';
                                        $this->data['msg'] = '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['bank'] = $bank;
                                }
                        }
                        elseif (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                if (!empty($bank['Dollar_4']))
                                {
                                        $this->data['msg'] = '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                if ($bank['Checkerid_11'] == 0):
                                        $this->data['id'] = $bank['Id_0'];
                                else :
                                        $this->data['id'] = '';
                                        $this->data['reset'] = 1;
                                endif;

                                $this->data['bank'] = $bank;
                                }
                        }
                        elseif (isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                if (!empty($bank['Dollar_4'])) 
                                {
                                        $this->data['msg'] = '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                        $this->data['bank'] = $bank;
                                        $this->data['id'] = '';
                                }
                        } 
                        else 
                        {
                                $this->data['msg'] = '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }

                        $this->data['action'] = '...';

                        if (isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 0)
                        {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;

                        if ($_SESSION['Logiref_role'] == 3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer';
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] = '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif ($_SESSION['Logiref_role'] == 4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] = '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif ($_SESSION['Logiref_role'] == 4)
                        {
                                if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }
                #Default
                elseif ($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

        /*
        * Manages all database updates
        * Calls to model's saving methos are made here
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 4
        */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if($obj == 'taux')
                {
                        $dollar = str_replace(' ','',$_POST['usd']);
                        $dollar = str_replace(',','.',$dollar);

                        if($_POST['eur'] !="")
                        {
                                $euro = str_replace(' ','',$_POST['eur']);
                                $euro = str_replace(',','.',$euro);
                                $data['Euro_5']     =   $euro;
                        }

                        $data['Date_1']              =   gmdate('Y-m-d H:i:s');
                        $data['Status_2']            =   1;
                        $data['Account_3']           =   $this->session->userdata['account_id'];
                        $data['Dollar_4']            =   $dollar;
                        $data['Agence_8']            =   $_SESSION['Logiref_agence'];
                        $data['Day_9']               =   gmdate('Y-m-d');
                        $data['Checkerid_11']        =   '0001';
                        $data['Makerid_10']          =   '0002';

                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                        $cid = $this->ratesModel->save_taux($data, NULL);

                        if($cid)
                        {
                                return $cid;
                        }

                }
        }

        /*
        * Manages additional data manipuations
        * Arguments could of any type, arrays or strings
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 5
        */

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if ($obj == "set_privilegies") {
                        $this->usersModel->get_privilegies();
                }

                ################################################################################
                # Dashboard Pie chart
                ################################################################################
                if ($obj == "pie-chart") {
                        if ($arg == 'commission') {
                                $stats = $data;

                                $datas = '
                                        {value:' . $stats[2] . ',label:"CDF",color:"#00C6F3",highlight:"green"},
                                        {value:' . $stats[3] . ',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                        {value:' . $stats[1] . ',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                        {value:' . $stats[4] . ',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                ';
                                return $datas;
                        }
                        elseif ($arg == 'paiement') {
                                $stats = $data;

                                $datas = '
                                        {value:' . $stats[2] . ',label:"CDF",color:"#00b461",highlight:"aqua"},
                                        {value:' . $stats[3] . ',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                        {value:' . $stats[1] . ',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                        {value:' . $stats[4] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                ';
                                return $datas;
                        }
                } 
                elseif ($obj == "pie-chart_operator") 
                {
                        if ($arg == 'paiement_situation_cdf') 
                        {
                                $stats = $data;
                                $datas = '
                                        {value:' . $stats['unvalidated'] . ',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                        {value:' . $stats['validated'] . ',label:" CDF",color:"#00b461",highlight:"aqua"},
                                        {value:' . $stats['reversed'] . ',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                        {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                ';
                                return $datas;
                        } 
                        elseif ($arg == 'paiement_situation_usd') 
                        {
                                $stats = $data;

                                $datas = '
                                        {value:' . $stats['unvalidated'] . ',label:" USD",color:"#ffa500",highlight:"aqua"},
                                        {value:' . $stats['validated'] . ',label:" USD",color:"#00b461",highlight:"aqua"},
                                        {value:' . $stats['reversed'] . ',label:" USD",color:"#00bfff",highlight:"aqua"},
                                        {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                ';
                                return $datas;
                        }
                } 
                elseif ($obj == "OBJ ") 
                {

                } 
                elseif ($obj == "OBJ ") 
                {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
