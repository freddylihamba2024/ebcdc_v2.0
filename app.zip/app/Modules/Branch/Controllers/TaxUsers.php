<?php 

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\BranchModel;
use Modules\Main\Models\MainModel;


class TaxUsers extends BaseController {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Glodi on the 19.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('privileges','settings','accountsydonia');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'users';
        public $options;
        public $logirefModel;
        public $branchModel;
        public $mainModel;
        public $usersModel;
        public $integrationModel;



        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is Branch 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->usersModel = new UsersModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxusers';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $this->session->userdata["account_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
	} 
	
        
	public function index()
	{
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "user") 
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['from'] = $arg;
                        $members = $this->usersModel->get_dropdown("users");
                        
			$this->load->model('MY_Main');
			$this->load->model('main/mainModel');
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];
                        foreach($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['user'] = $this->usersModel->get_user_info($id);
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['roles'] = $this->usersModel->role;
                        }
                        else
                        {
                            $this->data['fonctions'] = $this->usersModel->fonction;
                            $this->data['fonctions'][1] ="";

                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_user', $this->data);  
                }
                elseif($obj == "accountsydonia")
                {   
                        $user = $this->session->userdata['user_id'];
                        $this->data['identifiants'] = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        
                        echo view('\Modules\Branch\Views\users\_sydonia', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "user")
                {
                        if($_POST['userid']=='0' || $_POST['role']=='' || $_POST['ville']==''):
                                echo '<div class="alert alert-danger text-white">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        else:
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                    
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']= '2';
                                        $data['Statusvalidate_19']= '1';
                                        $data['Account_3']=$this->session->userdata['account_id'];
                                        $data['Maker_14']= $this->session->userdata['user_id'];
                                
                                endif;
                                
                                if($_SESSION['Logiref_role']==1)
                                {
                                        
                                        $data['Role_4']=$_POST['role'];
                                        $data['Province_5']=$_POST['province'];
                                        $data['Ville_6']= $_POST['ville'];
                                        $data['Agence_7']= $_POST['agence'];
                                        if($_SESSION['Logiref_groupe']== 'banks')
                                        {
                                            $data['Guichet_8']=$_POST['guichet'];
                                            $data['Regies_11']='';
                                        }
                                        else
                                        {
                                            $data['Service_10']=$_POST['service'];
                                            $data['Regies_11']=$_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9']=$_SESSION['Logiref_groupe'];
                                        $data['Code_12']=$_POST['code'];
                                        $data['Userid_13']=$_POST['userid'];
                                        
                                        


                                        if($_POST['role'] == '1')
                                        {
                                                $this->load->model('MY_Main');
                                                $this->load->model('main/mainModel');
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $userid = $_POST['userid'];
                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if($id != "" && $id !='0')
                                        {
                                            if($_POST['role'] != '1'):
                                                    $this->load->model('MY_Main');
                                                    $this->load->model('main/mainModel');
                                                    
                                                    $data['Statusvalidate_19'] = $_POST['status'];
                                                    $data['Maker_14']= $this->session->userdata['user_id'];
                                                    
                                                    $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                    $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                    $rdata['Type_10'] = '300';
                                                    $userid = $_POST['userid'];
                                                    $relationid = $this->mainModel->update_relation($rdata, $userid);
                                            endif;
                                        }
                                       
                                        $data['Checker_15']=0;
                                        $data['Validation_16']='0000-00-00';
                                       
                                    
                                }
                                else
                                {
                                        $data['Checker_15']= $this->session->userdata['user_id'];
                                        $data['Validation_16']= gmdate('Y-m-d H:i:s');
                                        if($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] !='0')
                                        {
                                                $data['Status_2'] = $_POST['statusvalidate'];
                                        }
                                }
                                
                                #Database
                                $cid = $this->usersModel->save_users($data, $id);
			endif;
                        if($cid): 
                                echo '<div class="alert aSuccess text-white">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif; 
                }
                elseif($obj == "account_sydonia")
                {
                        $encryption = array('codebank'=>$_POST['code'], 'encryption'=>$_POST['password']);
                        $user = $this->session->userdata['user_id'];
                        $data['Login_17'] = $_POST['login'];
                        $data['Password_18'] = json_encode($encryption);
                        $cid = $this->usersModel->update_users($data, $user);
                        if($cid): 
                                echo '<div class="alert aSuccess text-white">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif; 
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        $members = $this->usersModel->get_members();
                        $type = $this->session->userdata['user_type'];
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata['user_id'];
                                $cid = $this->usersModel->save_users($data, NULL);
                                if($cid) $members = $this->usersModel->get_members();
                        }
                        return $members;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */