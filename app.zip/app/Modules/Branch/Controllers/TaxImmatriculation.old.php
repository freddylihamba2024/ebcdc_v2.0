<?php

        namespace Modules\Branch\Controllers;

        use App\Controllers\BaseController;
        use Modules\Branch\Models\ImmatriculationModel;
        use Modules\Logiref\Models\InvLogirefModel;
        use Modules\Admin\Models\AccountModel;
        use Modules\Admin\Models\BranchModel;
        use Modules\Branch\Models\EncaissementModel;
        use Modules\Branch\Models\RatesModel;
        use Modules\Services\Sftp\Controllers\Siop;
        use Modules\Services\Comptabilisation\Controllers\InvComptabilisation;
        use Modules\Services\Comptabilisation\Models\InvComptabilisationModel;
        use Modules\Services\Amplitude\Controllers\AmplitudeInv;
        use Modules\Services\Castillo\Controllers\CastilloImmatriculation;
        use Modules\Services\Immatriculation\Models\ImmatriculationModel as ServiceImmatriculationModel;

        class TaxImmatriculation extends BaseController {
                /*
                * Presentation:
                * Last update:
                * By Donald on the 06.03.2026
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('integration', 'inv_to_confirm', '', '');
                public $role = '5';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'branch';
                public $folder = 'immatriculation';

                public $bank = '';
                public $bank_uppercase = '';
                public $core_banking = '';
                public $functionalities = array();
                public $options = array();
                public $roles = array();
                public $branch = '';

                public $base_url=null;

                public $invLogirefModel;
                public $encaissementModel;
                public $invComptabilisationModel;
                public $accountsModel;
                public $branchModel;
                public $ratesModel;
                public $amplitude;
                public $castilloImmatriculation;
                public $invComptabilisation;
                public $immatriculationModel;
                public $serviceImmatriculationModel;
                public $siop;

                public $headers=array();

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */
                        $this->invLogirefModel = new InvLogirefModel();
                        $this->encaissementModel = new EncaissementModel();
                        $this->invComptabilisationModel = new InvComptabilisationModel();
                        $this->accountsModel = new AccountModel();
                        $this->branchModel = new BranchModel();
                        $this->invComptabilisation = new InvComptabilisation();
                        $this->amplitude = new AmplitudeInv();
                        $this->castilloImmatriculation = new CastilloImmatriculation();
                        $this->ratesModel = new RatesModel();
                        $this->immatriculationModel = new ImmatriculationModel();
                        $this->serviceImmatriculationModel = new ServiceImmatriculationModel();
                        $this->siop = new Siop();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'taximmatriculation';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->invLogirefModel->documents;
                        $this->data['devises'] = $this->invLogirefModel->devises;
                        $this->data['modes'] = $this->invLogirefModel->modes;
                        $this->data['moyens'] = $this->invLogirefModel->moyens;
                        $this->data['infos'] = $this->invLogirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                        $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                        $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                        $this->data['i'] = 0;
                        $this->data['pending_integration_ids'] = [];

                        $this->data['deny'] = false;

                        if ($_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else
                        {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }

                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        $this->branch = $_SESSION['Logiref_guichet'];
                        $this->role = $_SESSION['Logiref_role'];

                        if($this->bank != "")
                        {
                                # Enlever @ dans le pageid
                                # Tranformer la premiere lettre en majuscule
                                $this->bank = substr($this->bank, 1);
                                $this->bank_uppercase = ucfirst($this->bank);
                        }

                        $this->base_url = (getenv('PLATES_LOGIREF_ENTERPRISE_BASE_URL') ?: getenv('LOGIREF_ENTERPRISE_BASE_URL'));

                }


                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Branch\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }


                /*
                * Manages sidebar menu
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */

                public function set($needle)
                {
                        if(in_array($needle, $this->menus))
                        {
                                if($_SESSION['Logiref_role']==4)
                                {
                                        $this->data['sidebar'] = '';
                                }
                                $this->index();
                        }
                }

                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "start")
                        {
                                $recettes = $this->invLogirefModel->get_dropdown('recettes',"DGI");

                                $this->data['recettes'] = $recettes["DGI"];
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_1', $this->data);
                        }
                        elseif ($obj == "verification")
                        {
                                $reference = trim($_POST['Reference_6']);
                                //Vérifier si la note de perception existe dans la base des données
                                $note_perception = $this->immatriculationModel->get_integration_immatriculation_by_reference($reference);

                                if(isset($note_perception->Id_0) && ($note_perception->Status_2==3 || $note_perception->Status_2==7))
                                {
                                        return $this->response->setJSON(['code'=>405,'message'=>'Cette note de perception a été déjà payée']);
                                }

                                if(isset($note_perception->Id_0) && in_array((int) $note_perception->Status_2, [5, 6], true))
                                {
                                        return $this->response->setJSON(['code'=>405,'message'=>'Cette note est en attente de régularisation']);
                                }

                                if(isset($note_perception->Id_0) && $note_perception->Status_2==2)
                                {
                                        return $this->response->setJSON(['code'=>406,'message'=>'Cette note de perception est en attente de validation']);
                                }

                                $id=isset($note_perception->Id_0)?$note_perception->Id_0:null;

                                if(empty($note_perception))
                                {
                                        $castillo_response = $this->castilloImmatriculation->getNote($reference);

                                        if(isset($castillo_response['code']) && $castillo_response['code']==200)
                                        {
                                                $call_response = $castillo_response['raw'];
                                                $result = $castillo_response['result'];

                                                if(isset($result['status']) && $result['status']==200)
                                                {
                                                        if($result['note_perception']['NoteStatus_13'] == "PAID")
                                                        {
                                                                return $this->response->setJSON(['code' => 405,'status' => false,'message' => 'Note de perception trouvée mais déjà payé.']);
                                                        }
                                                        else
                                                        {
                                                                $note_perception = $this->immatriculationModel->build_integration_data($call_response);

                                                                if($note_perception['Beneficiaries_13']==NULL)
                                                                {
                                                                        return $this->response->setJSON(['code' => 407,'status'=> false,'message' => 'Note de perception trouvée mais la liste des beneficiaires est vide. Impossible de procéder au paiement.']);
                                                                }

                                                                $id = $this->init_note_perception($note_perception);
                                                        }
                                                }
                                        }
                                        elseif(isset($castillo_response['code']) && $castillo_response['code']==404)
                                        {
                                                return $this->response->setJSON(['code'=>404,'message'=>'Note de perception non trouvée']);
                                        }
                                        else
                                        {
                                                return $this->response->setJSON(['code'=>500,'message'=>"Nous n’avons pas pu traiter votre demande. Veuillez réessayer dans quelques instants"]);
                                        }
                                }

                                $encaissement = $this->immatriculationModel->immatriculation_migrate_note($id);
                                # Préparation des données
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] = $this->invLogirefModel->get_dropdown("services", "DGI", NULL, true);

                                $recettes = $this->invLogirefModel->get_dropdown('recettes', "DGI");

                                $this->data['recettes'] = $recettes["DGI"];
                                $this->data['step'] = 2;
                                $this->data['note']=$note_perception;
                                $this->data['encaissement']=$encaissement;

                                $htmlView = view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);

                                return $this->response->setJSON(['code' => 'SUCCESS', 'html' => $htmlView]);
                        }
                        elseif ($obj == "integration")
                        {
                                echo view('\Modules\Branch\Views\immatriculation\integrations', $this->data);
                        }
                        elseif ($obj == "_integration_branch")
                        {
                                $this->data['step'] = 0;
                                $this->data['services'] =  $this->invLogirefModel->get_dropdown("services", "DGI", $province=NULL, true);

                                $treatment_on_goings = $this->immatriculationModel->get_integrations_sftp_treatment_in_progress("branch");

                                if(!empty($treatment_on_goings))
                                {
                                        $treatment_on_going = current($treatment_on_goings);

                                        $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                        $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                        $this->data['files_instructions_data'] = $files_instructions_data;
                                        $this->data['treatment_on_going'] = $treatment_on_going;
                                        $pending_files = $this->immatriculationModel
                                                ->get_integrations_sftp_on_pending_by_treatmentid($treatment_on_going->Id_0);
                                        $this->data['pending_integration_ids'] = array_map(
                                                static function ($file) { return (string) $file->Id_0; },
                                                $pending_files
                                        );
                                }
                                else
                                {
                                        $raw_instructions = $this->immatriculationModel->get_instructions_to_treat_for_sftp_dgda("branch");
                                        $this->data['files_instructions_data'] = $this->data("aggregate_instructions_by_office", $raw_instructions);

                                        $this->data['treatment_on_going'] = '';
                                }

                                $this->data['users'] = $this->invLogirefModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\immatriculation\_integration_branch', $this->data);
                        }
                        elseif ($obj == "_integration_branchless")
                        {
                                $this->data['step'] = 0;
                                $this->data['services'] =  $this->invLogirefModel->get_dropdown("services", "DGI", $province=NULL, true);

                                $treatment_on_goings = $this->immatriculationModel->get_integrations_sftp_treatment_in_progress("branchless");

                                if(!empty($treatment_on_goings))
                                {
                                        $treatment_on_going = current($treatment_on_goings);

                                        $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                        $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                        $this->data['files_instructions_data'] = $files_instructions_data;
                                        $this->data['treatment_on_going'] = $treatment_on_going;
                                        $pending_files = $this->immatriculationModel
                                                ->get_integrations_sftp_on_pending_by_treatmentid($treatment_on_going->Id_0);
                                        $this->data['pending_integration_ids'] = array_map(
                                                static function ($file) { return (string) $file->Id_0; },
                                                $pending_files
                                        );
                                }
                                else
                                {
                                        $raw_instructions = $this->immatriculationModel->get_instructions_to_treat_for_sftp_dgda("branchless");

                                        $this->data['files_instructions_data'] = $this->data("aggregate_instructions_by_office", $raw_instructions);
                                        $this->data['treatment_on_going'] = '';
                                }

                                $this->data['users'] = $this->invLogirefModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\immatriculation\_integration_branchless', $this->data);
                        }
                        elseif($obj=="_integration_details")
                        {
                                $notes_ids=$_POST['notes_ids'];

                                $notes=array();

                                foreach($notes_ids as $id)
                                {
                                        $note=$this->immatriculationModel->get_integration_immatriculation($id);

                                        if(!empty($note))
                                        {
                                                $notes[]=$note;
                                        }
                                }

                                $this->data['notes']=$notes;

                                return view("Modules\Branch\Views\immatriculation\_integration_details",$this->data);
                        }
                        elseif ($obj == "filter_integration_treatment")
                        {
                                $filter_date = isset($_POST['filter_date']) ? trim($_POST['filter_date']) : '';
                                $payment_type = isset($_POST['payment_type']) ? trim($_POST['payment_type']) : '';

                                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_date)
                                    || !in_array($payment_type, ['branch', 'branchless'], true))
                                {
                                        return $this->response
                                                ->setStatusCode(422)
                                                ->setBody('La date ou le type de paiement sélectionné est invalide.');
                                }

                                $this->data['step'] = 0;
                                $this->data['services'] = $this->invLogirefModel->get_dropdown("services", 'DGI', $province = NULL, true);
                                $this->data['filter_date'] = $filter_date;
                                $this->data['is_filter_result'] = true;

                                // Priorité à un traitement déjà créé mais pas entièrement envoyé.
                                $treatment_on_goings = $this->immatriculationModel
                                        ->get_integrations_sftp_treatment_by_filter($filter_date, $payment_type);

                                if(!empty($treatment_on_goings))
                                {
                                        $treatment_on_going = current($treatment_on_goings);

                                        // Réparer un ancien traitement clôturé prématurément alors
                                        // qu'un ou plusieurs fichiers par bureau restent à envoyer.
                                        if (!in_array((int) $treatment_on_going->Status_2, [1, 2], true))
                                        {
                                                $this->immatriculationModel->save_integration_summary(
                                                        ['Status_2' => 2],
                                                        $treatment_on_going->Id_0
                                                );
                                                $treatment_on_going->Status_2 = 2;
                                        }

                                        $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                        $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                        $this->data['files_instructions_data'] = $files_instructions_data;
                                        $this->data['treatment_on_going'] = $treatment_on_going;
                                        $pending_files = $this->immatriculationModel
                                                ->get_integrations_sftp_on_pending_by_treatmentid($treatment_on_going->Id_0);
                                        $this->data['pending_integration_ids'] = array_map(
                                                static function ($file) { return (string) $file->Id_0; },
                                                $pending_files
                                        );
                                }
                                else
                                {
                                        // Aucun traitement incomplet : rechercher d'abord de nouvelles
                                        // écritures de la date demandée (statuts 1 et 2 seulement).
                                        $raw_instructions = $this->immatriculationModel
                                                ->get_instructions_to_treat_for_sftp_immatriculation_by_date(
                                                        $filter_date,
                                                        $payment_type
                                                );

                                        if (!empty($raw_instructions))
                                        {
                                                $this->data['files_instructions_data'] = $this->data(
                                                        "aggregate_instructions_by_office",
                                                        $raw_instructions
                                                );
                                                $this->data['treatment_on_going'] = '';
                                        }
                                        else
                                        {
                                                $has_pending_journalisations = $this->immatriculationModel
                                                        ->has_pending_immatriculation_journalisations_by_date(
                                                                $filter_date,
                                                                $payment_type
                                                        );

                                                // Aucune nouvelle écriture : afficher le dernier traitement
                                                // terminé comme rapport des fichiers envoyés à cette date.
                                                $completed_treatment = !$has_pending_journalisations
                                                        ? $this->immatriculationModel
                                                                ->get_latest_integration_sftp_treatment_by_filter(
                                                                        $filter_date,
                                                                        $payment_type
                                                                )
                                                        : null;

                                                if (!empty($completed_treatment))
                                                {
                                                        $offices_data = json_decode($completed_treatment->Officesdata_10);
                                                        $this->data['files_instructions_data'] = $this->data(
                                                                "construct_files_instructions_data",
                                                                $offices_data
                                                        );
                                                        $this->data['treatment_on_going'] = $completed_treatment;
                                                        $this->data['is_completed_report'] = true;
                                                }
                                                else
                                                {
                                                        $this->data['files_instructions_data'] = [];
                                                        $this->data['treatment_on_going'] = '';
                                                }
                                        }
                                }

                                $this->data['users'] = $this->invLogirefModel->get_dropdown('users_array');

                                $view = $payment_type === 'branchless'
                                        ? '\Modules\Branch\Views\immatriculation\_integration_branchless'
                                        : '\Modules\Branch\Views\immatriculation\_integration_branch';

                                echo view($view, $this->data);
                        }
                        elseif ($obj == "_integration_filter")
                        {
                                $this->data['step'] = 0;
                                $this->data['services'] = $this->invLogirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                                $this->data['files_instructions_data'] = [];
                                $this->data['treatment_on_going'] = '';


                                $this->data['users'] = $this->invLogirefModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\immatriculation\_integration_filter', $this->data);
                        }
                        elseif($obj=="_integration_details_filter")
                        {
                                $notes_ids=$_POST['notes_ids'];

                                $notes_ids = json_decode($notes_ids, true);

                                $notes=array();

                                foreach($notes_ids as $id)
                                {
                                        $note=$this->immatriculationModel->get_integration_immatriculation($id);

                                        if(!empty($note))
                                        {
                                                $notes[]=$note;
                                        }
                                }

                                $this->data['notes']=$notes;

                                return view("Modules\Branch\Views\immatriculation\_integration_details",$this->data);
                        }
                        elseif($obj == "edit")
                        {
                                $note_perception = $this->immatriculationModel->get_integration_immatriculation($id);
                                $encaissement = $this->immatriculationModel->immatriculation_migrate_note($note_perception->Id_0);
                                # Préparation des données
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] = $this->invLogirefModel->get_dropdown("services", "DGI", NULL, true);

                                $recettes = $this->invLogirefModel->get_dropdown('recettes', "DGI");

                                $this->data['recettes'] = $recettes["DGI"];
                                $this->data['step'] = 2;
                                $this->data['print_attestation'] = $check = $this->immatriculationModel->check_print_attestation($note_perception->Logirefid_31);
                                $this->data['note'] = $note_perception;
                                $this->data['encaissement'] = $encaissement;

                                if($check === false) :
                                        echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);
                                else:
                                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                        $this->data['view'] = 'view';
                                        echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                                endif;
                        }
                        elseif($obj == "preview")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->invLogirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                                $recettes = $this->invLogirefModel->get_dropdown('recettes',"DGI");
                                $this->data['recettes'] = $recettes["DGI"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = 'view';

                                $immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);
                                $this->data['print_attestation'] = $this->immatriculationModel->check_print_attestation($immatriculation->Logirefid_31);
                                $this->data['encaissement'] = $encaissement = $this->immatriculationModel->immatriculation_migrate_note($immatriculation->Id_0);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                echo view($this->lang . '_denial', $this->data);
                        }
                        elseif($obj == "inv_to_confirm")
                        {
                                $this->data['notes'] = $this->serviceImmatriculationModel->get_unconfirmed_immatriculation_notes(500);
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['immatriculationConfirmationStatus'] = $this->invLogirefModel->immatriculationConfirmationStatus;
                                echo view('\Modules\Branch\Views\\'.$this->folder.'\inv_to_confirm', $this->data);
                        }
                }

                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if ($obj == 'confirm_inv_note')
                        {
                                $note = $this->serviceImmatriculationModel->get_integration_immatriculation($id);
                                $userId = isset($this->session->userdata['user_id']) ? $this->session->userdata['user_id'] : 0;

                                $response = $this->serviceImmatriculationModel->confirm_immatriculation_note($note, $userId);

                                return $this->response->setJSON($response);
                        }

                        //Nouvel enregistrement
                        //Tables concernées: tresor, integration
                        if($obj == 'initiation')
                        {

                                if($this->role == 4 || $this->role == 9)//Conditions maker nouveau
                                {
                                        //Récupération des données
                                        $error_code = 0;
                                        $return = $this->immatriculationModel->get_data_immatriculation();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Formattage des données
                                                $data  = $return['data'];

                                                $return = $this->immatriculationModel->get_formatage_data_immatriculation($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        //Traitements spécifiques
                                                        //Comptabilisation
                                                        $data  = $return['data'];

                                                        $check_existing_reference = $this->immatriculationModel->check_integration_immatriculation_by_reference($data['Noteid_26']);

                                                        if(isset($check_existing_reference['code']) && $check_existing_reference['code']!='E200')
                                                        {
                                                                $data = array();
                                                                $data['Id_0'] = $check_existing_reference['id'];
                                                        }
                                                        else
                                                        {
                                                                //Enregistrement base de données des informations des bénéficiaires
                                                                $plaque_immatriculation = $this->immatriculationModel->get_integration_immatriculation_by_reference($data['Noteid_26']);

                                                                $beneficiaires = json_decode($plaque_immatriculation->Beneficiaries_13,true);

                                                                $init_response = $this->init_paiements_beneficiaires($beneficiaires,$plaque_immatriculation, $data);

                                                                if($init_response > 0)
                                                                {
                                                                        $integration_immatriculation['Status_2']=2;
                                                                        $integration_immatriculation['Commission_14']=$data['Commission_23'];
                                                                        $integration_immatriculation['Devise_15']=$data['Devise_24'];
                                                                        $integration_immatriculation['Mode_17']=$data['Mode_19'];
                                                                        $integration_immatriculation['Refop_18']=$data['Reference_32'];
                                                                        $integration_immatriculation['Servicetype_19']=$data['Service_16'];
                                                                        $integration_immatriculation['Accountholder_26']=$data['Compte_33'];
                                                                        $integration_immatriculation['Devise_27']=$data['Devise_34'];
                                                                        $integration_immatriculation['Totalamount_28']=$this->immatriculationModel->formatage_amount($_POST['montantTotal']);
                                                                        $integration_immatriculation['Devise_29']=$data['Devise_12'];
                                                                        $integration_immatriculation['Guichet_32']=$_SESSION['Logiref_guichet'];
                                                                        $integration_immatriculation['Makerid_35']=isset($this->session->userdata['user_id'])?$this->session->userdata['user_id']:0;
                                                                        $integration_immatriculation['ValidateBySiop_39']= $_POST['ValidateBySiop_39'] ?? 0;

                                                                        $id_plaque = $plaque_immatriculation->Id_0;

                                                                        //Enregistrement base de données
                                                                        $updated = $this->immatriculationModel->update_immatriculation($integration_immatriculation,$id_plaque);

                                                                        if($updated==true)
                                                                        {
                                                                                $data['Id_0']=$id_plaque;

                                                                                $debit_mad_instructions = $this->invComptabilisation->get_first_instructions_immatriculation($data);

                                                                                if(!empty($debit_mad_instructions))
                                                                                {
                                                                                        $data['Logirefid_4'] = $plaque_immatriculation->Logirefid_31;

                                                                                        $first_instruction = $this->invComptabilisationModel->save_instructions_immatriculation($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'], 0);

                                                                                        if($first_instruction)
                                                                                        {
                                                                                                $debit_sequestre_instructions = $this->invComptabilisation->get_instructions_immatriculation_sequestre($data);

                                                                                                if(!empty($debit_sequestre_instructions))
                                                                                                {
                                                                                                        $second_instructions = $this->invComptabilisationModel->save_instructions_immatriculation($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                                                        if($second_instructions == false)
                                                                                                        {
                                                                                                                // breakdown instructions not saved
                                                                                                                $error_code = 403;
                                                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                                // verify whether the option integration by sftp is checked or not
                                                                                                                if(isset($_POST['ValidateBySiop_39']))
                                                                                                                {
                                                                                                                        $this->instructions_journalisation_cbs($data, $debit_sequestre_instructions);
                                                                                                                }
                                                                                                        }
                                                                                                }
                                                                                                else{
                                                                                                        $error_code = 408;
                                                                                                        $error_description = 'Erreur de construction des instructions de comptabilisation sequestre';
                                                                                                }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                                // first instruction not saved
                                                                                                $error_code = 402;
                                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                        }
                                                                                }
                                                                                else{
                                                                                        $error_code = 406;
                                                                                        $error_description = 'Erreur de construction des instructions de comptabilisation MAD';
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                // paiement not saved in the database
                                                                                $error_code = 401;
                                                                                $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                                        }

                                                                }
                                                                else
                                                                {
                                                                        // paiement not saved in the database
                                                                        $error_code = 401;
                                                                        $error_description = 'Paiements des bénéficiaires non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                                }

                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['plaqueid'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits d\'initier un paiement, veuillez contacter l\'op&eacute;rateur qui encaisse le paiement.';

                                        echo json_encode($data_return);
                                }
                        }
                        //Modification enregistrement
                        //Tables concernées: propres, integration
                        elseif ($obj == "update")
                        {
                                if ($this->role == 4 || $this->role == 9)
                                {
                                        $plaque_immatriculation = $this->immatriculationModel->get_integration_immatriculation_by_reference($_POST['Noteid_26']);

                                        if (!$plaque_immatriculation)
                                        {
                                                return $this->response->setJSON([
                                                        'code' => 404,
                                                        'message' => 'Paiement introuvable'
                                                ]);
                                        }

                                        if ($plaque_immatriculation->ValidateBySiop_39 == 1
                                                && $plaque_immatriculation->Status_2 > 2
                                                && !in_array((int) $plaque_immatriculation->Status_2, [5, 6], true))
                                        {
                                                return $this->response->setJSON([
                                                        'code' => 403,
                                                        'message' => 'Paiement en attente d\envoi de fichier SIOP, modification interdite'
                                                ]);
                                        }

                                        if (in_array((int) $plaque_immatriculation->Status_2, [5, 6], true))
                                        {
                                                return $this->response->setJSON([
                                                        'code' => 403,
                                                        'message' => 'Paiement à régulariser, modification interdite'
                                                ]);
                                        }

                                        if ($plaque_immatriculation->Status_2 >= 3)
                                        {
                                                return $this->response->setJSON([
                                                        'code' => 403,
                                                        'message' => 'Paiement déjà validé, modification interdite'
                                                ]);
                                        }

                                        $return = $this->immatriculationModel->get_data_immatriculation();

                                        if ($return['code'] != 200)
                                        {
                                                return $this->response->setJSON($return);
                                        }

                                        $data = $return['data'];

                                        $format = $this->immatriculationModel->get_formatage_data_immatriculation($data);

                                        if ($format['code'] != 200)
                                        {
                                                return $this->response->setJSON($format);
                                        }

                                        $data = $format['data'];

                                        $beneficiaires = json_decode($plaque_immatriculation->Beneficiaries_13,true);

                                        $this->immatriculationModel->delete_propres_immatriculation($_POST['Noteid_26']);

                                        $this->immatriculationModel->delete_tresor_immatriculation($_POST['Noteid_26']);

                                        $this->immatriculationModel->delete_immatriculation_journalisation($plaque_immatriculation->Id_0);

                                        $init_response = $this->init_paiements_beneficiaires($beneficiaires, $plaque_immatriculation, $data);

                                        if($init_response > 0)
                                        {
                                                $update_data = [
                                                        'Commission_14'         => $data['Commission_23'],
                                                        'Devise_15'             => $data['Devise_24'],
                                                        'Mode_17'               => $data['Mode_19'],
                                                        'Refop_18'              => $data['Reference_32'],
                                                        'Servicetype_19'        => $data['Service_16'],
                                                        'Accountholder_26'      => $data['Compte_33'],
                                                        'Devise_27'             => $data['Devise_34'],
                                                        'Totalamount_28'        => $this->immatriculationModel->formatage_amount($_POST['montantTotal']),
                                                        'Devise_29'             => $data['Devise_12'],
                                                        'Guichet_32'            => $_SESSION['Logiref_guichet'],
                                                        'Makerid_35'            => isset($this->session->userdata['user_id'])?$this->session->userdata['user_id']:0,
                                                        'ValidateBySiop_39'     => $_POST['ValidateBySiop_39'] ?? 0
                                                ];

                                                $id_plaque = $plaque_immatriculation->Id_0;

                                                $updated = $this->immatriculationModel->update_immatriculation($update_data, $id_plaque);

                                                if (!$updated)
                                                {
                                                        return $this->response->setJSON([
                                                                'code' => 500,
                                                                'message' => 'Erreur lors de la mise à jour'
                                                        ]);
                                                }

                                                $this->immatriculationModel->delete_instructions_by_note($id_plaque);

                                                $debit_mad_instructions = $this->invComptabilisation->get_first_instructions_immatriculation($data);

                                                if (!empty($debit_mad_instructions))
                                                {
                                                        $first_instruction = $this->invComptabilisationModel->save_instructions_immatriculation($plaque_immatriculation->Id_0,$data, $debit_mad_instructions,$plaque_immatriculation->Logirefid_31,0);

                                                        if($first_instruction)
                                                        {
                                                                $infos = json_decode($data["Notereference_30"], true);
                                                                $beneficiaries = [];

                                                                foreach($beneficiaires as $beneficiary)
                                                                {
                                                                        $beneficiaire['beneficiary_code']=$beneficiary['BeneficiaryCode_16'];
                                                                        $beneficiaire['beneficiary_name']=$beneficiary['BeneficiaryName_17'];
                                                                        $beneficiaire['amount']=$beneficiary['Amount_10'];
                                                                        $beneficiaire['currency']=$beneficiary['Currency_11'];
                                                                        $beneficiaries[] = $beneficiaire;
                                                                }
                                                                $infos['beneficiaries'] = $beneficiaries;
                                                                $data["Notereference_30"] = json_encode($infos);

                                                                $debit_sequestre_instructions = $this->invComptabilisation->get_instructions_immatriculation_sequestre($data);

                                                                if(!empty($debit_sequestre_instructions))
                                                                {
                                                                        $second_instruction = $this->invComptabilisationModel->save_instructions_immatriculation($id_plaque,$data,$debit_sequestre_instructions,$plaque_immatriculation->Logirefid_31,1);

                                                                        if($second_instruction)
                                                                        {
                                                                                // verify whether the option integration by sftp is checked or not
                                                                                if(isset($_POST['ValidateBySiop_39']))
                                                                                {
                                                                                        $this->instructions_journalisation_cbs($data, $debit_sequestre_instructions);
                                                                                }

                                                                                return $this->response->setJSON([
                                                                                        'code' => 200,
                                                                                        'id'   => $id_plaque,
                                                                                        'message' => 'Paiement modifié avec succès'
                                                                                ]);
                                                                        }
                                                                        else{
                                                                                return $this->response->setJSON([
                                                                                        'code' => 403,
                                                                                        'message' => 'Paiement enregistr&eacute; partiellement'
                                                                                ]);
                                                                        }
                                                                }
                                                                else{
                                                                        return $this->response->setJSON([
                                                                                'code' => 408,
                                                                                'message' => 'Erreur de construction des instructions de comptabilisation sequestre'
                                                                        ]);
                                                                }
                                                        }
                                                        else{

                                                                return $this->response->setJSON([
                                                                        'code' => 402,
                                                                        'message' => 'Paiement enregistr&eacute; partiellement'
                                                                ]);
                                                        }
                                                }
                                                else{
                                                        return $this->response->setJSON([
                                                                'code' => 406,
                                                                'message' => 'Erreur de construction des instructions de comptabilisation MAD'
                                                        ]);
                                                }
                                        }
                                        else
                                        {
                                                return $this->response->setJSON([
                                                        'code' => 411,
                                                        'message' => 'Paiements des bénéficiaires non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.'
                                                ]);
                                        }
                                }
                                else
                                {
                                        return $this->response->setJSON([
                                                'code' => 411,
                                                'message' => 'Accès refusé'
                                        ]);
                                }
                        }
                        //Validation
                        //Tables concernées: propres, integration
                        elseif($obj == "validation")//Conditions maker pour modification
                        {
                                if($id > 0 && ($this->role == 2 || $this->role == 3))//Conditions maker pour modification
                                {
                                        $error_code = 0;
                                        //Formattage des données
                                        $return = $this->immatriculationModel->get_data_validation_immatriculation($id);

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Traitements spécifiques
                                                $plaque_immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);

                                                if(!in_array((int) $plaque_immatriculation->Status_2, [5, 6, 7], true))
                                                {
                                                        // Mise à jour du statut de paiement en statut regularisation
                                                        // Pour la premiere sequence
                                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 5);

                                                        $data = $return['data'];

                                                        $core_banking = strtolower($this->core_banking);

                                                        $response = $this->{$core_banking}->virement_immatriculation($data);
                                                        $result = json_decode($response, true);

                                                        if($this->immatriculationModel->has_partially_completed_primary_instructions($id))
                                                        {
                                                                // La première écriture a débité le client, mais au moins une
                                                                // autre écriture de priorité 0 doit encore être régularisée.
                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 6);
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 300;
                                                                $error_description = 'Paiement partiellement valid&eacute; : la premi&egrave;re &eacute;criture a r&eacute;ussi, mais les autres doivent &ecirc;tre r&eacute;gularis&eacute;es.';
                                                        }
                                                        elseif(isset($result['response']) && $result['response'] == 200)
                                                        {
                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 7);
                                                                //Formattage des données pour la confirmation dans Castillo
                                                                $return = $this->immatriculationModel->get_data_confirmation_immatriculation();

                                                                if(isset($return['code']) && $return['code'] == 200)
                                                                {
                                                                        $apidata = $return['data'];

                                                                        $confirmation_response = $this->confirm_payment_note($apidata);

                                                                        if(isset($confirmation_response['code']) && $confirmation_response['code']==200)
                                                                        {
                                                                                // Paiement validé dans Amplitude et note confirmée dans Castillo.
                                                                                // Le statut 3 est réservé à l'envoi réussi du fichier SIOP.
                                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);

                                                                                $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                                                $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);
                                                                        }
                                                                        elseif(isset($confirmation_response['code']) && $confirmation_response['code']==201)
                                                                        {
                                                                                // Paiement validé dans Amplitude et note déjà confirmée dans Castillo.
                                                                                // Le statut 3 est réservé à l'envoi réussi du fichier SIOP.
                                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);

                                                                                $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                                                $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);

                                                                                $error_code = $confirmation_response['code'];
                                                                                $error_description = "Paiement valid&eacute; dans Amplitude, Mais : ".$confirmation_response['message'];
                                                                        }
                                                                        else
                                                                        {
                                                                                $error_code = $confirmation_response['code'];
                                                                                $error_description = "Paiement valid&eacute; dans Amplitude, Mais : ".$confirmation_response['message'];
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $error_code = 411;
                                                                        $error_description = "La validation a échoué. Merci de procéder à la régularisation dans l’onglet « Paiements à régulariser »";
                                                                }
                                                        }
                                                        elseif(isset($return['code']) && $return['code'] == 300)
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 300;
                                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                        }
                                                        elseif(isset($return['code']) && $return['code'] == 411)
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 411;
                                                                $error_description = 'Problème de connexion lors de l\'intégration des écritures dans le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                                        }
                                                        else
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 411;
                                                                $error_description = 'Problème de connexion lors de la communication avec le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = 411;
                                                        $error_description = 'Ce paiement est déjà dans le menu régularisation';
                                                }
                                        }
                                        else
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);
                                                $error_code = 411;
                                                $error_description = "La validation a échoué. Veuillez réessayer";
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement valid&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 411;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                                        echo json_encode($data_return);
                                }
                        }

                        //Suppression
                        //Tables concernées: propres, integration
                        elseif($obj == "deletion")//Conditions maker pour modification
                        {
                                if($id > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                                {
                                        $integration = $this->immatriculationModel->get_integration_immatriculation($id);

                                        if(!empty($integration) && $integration->Status_2 == 2)
                                        {
                                                $error_code = 0;
                                                //Récupération des données
                                                $return = $this->immatriculationModel->get_data_deletion_immatriculation();

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        $this->immatriculationModel->update_immatriculation(['Status_2' => 0], $id);

                                                        $data = $return['data'];
                                                        // Mise à jour du statut de paiement en statut en supprimé

                                                        $pid1 = $this->immatriculationModel->update_payment_tresor_data($integration->Reference_6,$data);
                                                        $pid2 = $this->immatriculationModel->update_payment_propre_data($integration->Reference_6,$data);

                                                        //Traitements spécifiques
                                                        if(!$pid1 || !$pid2)
                                                        {
                                                                $error_code = 404;
                                                                $error_description = "Le paiement n’a pas pu être supprimé. Veuillez réessayer.";
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }

                                                //Return utilisateurs
                                                if($error_code != 0)
                                                {
                                                        $data_return['code'] = $error_code;
                                                        $data_return['id'] = '';
                                                        $data_return['message'] = $error_description;
                                                }
                                                else
                                                {
                                                        $data_return['code'] = 200;
                                                        $data_return['id'] = $id;
                                                        $data_return['message'] = 'Bravo ! paiement suppri&eacute; avec succ&egrave;s.';
                                                }

                                                echo json_encode($data_return);
                                        }
                                        else{
                                                $data_return['code'] = 411;
                                                $data_return['id'] = '';
                                                $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'administrateur.';
                                        }
                                }
                                else
                                {
                                        $data_return['code'] = 411;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj=="confirmation_note")
                        {
                                if($id > 0 && ($this->role == 3 || $this->role == 4))
                                {
                                        $error_code = 0;
                                        //Formattage des données pour la confirmation de la note dans Castillo
                                        $return = $this->immatriculationModel->get_data_confirmation_immatriculation();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $apidata = $return['data'];

                                                $confirmation_response = $this->confirm_payment_note($apidata);

                                                if(isset($confirmation_response['code']) && $confirmation_response['code']==200)
                                                {
                                                        // Paiement validé et note confirmée avec succès.
                                                        // Seul send_file_integration peut faire passer la note au statut 3.
                                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);

                                                        $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                        $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);
                                                }
                                                elseif(isset($confirmation_response['code']) && $confirmation_response['code']==201)
                                                {
                                                        // Paiement validé et note déjà confirmée avec succès.
                                                        // Seul send_file_integration peut faire passer la note au statut 3.
                                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);

                                                        $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                        $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);

                                                        $error_code = $confirmation_response['code'];
                                                        $error_description = $confirmation_response['message'];
                                                }
                                                else
                                                {
                                                        $error_code = $confirmation_response['code'];
                                                        $error_description = $confirmation_response['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement confirm&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 411;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de confirmer ce paiement, veuillez contacter le validateur.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj=="traitement")
                        {
                                if($id > 0 && $this->role == 4)
                                {
                                        $error_code = 0;
                                        //Formattage des données
                                        $return = $this->immatriculationModel->get_data_validation_immatriculation($id);

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Traitements spécifiques
                                                $plaque_immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);

                                                if(!in_array((int) $plaque_immatriculation->Status_2, [5, 6, 7], true))
                                                {
                                                        // Mise à jour du statut de paiement en statut regularisation
                                                        // Pour la premiere sequence
                                                        $this->immatriculationModel->update_integration_immatriculation_validation($id, 5);

                                                        $data = $return['data'];

                                                        $core_banking = strtolower($this->core_banking);

                                                        $response = $this->{$core_banking}->virement_immatriculation_treatment($data);
                                                        $result = json_decode($response, true);

                                                        if($this->immatriculationModel->has_partially_completed_primary_instructions($id))
                                                        {
                                                                // La première écriture a débité le client, mais au moins une
                                                                // autre écriture de priorité 0 doit encore être régularisée.
                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 6);
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 300;
                                                                $error_description = 'Paiement partiellement trait&eacute; : la premi&egrave;re &eacute;criture a r&eacute;ussi, mais les autres doivent &ecirc;tre r&eacute;gularis&eacute;es.';
                                                        }
                                                        elseif(isset($result['response']) && $result['response'] == 200)
                                                        {
                                                                // update cbs journalisation of immatriculation after a successfull response
                                                                $this->immatriculationModel->update_integration_immatriculation_journalisation();

                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 7);

                                                                $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'],2);
                                                                $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'],2);

                                                                //Formattage des données pour la confirmation dans Castillo
                                                                $return = $this->immatriculationModel->get_data_confirmation_immatriculation();

                                                                if(isset($return['code']) && $return['code'] == 200)
                                                                {
                                                                        $apidata = $return['data'];

                                                                        $confirmation_response = $this->confirm_payment_note($apidata);

                                                                        if(isset($confirmation_response['code']) && $confirmation_response['code']==200)
                                                                        {
                                                                                // Mise à jour du statut de paiement en statut validE et confirmE
                                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);
                                                                        }
                                                                        elseif(isset($confirmation_response['code']) && $confirmation_response['code']==201)
                                                                        {
                                                                                // Mise à jour du statut de paiement en statut validE et confirmE
                                                                                $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);

                                                                                $error_code = $confirmation_response['code'];
                                                                                $error_description = "Paiement valid&eacute; dans Amplitude, Mais : ".$confirmation_response['message'];
                                                                        }
                                                                        else
                                                                        {
                                                                                $error_code = $confirmation_response['code'];
                                                                                $error_description = "Paiement valid&eacute; dans Amplitude, Mais : ".$confirmation_response['message'];
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $error_code = 411;
                                                                        $error_description = "Le traitement de votre demande a échoué. Veuillez réessayer";
                                                                }

                                                        }
                                                        elseif(isset($return['code']) && $return['code'] == 300)
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 300;
                                                                $error_description = 'Paiement trait&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                        }
                                                        elseif(isset($return['code']) && $return['code'] == 411)
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 411;
                                                                $error_description = 'Problème de connexion lors de l\'intégration des écritures dans le Core Banking. Veuillez aller sur le menu régularization pour réessayer';
                                                        }
                                                        else
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);

                                                                $error_code = 411;
                                                                $error_description = "La communication avec le Core Banking a échoué. Veuillez aller sur le menu régularization pour réessayer";
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = 411;
                                                        $error_description = 'Ce paiement est déjà dans le menu régularisation';
                                                }
                                        }
                                        else
                                        {
                                                // Mettre a jour le champ Attempts_29 dans la table instructions
                                                $this->immatriculationModel->update_integration_immatriculation_attempts($id, 0);
                                                $error_code = 411;
                                                $error_description = "Le traitement de votre demande n’a pas pu aboutir. Veuillez réessayer.";
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement trait&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 411;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de traiter ce paiement, veuillez contacter l\'opérateur.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj == "save_cbs_journalisation")
                        {
                                $paiement_data = $id;

                                $instructions = $arg;
                                $type=$param;
                                $final_return = '';
                                $data_= array();

                                $noteid = isset($paiement_data['Noteid_26']) ? $paiement_data['Noteid_26'] : 0;

                                $note_info = $this->immatriculationModel->get_integration_immatriculation_by_reference($noteid);

                                if(!empty($note_info))
                                {
                                        # Get data to save
                                        $return = $this->immatriculationModel->get_data_cbs_journalisation($paiement_data, $instructions, $note_info, $type);

                                        if($return['code'] == '200')
                                        {
                                                $this->immatriculationModel->save_cbs_journalisation($return['data'], NULL);
                                                $final_return =  $return['code'];
                                        }
                                        else
                                        {
                                                $final_return = $return['code'];
                                        }
                                }
                                else
                                {
                                        $final_return = 404;
                                }

                                return $final_return;
                        }
                        elseif ($obj == "integration_sftp")
                        {

                                /*
                                 * --------------------------------------------
                                 * Variable initialization
                                 * --------------------------------------------
                                 */
                                $data = [];
                                $fileids = [];
                                $offices_data = [];
                                $total_amount_debited = 0;
                                $total_amount_credited = 0;
                                $nbfile = 0;

                                if(isset($_POST['file_line']) && !empty($_POST['file_line']))
                                {
                                        $integration_date = isset($_POST['integration_date'])
                                                ? trim($_POST['integration_date'])
                                                : '';
                                        $summary_date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $integration_date)
                                                ? $integration_date
                                                : gmdate('Y-m-d');
                                        $type = isset($_POST['type_integration'])
                                                ? trim($_POST['type_integration'])
                                                : '';

                                        if (!in_array($type, ['branch', 'branchless'], true))
                                        {
                                                echo 0;
                                                return;
                                        }
                                        $lockName = $this->immatriculationModel->acquire_integration_lock(
                                                'summary:' . $_SESSION['Logiref_guichet'] . ':' . $type . ':' . $summary_date
                                        );

                                        if ($lockName === false)
                                        {
                                                echo 0;
                                                return;
                                        }

                                        try
                                        {
                                        $data['Date_1'] = $summary_date . ' ' . gmdate('H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];

                                        foreach($_POST['file_line'] as $row)
                                        {
                                                // L'entrée est encodée en base64 pour conserver le JSON complet dans un champ hidden
                                                $decoded_row = base64_decode($row, true);
                                                $file_object = json_decode($decoded_row, true);

                                                if (!is_array($file_object)
                                                        || empty($file_object['office'])
                                                        || empty($file_object['amount_currency'])
                                                        || empty($file_object['instructions_ids'])
                                                        || empty($file_object['notes_ids'])
                                                        || (int) $file_object['nb_instructions_by_office'] <= 0
                                                        || (float) $file_object['amount_debited_by_office'] <= 0)
                                                {
                                                        echo 0;
                                                        return;
                                                }

                                                $offices_data [] = [

                                                        'office'=> $file_object['office'],
                                                        'path'=> '',
                                                        'amount_debited'=> $file_object['amount_debited_by_office'],
                                                        'amount_credited'=> $file_object['amount_credited_by_office'],
                                                        'amount_currency'=> $file_object['amount_currency'],
                                                        'bankaccount'=> $file_object['bank_account'],
                                                        'payment_ids'=> json_encode($file_object['notes_ids']),
                                                        'nbinstructions'=> $file_object['nb_instructions_by_office'],
                                                        'nnotes'=> $file_object['nb_notes_by_office'],
                                                        'journalisationid'=>json_encode($file_object['instructions_ids']),
                                                        'noteids'=>json_encode($file_object['notes_ids'])
                                                ];

                                                $total_amount_debited += $file_object['amount_debited_by_office'];
                                                $total_amount_credited += $file_object['amount_credited_by_office'];

                                                $nbfile++;
                                        }

                                        $data['Totalamountdebited_8'] = $total_amount_debited;
                                        $data['Totalamountcredited_9'] = $total_amount_credited;
                                        $data['Officesdata_10'] = json_encode($offices_data);
                                        $data['Nbfiles_7'] = $nbfile;
                                        $data['Branch_11'] = $_SESSION['Logiref_guichet'];
                                        $data['Type_13'] = 'immatric';
                                        $data['Type_16'] = $type;

                                        $summaryHash = hash('sha256', json_encode($offices_data));
                                        $activeSummaries = $this->immatriculationModel
                                                ->get_active_integration_summaries($summary_date, $type);

                                        foreach ($activeSummaries as $activeSummary)
                                        {
                                                $activeOffices = json_decode($activeSummary->Officesdata_10, true);
                                                if (is_array($activeOffices)
                                                        && hash('sha256', json_encode($activeOffices)) === $summaryHash)
                                                {
                                                        echo $activeSummary->Id_0;
                                                        return;
                                                }
                                        }

                                        # Save id of each file line
                                        $id = $this->immatriculationModel->save_integration_summary($data, NULL);

                                        if($id > 0)
                                        {
                                                echo $id;
                                        }
                                        else
                                        {
                                                echo 0;
                                        }
                                        }
                                        finally
                                        {
                                                $this->immatriculationModel->release_integration_lock($lockName);
                                        }
                                }
                        }
                        elseif ($obj == "create_file_xml")
                        {
                                /*
                                 * --------------------------------------------
                                 * Variable initialization
                                 * --------------------------------------------
                                 */

                                $data_to_save = array();
                                $ids = array();
                                $integrationids = array();
                                $bureau = array();
                                $result = array();
                                $path = '';
                                $request = array();
                                $designations = array();
                                $tax_payer = array();
                                $agence_src = $_SESSION['Logiref_guichet'];
                                $users = $this->invLogirefModel->get_dropdown('users_array');
                                $user = $this->session->userdata['user_id'];
                                $account_id = $this->session->userdata['account_id'];
                                $operateur = $users[$user];

                                $type = isset($_POST['type_integration'])
                                        ? trim($_POST['type_integration'])
                                        : '';

                                if (!in_array($type, ['branch', 'branchless'], true))
                                {
                                        echo json_encode(['code' => 422, 'message' => 'Type d’intégration invalide.']);
                                        return;
                                }

                                $lockName = $this->immatriculationModel->acquire_integration_lock('files:' . $id);
                                if ($lockName === false)
                                {
                                        echo json_encode(['code' => 409, 'message' => 'Une création est déjà en cours.']);
                                        return;
                                }

                                try
                                {

                                $integration_summary = $this->immatriculationModel->get_integration_sftp_summary_by_id($id);

                                if (empty($integration_summary)
                                        || (int) $integration_summary->Account_3 !== (int) $account_id
                                        || $integration_summary->Branch_11 !== $_SESSION['Logiref_guichet']
                                        || (!empty($integration_summary->Type_16)
                                                && $integration_summary->Type_16 !== $type))
                                {
                                        echo json_encode([
                                                'code' => 403,
                                                'message' => 'Le type demandé ne correspond pas au traitement enregistré.'
                                        ]);
                                        return;
                                }

                                if (empty($integration_summary->Type_16))
                                {
                                        // Compatibilité avec les anciens résumés créés avant que le
                                        // type soit enregistré dès leur constitution.
                                        $this->immatriculationModel->save_integration_summary(
                                                ['Type_16' => $type],
                                                $integration_summary->Id_0
                                        );
                                        $integration_summary->Type_16 = $type;
                                }

                                $offices_data = json_decode($integration_summary->Officesdata_10, true);

                                if (empty($offices_data) || !is_array($offices_data))
                                {
                                        echo json_encode(['code' => 422, 'message' => 'Aucune donnée valide à intégrer.']);
                                        return;
                                }

                                $existingFiles = $this->immatriculationModel->get_integrations_sftp_by_treatmentid($id);
                                $existingFilesByKey = [];

                                foreach ($existingFiles as $existingFile)
                                {
                                        if (!$this->is_valid_integration_xml_file($existingFile->Path_16))
                                        {
                                                $this->immatriculationModel->save_integration_sftp(
                                                        ['Status_2' => 0],
                                                        $existingFile->Id_0
                                                );
                                                continue;
                                        }

                                        $existingJournalisation = json_decode($existingFile->Journalisationid_13, true);
                                        $key = $existingFile->Office_7 . '|'
                                                . hash('sha256', (string) $existingJournalisation);
                                        $existingFilesByKey[$key] = $existingFile;
                                }

                                foreach($offices_data as $row)
                                {
                                        if (empty($row['office'])
                                                || empty($row['journalisationid'])
                                                || (int) $row['nbinstructions'] <= 0
                                                || (float) $row['amount_debited'] <= 0)
                                        {
                                                continue;
                                        }

                                        $fileKey = $row['office'] . '|'
                                                . hash('sha256', (string) $row['journalisationid']);

                                        if (isset($existingFilesByKey[$fileKey]))
                                        {
                                                $existingFile = $existingFilesByKey[$fileKey];
                                                $integrationids[$row['office']][] = $existingFile->Id_0;
                                                $bureau[] = $row['office'];
                                                continue;
                                        }

                                        $ref_integration = $this->immatriculationModel->generate_unique_reference_for_sftp();
                                        $request['journalisation_ids'] = $row['journalisationid'];
                                        $request['total_amount'] = $row['amount_debited'];
                                        $request['debit_account'] = $row['bankaccount'];
                                        $request['debit_account_currency'] = $row['amount_currency'];
                                        $request['type'] = 'immatric';
                                        $request['payment_type'] = $type;
                                        $request['logirefid'] = $ref_integration;
                                        $bureau [] = $row['office'];

                                        $return = $this->siop->create_xml_request_immatriculation($request);

                                        // Interpréter les codes erreurs attendus 405/406
                                        if (is_numeric($return) && in_array((int)$return, [405, 406], true)) {
                                                log_message('error', 'SIOP create_xml_request returned numeric error code '.$return.' for office '.$row['office']);
                                                break; // arrêt de traitement sur erreur critique
                                        }

                                        // Parfois la réponse est un JSON d'erreur (string), ex. {"code":405,...}
                                        if (is_string($return)) {
                                                $decodedError = json_decode($return, true);
                                                if (json_last_error() === JSON_ERROR_NONE && isset($decodedError['code'])) {
                                                        $errorCode = (int)$decodedError['code'];
                                                        log_message('error', 'SIOP create_xml_request returned JSON error payload for office '.$row['office'].': '.json_encode($decodedError));
                                                        if (in_array($errorCode, [405, 406], true)) {
                                                                break;
                                                        }

                                                        // continuer sur l'office suivant
                                                        continue;
                                                }
                                        }

                                        $xml = (string)$return;

                                        if (trim($xml) === '') {
                                                log_message('error', 'SIOP create_xml_request returned empty payload for office '.$row['office']);
                                                continue;
                                        }

                                        $operateur = ltrim($operateur);
                                        $name = str_replace(' ', '-', $operateur);
                                        $fname = explode('-', $name)[0];

                                                $filename = 'SIOP_LOGIREF' . date('d') . date('m') . $fname . substr(explode('-', $name)[1], 0, 1) . "_" . $ref_integration.'_immatriculation';
                                                $path = './drive/logiref/' . $account_id . '/' . date('Y-m') . '/integration/siop';

                                                if (is_dir($path) == false) 
                                                {
                                                        mkdir($path, 0777, true);
                                                }

                                                $f_dir = $path . '/' . $filename;

                                                // Si le fichier portant ce nom existe.
                                                if (is_file($f_dir) == true) 
                                                {
                                                        // On recupère ledernier caractère du nom du fichier.
                                                        $f = substr($filename, -1);

                                                        // Si le dernier caractère est un numerique.
                                                        if (is_numeric($f)) 
                                                        {
                                                                // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                                                $f += 1;
                                                                $filename = $filename . $f;
                                                        } 
                                                        else 
                                                        {
                                                                $filename . '1';
                                                        }

                                                        $path = $path . '/' . $filename;
                                                } 
                                                else 
                                                {
                                                        $path = $f_dir;
                                                }

                                                // Charger le contenu XML dans DOMDocument pour le formater.
                                                $cleanedXml = $this->clean_xml_entities($xml);

                                                try {
                                                        $dom = new \DOMDocument('1.0', 'UTF-8');
                                                        $dom->preserveWhiteSpace = false;
                                                        $dom->formatOutput = true;

                                                        $dom->loadXML($cleanedXml, LIBXML_NOBLANKS);

                                                        $xpath = new \DOMXPath($dom);
                                                        $nbOfTxsNode = $xpath->query('//*[local-name()="NbOfTxs"]')->item(0);
                                                        $ctrlSumNode = $xpath->query('//*[local-name()="CtrlSum"]')->item(0);
                                                        $nbOfTxs = $nbOfTxsNode ? (int) trim($nbOfTxsNode->nodeValue) : 0;
                                                        $ctrlSum = $ctrlSumNode
                                                                ? (float) str_replace([' ', ','], ['', '.'], trim($ctrlSumNode->nodeValue))
                                                                : 0;

                                                        if ($nbOfTxs <= 0 || $ctrlSum <= 0)
                                                        {
                                                                log_message(
                                                                        'error',
                                                                        'Fichier immatriculation refusé (NbOfTxs/CtrlSum nul) pour '
                                                                        . $row['office'] . '/' . $row['amount_currency']
                                                                );
                                                                continue;
                                                        }

                                                        $bytes = file_put_contents($path, $dom->saveXML(), LOCK_EX);
                                                } catch (\Throwable $e) {
                                                        log_message('error', 'DOMDocument::loadXML failed for office '.$row['office'].': '.$e->getMessage());
                                                        continue; // passer à l'office suivant
                                                }

                                                if($bytes === false)
                                                {
                                                        $return = 500;
                                                }
                                                else
                                                {
                                                        # Get data to save in the table
                                                        $data = $this->immatriculationModel->get_data_integration_sftp($row, $path, $id, $ref_integration);

                                                        # Save the integration sftp by office
                                                        $integrationids[$row['office']][] = $this->immatriculationModel->save_integration_sftp($data, NULL);
                                                }
                                }

                                $createdFilesCount = array_sum(array_map('count', $integrationids));

                                if (!empty($integrationids) && $createdFilesCount === count($offices_data))
                                {
                                        $data_to_update = [];

                                        $data_to_update['Status_2'] = 2;
                                        $data_to_update['Integrationsftpid_14'] = json_encode($integrationids);
                                        $data_to_update['Officespending_17'] = json_encode($bureau);
                                        $data_to_update['Type_16'] = $type;

                                        $this->immatriculationModel->save_integration_summary($data_to_update, $id);

                                        $return = 200;
                                } 
                                else 
                                {
                                        $return = 422;
                                }

                                $result['code'] = $return;
                                $result['integrationids'] = $integrationids;
                                $result['bureau'] = $bureau;

                                echo json_encode($result);
                                }
                                finally
                                {
                                        $this->immatriculationModel->release_integration_lock($lockName);
                                }
                        }
                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "validate_paiments")
                        {
                                $error = '';
                                if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                                return $error;
                        }
                        elseif($obj == "get_paiment_transid")
                        {

                                $transid = $_POST['transID'] ?? "";

                                $paiement_tresor = $this->immatriculationModel->get_paiement_tresor_by_transactionid($transid);
                                if (empty($paiement_tresor))
                                        $paiement_propres = $this->immatriculationModel->get_paiement_propre_by_transactionid($transid);

                                if (!empty($paiement_tresor) || !empty($paiement_propres))
                                        echo '405';
                                else
                                        echo '200';
                        }
                        elseif ($obj == "get_transactions_by_message_id")
                        {
                                $messageId = $data;

                                $row = $this->immatriculationModel->get_ack_by_message_id($messageId);

                                if (!$row || empty($row->TxInfAndSts_14)) {
                                    return $this->data("empty_transaction_data");
                                }

                                /**
                                 * Décodage du JSON stocké en base
                                 */
                                $transactions = json_decode($row->TxInfAndSts_14);

                                if (!is_array($transactions)) {
                                    return $this->data("empty_transaction_data");
                                }

                                // ================================
                                // Calculs globaux
                                // ================================
                                $totalAmount = 0;
                                $accepted = 0;
                                $pending  = 0;
                                $rejected = 0;

                                foreach ($transactions as $tx) {

                                    $amount = $tx->OrgnlTxRef->Amt->InstdAmt ?? 0;
                                    $totalAmount += $amount;

                                    switch ($tx->TxSts ?? null) {
                                        case 'ACSP':
                                            $accepted++;
                                            break;

                                        case 'PDNG':
                                            $pending++;
                                            break;

                                        default:
                                            $rejected++;
                                            break;
                                    }
                                }

                                return [
                                    'transactions' => $transactions,
                                    'totalTx'      => count($transactions),
                                    'totalAmount'  => $totalAmount,
                                    'accepted'     => $accepted,
                                    'pending'      => $pending,
                                    'rejected'     => $rejected,
                                ];
                        }
                        elseif ($obj == "empty_transaction_data") 
                        {
                                return [
                                    'transactions' => [],
                                    'totalTx'      => 0,
                                    'totalAmount'  => 0,
                                    'accepted'     => 0,
                                    'pending'      => 0,
                                    'rejected'     => 0,
                                ];
                        }
                        elseif ($obj == "verify_total_matches_tax_sum") 
                        {
                                $data = $_POST;

                                // Récupération du montant total du bulletin
                                $bl_amount_unformated = isset($data['Montant_11']) ? $data['Montant_11'] : 0;
                                $bl_amount = floatval(str_replace([' ', ','], ['', '.'], $bl_amount_unformated));

                                // Récupération des montants des taxes
                                $taxes_amount = $data['taxes_amounts'] ?? [];

                                // Validation des données d'entrée
                                if ($bl_amount > 0 && !empty($taxes_amount)) 
                                {
                                        // Convertir tous les montants de taxe en float (au cas où)
                                        $taxes_amount = array_map('floatval', $taxes_amount);

                                        $sum_taxes = array_sum($taxes_amount);

                                        // Tolérance d'arrondi (0.01 pour centimes)
                                        //if (abs($bl_amount - $sum_taxes) < 0.01) 
                                        if (true)
                                        {
                                                echo '200';
                                        }
                                        else
                                        {
                                                echo '300';
                                        }
                                }
                                else
                                {
                                        echo '402';
                                }
                        }
                        elseif ($obj == "aggregate_instructions_by_office")
                        {
                                $raw_instructions = $data;

                                $instructions_by_office_currency = [];

                                $files_instructions_data = [];

                                if (!empty($raw_instructions))
                                {
                                        /**
                                         * Regroupement par bureau + devise
                                         */
                                        foreach ($raw_instructions as $row)
                                        {
                                                $currency = $this->data(
                                                    "get_currency_of_immatriculation_instructions",
                                                    $row->Instructions_11
                                                );

                                                $key = $row->Office_7 . '_' . $currency;

                                                $instructions_by_office_currency[$key][] = $row;
                                        }

                                        /**
                                         * Construction des fichiers
                                         */
                                        foreach ($instructions_by_office_currency as $key => $rows)
                                        {
                                                $currency = $this->data(
                                                    "get_currency_of_immatriculation_instructions",
                                                    $rows[0]->Instructions_11
                                                );

                                                $file_object = new \stdClass();

                                                $file_object->office = $rows[0]->Office_7;

                                                $file_object->amount_debited_by_office =
                                                    $this->immatriculationModel
                                                        ->sum_instructions_amount_debited_by_office($rows);

                                                $file_object->amount_credited_by_office =
                                                    $this->immatriculationModel
                                                        ->sum_instructions_amount_credited_by_office($rows);

                                                $file_object->amount_currency = $currency;

                                                $file_object->bank_account =
                                                    isset($rows[0]->Account_16)
                                                        ? $rows[0]->Account_16
                                                        : '00000000000000000000000';

                                                $file_object->nb_instructions_by_office =
                                                    $this->immatriculationModel
                                                        ->sum_nb_instructions_by_office($rows);

                                                $file_object->nb_notes_by_office =
                                                    $this->immatriculationModel
                                                        ->sum_nb_notes_by_office($rows);

                                                $file_object->instructions_ids =
                                                    $this->immatriculationModel
                                                        ->construct_instructions_id_by_office($rows);

                                                $file_object->notes_ids =
                                                    $this->immatriculationModel
                                                        ->construct_notes_id_by_office($rows);

                                                $files_instructions_data[$key] = $file_object;
                                        }

                                        return $files_instructions_data;
                                }

                                return [];
                        }
                        elseif($obj == "get_currency_of_immatriculation_instructions")
                        {
                                $immatric_instructions = $data;
                                $result = json_decode($immatric_instructions, true);

                                if (json_last_error() !== JSON_ERROR_NONE) {
                                    return null;
                                }

                                return $result[0]['Devise_11'] ?? null;
                        }
                        elseif ($obj == "construct_files_instructions_data")
                        {
                                $offices_data = [];

                                foreach($data as $row)
                                {
                                        $key = $row->office . '_' . $row->amount_currency;

                                        $files_instructions_data = new \stdClass();

                                        $files_instructions_data->office = $row->office;
                                        $files_instructions_data->path = $row->path;

                                        $files_instructions_data->amount_debited_by_office =
                                            $row->amount_debited;

                                        $files_instructions_data->amount_credited_by_office =
                                            $row->amount_credited;

                                        $files_instructions_data->amount_currency =
                                            $row->amount_currency;

                                        $files_instructions_data->bank_account =
                                            $row->bankaccount;

                                        $files_instructions_data->nb_notes_by_office =
                                            $row->nnotes;

                                        $files_instructions_data->nb_instructions_by_office =
                                            $row->nbinstructions;

                                        $files_instructions_data->payment_ids =
                                            $row->payment_ids;

                                        $files_instructions_data->instructions_ids =
                                            $row->journalisationid;

                                        $files_instructions_data->notes_ids =
                                            $row->noteids;

                                        $offices_data[$key] = $files_instructions_data;
                                }

                                return $offices_data;
                        }
                        elseif ($obj == "create_file_xml")
                        {
                                // Le flux en ligne utilise le même générateur idempotent et validé
                                // que le flux agence. Cela évite toute divergence de contrôles.
                                return $this->save("create_file_xml", $data);

                                /*
                                 * --------------------------------------------
                                 * Variable initialization
                                 * --------------------------------------------
                                 */

                                $data_to_save = array();
                                $id = $data;
                                $ids = array();
                                $integrationids = array();
                                $bureau = array();
                                $result = array();
                                $path = '';
                                $request = array();
                                $designations = array();
                                $tax_payer = array();
                                $agence_src = $_SESSION['Logiref_guichet'];
                                $users = $this->invLogirefModel->get_dropdown('users_array');
                                $user = $this->session->userdata['user_id'];
                                $account_id = $this->session->userdata['account_id'];
                                $operateur = $users[$user];

                                $type=$_POST['type_integration'];

                                $integration_summary = $this->immatriculationModel->get_integration_sftp_summary_by_id($id);

                                $offices_data = json_decode($integration_summary->Officesdata_10, true);

                                foreach($offices_data as $row)
                                {
                                        $ref_integration = $this->immatriculationModel->generate_unique_reference_for_sftp();
                                        $request['journalisation_ids'] = $row['journalisationid'];
                                        $request['total_amount'] = $row['amount_debited'];
                                        $request['debit_account'] = $row['bankaccount'];
                                        $request['debit_account_currency'] = 'CDF';
                                        $request['type'] = 'immatric';
                                        $request['payment_type'] = $type;
                                        $request['logirefid'] = $ref_integration;
                                        $bureau [] = $row['office'];

                                        $return = $this->siop->create_xml_request_immatriculation($request);

                                        // Interpréter les codes erreurs attendus 405/406
                                        if (is_numeric($return) && in_array((int)$return, [405, 406], true)) {
                                                log_message('error', 'SIOP create_xml_request returned numeric error code '.$return.' for office '.$row['office']);
                                                break; // arrêt de traitement sur erreur critique
                                        }

                                        // Parfois la réponse est un JSON d'erreur (string), ex. {"code":405,...}
                                        if (is_string($return)) {
                                                $decodedError = json_decode($return, true);
                                                if (json_last_error() === JSON_ERROR_NONE && isset($decodedError['code'])) {
                                                        $errorCode = (int)$decodedError['code'];
                                                        log_message('error', 'SIOP create_xml_request returned JSON error payload for office '.$row['office'].': '.json_encode($decodedError));
                                                        if (in_array($errorCode, [405, 406], true)) {
                                                                break;
                                                        }

                                                        // continuer sur l'office suivant
                                                        continue;
                                                }
                                        }

                                        $xml = (string)$return;

                                        if (trim($xml) === '') {
                                                log_message('error', 'SIOP create_xml_request returned empty payload for office '.$row['office']);
                                                continue;
                                        }

                                        $operateur = ltrim($operateur);
                                        $name = str_replace(' ', '-', $operateur);
                                        $fname = explode('-', $name)[0];

                                                $filename = 'SIOP_LOGIREF' . date('d') . date('m') . $fname . substr(explode('-', $name)[1], 0, 1) . "_" . $ref_integration;
                                                $path = './drive/logiref/' . $account_id . '/' . date('Y-m') . '/integration/siop';

                                                if (is_dir($path) == false) 
                                                {
                                                        mkdir($path, 0777, true);
                                                }

                                                $f_dir = $path . '/' . $filename;

                                                // Si le fichier portant ce nom existe.
                                                if (is_file($f_dir) == true) 
                                                {
                                                        // On recupère ledernier caractère du nom du fichier.
                                                        $f = substr($filename, -1);

                                                        // Si le dernier caractère est un numerique.
                                                        if (is_numeric($f)) 
                                                        {
                                                                // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                                                $f += 1;
                                                                $filename = $filename . $f;
                                                        } 
                                                        else 
                                                        {
                                                                $filename . '1';
                                                        }

                                                        $path = $path . '/' . $filename;
                                                } 
                                                else 
                                                {
                                                        $path = $f_dir;
                                                }

                                                // Charger le contenu XML dans DOMDocument pour le formater.
                                                $cleanedXml = $this->clean_xml_entities($xml);

                                                try {
                                                        $dom = new \DOMDocument('1.0', 'UTF-8');
                                                        $dom->preserveWhiteSpace = false;
                                                        $dom->formatOutput = true;

                                                        $dom->loadXML($cleanedXml, LIBXML_NOBLANKS);

                                                        $bytes = file_put_contents($path, $dom->saveXML(), LOCK_EX);
                                                } catch (\Throwable $e) {
                                                        log_message('error', 'DOMDocument::loadXML failed for office '.$row['office'].': '.$e->getMessage());
                                                        continue; // passer à l'office suivant
                                                }

                                                if($bytes === false)
                                                {
                                                        $return = 500;
                                                }
                                                else
                                                {
                                                        # Get data to save in the table
                                                        $data = $this->immatriculationModel->get_data_integration_sftp($row, $path, $id, $ref_integration);

                                                        # Save the integration sftp by office
                                                        $integrationids[$row['office']][] = $this->immatriculationModel->save_integration_sftp($data, NULL);
                                                }
                                }

                                if (!empty($integrationids)) 
                                {
                                        $data_to_update = [];

                                        $data_to_update['Status_2'] = 2;
                                        $data_to_update['Integrationsftpid_14'] = json_encode($integrationids);
                                        $data_to_update['Officespending_17'] = json_encode($bureau);
                                        $data_to_update['Type_16'] = $type;

                                        $this->immatriculationModel->save_integration_summary($data_to_update, $id);

                                        $return = 200;
                                } 
                                else 
                                {
                                        $return = 501;
                                }

                                $result['code'] = $return;
                                $result['integrationids'] = $integrationids;
                                $result['bureau'] = $bureau;

                                echo json_encode($result);
                        }
                        elseif ($obj == "send_file_integration") 
                        {
                                /*
                                * --------------------------------------------
                                * Variable initialization
                                * --------------------------------------------
                                */

                                $office = $_POST['office'];
                                $integrationid = $_POST['integration_id'];

                                $lockName = $this->immatriculationModel
                                        ->acquire_integration_lock('send:' . $integrationid, 5);

                                if ($lockName === false)
                                {
                                        echo json_encode(['code' => 409, 'message' => 'Ce fichier est déjà en cours d’envoi.']);
                                        return;
                                }

                                try
                                {

                                $integration = $this->immatriculationModel->get_integrations_sftp_by_treatmentid_and_office($integrationid, $office);

                                if (empty($integration)
                                        || $integration->Branch_15 !== $_SESSION['Logiref_guichet']
                                        || (int) $integration->Account_3 !== (int) $this->session->userdata['account_id'])
                                {
                                        echo json_encode(['code' => 409, 'message' => 'Ce fichier a déjà été envoyé ou n’est plus disponible.']);
                                        return;
                                }

                                if (!$this->is_valid_integration_xml_file($integration->Path_16))
                                {
                                        $this->immatriculationModel->save_integration_sftp(
                                                ['Status_2' => 0],
                                                $integration->Id_0
                                        );
                                        echo json_encode([
                                                'code' => 422,
                                                'message' => 'Le fichier est vide ou invalide et ne peut pas être envoyé.'
                                        ]);
                                        return;
                                }

                                $request = [];
                                $data_to_update_integration =[];
                                $data_to_update_note = [];
                                $data_to_update_integration = [];
                                $data_to_update_treatment = [];
                                $data_to_update_journalisation = [];
                                $offices = [];

                                $noteids = [];
                                $request['path'] = $integration->Path_16;
                                $request['integrationid'] = $integration->Id_0;
                                $id = $integration->Id_0;
                                $noteids = [];

                                $return = $this->siop->send_immatriculation_file($request);

                                if(isset($return['code']) &&  $return['code'] == 200)
                                {
                                        $json_journalisationids= json_decode($integration->Journalisationid_13, true);
                                        $journalisationids = json_decode($json_journalisationids, true);

                                        $data_to_update_journalisation['Status_2'] = 3;

                                        $this->immatriculationModel->update_journalisation_by_ids($data_to_update_journalisation, $journalisationids);

                                        $data_to_update_integration['Status_2'] = 2;
                                        $this->immatriculationModel->save_integration_sftp($data_to_update_integration, $id);

                                        // Mise à jour du traitement et des bureaux traités
                                        $this->data("update_treatment_after_office_sent", $integration->Treatmentid_18, $office);

                                        $json_noteids = json_decode($integration->Noteids_14, true);
                                        $noteids = json_decode($json_noteids, true);

                                        // Une note ne devient intégrée (statut 3) qu'après un envoi SIOP réussi,
                                        // et uniquement si elle était préalablement payée et confirmée (statut 2).
                                        $data_to_update_note['Status_2'] = 3;
                                        $this->immatriculationModel->update_notes($data_to_update_note, $noteids, 2);
                                }

                                echo json_encode($return);
                                }
                                finally
                                {
                                        $this->immatriculationModel->release_integration_lock($lockName);
                                }
                        }
                        elseif($obj == "update_treatment_after_office_sent")
                        {
                                $treatmentId = $data;
                                $office = $arg;

                                $data_to_update_treatment = [];

                                // Vérifier si tous les fichiers de ce traitement ont été envoyés
                                $pendingFiles = $this->immatriculationModel->get_integrations_sftp_on_pending_by_treatmentid($treatmentId);

                                if (empty($pendingFiles))
                                {
                                        $data_to_update_treatment['Status_2'] = 3; // Tous les fichiers envoyés
                                }

                                // Mettre à jour les bureaux déjà traités
                                $summary = $this->immatriculationModel->get_summary_by_id($treatmentId);

                                $offices = json_decode($summary->Officestreated_15 ?? '[]', true);

                                if (!is_array($offices)) 
                                {
                                        $offices = [];
                                }

                                if (!in_array($office, $offices, true)) 
                                {
                                        $offices[] = $office;
                                }

                                $data_to_update_treatment['Officestreated_15'] = json_encode(array_values($offices));

                                // Sauvegarder dans la base
                                $this->immatriculationModel->save_integration_summary($data_to_update_treatment, $treatmentId);
                        }
                        elseif($obj == "OBJ ")
                        {

                        }
                }

                public function instructions_journalisation_cbs($data, $instructions)
                {
                        try 
                        {
                                $return_journalisation = $this->save("save_cbs_journalisation", $data, $instructions, "branch");
                        } 
                        catch (\Exception $e) 
                        {   
                                log_message('error_journalidation_cbs_immatriculation', 'SAVE JOURNALISATION ERROR: ' . $e->getMessage());
                                return false;
                        }
                }

                public function init_note_perception($note_perception)
                {
                        if(!empty($note_perception))
                        {
                                $pid = $this->immatriculationModel->save_immatriculation($note_perception);

                                if($pid > 0)
                                {
                                        return $pid;
                                }
                                else
                                {
                                        return 500;
                                }

                        }
                }

                public function init_paiements_beneficiaires($beneficiaires,$data, $post_data)
                {
                        $logiref_beneficiaires=$this->invLogirefModel->get_dropdown("immatriculation_beneficiaries");
                        $return_id=0;

                        if(!empty($beneficiaires))
                        {
                                $i=1;
                                foreach($beneficiaires as $beneficiaire)
                                {
                                        $beneficiaire_code=(!empty($beneficiaire['BeneficiaryCode_16']))?$beneficiaire['BeneficiaryCode_16']:"AIP";

                                        $type = (!empty($logiref_beneficiaires[$beneficiaire_code]['Type_4']))?$logiref_beneficiaires[$beneficiaire_code]['Type_4']:"AIP";

                                        $beneficiaire['suffix']=$i;

                                        $paiement_data=$this->immatriculationModel->get_data_immatriculation_by_type_beneficiaire($beneficiaire,$data,$type, $post_data);

                                        if(isset($paiement_data['code']) && $paiement_data['code']==200)
                                        {
                                                $data_to_save=$paiement_data['data'];

                                                if($type=="RGF")
                                                {
                                                        $return_id=$this->immatriculationModel->save_paiement_tresor($data_to_save);
                                                }
                                                elseif($type=="AIP")
                                                {
                                                        $return_id=$this->immatriculationModel->save_paiement_propre($data_to_save);
                                                }
                                        }
                                        else
                                        {
                                                $return_id=0;
                                        }
                                        $i++;
                                }
                        }
                        return $return_id;
                }
                
                private function confirm_payment_note($confirmation_data)
                {
                        $confirmation_response = $this->castilloImmatriculation->confirmNote($confirmation_data);

                        return [
                                'code' => $confirmation_response['code'] ?? 500,
                                'message' => $confirmation_response['message'] ?? "La confirmation de la note de perception n’a pas pu être effectuée. Veuillez réessayer."
                        ];
                }

                private function is_valid_integration_xml_file($path)
                {
                        if (empty($path) || !is_file($path) || !is_readable($path))
                        {
                                return false;
                        }

                        try
                        {
                                $dom = new \DOMDocument();
                                $previous = libxml_use_internal_errors(true);
                                $loaded = $dom->load($path, LIBXML_NOBLANKS | LIBXML_NONET);
                                libxml_clear_errors();
                                libxml_use_internal_errors($previous);

                                if (!$loaded)
                                {
                                        return false;
                                }

                                $xpath = new \DOMXPath($dom);
                                $nbOfTxsNode = $xpath->query('//*[local-name()="NbOfTxs"]')->item(0);
                                $ctrlSumNode = $xpath->query('//*[local-name()="CtrlSum"]')->item(0);

                                $nbOfTxs = $nbOfTxsNode ? (int) trim($nbOfTxsNode->nodeValue) : 0;
                                $ctrlSumValue = $ctrlSumNode
                                        ? str_replace([' ', ','], ['', '.'], trim($ctrlSumNode->nodeValue))
                                        : '0';

                                return $nbOfTxs > 0 && (float) $ctrlSumValue > 0;
                        }
                        catch (\Throwable $e)
                        {
                                log_message('error', 'Validation XML immatriculation impossible: ' . $e->getMessage());
                                return false;
                        }
                }

                
                private function clean_xml_entities($xml)
                {
                        // Échapper d'abord les caractères réservés XML pour éviter les erreurs de parsing
                        $xml = htmlspecialchars($xml, ENT_XML1, 'UTF-8');
                        // Puis décoder les entités HTML (accents, etc.) pour un contenu lisible
                        return html_entity_decode($xml, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                }
        }
