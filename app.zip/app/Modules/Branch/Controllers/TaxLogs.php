<?php
        class TaxLogs extends MY_Controller {
                /*
                * Presentation: gestion des logs de type systemes
                * Last update:
                * By Papin on the 25.12.2020
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('','','');
                public $roles = '5';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'rawbank';

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project 
                        * Submodule or application is activities 
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */
                        $this->load->model('MY_Logiref_Rawbank');
                        $this->load->model('MY_Logiref_Main');
                        $this->load->model($this->module.'/logs_model');
                        $this->load->model('logiref/logirefModel');;
                        
                        
                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'bank';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;
                        
                        /*
                        * Control user access to this module
                        * If role is not set to access this module, then access denied
                        */
                        if($_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else
                        {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                } 
                
                
                public function index()
                {
                        $this->data['subview'] = 'container';
                        $this->load->view("_layout_".$this->module, $this->data);
                }
                
                
                /*
                * Manages sidebar menu 
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */
                public function set($needle)
                {
                        if(in_array($needle, $this->menus))
                        {
                                if($_SESSION['Logiref_role']==4)
                                {
                                        $this->data['sidebar'] = '';
                                }
                                $this->index();
                        }
                }
                
                
                
                
                
                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "OBJ ")
                        {
                                
                        }
                        elseif($obj == "OBJ ") 
                        {
                                
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                $this->data['country'] = $this->session->userdata['account_country'];
                                echo view('\Modules\Branch\Views\fr_denial', $this->data);
                        }
                }
                
                
                
                
                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "OBJ ")
                        {
                        
                        }
                        elseif($obj == "OBJ ")
                        {
                        
                        }
                        elseif($obj == "OBJ ")
                        {
                        
                        }
                }
                
                
                
                
                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "OBJ ")
                        {
                        
                        }
                        elseif($obj == "OBJ ")
                        {
                        
                        }
                        elseif($obj == "OBJ ")
                        {
                        
                        }
                }
        }

        /* End of file welcome.php  */
        /* Location: /project/activities  */