<?php

        namespace Modules\Branch\Controllers;

        use App\Controllers\BaseController;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Branch\Models\IntegrationModel;
        use Modules\Admin\Models\AccountModel;
        use Modules\Branch\Models\DataModel;
        use Modules\Branch\Models\PermisModel;
        use Modules\Branch\Models\EncaissementModel;
        use Modules\Branch\Models\CurlModel;
        use Modules\Branch\Models\RatesModel;
        use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
        use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
        use Modules\Services\Bsqr\Controllers\Bsqr;
        use Modules\Services\Igor\Controllers\Igor;
        use Modules\Services\Flexcube\Controllers\Flexcube;
        use Modules\Services\Amplitude\Controllers\Amplitude;
        use Modules\Services\Synergies\Controllers\Synergies;
        use Modules\Services\FIBridge\Controllers\FIBridge;
        use Modules\Services\Finacle\Controllers\Finacle;
        use Modules\Services\Logirad\Controllers\Logirad;
        use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
        use Modules\Services\Temenos\Controllers\Temenos;
        use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
        use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

        class TaxPermis extends BaseController {
                /*
                * Presentation:
                * Last update:
                * By Donald k. on the 20.10.2025
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('','','');
                public $role = '5';
                public $group = 'banks';
                public $tva = 0.16;
                public $restrictions = 0;
                public $lang = 'fr';
                public $module = 'branch';
                public $folder = 'permis';

                public $bank = '';
                public $bank_uppercase = '';
                public $core_banking = '';
                public $temenos;
                public $functionalities = array();
                public $options = array();
                public $roles = array();
                public $branch = '';

                public $logirefModel;
                public $encaissementModel;
                public $integrationModel;
                public $comptabilisationModel;
                public $accountsModel;
                public $dataModel;
                public $permisModel;
                public $curlModel;
                public $ratesModel;
                public $amplitude;
                public $amplitudeSolidaireBanque;
                public $comptabilisation;
                public $bsqr;
                public $igor;
                public $flexcube;
                public $synergies;
                public $fiBridge;
                public $finacle;
                public $finacleStandardBank;
                public $logirad;
                public $temenoscrdb;

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */
                        $this->logirefModel = new LogirefModel();
                        $this->encaissementModel = new EncaissementModel();
                        $this->integrationModel = new IntegrationModel();
                        $this->comptabilisationModel = new ComptabilisationModel();
                        $this->accountsModel = new AccountModel();
                        $this->dataModel = new DataModel();
                        $this->curlModel = new CurlModel();
                        $this->comptabilisation = new Comptabilisation();
                        $this->bsqr = new Bsqr();
                        $this->igor = new Igor();
                        $this->flexcube = new Flexcube();
                        $this->temenos = new Temenos();
                        $this->synergies = new Synergies();
                        $this->fiBridge = new FIBridge();
                        $this->finacle = new Finacle();
                        $this->finacleStandardBank = new FinacleStandardBank();
                        $this->amplitude = new Amplitude();
                        $this->amplitudeSolidaireBanque = new AmplitudeSolidaireBanque();
                        $this->ratesModel = new RatesModel();
                        $this->permisModel = new PermisModel();
                        $this->logirad = new Logirad();
                        $this->temenoscrdb = new TemenosCrdb();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'taxpermis';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                        $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                        $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                        $this->data['i'] = 0;

                        $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                        $this->data['deny'] = false;

                        if ($_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else
                        {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }

                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        $this->branch = $_SESSION['Logiref_guichet'];
                        $this->role = $_SESSION['Logiref_role'];

                        if($this->bank != "")
                        {
                                # Enlever @ dans le pageid
                                # Tranformer la premiere lettre en majuscule
                                $this->bank = substr($this->bank, 1);
                                $this->bank_uppercase = ucfirst($this->bank);
                        }

                }


                public function index()
                {
                        if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Branch\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }


                /*
                * Manages sidebar menu
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */

                public function set($needle)
                {
                        if(in_array($needle, $this->menus))
                        {
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                                {
                                        $this->data['sidebar'] = '';
                                }
                                $this->index();
                        }
                }

                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "start")
                        {
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");

                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_permis', $this->data);
                        }
                        elseif ($obj == "verification")
                        {
                                $data = $_POST;
                                $data['Reference_8'] = strtoupper($data['Reference_8']);

                                $integrations = $this->integrationModel->get_note_by_ref($data['Reference_8']);

                                $result = $this->permisModel->check_existing_payments_permis($integrations, $data);

                                $code         = $result['code'];
                                $html         = $result['html'];
                                $checked      = $result['checked'];
                                $encaissement = $result['encaissement'] ?? null;

                                if ($code == 'E200')
                                {
                                        $code = $this->logirad->get_note_permis($data);
                                }

                                if ($this->data('handle_error_codes', $code, $data))
                                {
                                        echo json_encode(['code' => $code, 'message' => $html ?? null]);
                                        die;
                                }

                                $note = $this->integrationModel->get_paiement_logirad($code);

                                if (!isset($note->Id_0))
                                {
                                        echo json_encode(['code' => 'E406', 'message' => 'Un problème est survenu. Merci de réessayer plus tard.']);
                                        return;
                                }

                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGRAD", NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes', "DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];

                                if ($checked)
                                {
                                        $pid = $encaissement->Id_0;
                                        $this->data['encaissement'] = $this->permisModel->get_paiement_info($pid);
                                }
                                else
                                {
                                        $this->data['encaissement'] = $this->dataModel->logirad_migrate_note($code);
                                }

                                $this->data['note_id'] = $code;
                                $this->data['note']    = $note;

                                $htmlView = view('\Modules\Branch\Views\\'.$this->folder.'\_permis_2', $this->data);
                                echo json_encode(['code' => 'SUCCESS', 'html' => $htmlView]);
                        }
                        elseif($obj == "edit")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = '';
                                $this->data['encaissement'] = $encaissement = $this->permisModel->get_paiement_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_permis_3', $this->data);
                        }
                        elseif($obj == "preview")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = 'view';
                                $this->data['encaissement'] = $encaissement = $this->permisModel->get_paiement_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_permis_3', $this->data);
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                echo view($this->lang . '_denial', $this->data);
                        }
                }

                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == 'initiation')
                        {
                                if(!empty($_POST) && ($_POST['Id_0'] == NULL || $_POST['Id_0'] == "") && in_array((int) $this->role, [4, 7, 9], true))
                                {
                                        $error_code = 0;
                                        $return = $this->permisModel->get_data_permis();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $data  = $return['data'];
                                                $return = $this->permisModel->get_formatage_data_permis($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        $data  = $return['data'];

                                                        $check_existing_reference = $this->permisModel->check_paiement_tresor_permis_by_reference($data['Noteid_26']);

                                                        if(isset($check_existing_reference['code']) && $check_existing_reference['code']!='E200')
                                                        {
                                                                $data = array();
                                                                $data['Id_0'] = $check_existing_reference['id'];
                                                        }
                                                        else
                                                        {
                                                                $data['Id_0'] = $this->permisModel->save_paiement_tresor_permis($data);

                                                                if($data['Id_0'] > 0)
                                                                {
                                                                        $instructions = $this->comptabilisation->get_instructions_permis($data);

                                                                        if(!empty($instructions))
                                                                        {
                                                                                $this->comptabilisationModel->save_instructions_permis($data['Id_0'], $data, $instructions, $data['Logirefid_4'], 0);
                                                                        }
                                                                        else{
                                                                                $error_code = 402;
                                                                                $error_description = 'Erreur de construction des instructions de comptabilisation';
                                                                        }

                                                                }
                                                                else
                                                                {
                                                                        $error_code = 401;
                                                                        $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                                }
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits d\'initier un paiement, veuillez contacter l\'op&eacute;rateur qui encaisse le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj == "update")
                        {
                                if(!empty($_POST) && $_POST['Id_0'] > 0 && in_array((int) $this->role, [4, 7, 9], true))
                                {
                                        $error_code = 0;
                                        $return = $this->permisModel->get_data_permis();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $data  = $return['data'];
                                                $return = $this->permisModel->get_formatage_data_permis($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        $data  = $return['data'];

                                                        $data['Id_0'] = $this->permisModel->update_payment_tresor($data, $data['Id_0']);

                                                        if($data['Id_0'] > 0)
                                                        {
                                                                $this->comptabilisationModel->delete_instructions_permis($data['Id_0']);

                                                                $instructions = $this->comptabilisation->get_instructions_permis($data);

                                                                if(!empty($instructions))
                                                                {
                                                                        $this->comptabilisationModel->save_instructions_permis($data['Id_0'], $data, $instructions, $data['Logirefid_4'], 0);
                                                                }
                                                                else{
                                                                        $error_code = '402';
                                                                        $error_description = 'Erreur de construction des instructions de comptabilisation';
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $error_code = '401';
                                                                $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de modifier ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj == "validation")
                        {
                                if($id > 0 && in_array((int) $this->role, [2, 3, 8], true))
                                {
                                        $error_code = 0;
                                        $return = $this->permisModel->get_data_validation_permis($id);

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $this->permisModel->update_payment_validation($id, 5);

                                                $data = $return['data']['firstTrans'];

                                                $core_banking = strtolower($this->core_banking);
                                                $result = $this->{$core_banking}->virement($data);

                                                if(isset($result['response']) && $result['response'] == 200)
                                                {
                                                        $this->permisModel->update_payment_validation($id, 6);

                                                        $data = $return['data']['secondTrans'];

                                                        $result = $this->{$core_banking}->virement($data);

                                                        if(isset($result['response']) && $result['response'] == 200)
                                                        {
                                                                $this->permisModel->update_payment_validation($id, 7);

                                                                $return = $this->permisModel->get_data_confirmation_permis();

                                                                if(isset($return['code']) && $return['code'] == 200)
                                                                {
                                                                        $apidata = $return['data'];
                                                                        //$response = $this->logirad->confirm_note_permis($apidata);
                                                                        $response = "E200";

                                                                        if($response == "E200" || $response == "CP200")
                                                                        {
                                                                                $this->permisModel->update_payment_validation($id, 2);
                                                                        }
                                                                        else
                                                                        {
                                                                                $error_code = $response;
                                                                                $error_description = "Paiement valid&eacute; dans Finacle, Mais la confirmation n'a pas abouti dans Logirad.";
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $error_code = $return['code'];
                                                                        $error_description = $return['message'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->integrationModel->update_integration_permis_attempts($id, 1);

                                                                $error_code = $return['code'];
                                                                $error_description = $return['message'];
                                                        }
                                                }
                                                else
                                                {
                                                        $this->integrationModel->update_integration_permis_attempts($id, 0);

                                                        $error_code = $return['code'];
                                                        $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }

                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                                        echo json_encode($data_return);
                                }
                        }
                        elseif($obj == "deletion")
                        {
                                if($id > 0 && in_array((int) $this->role, [4, 7, 9], true))
                                {
                                        $error_code = 0;
                                        $return = $this->permisModel->get_data_deletion_permis();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $data = $return['data'];
                                                $pid = $this->encaissementModel->update_payment_tresor_permis($data, $id);

                                                if($pid == 0)
                                                {
                                                        $error_code = 404;
                                                        $error_description = 'Paiement non supprim&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement suppri&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }

                        }

                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "validate_paiments")
                        {
                                $error = '';
                                if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                                return $error;
                        }
                        elseif($obj == "get_paiment_transid")
                        {
                                $transid = isset($_POST['transID']) ? $_POST['transID'] : "";

                                $paiement = $this->encaissementModel->get_paiement_permis_by_transactionid($transid);

                                if (!empty($paiement))
                                {
                                        echo '405';
                                }
                                else
                                {
                                        echo '200';
                                }
                        }
                        elseif($obj == "handle_error_codes")
                        {
                                $error_codes = ["E604", "E000", "E002", "E22", "E404", "E405", "E503", "E504", "E505", "E506", "401", "402", "500"];

                                $code = $data;
                                if (!in_array($code, $error_codes))
                                {
                                        return false;
                                }

                                if (isset($data['Typerecette_12']) && $data['Typerecette_12'] == "27421600" && $code == "E404")
                                {
                                        $_SESSION['login_info']['ip']['attempts']++;
                                        if ($_SESSION['login_info']['ip']['attempts'] >= 3)
                                        {
                                                $this->save_ipaddress();
                                                echo json_encode(['code' => 'LOCKOUT', 'message' => 'Nombre maximum de tentatives dépassé.']);
                                                die;
                                        }
                                }
                                else
                                {
                                        $_SESSION['login_info']['ip']['attempts'] = 0;
                                }
                                return true;
                        }
                        elseif($obj == "OBJ ")
                        {

                        }
                }

                public function save_ipaddress()
                {
                        $description = array('Detail'=> '3 tentatives de consultation de permis echouées');

                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = '46';
                        $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];
                        $data['Sessionid_8'] = $this->session->session_id;
                        $data['Observation_9'] = json_encode($description);

                        $this->logirefModel->save_ipaddress($data, NULL);
                }
        }
        /* End of file welcome.php  */
        /* Location: /project/activities  */
