<?php

    namespace Modules\Branch\Controllers;

    use App\Controllers\BaseController;
    use Modules\Branch\Models\CurlModel;
    use Modules\Branch\Models\DataModel;
    use Modules\Branch\Models\RatesModel;
    use Modules\Admin\Models\AccountModel;
    use Modules\Logiref\Models\LogirefModel;
    use Modules\Branch\Models\IntegrationModel;
    use Modules\Branch\Models\EncaissementModel;
    use Modules\Branch\Models\ComptabilisationModel;
    use Modules\Services\Flexcube\Controllers\Flexcube;
    use Modules\Services\Temenos\Controllers\Temenos;
    use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
    use Modules\Services\Bsqr\Controllers\Bsqr;
    use Modules\Services\Igor\Controllers\Igor;
    use Modules\Services\Finacle\Controllers\Finacle;
    use Modules\Services\Amplitude\Controllers\Amplitude;
    use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;
    use Modules\Services\Gesimpots\Controllers\Gesimpots;
    use Modules\Services\Synergies\Controllers\Synergies;
    use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
    use Modules\Services\FIBridge\Controllers\FIBridge;
    use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;

    class TaxDgpek extends BaseController {
            /*
            * Presentation:
            * Last update:
            * By Don@ld K. on the 12.06.2025
            * *  *************************************************************************************************************************SECTION 1
            */
            public $menus = array('','','');
            public $roles = '5';
            public $group = 'banks'; //Banks, Regies, Clients
            public $tva = 0.16;
            public $restrictions = 0; //1 = no access or limited access
            public $lang = 'fr';
            public $module = 'branch';
            public $folder = 'dgpek';
            public $logirefModel;
            public $encaissementModel;
            public $integrationModel;
            public $comptabilisationModel;
            public $accountModel;
            public $ratesModel;
            public $curlModel;
            public $synergies;
            public $comptabilisation;
            public $functionalities;
            public $amplitude;
            public $igor;
            public $bsqr;
            public $bank;
            public $finacle;
            public $finacle_standardbank;
            public $core_banking;
            public $temenos;
            public $gesimpots;
            public $dataModel;
            public $options;
            public $role;
            public $bank_uppercase;
            public $amplitude_solidairebanque;
            public $fibridge;
            public $flexcube;
            public $temenoscrdb;

            public function __construct()
            {
                    parent::__construct();
                    /*
                    * Module is project
                    * Submodule or application is activities
                    * function will be set within display function
                    * PS: A modifier au besoin!!
                    */

                    $this->curlModel = new CurlModel();
                    $this->dataModel = new DataModel();
                    $this->encaissementModel = new EncaissementModel();
                    $this->integrationModel = new IntegrationModel();
                    $this->comptabilisationModel = new ComptabilisationModel();
                    $this->accountModel = new AccountModel();
                    $this->ratesModel = new RatesModel();
                    $this->logirefModel = new LogirefModel();
                    $this->bsqr = new Bsqr();
                    $this->igor = new Igor();
                    $this->finacle = new Finacle();
                    $this->finacle_standardbank = new FinacleStandardBank();
                    $this->amplitude = new Amplitude();
                    $this->gesimpots = new Gesimpots();
                    $this->synergies = new Synergies();
                    $this->comptabilisation = new Comptabilisation();
                    $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                    $this->fibridge = new FIBridge();
                    $this->flexcube = new Flexcube();
                    $this->temenos = new Temenos();
                    $this->temenoscrdb = new TemenosCrdb();

                    $this->data['module'] = $this->module;
                    $this->data['application'] = 'taxdgpek';
                    $this->data['function'] = '';
                    $this->data['role'] = $_SESSION['Logiref_role'];
                    $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                    $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                    $this->data['lang'] = $this->lang;
                    $this->data['group'] = $this->group;
                    $this->data['documents'] = $this->encaissementModel->documents;
                    $this->data['devises'] = $this->encaissementModel->devises;
                    $this->data['modes'] = $this->encaissementModel->modes;
                    $this->data['moyens'] = $this->encaissementModel->moyens;
                    $this->data['infos'] = $this->encaissementModel->infos;
                    $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGPEK", NULL, true);
                    $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes", "DGPEK", NULL, true);
                    $this->data['currency'] = $this->session->userdata['account_currency'];
                    $this->data['fullname'] = $this->session->userdata['user_fname'];
                    $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                    $this->data['userid'] = $this->session->userdata["user_id"];
                    $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                    $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                    $this->data['i'] = 0;
                    $user_roles = $this->session->userdata['user_roles'];

                    if($this->bank != "")
                    {
                            # Enlever @ dans le pageid
                            # Tranformer la premiere lettre en majuscule
                            $this->bank = substr($this->bank, 1);
                            $this->bank_uppercase = ucfirst($this->bank);
                    }

                    $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                    $this->data['i'] = 0;
                    $this->data['deny'] = false;

                    /*
                        * Control user access to this module
                        * If role is not set to access this module, then access denied
                    */
                    if($_SESSION['Logiref_role'] > 2)
                    {
                            $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                    }
                    else
                    {
                            $this->data['sidebar'] = '';
                            $this->data['deny'] = true;
                    }

                    # Retrieve options configured based on the bank connected
                    if (isset($_SESSION['userdata']['options']))
                    {
                            $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                    }
                    else
                    {
                            $this->data['options'] = $this->options = array();
                    }

            }


            public function index()
            {
                    if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                    {
                            $this->data['sidebar'] = '';
                    }
                    $this->data['subview'] = '\Modules\Branch\Views\container';
                    echo view('layouts/layout_main', $this->data);
            }


            /*
            * Manages sidebar menu
            * Must match de third section of the URL
            * PS: A modifier uniquement si c'est necessaire!!
            * *  *************************************************************************************************************************SECTION 2
            */

            public function set($needle)
            {
                        if(in_array($needle, $this->menus))
                        {
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                                {
                                        $this->data['sidebar'] = '';
                                }
                                $this->index();
                        }
            }


            /*
            * Manages all the views
            * View calls are made here
            * * PS: A personnaliser !!
            * *  *************************************************************************************************************************SECTION 3
            */

            public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
            {
                        if($obj == "start")
                        {
                                $this->data['step'] = 1;
                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_'.$obj, $this->data);
                        }
                        elseif($obj == "verification")
                        {
                                $declaration = $this->encaissementModel->check_prepayment_propres_by_note($_POST["Noteid_26"]);

                                if($declaration != NULL){
                                    $this->data['encaissement'] = $declaration;
                                }
                                else{
                                    $this->data['encaissement'] = $this->encaissementModel->get_paiement_propre_info();
                                }

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);

                        }
                        elseif($obj == "create")
                        {
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGPEK", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGPEK");
                                $this->data['recettes'] = $recettes["DGPEK"];
                                $this->data['client'] = $this->logirefModel->get_clients_by_nif($_POST['Nif_17']);
                                $this->data['note_reference'] = $this->encaissementModel->get_paiement_by_reference($_POST['Reference_14']);
                                $this->data['encaissement'] = $this->encaissementModel->get_paiement_tresor_info();
                                $this->data['type_services'] =$this->logirefModel->get_dropdown("type_services");

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);
                        }
                        elseif($obj == "edit")
                        {
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGPEK", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGPEK");
                                $this->data['recettes'] = $recettes["DGPEK"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = '';
                                $this->data['type_services'] =$this->logirefModel->get_dropdown("type_services");
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                        }
                        elseif($obj == "preview")
                        {
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGPEK", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGPEK");
                                $this->data['recettes'] = $recettes["DGPEK"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = 'view';
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                $this->data['country'] = $this->session->userdata['account_country'];
                                echo view('\Modules\Branch\Views\\'.$this->lang.'_denial', $this->data);
                        }
            }




            /*
            * Manages all database updates
            * Calls to model's saving methos are made here
            * PS: A modifier uniquement si c'est necessaire!!
            * *  *************************************************************************************************************************SECTION 4
            */
            public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
            {
                    if($obj == "comptant")
                    {
                            # Save payment
                            # Validate payment form
                            $error = $this->data("validate_paiments");

                            #If form could not be validate
                            if($error !='')
                            {
                                    echo '<div class="alert alert-danger text-white">Error! To assign a member to a group, please select both a member and a group.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                    die;
                            }
                            # If form is validate successfullly
                            else
                            {
                                    $data = array();
                                    $data_id_paiement = array();

                                    if(isset($_POST['Ndeclaration']))
                                    {
                                            $declaration = $_POST['Ndeclaration'];
                                            unset($_POST['Ndeclaration']);
                                    }

                                    // Controle sur les taux d'echange a appliquer
                                    if($_POST['Devise_34'] == 'CDF' && $_POST['Devise_12'] == 'USD')
                                    {
                                            $data = $_POST;
                                    }
                                    else
                                    {
                                            $_POST['Infos']['rate_code'] = 'TTB';
                                            $data = $_POST;
                                    }

                                    $data['Status_2'] = 1;
                                    $data['Account_3'] = $this->session->userdata['account_id'];
                                    if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true)) $data['Makerid_9'] = $this->session->userdata['user_id'];
                                    $benificiaire = $data['Beneficaire_15'] = 'DGPEK';
                                    $infos = $data['Infos'];

                                    // Test if the total_amount has been calculated
                                    if($infos['totalMontant'] == "")
                                    {
                                            $infos['totalMontant'] = $this->encaissementModel->get_montant_total($data);
                                    }

                                    $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                                    #Taux de change
                                    if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                    {
                                            $data['Taux_41'] = $_POST['Taux_41'];
                                    }
                                    else if($data['Devise_12']!='CDF')
                                    {
                                            $taux = json_decode($_SESSION['Bank_rates'], true);
                                            if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                            if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                            if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                    }

                                    //Formatting amount
                                    $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                    $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                    $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                    $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                    $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                    $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                    $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                    $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);


                                    $data['Notereference_30'] = json_encode($infos);
                                    unset($data['Infos']);


                                    #Contre valeur en CDF
                                    $data['Devise_42'] = $data['Devise_12'];
                                    $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                                    # SAVE PAYMENT
                                    # Check if it's a new payment
                                    if($data['Id_0']=="" || $data['Id_0']==0)
                                    {
                                            unset($data['Id_0']);
                                            $data['Id_0'] = NULL;
                                    }

                                    # Encaissement existant
                                    if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                    {
                                            #Is this a validation? Yes if it's a validator or the supervisor
                                            if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                                            {
                                                    #Invocation of the api transfer

                                                    $id = $data['Id_0'];

                                                    $data_to_update['Status_2'] = 5;
                                                    $this->encaissementModel->update_payment_propres($data_to_update, $id);

                                                    $core_banking = strtolower($this->core_banking);
                                                    $return = $this->{$core_banking}->virement($data);
                                                    $return = json_decode($return,true);

                                                    if(isset($return['response']) && $return['response'] == 200)
                                                    {
                                                            $result = json_decode($data['Notereference_30'], true);

                                                            $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";

                                                            $logirefid = $data['Logirefid_4'];

                                                            // Pour eviter la modification du paiment par le validateur
                                                            $data = array();
                                                            $data['Notereference_30'] = json_encode($result);
                                                            $data['Id_0'] = $id;
                                                            $data['Logirefid_4'] = $logirefid;
                                                            $data['Status_2'] = 1;
                                                            $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                            $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                    }
                                                    elseif(isset($return['response']) && $return['response'] != "")
                                                    {
                                                            echo $return['response'];
                                                            die;
                                                    }
                                                    else
                                                    {
                                                            echo 'E411';
                                                            die;
                                                    }

                                            }
                                            else
                                            {
                                                    $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                                    $this->comptabilisationModel->delete_instructions_dgpek($data['Logirefid_4']);
                                            }

                                            # Save changes
                                            $this->encaissementModel->update_payment_propres($data, $data['Logirefid_4']);

                                    }
                                    # Nouvel encaissement
                                    else
                                    {
                                            #Enregistrement
                                            $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                            $instructions = array();
                                            $logiref_id = $data['Logirefid_4'];
                                            if($data['Id_0'] == 0) $data['Id_0'] = NULL;

                                            $pid = $this->encaissementModel->save_payment_propres($data, $data['Id_0']);

                                            $data['Id_0'] = $pid;
                                    }

                                    if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                                    {
                                            #
                                            #Comptabilisation
                                            $agence_src= $_SESSION['Logiref_guichet'];

                                            $periode = isset($infos['standard']) ? $infos['standard'] : "";

                                            $agence_dst=NULL;
                                            $list = NULL;
                                            $comptes_recettes = NULL;
                                            $service_type =$this->logirefModel->get_dropdown("type_services");

                                            $service = isset($service_type[$data['Service_16']]) ? $service_type[$data['Service_16']] : "";
                                            $recette = $data['Typerecette_17'];
                                            $case = $this->comptabilisationModel->get_use_case($data);
                                            $comptes = $this->accountModel->get_comptes_array($list, $agence_src, $agence_dst, $data['Beneficaire_15'], $service, $recette);

                                            switch ($case)
                                            {
                                                    case "case_1":
                                                            $instructions = $this->comptabilisationModel->get_instructions_case_1($data, $comptes,"DGPEK", $comptes_recettes, $service, $periode);
                                                            break;
                                                    case "case_2":
                                                            $instructions = $this->comptabilisationModel->get_instructions_case_2($data, $comptes,"DGPEK", $comptes_recettes, $service, $periode);
                                                            break;
                                                    case "case_3":
                                                            $instructions = $this->comptabilisationModel->get_instructions_case_3($data, $comptes,"DGPEK", $comptes_recettes, $service, $periode);
                                                            break;
                                                    case "case_4":
                                                            $instructions = $this->comptabilisationModel->get_instructions_case_4($data, $comptes,"DGPEK", $comptes_recettes, $service, $periode);
                                                            break;
                                                    case "case_5":
                                                            $instructions = $this->comptabilisationModel->get_instructions_case_5($data, $comptes,"DGPEK", $comptes_recettes, $service, $periode);
                                                            break;
                                                    default:
                                                            //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGPEK");
                                                            break;
                                            }

                                            if(!empty($instructions))
                                            {
                                                    $this->comptabilisationModel->save_instructions_dgpek($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                            }
                                    }

                                    #Return
                                    echo $data['Id_0'];
                                    die;
                            }
                    }
                    elseif($obj == "delete")
                    {
                            $pid = 0;

                            $pid = $this->encaissementModel->delete_paiement_propre($id);

                            if($pid > 0)
                            {
                                $this->comptabilisationModel->delete_instructions_dgpek($id);
                            }
                            #Return
                            echo $pid;
                            die;
                    }
                    elseif($obj == "OBJ ")
                    {

                    }
            }


            /*
            * Manages additional data manipuations
            * Arguments could of any type, arrays or strings
            * PS: A modifier uniquement si c'est necessaire!!
            * *  *************************************************************************************************************************SECTION 5
            */
            public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
            {
                    if($obj == "validate_paiments")
                    {
                            $error = '';
                            if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                            return $error;
                    }
                    elseif($obj == "OBJ ")
                    {

                    }
                    elseif($obj == "OBJ ")
                    {

                    }
            }
    }

    /* End of file welcome.php  */
    /* Location: /project/activities */
