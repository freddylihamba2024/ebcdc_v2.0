<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\AccountModel;
use Modules\Branch\Models\OfflineModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\BulletinsModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Services\Igor\Models\IgorModel;
use Modules\Services\Sftp\Controllers\Siop;
use Modules\Branch\Models\EncaissementModel;
use Modules\Services\Sydonia\Controllers\Sydonia;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Bulletin\Controllers\BulletinLiquidation;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;



class TaxBulletin extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 05.10.2023
         * *  *************************************************************************************************************************SECTION 1
         */

        public $menus = array('batchs', 'integration', '');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'bulletins';
        public $integrationModel;
        public $logirefModel;
        public $bulletinsModel;
        public $dataModel;
        public $curlModel;
        public $comptabilisationModel;
        public $usersModel;
        public $ratesModel;
        public $accountModel;
        public $feesModel;
        public $stakeholderModel;
        public $encaissementModel;
        public $offlineModel;
        public $mainModel;
        public $synergies;
        public $comptabilisation;
        public $functionalities;
        public $igor;
        public $bank;
        public $igorModel;
        public $amplitude;
        public $flexcube;
        public $fibridge;
        public $amplitude_solidairebanque;
        public $finacle_standardbank;
        public $sydonia;
        public $siop;
        public $core_banking;
        public $temenos;
        public $branchModel;
        public $bsqr;
        public $options;
        public $bank_uppercase;
        public $bulletinLiquidation;

        public function __construct() 
        {
                parent::__construct();
                /*
                 * Module is branch 
                 * function will be set within display function
                 * PS: A modifier au besoin
                 */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->bulletinsModel = new BulletinsModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->usersModel = new UsersModel();
                $this->ratesModel = new RatesModel();
                $this->accountModel = new AccountModel();
                $this->feesModel = new FeesModel();
                $this->branchModel = new BranchModel();
                $this->curlModel = new CurlModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->encaissementModel = new EncaissementModel();
                $this->mainModel = new MainModel();
                $this->synergies = new Synergies();
                $this->comptabilisation = new Comptabilisation();
                $this->igor = new Igor();
                $this->bsqr = new Bsqr();
                $this->siop = new Siop();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->igorModel = new IgorModel();
                $this->amplitude = new Amplitude();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->sydonia = new Sydonia();
                $this->offlineModel = new OfflineModel();
                $this->curlModel=new CurlModel();
                $this->fibridge = new FIBridge();
                $this->bulletinLiquidation = new BulletinLiquidation();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxbulletin';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;

                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                $this->data['deny'] = false;

                if ($_SESSION['Logiref_role'] > 2) 
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                } 
                else 
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options'])) 
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                } 
                else 
                {
                        $this->data['options'] = $this->options = array();
                }

                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank_uppercase = ucfirst($this->bank);
                }



                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                 */
        }   

        public function index() {
                if ($_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

    /*
     * Manages sidebar menu 
     * Must match de third section of the URL
     * PS: A modifier uniquement si c'est necessaire!!
     * *  *************************************************************************************************************************SECTION 2
     */

        public function set($needle) 
        {
                if (in_array($needle, $this->menus)) 
                {
                        if ($_SESSION['Logiref_role'] == 4) 
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
         */

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "_integration") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['bulletins'] = $paiement = $this->integrationModel->get_bulletins_to_integrate_by_office();
                        $this->data['paiement'] = current($paiement);

                        $total_amount = 0;
                        $total_commission = 0;
                        
                        foreach ($paiement as $row) 
                        {
                                $total_amount += $row->Amount_12;
                                $total_commission += $row->Commission_26;
                        }

                        $this->data['total_amount'] = $total_amount;
                        $this->data['total_commission'] = $total_commission;

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);
                        $this->data['compte_guichet_unique'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";

                        echo view('\Modules\Branch\Views\bulletins\_integration', $this->data);
                } 
                elseif ($obj == "_integration_branch") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $treatment_on_goings = $this->integrationModel->get_integrations_sftp_treatment_in_progress("branch");

                        if(!empty($treatment_on_goings))
                        { 
                                $treatment_on_going = current($treatment_on_goings);
                                $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                $this->data['files_instructions_data'] = $files_instructions_data;
                                $this->data['treatment_on_going'] = $treatment_on_going;
                        }
                        else
                        {
                                $raw_instructions = $this->integrationModel->get_instructions_to_treat_for_sftp_dgda("branch");
                                $this->data['files_instructions_data'] = $this->data("aggregate_instructions_by_office", $raw_instructions);
                                $this->data['treatment_on_going'] = '';
                        }
                        
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\bulletins\_integration_branch', $this->data);
                } 
                elseif ($obj == "filter_integration_treatment") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $treatment_on_goings = $this->integrationModel->get_integrations_sftp_treatment_by_filter();

                        if(!empty($treatment_on_goings))
                        { 
                                $treatment_on_going = current($treatment_on_goings);
                                $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                $this->data['files_instructions_data'] = $files_instructions_data;
                                $this->data['treatment_on_going'] = $treatment_on_going;
                        }
                        else
                        {
                                $this->data['files_instructions_data'] = [];
                                $this->data['treatment_on_going'] = '';
                        }
                        
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\bulletins\_filter_integration_treatment', $this->data);
                } 
                elseif ($obj == "_integration_filter") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['files_instructions_data'] = [];
                        $this->data['treatment_on_going'] = '';
                        
                        
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\bulletins\_integration_filter', $this->data);
                }
                elseif ($obj == "_integration_rbo") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $treatment_on_goings = $this->integrationModel->get_integrations_sftp_treatment_in_progress("branchless");

                        if(!empty($treatment_on_goings))
                        { 
                                $treatment_on_going = current($treatment_on_goings);
                                $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                $this->data['files_instructions_data'] = $files_instructions_data;
                                $this->data['treatment_on_going'] = $treatment_on_going;
                        }
                        else
                        {
                                $raw_instructions = $this->integrationModel->get_instructions_to_treat_for_sftp_dgda("branchless");
                                $this->data['files_instructions_data'] = $this->data("aggregate_instructions_by_office", $raw_instructions);
                                $this->data['treatment_on_going'] = '';
                        }
                        
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\bulletins\_integration_rbo', $this->data);
                } 
                elseif($obj=="_integration_details")
                {
                        $bulletins_ids=$_POST['bulletins_ids'];
                        
                        $bulletins=array();
                        
                        foreach($bulletins_ids as $id)
                        {
                                $bulletin=$this->integrationModel->get_integration_sydonia_by_id($id);
                                if(!empty($bulletin))
                                {
                                        $bulletins[]=$bulletin;
                                }
                        }
                        $this->data['bulletins']=$bulletins;
                        return view("Modules\Branch\Views\bulletins\_integration_details",$this->data);
                }
                elseif ($obj == "start")
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        if(isset($_SESSION['bank_account']))unset($_SESSION['bank_account']);
                        if(isset($_SESSION['mode']))unset($_SESSION['mode']);

                        $beneficiary = "'$this->bank_uppercase'";

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->comptabilisation->get_comptes_array_for_banks("'MAD'", $beneficiary, $agence, []);

                        $this->data['compte_mad'] = isset($comptes['MAD']) ? $comptes['MAD'] : "";

                        echo view('\Modules\Branch\Views\bulletins\_step_1', $this->data);
                }
                elseif ($obj == "verification")
                {

                        $bulletin = $this->integrationModel->check_bl_exist();
                        $bulletin = current($bulletin);

                        if(isset($bulletin->Id_0) && $id == NULL)
                        {
                                $response['code'] = "E500";
                                echo json_encode($response); die;
                        }

                        # Appel à la méthode principale de vérification du bulletin de liquidation 
                        $return = $this->bulletinLiquidation->handle_check_bulletin();

                        echo json_encode($return); die;
                }
                elseif ($obj == "step_1_details")
                {
                        $amount = str_replace(' ', '', $_POST['Amount']);
                        $amount = str_replace('.', '', $amount);
                        $amount = str_replace(',', '.', $amount);


                        $devise = $_POST['devise'];

                        $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                        $service = $_POST['Office'];

                        $agence = $_SESSION['Logiref_guichet'];
                        $mode = $_POST['Mode'];

                        $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                        $taux = json_decode($_SESSION['Bank_rates'], true);

                        if ($devise != 'CDF') 
                        {
                                if (isset($_POST['Taux']) && $_POST['Taux'] != "") 
                                {
                                        $devise_taux = $_POST['Taux'];
                                } 
                                else 
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        $devise_taux = $taux['Dollar_4'];
                                }
                        } 
                        else 
                        {
                                $devise_taux = 1;
                        }

                        if (isset($_POST['Nif'])) 
                        {
                                $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);

                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                if (isset($_POST['designation']))
                                        $this->data['designation'] = $_POST['designation'];
                        }

                        $commission_treated = isset($_POST['Commission']) ? $_POST['Commission'] : "";
                        
                        $account_saved = isset($_SESSION['bank_account']) ? $_SESSION['bank_account']: $_POST['bank_account'];
                        $mode_saved = isset($_SESSION['mode']) ? $_SESSION['mode'] : $_POST['Mode'];

                        if ($commission_treated == '' || $_POST['Mode'] != $mode_saved || $_POST['bank_account'] != $account_saved) 
                        {
                                if(isset($_SESSION['bank_account']))unset($_SESSION['bank_account']);
                                if(isset($_SESSION['mode']))unset($_SESSION['mode']);
                                
                                $rules = $this->feesModel->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence, $account_client, $account_devise);
                                $rules_with_account = $this->feesModel->get_customer_charges('DGDA',$service, NULL, $devise, $amount, $agence, $account_client);
                                $rules_with_mode = $this->feesModel->get_charges_by_paiement_method('DGDA', $service, NULL, $devise, $amount, $agence, $mode);
                                
                                if($rules_with_account['Valeur'] != 0 && $rules_with_account['Valeur'] != '') 
                                {
                                        $rules = $rules_with_account;
                                }
                                elseif($rules_with_mode['Valeur'] != 0 && $rules_with_mode['Valeur'] !='')
                                {
                                        $rules = $rules_with_mode;
                                }

                                if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                                {
                                        $com['com'] = ($amount * $rules['Valeur']) / 100;
                                        $com['devise'] = $devise;
                                } 
                                elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                                {
                                        $com['com'] = $rules['Valeur'];
                                        $com['devise'] = $rules['Unite'];
                                }
                                if (!empty($com) && $com['com'] != 0) 
                                {
                                        if ($com['devise'] != 'CDF') 
                                        {
                                                $this->data['commission'] = $com['com'] * $devise_taux;
                                                $this->data['commission_devise'] = $com['devise'];
                                                $tva = $this->data['commission'] * 0.16;

                                                $this->data['total_amount'] = $amount + $this->data['commission'] + $tva;
                                        } 
                                        else 
                                        {
                                                $this->data['commission'] = $com['com'];
                                                $this->data['commission_devise'] = $com['devise'];
                                                $tva = $this->data['commission'] * 0.16;

                                                $this->data['total_amount'] = $amount + $com['com'] + $tva;
                                        }
                                } 
                                else 
                                {
                                        $this->data['commission'] = $amount * 0;
                                        $this->data['commission_devise'] = $devise;

                                        $tva = $this->data['commission'] * 0.16;
                                        $this->data['total_amount'] = $amount + $this->data['commission'] + $tva;
                                }


                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        } 
                        else 
                        {
                                $commission = str_replace(' ', '', $_POST['Commission']);
                                $commission = str_replace('.', '', $commission);
                                $commission = str_replace(',', '.', $commission);

                                $this->data['commission'] = $commission;
                                $this->data['commission_devise'] = $_POST['Devise_commission'];

                                if ($_POST['Devise_commission'] != "CDF") 
                                {
                                        if (isset($_POST['Taux']) && $_POST['Taux'] != "") 
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        } 
                                        else 
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                        $commission = $this->data['commission'] * $devise_taux;

                                        $tva = $commission * 0.16;

                                        $this->data['total_amount'] = $amount + $commission + $tva;
                                } 
                                else 
                                {
                                        $tva = $this->data['commission'] * 0.16;
                                        $this->data['total_amount'] = $amount + $commission + $tva;
                                }

                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        }
                        
                        if(!isset($_SESSION['bank_account']))
                        {
                                $_SESSION['bank_account'] = $_POST['bank_account'];
                                $_SESSION['mode'] = $_POST['Mode'];
                        }
                        
                        $this->data['bank_account'] = $_SESSION['bank_account'];
                        $this->data['mode'] = $_SESSION['mode'];

                        # Balance verification
                        # Test whether the api account info retrieve both balance with account infos
                        if (isset($this->options['ALL']['retrieve-balance-with-account-info'])) 
                        {
                                if ($_POST['account_currency'] == "" || $_POST['account_balance'] == "") 
                                {
                                        echo 'E411';
                                        die;
                                }
                                elseif (isset($_POST['account_balance']) && $_POST['account_balance']= "no-verification-balance")
                                {
                                        $this->data['account_balance'] = "Approvisionné";
                                        $this->data['balance'] = 'ok';
                                }
                                else 
                                {
                                        if ($_POST['account_currency'] == 'CDF') 
                                        {
                                                $tva = $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                if ($_POST['account_balance'] >= $amount_to_pay) 
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                } 
                                                else 
                                                {
                                                        $this->data['account_balance'] = "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        } 
                                        elseif ($_POST['account_currency'] == 'USD') 
                                        {
                                                $tva = $this->data['commission'] * 0.16;
                                                $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                                $taux = $this->data['bank_rate_applied'];

                                                # convert amount in USD
                                                $amount_to_pay = $amount_to_pay / $taux;

                                                if ($_POST['account_balance'] >= $amount_to_pay) 
                                                {
                                                        $this->data['account_balance'] = "Approvisionné";
                                                        $this->data['balance'] = 'ok';
                                                } 
                                                else 
                                                {
                                                        $this->data['account_balance'] = "Solde insuffisant";
                                                        $this->data['balance'] = 'ko';
                                                }
                                        }
                                }
                        } 
                        else 
                        {
                                if ($_POST['account_currency'] == 'CDF') 
                                {
                                        $tva = $this->data['commission'] * 0.16;
                                        $amount_to_pay = $amount + $this->data['commission'] + $tva;
                                } 
                                elseif ($_POST['account_currency'] == 'USD') 
                                {
                                        $tva = $this->data['commission'] * 0.16;
                                        $amount_to_pay = $amount + $this->data['commission'] + $tva;

                                        $taux = $this->data['bank_rate_applied'];

                                        # convert amount in USD
                                        $amount_to_pay = $amount_to_pay / $taux;
                                }

                                $data['bank_account'] = $_POST['bank_account'];
                                $data['devise_account'] = $_POST['Devise_account'];
                                $data['amount'] = $amount_to_pay;

                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);
                                $return = $this->{$core_banking}->check_balance($data);

                                if (isset($return['code']) && $return['code'] == 200) 
                                {
                                        $this->data['account_balance'] = "Approvisionné";
                                        $this->data['balance'] = 'ok';
                                } 
                                elseif (isset($return['code']) && $return['code'] == 300) 
                                {
                                        $this->data['account_balance'] = "Solde insuffisant";
                                        $this->data['balance'] = 'ko';
                                } 
                                else 
                                {
                                        echo 'E411';
                                        die;
                                }
                        }

                        # Verify the option of fetching accounts based on DGDA office
                        if (isset($this->options['DGDA']['accounts-fetch-by-dgda-office'])) 
                        {
                                $return = $this->branchModel->get_branche_by_service($service);

                                if ($return != 0) 
                                {
                                        $agence = $return;

                                        $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);
                                        $this->data['compte_guichet'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";

                                        $this->data['referenceOP'] = (isset($_POST['reference'])) ? $_POST['reference'] : "";
                                        $this->data['disabled'] = "";
                                } 
                                else 
                                {
                                        # the bureau is not configured 
                                        echo 'E418';
                                        die;
                                }
                        } 
                        else 
                        {
                                $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);

                                $this->data['compte_guichet'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";

                                $this->data['referenceOP'] = (isset($_POST['reference'])) ? $_POST['reference'] : "";
                                $this->data['disabled'] = "";
                        }

                        # Verify in the options tab if the bcc fees is deduced before the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-before-validation-with_exception'])) 
                        {
                                # Deduce the remote compensation 
                                $frais_bcc = $amount * 0.002;
                        } 
                        else 
                        {
                                $frais_bcc = 0;
                        }

                        $total_amount = isset($this->data['total_amount']) ? $this->data['total_amount'] : 0;

                        if ($total_amount > 0 && $total_amount != '') 
                        {
                                $total_amount = $total_amount + $frais_bcc;
                                $this->data['total_amount'] = round($total_amount, 2);
                        } 
                        else 
                        {
                                $tva = $this->data['commission'] * 0.16;
                                $total_amount = $amount + $this->data['commission'] + $tva + $frais_bcc;
                                $this->data['total_amount'] = round($total_amount, 2);
                        }
                        
                        if(isset($_POST['Mode']) && $_POST['Mode'] == '7')
                        {
                                $this->data['reference_mandatory'] = true;
                        }
                        else
                        {
                                $this->data['reference_mandatory'] = false;
                        }

                        echo view('\Modules\Branch\Views\bulletins\_step_1_details', $this->data);
                } 
                elseif ($obj == "step_1_process") 
                {
                        $this->data['step'] = 0;
                        $bl = $id;

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);

                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] != "") ? $_GET['controller'] : '';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] != "") ? $_GET['view'] : '';
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        
                        $integrations = $this->comptabilisationModel->get_first_instructions_dgda($id);
                        
                        $integration_status = array();
                        
                        foreach($integrations as $row)
                        {
                                $integration_status[] = $row->Status_2;
                        }
                        
                        $this->data['integrations'] = $integrations;
                        $this->data['integration_status'] = $integration_status;

                        echo view('\Modules\Branch\Views\bulletins\_step_1_process', $this->data);
                }
                elseif($obj == "batch_step_1_process")
                {   
                        $batch_lines = $this->integrationModel->get_bulletin_batch_info($id);
                        
                        
                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $bulletins = json_decode($batch_lines->Bulletins_22, true);

                                $i = 1;
                                $amounts = 0;

                                for($i=1; $i<=count($bulletins['years']); $i++) 
                                {
                                        $bulletin = new \stdClass();

                                        $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $bulletin->year = $bulletins['years'][$i];
                                        $bulletin->number = $bulletins['serials'][$i];
                                        $bulletin->amount = $amount;
                                        $amounts += $amount;

                                        $tables[] = $bulletin;
                                }

                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['nif'] = $batch_lines->Nif_8;
                                $this->data['designation'] = $batch_lines->Designation_15;

                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['total'] = $batch_lines->Amount_11;
                                $this->data['bulletins'] = $tables;
                                $this->data['batch'] = $batch_lines;
                                $this->data['logirefid'] = $batch_lines->Lot_14;
                                $this->data['account_name'] = $batch_lines->Accountholder_18; 
                                $this->data['commission'] = $batch_lines->Commission_20;
                                $this->data['total_to_paid']  = $batch_lines->Total_23; 
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['bank'] = $batch_lines->Bank_10;
                                $this->data['refOp'] = $batch_lines->Refop_25;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['taux'] = $batch_lines->Taux_26;
                                $this->data['account'] = $batch_lines->Account_16; 
                                $this->data['cdevise'] = $batch_lines->Devise_17;
                                $this->data['customercode'] = $batch_lines->Customercode_27;
                                $this->data['maker'] = $batch_lines->Maker_28;
                                $this->data['step'] = 1;

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['compte_guichet_unique'] = $compte_cgu;

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_2_branchless', $this->data);
                        }
                }
                elseif($obj=="preview_batch")
                {
                        $batch_lines = $this->integrationModel->get_bulletin_batch_info($id);

                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $bulletins = json_decode($batch_lines->Bulletins_22, true);

                                $i = 1;
                                $amounts = 0;

                                for($i=1; $i<=count($bulletins['years']); $i++) 
                                {
                                        $bulletin = new \stdClass();

                                        $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $bulletin->year = $bulletins['years'][$i];
                                        $bulletin->serial = $bulletins['serials'][$i];
                                        $bulletin->number = $bulletins['numbers'][$i];
                                        $bulletin->amount = $amount;
                                        $bulletin->error="E022";
                                        $amounts += $amount;

                                        $tables[] = $bulletin;
                                }

                                 $refop = ($batch_lines->Customercode_27!="") ? $batch_lines->Lot_14 :  $batch_lines->Refop_25;
                                $integrations = $this->comptabilisationModel->get_first_instructions_dgda($refop);
                        
                                $integration_status = array();
                                
                                foreach($integrations as $row)
                                {
                                        $integration_status[] = $row->Status_2;
                                }

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['compte_guichet_unique'] = $compte_cgu;
                                
                                $this->data['integrations'] = $integrations;
                                $this->data['integration_status'] = $integration_status;

                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['nif'] = $batch_lines->Nif_8;
                                $this->data['designation'] = $batch_lines->Designation_15;

                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['total_amount'] = $batch_lines->Amount_11;
                                $this->data['failds'] = $tables;
                                $this->data['batch'] = $batch_lines;
                                $this->data['logirefid'] = $batch_lines->Lot_14;
                                $this->data['accountnane'] = $batch_lines->Accountholder_18; 
                                $this->data['commission'] = $batch_lines->Commission_20;
                                $this->data['totalpaid']  = $batch_lines->Total_23; 
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['bank'] = $batch_lines->Bank_10;
                                $this->data['refOp'] = $batch_lines->Refop_25;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['taux'] = $batch_lines->Taux_26;
                                $this->data['account'] = $batch_lines->Account_16; 
                                $this->data['cdevise'] = $batch_lines->Devise_17;
                                $this->data['customercode'] = $batch_lines->Customercode_27;
                                $this->data['maker'] = $batch_lines->Maker_28;
                                $this->data['step'] = 1;

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['cGuichet'] = $compte_cgu;

                                # Verify whether we are in the the case which the bullletins were 
                                # Confirmed but there has been a time out from the front-end
                                
                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($batch_lines->Lot_14);
                                
                                if(isset($bulletins[0]->Results_13) && $bulletins[0]->Results_13 != '')
                                {
                                        $this->data['failds'] = [];
                                        $this->data['bulletins'] = $bulletins;
                                }

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_3', $this->data);
                        }
                }
                elseif($obj=="preview_batch_confirmed_but_not_saved")
                {
                        $batch_lines = $this->integrationModel->get_bulletin_batch_info($id);
                        
                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $bulletins = json_decode($batch_lines->Bulletins_22, true);

                                $i = 1;
                                $amounts = 0;

                                for($i=1; $i<=count($bulletins['years']); $i++) 
                                {
                                        $bulletin = new \stdClass();

                                        $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $bulletin->year = $bulletins['years'][$i];
                                        $bulletin->serial = $bulletins['serials'][$i];
                                        $bulletin->number = "";
                                        $bulletin->amount = $amount;
                                        $bulletin->error="E022";
                                        $amounts += $amount;
                                        
                                        $tables[] = $bulletin;
                                }

                                $refop = $batch_lines->Refop_25;
                                $integrations = $this->comptabilisationModel->get_first_instructions_dgda($refop);
                        
                                $integration_status = array();
                                
                                foreach($integrations as $row)
                                {
                                        $integration_status[] = $row->Status_2;
                                }

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['compte_guichet_unique'] = $compte_cgu;
                                
                                $this->data['integrations'] = $integrations;
                                $this->data['integration_status'] = $integration_status;

                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['nif'] = $batch_lines->Nif_8;
                                $this->data['designation'] = $batch_lines->Designation_15;

                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['total_amount'] = $batch_lines->Amount_11;
                                $this->data['failds'] = $tables;
                                $this->data['batch'] = $bulletins;
                                $this->data['logirefid'] = $batch_lines->Lot_14;
                                $this->data['accountnane'] = $batch_lines->Accountholder_18; 
                                $this->data['commission'] = $batch_lines->Commission_20;
                                $this->data['totalpaid']  = $batch_lines->Total_23; 
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['bank'] = $batch_lines->Bank_10;
                                $this->data['refOp'] = $batch_lines->Refop_25;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['taux'] = $batch_lines->Taux_26;
                                $this->data['account'] = $batch_lines->Account_16; 
                                $this->data['cdevise'] = $batch_lines->Devise_17;
                                $this->data['customercode'] = $batch_lines->Customercode_27;
                                $this->data['maker'] = $batch_lines->Maker_28;
                                $this->data['step'] = 1;

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['cGuichet'] = $compte_cgu;
                                
                                # Verify whether we are in the the case which the bullletins were 
                                # Confirmed but there has been a time out from the front-end
                                
                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($batch_lines->Lot_14);
                                
                                if(isset($bulletins[0]->Results_13) && $bulletins[0]->Results_13 != '')
                                {
                                        $this->data['failds'] = [];
                                        $this->data['bulletins'] = $bulletins;
                                }

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_3_branchless', $this->data);
                        }
                }
                elseif($obj=="preview_batch_branchless")
                {
                        $batch_lines = $this->integrationModel->get_bulletin_batch_info_branchless($id);

                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $bulletins = json_decode($batch_lines->Bulletins_22, true);

                                $i = 1;
                                $amounts = 0;

                                for($i=1; $i<=count($bulletins['years']); $i++) 
                                {
                                        $bulletin = new \stdClass();

                                        $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $bulletin->year = $bulletins['years'][$i];
                                        $bulletin->serial = $bulletins['serials'][$i];
                                        $bulletin->number = $bulletins['serials'][$i].''.$bulletins['numbers'][$i];
                                        $bulletin->amount = $amount;
                                        $bulletin->error="E022";
                                        $amounts += $amount;
                                        
                                        $tables[] = $bulletin;
                                }
                                
                                $refop = $batch_lines->Refop_25;
                                $integrations = $this->comptabilisationModel->get_first_instructions_dgda($refop);
                        
                                $integration_status = array();
                                
                                foreach($integrations as $row)
                                {
                                        $integration_status[] = $row->Status_2;
                                }

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['compte_guichet_unique'] = $compte_cgu;
                                
                                $this->data['integrations'] = $integrations;
                                $this->data['integration_status'] = $integration_status;

                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['nif'] = $batch_lines->Nif_8;
                                $this->data['designation'] = $batch_lines->Designation_15;

                                $this->data['agent'] = $batch_lines->Agent_9;
                                $this->data['total_amount'] = $batch_lines->Amount_11;
                                $this->data['bulletins_table'] = $tables;
                                $this->data['batch'] = $batch_lines;
                                $this->data['logirefid'] = $batch_lines->Lot_14;
                                $this->data['account_name'] = $batch_lines->Accountholder_18; 
                                $this->data['commission'] = $batch_lines->Commission_20;
                                $this->data['totalpaid']  = $batch_lines->Total_23; 
                                $this->data['office'] = $batch_lines->Office_7;
                                $this->data['bank'] = $batch_lines->Bank_10;
                                $this->data['refOp'] = $batch_lines->Refop_25;
                                $this->data['mode'] = $batch_lines->Mode_19;
                                $this->data['taux'] = $batch_lines->Taux_26;
                                $this->data['account'] = $batch_lines->Account_16; 
                                $this->data['cdevise'] = $batch_lines->Devise_17;
                                $this->data['customercode'] = $batch_lines->Customercode_27;
                                $this->data['maker'] = $batch_lines->Maker_28;
                                $this->data['step'] = 1;

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['cGuichet'] = $compte_cgu;
                                
                                # Verify whether we are in the the case which the bullletins were 
                                # Confirmed but there has been a time out from the front-end
                                
                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($batch_lines->Lot_14);
                                
                                if(isset($bulletins[0]->Results_13) && $bulletins[0]->Results_13 != '')
                                {
                                        $this->data['failds'] = [];
                                        $this->data['bulletins'] = $bulletins;
                                }

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_2_branchless', $this->data);
                        }
                }
                elseif ($obj == "debit_client") 
                {
                        $data['Logirefid_4'] = isset($_POST['logirefid']) ? $_POST['logirefid'] : "";

                        $id = $_POST['bulletin_id'];

                        $data['Sydonia_44'] = $id;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['branch_code'] = $_POST['branch_code'] ?? "";
                        $data['Priority'] = 0;

                        # Update the bulletin in order to indicate that it's already treated
                        $data_to_update['Treated_45'] = 1;
                        $this->integrationModel->save_bulletin($data_to_update, $id);

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'debit_customer_bulletin_single'))
                        {
                                $return = $this->{$core_banking}->debit_customer_bulletin_single($data);

				if (is_string($return)) $response = json_decode($return, true);

                                # Update the bulletin in order to indicate that it's already treated
                                $data_to_update['Treated_45'] = '2';
                                $this->integrationModel->save_bulletin($data_to_update, $id);

                                echo $return;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                elseif ($obj == "debit_client_batch")
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */

                        $data = array();
                        $return = array();
                        $result = array();
                        $data_to_update = array();

                        # Get the bulletin uniqueid
                        $lot_id = $_POST['refOp'] ? $_POST['refOp'] : "";

                        if ($lot_id != '')
                        {
                                # Data construction
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Designation_14'] = isset($_POST['designation']) ? $_POST['designation'] : '';
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Sydonia_44'] = $_POST['batchid'];
                                $data['Paiementid_4'] = $lot_id;
                                $data['Logirefid_4'] = isset($_POST['logirefid']) ? $_POST['logirefid'] : "";
                                $data['branch_code'] = $_POST['branch_code'] ?? "";
                                $data['Priority'] = 0;

                                # Update the bulletin in order to indicate that it's already treated
                                $data_to_update['Treated_34'] = 1;
                                $this->integrationModel->save_batch_bulletin($data_to_update, $_POST['batchid']);

                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);

                                # Vérifier si la méthode existe dans la classe
                                if (method_exists($this->{$core_banking}, 'debit_customer_bulletin_batch'))
                                {
                                        $return = $this->{$core_banking}->debit_customer_bulletin_batch($data);

                         

                                        echo $return;
                                }
                                else
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result);
                                        die;
                                }
                        }
                        else
                        {
                                $result['code'] = 'E405';
                                $result['message'] = '';

                                echo json_encode($result);
                        }
                }
                elseif ($obj == "verify_transaction_single")
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */
                        $data = array();
                        $return = array();
                        $result = array();

                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'bulletin_single_verification_treatment'))
                        {
                                $return = $this->{$core_banking}->bulletin_single_verification_treatment($data);

                                echo $return;
                                die;
                        }
                        else
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                elseif ($obj == "verify_transaction_batch")
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */

                        $data = array();
                        $return = array();
                        $result = array();

                        $data['Sydonia_44'] = $_POST['refOp'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['Type'] = "batch";
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'bulletin_batch_verification_treatment')) 
                        {
                                $return = $this->{$core_banking}->bulletin_batch_verification_treatment($data);

                                echo $return;
                                die;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif ($obj == "first_transaction") 
                {
                        $id = $_POST['bulletin_id'];

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                    
                        $data['Sydonia_44'] = $id;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $bulletin->Designation_23;
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        $data['Priority'] = 0;
                        
                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);
                        
                        
                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'virement')) 
                        {
                                $return = $this->{$core_banking}->virement($data);
                                
                                echo $return;
                                die;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }

                        if (isset($return['response']) && $return['response'] == "200") 
                        {
                                echo "E" . $return['response'];
                        } 
                        elseif (isset($return['response']) && ($return['response'] == "E30044" || $return['response'] == "E30043" || $return['response'] == "E411" || $response['response'] == "E405")) 
                        {
                                echo $return['response'];
                        } 
                        else
                        {
                                echo "E411";
                        }
                }
                elseif ($obj == "validate_amount_blocked")
                {
                        $id = $_POST['bulletin_id'];
                        $data_to_update = array();
                        $result = array();
                        $response = array();
                        $data = array();

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);

                        $block_amount_info = json_decode($bulletin->Reservation_43, true);

                        $data['reference'] = $id;
                        $data['logirefid'] = isset($bulletin->Logirefid_34) ? $bulletin->Logirefid_34 : "";

                        $data['lien_id']= isset($block_amount_info['lien_id']) ? $block_amount_info['lien_id'] : "";

                        $core_banking = strtolower($this->core_banking);

                        if(method_exists($this->{$core_banking}, 'validate_transaction'))
                        {
                                $return = $this->{$core_banking}->validate_transaction($data);

                                $result = json_decode($return, true);

                                if (isset($result['response']) && $result['response'] == "200")
                                {
                                        $response['response'] = $result['response'];
                                        $response['message'] = $result['message'];
                                }
                                elseif (isset($result['response']) && $result['response'] != "")
                                {
                                        $response['response'] = $result['response'];
                                        $response['message'] = $result['message'];
                                }
                                else
                                {
                                        $response['response'] = "411";
                                        $response['message'] = 'L\'envoi de la requête s\'est fait avec succès mais '.$core_banking.' n\'a pas retourné de réponse, veuillez cliquer sur le bouton [vérifier la transaction] s\il vous plaît';
                                }
                        }
                        else
                        {
                                $response['response'] = "407";
                                $response['message'] = "Erreur de validation de la transaction";
                        }

                        echo json_encode($response);
                }
                elseif ($obj == "validate_batch_amount_blocked")
                {
                        $id = $_POST['batchid'];
                        $data_to_update = array();
                        $result = array();
                        $response = array();
                        $data = array();

                        $batchs = $this->integrationModel->get_paiement_sydonia_batchs($id);

                        $block_amount_info = json_decode($batchs->Reservation_35, true);

                        $data['reference'] = $batchs->Refop_25;
                        $data['logirefid'] = isset($batchs->Lot_14) ? $batchs->Lot_14 : "";
                        $data['lien_id'] = isset($block_amount_info['lien_id']) ? $block_amount_info['lien_id'] : "";

                        $core_banking = strtolower($this->core_banking);

                        if(method_exists($this->{$core_banking}, 'validate_transaction'))
                        {
                                $return = $this->{$core_banking}->validate_transaction($data);

                                $result = json_decode($return, true);

                                if (isset($result['response']) && $result['response'] == "200")
                                {
                                        $response['response'] = $result['response'];
                                        $response['message'] = $result['message'];
                                }
                                elseif (isset($result['response']) && $result['response'] != "")
                                {
                                        $response['response'] = $result['response'];
                                        $response['message'] = $result['message'];
                                }
                                else
                                {
                                        $response['response'] = "411";
                                        $response['message'] = 'L\'envoi de la requête s\'est fait avec succès mais Igor n\'a pas retourné de réponse, veuillez cliquer sur le bouton [vérifier la transaction] s\il vous plaît';
                                }
                        }
                        else
                        {
                                $response['response'] = "407";
                                $response['message'] = "Erreur de validation de la transaction";
                        }

                        echo json_encode($response);
                }
                elseif ($obj == "create_bulletin")
                {
                        # reference of the payment.
                        $data = array();
                        $result = array();

                        $data['Logirefid_4'] = $this->encaissementModel->generate_unique_reference();

                        $return = $this->save('bulletin', $data['Logirefid_4'], $id);

                        if ($return != 0)
                        {
                                $result['code'] = $return['code'];
                                $result['id'] = $return['id'];
                                $result['logirefid'] = $return['logirefid'];

                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = $return;
                                echo json_encode($result);
                        }
                }
                elseif ($obj == "initiate_transaction")
                {
                        $id = isset($_POST['bulletin_id']) ? $_POST['bulletin_id'] : "";

                        # Retrieve the bl informations
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);

                        $result = array();
                        $data = array();

                        if (isset($bulletin->Id_0))
                        {
                                $data['Sydonia_44'] = $bulletin->Id_0;
                                $data['Designation_14'] = $bulletin->Designation_23;
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Devise_12'] = 'CDF';
                                $data['Compte_33'] = $bulletin->Account_28;
                                $data['Devise_34'] = $bulletin->Devise_29;
                                $data['Taux_41'] = $bulletin->Taux_31;
                                $data['Logirefid_4'] = $bulletin->Logirefid_34;
                                $data['Priority'] = 0;

                                $core_banking = strtolower($this->core_banking);

                                if(method_exists($this->{$core_banking}, 'reservation_with_instructions'))
                                {
                                        $response = $this->{$core_banking}->reservation_with_instructions($data);

                                        $return = json_decode($response, true);

                                        if (isset($return['response']) && $return['response'] == "200")
                                        {
                                                #Update the bulletin in order to indicate that it's already treated
                                                $data_to_update = array();
                                                $data_to_update['Treated_45'] = 1;
                                                $this->integrationModel->save_bulletin($data_to_update, $id);

                                                # Successful attempt
                                                $msg = '<div class="alert aSuccess text-white">Paiement enregistr&eacute; avec succ&eagrave;s, veuillez contacter le validateur pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                        elseif (isset($return['response']) && $return['response'] != "")
                                        {
                                                $msg = '<div class="alert aDanger text-white">' . $return['message'] . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                        else
                                        {
                                                $msg = '<div class="alert aDanger text-white">L\'envoi de la requête s\'est fait avec succès mais Igor n\'a pas retourné de réponse, veuillez réessayer s\il vous plaît ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                }
                                else{
                                        $msg = '<div class="alert aDanger text-white">Erreur de validation de la transaction<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        echo $msg;
                                }
                        }
                        else
                        {
                                # Failure attempt
                                $msg = '<div class="alert aDanger text-white">Le paiement n\'a pas été enregistré; un problème est survenu. Veuillez reprendre s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                echo $msg;
                        }
                }
                elseif ($obj == "initiate_transaction_batch")
                {
                        $lot_id = $_POST['refOp'] ? $_POST['refOp'] : "";

                        $result = array();
                        $data = array();

                        if ($lot_id != '')
                        {
                                $data['Sydonia_44'] = $lot_id;
                                $data['Designation_14'] = isset($_POST['designation']) ? $_POST['designation'] : '';
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Devise_12'] = 'CDF';
                                $data['Compte_33'] = $_POST['account'];
                                $data['Devise_34'] = $_POST['cdevise'];
                                $data['Taux_41'] = $_POST['taux'];
                                $data['Logirefid_4'] = isset($_POST['logirefid']) ? $_POST['logirefid'] : "";
                                $data['Priority'] = 0;

                                $core_banking = strtolower($this->core_banking);

                                if(method_exists($this->{$core_banking}, 'reservation_with_instructions'))
                                {
                                        $response = $this->{$core_banking}->reservation_with_instructions($data);

                                        $return = json_decode($response, true);

                                        if (isset($return['response']) && $return['response'] == "200")
                                        {
                                                #Update the bulletin in order to indicate that it's already treated
                                                $data_to_update = array();
                                                $data_to_update['Treated_34'] = 1;
                                                $this->integrationModel->save_batch_bulletin($data_to_update, $_POST["batchid"]);

                                                # Successful attempt
                                                $msg = '<div class="alert aSuccess text-white">Paiement enregistr&eacute; avec succ&eagrave;s, veuillez contacter le validateur pour la validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                        elseif (isset($return['response']) && $return['response'] != "")
                                        {
                                                $msg = '<div class="alert aDanger text-white">' . $return['message'] . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                        else
                                        {
                                                $msg = '<div class="alert aDanger text-white">L\'envoi de la requête s\'est fait avec succès mais Igor n\'a pas retourné de réponse, veuillez réessayer s\il vous plaît ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                echo $msg;
                                        }
                                }
                                else{
                                        $msg = '<div class="alert aDanger text-white">Erreur de validation de la transaction<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        echo $msg;
                                }

                        }
                        else
                        {
                                # Failure attempt
                                $msg = '<div class="alert aDanger text-white">Le paiement n\'a pas été enregistré; un problème est survenu. Veuillez reprendre s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                echo $msg;
                        }
                }
                elseif ($obj == "verify")
                {
                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        $response = $this->curlModel->call_bank_verify_reservation($data);

                        $return = json_decode($response, true);

                        if ($return['response'] == '200') 
                        {
                                echo 'E200';
                        } 
                        elseif ($return['response'] == '304') 
                        {
                                echo 'E304';
                        } 
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411'))
                        {
                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "cancel_reservation") 
                {
                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'cancel_reservation_bulletin_single')) 
                        {
                                $response = $this->{$core_banking}->cancel_reservation_bulletin_single($data);
                        } 
                        else 
                        {
                                echo 'E407';
                                die;
                        }

                        $return = json_decode($response, true);

                        if ($return['response'] == '200') 
                        {

                                echo 'E200'; die;
                        } 
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) 
                        {
                                $pid = $_POST['bulletin_id'];
                                $bl_data['Status_2'] = '5';
                                $bl = $this->integrationModel->update_bulletin($bl_data, $pid);

                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "cancel_reservation_for_bl_batch")
                {
                        $data['Sydonia_44'] = $_POST['refOp'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'cancel_reservation_bulletin_batch')) 
                        {
                                $response = $this->{$core_banking}->cancel_reservation_bulletin_batch($data);
                        }
                        else
                        {
                                echo 'E407';
                                die;
                        }

                        $return = json_decode($response, true);

                        if ($return['response'] == '200')
                        {

                                echo 'E200'; die;
                        }
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) 
                        {
                                $pid = $_POST['bulletin_id'];
                                $bl_data['Status_2'] = '5';
                                $bl = $this->integrationModel->update_bulletin($bl_data, $pid);

                                echo 'E' . $return['response'];
                                die;
                        }
                }
                elseif ($obj == "lock_paiement")
                {
                        # Method to lock the payment
                        $bulletin_id = $id;
                        $this->save('lock_paiement', $bulletin_id);
                }
                elseif ($obj == "batch_reservation")
                {
                        $to_echappe = array('&', '/');
                        $_POST['designation'] = str_replace($to_echappe, '', $_POST['designation']);

                        $ref = preg_replace('`[^0-9]`', '', $_POST['refOp']);

                        $transaction = $this->comptabilisationModel->get_comptant_batch_instructions($ref);

                        if (count($transaction) > 0 && !isset($_POST['reuseRef']))
                        {
                                $lines = array();
                                $i = 1;
                                foreach ($transaction as $row)
                                {
                                        $lines[$i]['status'] = $row->Status_2;
                                        $lines[$i]['id'] = $row->Id_0;
                                        $lines[$i]['reference'] = $row->Reference_14;

                                        $i++;
                                }

                                if (isset($lines[3]['status']) && $lines[1]['status'] == "1" && $lines[2]['status'] == "1" && $lines[3]['status'] == "1") 
                                {
                                        # reference of the payment.
                                        $id = $data['Logirefid_4'] = $ref;

                                        $data['Sydonia_44'] = $id;
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Account_3'] = $this->session->userdata['account_id'];

                                        $data['Priority'] = 0;

                                        //$response = $this->curlModel->call_comptant_batch_reservation($data);
                                        //$return = json_decode($response, true);
                                        #Invocation of the api transfer
                                        $core_banking = strtolower($this->core_banking);
                                        $return = $this->{$core_banking}->reservation_bulletin_batch($data);

                                        if ($return['response'] == '200') 
                                        {
                                                $result['code'] = 'E200';

                                                $result['id'] = $id;

                                                $result['reference'] = $data['Logirefid_4'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '301') 
                                        {
                                                $result['code'] = 'E301';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '302') 
                                        {
                                                $result['code'] = 'E302';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '303') 
                                        {
                                                $result['code'] = 'E303';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '304') 
                                        {
                                                $result['code'] = 'E304';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '305') 
                                        {
                                                $result['code'] = 'E305';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        } 
                                        elseif ($return['response'] == '306') 
                                        {
                                                $result['code'] = 'E306';

                                                $result['reference'] = $data['Logirefid_4'];

                                                $result['id'] = $id;

                                                $result['transaction_id'] = $return['transaction_id'];

                                                echo json_encode($result);
                                        }
                                } 
                                elseif (isset($lines[1]['status']) && ($lines[1]['status'] == "4" || $lines[1]['status'] == "5")) 
                                {
                                        $result['code'] = 'E501';

                                        $result['id'] = $ref;

                                        $result['transaction_id'] = $lines[1]['id'];

                                        $result['reference'] = $lines[1]['reference'];

                                        echo json_encode($result);
                                } 
                                elseif (isset($lines[2]['status']) && ($lines[2]['status'] == "4" || $lines[2]['status'] == "5")) 
                                {
                                        $result['code'] = 'E502';

                                        $result['id'] = $ref;

                                        $result['transaction_id'] = $lines[2]['id'];

                                        $result['reference'] = $lines[2]['reference'];

                                        echo json_encode($result);
                                } 
                                elseif (isset($lines[3]['status']) && ($lines[3]['status'] == "4" || $lines[3]['status'] == "5")) 
                                {
                                        $result['code'] = 'E503';

                                        $result['id'] = $ref;

                                        $result['transaction_id'] = $lines[3]['id'];

                                        $result['reference'] = $lines[3]['reference'];

                                        echo json_encode($result);
                                } 
                                elseif (isset($lines[3]['status']) && $lines[1]['status'] == "2" || $lines[2]['status'] == "2" && $lines[3]['status'] == "2") 
                                {
                                        # the reservation was succesfull.
                                        $result['code'] = 'E500';

                                        $result['id'] = $ref;

                                        $result['reference'] = $lines[3]['reference'];

                                        echo json_encode($result);
                                }
                        }
                        else
                        {
                                # reference of the payment.
                                $data['Logirefid_4'] = $ref;

                                $id = $this->save('batch_reservation', $data['Logirefid_4']);

                                $data['Sydonia_44'] = $id;
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Designation_14'] = $_POST['designation'];
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                $data['Priority'] = 0;

                                #Invocation of the api transfer
                                $core_banking = strtolower($this->core_banking);
                                $return = $this->{$core_banking}->reservation_bulletin_batch($data);
                                //$return = json_decode($response, true);

                                if ($return['response'] == '200') 
                                {
                                        $result['code'] = 'E200';

                                        $result['id'] = $id;

                                        $result['reference'] = $data['Logirefid_4'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '301') 
                                {
                                        $result['code'] = 'E301';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '302') 
                                {
                                        $result['code'] = 'E302';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '303')
                                {
                                        $result['code'] = 'E303';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '304') 
                                {
                                        $result['code'] = 'E304';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '305') 
                                {
                                        $result['code'] = 'E305';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '306') 
                                {
                                        $result['code'] = 'E306';

                                        $result['reference'] = $data['Logirefid_4'];

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                }
                        }
                } 
                elseif ($obj == "batch_create_bulletin") 
                {
                        # If the account is not internal
                        # Reservation
                        $result = array();

                        $data['Logirefid_4'] = $this->encaissementModel->generate_unique_reference();

                        $return = $this->save('batch_bulletin', $data['Logirefid_4'], $id);

                        if ($return != 0) 
                        {
                                $return['code']= "E200";
                                $result['code'] = $return['code'];
                                $result['batchid'] = $return['id'];
                                $result['logirefid'] = $data['Logirefid_4'];

                                echo json_encode($result);
                        } 
                        else 
                        {
                                $result['code'] = $return;
                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "batch_verify") 
                {
                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        #Invocation of the api transfer
                        $core_banking = strtolower($this->core_banking);
                        $return = $this->{$core_banking}->check_bulletin_batch($data);

                        if ($return['response'] == '200') 
                        {
                                echo 'E200';
                        } 
                        elseif ($return['response'] == '304') 
                        {
                                echo 'E304';
                        } 
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) 
                        {
                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "batch_cancel_reservation") 
                {
                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];

                        $data['Priority'] = 0;

                        $response = $this->curlModel->call_comptant_batch_cancel_reservation($data);

                        $return = json_decode($response, true);

                        if ($return['response'] == '200')
                        {
                                echo 'E200';
                        }
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) 
                        {
                                echo 'E' . $return['response'];
                                die;
                        }
                }
                elseif ($obj == "confirmation")
                {
                        $paiement_id = ($_POST['bulletin_id']) ?? "";

                        # Préparation des certaines variables pour la confirmation 
                        $_POST['Paiementid'] = $paiement_id;
                        $_POST['Account'] = $this->session->userdata['account_id'] ?? "";
                        $_POST['User'] = $this->session->userdata['user_id']  ?? "";
                        $_POST['Agence'] = $_SESSION['Logiref_guichet'] ?? "";

                        # Appel du service de confirmation SYDONIA
                        $return = $this->bulletinLiquidation->handle_confirm_bulletin();

                        # Sortie finale JSON
                        echo json_encode($return); die;
                }
                elseif($obj=="confirmation_branchless")
                {
                        $_POST['Paiementid'] = $_POST['bulletin_id'];

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $response = $this->curlModel->call_bank_comptant_single($credentials);

                        $message_en = $this->integrationModel->sydonia_error_message['en'];
                        $message_fr = $this->integrationModel->sydonia_error_message['fr'];

                        $result = json_decode($response, true);

                        if(isset($result['code']))
                        {
                                if($result['code']=='E11' || $result['code']=='E34' ||  $result['code']=='E22' || $result['code'] == 'E404' || $result['code'] == 'E405' || $result['code'] == 'E406' || $result['code'] == 'E000' || $result['code'] == 'E002' || $result['code'] == 'E18' || $result['code'] == 'E21' || $result['code'] == 'E15')
                                {
                                        $response['code'] = $result['code'];
                                        
                                        echo json_encode($response);
                                        die;
                                }
                                elseif ($result['code'] == 'E13' || $result['code'] == 'E003') 
                                {
                                        foreach ($message_en as $key => $row) 
                                        {
                                                $message_sydonia = strtolower($result['message']);

                                                if (strstr($message_sydonia, $row)) 
                                                {
                                                        $result['message'] = $message_fr[$key];
                                                        break;
                                                }
                                        }

                                        $result['message'] = '<div class="alert aWarning text-white">' . $result['message'] . '.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $response = json_encode($result);

                                        echo $response;
                                        die;
                                }
                                elseif ($result['code'] == 'OK') 
                                {
                                        $response = array();

                                        $response['code'] = $result['code'];
                                        $response['id'] = $result['id'];

                                        echo json_encode($response);
                                        die;
                                }
                        }
                        else
                        {
                                # no return
                                $response = array();
                                $response['code'] = 'E406';

                                echo json_encode($response);
                                die;
                        }
                }
                elseif($obj == "single_recover_branchless")
                {   
                        $_POST['Paiementid'] = isset($_POST['bulletin_id'])?$_POST['bulletin_id']:"";

                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, NULL);
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";

                        $user = $this->session->userdata['user_id'];

                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);

                        $response = $this->curlModel->call_single_recover($credentials);

                        $response = trim($response);

                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000' || $response == 'E18' || $response == 'E21' || $response == 'E15')
                        {
                                echo $response; die;
                        }
                        elseif($response == 'OK')
                        {
                                # declaration under payment process or not paid yet.
                                echo $response;
                        }
                        else
                        {
                                # Update the payment on RBO
                                //$this->save("update_bl_rbo", $_POST['Paiementid']);

                                #If the bulletin is from RBO
                                $log_info = $this->integrationModel->get_log_brancless_by_bl($_POST['Paiementid']);

                                if(isset($log_info->Id_0))
                                {
                                        $log_data['Status_2'] = '2';
                                        $this->integrationModel->update_log_info($log_data, $log_info->Id_0);
                                                }
                                echo $response; 
                                die;
                        }
                }
                elseif ($obj == "batch_start") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', NULL, true);
                        $this->data['step'] = 0;

                        echo view('\Modules\Branch\Views\bulletins\_batch_start', $this->data);
                } 
                elseif ($obj == "batch_step_2") 
                {
                        $bulletins = [];
                        $tables = [];
                        $amounts = 0;

                        $file = $_FILES['attachement']['tmp_name'];
                        $file_extension = strtolower(substr(strrchr($_FILES['attachement']['name'], '.'), 1));
                        $valid_extensions = array('xlsx', 'xls');

                        if (empty($file)) 
                        {
                                echo 'E200';
                                die;
                        }

                        if (!in_array($file_extension, $valid_extensions)) 
                        {
                                echo 'E202';
                                die;
                        }
                        
                        $handle = fopen($file, "r");
                        
                        if ($handle == false) 
                        {
                                echo 'E200';
                        } 
                        else 
                        {
                                # Lecture du fichier Excel
                                $reader = IOFactory::createReaderForFile($file);
                                $reader->setReadDataOnly(true);
                                $spreadsheet = $reader->load($file);
                                $worksheet = $spreadsheet->getActiveSheet();
                                $lot = $worksheet->toArray(null, true, true, true);

                                if (!empty($lot)) 
                                {
                                        $t = 1;
                                        foreach ($lot as $worksheet) 
                                        {
                                                if ($t > 1) 
                                                {
                                                        $bulletins[] = $worksheet;
                                                }

                                                $t++;
                                        }

                                        if(isset($_SESSION['Guichet_options']['batch_bulletin']['fees']))
                                        {
                                                $type_prelevement = $_SESSION['Guichet_options']['batch_bulletin']['fees'];
                                        }
                                        else
                                        {
                                                $type_prelevement = 'detail';
                                        }
                                        
                                        if(!empty($return) || $type_prelevement == "global") 
                                        {
                                                foreach($bulletins as $sheet) 
                                                {
                                                        $bl_exists = false;
                                                        foreach($tables as $bl)
                                                        {
                                                                if($sheet['A'] == $bl->year && $sheet['B']== $bl->number && $sheet['C']== $bl->amount)
                                                                {
                                                                        $bl_exists = true;   
                                                                }
                                                        }

                                                        if($bl_exists == false)
                                                        {
                                                                if($sheet['A'] != "" && $sheet['B'] != "" && $sheet['C'] != "")
                                                                {
                                                                        $serial = substr($sheet['B'], 0, 1);
                                                                        $number = substr($sheet['B'], 1);

                                                                        $bulletin = new \stdClass();
                                                                        $bulletin->year = $sheet['A'];
                                                                        $bulletin->serial = $serial;
                                                                        $bulletin->number = $number;
                                                                        
                                                                        $montant1 =  str_replace(' ','',intval($sheet['C']));
                                                                        $bulletin->amount = $amount = str_replace(',','.',$montant1);

                                                                        $amounts += $amount;
                                                                        $tables[] = $bulletin;
                                                                }

                                                        }
                                                }
                                                
                                                // Calcul de la commission du lot
                                                $agence = $_SESSION['Logiref_guichet'];
                                                $response = array();
                                                $cdata['regie'] = "DGDA";
                                                $cdata['service']= $_POST['office'];
                                                $cdata['recette']= NULL;
                                                $cdata['devise'] = "CDF";
                                                $cdata['guichet'] = $agence;
                                                $cdata['montant'] = $amounts;
                                                $cdata['compte'] = $_POST['account'];
                                                $cdata['compteDevise'] = $_POST['cdevise'];

                                                $commission = $this->data('get_commission', $cdata);
                                        }
                                        else
                                        {
                                                $commission = array('0'=>0, '1'=>'USD', '2'=>0);
                                                
                                                foreach($bulletins as $sheet) 
                                                {
                                                        $bl_exists = false;
                                                        foreach($tables as $bl)
                                                        {
                                                                if($sheet['A'] == $bl->year && $sheet['B']== $bl->number && $sheet['C']== $bl->amount)
                                                                {
                                                                        $bl_exists = true;   
                                                                }
                                                        }

                                                        if($bl_exists == false)
                                                        {
                                                                if($sheet['A'] != "" && $sheet['B'] != "" && $sheet['C'] != "")
                                                                {
                                                                        $serial = substr($sheet['B'], 0, 1);
                                                                        $number = substr($sheet['B'], 1);

                                                                        $bulletin = new \stdClass();
                                                                        $bulletin->year = $sheet['A'];
                                                                        $bulletin->serial = $serial;
                                                                        $bulletin->number = $number;
                                                                        
                                                                        $montant1 =  str_replace(' ','',intval($sheet['C']));
                                                                        $bulletin->amount = $amount = str_replace(',','.',$montant1);
                                                                        
                                                                        $agence = $_SESSION['Logiref_guichet'];
                                                                        
                                                                        $cdata['regie'] = "DGDA";
                                                                        $cdata['service']= $_POST['Office'];
                                                                        $cdata['recette']= NULL;
                                                                        $cdata['devise'] = "CDF";
                                                                        $cdata['guichet'] = $agence;
                                                                        $cdata['montant'] = $amount;
                                                                        
                                                                        $return = $this->data('get_commission', $cdata);
                                                                        
                                                                        $commission_partielle = isset($return[0]) ? $return[0] : 0;
                                                                        $devise = isset($return[1]) ? $return[1] : 'USD';
                                                                        $total_amount = isset($return[2]) ? $return[2] : 0;
                                                                        
                                                                        $commission[0] = $commission_partielle + $commission[0];
                                                                        $commission[1] = $devise;
                                                                        $commission[2] = $total_amount + $commission[2];

                                                                        $amounts += $amount;
                                                                        $tables[] = $bulletin;
                                                                }
                                                        }
                                                }
                                        }

                                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                        $this->data['nif'] = $_POST['Nif'];

                                        $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);
                                        $designation = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                        if (isset($designation) && $designation != "") 
                                        {
                                                $this->data['designation'] = $designation;
                                        } 
                                        else 
                                        {
                                                $this->data['designation'] = $_POST["designation"];
                                        }

                                        $this->data['agent'] = $_POST['Agent'];
                                        $this->data['total'] = $_POST["total_amount"] = $amounts;
                                        $this->data['bulletins'] = $tables;
                                        $this->data['account_name'] = $_POST['account_name'];
                                        $this->data['commission'] = $_POST['Commission'] = $commission[0];
                                        $this->data['total_to_paid'] = $_POST["total_topaid"] = $amounts + $commission[0];
                                        $this->data['office'] = $_POST['Office'];
                                        $this->data['bank'] = $_POST['Bank'];
                                        $this->data['refOp'] = $_POST['ref'];
                                        $this->data['mode'] = $_POST['mode'];
                                        $this->data['taux'] = $_POST['Taux'] ?? '00,00';
                                        $this->data['account'] = $_POST['account'] ?? '';
                                        $this->data['branch_code'] = $_POST['branch_code'] ?? '';
                                        $this->data['cdevise'] = $_POST['cdevise'] ?? '';

                                        $agence = $_SESSION['Logiref_guichet'];
                                        $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                        # Get the account CGU
                                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                        $this->data['compte_guichet_unique'] = $compte_cgu;

                                        $_POST['bulletin'] = $tables;

                                        # Verification des bulletins 
                                        $return = $this->display("batch_verification", $_POST);
                                        $response = json_decode($return, true);

                                        # check if the reference exist
                                        $ref = $_POST['ref'];

                                        $instructions = $this->comptabilisationModel->get_comptant_batch_instructions($ref);

                                        if (!empty($instructions)) 
                                        {
                                                $batch_bulletin = $this->integrationModel->get_batch_bulletin_by_infos();

                                                if (isset($batch_bulletin[0]->Id_0)) 
                                                {
                                                        $this->data['reuseRef'] = $_POST['ref'];
                                                        $this->data['instructions'] = $instructions;
                                                        $this->data['batch_bulletin'] = $batch_bulletin;
                                                }
                                        }

                                        if ($response['error'] == true) 
                                        {
                                                $j = 0;
                                                foreach ($this->data['bulletins'] as $bulletin) 
                                                {
                                                        # Vérifier si le numéro existe dans le deuxième tableau
                                                        if (isset($response['bulletins'][$j])) 
                                                        {
                                                                # Ajouter la correspondance au résultat
                                                                $result[] = [
                                                                    "year" => $bulletin->year,
                                                                    "number" => $bulletin->number,
                                                                    "serial" => $bulletin->serial,
                                                                    "amount" => $bulletin->amount,
                                                                    "code" => $response['bulletins'][$j]
                                                                ];
                                                        }

                                                        $j++;
                                                }

                                                $this->data['response_bls'] = $result;
                                                $this->data['step'] = 1;

                                                $response['page'] = view('\Modules\Branch\Views\bulletins\_batch_start_process', $this->data);

                                                echo json_encode($response);
                                        } 
                                        else 
                                        {
                                                $this->data['step'] = 2;

                                                $response['page'] = view('\Modules\Branch\Views\bulletins\_batch_step_2', $this->data);

                                                echo json_encode($response);
                                        }
                                } 
                                else 
                                {
                                        echo 'E200';
                                }
                        }
                }
                elseif ($obj == "batch_step_2_process")
                {

                        $bulletin_to_retreat = array();
                        $treatment_result = json_decode($_POST['treatment_result']);
                        $bulletins = json_decode($_POST['bulletins']);

                        $agence = $_SESSION['Logiref_guichet'];
                        $response = array();
                        $cdata['regie'] = "DGDA";
                        $cdata['service'] = $_POST['office'];
                        $cdata['recette'] = NULL;
                        $cdata['devise'] = "CDF";
                        $cdata['guichet'] = $agence;
                        $cdata['montant'] = isset($_POST['total_amount']) ? $_POST['total_amount'] : 0;

                        $commission = $this->data('get_commission', $cdata);

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['nif'] = $_POST['Nif'];

                        $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);
                        $designation = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                        if (isset($designation) && $designation != "") 
                        {
                                $this->data['designation'] = $designation;
                        } 
                        else 
                        {
                                $this->data['designation'] = $_POST["designation"];
                        }

                        $this->data['agent'] = $_POST['agent'];
                        $this->data['total'] = $_POST['total_amount'];
                        $this->data['bulletins'] = $bulletins;
                        $this->data['account_name'] = $_POST['account_name'];
                        $this->data['commission'] = $_POST['Commission'];
                        $this->data['total_to_paid'] = $_POST['total_topaid'];
                        $this->data['office'] = $_POST['office'];
                        $this->data['bank'] = $_POST['bank'];
                        $this->data['refOp'] = $_POST['ref'];
                        $this->data['mode'] = $_POST['mode'];
                        $this->data['taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : '00,00';

                        $this->data['account'] = (isset($_POST['account'])) ? $_POST['account'] : '';
                        $this->data['cdevise'] = (isset($_POST['cdevise'])) ? $_POST['cdevise'] : '';

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                        # Get the account CGU
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $this->data['compte_guichet_unique'] = $compte_cgu;

                        foreach ($treatment_result as $row)
                        {
                                if ($row->code != 'OK') {

                                        $bulletin_to_retreat[] = $row;
                                }
                        }

                        $_POST['bulletin'] = $bulletin_to_retreat;

                        # Verification des bulletins 
                        $return = $this->display("batch_verification", $_POST);

                        $response = json_decode($return, true);

                        if ($response['error'] == true) 
                        {
                                $j = 0;
                                $result = array();

                                foreach ($bulletins as $bulletin) 
                                {
                                        # Vérifier si le numéro existe dans le deuxième tableau
                                        if (isset($response['bulletins'][$j])) 
                                        {
                                                # Ajouter la correspondance au résultat
                                                $result[] = [
                                                    "year" => $bulletin->year,
                                                    "number" => $bulletin->number,
                                                    "amount" => $bulletin->amount,
                                                    "code" => $response['bulletins'][$j]
                                                ];
                                        }

                                        $j++;
                                }

                                $this->data['response_bls'] = $result;
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\bulletins\_batch_start_process', $this->data);
                        } 
                        else 
                        {
                                # check if the reference exist
                                $ref = $_POST['ref'];

                                $instructions = $this->comptabilisationModel->get_comptant_batch_instructions($ref);

                                if (!empty($instructions)) 
                                {
                                        $batch_bulletin = $this->integrationModel->get_batch_bulletin_by_infos();

                                        if (isset($batch_bulletin[0]->Id_0)) 
                                        {
                                                $this->data['reuseRef'] = $_POST['ref'];
                                                $this->data['instructions'] = $instructions;
                                                $this->data['batch_bulletin'] = $batch_bulletin;
                                        }
                                }


                                $this->data['step'] = 2;

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_2', $this->data);
                        }
                } 
                elseif ($obj == "batch_verification") 
                {
                        # Récupération sécurisée de l'agence
                        $agence = $_SESSION['Logiref_guichet'] ?? '';

                        # Initialisation
                        $years = $numbers = $serials = $amounts = [];
                        $bulletins = $data = $bl = [];
                        $total_amount = 0;

                        # Vérifier que des bulletins ont été fournis et sont itérables
                        $bulletins = $_POST['bulletin'] ?? [];

                        foreach ($bulletins as $row) 
                        {
                                # S'assurer que $row contient les propriétés attendues
                                $year   = $row->year   ?? null;
                                $number = $row->number ?? null;
                                $serial = $row->serial ?? null;
                                $amount = isset($row->amount) ? (float) $row->amount : 0.0;

                                # Ignorer les entrées vides si nécessaire
                                if ($year === null && $number === null && $serial === null && $amount === 0.0) 
                                continue;

                                $years[]   = $year;
                                $numbers[] = $number;
                                $serials[] = $serial;
                                $amounts[] = $amount;
                        }


                        # Préparer les données à envoyer au web service (ne pas modifier $_POST global)
                        $_POST['Account'] = $_SESSION['userdata']['account_id'] ?? '';
                        $_POST['User']    = $_SESSION['userdata']['user_id']    ?? '';
                        $_POST['guichet'] = $agence;
                        $_POST['years']   = $years;
                        $_POST['numbers'] = $numbers;
                        $_POST['serials'] = $serials;
                        $_POST['amounts'] = $amounts;

                        # Appel du service en passant le payload (elle attend $_POST)
                        $result = $this->bulletinLiquidation->handle_check_batch_bulletin();
           
                        if ($result['code'] == 'OK')
                        {
                                # Batch verification
                                $verification              = array();
                                $verification['error']     = false;
                                $verification['response']  = 'batchvalide';
                                $verification['bulletins'] = count($serials);

                                foreach ($serials as $i => $series)
                                {
                                        $montant1 = str_replace(' ', '', $amounts[$i]);
                                        $_POST['Amount'] = $amount = str_replace(',', '.', $montant1);
                                        $total_amount = $total_amount + $amount;

                                        $verification['total_amount'] = $total_amount;
                                }

                                # Calcul de la commission 
                                if (isset($_POST['Commission']) && $_POST['Commission'] == "") 
                                {
                                        $response = array();
                                        $cdata['regie'] = "DGDA";
                                        $cdata['service'] = $data['Office'];
                                        $cdata['recette'] = NULL;
                                        $cdata['devise'] = "CDF";
                                        $cdata['guichet'] = $agence;
                                        $cdata['montant'] = $amount;

                                        $commission = $this->data('get_commission', $cdata)[0];
                                        $tva = $commission[0] * 0.16;
                                        $total_to_paid = $commission + $total_amount + $tva;

                                        $verification['tva'] = $tva;
                                        $verification['commission'] = $commission;
                                        $verification['total'] = $total_to_paid;
                                } 
                                else 
                                {
                                        $commission = str_replace(' ', '', ($_POST['Commission'] ?? 0));
                                        $commission = str_replace(',', '.', $commission);
                                        $tva = $commission * 0.16;
                                        $total_to_paid = $commission + $total_amount + $tva;

                                        $verification['tva'] = $tva;
                                        $verification['commission'] = $commission;
                                        $verification['total'] = $total_to_paid;
                                }

                                $data['bank_account'] = $_POST['account'] ?? "";
                                $data['devise_account'] = $_POST['cdevise'] ?? "";
                                $data['amount'] = $total_to_paid;

                                if (isset($_POST['account_balance']) && $_POST['account_balance']="no-verification-balance")
                                {
                                        $verification['balance'] = 'OK';
                                }
                                else
                                {
                                        #Invocation of the api checkbalance
                                        $core_banking = strtolower($this->core_banking);
                                        $response = $this->{$core_banking}->check_balance($data);

                                        if (isset($response['code']) && $response['code'] == 200)
                                        {
                                                $verification['balance'] = 'OK';
                                        }
                                        elseif (isset($response['code']) && $response['code'] == 300)
                                        {
                                                $verification['balance'] = 'KO';
                                                $verification['error'] = true;
                                        }
                                        else
                                        {
                                                $verification['balance'] = 'E411';
                                        }
                                }

                                return json_encode($verification);
                        }
                        else
                        {
                                # Variable retour
                                $verification = array();
                                $verification['error'] = false;
                                $verification['response'] = 'OK';

                                # Verification de chaque bulletin dans SYDONIA
                                foreach ($serials as $i => $series)
                                {
                                        $amount =  str_replace(' ','',$amounts[$i]);
                                        $amount = str_replace(',','.',$amount);

                                        $total_amount = $total_amount + $amount;

                                        $verification['total_amount'] = $total_amount;

                                        # Data construction
                                        $_POST['Amount'] = $amount ?? 0;
                                        $_POST['Year']   = $years[$i] ?? "";
                                        $_POST['Series'] = $serials[$i] ?? "";
                                        $_POST['Number'] = $numbers[$i]?? "";

                                        # Appel à la méthode principale de vérification du bulletin de liquidation 
                                        $result = $this->bulletinLiquidation->handle_check_bulletin();

                                        $code_errors = ['E003', 'E404', 'E000', 'E405'];
                                        if (in_array($result['code'], $code_errors)) 
                                                $verification['response'] = $result['code'];

                                        if($result['code'] != "OK")
                                                $verification['error'] = true;

                                        $bulletins[] = $result['code'];

                                        $verification['bulletins'] = $bulletins;
                                }

                                if ($verification['error'] == false)
                                {
                                        //Calcul de la commission
                                        if (isset($_POST['Commission']) && $_POST['Commission'] == "")
                                        {
                                                $agence = $_SESSION['Logiref_guichet'];
                                                $response = array();
                                                $cdata['regie'] = "DGDA";
                                                $cdata['service'] = $data['Office'];
                                                $cdata['recette'] = NULL;
                                                $cdata['devise'] = "CDF";
                                                $cdata['guichet'] = $agence;
                                                $cdata['montant'] = $amount;

                                                $commission = $this->data('get_commission', $cdata)[0];
                                                $tva = $commission[0] * 0.16;
                                                $total_to_paid = $commission + $total_amount + $tva;

                                                $verification['tva'] = $tva;
                                                $verification['commission'] = $commission;
                                                $verification['total'] = $total_to_paid;
                                        } 
                                        else 
                                        {
                                                $commission = str_replace(' ', '', ($_POST['Commission'] ?? 0));
                                                $commission = str_replace(',', '.', $commission);
                                                $tva = $commission * 0.16;
                                                $total_to_paid = $commission + $total_amount + $tva;

                                                $verification['tva'] = $tva;
                                                $verification['commission'] = $commission;
                                                $verification['total'] = $total_to_paid;
                                        }

                                        //Vérification de la balance du client
                                        $data['bank_account'] = $_POST['account'] ?? "";
                                        $data['devise_account'] = $_POST['cdevise'] ?? "";
                                        $data['amount'] = $total_to_paid;
                                        
                                        if (isset($_POST['account_balance']) && $_POST['account_balance']="no-verification-balance")
                                        {
                                                $verification['balance'] = 'OK';
                                        }
                                        else
                                        {
                                                #Invocation of the api checkbalance
                                                $core_banking = strtolower($this->core_banking);
                                                $response = $this->{$core_banking}->check_balance($data);

                                                if (isset($response['code']) && $response['code'] == 200) 
                                                {
                                                        $verification['balance'] = 'OK';
                                                } 
                                                elseif (isset($response['code']) && $response['code'] == 300) 
                                                {
                                                        $verification['balance'] = 'KO';
                                                } 
                                                else 
                                                {
                                                        $verification['balance'] = 'E411';
                                                }
                                        }
                                }

                                return json_encode($verification);
                        }
                } 
                elseif ($obj == "batch_confirmation_from_operator") 
                {
                        $result = "";
                        
                        if (!empty($_POST))
                        {
                                # ignore_user_abort(true);
                                set_time_limit(0);

                                # --- Réponse rapide au navigateur ---
                                # Réponse immédiate (envoyer tout de suite le retour au navigateur)
                                if (ob_get_level()) 
                                {
                                        ob_end_clean();
                                }

                                # au moins 5-10 octets
                                //$response = json_encode(['code' => 'E200']); 
                                $response = "E200"; 
                                header("Connection: close");
                                header("Content-Length: " . strlen($response));
                                http_response_code(200);
                                echo $response;
                                
                                # libère le verrou
                                session_write_close(); 
                                
                                # envoie la réponse immédiatement
                                flush(); 

                                $_POST['guichet']       = $_SESSION['Logiref_guichet'] ?? "";
                                $_POST['Account']       = $_SESSION['userdata']['account_id'] ?? '';
                                $_POST['User']          = $_SESSION['userdata']['user_id'] ?? "";
                                $_POST['email_adress']  = $_SESSION['userdata']['user_email'] ?? "";
                                $_POST['module']        = $this->module;
                                
                                # Continue en background
                                $this->bulletinLiquidation->handle_confirm_batch_bulletin();
                                exit; 
                        }
                        else
                        {
                                $batch_lines = $this->integrationModel->get_bulletin_batch_info($id);
                                $logirefid = $batch_lines->Lot_14;

                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($logirefid);

                                $data_ids = [];
                                foreach($bulletins as $row)
                                {
                                        $data_ids[] = $row->Id_0;
                                }

                                $result = implode(',', $data_ids);

                                $account_name = $batch_lines->Accountholder_18; 

                                $_POST['account'] = $batch_lines->Account_16;
                                $_POST['cdevise'] = $batch_lines->Devise_17;
                                $_POST['Agent'] = $batch_lines->Agent_9;
                                $_POST['Office'] = $batch_lines->Office_7;
                                $_POST['mode'] = $batch_lines->Mode_19;
                                $_POST['designation'] = $batch_lines->Designation_15;
                                $_POST['Nif'] = $batch_lines->Nif_8;
                                $_POST['total_amount'] = $batch_lines->Total_23; 
                                $_POST['Commission'] = $batch_lines->Commission_20;
                                $_POST['tva'] = ($batch_lines->Commission_20 * 0.16);
                                $_POST['total_topaid'] = $batch_lines->Total_23; 

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $_POST['cGuichet'] = $compte_cgu;

                                $this->data['batch_status'] = $batch_lines->Status_2;
                        }

                        if ($result == 'E003' || $result == 'E22' || $result == 'E21' || $result == 'E11' || $result == 'E34' || $result == 'E404' || $result == 'E405' || $result == 'E406' || $result == 'E13' || $result == 'E444' || $result == 'E501' || $result == 'E4' || $result == 'E000') 
                        {
                                echo $result;
                                die;
                        } 
                        else if ($result == "" && $result == NULL) 
                        {
                                echo "E411";
                                die;
                        } 
                        else 
                        {
                                $this->data['bulletins'] = $bulletins = $this->bulletinsModel->get_bulletins_by_lot($result);

                                $this->data['failds'] = array();
                                $this->data['account'] = (isset($_POST['account'])) ? $_POST['account'] : '';
                                $this->data['cdevise'] = (isset($_POST['cdevise'])) ? $_POST['cdevise'] : '';
                                $this->data['agent'] = $_POST['Agent'];
                                $this->data['office'] = $_POST['Office'];
                                $this->data['mode'] = $_POST['mode'];
                                $this->data['designation'] = $_POST['designation'];
                                $this->data['nif'] = $_POST['Nif'];
                                $this->data['accountnane'] = $account_name;
                                $this->data['total_amount'] = $_POST['total_amount'];
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['tva'] = $_POST['tva'];
                                $this->data['totalpaid'] = $_POST['total_topaid'];
                                $this->data['cGuichet'] = $_POST['cGuichet'];
                                $this->data['logirefid'] = $bulletins[0]->Logirefid_34;
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['step'] = 1;
                                
                                echo view('\Modules\Branch\Views\bulletins\_batch_step_3', $this->data);
                        }
                } 
                elseif($obj=="batch_treatments_current")
                {
                        $batch_lines = $this->integrationModel->get_bulletin_batch_info($id);

                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                // $bulletins = json_decode($batch_lines->Bulletins_22, true);

                                // $i = 1;
                                // $amounts = 0;

                                // for($i=1; $i<=count($bulletins['years']); $i++) 
                                // {
                                //         $bulletin = new \stdClass();

                                //         $amount = str_replace(' ', '', $bulletins['amounts'][$i]);
                                //         $amount = str_replace(',','.', $amount);

                                //         $bulletin->year = $bulletins['years'][$i];
                                //         $bulletin->serial = $bulletins['serials'][$i];
                                //         $bulletin->number = "";
                                //         $bulletin->amount = $amount;
                                //         $bulletin->error="E022";
                                //         $amounts += $amount;

                                //         $tables[] = $bulletin;
                                // }

                                // $refop = $batch_lines->Refop_25;
                                // $integrations = $this->comptabilisationModel->get_first_instructions_dgda($refop);
                        
                                // $integration_status = array();
                                
                                // foreach($integrations as $row)
                                // {
                                //         $integration_status[] = $row->Status_2;
                                // }

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['compte_guichet_unique'] = $compte_cgu;
                                
                                //$this->data['integrations'] = $integrations;
                                //$this->data['integration_status'] = $integration_status;

                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['batch'] = $batch_lines;

                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                                # Get the account CGU
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $this->data['cGuichet'] = $compte_cgu;

                                # Verify whether we are in the the case which the bullletins were 
                                # Confirmed but there has been a time out from the front-end
                                
                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($batch_lines->Lot_14);
                                
                                if(isset($bulletins[0]->Results_13) && $bulletins[0]->Results_13 != ''):
                                        $this->data['bulletins'] = $bulletins;
                                else:
                                        $this->data['bulletins'] = [];
                                endif;

                                echo view('\Modules\Branch\Views\bulletins\_batch_step_treatment', $this->data);
                        }
                }
                elseif ($obj == "batch_confirmation") 
                {
                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata['account_id'];
                        $_POST['User'] = $this->session->userdata['user_id'];

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);

                        $encrytions = json_decode($credentials->Password_18);

                        $data = $_POST;

                        $data['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                        $data['password'] = (isset($encrytions->encryption)) ? $encrytions->encryption : '';
                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";

                        set_time_limit(250);

                        #Invocation of the api sydonia
                        $result = $this->sydonia->comptant_batch($data);
                        
                        if ($result == 'E003' || $result == 'E22' || $result == 'E21' || $result == 'E11' || $result == 'E34' || $result == 'E404' || $result == 'E405' || $result == 'E406' || $result == 'E13' || $result == 'E444' || $result == 'E501' || $result == 'E4' || $result == 'E000') 
                        {
                                echo $result;
                                die;
                        }
                        else if ($result == "" && $result == NULL) 
                        {
                                echo "E411";
                                die;
                        } 
                        else 
                        {
                                $this->data['bulletins'] = $bulletins = $this->bulletinsModel->get_bulletins_by_lot($result);
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['paiement'] = $this->integrationModel->get_bulletins_batch_by_lot($_POST['lot_id']);
                                $this->data['failds'] = array();
                                $this->data['account'] = (isset($_POST['account'])) ? $_POST['account'] : '';
                                $this->data['cdevise'] = (isset($_POST['cdevise'])) ? $_POST['cdevise'] : '';
                                $this->data['agent'] = $_POST['Agent'];
                                $this->data['office'] = $_POST['Office'];
                                $this->data['mode'] = $_POST['mode'];
                                $this->data['designation'] = $_POST['designation'];
                                $this->data['nif'] = $_POST['Nif'];
                                $this->data['accountnane'] = $account_name;
                                $this->data['total_amount'] = $_POST['total_amount'];
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['tva'] = $_POST['tva'];
                                $this->data['totalpaid'] = $_POST['total_topaid'];
                                $this->data['compte_guichet_unique'] = $_POST['cGuichet'];
                                $this->data['logirefid'] = $bulletins[0]->Logirefid_34;
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\bulletins\_batch_confirmed', $this->data);
                        }
                } 
                elseif($obj == "batch_confirmation_branchless")
                { 
                         # Get the batch line from local server if already exists
                        $batch_info = $this->integrationModel->get_bulletins_batch_by_lot($_POST['logirefid']);
                        
                        # Get the the batch from remote server
                        $batch_branchless_line = $this->integrationModel->get_bulletins_batch_by_lot_branchless($_POST['logirefid']);
                        
                        if(empty($batch_info))
                        {
                                $json = json_encode($batch_branchless_line);
                                
                                $data = json_decode($json, true);
                                
                                if(isset($data['Lock_34'])) unset($data['Lock_34']);
                                
                                $batchid =  $this->integrationModel->save_batch_bulletin($data, NULL);
                                $batch_remote_id = $batch_branchless_line->Id_0;
                        }
                        else
                        {
                                $batchid = $batch_info->Id_0;
                                $batch_remote_id = $batch_branchless_line->Id_0;
                        }
                        
                        if($batchid > 0)
                { 
                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata['account_id'];
                        $_POST['User'] =  $this->session->userdata['user_id'];

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_dgda("'CTR'", NULL, $agence);

                        # Get the account CGU
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                                
                        $_POST['cGuichet'] = isset($type_comptes['CTR']) ? $type_comptes['CTR'] : '00000000000000000000000';

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);

                        $data = $_POST;
                        $data['login'] = isset($credentials->Login_17) ? $credentials->Login_17 : "";
                        $data['password'] = isset($encrytions->encryption) ? $encrytions->encryption : "";
                        $data['batchid'] = $batchid;
                        $data['batch_remote_id'] = $batch_remote_id;

                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";

                        $result = $this->sydonia->comptant_batch_branchless($data);

                        if($result=='E003' || $result=='E22' || $result=='E21' || $result=='E11' || $result=='E34' || $result == 'E404' || $result == 'E405' || $result == 'E406' || $result == 'E13'  || $result == 'E444' || $result == 'E501' || $result == 'E4' || $result == 'E000')
                        {
                                echo $result; die;
                        }
                        else if($result == "" || $result == NULL || $result == false)
                        {
                               echo "E411"; die;
                        }
                        else
                        {
                                                                $this->data['bulletins'] = $bulletins = $this->bulletinsModel->get_bulletins_by_lot($result);
                                $this->data['failds'] = array();
                                $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                                $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                                $this->data['agent'] = $_POST['Agent'];
                                $this->data['office'] = $_POST['Office'];
                                $this->data['mode'] = $_POST['mode'];
                                $this->data['designation'] = $_POST['designation'];
                                $this->data['nif'] = $_POST['Nif'];
                                $this->data['accountnane'] = $account_name;
                                $this->data['total_amount'] = $_POST['total_amount'];
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['tva'] = $_POST['tva'];
                                $this->data['totalpaid'] = $_POST['total_topaid'];
                                $this->data['cGuichet'] =  $_POST['cGuichet'];
                                        $this->data['logirefid'] = isset($bulletins[0])?$bulletins[0]->Logirefid_34:"";
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                                $this->data['step'] = 1;
                                //$this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_batch_step_3', $this->data);

                                        echo view('\Modules\Branch\Views\bulletins\_batch_step_3_branchless', $this->data);
                                } 
                        }
                        else
                        {
                                echo 'E504';
                        }                
                }
                elseif($obj == "batch_recover_branchless")
                {
                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $agence = $_SESSION['Logiref_guichet'];
                        $bulletins = array();
                        $failds = array();
                        $serials  = $_POST['years'];
                        $years = $_POST['serials'];
                        $amounts = $_POST['amounts'];

                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata['account_id'];
                        $_POST['User'] =  $this->session->userdata['user_id'];
                        
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];
                        $_POST['Taux'] = $taux;

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_dgda("'CTR'", NULL, $agence);

                        # Get the account CGU
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes); 
                        $_POST['cGuichet'] = isset($type_comptes['CTR']) ? $type_comptes['CTR'] : '00000000000000000000000';
                        $_POST['devise'] = 'CDF';
                        $_POST['Devise_commission'] = $_POST['devise_commision'];
                        $_POST['Mode'] = '';
                        $_POST['Total_amount'] = $_POST['total_amount'];
                        $_POST['reference'] = $_POST['logirefid'];
                        $_POST['DateL'] = gmdate('d-m-Y');
                        $_POST['lot'] = $_POST['logirefid'];
                        $_POST['Customercode'] = $_POST['customercode'];

                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";

                        $total_amount = 0;

                        // Variable retour
                        $verification = array();

                        //Verification de chaque bulletin dans SYDONIA
                        for($i = 1; $i<= count($serials); $i++)
                        {
                                $_POST['Year'] = $years = $_POST['years'][$i];
                                $montant1 =  str_replace(' ','',$_POST['amounts'][$i]);
                                $_POST['Amount']= $amount = str_replace(',','.',$montant1);
                                $total_amount = $total_amount + $amount;

                                $bulletin = $_POST['serials'][$i];
                                $service = $_POST['Office'];
                                $_POST['Series'] = $serial = substr($bulletin,0,1);
                                $_POST['Number'] = $number = substr($bulletin,1);
                                $agent = $_POST['Agent'];
                                $bank = $_POST['Bank'];

                                set_time_limit(250);
                                $response = $this->curlModel->call_batch_recover_branchless($credentials);

                                $response = json_decode($response, true);
                                
                                $error_codes = array(
                                        '0'=>'E404',
                                        '1'=>'E000',
                                        '2'=>'E002',
                                        '3'=>'E22'
                                );
                                
                                if(isset($response['code']) && in_array($response['code'], $error_codes))
                                {
                                        echo $response['code'];
                                        die;
                                }
                                else
                                {
                                        if(isset($response['id']) && $response['id'] > 0)
                                        {
                                                $bulletins[] = $response['id'];
                                        }
                                        else
                                        {
                                                $faild = new \stdClass();
                                                $faild->error = $response;
                                                $faild->number = $_POST['Number'];
                                                $faild->serial = $_POST['Series'];
                                                $faild->amount = $_POST['Amount'];
                                                $faild->year = $_POST['Year'];
                                                $failds[] = 'E22';
                                        }

                                }                
                        }

                        $result = implode(",",$bulletins);
                        

                        if(count($bulletins) > 0) 
                        {
                                # Get the the batch from remote server
                                $batch_branchless_line = $this->integrationModel->get_bulletins_batch_by_lot_branchless($_POST['logirefid']);
                                
                                $data_to_update = array();
                                $data_to_update['Status_2'] = 2;
                                $data_to_update['Status_31'] = 2;
                                $id = $batch_branchless_line->Id_0;
                                
                                $this->integrationModel->update_paiement_branchless_batch($data_to_update, $id);

                                $lot = $this->bulletinsModel->get_bulletins_by_lot($result);
                        }
                        else
                        {
                                $lot = array();
                        }

                        $this->data['bulletins'] = $lot;
                        $bulletin = current($lot);
                        $this->data['logirefid'] = isset($bulletin->Logirefid_34) ? $bulletin->Logirefid_34 : "";
                        $this->data['account'] = (isset($_POST['account']))? $_POST['account']:'';
                        $this->data['cdevise'] = (isset($_POST['cdevise']))? $_POST['cdevise']:'';
                        $this->data['agent'] = $_POST['Agent'];
                        $this->data['office'] = $_POST['Office'];
                        $this->data['mode'] = $_POST['mode'];
                        $this->data['designation'] = $_POST['designation'];
                        $this->data['nif'] = $_POST['Nif'];
                        $this->data['failds'] = $failds;
                        $this->data['accountnane'] = $account_name;
                        $this->data['total_amount'] = isset($_POST['total_amount'])?$_POST['total_amount']:"";
                        $this->data['commission'] = isset($_POST['Commission'])?$_POST['Commission']:"";
                        $this->data['tva'] = isset($_POST['tva'])?$_POST['tva']:"";
                        $this->data['totalpaid'] =isset($_POST['total_topaid'])?$_POST['total_topaid']:"";
                        $this->data['cGuichet'] =  isset($_POST['cGuichet'])?$_POST['cGuichet']:"";
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['step'] = "";

                        echo view('\Modules\Branch\Views\bulletins\_batch_step_3_branchless', $this->data);
                }
                elseif ($obj == "batch_confirmed_continuous") 
                {
                        $lot_id = $id;

                        $this->data['bulletins'] = $bulletins = $this->bulletinsModel->get_bulletins_by_logiredid($lot_id);
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['paiement'] = $paiement = $this->integrationModel->get_bulletins_batch_by_lot($lot_id);

                        $this->data['failds'] = array();
                        $this->data['account'] = $paiement->Account_16;
                        $this->data['cdevise'] = $paiement->Devise_17;
                        $this->data['agent'] = $paiement->Agent_9;
                        $this->data['office'] = $paiement->Office_7;
                        $this->data['mode'] = $paiement->Mode_19;                     
                        $this->data['designation'] = $paiement->Designation_15;
                        $this->data['nif'] = $paiement->Nif_8;

                        $this->data['accountnane'] = $paiement->Accountholder_18;
                        $this->data['total_amount'] = $paiement->Total_23;
                        $this->data['commission'] = $paiement->Commission_20;
                        $this->data['tva'] = $paiement->Commission_20 * 0.16;
                        $this->data['logirefid'] = $lot_id;

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                        # Get the account CGU
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $this->data['compte_guichet_unique'] = $compte_cgu;

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['step'] = 1;

                        echo view('\Modules\Branch\Views\bulletins\_batch_confirmed_continuous', $this->data);
                } 
                elseif ($obj == "batch_confirmation_export_file") 
                {
                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata['account_id'];
                        $_POST['User'] = $this->session->userdata['user_id'];

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);

                        $encrytions = json_decode($credentials->Password_18);

                        $data = $_POST;

                        $data['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                        $data['password'] = (isset($encrytions->encryption)) ? $encrytions->encryption : '';
                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";

                        set_time_limit(250);

                        #Invocation of the api sydonia
                        $result = $this->sydonia->comptant_batch($data);

                        if ($result == 'E003' || $result == 'E22' || $result == 'E21' || $result == 'E11' || $result == 'E34' || $result == 'E404' || $result == 'E405' || $result == 'E406' || $result == 'E13' || $result == 'E444' || $result == 'E501' || $result == 'E4' || $result == 'E000') 
                        {
                                echo $result;
                                die;
                        } 
                        else if ($result == "" && $result == NULL) 
                        {
                                echo "E411";
                                die;
                        } 
                        else 
                        {
                                $this->data['bulletins'] = $bulletins = $this->bulletinsModel->get_bulletins_by_lot($result);
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['paiement'] = $this->integrationModel->get_bulletins_batch_by_lot($_POST['lot_id']);
                                $this->data['failds'] = array();
                                $this->data['account'] = (isset($_POST['account'])) ? $_POST['account'] : '';
                                $this->data['cdevise'] = (isset($_POST['cdevise'])) ? $_POST['cdevise'] : '';
                                $this->data['agent'] = $_POST['Agent'];
                                $this->data['office'] = $_POST['Office'];
                                $this->data['mode'] = $_POST['mode'];
                                $this->data['designation'] = $_POST['designation'];
                                $this->data['nif'] = $_POST['Nif'];
                                $this->data['accountnane'] = $account_name;
                                $this->data['total_amount'] = $_POST['total_amount'];
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['tva'] = $_POST['tva'];
                                $this->data['totalpaid'] = $_POST['total_topaid'];
                                $this->data['compte_guichet_unique'] = $_POST['cGuichet'];
                                $this->data['logirefid'] = $bulletins[0]->Logirefid_34;
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['step'] = 1;
                                $this->data['action'] = isset($_POST['action']) ? $_POST['action'] : '';
                                $this->data['batch_id'] = isset($_POST['batch_id']) ? $_POST['batch_id'] : '';

                                if (isset($bulletins[0]->Id_0) && $bulletins[0]->Id_0 > 0) 
                                {
                                        echo $bulletins[0]->Id_0;
                                } 
                                else 
                                {
                                        echo "E002";
                                }
                        }
                } 
                elseif ($obj == "batch_recover") 
                {
                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $agence = $_SESSION['Logiref_guichet'];
                        $bulletins = array();
                        $failds = array();
                        $serials = $_POST['years'];
                        $years = $_POST['serials'];
                        $amounts = $_POST['amounts'];

                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);

                        $_POST['guichet'] = $guichet = $_SESSION['Logiref_guichet'];
                        $_POST['Account'] = $this->session->userdata['account_id'];
                        $_POST['User'] = $this->session->userdata['user_id'];
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";
                        $account_name = $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";

                        $total_amount = 0;

                        // Variable retour
                        $verification = array();

                        //Verification de chaque bulletin dans SYDONIA
                        for ($i = 1; $i <= count($serials); $i++) 
                        {
                                $_POST['Year'] = $years = $_POST['years'][$i];
                                $montant1 = str_replace(' ', '', $_POST['amounts'][$i]);
                                $_POST['Amount'] = $amount = str_replace(',', '.', $montant1);
                                $total_amount = $total_amount + $amount;

                                $bulletin = $_POST['serials'][$i];
                                $service = $_POST['Office'];
                                $_POST['Series'] = $serial = substr($bulletin, 0, 1);
                                $_POST['Number'] = $number = substr($bulletin, 1);
                                $agent = $_POST['Agent'];
                                $bank = $_POST['Bank'];

                                set_time_limit(250);
                                $response = $this->curlModel->call_batch_recover($credentials);
                                $response = trim($response);
                                if ($response == 'E404' || $response == 'E000' || $response == 'E002') 
                                {
                                        echo $response;
                                        die;
                                } 
                                else 
                                {
                                        if (is_numeric($response)) 
                                        {
                                                $bulletins[] = $response;
                                        } 
                                        else 
                                        {
                                                $faild = new \stdClass();
                                                $faild->error = $response;
                                                $faild->number = $_POST['Number'];
                                                $faild->serial = $_POST['Series'];
                                                $faild->amount = $_POST['Amount'];
                                                $faild->year = $_POST['Year'];
                                                $failds[] = $faild;
                                        }
                                }
                        }

                        $result = implode(",", $bulletins);
                        if (count($bulletins) > 0)
                                $lot = $this->bulletinsModel->get_bulletins_by_lot($result);
                        else
                                $lot = array();
                        
                        $this->data['bulletins'] = $lot;
                        $this->data['account'] = (isset($_POST['account'])) ? $_POST['account'] : '';
                        $this->data['cdevise'] = (isset($_POST['cdevise'])) ? $_POST['cdevise'] : '';
                        $this->data['agent'] = $_POST['Agent'];
                        $this->data['office'] = $_POST['Office'];
                        $this->data['mode'] = $_POST['mode'];
                        $this->data['designation'] = $_POST['designation'];
                        $this->data['nif'] = $_POST['Nif'];
                        $this->data['failds'] = $failds;
                        $this->data['accountnane'] = $account_name;
                        $this->data['total_amount'] = $_POST['total_amount'];
                        $this->data['commission'] = $_POST['Commission'];
                        $this->data['tva'] = $_POST['tva'];
                        $this->data['totalpaid'] = $_POST['total_topaid'];
                        $this->data['cGuichet'] = $_POST['cGuichet'];
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['step'] = 1;

                        echo view("\Modules\Branch\Views\bulletins\_batch_step_3",$this->data);
                }
                elseif ($obj == "batch_recover_start")
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        echo view('\Modules\Branch\Views\bulletins\_batch_recover_start', $this->data);
                }
                elseif ($obj == "batchs")
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        if(isset($this->functionalities['DGDA']['funds-reservation']) || isset($this->functionalities['DGDA']['funds-reservation-with-instructions']))
                        {
                                $this->data['bulletins'] = $this->integrationModel->get_unvalidated_batch_bl_funds_reservation();
                        }
                        else
                        {
                                $this->data['bulletins'] = $this->integrationModel->get_unvalidated_batch_bl();
                        }

                        $_SESSION['paiement_result'] = array();

                        echo view('\Modules\Branch\Views\bulletins\batchs', $this->data);
                }
                elseif ($obj == "batch")
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['paiement'] = $paiement = $this->integrationModel->get_bulletins_batch_by_id($id);
                        $this->data['bulletins'] = json_decode($paiement->Bulletins_22, true);
                        $_SESSION['paiement_result'] = [];

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);
                        $this->data['compte_guichet_unique'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";

                        echo view('\Modules\Branch\Views\bulletins\_batch', $this->data);
                }
                elseif ($obj == "__batch")
                {
                        $lot_id = array();

                        foreach ($_POST['batch_reference'] as $row)
                        {
                                $lot_id [] = $row;
                        }
                        
                        $lot_id = sprintf("'%s'", implode("','", $lot_id));
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $paiement = $this->integrationModel->get_paiement_batchs_by_reference($lot_id);
                        
                        
                        $data = array();
                        $data['total_commission'] =0;
                        $data['total_amount'] =0;
                        $data['total_bl'] =0;
                        
                        foreach($paiement as $line)
                        {
                                $bl_list = json_decode($line->Bulletins_22, true); 
                                $total_bl = isset($bl_list['years']) ? count($bl_list['years']) : 0;
                                
                                $data['total_commission'] += $line->Commission_20;
                                $data['total_amount'] += $line->Amount_11;
                                $data['total_bl'] += $total_bl;
                        }
                        
                        
                        $this->data['data'] = $data;
                        $this->data['bulletins'] = $this->integrationModel->get_bulletins_by_many_logirefid($lot_id);
                        
                        //var_dump($this->data['bulletins']); die;
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_dgda("'CGU'", NULL, $agence);

                        # Get the account CGU
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $this->data['compte_guichet_unique'] = $compte_cgu;
                        $this->data['batch_reference'] = $_POST['batch_reference'];

                        echo view('\Modules\Branch\Views\bulletins\__batch_confirmed_continuous', $this->data);
                } 
                elseif ($obj == "result") 
                {
                        $this->data['paiementid'] = $_POST['bulletin_id'];
                        $this->data['paiement_result'] = $_SESSION['paiement_result'];
                        
                        echo view('\Modules\Branch\Views\bulletins\_result', $this->data);
                } 
                elseif ($obj == "result_with_export_file") 
                {
                        $this->data['logirefid'] = '';
                        $this->data['batch_reference'] = $_POST['batch_reference'];
                        $this->data['action'] = isset($_POST['action']) ? $_POST['action'] : "";
                        $this->data['integration'] = $this->integrationModel->get_integration_sftp_by_id($id);
                        
                        $this->data['bulletin_id'] = isset($_POST['bulletin_id']) ? $_POST['bulletin_id'] : '0';

                        echo view('\Modules\Branch\Views\bulletins\__result', $this->data);
                } 
                elseif ($obj == "result_integration_single_bl") 
                {
                        $this->data['integration'] = $this->integrationModel->get_integration_sftp_by_id($id);

                        echo view('\Modules\Branch\Views\bulletins\__result_single_bl', $this->data);
                } 
                elseif ($obj == "extractbls") 
                {
                        set_time_limit(250);

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";

                        $_POST['Logirefid'] = mt_rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y') . mt_rand(1, 99);

                        $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);
                        $designation = ($client != NULL && isset($client->Designation_5) && $client->Designation_5 !="") ? $client->Designation_5 : $_POST['designation'];

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);

                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];

                        $data = $_POST;
                        $data['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                        $data['password'] = (isset($encrytions->encryption)) ? $encrytions->encryption : '';
                        $data['User'] = $this->session->userdata['user_id'];
                        $data['Account'] = $this->session->userdata['account_id'];
                        $data['taux'] = $taux;
                        $data['Agence'] = $_SESSION['Logiref_guichet'];
                        $data['designation'] = $designation;

                        //$response = $this->curlModel->call_dgda_payments($credentials);

                        $response = $this->sydonia->extract_bl($data);

                        if ($response == "E514" || $response == "E404" || $response == "E44" || $response == "E501" || $response == "E502" || $response == "E405" || $response == "E406" || $response == "E000" || $response == "E13"):

                                echo $response;
                                die;
                        else :
                                $this->data['lot'] = $response;
                                $this->data['account'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                $this->data['currency'] = isset($_POST['account_currency']) ? $_POST['account_currency'] : "";
                                $this->data['accountname'] = isset($_POST['account_name']) ? $_POST['account_name'] : "";
                                $this->data['balance'] = isset($_POST['balance']) ? $_POST['balance'] : "0";
                                $this->data['office'] = $_POST['Office'];
                                $this->data['cGuichet'] = $_POST['cGuichet'];
                                $this->data['designation']= $designation;
                                $Logirefid = $this->data['Logirefid'] = $_POST['Logirefid'];
                                $this->data['bulletins'] = $this->bulletinsModel->get_bulletins_by_logiredid($Logirefid);
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['step'] = 1;

                                echo view('\Modules\Branch\Views\bulletins\_batch_recover_step_1', $this->data);

                        endif;
                } 
                elseif ($obj == "single_recover") 
                {
                        $_POST['Paiementid'] = $_POST['bulletin_id'];

                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];
                        
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, NULL);
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        
                        $notemontant = str_replace(' ','',$_POST['Amount']);
                        $Amount = str_replace(',','.',$notemontant);
                        
                        $data = array();
                        $data['designation'] = isset($_POST['designation']) ? $_POST['designation'] : "";
                        $data['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                        $data['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                        $data['Amount'] = intval($Amount);
                        $data['Year'] = $_POST['Year'];
                        $data['Series'] = $_POST['Series'];
                        $data['Number'] = $_POST['Number'];
                        $data['Agent'] = $_POST['Agent'];
                        $data['Office'] = $_POST['Office'];
                        $data['Nif'] = $_POST['Nif'];
                        $data['Account'] = $this->session->userdata['account_id'];
                        $data['Bank'] = $_POST['Bank'];
                        $data['User'] = $this->session->userdata['user_id'];
                        $data['Devise'] = $_POST['devise'];
                        $data['Compte_guichet'] = isset($_POST['Compte_guichet'])?$_POST['Compte_guichet']:"";
                        $data['Commission'] = $_POST['Commission'];
                        $data['Devise_commission'] = $_POST['Devise_commission'];
                        $data['Total_amount'] = $_POST['Total_amount'];
                        $data['Mode'] = $_POST['Mode'];
                        $data['ReferenceOp'] = $_POST['reference'];
                        $data['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                        $data['Agence'] = $_SESSION['Logiref_guichet'];
                        $data['DateL'] = $_POST['DateL'];
                        $data['cGuichet'] = $_POST['cGuichet'];
                        $data['Taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux;
                        $data['bank_account'] = isset($_POST['bank_account']) ? $_POST['bank_account'] : "";
                        $data['Devise_account'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                        $data['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                        
                        $response = $this->sydonia->recover_single($data);
                        
                        $result = json_decode($response, true);
                        
                        if(isset($result['code']))
                        {
                                echo $result['code'];
                        }
                        else
                        {
                                echo 'E404';
                        }
                } 
                elseif ($obj == "single_recover_branchless") 
                {
                        $_POST['Paiementid'] = $_POST['bulletin_id'];

                        $agence_src = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, NULL);
                        $_POST['cGuichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curlModel->call_single_recover($credentials); //recover_single
                        $response = trim($response);

                        if ($response == 'E003' || $response == 'E22' || $response == 'E11' || $response == 'E34' || $response == 'E404' || $response == 'E13' || $response == 'E000' || $response == 'E18' || $response == 'E21' || $response == 'E15') 
                        {
                                echo $response;
                                die;
                        } 
                        elseif ($response == 'OK') 
                        {
                                # declaration under payment process or not paid yet.
                                echo $response;
                        } 
                        else 
                        {
                                # Update the payment on RBO
                                $this->save("update_bl_rbo", $_POST['Paiementid']);
                                #If the bulletin is from RBO
                                $log_info = $this->integrationModel->get_log_brancless_by_bl($_POST['Paiementid']);

                                if (isset($log_info->Id_0))
                                {
                                        $log_data['Status_2'] = '2';
                                        $this->integrationModel->update_log_info($log_data, $log_info->Id_0);
                                }
                                echo $response;
                                die;
                        }
                } 
                elseif ($obj == "edit") 
                {
                        
                        $bl = $id;
                        $arrondi = 0;
                        $frais_bcc = 0;
                        $fbc_propres = 0;
                        $comptes_fbc = '00000000000000000000000';
                        $comptes_fbc_propes = '00000000000000000000000';

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);

                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        # Test if the functionalities of arrondis has to be taken into account
                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                {
                                        if ($bulletin->Mode_30 == '5') 
                                        {
                                                $total_amount_payed = $bulletin->Amount_25;
                                                $real_total_amount = $this->encaissementModel->get_montant_total($data);
                                                $arrondi = $total_amount_payed - $real_total_amount;

                                                $data['arrondi'] = $arrondi;
                                        }
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced before the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-before-validation-with_exception'])) 
                        {
                                # Deduce the remote compensation 
                                $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                        }

                        $instructions1 = $this->comptabilisation->get_instructions_dgda($data);

                        $info = $encaissement->Notereference_30;

                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        # Verify the option of fetching accounts based on DGDA office
                        if (isset($this->options['DGDA']['accounts-fetch-by-dgda-office'])) 
                        {
                                $return = $this->branchModel->get_branche_by_service($data['Service_16']);

                                $agence = $return;
                        }

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $instructions2 = array();

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $taxes = array();
                        $taxesPaid = $info['taxesPaid'];
                        if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                        {
                                $taxes = $taxesPaid;
                        } 
                        elseif (is_object($taxesPaid) && $taxesPaid != "") 
                        {
                                $taxes[] = $taxesPaid;
                        }

                        # Verify in the options tab if the bcc fees account is retrieved by account
                        if (isset($this->options['ALL']['get-bank-fees-account-based-on-branch-code'])) 
                        {
                                $code_agence = isset($data['Compte_33']) ? substr($data['Compte_33'], 0, 5) : "";
                                $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, NULL, $code_agence);
                        } 
                        else 
                        {
                                if (isset($this->options['ALL']['bcc-fees-deduction'])) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                        $frais_bcc = $amount + $frais_bcc;
                                                }
                                        }
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation-with_exception'])) 
                        {
                                # initialization of the treasury tax value 
                                $is_there_taxe_tresor = false;

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        if ($taxe->taxeAmount > 0) 
                                                        {
                                                                $is_there_taxe_tresor = true;
                                                        }
                                                }
                                        }
                                }

                                $frais_bcc += $data['Montant_11'] * ($is_there_taxe_tresor ? 0.002 : 0.0015);
                        }

                        # Déduction des frais BCC après validation pour les taxes des fonds propres
                        if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $taxe_code = $taxe->taxeCode; 
                                                $taxe_amount = $taxe->taxeAmount;

                                                $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                //$frais_bcc += $fees_bcc['Valeur'];
                                                if (($_SESSION['userdata']['account_id']) == "36")
                                                        $fbc_propres += $fees_bcc['Valeur'];
                                                else
                                                        $frais_bcc += $fees_bcc['Valeur'];
                                        }
                                }
                        }

                        if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $data['Typerecette_17'] = $taxe->taxeCode;

                                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                if($type_comptes['CPI'] == '000000000000000000000000')
                                                {
                                                        $frais_bcc += $taxe->taxeAmount * 0.002;
                                                }
                                        }
                                }
                        }

                        # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                        if ($frais_bcc > 0) 
                        {
                                $data['frais_bcc'] = $frais_bcc;
                            
                                if (!isset($comptes_fbc)) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                            
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                $instruction = current($instruction);
                            
                                if (!empty($instruction)) 
                                {
                                        $instructions2[] = $instruction;
                                }
                        }

                        if ($fbc_propres > 0) 
                        {
                                $data['frais_bcc'] = $fbc_propres;
                                $data['RFPROPD'] = "PROPRES";
                            
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc_propes, $data, 'DGDA');
                                $instruction = current($instruction);
                            
                                if (!empty($instruction)) 
                                {
                                        $instructions2[] = $instruction;
                                }
                        }

                        # Verify in the options tab if the option of remote compensation is activated
                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('tax_others_banks', $this->functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }
                        }

                        # Encode the value of Notereference_30 before generating instructions
                        $data['Notereference_30'] = json_encode($data['Notereference_30']);

                        foreach ($taxes as $taxe) 
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;

                                $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                $instructions2[] = $instruction;

                                #Taxes comptes
                                $comptes_recettes = array();

                                $comptes_recettes = $this->accountModel->get_comptes_recettes_agence_array($agence, "'CPI','CPT'");

                                # Call the method to know whether tax
                                # is to be sent to others banks
                                if (isset($tax_others_banks[$taxe->taxeCode])) 
                                {
                                        $instruction = $this->data("additionnal_instructions_for_leveling", $comptes_recettes, $data, $tax_others_banks);
                                        foreach ($instruction as $row) 
                                        {
                                                $instructions2[] = $row;
                                        }
                                }
                        }

                        # Verify in the options tab if the option of remote compensation is activated
                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('taxes_autres_banques', $this->functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }
                        }

                        $others_banks_instructions = array();

                        foreach ($instructions2 as $row) 
                        {
                                if(isset($row['Codetaxe_28']))
                                {
                                        if (isset($tax_others_banks[$row['Codetaxe_28']])) 
                                        {
                                                $others_banks_instructions [$row['Codetaxe_28']][] = $row;
                                        }
                                }
                        }

                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['others_banks_instructions'] = $others_banks_instructions;
                        $this->data['tax_others_banks'] = isset($tax_others_banks) ? $tax_others_banks : array();
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        $this->data['bulletin_remote_id'] = $bl_in_remote_bd->Id_0;

                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : "";
                        $this->data['cCompte'] = isset($_GET['mode']) ? $_GET['compte'] : "";
                        $this->data['cDevise'] = isset($_GET['mode']) ? $_GET['devise'] : "";
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['bulletin'] = $bulletin;
                        $this->data['param'] = isset($_GET ["param"]) && $_GET ["param"] !="" ? $_GET ["param"]:""; 


                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['step'] = 1;


                        echo view('\Modules\Branch\Views\bulletins\_step_2', $this->data);
                } 
                elseif ($obj == "edit_branchless") 
                {
                        
                        $bl = $id;
                        $arrondi = 0;
                        $frais_bcc = 0;
                        $comptes_fbc = '00000000000000000000000';
                        
                        $bl_in_remote_bd = $this->integrationModel->get_paiement_sydonia_branchless($id);

                        $_POST['Amount'] = $bl_in_remote_bd->Amount_12;
                        $_POST['Office'] = $bl_in_remote_bd->Office_6;
                        $_POST['Year'] = $bl_in_remote_bd->Year_5;
                        $_POST['Nif'] = $bl_in_remote_bd->Nif_9;
                        $_POST['Series'] = $bl_in_remote_bd->Serie_7;
                        $_POST['Number'] = $bl_in_remote_bd->Number_8;
                        $_POST['Bank'] = $bl_in_remote_bd->Bank_11;
                        $_POST['Agent'] = $bl_in_remote_bd->Agent_10;
                        
                        $return = $this->integrationModel->check_bulletin_sydonia();
                        
                        if(empty($return))
                        {
                                $id = $this->save("save_bulletin_branchless_treated_on_remote", $bl_in_remote_bd);
                                $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        }
                        else
                        {
                                $bulletin = current($return);
                                $id = $this->save("save_bulletin_branchless_treated_on_remote", array(), $bulletin, $bl_in_remote_bd->Id_0);
                                $id = $bulletin->Id_0;
                        }

                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        # Test if the functionalities of arrondis has to be taken into account
                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('comptabilisation_arrondis', $this->functionalities['functionalities'])) 
                                {
                                        if ($bulletin->Mode_30 == '5') 
                                        {
                                                $total_amount_payed = $bulletin->Amount_25;
                                                $real_total_amount = $this->encaissementModel->get_montant_total($data);
                                                $arrondi = $total_amount_payed - $real_total_amount;

                                                $data['arrondi'] = $arrondi;
                                        }
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced before the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-before-validation-with_exception'])) 
                        {
                                # Deduce the remote compensation 
                                $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                        }

                        $existent_instructions = $this->integrationModel->get_instructions_dgda_branchless_by_paiement_id($bl);
                        
                        if(empty($existent_instructions))
                        {
                                $instructions1 = $this->comptabilisation->get_instructions_dgda_branchless($data);
                        }
                        else
                        {
                                $instructions1 = $existent_instructions;
                        }

                        $info = $encaissement->Notereference_30;
                        $liste = ("'CPT', 'CPI', 'CSO', 'CTR'");
                        $agence = $_SESSION['Logiref_guichet'];

                        # Verify the option of fetching accounts based on DGDA office
                        if (isset($this->options['DGDA']['accounts-fetch-by-dgda-office'])) 
                        {
                                $return = $this->branchModel->get_branche_by_service($data['Service_16']);

                                $agence = $return;
                        }
                        
                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                        
                        $comptes_ctr = $this->accountModel->get_comptes_dgda("'CTR'", NULL, $agence);

                        # Get the account CGU for the payment treated online (branchless)
                        $type_comptes_ctr = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes_ctr); 
                        
                        $compte_cgu = isset($type_comptes_ctr['CTR']) ? $type_comptes_ctr['CTR'] : '00000000000000000000000';

                        $instructions2 = array();

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $taxes = array();
                        $taxesPaid = $info['taxesPaid'];
                        if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                        {
                                $taxes = $taxesPaid;
                        } 
                        elseif (is_object($taxesPaid) && $taxesPaid != "") 
                        {
                                $taxes[] = $taxesPaid;
                        }

                        # Verify in the options tab if the bcc fees account is retrieved by account
                        if (isset($this->options['ALL']['get-bank-fees-account-based-on-branch-code'])) 
                        {
                                $code_agence = isset($data['Compte_33']) ? substr($data['Compte_33'], 0, 5) : "";
                                $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, NULL, $code_agence);
                        } 
                        else 
                        {
                                if (isset($this->options['ALL']['bcc-fees-deduction'])) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                        $frais_bcc = $amount + $frais_bcc;
                                                }
                                        }
                                }

                                # Contruct the instructions for frais bcc
                                $data['frais_bcc'] = $frais_bcc;
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);

                                if (!empty($instruction)) 
                                {
                                        $instructions2[] = $instruction;
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation-with_exception'])) 
                        {
                                # initialization of the treasury tax value 
                                $is_there_taxe_tresor = false;

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        if ($taxe->taxeAmount > 0) 
                                                        {
                                                                $is_there_taxe_tresor = true;
                                                        }
                                                }
                                        }
                                }

                                # Deduce the remote compensation 
                                # If the bulletin there is a treasury taxe
                                if ($is_there_taxe_tresor) 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                                } 
                                else 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.0015;
                                }

                                # Contruct the instructions for frais bcc
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);
                              
                                if (!empty($instruction)) 
                                {
                                        $instructions2[] = $instruction;
                                }
                        }

                        # Encode the value of Notereference_30 before generating instructions
                        $data['Notereference_30'] = json_encode($data['Notereference_30']);

                        foreach ($taxes as $taxe) 
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;

                                $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);

                                $instructions2[] = $instruction;
                                

                                #Taxes comptes
                                $comptes_recettes = array();

                                $comptes_recettes = $this->accountModel->get_comptes_recettes_agence_array($agence, "'CPI','CPT'");

                                $tax_others_banks=array();
                                # Call the method to know whether tax
                                # is to be sent to others banks
                                if (isset($tax_others_banks[$taxe->taxeCode])) 
                                {
                                        $instruction = $this->data("additionnal_instructions_for_leveling", $comptes_recettes, $data, $tax_others_banks);
                                        foreach ($instruction as $row) 
                                        {
                                                $instructions2[] = $row;
                                        }
                                }
                        }

                        # Verify in the options tab if the option of remote compensation is activated
                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('taxes_autres_banques', $this->functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }
                        }

                        $others_banks_instructions = array();

                        foreach ($instructions2 as $row) 
                        {
                                if(isset($row['Codetaxe_28']))
                                {
                                        if (isset($tax_others_banks[$row['Codetaxe_28']])) 
                                        {
                                                $others_banks_instructions [$row['Codetaxe_28']][] = $row;
                                        }
                                }
                        }

                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['others_banks_instructions'] = $others_banks_instructions;
                        $this->data['tax_others_banks'] = isset($tax_others_banks) ? $tax_others_banks : array();
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        $this->data['bulletin_remote_id'] = $bl_in_remote_bd->Id_0;

                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : "";
                        $this->data['cCompte'] = isset($_GET['mode']) ? $_GET['compte'] : "";
                        $this->data['cDevise'] = isset($_GET['mode']) ? $_GET['devise'] : "";
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['bulletin'] = $bulletin;

                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['step'] = 1;

                        echo view('\Modules\Branch\Views\bulletins\_step_2_branchless', $this->data);
                } 
                elseif ($obj == "preview") 
                {
                        $bl = $id;

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] != "") ? $_GET['controller'] : '';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] != "") ? $_GET['view'] : '';
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $instructions = $this->comptabilisationModel->get_instructions_dgda($id);

                        $others_banks_instructions = array();
                        $tax_others_banks = array();

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "") 
                        {
                                if (in_array('tax_others_banks', $this->functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }

                                foreach ($instructions as $row) 
                                {
                                        if (isset($tax_others_banks[$row->Codetaxe_28])) 
                                        {
                                                $others_banks_instructions [$row->Codetaxe_28][] = $row;
                                        }
                                }
                        }

                        $this->data['tax_others_banks'] = $tax_others_banks;
                        $this->data['others_banks_instructions'] = $others_banks_instructions;
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\bulletins\_step_3', $this->data);
                } 
                elseif ($obj == "getquittance") 
                {
                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        
                        #initialisation
                        $apidata = array();
                        $bl = $id;

                        $bulletin = $this->integrationModel->get_paiement_sydonia($bl);
                        
                        if($arg == 'batch')
                        {
                                $bulletin->Pdfcontent_18 = 'quittances/QUITTANCE_L_26440.pdf';
                        }
                        else
                        {
                                $bulletin->Pdfcontent_18 = 'quittances/QUITTANCE_L_26440.pdf';
                        }

                        //$bulletin->Pdfcontent_18 = 'quittances/QUITTANCE_L_26440.pdf';

                        if (isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 != "") 
                        {
                                $quittance = $bulletin->Pdfcontent_18;
                                echo $quittance;
                        } 
                        else 
                        {
                                $declaration = json_decode($bulletin->Results_13);
                                $apidata['ReceiptSerial'] = $declaration->receiptSerial;

                                $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                                $apidata['ReceiptDate'] = $declaration->receiptDate;
                                $apidata['Office'] = $bulletin->Office_6;

                                $apidata['Account'] = $this->session->userdata['account_id'];
                                $apidata['Paiementid'] = $bl;
                                $apidata['User'] = $this->session->userdata['user_id'];
                                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                                $apidata['password'] = (isset($encrytions->encryption)) ? $encrytions->encryption : '';
                                $apidata['code_bank'] = (isset($encrytions->codebank)) ? $encrytions->codebank : '';

                                $response = $this->sydonia->quittance($apidata);

                                if ($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000") 
                                {
                                        echo $response;
                                } 
                                else 
                                {
                                        $bulletin = $this->integrationModel->get_paiement_sydonia($bl);

                                        if (isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 != "") 
                                        {
                                                $quittance = $bulletin->Pdfcontent_18;
                                                echo $quittance;
                                        } 
                                        else 
                                        {
                                                echo "E406";
                                        }
                                }
                        }
                } 
                elseif ($obj == "_batch_2") 
                {
                        $bl = $id;

                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);
                        $instructions = $this->integrationModel->get_instructions_dgda_by_paiement_id($bulletin->Id_0);

                        # Convertir les objets stdClass en tableaux associatifs
                        $instructions = array_map(function($row) {
                                return (array) $row;
                        }, $instructions);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $this->data['instructions'] = $instructions;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = isset($_GET['mode']) ? $_GET['mode'] : "";
                        $this->data['cCompte'] = isset($_GET['mode']) ? $_GET['compte'] : "";
                        $this->data['cDevise'] = isset($_GET['mode']) ? $_GET['devise'] : "";
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        echo view('\Modules\Branch\Views\bulletins\_batch_2', $this->data);

                } 
                elseif ($obj == "step_1_branchless") 
                {
   
                        $bulletin = $this->integrationModel->get_paiement_sydonia_branchless($id);
                        // var_dump($bulletin);die;
                        $this->data['bulletin'] = $bulletin;
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['user_session_id']=$this->session->userdata['user_id'];
                        $this->data['account_session_id']=$this->session->userdata['account_id'];

                        return view("\Modules\Branch\Views\bulletins\_step_1_branchless", $this->data);
                        // $log_info = $this->integrationModel->get_log_brancless_info($id);
                        // var_dump($log_info);die;
                        // $bl_info = json_decode($log_info->Bulletin_9);

                        // # Insert data in post to in order to send data
                        // $_POST['Office'] = isset($bl_info->bureau) ? $bl_info->bureau : "";
                        // $_POST['Year'] = isset($bl_info->year) ? $bl_info->year : "";
                        // $_POST['Nif'] = isset($bl_info->nif) ? $bl_info->nif : "";
                        // $_POST['Series'] = isset($bl_info->serial) ? $bl_info->serial : "";
                        // $_POST['Number'] = isset($bl_info->number) ? $bl_info->number : "";
                        // $_POST['Amount'] = isset($bl_info->amount) ? $bl_info->amount : "";
                        // $_POST['Bank'] = isset($bl_info->bank_code) ? $bl_info->bank_code : "";
                        // $_POST['Agent'] = isset($bl_info->agent) ? $bl_info->agent : "";

                        // $bulletin = $this->integrationModel->retrieve_bulletin_by_log_info();

                        // if (empty($bulletin)) 
                        // {
                        //         #BL inexistant
                        //         echo 0;
                        // } 
                        // else 
                        // {

                        //         $this->data['bulletin'] = current($bulletin);
                        //         $this->data['step'] = 0;
                        //         $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        //         $this->data['user_session_id']=$this->session->userdata['user_id'];
                        //         $this->data['account_session_id']=$this->session->userdata['account_id'];

                        //         return view("\Modules\Branch\Views\bulletins\_step_1_branchless", $this->data);
                        // }
                }
                elseif($obj == "instructions_attestation")
                {
                        $instructions = [];
                        $data = $_POST;

                        $instruction = $this->integrationModel->get_instructions_unvalidated_attestation_dgda($data['Sydonia_44']);

                        if (empty($instruction))
                        {
                                #Impression des attestation - repartition
                                $commission = 0;
                                $devise_com = '';

                                $end_execution = '';
                                $data = $_POST;

                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];

                                $infos = $data['Infos'];

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                                $types = [
                                        'FIA' => $paid_attestation ?? null,
                                        'FDA' => $paid_duplicata ?? null,
                                ];

                                foreach ($types as $code => $paid) 
                                {
                                        if ($paid === $code) 
                                        {
                                                $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                {
                                                        $commission = $rules['Valeur'];
                                                        $devise_com = $rules['Unite'];

                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                        $data['Type_fees'] = $code;

                                                        $instructions = $this->comptabilisation->get_instructions_printed_attestation_for_dgda($data);
                                                }
                                        }
                                }

                                if (!empty($instructions))
                                {
                                        $this->data['instructions'] = $instructions;

                                        $return['code'] = "200";
                                        $return['html'] = view('\Modules\Branch\Views\bulletins\_instructions_attestation', $this->data);
                                }
                                else
                                {
                                        $return['code'] = "405";
                                }

                                echo json_encode($return);
                        }
                        else
                        {
                                $result['code'] = 'E405';
                                $result['id'] = 0;
                                
                                echo json_encode($result);
                        }
                }
                elseif ($obj == 'transactions_detail') 
                {
                        $message_id = $id;
                        $data = $this->data("get_transactions_by_message_id", $message_id);

                        echo view('\Modules\Branch\Views\reports\_payment_integrated', $data);
                }
                #Default
                elseif ($obj == "deny") 
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
         */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL,$param1=NULL) 
        {
                if ($obj == "comptant") 
                {
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();

                        $data = $_POST;
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $frais_bcc = 0;
                        $fbc_propres =0;

                        $infos = $data['Infos'];

                        $data['Notereference_30'] = json_encode($infos);
                        unset($data['Infos']);
                        if(isset($data['taxes_amounts']))unset($data['taxes_amounts']);

                        #Taux de change
                        if (isset($_POST['Taux_41']) && $_POST['Taux_41'] != "") 
                        {
                                $data['Taux_41'] = $_POST['Taux_41'];
                        } 
                        else if ($data['Devise_12'] != 'CDF') 
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if ($data['Devise_12'] == 'USD')
                                        $data['Taux_41'] = $taux['Dollar_4'];
                                if ($data['Devise_12'] == 'EUR')
                                        $data['Taux_41'] = $taux['Euro_5'];
                                if ($data['Devise_12'] == 'ZAF')
                                        $data['Taux_41'] = $taux['Rand_6'];
                        }

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ', '', $data['Montant_11']);
                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);
                        $data['Notemontant_28'] = str_replace(' ', '', $data['Notemontant_28']);
                        $data['Notemontant_28'] = str_replace(',', '.', $data['Notemontant_28']);
                        $data['Taux_41'] = str_replace(' ', '', $data['Taux_41']);
                        $data['Taux_41'] = str_replace(',', '.', $data['Taux_41']);
                        $data['Commission_23'] = str_replace(' ', '', $data['Commission_23']);
                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                        #Contre valeur en CDF
                        $data['Devise_42'] = $data['Devise_12'];
                        $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                        $data['Beneficaire_15'] = 'DGDA';

                        # SAVE PAYMENT

                        $results = $infos;
                        $prefix = 1;
                        $logirefid = $data['Logirefid_4'];
                        $end_execution = NULL;

                        #Taxes comptes
                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        # Verify the option of fetching accounts based on DGDA office
                        if (isset($this->options['DGDA']['accounts-fetch-by-dgda-office'])) 
                        {
                                $return = $this->branchModel->get_branche_by_service($data['Service_16']);

                                $agence = $return;
                        }

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);
                        $instructions = array();

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $taxes = array();
                        //$taxesPaid = unserialize($results['taxesPaid']);
                        $taxesPaidRaw = html_entity_decode($results['taxesPaid'], ENT_QUOTES, 'UTF-8');
                        $taxesPaid = unserialize($taxesPaidRaw);
                        if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                        {
                                $taxes = $taxesPaid;
                        } 
                        elseif (is_object($taxesPaid) && $taxesPaid != "") 
                        {
                                $taxes[] = $taxesPaid;
                        }

                        #Serie et numero du bulletin
                        $noteid = isset($data['Noteid_26']) ? $data['Noteid_26'] : "";

                        $bulletin = $this->integrationModel->get_paiement_sydonia($data['Sydonia_44']);

                        $pkeys_tresor = array();
                        $pkeys_propre = array();

                        foreach ($taxes as $taxe) 
                        {
                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
                                } 
                                else 
                                {
                                        $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
                                }
                        }
                        if (!empty($pkeys_tresor)) 
                        {
                                $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                if (!empty($pkeys_tresor_exist)) 
                                {
                                        foreach ($pkeys_tresor_exist as $row) 
                                        {
                                                $pkeys_tresor_exist[] = $row->Paiementkey_50;
                                        }
                                }
                        }
                        if (!empty($pkeys_propre)) 
                        {
                                $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                if (!empty($pkeys_propre_exist))
                                {
                                        foreach ($pkeys_propre_exist as $row) 
                                        {
                                                $pkeys_propre_exist[] = $row->Paiementkey_50;
                                        }
                                }
                        }

                        $data_tresor = array();
                        $data_propre = array();

                        if (isset($functionalities['functionalities']) && $functionalities['functionalities'] != "") 
                        {
                                if (in_array('comptabilisation_arrondis', $functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }
                        }


                        # Verify in the options tab if the bcc fees account is retrieved by account
                        if (isset($this->options['ALL']['get-bank-fees-account-based-on-branch-code'])) 
                        {
                                $code_agence = isset($data['Compte_33']) ? substr($data['Compte_33'], 0, 5) : "";
                                $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, NULL, $code_agence);
                        } 
                        else 
                        {
                                if (isset($this->options['ALL']['bcc-fees-deduction'])) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                        $frais_bcc = $amount + $frais_bcc;
                                                }
                                        }
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation-with_exception'])) 
                        {
                                # initialization of the treasury tax value 
                                $is_there_taxe_tresor = false;

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        if ($taxe->taxeAmount > 0) 
                                                        {
                                                                $is_there_taxe_tresor = true;
                                                        }
                                                }
                                        }
                                }

                                # Deduce the remote compensation 
                                # If the bulletin there is a treasury taxe
                                if ($is_there_taxe_tresor) 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                                } 
                                else 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.0015;
                                }

                                # Contruct the instructions for frais bcc
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);

                                if (!empty($instruction)) 
                                {
                                        $instructions[] = $instruction;
                                }
                        }

                        if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $taxe_code = $taxe->taxeCode; 
                                                $taxe_amount = $taxe->taxeAmount;

                                                $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                //$frais_bcc += $fees_bcc['Valeur'];
                                                if (($_SESSION['userdata']['account_id']) == "36")
                                                        $fbc_propres += $fees_bcc['Valeur'];
                                                else
                                                        $frais_bcc += $fees_bcc['Valeur'];
                                        }
                                }
                        }

                        if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $data['Typerecette_17'] = $taxe->taxeCode;

                                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                if($type_comptes['CPI'] == '000000000000000000000000')
                                                {
                                                        $frais_bcc += $taxe->taxeAmount * 0.002;
                                                }
                                        }
                                }
                        }

                        # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                        if ($frais_bcc > 0) 
                        {
                                $data['frais_bcc'] = $frais_bcc;
                                
                                # Comptes à utiliser, selon ce qui est disponible
                                if (!isset($comptes_fbc)) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                                
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                $instruction = current($instruction);
                                
                                if (!empty($instruction)) 
                                        $instructions[] = $instruction;
                        }

                        # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                        if ($fbc_propres > 0) 
                        {
                                $comptes_fbc_propes = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                $data['frais_bcc'] = $fbc_propres;
                                $data['RFPROPD'] = "PROPRES";
                                
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc_propes, $data, 'DGDA');
                                $instruction = current($instruction);
                                
                                if (!empty($instruction)) 
                                        $instructions[] = $instruction;

                                unset($data['RFPROPD']);
                        }

                        if (isset($data['frais_bcc']))
                                unset($data['frais_bcc']);

                        foreach ($taxes as $taxe) 
                        {
                                $data['Logirefid_4'] = $logirefid . '-' . $prefix;
                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;

                                $pid = "";

                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_tresor_exist)) 
                                        {
                                                $data['Missmatch_46'] = 0;
                                                $data['Tresor_45'] = '1';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $type_rectte = $type_recettes[$taxe->taxeCode];

                                                $data_tresor[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);

                                                $instructions[] = $instruction;
                                        }
                                } 
                                else if (isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                        {
                                                $data['Missmatch_46'] = 0;
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $data_propre[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                $instructions[] = $instruction;

                                                # Call the method to know whether tax
                                                # is to be sent to others banks
                                                if (isset($tax_others_banks[$taxe->taxeCode])) 
                                                {
                                                        #Taxes comptes
                                                        $comptes_recettes = array();

                                                        $comptes_recettes = $this->accountModel->get_comptes_recettes_agence_array($agence, "'CPI','CPT'");

                                                        $instruction = $this->data("additionnal_instructions_for_leveling", $comptes_recettes, $data, $tax_others_banks);

                                                        foreach ($instruction as $row) 
                                                        {
                                                                $instructions[] = $row;
                                                        }
                                                }
                                        }
                                } 
                                else 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                        {
                                                $data['Missmatch_46'] = 1;
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $taxe->taxeCode;

                                                $data_propre[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                $instructions[] = $instruction;
                                        }
                                }

                                $prefix++;
                        }

                        #Impression des attestation - repartition
                        if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                        {
                                $instruction_fees = array();

                                #Impression des attestation - repartition
                                $commission = 0;
                                $devise_com = '';

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                                $types = [
                                        'FIA' => $paid_attestation ?? null,
                                        'FDA' => $paid_duplicata ?? null,
                                ];

                                foreach ($types as $code => $paid) 
                                {
                                        if ($paid === $code) 
                                        {
                                                $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                {
                                                        $commission = $rules['Valeur'];
                                                        $devise_com = $rules['Unite'];

                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                        $data['Type_fees'] = $code;

                                                        $instruction_fees = $this->comptabilisation->get_instructions_printed_attestation_for_dgda($data);
                                                }
                                        }
                                }

                                if (!empty($instruction_fees)) 
                                {
                                        foreach ($instruction_fees as $row) 
                                        {
                                                $instructions[] = $row;
                                        }
                                }
                        }

                        $return = false;

                        if (!empty($data_tresor)) 
                        {
                                $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                        }
                        if (!empty($data_propre)) 
                        {
                                $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                        }
                        
                        if ($return) 
                        {
                                if (!empty($instructions)) 
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;

                                        $end_execution = $this->comptabilisationModel->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                                }

                                if ($end_execution) 
                                {
                                        # Verirfy the option is activated in order to save the instructions in log for the SFTP integration
                                        if(isset($this->options['DGDA']['breakdown-accounting-by-sftp-file-integration']))
                                        {
                                                $instructions = $this->integrationModel->clean_array_special_characters($instructions);
                                                
                                                $return = $this->save("save_cbs_journalisation", $data, $instructions, $bulletin);
                                        }
                                       
                                        $bl_data['Status_2'] = '2';
                                        $this->integrationModel->save_bulletin($bl_data, $data['Sydonia_44']);
                                        
                                        unset($instructions);
                                }

                                echo $data['Sydonia_44'];
                        }
                        else
                        {
                                if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                {
                                        #Payment exist already
                                        echo 'E500';
                                }
                                else
                                {
                                        echo 0;
                                }
                        }
                }
                elseif ($obj == "comptant_branchless") 
                {
                        
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();

                        $data = $_POST;
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $frais_bcc = 0;

                        $infos = $data['Infos'];

                        $data['Notereference_30'] = json_encode($infos);
                        unset($data['Infos']);
                        if(isset($data['bulletin_remote_id'])) unset($data['bulletin_remote_id']);

                        #Taux de change
                        if (isset($_POST['Taux_41']) && $_POST['Taux_41'] != "") 
                        {
                                $data['Taux_41'] = $_POST['Taux_41'];
                        } 
                        else if ($data['Devise_12'] != 'CDF') 
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if ($data['Devise_12'] == 'USD')
                                        $data['Taux_41'] = $taux['Dollar_4'];
                                if ($data['Devise_12'] == 'EUR')
                                        $data['Taux_41'] = $taux['Euro_5'];
                                if ($data['Devise_12'] == 'ZAF')
                                        $data['Taux_41'] = $taux['Rand_6'];
                        }

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ', '', $data['Montant_11']);
                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);
                        $data['Notemontant_28'] = str_replace(' ', '', $data['Notemontant_28']);
                        $data['Notemontant_28'] = str_replace(',', '.', $data['Notemontant_28']);
                        $data['Taux_41'] = str_replace(' ', '', $data['Taux_41']);
                        $data['Taux_41'] = str_replace(',', '.', $data['Taux_41']);
                        $data['Commission_23'] = str_replace(' ', '', $data['Commission_23']);
                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                        #Contre valeur en CDF
                        $data['Devise_42'] = $data['Devise_12'];
                        $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                        $data['Beneficaire_15'] = 'DGDA';

                        # SAVE PAYMENT

                        $results = $infos;
                        $prefix = 1;
                        $logirefid = $data['Logirefid_4'];
                        $end_execution = NULL;

                        #Taxes comptes
                        $liste = ("'CPT', 'CPI', 'CSO', 'CTR' ");
                        $agence = $_SESSION['Logiref_guichet'];
                       

                        # Verify the option of fetching accounts based on DGDA office
                        if (isset($this->options['DGDA']['accounts-fetch-by-dgda-office'])) 
                        {
                                $return = $this->branchModel->get_branche_by_service($data['Service_16']);

                                $agence = $return;
                        }

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);
                        $instructions = array();

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $taxes = array();
                        $taxesPaid = unserialize($results['taxesPaid']);
                        if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                        {
                                $taxes = $taxesPaid;
                        } 
                        elseif (is_object($taxesPaid) && $taxesPaid != "") 
                        {
                                $taxes[] = $taxesPaid;
                        }

                        #Serie et numero du bulletin
                        $noteid = isset($data['Noteid_26']) ? $data['Noteid_26'] : "";

                        $bulletin = $this->integrationModel->get_paiement_sydonia($data['Sydonia_44']);

                        $existent_instructions=$this->integrationModel->get_instructions_dgda_branchless_by_paiement_id($data['Sydonia_44']);
                        $first_instructions=array();
                        if(!empty($existent_instructions))
                        {
                                foreach($existent_instructions as $instruction)
                                {
                                        if($instruction['TypeCompte_29'] != "P")
                                        {
                                                $first_instructions[]=array(
                                                                'Operation_8'=>'V', 
                                                                'Compte_9'=>$instruction['Compte_9'],
                                                                'Libelle_12'=>$instruction['Libelle_12'],
                                                                'Montant_10'=>$instruction['Montant_10'], 
                                                                'Devise_11'=>$instruction['Devise_11'],
                                                                'Compte_13'=>$instruction['Compte_13'],
                                                                'Codetaxe_28'=>$instruction['Codetaxe_28'],
                                                                'TypeCompte_29'=>$instruction['TypeCompte_29']
                                                        );
                                        }
                                        
                                }
                        }

                        $pkeys_tresor = array();
                        $pkeys_propre = array();

                        foreach ($taxes as $taxe) 
                        {
                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
                                } 
                                else 
                                {
                                        $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;
                                }
                        }
                        if (!empty($pkeys_tresor)) 
                        {
                                $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                if (!empty($pkeys_tresor_exist)) 
                                {
                                        foreach ($pkeys_tresor_exist as $row) 
                                        {
                                                $pkeys_tresor_exist[] = $row->Paiementkey_50;
                                        }
                                }
                        }
                        if (!empty($pkeys_propre)) 
                        {
                                $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                if (!empty($pkeys_propre_exist))
                                {
                                        foreach ($pkeys_propre_exist as $row) 
                                        {
                                                $pkeys_propre_exist[] = $row->Paiementkey_50;
                                        }
                                }
                        }

                        $data_tresor = array();
                        $data_propre = array();

                        if (isset($functionalities['functionalities']) && $functionalities['functionalities'] != "") 
                        {
                                if (in_array('comptabilisation_arrondis', $functionalities['functionalities'])) 
                                {
                                        $tax_others_banks = $this->data("tax_others_banks", $data);
                                }
                        }


                        # Verify in the options tab if the bcc fees account is retrieved by account
                        if (isset($this->options['ALL']['get-bank-fees-account-based-on-branch-code'])) 
                        {
                                $code_agence = isset($data['Compte_33']) ? substr($data['Compte_33'], 0, 5) : "";
                                $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, NULL, $code_agence);
                        } 
                        else 
                        {
                                if (isset($this->options['ALL']['bcc-fees-deduction'])) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                        $frais_bcc = $amount + $frais_bcc;
                                                }
                                        }
                                }

                                # Contruct the instructions for frais bcc
                                $data['frais_bcc'] = $frais_bcc;
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);

                                if (!empty($instruction)) 
                                {
                                        $instructions[] = $instruction;
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation-with_exception'])) 
                        {
                                # initialization of the treasury tax value 
                                $is_there_taxe_tresor = false;

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        if ($taxe->taxeAmount > 0) 
                                                        {
                                                                $is_there_taxe_tresor = true;
                                                        }
                                                }
                                        }
                                }

                                # Deduce the remote compensation 
                                # If the bulletin there is a treasury taxe
                                if ($is_there_taxe_tresor) 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                                } 
                                else 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.0015;
                                }

                                # Contruct the instructions for frais bcc
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);

                                if (!empty($instruction)) 
                                {
                                        $instructions[] = $instruction;
                                }
                        }

                        if (isset($data['frais_bcc']))
                                unset($data['frais_bcc']);

                        foreach ($taxes as $taxe) 
                        {
                                $data['Logirefid_4'] = $logirefid . '-' . $prefix;
                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $bulletin->Year_5;

                                $pid = "";
                               
                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_tresor_exist)) 
                                        {
                                                $data['Missmatch_46'] = 0;
                                                $data['Tresor_45'] = '1';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $type_rectte = $type_recettes[$taxe->taxeCode];

                                                $data_tresor[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);

                                                $instructions[] = $instruction;
                                        }
                                } 
                                else if (isset($beneficiaires[$taxe->taxeCode])) 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                        {
                                                $data['Missmatch_46'] = 0;
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                $data_propre[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);
                                                $instructions[] = $instruction;

                                                # Call the method to know whether tax
                                                # is to be sent to others banks
                                                if (isset($tax_others_banks[$taxe->taxeCode])) 
                                                {
                                                        #Taxes comptes
                                                        $comptes_recettes = array();

                                                        $comptes_recettes = $this->accountModel->get_comptes_recettes_agence_array($agence, "'CPI','CPT'");

                                                        $instruction = $this->data("additionnal_instructions_for_leveling", $comptes_recettes, $data, $tax_others_banks);

                                                        foreach ($instruction as $row) 
                                                        {
                                                                $instructions[] = $row;
                                                        }
                                                }
                                        }
                                } 
                                else 
                                {
                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                        {
                                                $data['Missmatch_46'] = 1;
                                                $data['Tresor_45'] = '0';
                                                $data['Beneficaire_15'] = $taxe->taxeCode;

                                                $data_propre[] = $data;
                                                $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);
                                                $instructions[] = $instruction;
                                        }
                                }

                                $prefix++;
                        }

                        $return = false;

                        if (!empty($data_tresor)) 
                        {
                                $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                        }
                        if (!empty($data_propre)) 
                        {
                                $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                        }

                        if ($return) 
                        {
                                if (!empty($instructions)) 
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;

                                        $end_execution = $this->comptabilisationModel->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                                        // unset($instructions);
                                }

                                // $instructions=array();
                                # Verirfy the option is activated in order to save the instructions in log for the SFTP integration
                                if(isset($this->options['DGDA']['breakdown-accounting-by-sftp-file-integration']))
                                {
                                        $journalistation_instructions=array_merge($first_instructions,$instructions);
                                        $instructions = $this->integrationModel->clean_array_special_characters($journalistation_instructions);
                                        
                                        $return = $this->save("save_cbs_journalisation", $data, $instructions, $bulletin,"branchless");
                                }
                                
                                // $bl_data['Status_2'] = '2';
                                // $this->integrationModel->save_bulletin($bl_data, $data['Sydonia_44']);
                                
                                unset($instructions);
                                // if ($end_execution) 
                                // {
                                //         $bl_data['Status_2'] = '2';
                                //         $this->integrationModel->save_bulletin($bl_data, $data['Sydonia_44']);
                                // }
                                
                                # Update the bulletin_remote 
                                $data_to_update = array();
                                $id = $_POST['bulletin_remote_id'];
                                $data_to_update['Status_2'] = 2;
                                $data_to_update['Status_39'] = 2;
                                
                                $this->integrationModel->update_paiement_branchless($data_to_update, $id);
                                echo $data['Sydonia_44'];
                        } 
                        else 
                        {
                                if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                {
                                        #Payment exist already
                                        echo 'E500';
                                } 
                                else 
                                {
                                        echo 0;
                                }
                        }
                }
                elseif ($obj == "validate_single_bl")
                {
                        if (isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "")
                        {
                                $data = $_POST;
                                $code = '';
                                $id = $_POST['Sydonia_44'];

                                #Is this a validation? Yes if it's a validator or the supervisor
                                if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2)
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['type'] = 'comptant';
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['Designation_14'];
                                        $data['Account_3'] = $this->session->userdata['account_id'];

                                        $agence = $_SESSION['Logiref_guichet'];
                                        $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);
                                        $data['compte_guichet'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'validate_payment')) 
                                        {
                                                $return = $this->{$core_banking}->validate_payment($data);

                                                $result = json_decode($return, true);

                                                if ($result['code'] == '200') 
                                                {
                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                        if ($tid) 
                                                        {
                                                                $bl_data['Status_2'] = '3';
                                                                $bl = $this->integrationModel->save_bulletin($bl_data, $id);
                                                        }
                                                }

                                                echo $return;
                                                die;
                                        } 
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result);
                                                die;
                                        }
                                } 
                                else 
                                {
                                        $result['code'] = 'E408';
                                        echo json_encode($result);
                                        die;
                                }
                        } 
                        else 
                        {
                                $result['code'] = 'E409';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif ($obj == "validate") 
                {
                        $data = $_POST;
                        $code = '';

                        if (isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "") 
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) 
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['type'] = 'comptant';
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Logirefid_4'] =  $_POST['Logirefid'] ?? "";
                                        $id = $_POST['Sydonia_44'];
                                        #Invocation of the api transfer
                                        # Nom du core banking
                                        
                                        $core_banking = strtolower($this->core_banking);
                                        $result = $this->{$core_banking}->virement($data);
                                        
                                        $return = json_decode($result, true);

                                        if (isset($return['response']) && $return['response'] == "200") 
                                        {
                                                $code = 200;
                                                $message = isset($return['message']) ? $return['message'] : "";
                                                $id = $_POST['Sydonia_44'];
                                                $_SESSION['paiement_result'][$id] = $code;

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                if ($tid) 
                                                {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->integrationModel->save_bulletin($bl_data, $id);
                                                }
                                        } 
                                        elseif (isset($return['response']) && $return['response'] != "") 
                                        {
                                                $info['lien_id'] = "";
                                                $info['date_lien'] = "";
                                                $bl_data['Reservation_43'] = json_encode($info);
                                                $bl = $this->integrationModel->save_bulletin($bl_data, $id);
                                                $code = $return['response'];

                                                $_SESSION['paiement_result'][$id] = $code;

                                                $message = isset($return['message']) ? $return['message'] : "";
                                        }
                                }
                                
                                $bulletins = $this->integrationModel->get_bulletins_by_lot_to_validate($_POST['lot']);
                                
                                $return = $this->data('get_view', $bulletins, $_POST);

                                echo $return;
                        }
                } 
                elseif ($obj == "paid_attestation")
                {
                        $data =$_POST;

                        $logirefid = $data['Logirefid_4'];
                        $end_execution = NULL;

                        #Is this a validation? Yes if it's a validator or the supervisor
                        if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                        {
                                #Impression des attestation - repartition
                                $instruction_fees = array();

                                #Impression des attestation - repartition
                                $commission = 0;
                                $devise_com = '';

                                $infos = $data['Infos'];

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                                $types = [
                                        'FIA' => $paid_attestation ?? null,
                                        'FDA' => $paid_duplicata ?? null,
                                ];

                                foreach ($types as $code => $paid) 
                                {
                                        if ($paid === $code) 
                                        {
                                                $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                {
                                                        $commission = $rules['Valeur'];
                                                        $devise_com = $rules['Unite'];

                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                        $data['Type_fees'] = $code;

                                                        $instruction_fees = $this->comptabilisation->get_instructions_printed_attestation_for_dgda($data);
                                                }
                                        }
                                }

                                if (!empty($instruction_fees)) 
                                {
                                        foreach ($instruction_fees as $row) 
                                        {
                                                $instructions[] = $row;
                                        }

                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        
                                        $end_execution = $this->comptabilisationModel->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                                        unset($instructions);
                                }

                                if ($end_execution) 
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Variable initialization for payment validation
                                        * ------------------------------------------------
                                        */
                                        
                                        $id =  $data['Sydonia_44'];
                                        
                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);
                                        
                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'validate_payment')) 
                                        { 
                                                $return = $this->{$core_banking}->virement_bank_charge_exception($data);

                                                $result = json_decode($return, true);
                                                                
                                                if($result['code'] == '200')
                                                {
                                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                        $result['id'] = $id;
                                                }
                                                                                                
                                                echo $return;
                                                die;
                                        }
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                                echo json_encode($result); die;
                        }
                }
                elseif($obj == "save_cbs_journalisation")
                {
                        $paiement_data = $id;
                        $instructions = $arg;
                        $bulletin = $param;
                        $type=$param1;
                        $final_return = '';
                        $data_= array();
                        
                        # Get data to save
                        $return = $this->integrationModel->get_data_cbs_journalisation($paiement_data, $instructions, $bulletin,$type);
                        
                        if($return['code'] == '200')
                        {
                                $this->integrationModel->save_cbs_journalisation($return['data'], NULL);
                                
                                $final_return =  $return['code'];
                        }
                        else
                        {
                                $final_return = $return['code'];
                        }
                        
                        return $final_return;
                }
                elseif ($obj == "instructions") 
                {
                        if (!empty($_POST)) 
                        {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                                $bulletins = array();
                                $bulletin_ids = array();

                                $logirefid = $_POST['Logirefid'];

                                $bulletins = $this->integrationModel->get_bulletins_by_logirefid($logirefid);

                                foreach ($bulletins as $row) 
                                {
                                        $bulletin_ids[] = $row->Id_0;
                                }

                                $bulletin_ids = implode(',', $bulletin_ids);

                                // Nombre des bulletins
                                $all_paiements = count($bulletins);

                                $bulletins_instruction = $this->integrationModel->get_bulletins_instructions_by_ids($bulletin_ids);

                                // Total des instructions de tous les bulletins
                                $total_instructions_bulletins = count($bulletins_instruction);

                                $batch_line = $this->integrationModel->get_bulletins_batch_by_lot($logirefid);

                                // Montant total des tous les bulletins
                                $total_amount = isset($batch_line->Amount_11) ? $batch_line->Amount_11 : 0;

                                if (!empty($bulletins_instruction)) 
                                {
                                        $data['Instructions_7'] = json_encode($bulletins_instruction);
                                        $data['Paiements_10'] = $all_paiements;
                                        $data['Instructions_11'] = $total_instructions_bulletins;
                                        $data['Agence_14'] = $_SESSION['Logiref_guichet'];
                                        $data['Montant_12'] = $total_amount;
                                        $data['Regie_13'] = 'DGDA';
                                        $data['Devise_16'] = 'CDF';

                                        $paiements = array();
                                        $paiements['bulletins'] = $bulletins;

                                        $data['Paiements_17'] = json_encode($paiements);

                                        $pid = $this->offlineModel->save_integrations($data, $id);

                                        if ($pid > 0) 
                                        {
                                                $data_to_update = array();
                                                $data_to_update['Status_2'] = 3;

                                                $this->integrationModel->save_batch_bulletin($data_to_update, $_POST['batchid']);
                                                echo $pid;
                                        } 
                                        else 
                                        {
                                                echo '202';
                                        }
                                } 
                                else 
                                {
                                        echo '400';
                                        die;
                                }
                        } 
                        else 
                        {
                                echo '501';
                                die;
                        }
                } 
                elseif ($obj == "bulletin") 
                {
                        $bulletin = $this->integrationModel->check_bulletin_sydonia();
                    
                        if (empty($bulletin)) 
                        {
                                $logirefid = $id;
                                $type = $arg;
                                $arrondi = 0;

                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                $data['Designation_23'] = $this->integrationModel->remove_all_special_characters($_POST['designation']);

                                $data['Amount_12'] = str_replace(' ', '', $_POST['Amount']);
                                $data['Amount_12'] = str_replace(',', '.', $data['Amount_12']);

                                $data['Amount_25'] = str_replace(' ', '', $_POST['Total_amount']);
                                $data['Amount_25'] = str_replace(',', '.', $data['Amount_25']);

                                $data['Commission_26'] = str_replace(' ', '', $_POST['Commission']);
                                $data['Commission_26'] = str_replace(',', '.', $data['Commission_26']);

                                # Test if the functionalities of arrondis has to be taken into account
                                if (isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                {
                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                        {
                                                if ($_POST['Mode'] == '5') 
                                                {
                                                        $total_amount_payed = $data['Amount_25'];

                                                        $data_to_send = array();

                                                        $data_to_send['Montant_11'] = $data['Amount_12'];
                                                        $data_to_send['Commission_23'] = $data['Commission_26'];

                                                        $real_total_amount = $this->encaissementModel->get_montant_total($data_to_send);

                                                        $arrondi = $total_amount_payed - $real_total_amount;
                                                }
                                        }
                                }

                                $branch_code = $_POST['branch_code'] ?? '';
                                $bank_account = (($branch_code != "") ? $branch_code.'-' : '') . $_POST['bank_account'];

                                $data['Devise_27'] = $_POST['devise'];
                                $data['Year_5'] = $_POST['Year'];
                                $data['Serie_7'] = $_POST['Series'];
                                $data['Number_8'] = $_POST['Number'];
                                $data['Agent_10'] = $_POST['Agent'];
                                $data['Office_6'] = $_POST['Office'];
                                $data['Nif_9'] = $_POST['Nif'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Bank_11'] = $_POST['Bank'];
                                $data['User_15'] = $this->session->userdata['user_id'];
                                $data['Mode_30'] = $_POST['Mode'];

                                $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                                $data['Account_28'] = $bank_account;
                                $data['Account_24'] = $_POST['Compte_guichet'];
                                $data['Devise_29'] = $_POST['Devise_account'];

                                $data['Devise_27'] = $_POST['Devise_amount'];
                                $data['Reference_19'] = isset($_POST['reference']) ? $_POST['reference'] : "";

                                $data['Taux_31'] = $_POST['Taux'];
                                $data['Accountholder_33'] = $_POST['account_name'];

                                if (isset($_POST['pourcompte']))
                                        $paiementinfo['pourcompte'] = $_POST['pourcompte'];

                                if (isset($_POST['tva']))
                                        $paiementinfo['tva'] = $_POST['tva'];
                                if (isset($_POST['fraisbcc']))
                                        $paiementinfo['fraisbcc'] = $_POST['fraisbcc'];
                                if (isset($_POST['DateL']))
                                        $paiementinfo['DateL'] = $_POST['DateL'];

                                if (isset($paiementinfo)) 
                                {
                                        $data['Paiementinfo_44'] = json_encode($paiementinfo);
                                }

                                if ($type == 'reservation') 
                                {
                                        $info['lien_id'] = $_POST['lien_id'];
                                        $info['date_lien'] = $_POST['date_lien'];
                                } 
                                else 
                                {
                                        $info['lien_id'] = "";
                                        $info['date_lien'] = "";
                                }

                                $data['Reservation_43'] = json_encode($info);

                                $data['Logirefid_34'] = $logirefid;

                                $last_id = $this->integrationModel->get_last_paiement_id();
                                $next_id = $last_id + 1;

                                # The unique key of the payment
                                $montant =  intval($data['Amount_12']);
                                $data['Paiementkey_42'] = $data['Year_5'].$data['Office_6'].$data['Serie_7'].$data['Number_8'].$data['Nif_9'].$data['Bank_11'].$montant;

                                if(isset($this->options['DGDA']['funds-reservation']))
                                {
                                        $data['Treated_45'] = 2;
                                }

                                $id = $this->integrationModel->save_bulletin($data, NULL);

                                if ($id) 
                                {
                                        $data = array();

                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Agence_20'] = $_SESSION['Logiref_agence'];
                                        $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                        $data['Mode_19'] = $_POST['Mode'];
                                        $data['Typerecette_17'] = $_POST['Year'] . $_POST['Series'] . $_POST['Number'];
                                        $data['Service_16'] = $_POST['Office'];
                                        $data['Devise_34'] = $_POST['Devise_account'];

                                        if (isset($paiementinfo['tva'])) 
                                        {
                                                $data['tva'] = $paiementinfo['tva'];
                                        } 
                                        else 
                                        {
                                                $data['tva'] = "";
                                        }

                                        if (isset($paiementinfo['fraisbcc'])) 
                                        {
                                                $data['fraisbcc'] = $paiementinfo['fraisbcc'];
                                        } 
                                        else 
                                        {
                                                $data['fraisbcc'] = "";
                                        }

                                        $data['Montant_11'] = str_replace(' ', '', $_POST['Amount']);
                                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                                        $data['Devise_12'] = $_POST['devise'];
                                        $data['Compte_33'] = $_POST['bank_account'];
                                        $data['Noteid_26'] = $_POST['Year'] . $_POST['Series'] . $_POST['Number'];
                                        $data['Notedate_27'] = gmdate('Y-m-d');

                                        $data['Commission_23'] = $_POST['Commission'];

                                        $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                                        $data['Devise_24'] = $_POST['Devise_commission'];
                                        $data['Nif_13'] = $_POST['Nif'];

                                        # Verify in the options tab if the bcc fees is deduced before the validation with an exception
                                        if (isset($this->options['DGDA']['bcc-fees-deduction-before-validation-with_exception'])) 
                                        {
                                                # Deduce the remote compensation 
                                                $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                                        }

                                        # Get the instruction for the roundings when the payment method is cash
                                        if ($arrondi > 0) 
                                        {
                                                $data['arrondi'] = $arrondi;
                                        }

                                        # Comptabilisation
                                        $instructions = $this->comptabilisation->get_instructions_dgda($data);
                                      
                                        if (!empty($instructions)) {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                
                                                $instructions = $this->integrationModel->clean_array_special_characters($instructions);
                                                
                                                $r = $this->comptabilisationModel->save_first_instructions_dgda($id, $data, $instructions, $logirefid, $priority);
                                        }

                                        $return['id'] = $id;
                                        $return['logirefid'] = $logirefid;
                                        $return['code'] = 'E200';

                                        return $return;
                                } 
                                else 
                                {
                                        return 0;
                                }
                        }
                        else
                        {
                                $bulletin = current($bulletin);
                                # Enter this block in case the bulletin has already been saved and treated
                                $return['id'] = $bulletin->Id_0;
                                $return['logirefid'] = $bulletin->Logirefid_34;
                                $return['code'] = 'E200';

                                return $return;
                        }
                } 
                elseif ($obj == "cbs_return") 
                {
                        if ($id != "" && $arg != "") 
                        {
                                # Data to save in the in logiref_cbs_return
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Sydonia_5'] = $id;
                                $data['Result_6'] = $arg;

                                # Save in logiref_cbs_return
                                $this->integrationModel->save_cbs_return($data, NULL);
                        }
                } 
                elseif ($obj == "batch_reservation") 
                {
                        $refOp = $id;
                        $data = array();
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Agence_20'] = $_SESSION['Logiref_agence'];
                        $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                        $data['Mode_19'] = $_POST['mode'];
                        $data['Typerecette_17'] = 'OP' . $id;
                        $data['Devise_34'] = 'CDF';
                        $data['Service_16'] = '';

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ', '', $_POST['total_amount']);
                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                        $data['Devise_12'] = $_POST['cdevise'];
                        $data['Compte_33'] = $_POST['account'];
                        $logirefid = $data['Noteid_26'] = $id;

                        //Formatting amount
                        $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                        $data['Devise_24'] = $_POST['devise_commision'];
                        $data['Nif_13'] = $_POST['Nif'];
                        $data['Notedate_27'] = gmdate('Y-m-d');

                        $agence_src = $_SESSION['Logiref_guichet'];

                        # Comptabilisation
                        $instructions = $this->comptabilisation->get_instructions_dgda($data);

                        if (!empty($instructions)) 
                        {
                                # priority for integrating the counting in cbs
                                $priority = 0;
                                $this->comptabilisationModel->save_comptant_batch_instructions($id, $data, $instructions, $logirefid, $priority);
                        }

                        return $refOp;
                } 
                elseif ($obj == "batch_bulletin") 
                {
                        $return = array();
                        $reference_op = isset($_POST['refOp']) ? $_POST['refOp'] : "";
                        $batch_line = $this->integrationModel->check_batch_bulletin_sydonia($reference_op);

                        if (empty($batch_line))
                        {
                                $logirefid = $id;
                                $type = $arg;

                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];

                                $data['Office_7'] = $_POST['Office'];
                                $data['Nif_8'] = $_POST['Nif'];
                                $data['Agent_9'] = $_POST['Agent'];
                                $data['Bank_10'] = $_POST['Bank'];

                                $data['Amount_11'] = str_replace(' ', '', $_POST['total_amount']);
                                $data['Amount_11'] = str_replace(',', '.', $data['Amount_11']);

                                $data['Devise_12'] = 'CDF';

                                $data['User_13'] = $this->session->userdata['user_id'];
                                $data['Lot_14'] = $logirefid;
                                $data['Designation_15'] = $this->integrationModel->remove_all_special_characters($_POST['designation']);

                                $data['Account_16'] = $_POST['account'];
                                $data['Devise_17'] = $_POST['cdevise'];
                                $data['Accountholder_18'] = $_POST['account_name'];
                                $data['Mode_19'] = $_POST['mode'];

                                $data['Commission_20'] = str_replace(' ', '', $_POST['Commission']);
                                $data['Commission_20'] = str_replace(',', '.', $data['Commission_20']);

                                $data['Devise_21'] = $_POST['devise_commision'];

                                $data['Total_23'] = str_replace(' ', '', $_POST['total_topaid']);
                                $data['Total_23'] = str_replace(',', '.', $data['Total_23']);

                                $bulletins['years'] = $_POST['years'];
                                $bulletins['serials'] = $_POST['serials'];
                                $bulletins['numbers']= $_POST['numbers'];
                                $bulletins['amounts'] = $_POST['amounts'];

                                $data['Bulletins_22'] = json_encode($bulletins);
                                $data['Agence_24'] = $_SESSION['Logiref_guichet'];
                                $data['Refop_25'] = $_POST['refOp'];
                                $data['Typeaccount_36'] = $_POST['account_type'];

                                # The variable type permits to distinguish whether the bulletin is paid with 
                                # an current account or an internal account
                                if ($type == 'reservation') 
                                {
                                        $info['lien_id'] = $_SESSION['lien_id'] = $_POST['lien_id'];
                                        $info['date_lien'] = $_SESSION['date_lien'] = $_POST['date_lien'];
                                } 
                                else 
                                {
                                        $info['lien_id'] = "";
                                        $info['date_lien'] = "";
                                }

                                $data['Taux_26'] = str_replace(' ', '', $_POST['taux']);
                                $data['Taux_26'] = str_replace(',', '.', $data['Taux_26']);

                                $data['Reservation_35'] = json_encode($info);

                                $id = $this->integrationModel->save_batch_bulletin($data, NULL);

                                if ($id != "") 
                                {
                                        $data = array();

                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Agence_20'] = $_SESSION['Logiref_agence'];
                                        $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                        $data['Mode_19'] = $_POST['mode'];
                                        $data['Typerecette_17'] = $refOp = $_POST['refOp'];
                                        $data['Service_16'] = $_POST['Office'];
                                        $data['Devise_34'] = $_POST['cdevise'];

                                        if (isset($_POST['tva']) && $_POST['tva'] > 0) 
                                        {
                                                $data['tva'] = $_POST['tva'];
                                        } 
                                        else 
                                        {
                                                $data['tva'] = "";
                                        }

                                        $data['Montant_11'] = str_replace(' ', '', $_POST['total_amount']);
                                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                                        $data['Devise_12'] = 'CDF';
                                        $data['Compte_33'] = $_POST['account'];
                                        $data['Noteid_26'] = $_POST['refOp'];
                                        $data['Notedate_27'] = gmdate('Y-m-d');

                                        $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                                        $data['Devise_24'] = $_POST['devise_commision'];
                                        $data['Nif_13'] = $_POST['Nif'];

                                        $agence_src = $_SESSION['Logiref_guichet'];

                                        # Comptabilisation
                                        $instructions = $this->comptabilisation->get_instructions_dgda($data);

                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                //$this->comptabilisationModel->save_comptant_batch_instructions($id, $data, $instructions, $logirefid, $priority);
                                                $instructions = $this->integrationModel->clean_array_special_characters($instructions);
                                                $this->comptabilisationModel->save_comptant_batch_instructions($reference_op, $data, $instructions, $logirefid, $priority);
                                        }

                                        $return['id'] = $id;
                                        $return['code'] = 'E200';

                                        return $return;
                                } 
                                else 
                                {
                                        return 0;
                                }
                        } 
                        else 
                        {
                                $batch_line = current($batch_line);

                                if (isset($batch_line->Treated_34) && $batch_line->Treated_34 > 0)
                                {
                                        # Enter this block in case the bulletin has already been saved and treated
                                        $return['id'] = isset($batch_line->Id_0) ? $batch_line->Id_0 : '';
                                        $return['code'] = 'E200';

                                        return $return;
                                } 
                                else 
                                {
                                        $return['id'] = isset($batch_line->Id_0) ? $batch_line->Id_0 : '';
                                        $return['code'] = 'E500';

                                        return $return;
                                }
                        }
                } 
                elseif ($obj == "save_batch") 
                {
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();
                        $prefix = 1;

                        $frais_bcc = 0;
                        $fbc_propres = 0;

                        $end_execution = NULL;

                        $Missmatch['Missmatch_32'] = 0;

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $payments = $this->bulletinsModel->get_bulletins_by_logiredid($_POST['Logirefid']);

                        $i = 1;
                        foreach ($payments as $row) 
                        {
                                $encaissement = $this->dataModel->sydonia_migrate_bl($row->Id_0);

                                $agence_src = $_SESSION['Logiref_guichet'];

                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);

                                //$data['Compte_33'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                $data['Compte_33'] = (isset($_POST['Compte_33']) && $_POST['Compte_33']!="") 
                                                        ? $_POST['Compte_33'] 
                                                        : (isset($_POST['account']) && $_POST['account']!=""  ? $_POST['account'] : "000000000000000000000000");
                                $amount = $data['Montant_11'];

                                $client = $this->logirefModel->get_clients_by_nif($encaissement->Nif_13);
                                $data['Designation_14'] = ($client != NULL && isset($client->Designation_5) && $client->Designation_5!= "") ? $client->Designation_5 : (isset($_POST['designation']) ? $_POST['designation'] : "");

                                $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                $data['Commission_23'] = 0;
                                $data['Devise_24'] = "CDF";
                                $commission = 0;
                                $commission_devise = "CDF";

                                #Save payment de chaque taxe
                                $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                                $agence = $_SESSION['Logiref_guichet'];

                                $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                $instructions = array();

                                $info = $encaissement->Notereference_30;

                                $taxesPaid = $info['taxesPaid'];

                                if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                                {
                                        $taxes = $taxesPaid;
                                } 
                                elseif (is_object($taxesPaid) && $taxesPaid != "") 
                                {
                                        $taxes = array();

                                        $taxes[] = $taxesPaid;
                                }

                                $logirefid = $data['Logirefid_4'];

                                #Serie et numero du bulletin
                                $noteid = isset($data['Typerecette_17']) ? $data['Typerecette_17'] : "";

                                unset($data['CGU']);
                                unset($data['Total']);

                                $pkeys_tresor = array();
                                $pkeys_propre = array();

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        } 
                                        else 
                                        {
                                                $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        }
                                }

                                if (!empty($pkeys_tresor)) 
                                {
                                        $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                        $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                        if (!empty($pkeys_tresor_exist)) 
                                        {
                                                foreach ($pkeys_tresor_exist as $ligne) 
                                                {
                                                        $pkeys_tresor_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }
                                if (!empty($pkeys_propre)) 
                                {
                                        $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                        $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                        if (!empty($pkeys_propre_exist)) 
                                        {
                                                foreach ($pkeys_propre_exist as $ligne) 
                                                {
                                                        $pkeys_propre_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }

                                # Déduction des frais BCC après validation pour les taxes des fonds propres
                                if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes'])) 
                                {
                                        foreach ($taxes as $taxe) 
                                        {
                                                if (isset($taxe->taxeCode)) 
                                                {
                                                        $taxe_code = $taxe->taxeCode; 
                                                        $taxe_amount = $taxe->taxeAmount;

                                                        $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                       if (($_SESSION['userdata']['account_id']) == "36")
                                                                $fbc_propres += $fees_bcc['Valeur'];
                                                        else
                                                                $frais_bcc += $fees_bcc['Valeur'];
                                                }
                                        }
                                }

                                if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                                {
                                        foreach ($taxes as $taxe) 
                                        {
                                                if (isset($taxe->taxeCode)) 
                                                {
                                                        $data['Typerecette_17'] = $taxe->taxeCode;

                                                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                        if($type_comptes['CPI'] == '000000000000000000000000')
                                                        {
                                                                $frais_bcc += $taxe->taxeAmount * 0.002;
                                                        }
                                                }
                                        }
                                }

                                if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                                {
                                        if ($data['Compte_33']!="" || $data['Compte_33'] != '000000000000000000000000')
                                        {
                                                foreach ($taxes as $taxe) 
                                                {
                                                        if (isset($taxe->taxeCode)) 
                                                        {
                                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                                {
                                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                                        $frais_bcc = $amount + $frais_bcc;
                                                                }
                                                        }
                                                }
                                        }

                                }

                                # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                                if ($frais_bcc > 0) 
                                {
                                        $data['frais_bcc'] = $frais_bcc;
                                        
                                        # Comptes à utiliser, selon ce qui est disponible
                                        if (!isset($comptes_fbc)) 
                                        {
                                                $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                        }

                                        $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                        $instruction = current($instruction);
                                        
                                        if (!empty($instruction)) 
                                        {
                                                $instructions[] = $instruction;
                                        }

                                }

                                # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                                if ($fbc_propres > 0) 
                                {
                                        $data['frais_bcc'] = $fbc_propres;
                                        $data['RFPROPD'] = "PROPRES";

                                        $comptes_fbc_propes = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                
                                        $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc_propes, $data, 'DGDA');
                                        $instruction = current($instruction);
                                
                                        if (!empty($instruction)) 
                                                $instructions[] = $instruction;

                                        unset($data['RFPROPD']);
                                }

                                if (isset($data['frais_bcc']))
                                        unset($data['frais_bcc']);

                                $data_tresor = array();
                                $data_propre = array();

                                foreach ($taxes as $taxe) 
                                {
                                        $data['Logirefid_4'] = $logirefid . '-' . $prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Commission_23'] = $commission;
                                        $data['Devise_24'] = $commission_devise;
                                        $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        $data['Status_2'] = '1';

                                        $prefix++;

                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_tresor_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $data_tresor[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);

                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else if (isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $data_propre[] = $data;

                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                }

                                $return = false;

                                if (!empty($data_tresor))
                                {
                                        $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                                }
                                if (!empty($data_propre))
                                {
                                        $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                                }

                                if ($return) 
                                {
                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;

                                                $end_execution = $this->comptabilisationModel->save_instructions($row->Id_0, $data, $instructions, $_POST['Logirefid'], $priority);

                                                unset($instructions);
                                        }

                                        if ($end_execution) 
                                        {
                                                $bl_data['Status_2'] = '2';
                                                $bl_data['Treated_45'] = '2';
                                                $this->integrationModel->update_bulletin($bl_data, $data['Sydonia_44']);
                                        }
                                }
                        }

                        if ($return) 
                        {
                                $data_to_update = array();
                                $data_to_update['Status_2'] = 2;

                                $result = $this->integrationModel->update_batch_bulletin($data_to_update, $_POST['Logirefid']);

                                echo $result;
                        } 
                        else 
                        {
                                if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                {
                                        #Payment exist already
                                        echo 'E500';
                                } 
                                else 
                                {
                                        echo 0;
                                }
                        }
                } 
                elseif ($obj == "save_batch_branchless") 
                {
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();
                        $cbs_instructions_from_branchless=array();
                        $journalistation_instructions=array();
                        $prefix = 1;

                        $end_execution = NULL;

                        $Missmatch['Missmatch_32'] = 0;

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $payments = $this->bulletinsModel->get_bulletins_by_logiredid($_POST['Logirefid']);
                        
                        $i = 0;
                        $j = 1;
                        
                        foreach ($payments as $row) 
                        {
                                $encaissement = $this->dataModel->sydonia_migrate_bl($row->Id_0);

                                $agence_src = $_SESSION['Logiref_guichet'];

                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);

                                $data['Compte_33'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                $amount = $data['Montant_11'];

                                $client = $this->logirefModel->get_clients_by_nif($encaissement->Nif_13);
                                $data['Designation_14'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                $data['Commission_23'] = 0;
                                $data['Devise_24'] = "CDF";
                                $commission = 0;
                                $commission_devise = "CDF";

                                #Save payment de chaque taxe
                                $liste = ("'CPT', 'CPI', 'CSO', 'CTR' ");
                                $agence = $_SESSION['Logiref_guichet'];

                                $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                $instructions = array();

                                $info = $encaissement->Notereference_30;

                                $taxesPaid = $info['taxesPaid'];

                                if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                                {
                                        $taxes = $taxesPaid;
                                } 
                                elseif (is_object($taxesPaid) && $taxesPaid != "") 
                                {
                                        $taxes = array();

                                        $taxes[] = $taxesPaid;
                                }

                                $logirefid = $data['Logirefid_4'];

                                #Serie et numero du bulletin
                                $noteid = isset($data['Typerecette_17']) ? $data['Typerecette_17'] : "";

                                unset($data['CGU']);
                                unset($data['Total']);

                                $pkeys_tresor = array();
                                $pkeys_propre = array();

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        } 
                                        else 
                                        {
                                                $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        }
                                }

                                if (!empty($pkeys_tresor)) 
                                {
                                        $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                        $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                        if (!empty($pkeys_tresor_exist)) 
                                        {
                                                foreach ($pkeys_tresor_exist as $ligne) 
                                                {
                                                        $pkeys_tresor_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }
                                if (!empty($pkeys_propre)) 
                                {
                                        $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                        $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                        if (!empty($pkeys_propre_exist)) 
                                        {
                                                foreach ($pkeys_propre_exist as $ligne) 
                                                {
                                                        $pkeys_propre_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }

                                $data_tresor = array();
                                $data_propre = array();

                                foreach ($taxes as $taxe) 
                                {
                                        $data['Logirefid_4'] = $logirefid . '-' . $prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Commission_23'] = $commission;
                                        $data['Devise_24'] = $commission_devise;
                                        $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        $data['Status_2'] = '1';

                                        $prefix++;

                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_tresor_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $data_tresor[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);

                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else if (isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);
                                                        
                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else 
                                        {
                                                if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $data_propre[] = $data;

                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda_for_branchless_payment($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                }


                                $return = false;

                                if (!empty($data_tresor))
                                {
                                        $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                                }
                                if (!empty($data_propre))
                                {
                                        $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                                }
                                 
                             
                                if ($return) 
                                {
                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                // if($j == 1)
                                                // {
                                                        # Get the fees instruction of the batch payment in remote
                                                                
                                                                // if(empty($instructions_from_branchless))
                                                                // {
                                                                //         $data_to_update = array();

                                                                //         $data_to_update['Agence_20'] = $_SESSION['Logiref_agence'];
                                                                //         $data_to_update['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                                                //         $data_to_update['Mode_19'] = '7';

                                                                //         $logirefid = $_POST['Logirefid'];

                                                                //         $this->comptabilisationModel->save_first_instructions_dgda_from_branchless($instructions_from_branchless, $row->Id_0, $data, $logirefid);
                                                                // }
                                                        
                                                // }

                                                $end_execution = $this->comptabilisationModel->save_instructions($row->Id_0, $data, $instructions, $_POST['Logirefid'], $priority);
                                                
                                                // $j++;
                                        }
                                        
                                        if ($end_execution) 
                                        {
                                                # Verirfy the option is activated in order to save the instructions in log for the SFTP integration
                                                if(isset($this->options['DGDA']['breakdown-accounting-by-sftp-file-integration']))
                                                {
                                                        $instructions = $this->integrationModel->clean_array_special_characters($instructions);
                                                        $return = $this->save("save_cbs_journalisation", $data, $instructions, $row,"branchless"); 
                                                }
                                                unset($instructions);
                                                
                                                $bl_data['Status_2'] = '2';
                                                $this->integrationModel->update_bulletin($bl_data, $data['Sydonia_44']);
                                        }

                                }

                        }

                        //Get the fees instructions
                        $instructions_from_branchless = $this->comptabilisationModel->get_instructions_dgda_by_logirefid($_POST['Logirefid']);
                        if(!empty($instructions_from_branchless))
                        {
                                foreach($instructions_from_branchless as $instruction)
                                {
                                        if($instruction['TypeCompte_29'] != "P")
                                        {
                                                $cbs_instructions_from_branchless[]=array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$instruction['Compte_9'],
                                                        'Libelle_12'=>$instruction['Libelle_12'],
                                                        'Montant_10'=>$instruction['Montant_10'], 
                                                        'Devise_11'=>$instruction['Devise_11'],
                                                        'Compte_13'=>$instruction['Compte_13'],
                                                        'Codetaxe_28'=>$instruction['Codetaxe_28'],
                                                        'TypeCompte_29'=>$instruction['TypeCompte_29']
                                                );
                                        }
                                }
                        }

                        if(!empty($instructions_from_branchless))
                        {
                                $cbs_clean_instructions = $this->integrationModel->clean_array_special_characters($cbs_instructions_from_branchless);
                                $return = $this->save("save_cbs_journalisation", $data, $cbs_clean_instructions, $row,"branchless");

                                $bl_data['Status_2'] = '2';
                                $this->integrationModel->update_bulletin($bl_data, $data['Sydonia_44']);
                                
                                unset($cbs_clean_instructions);
                        }

                        if ($return) 
                        {
                                $data_to_update = array();
                                $data_to_update['Status_2'] = 2;

                                $result = $this->integrationModel->update_batch_bulletin($data_to_update, $_POST['Logirefid']);

                                echo $result;
                        } 
                        else 
                        {
                                if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                {
                                        #Payment exist already
                                        echo 'E500';
                                } 
                                else 
                                {
                                        echo 0;
                                }
                        }
                }
                elseif ($obj == "batch_rbo") 
                {
                        # Save payment
                        # Validate payment form 

                        $error = $this->data("validate_rbobatchpaiments");

                        #If form could not be validate
                        if ($error != '') 
                        {
                                echo $error;
                                die;
                        }
                        # If form is validate successfullly
                        else 
                        {
                                $data = array();
                                $data_id_paiement = array();
                                $prefix = 1;

                                $end_execution = NULL;

                                $Missmatch['Missmatch_32'] = 0;

                                $type_recettes = $this->logirefModel->get_dropdown("type_recette");

                                $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                                $payments = $this->bulletinsModel->get_rbo_declarations_by_customer($_POST['customer']);

                                foreach ($payments as $row) 
                                {
                                        $encaissement = $this->dataModel->sydonia_migrate_bl($row->Id_0);

                                        $agence_src = $_SESSION['Logiref_guichet'];

                                        $object = json_encode($encaissement);
                                        $data = json_decode($object, true);

                                        $case = $this->comptabilisationModel->get_use_case($data);
                                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, "DGDA");

                                        $data['Compte_33'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                        $amount = $data['Montant_11'];

                                        $client = $this->logirefModel->get_clients_by_nif($encaissement->Nif_13);
                                        $data['Designation_14'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                        $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                        $data['Commission_23'] = 0;
                                        $data['Devise_24'] = "CDF";
                                        $commission = 0;
                                        $commission_devise = "CDF";

                                        #SAVE PAYMENT DE CHAQUE TAXE
                                        #Comptes CGU & CPT
                                        $guichet = $_SESSION['Logiref_guichet'];
                                        $compte_cpt = isset($comptes['Rawbank']['CSO'][$data['Devise_12']]) ? $comptes['Rawbank']['CSO'][$data['Devise_12']] : '00000000000000000000000';
                                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';

                                        #Taxes comptes
                                        unset($comptes);

                                        $comptes = array();
                                        $agence_src = $_SESSION['Logiref_guichet'];
                                        $instructions = array();

                                        $comptes = $this->accountModel->get_comptes_recettes_agence_array($agence_src, "'CPI','CPT'");

                                        $info = $encaissement->Notereference_30;

                                        $taxesPaid = $info['taxesPaid'];

                                        if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                                        {
                                                $taxes = $taxesPaid;
                                        } 
                                        elseif (is_object($taxesPaid) && $taxesPaid != "") 
                                        {
                                                $taxes = array();

                                                $taxes[] = $taxesPaid;
                                        }

                                        $logirefid = $data['Logirefid_4'];

                                        #Serie et numero du bulletin
                                        $noteid = isset($data['Typerecette_17']) ? $data['Typerecette_17'] : "";

                                        unset($data['CGU']);
                                        unset($data['Total']);

                                        $pkeys_tresor = array();
                                        $pkeys_propre = array();

                                        foreach ($taxes as $taxe) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                                {
                                                        $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                                } 
                                                else 
                                                {
                                                        $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                                }
                                        }

                                        if (!empty($pkeys_tresor)) 
                                        {
                                                $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                                $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                                if (!empty($pkeys_tresor_exist)) 
                                                {
                                                        foreach ($pkeys_tresor_exist as $ligne) 
                                                        {
                                                                $pkeys_tresor_exist[] = $ligne->Paiementkey_50;
                                                        }
                                                }
                                        }
                                        if (!empty($pkeys_propre)) 
                                        {
                                                $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                                $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                                if (!empty($pkeys_propre_exist)) 
                                                {
                                                        foreach ($pkeys_propre_exist as $ligne) 
                                                        {
                                                                $pkeys_propre_exist[] = $ligne->Paiementkey_50;
                                                        }
                                                }
                                        }

                                        $data_tresor = array();
                                        $data_propre = array();

                                        foreach ($taxes as $taxe) 
                                        {
                                                $data['Logirefid_4'] = $logirefid . '-' . $prefix;
                                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                                $data['Montant_11'] = $taxe->taxeAmount;
                                                $data['Typerecette_17'] = $taxe->taxeCode;
                                                $data['Commission_23'] = $commission;
                                                $data['Devise_24'] = $commission_devise;
                                                $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_44'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                                $data['Status_2'] = '1';

                                                $prefix++;

                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                                {
                                                        if (!in_array($data['Paiementkey_50'], $pkeys_tresor_exist)) 
                                                        {
                                                                $data['Tresor_45'] = '1';
                                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                                $type_rectte = $type_recettes[$taxe->taxeCode];

                                                                $data_tresor[] = $data;
                                                                $instruction = $this->comptabilisationModel->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, $type_rectte);
                                                                $instructions[] = $instruction;
                                                        }
                                                } 
                                                else if (isset($beneficiaires[$taxe->taxeCode])) 
                                                {
                                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                        {
                                                                $data['Tresor_45'] = '0';

                                                                $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                                $data_propre[] = $data;
                                                                $instruction = $this->comptabilisationModel->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                                $instructions[] = $instruction;
                                                        }
                                                } 
                                                else 
                                                {
                                                        if (!in_array($data['Paiementkey_50'], $pkeys_propre_exist)) 
                                                        {
                                                                //$data['Missmatch_46'] = 1;
                                                                $data['Tresor_45'] = '0';
                                                                $data['Beneficaire_15'] = $taxe->taxeCode;

                                                                $data_propre[] = $data;

                                                                $instruction = $this->comptabilisationModel->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "PROPRES");
                                                                $instructions[] = $instruction;
                                                        }
                                                }
                                        }

                                        $return = false;

                                        if (!empty($data_tresor)) {
                                                $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                                        }
                                        if (!empty($data_propre)) {
                                                $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                                        }



                                        if ($return) 
                                        {
                                                if (!empty($instructions)) 
                                                {
                                                        # priority for integrating the counting in cbs
                                                        $priority = 1;
                                                        $end_execution = $this->comptabilisationModel->save_instructions($row->Id_0, $data, $instructions, $logirefid, $priority);
                                                        unset($instructions);
                                                }

                                                if ($end_execution) 
                                                {
                                                        $bl_data['Status_2'] = '2';
                                                        $this->integrationModel->update_bulletin($bl_data, $data['Sydonia_44']);
                                                }
                                        }
                                }

                                if ($return) 
                                {
                                        echo $row->Id_0;
                                } 
                                else 
                                {
                                        if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                        {
                                                #Payment exist already
                                                echo 'E500';
                                        } 
                                        else 
                                        {
                                                echo 0;
                                        }
                                }
                        }
                } 
                elseif ($obj == "batch_instrcutions") 
                {

                        if (!empty($_POST)) {

                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];

                                $lots = implode(',', $_POST['batch']);

                                $response = $this->bulletinsModel->get_declarations_by_ref($lots);

                                $bulletins = implode(',', $response['bulletins']);

                                // Nombre des bulletins
                                $all_paiements = count($response['bulletins']);

                                $declarations_instruction = $this->bulletinsModel->get_declarations_instructions_by_ref($bulletins);

                                // Total des instructions de tous les bulletins
                                $nbr_total_instructions = count($declarations_instruction);

                                // Montant total des tous les bulletins
                                $total_amount = array_sum($response['amounts']);
                                $total_fees = array_sum($response['fees']);
                                $total_tva = $total_fees * 0.16;

                                $total = ($total_amount + $total_fees + $total_tva);

                                if (!empty($declarations_instruction)) 
                                {
                                        $data['Instructions_7'] = json_encode($declarations_instruction);
                                        $data['Paiements_10'] = $all_paiements;
                                        $data['Instructions_11'] = $nbr_total_instructions;
                                        $data['Agence_14'] = $_SESSION['Logiref_guichet'];
                                        $data['Montant_12'] = $total;
                                        $data['Regie_13'] = 'DGDA';
                                        $data['Devise_16'] = 'CDF';

                                        $paiements = array();
                                        $paiements['bls'] = array();
                                        $paiements['declarations'] = $bulletins;
                                        $paiements['DGI'] = array();
                                        $paiements['DGRAD'] = array();

                                        $data['Paiements_17'] = json_encode($paiements);

                                        $pid = $this->offline_model->save_integrations($data, $id);

                                        if ($pid > 0) 
                                        {
                                                echo $pid;
                                                $_SESSION['paiementid'] = $pid;
                                                $_SESSION['datas'] = $_POST;
                                        } 
                                        else 
                                        {
                                                echo '202';
                                        }
                                } 
                                else 
                                {
                                        echo '400';
                                        die;
                                }
                        } 
                        else 
                        {

                        }
                } 
                elseif ($obj == "update_bl_rbo") 
                {
                        $bl = $id;
                        ############################# CALL LOGIREF API TO UPDATE THE PAYMENT ON THE RBO ###################################

                        $bulletin = $this->integrationModel->get_paiement_sydonia($bl);

                        if (!empty($bulletin)) 
                        {
                                $apidata = array();
                                $apidata['regie'] = 'DGDA';
                                $apidata['payment'] = $bulletin;

                                $retour = $this->curlModel->call_logiref_update_payment($apidata);
                        }

                        return $bl;
                } 
                elseif ($obj == "lock_paiement") 
                {
                        $data = array();

                        $data['Lock_46'] = $this->session->userdata['user_id'];
                        $bl_id = $this->integrationModel->update_bulletin($data, $id);

                        if ($bl_id > 0) 
                        {
                                $log_info = $this->integrationModel->get_paiement_sydonia($id);
                                $data = array();
                                $data['Lock_12'] = $this->session->userdata['user_id'];

                                $id = $this->integrationModel->update_log_info($data, $log_info->Id_0);
                        }
                } 
                elseif($obj == "lock_batch_paiement")
                {
                        $data = array();

                                $data['Lock_33'] = $this->session->userdata['user_id'];
                                $bl_id = $this->integrationModel->lock_batch_paiement($data, $id);

                                if($bl_id > 0)
                                {
                                        $log_info = $this->integrationModel->get_log_brancless_by_bl($id);
                                        $data = array();
                                        $data['Lock_12'] = $this->session->userdata['user_id'];

                                        if($log_info!=NULL)
                                        {
                                                $id = $this->integrationModel->update_log_info($data, $log_info->Id_0);
                                        }
                                
                                }
                }
                elseif ($obj == "integration_sftp") 
                {
                        /*
                         * --------------------------------------------
                         * Variable initialization
                         * --------------------------------------------
                         */
                        $data = [];
                        $fileids = [];
                        $offices_data = [];
                        $total_amount_debited = 0;
                        $total_amount_credited = 0;
                        $nbfile = 0;
                        
                        if(isset($_POST['file_line']) && !empty($_POST['file_line']))
                        {
                                
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                                
                                foreach($_POST['file_line'] as $row)
                                {
                                        $file_object = json_decode($row, true);
                                        
                                        $offices_data [] = [
                                            
                                                'office'=> $file_object['office'],
                                                'path'=> '',
                                                'amount_debited'=> $file_object['amount_debited_by_office'],
                                                'amount_credited'=> $file_object['amount_credited_by_office'],
                                                'bankaccount'=> $file_object['bank_account'],
                                                'payment_ids'=> json_encode($file_object['bulletins_ids']),
                                                'nbinstructions'=> $file_object['nb_instructions_by_office'],
                                                'nbulletins'=> $file_object['nb_bulletins_by_office'],
                                                'journalisationid'=>json_encode($file_object['instructions_ids']),
                                                'bulletinids'=>json_encode($file_object['bulletins_ids'])
                                        ];
                                        
                                        $total_amount_debited += $file_object['amount_debited_by_office'];
                                        $total_amount_credited += $file_object['amount_credited_by_office'];
                                        
                                        $nbfile++;
                                }
                                
                                $data['Totalamountdebited_8'] = $total_amount_debited;
                                $data['Totalamountcredited_9'] = $total_amount_credited;
                                $data['Officesdata_10'] = json_encode($offices_data);
                                $data['Nbfiles_7'] = $nbfile;
                                $data['Branch_11'] = $_SESSION['Logiref_guichet'];
                                $data['Type_13'] = 'comptant';
                                
                                # Save id of each file line
                                $id = $this->integrationModel->save_integration_summary($data, NULL);
                                
                                if($id > 0)
                                {
                                        echo $id;
                                }
                                else
                                {
                                        echo 0;
                                }
                        }
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
         */

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) 
        {
                if ($obj == "validate_paiments") 
                {
                        $error = '';
                        if ($_POST['Montant_11'] == '0' || $_POST['Montant_11'] == '')
                                $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                } 
                elseif ($obj == "validate_batchpaiments") 
                {
                        $error = '';
                        if ($_POST['Logirefid'] == '0' || $_POST['Logirefid'] == '')
                                $error = '<div class="alert alert-danger text-white">Le lot ne peut pas &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        return $error;
                } 
                elseif ($obj == "get_transactions_by_message_id") 
                {
                        $messageId = $data;
                        
                        $row = $this->integrationModel->get_ack_by_message_id($messageId);

                        if (!$row || empty($row->TxInfAndSts_14)) {
                            return $this->data("empty_transaction_data");
                        }

                        /**
                         * Décodage du JSON stocké en base
                         */
                        $transactions = json_decode($row->TxInfAndSts_14);

                        if (!is_array($transactions)) {
                            return $this->data("empty_transaction_data");
                        }

                        // ================================
                        // Calculs globaux
                        // ================================
                        $totalAmount = 0;
                        $accepted = 0;
                        $pending  = 0;
                        $rejected = 0;

                        foreach ($transactions as $tx) {

                            $amount = $tx->OrgnlTxRef->Amt->InstdAmt ?? 0;
                            $totalAmount += $amount;

                            switch ($tx->TxSts ?? null) {
                                case 'ACSP':
                                    $accepted++;
                                    break;

                                case 'PDNG':
                                    $pending++;
                                    break;

                                default:
                                    $rejected++;
                                    break;
                            }
                        }

                        return [
                            'transactions' => $transactions,
                            'totalTx'      => count($transactions),
                            'totalAmount'  => $totalAmount,
                            'accepted'     => $accepted,
                            'pending'      => $pending,
                            'rejected'     => $rejected,
                        ];
                }
                elseif ($obj == "empty_transaction_data") 
                {
                        return [
                            'transactions' => [],
                            'totalTx'      => 0,
                            'totalAmount'  => 0,
                            'accepted'     => 0,
                            'pending'      => 0,
                            'rejected'     => 0,
                        ];
                }
                elseif ($obj == "verify_total_matches_tax_sum") 
                {   
                        $data = $_POST;

                        // Récupération du montant total du bulletin
                        $bl_amount_unformated = isset($data['Montant_11']) ? $data['Montant_11'] : 0;
                        $bl_amount = floatval(str_replace([' ', ','], ['', '.'], $bl_amount_unformated));

                        // Récupération des montants des taxes
                        $taxes_amount = $data['taxes_amounts'] ?? [];

                        // Validation des données d'entrée
                        if ($bl_amount > 0 && !empty($taxes_amount)) 
                        {
                                // Convertir tous les montants de taxe en float (au cas où)
                                $taxes_amount = array_map('floatval', $taxes_amount);

                                $sum_taxes = array_sum($taxes_amount);

                                // Tolérance d'arrondi (0.01 pour centimes)
                                //if (abs($bl_amount - $sum_taxes) < 0.01) 
                                if (true) 
                                {   
                                        echo '200';
                                } 
                                else 
                                {
                                        echo '300';
                                }
                        } 
                        else 
                        {
                                echo '402';
                        }
                }
                elseif ($obj == "aggregate_instructions_by_office") 
                {
                        $raw_instructions = $data;
                        
                        $amount_debited_by_office = 0;
                        $amount_credited_by_office = 0;
                        $nb_instructions_by_office = 0;
                        
                        $instructions_by_office = []; 
                        
                        $files_instructions_data = array();
                        
                        if(!empty($raw_instructions))
                        {
                                # aggregate instructions by office
                                foreach($raw_instructions as $row)
                                {
                                        $instructions_by_office[$row->Office_7][] = $row;
                                }
                                
                                $i = 0;
                                
                                foreach($instructions_by_office as $row)
                                {
                                        $file_object = new \stdclass();
                                        
                                        $amount_debited_by_office = $this->integrationModel->sum_instructions_amount_debited_by_office($row);
                                        $amount_credited_by_office = $this->integrationModel->sum_instructions_amount_credited_by_office($row);
                                        $nb_instructions_by_office = $this->integrationModel->sum_nb_instructions_by_office($row);
                                        $nb_bulletins_by_office = $this->integrationModel->sum_nb_bulletins_by_office($row);
                                        $instructions_ids = $this->integrationModel->construct_instructions_id_by_office($row);
                                        $bulletin_ids = $this->integrationModel->construct_bulletins_id_by_office($row);
                                        
                                        $file_object->office = $row[0]->Office_7;
                                        $file_object->amount_debited_by_office = $amount_debited_by_office;
                                        $file_object->amount_credited_by_office = $amount_credited_by_office;
                                        $file_object->bank_account = isset($row[0]->Account_16) ? $row[0]->Account_16 : '00000000000000000000000';
                                        $file_object->nb_instructions_by_office = $nb_instructions_by_office;
                                        $file_object->nb_bulletins_by_office = $nb_bulletins_by_office;
                                        $file_object->instructions_ids = $instructions_ids;
                                        $file_object->bulletins_ids = $bulletin_ids;
                                        
                                        $files_instructions_data[$row[0]->Office_7] = $file_object;
                                }
                                
                                return $files_instructions_data;
                        }
                        else
                        {
                                return [];
                        }
                }
                elseif ($obj == "construct_files_instructions_data") 
                {   
                        $offices_data = [];
                        
                        foreach($data as $row)
                        {
                                $files_instructions_data = new \stdclass();
                                
                                $files_instructions_data->office = $row->office;
                                $files_instructions_data->path = $row->path;
                                $files_instructions_data->amount_debited_by_office = $row->amount_debited;
                                $files_instructions_data->amount_credited_by_office = $row->amount_credited;
                                $files_instructions_data->bank_account = $row->bankaccount;
                                $files_instructions_data->nb_bulletins_by_office = $row->nbulletins;
                                $files_instructions_data->nb_instructions_by_office = $row->nbinstructions;
                                $files_instructions_data->payment_ids = $row->payment_ids;
                                $files_instructions_data->instructions_ids = $row->journalisationid;
                                $files_instructions_data->bulletins_ids = $row->bulletinids;
                                
                                $offices_data[$row->office] = $files_instructions_data;
                        }
                        
                        return $offices_data;
                }
                elseif ($obj == "get_nif") 
                {
                        if(isset($_POST['nif']))
                        {
                                $client = $this->logirefModel->get_clients_by_nif($_POST['nif']);
                                $designation = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                echo $designation;
                        }
                        else
                        {
                                echo '';
                        }
                }
                elseif ($obj == "get_commission") 
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ', '', $cdata['montant']);
                        $montant2 = str_replace(',', '.', $montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->feesModel->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                $com['devise'] = $cdata['devise'];
                        } 
                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if (!empty($com) && $com['com'] != 0) 
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        } 
                        else 
                        {
                                $cdata['commission'] = $cdata['montant'] * 0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        if (isset($_SESSION['Bank_rates'])):
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                        else:
                                $taux['Dollar_4'] = 1;
                        endif;

                        if ($cdata['devise'] == $oDeivise) 
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'];
                        } 
                        else if ($cdata['devise'] == 'USD') 
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission'] * $taux['Dollar_4']);
                        } 
                        else if ($result[1] == 'CDF') 
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission'] / $taux['Dollar_4']);
                        } 
                        else 
                        {
                                $cdata['total'] = 0;
                        }

                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar;
                        exit;
                } 
                elseif ($obj == "get_feesbcc_tax") 
                {
                        $fees_bcc = 0;

                        $montant  = $arg;
                        $montant1 = str_replace(' ', '', $montant);
                        $montant2 = str_replace(',', '.', $montant1);
                        $taxe_amount = $montant2;

                        $recette = $data;
                        $rules = $this->feesModel->get_charges_by_fees_bcc(NULL, NULL, $recette, NULL, NULL, NULL, 'BCC');

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $fees_bcc = $taxe_amount * $rules['Valeur'];
                        } 

                        $ar = array('Valeur' => $fees_bcc);
                        return $ar;
                        exit;

                }
                elseif ($obj == "validate_rbobatchpaiments") 
                {
                        $error = '';
                        if ($_POST['customer'] == '0' || $_POST['customer'] == '')
                                $error = '<div class="alert alert-danger text-white">Le lot ne peut pas &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        return $error;
                } 
                elseif ($obj == "create_file_xml") 
                {
                        /*
                         * --------------------------------------------
                         * Variable initialization
                         * --------------------------------------------
                         */

                        $data_to_save = array();
                        $id = $data;
                        $ids = array();
                        $integrationids = array();
                        $bureau = array();
                        $result = array();
                        $path = '';
                        $request = array();
                        $designations = array();
                        $tax_payer = array();
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $users = $this->mainModel->get_dropdown('users_array');
                        $user = $this->session->userdata['user_id'];
                        $account_id = $this->session->userdata['account_id'];
                        $operateur = $users[$user];

                        $type=$_POST['type_integration'];

                        $integration_summary = $this->integrationModel->get_integration_sftp_summary_by_id($id);
                        $offices_data = json_decode($integration_summary->Officesdata_10, true);
                        
                        foreach($offices_data as $row)
                        {
                                $ref_integration = $this->integrationModel->generate_unique_reference();
                                $request['journalisation_ids'] = $row['journalisationid'];
                                $request['total_amount'] = $row['amount_debited'];
                                $request['debit_account'] = $row['bankaccount'];
                                $request['debit_account_currency'] = 'CDF';
                                $request['type'] = 'comptant';
                                $request['logirefid'] = $ref_integration;
                                $bureau [] = $row['office'];

                                $return = $this->siop->create_xml_request($request);

                                if ($return != 405 && $return != 406) 
                                {
                                        
                                        $xml = $return;

                                        $operateur = ltrim($operateur);
                                        $name = str_replace(' ', '-', $operateur);
                                        $fname = explode('-', $name)[0];

                                        $filename = 'SIOP_LOGIREF' . date('d') . date('m') . $fname . substr(explode('-', $name)[1], 0, 1) . "_" . $ref_integration;
                                        $path = './drive/logiref/' . $account_id . '/' . date('Y-m') . '/integration/siop';

                                        if (is_dir($path) == false) 
                                        {
                                                mkdir($path, 0777, true);
                                        }

                                        $f_dir = $path . '/' . $filename;

                                        // Si le fichier portant ce nom existe.
                                        if (is_file($f_dir) == true) 
                                        {
                                                // On recupère ledernier caractère du nom du fichier.
                                                $f = substr($filename, -1);

                                                // Si le dernier caractère est un numerique.
                                                if (is_numeric($f)) 
                                                {
                                                        // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                                        $f += 1;
                                                        $filename = $filename . $f;
                                                } 
                                                else 
                                                {
                                                        $filename . '1';
                                                }

                                                $path = $path . '/' . $filename;
                                        } 
                                        else 
                                        {
                                                $path = $f_dir;
                                        }


                                        // Charger le contenu XML dans DOMDocument pour le formater.
                                        $xml = str_replace(
                                            ['&deg;', '&eacute;', '&Eacute;', '&agrave;', '&ocirc;', '&ugrave;', '&Egrave;', '&egrave;', '&ecirc;', '&Ecirc;', '&Ocirc;', '&ccedil;', '&Ccedil;', '&icirc;', '&Icirc;', '&amp;', '&lt;'],
                                            ['°', 'e', 'E', 'a', 'o', 'u', 'E', 'e', 'e', 'E', 'O', 'c', 'C', 'i', 'I', '&', ''],
                                            $xml
                                        );
                                        
                                        // À ce stade, on peut parser en toute sécurité
                                        //$xml = $return;
                                        
                                        $dom = new \DOMDocument('1.0', 'UTF-8');
                                        $dom->preserveWhiteSpace = false;
                                        $dom->formatOutput = true;

                                        // 🔴 DÉCODAGE OBLIGATOIRE
                                        $xml = html_entity_decode($xml, ENT_QUOTES | ENT_HTML5, 'UTF-8');

                                        $dom->loadXML($xml, LIBXML_NOBLANKS);

                                        # Ecrire le contenu XML dans le fichier
                                        $bytes = file_put_contents($path, $dom->saveXML(), LOCK_EX);

                                        if($bytes === false)
                                        {
                                                $return = 500;
                                        }
                                        else
                                        {
                                                # Get data to save in the table
                                                $data = $this->integrationModel->get_data_integration_sftp($row, $path, $id, $ref_integration);

                                                # Save the integration sftp by office
                                                $integrationids[$row['office']][] = $this->integrationModel->save_integration_sftp($data, NULL);
                                        }
                                } 
                                else 
                                {
                                        break;
                                }
                        }

                        if (!empty($integrationids)) 
                        {
                                $data_to_update = [];
                                
                                $data_to_update['Status_2'] = 2;
                                $data_to_update['Integrationsftpid_14'] = json_encode($integrationids);
                                $data_to_update['Officespending_17'] = json_encode($bureau);
                                $data_to_update['Type_16'] = $type;
                                
                                $this->integrationModel->save_integration_summary($data_to_update, $id);
                                                        
                                $return = 200;
                        } 
                        else 
                        {
                                $return = 501;
                        }
                        
                        $result['code'] = $return;
                        $result['integrationids'] = $integrationids;
                        $result['bureau'] = $bureau;
                        
                        echo json_encode($result);
                } 
                elseif ($obj == "create_file_sftp") 
                {
                        $agence_src = $_SESSION['Logiref_guichet'];

                        $users = $this->mainModel->get_dropdown('users_array');
                        $user = $this->session->userdata['user_id'];
                        $account_id = $this->session->userdata['account_id'];
                        $operateur = $users[$user];

                        $name = str_replace(' ', '-', $operateur);
                        $fname = explode('-', $name)[0];

                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, 'DGDA');
                        $compte_cgu = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $CGU = explode('-', $compte_cgu);

                        $day = str_replace('-', '', gmdate("d-m-Y"));
                        $carct = array('-', '&');

                        $integrations = $this->offlineModel->get_integration_offline_info($data);

                        $p = json_decode($integrations->Paiements_17);

                        $alldeclataions = $p->bulletins;

                        $tdebit = $integrations->Montant_12;

                        $lines = json_decode($integrations->Instructions_7);
                        $filename = 'VIRMUL_LGIREF' . date('d') . date('m') . $fname . substr(explode('-', $name)[1], 0, 1);
                        $path = './drive/logiref/' . $account_id . '/' . date('Y-m') . '/integration';

                        if (is_dir($path) == false) 
                        {
                                mkdir($path, 0777, true);
                        }

                        $f_dir = $path . '/' . mb_strimwidth($filename, 0, 29, '') . '.txt';

                        // Si le fichier portant ce non existe.
                        if (is_file($f_dir) == true) 
                        {
                                // On recupère ledernier caractère du nom du fichier.
                                $f = substr($filename, -1);

                                // Si le dernier caractère est un numerique.
                                if (is_numeric($f)) 
                                {
                                        // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                        $f += 1;
                                        $filename = $filename . $f;
                                } 
                                else 
                                {
                                        $filename . '1';
                                }

                                $path = $path . '/' . $filename . '.txt';
                        } 
                        else 
                        {
                                $path = $f_dir;
                        }


                        $handle = fopen($path, "w");

                        // Debit guichet unique
                        $code = 1; // 1 digit
                        $refOder = $this->data('ordercode', 5);  // 8 digit aleatoir de A à Z
                        $refOder = str_pad($refOder, 8);  // 8 digit aleatoir de A à Z
                        $datevirment = date('d') . date('m') . substr(date('Y'), -2, 2); // 6 digit
                        $designation = str_pad('LGIREF', 36);  // 36 digit
                        $codebank = '05100'; // 5 digit
                        $codeagence = $CGU[0]; // 5 digit

                        $compte = str_pad($CGU[1], 16); // 11 digit
                        $cle = $CGU[2]; // 2 digit
                        $nbinstuctions = str_pad(count($lines), 6, 0, STR_PAD_LEFT); // 6 digit partie entier et 2 digit partie decimale

                        $amouts = explode('.', $tdebit);
                        $entier = $amouts[0];
                        if (isset($amouts[1]) && $amouts[1] > 0)
                                $decimal = substr($amouts[1], 0, 2);
                        else
                                $decimal = '00';
                        $total_amount = str_pad($entier . $decimal, 20); // 20 digit


                        $motif = str_pad('BULLETINS DU ' . str_replace('-', '', date('d-m-Y')), 30); // 30 digit
                        $filler = str_pad('', 6); // 7digit
                        $devise_code = str_pad('181', 115); // 3 digit


                        $instructions = $code . $refOder . $datevirment . $designation . $codebank . $codeagence . $compte . $cle . $nbinstuctions . $total_amount . $motif . $filler . $devise_code;

                        fwrite($handle, $instructions . "\n");

                        foreach ($lines as $row) 
                        {
                                if ($row->Montant_10 > 0) 
                                {
                                        ############################# Virmul, preparation des donnees ####################################
                                        $compte_source = explode('-', $row->Compte_13);
                                        $agence = isset($compte_source[0]) ? $compte_source[0] : "";
                                        $compte = isset($compte_source[1]) ? $compte_source[1] : "";
                                        $cle = isset($compte_source[2]) ? $compte_source[2] : "";
                                        $montants = explode('.', $row->Montant_10);
                                        $entier = $montants[0];
                                        if (isset($montants[1]) && $montants[1] > 0)
                                                $decimal = substr($montants[1], 0, 2);
                                        else
                                                $decimal = '00';

                                        $amount = $entier . $decimal;
                                        $code = 2;
                                        $refvirement = str_pad($refOder, 12);
                                        $designation = str_pad('BENEFICIAIRE', 36); // 36 digit
                                        $Bank = str_pad('RAWBANK', 24); //24 digit
                                        $codebank = '05100'; // 5 digit
                                        $codeagence = $agence; //  5 digit
                                        $account = str_pad($compte, 16);
                                        $key = str_pad($cle, 2);
                                        // taille du montant 
                                        $taxeamount = str_pad($amount, 20, ' ', STR_PAD_LEFT);
                                        $libelle = str_pad(str_replace(array('/', '&', '-'), ' ', $row->Libelle_12), 30);

                                        $instructions = $code . $refvirement . $designation . $Bank . $codebank . $codeagence . $account . $key . $taxeamount . $libelle;

                                        fwrite($handle, $instructions . "\n");
                                }
                        }

                        fclose($handle);
                        // Ajout du lien du fichier créé dans la table offline

                        $dataOffline['Pathexcel_8'] = $path;
                        $upid = $this->offlineModel->save_integrations($dataOffline, $data);

                        echo $data;
                } 
                elseif ($obj == "tax_others_banks") 
                {
                        $account_list = array();
                        $return = $this->accountModel->get_others_banks_account_by_tax();

                        if (!empty($return)) 
                        {
                                $agence_src = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountModel->get_comptes_array_leveling("'CNP','FBC'", $agence_src, NULL);

                                foreach ($return as $row) 
                                {
                                        $account_list[$row->Recette_13]['CNP'] = isset($comptes['Solidairebank']['CNP'][$data['Devise_12']]) ? $comptes['Solidairebank']['CNP'][$data['Devise_12']] : 00000000000000000000000;
                                        $account_list[$row->Recette_13]['FBC'] = isset($comptes['Solidairebank']['FBC'][$data['Devise_12']]) ? $comptes['Solidairebank']['FBC'][$data['Devise_12']] : 00000000000000000000000;
                                }

                                return $account_list;
                        }
                } 
                elseif ($obj == "additionnal_instructions_for_leveling") 
                {
                        $comptes_nivellement = $param;
                        $comptes_recettes = $data;
                        $data = $arg;
                        $intsructions = array();

                        $compte_src = isset($comptes_recettes[$data['Typerecette_17']]['CDF']) ? $comptes_recettes[$data['Typerecette_17']]['CDF'] : 00000000000000000000000;

                        $intsructions = $this->comptabilisationModel->get_instructions_others_banks($compte_src, $comptes_nivellement, $data);

                        return $intsructions;
                } 
                elseif ($obj == "send_file_bl_batch") 
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                    
                        $request = array();
                        $data_to_update_integration = array();
                        $data_to_update_bulletin = array();
                        $data_to_update_batch = array();
                        $batch_reference = array();
                        $bulletinids = array();
                        $request['path'] = $_POST['path'];
                        $request['integrationid'] = $_POST['integrationid'];
                        $id = $_POST['integrationid'];
                        $bulletinids = array();
                        
                        $return = $this->siop->send_file($request);
                        
                        //$return['code'] = 200;
                        //$return['msg'] = '<div class="alert aSuccess text-white">Bravo, fichier envoy&eacute; avec succ&egrave;s, veuillez cliquer sur télécharger pour visualiser le fichier envoyé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                        if (isset($return['code']) &&  $return['code'] == 200) 
                        {
                                $data_to_update_integration['Status_2'] = 2;
                                $this->integrationModel->save_integration_sftp($data_to_update_integration, $id);

                                $integration = $this->integrationModel->get_integration_sftp_by_id($id);

                                # Get the list of bl integrated in order to change the status 
                                # Of each bulletin in the table logiref_integration_sydonia
                                $ids = json_decode($integration->Paymentid_11, true);
                                $ids = implode(',', $ids);

                                $bulletins = $this->integrationModel->get_bulletins_by_id($ids);

                                if(!empty($bulletins))
                                {
                                        foreach ($bulletins as $row) 
                                        {
                                                $bulletinids[] = $row->Id_0;
                                        }

                                        $data_to_update_bulletin['Status_2'] = 3;

                                        $result = $this->integrationModel->update_bulletin($data_to_update_bulletin, $bulletinids);
                                }
                                
                                # Changing the status of each batch line in the table logiref_integration_sydonia_batchs
                                $batch_reference = $_POST['batch_reference'];
                                $data_to_update_batch['Status_2'] = 3;
                                $this->integrationModel->update_batch_bulletin($data_to_update_batch, $batch_reference);
                        }

                        echo json_encode($return);
                } 
                elseif ($obj == "send_file_integration") 
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        
                        $office = $_POST['office'];
                        $integrationid = $_POST['integration_id'];
                        
                        $integration = $this->integrationModel->get_integrations_sftp_by_treatmentid_and_office($integrationid, $office);
                        
                        $request = [];
                        $data_to_update_integration =[];
                        $data_to_update_bulletin = [];
                        $data_to_update_integration = [];
                        $data_to_update_treatment = [];
                        $data_to_update_journalisation = [];
                        $offices = [];
                        
                        $bulletinids = [];
                        $request['path'] = $integration->Path_16;
                        $request['integrationid'] = $integration->Id_0;
                        $id = $integration->Id_0;
                        $bulletinids = [];

                        //$return = $this->siop->send_file($request);
                        
                        $return['code'] = 200;

                        if(isset($return['code']) &&  $return['code'] == 200) 
                        {
                                $json_journalisationids= json_decode($integration->Journalisationid_13, true);
                                $journalisationids = json_decode($json_journalisationids, true);
                                
                                $data_to_update_journalisation['Status_2'] = 2;
                                $this->integrationModel->update_journalisation_by_ids($data_to_update_journalisation, $journalisationids);
                                
                                $data_to_update_integration['Status_2'] = 2;
                                $this->integrationModel->save_integration_sftp($data_to_update_integration, $id);
                                
                                // Mise à jour du traitement et des bureaux traités
                                $this->data("update_treatment_after_office_sent", $integration->Treatmentid_18, $office);

                                $json_bulletinids = json_decode($integration->Bulletinids_14, true);
                                $bulletinids = json_decode($json_bulletinids, true);

                                $data_to_update_bulletin['Status_2'] = 3;
                                $this->integrationModel->update_bulletin($data_to_update_bulletin, $bulletinids);
                        }

                        echo json_encode($return);
                } 
                elseif($obj == "update_treatment_after_office_sent")
                {
                        $treatmentId = $data;
                        $office = $arg;
                        
                        $data_to_update_treatment = [];

                        // Vérifier si tous les fichiers de ce traitement ont été envoyés
                        $pendingFiles = $this->integrationModel->get_integrations_sftp_on_pending_by_treatmentid($treatmentId);
                        
                        if (empty($pendingFiles)) 
                        {
                                $data_to_update_treatment['Status_2'] = 3; // Tous les fichiers envoyés
                        }

                        // Mettre à jour les bureaux déjà traités
                        $summary = $this->integrationModel->get_summary_by_id($treatmentId);
                        
                        $offices = json_decode($summary->Officestreated_15 ?? '[]', true);
                        
                        if (!is_array($offices)) 
                        {
                                $offices = [];
                        }

                        if (!in_array($office, $offices, true)) 
                        {
                                $offices[] = $office;
                        }

                        $data_to_update_treatment['Officestreated_15'] = json_encode(array_values($offices));

                        // Sauvegarder dans la base
                        $this->integrationModel->save_integration_summary($data_to_update_treatment, $treatmentId);
                } 
                elseif ($obj == "get_view") 
                {
                        $bulletins = $data;
                        $_POST = $arg;
                        $paiementid_next = $_POST['Sydonia_44_next'];
                        $index = (int) $_POST['index'];
                        $iteration = $_POST['iteration'];

                        $paiementid = $_POST['paimentid'];
                        $last_value = end($paiementid);

                        $paiement_treated = $_POST['paiement_treated'];

                        if ($index % 10 == 0) 
                        {
                                if (isset($paiement_treated[$iteration])) 
                                {
                                        $data_to_update = array();
                                        $data_to_update['Treated_45'] = 3;
                                        $this->integrationModel->update_bulletin_batch($data_to_update, $paiement_treated[$iteration]);
                                }
                        }

                        ob_start();
                        ?>
                        <table id="dataTable" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-gray">
                                    <th width="5">#</th>
                                    <th width="10">Ann&eacute;e</th>
                                    <th width="50">Bulletin</th>
                                    <th width="20">Devise</th>
                                    <th width="200">Montant</th>
                                    <th class="text-center">Message</th>
                                    <th width="80" class="text-center">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                        <?php
                        $i = 1;
                         
                        foreach ($bulletins as $obj) 
                        {
                                if ($obj->Treated_45 <= 2) 
                                {
                                        ?>
                                                <tr>
                                                    <td><span><b><?php echo $i; ?></b></span></td>
                                                    <td width=""><?php echo $obj->Year_5; ?></td>
                                                    <td><?php echo $obj->Serie_7 . ' ' . $obj->Number_8; ?></td>
                                                    <td><?php echo 'CDF'; ?></td>
                                                    <td><?php echo number_format($obj->Amount_12, 2, ".", ","); ?></td>
                                                    <?php if (isset($_SESSION['paiement_result'][$obj->Id_0]) && $_SESSION['paiement_result'][$obj->Id_0] === 200) { ?>
                                                        <td class="text-center"><span class='text-green bold'>Bulletin validé avec succès </span></td>
                                                    <?php } elseif(isset($_SESSION['paiement_result'][$obj->Id_0]) && $_SESSION['paiement_result'][$obj->Id_0] !== 200)  { ?>
                                                        <td class="text-center"><span class='text-red bold'>Bulletin validé partiellement </span></td>
                                                    <?php }else{ ?>
                                                        <td class="text-center"><span class='text-yellow bold'>Bulletin en attente de validation</span></td>
                                                    <?php }?>
                                        <?php if ($obj->Id_0 == $paiementid_next) { ?>
                                                        <td class="text-center"><span id="" class=""><img align="middle" height="18px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></span></td>
                                                    <?php } else { ?>
                                                        <?php if (isset($_SESSION['paiement_result'][$obj->Id_0]) && $_SESSION['paiement_result'][$obj->Id_0] == 200) { ?>
                                                            <td class="text-center"><span id="" class="fa fa-fw text-green fa-check-circle f20"></span></td>
                                                        <?php } elseif(isset($_SESSION['paiement_result'][$obj->Id_0]) && $_SESSION['paiement_result'][$obj->Id_0] != 200) { ?>
                                                            <td class="text-center"><span id="" class="fa fa-times-circle text-danger f20"></span></td>
                                                        <?php }else{ ?>
                                                            <td class="text-center"><span id="" class="fa fa-fw text-gray fa-question f20"></span></td>
                                                        <?php } ?>
                                                    <?php } ?>
                                                </tr>
                                        <?php
                                        $i++;
                                }
                        }
                        ?>
                            </tbody>    
                        </table>
                        <script type="text/javascript">
                            $(document).ready(function () {

                                table = $('#dataTable').DataTable();
                            });

                        </script>
                        <?php
                        
                        if ($paiementid_next == $last_value) 
                        {
                                $data_to_update = array();
                                $data_to_update['Status_2'] = 3;

                                $this->integrationModel->save_batch_bulletin($data_to_update, $_POST['batchid']);
                                //$_SESSION['paiement_result'] = array();
                        }
                        
                        $tableHTML = ob_get_clean();
                        return $tableHTML;
                }
        }
}
