<?php

namespace Modules\Branch\Controllers;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\UserModel;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\AccountModel;
use Modules\Branch\Models\ReportsModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\BulletinsModel;
use Modules\Branch\Models\ReportingModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Services\Bulletin\Services\BulletinBatchVerificationService;

class TaxReports extends BaseController {
    /*
     * Presentation:
     * Last update:
     * By Glodi on the 11.10.2023
     * *  *************************************************************************************************************************SECTION 1
     */

        public $menus = array('taux', 'operations_dgda', 'encaissements', 'list', 'reversements', 'reports', 'commissions', 'penalties', 'reporting', 'declarations', 'gudouane', 'ordres', 'nvalidated', 'unsaved', 'validated','validated_plaques', 'transferred', 'penalities', 'rapport', 'report_agence', 'report_clients', 'report_users', 'report_bl', 'pending', 'report_paydgda', 'report_dgrad_dgi', 'report_dgrad', 'alerts', 'prepaids', 'overview_prepaid', 'prepaids_step1', 'reversements', 'report_prepayments', 'prepaidvalidated', 'batchvalidated', 'reverses', 'situations', 'impressions', 'validatepayment','reports_paiements_rbo', 'paiement_integrated', 'isysextract', 'treatments', 'batch_treatments_operator', 'passport','paiements_passports','online-taxes', 'nvalidatedpassport','validatedpassport','passports','nvalidatedpassports','nvalidatedgnk','dgnkvalidated','dgnkreports','nvalidatedimmatric', 'reporting_immatriculation_tresor', 'reporting_immatriculation_propre', 'reporting_immatriculation_tresor_data', 'reporting_immatriculation_propre_data', 'reporting_immatriculation_tresor_export', 'reporting_immatriculation_propre_export', 'immatriculation_paid_unconfirmed', 'immatriculation_regularization_report');

        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'branch';
        public $folder = 'reports';
        public $integrationModel;
        public $logirefModel;
        public $bulletinsModel;
        public $dataModel;
        public $comptabilisationModel;
        public $userModel;
        public $ratesModel;
        public $accountModel;
        public $feesModel;
        public $reportsModel;
        public $prepaymentsModel;
        public $encaissementModel;
        public $stakeholdersModel;
        public $branchModel;
        public $mainModel;
        public $role;
        public $bank;
        public $reportingModel;
        public $options;
        public $functionalities;

        public function __construct() {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                 */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->bulletinsModel = new BulletinsModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->userModel = new UserModel();
                $this->accountModel = new AccountModel();
                $this->ratesModel = new RatesModel();
                $this->feesModel = new FeesModel();
                $this->reportsModel = new ReportsModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();
                $this->reportingModel=new ReportingModel();

                $this->folder = 'reports';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxreports';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['usertype'] = $this->session->userdata["user_type"];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['core_banking'] = $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options'])) 
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                } 
                else 
                {
                        $this->data['options'] = $this->options = array();
                }

                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                 */
   
                if (
                        (isset($this->options['ALL']['client-exchange-rate-override']) && $_SESSION['Logiref_role'] >= 2) ||
                        (!isset($this->options['ALL']['client-exchange-rate-override']) && $_SESSION['Logiref_role'] >= 2)
                ) 
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                } else {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
        }

        public function index() {
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

    /*
     * Manages sidebar menu 
     * Must match de third section of the URL
     * PS: A modifier uniquement si c'est necessaire!!
     * *  *************************************************************************************************************************SECTION 2
     */

        public function set($needle)
        {
                if (in_array($needle, $this->menus))
                {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
         */

        private function provincialTaxPaymentsEnabled(): bool
        {
                $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                return is_array($options)
                        && array_key_exists('provincial_tax_payments', $options['ALL'] ?? []);
        }

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if (in_array($obj, ['reporting_immatriculation_payments_sent', 'reporting_immatriculation_payments_sent_data', 'reporting_immatriculation_payments_sent_export', 'reporting_immatriculation_payments_pending', 'reporting_immatriculation_payments_pending_data', 'reporting_immatriculation_payments_pending_export'], true)) {
                        return $this->display_integrated_immatriculation_payments($obj);
                }

                // Les variantes fixent le périmètre côté serveur, y compris pour Excel.
                $siopReport = '';
                if (preg_match('/^reporting_immatriculation_(tresor|propre)_siop_(sent|pending)(_data|_export)?$/', (string) $obj, $matches)) {
                        $siopReport = $matches[2];
                        $obj = 'reporting_immatriculation_' . $matches[1] . ($matches[3] ?? '');
                }


                if ($obj == "immatriculation_paid_unconfirmed" || $obj == "immatriculation_regularization_report")
                {
                        $isRegularizationReport = $obj == "immatriculation_regularization_report";
                        $statuses = $isRegularizationReport ? [5, 6] : [6, 7];

                        $this->data['payments'] = $this->reportsModel
                                ->get_immatriculation_payments_by_statuses($statuses, 1000);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['reportType'] = $isRegularizationReport ? 'regularization' : 'paid_unconfirmed';
                        $this->data['title'] = $isRegularizationReport
                                ? "Rapport des plaques en régularisation"
                                : "Rapport des plaques d'immatriculation payées et non confirmées";

                        echo view('\Modules\Branch\Views\reports\immatriculation_status_report', $this->data);
                
                        return;
                }

                if ($obj == "reporting_immatriculation_tresor" || $obj == "reporting_immatriculation_propre")
                {
                        $source = ($obj == "reporting_immatriculation_propre") ? 'propre' : 'tresor';
                        $filters = $_GET;
                        if (!isset($filters['start']) || $filters['start'] == '') {
                                $filters['start'] = date('Y-m-d', strtotime('-1 day'));
                        }
                        if (!isset($filters['end']) || $filters['end'] == '') {
                                $filters['end'] = date('Y-m-d');
                        }

                        $this->data['source'] = $source;
                        $this->data['title'] = ($source == 'propre') ? "Rapport détaillé des plaques d'immatriculation propres" : "Rapport détaillé des plaques d'immatriculation Trésor";
                        $this->data['siopReport'] = $siopReport;
                        if ($siopReport !== '') {
                                $reportLabel = $source === 'propre' ? ' propres' : '';
                                $this->data['title'] = "Rapport détaillé des plaques d'immatriculation" . $reportLabel
                                        . ($siopReport === 'sent'
                                                ? ' envoyés vers Amplitude'
                                                : ' non envoyés vers Amplitude');
                        }
                        $reportEndpoint = 'reporting_immatriculation_' . $source
                                . ($siopReport !== '' ? '_siop_' . $siopReport : '');
                        $this->data['pageLength'] = 100;
                        $this->data['start'] = $filters['start'];
                        $this->data['end'] = $filters['end'];
                        $this->data['dataEndpoint'] = base_url($this->module . '/taxreports/display/' . ($reportEndpoint . '_data'));
                        $this->data['exportEndpoint'] = base_url($this->module . '/taxreports/display/' . ($reportEndpoint . '_export'));
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['filters'] = $filters;
                        $this->data['display'] = $obj;

                        echo view('\Modules\Branch\Views\reports\reporting_immatriculation_plaques', $this->data);
                
                        return;
                }

                if ($obj == "reporting_immatriculation_tresor_export" || $obj == "reporting_immatriculation_propre_export")
                {
                        $source = ($obj == "reporting_immatriculation_propre_export") ? 'propre' : 'tresor';
                        $params = $this->request->getGet();
                        $params['siop_report'] = $siopReport;

                        if (!isset($params['filter_start']) || $params['filter_start'] == '') {
                                $params['filter_start'] = isset($params['start']) && $params['start'] != '' ? $params['start'] : date('Y-m-d', strtotime('-1 day'));
                        }
                        if (!isset($params['filter_end']) || $params['filter_end'] == '') {
                                $params['filter_end'] = isset($params['end']) && $params['end'] != '' ? $params['end'] : date('Y-m-d');
                        }
                        $params['filter_start'] = $this->data('normalize_reporting_dgda_date', $params['filter_start'], date('Y-m-d', strtotime('-1 day')));
                        $params['filter_end'] = $this->data('normalize_reporting_dgda_date', $params['filter_end'], date('Y-m-d'));

                        try {
                                $this->data('export_reporting_immatriculation_excel', $source, $params);
                        } catch (\Throwable $e) {
                                log_message('error', 'Reporting immatriculation Excel export error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

                                return $this->response
                                        ->setStatusCode(500)
                                        ->setBody('Le traitement a pris beaucoup de temps, veuillez réessayer.');
                        }
                        exit;
                
                        return;
                }

                if ($obj == "reporting_immatriculation_tresor_data" || $obj == "reporting_immatriculation_propre_data")
                {
                        $source = ($obj == "reporting_immatriculation_propre_data") ? 'propre' : 'tresor';
                        $params = $this->request->getGet();
                        $params['siop_report'] = $siopReport;
                        $draw = isset($params['draw']) ? (int) $params['draw'] : (isset($params['sEcho']) ? (int) $params['sEcho'] : 1);
                        $offset = isset($params['start']) ? (int) $params['start'] : (isset($params['iDisplayStart']) ? (int) $params['iDisplayStart'] : 0);
                        $length = 100;
                        $search = isset($params['search']['value']) ? $params['search']['value'] : (isset($params['sSearch']) ? $params['sSearch'] : '');
                        $orderColumn = isset($params['order'][0]['column']) ? (int) $params['order'][0]['column'] : (isset($params['iSortCol_0']) ? (int) $params['iSortCol_0'] : 0);
                        $orderDir = isset($params['order'][0]['dir']) ? $params['order'][0]['dir'] : (isset($params['sSortDir_0']) ? $params['sSortDir_0'] : 'DESC');

                        if (!isset($params['filter_start']) || $params['filter_start'] == '') {
                                $params['filter_start'] = date('Y-m-d', strtotime('-1 day'));
                        }
                        if (!isset($params['filter_end']) || $params['filter_end'] == '') {
                                $params['filter_end'] = date('Y-m-d');
                        }
                        $params['filter_start'] = $this->data('normalize_reporting_dgda_date', $params['filter_start'], date('Y-m-d', strtotime('-1 day')));
                        $params['filter_end'] = $this->data('normalize_reporting_dgda_date', $params['filter_end'], date('Y-m-d'));

                        try {
                                $guichets = $this->branchModel->get_dropdown("guichets");
                                $report = $this->reportsModel->get_reporting_immatriculation_paiements_datatable($source, $params, $offset, $length, $search, $orderColumn, $orderDir);
                                $rows = [];

                                foreach ($report['rows'] as $row) {
                                        $noteDevise = isset($row->Notedevise_13) ? trim($row->Notedevise_13) : '';
                                        $deviseCredit = isset($row->Devisecredit_15) ? trim($row->Devisecredit_15) : '';
                                        $noteMontant = number_format((float) $row->Notemontant_3, 2, ',', ' ');
                                        $montantCredite = number_format((float) $row->Montantcredite_6, 2, ',', ' ');

                                        $rows[] = [
                                                'date' => $row->Date_1,
                                                'note_numero' => $row->Noteid_12,
                                                'type_transmission' => $row->TypeTransmission_2,
                                                'agence_bancaire' => isset($guichets[$row->Agencebancaire_18]) ? $guichets[$row->Agencebancaire_18] : $row->Agencebancaire_18,
                                                'note_montant' => $noteMontant . ($noteDevise != '' ? ' ' . $noteDevise : ''),
                                                'beneficiaire' => $row->Beneficiaire_4,
                                                'comptecredite' => $row->Comptecredite_5,
                                                'montantcredite' => $montantCredite . ($deviseCredit != '' ? ' ' . $deviseCredit : ''),
                                                'montantdollars' => number_format((float) $row->Montantdollars_14, 2, ',', ' '),
                                                'taux' => $row->Taux_7,
                                                'taxe' => $row->Taxe_8,
                                                'agence' => isset($guichets[$row->Agence_9]) ? $guichets[$row->Agence_9] : $row->Agence_9,
                                                'statut' => $row->Integrationstatus_19,
                                        ];
                                }

                                return $this->response->setJSON([
                                        'draw' => $draw,
                                        'sEcho' => $draw,
                                        'recordsTotal' => $report['recordsTotal'],
                                        'recordsFiltered' => $report['recordsFiltered'],
                                        'iTotalRecords' => $report['recordsTotal'],
                                        'iTotalDisplayRecords' => $report['recordsFiltered'],
                                        'data' => $rows,
                                        'aaData' => $rows,
                                ]);
                        } catch (\Throwable $e) {
                                log_message('error', 'Reporting immatriculation DataTables error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

                                return $this->response->setJSON([
                                        'draw' => $draw,
                                        'sEcho' => $draw,
                                        'recordsTotal' => 0,
                                        'recordsFiltered' => 0,
                                        'iTotalRecords' => 0,
                                        'iTotalDisplayRecords' => 0,
                                        'error' => true,
                                        'message' => 'Le traitement a pris beaucoup de temps, veuillez réessayer.',
                                        'data' => [],
                                        'aaData' => [],
                                ]);
                        }
                
                        return;
                }

                if ($obj == "reversements")
                {
                        $this->data['reversements'] = $this->logirefModel->reversements;

                        echo view('\Modules\Branch\Views\reversement\reversements', $this->data);
                }
                elseif ($obj == "validated")
                {
                        $type = $id;

                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);

                        if ($type == 'dailly')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_validated_paiements($type);
                                $this->data['bulletins'] = $this->integrationModel->get_validated_bls($type);
                                $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls($type);
                        }
                        elseif ($type == 'reversement_dgda')
                        {
                                $this->data['bulletins'] = $this->integrationModel->get_validated_bls($type);
                                $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls($type);

                                $this->data['encaissements'] = [];
                                echo view('\Modules\Branch\Views\reversement\reversement_dgda', $this->data);
                        }
                        elseif ($type == 'reversement_dgi')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_validated_paiements($type);
                                //$this->data['encaissements_immatriculation'] = $this->reportsModel->get_validated_paiements_immatriculation($type);
                                $this->data['bulletins'] = [];
                                $this->data['prepayments'] = [];
                                echo view('\Modules\Branch\Views\reversement\reversement_dgi', $this->data);
                        }
                        elseif ($type == 'reversement_dgrad')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_validated_paiements($type);
                                $this->data['bulletins'] = [];
                                $this->data['prepayments'] = [];
                                echo view('\Modules\Branch\Views\reversement\reversement_dgrad', $this->data);
                        }
                        elseif ($type == 'reversement_dgrk')
                        {
                                $this->data['encaissements_dgrk'] = $this->reportsModel->get_dgrk_reversement_page(0, 100);
                                $this->data['encaissements'] = [];
                                $this->data['bulletins'] = [];
                                $this->data['prepayments'] = [];
                                echo view('\Modules\Branch\Views\reversement\reversement_dgrk', $this->data);
                        }
                        else
                        {
                               
                                $encaissements = $this->reportsModel->get_validated_paiements("dailly");

                                foreach ($encaissements as $key => $row) 
                                {
                                        $infos  = json_decode($row->Notereference_30, true);
                                        $hasDGI = (isset($infos['QuotasDGI']) && $infos['QuotasDGI']==0);
                                        $hasTax = ($row->Typerecette_17 == 'IPRIER' || $row->Typerecette_17 == 'IRPPDR11');

                                        if ($hasTax && $hasDGI) 
                                        {
                                                unset($encaissements[$key]);
                                        }
                                }

                                // Réindexer le tableau si besoin
                                $encaissements = array_values($encaissements);

                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                                $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                                $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                                $this->data['banques'] = $this->bank;
                                $this->data['encaissements'] = $encaissements;
                                $this->data['bulletins'] = $this->integrationModel->get_validated_bls("");
                                
                                $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls("");
                                $this->data['encaissements_dgrk'] = $this->provincialTaxPaymentsEnabled()
                                        ? $this->reportsModel->get_dgrk_reversement_page(0, 100) : [];

                                echo view('\Modules\Branch\Views\reports\validated', $this->data);
                        }
                }
                elseif ($obj == "validated_plaques")
                {
                        $type = $id;

                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->data['banques'] = $this->bank;
                        $this->data['encaissements_immatriculation'] = $this->reportsModel->get_validated_paiements_immatriculation("dailly");

                        echo view('\Modules\Branch\Views\reports\validated_plaques', $this->data);
                }
                elseif($obj == "isysextract")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->data['banques'] = $this->bank;
                        $this->data['encaissements'] = $this->reportsModel->get_isysextract_paiements();
                        echo view('\Modules\Branch\Views\reversement\isysextract', $this->data);
                }
                elseif($obj == "filter_isysextract")
                {
                        #
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->data['banques'] = $this->bank;
                        $this->data['encaissements'] = $this->reportsModel->filter_isysextract_paiements($_POST);
                        echo view('\Modules\Branch\Views\reversement\_filter_isysextract', $this->data);
                }
                elseif ($obj == "prepaidvalidated")
                {
                        $this->data['prepayments'] = $this->prepaymentsModel->get_validated_prepaids();
                        #var_dump($this->data['prepayments']);die;
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);

                        echo view('\Modules\Branch\Views\reports\prepaidvalidated', $this->data);
                }
                elseif ($obj == "batchvalidated")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->data['bulletins'] = $this->integrationModel->get_validated_batch_bl();
                        #var_dump($this->data['bulletins']);die;

                        echo view('\Modules\Branch\Views\reports\batchvalidated', $this->data);
                } 
                elseif ($obj == "filter_isys") 
                {
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->data['isys'] = $this->reportsModel->get_filtered_isys($_POST);

                                echo view('\Modules\Branch\Views\reports\_filter_isys', $this->data);
                        } 
                elseif ($obj == "pending") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_validated_paiements();

                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls();

                        $this->data['bulletins_rbo'] = $this->reportsModel->get_validated_bls_rbo();
                        $this->data['encaissements_rbo'] = $this->reportsModel->get_encaissements_validated_rbo();

                        $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Branch\Views\reports\pending', $this->data);
                }
                elseif ($obj == "transferred")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->integrationModel->get_integrations_isys();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['encaissements_dgrk'] = $this->reportsModel->get_dgrk_transferred_page(0, 10);

                        echo view('\Modules\Branch\Views\reports\transferred', $this->data);

                }
                elseif ($obj == "nvalidated")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements_permis'] = $this->reportsModel->get_nvalidated_paiements_permis();
                        $this->data['encaissements_permis_online'] = $this->reportsModel->get_nvalidated_paiements_permis_online();
                        $this->data['encaissements'] = $this->reportsModel->get_nvalidated_paiements();

                        $this->data['encaissements_batchs'] = $this->reportsModel->get_nvalidated_paiements_batch();

                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls();

                        if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                $this->data['bulletins_batchs'] = $this->reportsModel->get_paiements_batchs();
                                $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_customers_treated();
                                $this->data['commissions'] = $this->prepaymentsModel->get_dropdown("commissions_ref");
                        }
                        else
                        {
                                $this->data['bulletins_batchs'] = [];
                                $this->data['prepayments'] = [];
                                $this->data['commissions'] = [];
                        }

                        $this->data['bulletins_rbo'] = $this->reportsModel->get_paiements_rbo();
                        $this->data['bulletins_batchs_rbo'] = $this->reportsModel->get_paiements_batchs_rbo();
                        $this->data['encaissements_rbo'] = $this->reportsModel->get_payments_rbo();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\nvalidated', $this->data);
                }
                elseif($obj == "nvalidatedgnk")
                {
                        $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                        if (!array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                                echo '<div class="alert aWarning text-white">La fonctionnalité Taxes provinciales n’est pas activée pour cette banque.</div>';
                                return;
                        }
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_unvalidated_paiements_dgnk();
                        $this->data['encaissements_online'] = $this->reportsModel->get_unvalidated_paiements_dgnk_online();
                        $normalizeDgrk = static function ($rows) {
                                foreach ($rows as $row) {
                                        // La vue historique utilise les suffixes communs;
                                        // DGRK possède ses propres colonnes.
                                        $row->Guichet_21 = $row->Guichet_28 ?? '';
                                        $row->Makerid_9 = $row->Makerid_7 ?? 0;
                                        $row->Datevaleur_31 = $row->Datevaleur_23 ?? $row->Date_1 ?? '';
                                        $row->Beneficaire_15 = $row->Beneficaire_10 ?? 'DGRK';
                                        $row->Typerecette_17 = $row->Typerecette_12 ?? '';
                                        $row->Devise_12 = $row->Devise_16 ?? '';
                                        $row->Montant_11 = $row->Montant_15 ?? 0;
                                        $row->Contrevaleur_22 = $row->Contrevaleur_19 ?? $row->Montant_15 ?? 0;
                                        $row->Devise_24 = $row->Devise_18 ?? ($row->Devise_16 ?? '');
                                        $row->Commission_23 = $row->Commission_17 ?? 0;
                                        $row->Agence_20 = $row->Agence_27 ?? '';
                                        $row->Checkerid_10 = $row->Checkerid_8 ?? 0;
                                }
                                return $rows;
                        };
                        $this->data['encaissements'] = $normalizeDgrk($this->data['encaissements']);
                        $this->data['encaissements_online'] = $normalizeDgrk($this->data['encaissements_online']);
                        
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['is_validated'] = false;

                        echo view('\Modules\Branch\Views\reports\nvalidatedgnk', $this->data);
                }
                elseif($obj == "dgnkvalidated")
                {
                        $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                        if (!array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                                echo '<div class="alert aWarning text-white">La fonctionnalité Taxes provinciales n’est pas activée pour cette banque.</div>';
                                return;
                        }
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_validated_paiements_dgnk();
                        $this->data['encaissements_online'] = $this->reportsModel->get_validated_paiements_dgnk_online();
                        foreach ([$this->data['encaissements'], $this->data['encaissements_online']] as $rows) {
                                foreach ($rows as $row) {
                                        $row->Guichet_21 = $row->Guichet_28 ?? '';
                                        $row->Makerid_9 = $row->Makerid_7 ?? 0;
                                        $row->Datevaleur_31 = $row->Datevaleur_23 ?? $row->Date_1 ?? '';
                                        $row->Beneficaire_15 = $row->Beneficaire_10 ?? 'DGRK';
                                        $row->Typerecette_17 = $row->Typerecette_12 ?? '';
                                        $row->Devise_12 = $row->Devise_16 ?? '';
                                        $row->Montant_11 = $row->Montant_15 ?? 0;
                                        $row->Contrevaleur_22 = $row->Contrevaleur_19 ?? $row->Montant_15 ?? 0;
                                        $row->Devise_24 = $row->Devise_18 ?? ($row->Devise_16 ?? '');
                                        $row->Commission_23 = $row->Commission_17 ?? 0;
                                        $row->Agence_20 = $row->Agence_27 ?? '';
                                        $row->Checkerid_10 = $row->Checkerid_8 ?? 0;
                                }
                        }
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['is_validated'] = true;

                        echo view('\Modules\Branch\Views\reports\nvalidatedgnk', $this->data);
                }
                elseif($obj == "dgnkreports")
                {
                        $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                        if (!array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                                echo '<div class="alert aWarning text-white">La fonctionnalité Taxes provinciales n’est pas activée pour cette banque.</div>';
                                return;
                        }
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_dgnkreports();
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['display'] = $obj;
                        foreach ($this->data['encaissements'] as $row) {
                                $row->Guichet_21 = $row->Guichet_28 ?? '';
                                $row->Makerid_9 = $row->Makerid_7 ?? 0;
                                $row->Datevaleur_31 = $row->Datevaleur_23 ?? $row->Date_1 ?? '';
                                $row->Beneficaire_15 = $row->Beneficaire_10 ?? 'DGRK';
                                $row->Typerecette_17 = $row->Typerecette_12 ?? '';
                                $row->Devise_12 = $row->Devise_16 ?? '';
                                $row->Montant_11 = $row->Montant_15 ?? 0;
                                $row->Contrevaleur_22 = $row->Contrevaleur_19 ?? $row->Montant_15 ?? 0;
                                $row->Devise_24 = $row->Devise_18 ?? ($row->Devise_16 ?? '');
                                $row->Commission_23 = $row->Commission_17 ?? 0;
                                $row->Agence_20 = $row->Agence_27 ?? '';
                                $row->Checkerid_10 = $row->Checkerid_8 ?? 0;
                        }

                        echo view('\Modules\Branch\Views\reports\dgnkreports', $this->data);
                }
                elseif ($obj == "report_dgrk")
                {
                        $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                        if (!array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                                echo '<div class="alert aWarning text-white">La fonctionnalité Taxes provinciales n’est pas activée pour cette banque.</div>';
                                return;
                        }
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_dgrk_report(false);
                        $this->data['encaissements_online'] = $this->reportsModel->get_paiements_dgrk_report(true);
                        $this->data['encaissements_from_reporting'] = [];
                        $dgrkServices = $this->logirefModel->get_dropdown('services', 'DGRK', null, true);
                        $this->data['services'] = $dgrkServices['DGRK'] ?? $dgrkServices;
                        $dgrkRecettes = $this->logirefModel->get_dropdown('recettes', 'DGRK');
                        $this->data['recettes'] = $dgrkRecettes['DGRK'] ?? $dgrkRecettes;
                        $this->data['guichets'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['reportTitle'] = 'Paiements DGRK validés';
                        $this->data['display'] = $obj;
                        echo view('\\Modules\\Branch\\Views\\reports\\dgrk_payments', $this->data);
                }
                elseif($obj == "nvalidatedimmatric")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements_immatriculation_agence'] = $this->reportsModel->get_nvalidated_paiements_immatriculation_agence();
                        $this->data['encaissements_immatriculation_enligne'] = $this->reportsModel->get_nvalidated_paiements_immatriculation_enligne();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\nvalidatedimmatric', $this->data);
                }
                elseif ($obj == "unsaved")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['bulletins'] = $this->integrationModel->get_unsaved_bls();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\unsaved', $this->data);
                }
                elseif ($obj == "treatments")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        //$this->data['bulletins'] = $this->integrationModel->get_unsaved_bls();
                        $this->data['bulletins'] =[];
                        $this->data['bulletins_batchs'] = $this->reportsModel->get_current_bl_batch_treatments();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\treatments', $this->data);
                }
                elseif ($obj == "batch_treatments_operator")
                {
                        $this->data['batch_treatments'] = $this->reportsModel->get_current_batch_verification_treatments();
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\batch_treatments_operator', $this->data);
                }
                elseif ($obj == "batch_treatments_operator_live")
                {
                        $batch_treatments = $this->reportsModel->get_current_batch_verification_treatments();

                        return $this->response->setJSON([
                                'code' => 200,
                                'html' => view('\Modules\Branch\Views\reports\_batch_treatments_operator_table', [
                                        'batch_treatments' => $batch_treatments,
                                ]),
                        ]);
                }
                elseif ($obj == "batch_treatments_operator_details")
                {
                        $service = new BulletinBatchVerificationService();
                        $tracking = $service->get_tracking_data((int) $id, (string) ($this->session->userdata['account_id'] ?? ''));

                        if ($tracking === null)
                        {
                                echo '<div class="alert aWarning">Le traitement demandé est introuvable.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        }

                        $this->data['return_url'] = base_url($this->module . '/taxreports/display/batch_treatments_operator');
                        echo view('\Modules\Branch\Views\bulletins\_batch_verification_tracking', array_merge($this->data, $tracking));
                }
                elseif ($obj == "prepaids")
                {
                        $this->data['processed'] = $this->prepaymentsModel->get_all_prepayments_treated();

                        echo view('\Modules\Branch\Views\reports\nvalidated_prepaids', $this->data);
                }
                elseif ($obj == "prepaids_step1")
                {
                        $this->data['step'] = 1;
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Branch\Views\prepaiements\_start', $this->data);
                }
                elseif ($obj == "list")
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown('agences');
                        $this->data['taux'] = $this->ratesModel->get_taux();
                        $cumules = $this->dataModel->get_rates_by_day();
                        $cumulous = $this->dataModel->get_month_of_rates();

                        $this->data['chart'] = $this->dataModel->get_rates_of_last_days($cumules, $cumulous);
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\rates\taux', $this->data);
                } 
                elseif ($obj == "paiement_tresor") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);

                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        //$this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['beneficiaires'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor_gu();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_tresor_gu();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\paiement_tresor', $this->data);
                } 
                elseif ($obj == "paiement_propre") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_propres_gu();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\paiement_propre', $this->data);
                } 
                elseif ($obj == "fond_propre") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reportsModel->get_fond_propres();
                        $this->data['encaissements_immatriculation'] = $this->reportsModel->get_fond_propres_immatriculation();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_fond_propres();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\fond_propre', $this->data);
                } 
                elseif ($obj == "dgi_guichet_unique") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reportsModel->get_report_paiements_dgi_iprier();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\dgi_guichet_unique', $this->data);
                } 
                elseif ($obj == "filter_gu") 
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        if ($status == 'tresor')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor_gu();
                                $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_tresor_gu();
                        } 
                        elseif ($status == 'propre') 
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        } 
                        else 
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_fond_tresor();
                        }

                        echo view('\Modules\Branch\Views\reports\filter_gu', $this->data);
                } 
                elseif ($obj == "filterresult") 
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['display'] = $obj;

                        if ($status == 'tresor') {
                                $this->data['encaissements'] = $encaissements = $this->reportsModel->get_paiements_dgi();

                                $this->data['encaissements_immatriculation'] = $encaissements = $this->reportsModel->get_paiements_dgi_immatriculation();


                                $this->data['encaissements_from_reporting'] = $encaissements = $this->reportingModel->get_paiements_dgi();
                        }
                        elseif ($status == 'tresor_dgi_gu') {
                                $this->data['encaissements'] = $encaissements = $this->reportsModel->get_paiements_tresor_dgi_gu($_POST);
                                $this->data['encaissements_from_reporting'] = $encaissements = $this->reportingModel->get_paiements_tresor_dgi_gu($_POST);
                        }
                        elseif ($status == 'tresor_dgrad') {
                                $this->data['encaissements'] = $encaissements = $this->reportsModel->get_paiements_dgrad();
                                $this->data['encaissements_from_reporting'] = $encaissements = $this->reportingModel->get_paiements_dgrad();
                        }
                        elseif ($status == 'propre')
                        {
                                $this->data['encaissements'] = $encaissements = $this->reportsModel->get_fond_propres();
                                $this->data['encaissements_immatriculation'] = $encaissements = $this->reportsModel->get_fond_propres_immatriculation();

                                $this->data['encaissements_from_reporting'] = $encaissements = $this->reportingModel->get_fond_propres($_POST);
                        }
                        else
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_fond_tresor();
                                $this->data['encaissements_from_reporting'] = $encaissements = $this->reportingModel->get_fond_tresor($_POST);
                        }

                        echo view('\Modules\Branch\Views\reports\filterresult', $this->data);
                } 
                elseif ($obj == "filterresult_dgda")
                {
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->data['bulletins_from_reporting'] = $this->reportingModel->get_reports_bls();
                        $data['datas'] = $this->data['bulletins'];
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\filterresult_dgda', $this->data);
                } 
                elseif ($obj == "filterresult_dgrad") 
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_dgrad();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_dgrad();
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['display'] = $obj;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\filterresult_dgrad', $this->data);
                } 
                elseif ($obj == "pay_prepayment") 
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['prepaids'] = $this->prepaymentsModel->get_prepayments_customers_validated();

                        echo view('\Modules\Branch\Views\reports\pay_prepayment', $this->data);
                } 
                elseif ($obj == "report_prepayments") 
                {
                        $data = $_GET;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['prepaids'] = $this->prepaymentsModel->get_prepayments_customers_validated();
                        $this->data['prepaids_from_reporting'] = $this->reportingModel->get_prepayments_customers_validated();
                        #$this->data['prepayments '] = $this->prepaymentsModel->get_prepayments_validated_by_reference($data);
                        //$this->data['instructions'] = $this->integrationModel->get_instructions_prepayments();

                        echo view('\Modules\Branch\Views\reports\report_prepayments', $this->data);
                } 
                elseif ($obj == '_bulletins') 
                {
                        $data = $_GET;

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_validated_by_reference($data);
                        #echo '<pre>'; var_dump($this->data['prepayments']);die;
                        echo view('\Modules\Branch\Views\reports\_report_prepaids_detail', $this->data);
                } 
                elseif ($obj == "ordres") 
                {
                        $bank = $this->session->userdata['account_id'];
                        if ($id != "")
                                $this->data['title'] = "Nouveaux odres des paiements";
                        else
                                $this->data['title'] = "Tous les odres des paiements";
                        $this->data['ordres'] = $this->encaissementModel->get_ordres('bank', $bank, $id);
                        $this->data['from'] = $id;
                        $this->data['status'] = $this->encaissementModel->order_status;
                        $this->data['OrderColor'] = $this->encaissementModel->color_orders;

                        echo view('\Modules\Branch\Views\reports\ordres', $this->data);
                } 
                elseif ($obj == "prepayments") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_treated();
                        echo view('\Modules\Branch\Views\prepayments\prepayments', $this->data);
                } 
                elseif ($obj == "declarationslist") 
                {
                        $this->data['messages'] = $this->integrationModel->declaration_ackmessages;

                        $this->data['status'] = $this->integrationModel->prepayments_status;
                        $this->data['color'] = $this->integrationModel->prepayments_status_color;
                        $this->data['declarations'] = $this->integrationModel->get_douane_declarations();

                        echo view('\Modules\Branch\Views\reports\declarations', $this->data);
                } 
                elseif ($obj == "reports") 
                {
                       
                        $this->data['reports'] = $this->logirefModel->reports;
                        echo view('\Modules\Branch\Views\reports\reports', $this->data);
                } 
                elseif ($obj == "rapport") 
                {
                       
                        if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true)):
                                $this->data['reportspay'] = $this->logirefModel->reportspay;
                                echo view('\Modules\Branch\Views\reports\_validateur_rapport', $this->data);

                        else:
                                echo view('\Modules\Branch\Views\reports\_' . $obj, $this->data);

                        endif;
                } 
                elseif ($obj == "situations") 
                {
                        $this->data['situations'] = $this->logirefModel->situations;
                        echo view('\Modules\Branch\Views\reports\situations', $this->data);
                } 
                elseif ($obj == "impressions") 
                {
                        $this->data['impressions'] = $this->logirefModel->impressions;
                        echo view('\Modules\Branch\Views\reports\impressions', $this->data);
                } 
                elseif ($obj == "validatepayment") 
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        
                        if ($_SESSION['Logiref_role'] == 5):
                                $this->data['encaissements'] = $this->reportsModel->get_validated_payments();
                        else:
                                $this->data['encaissements'] = $this->reportsModel->get_validated_payments("dailly");
                        endif;

                        $this->data['encaissements_batch'] = $this->reportsModel->get_validated_paiements_batch();

                        // if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                        // {
                                $this->data['bulletins'] =  $this->integrationModel->get_validated_bulletins();
                        // }
                        
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        if ($arg == "filter"):
                                echo view('\Modules\Branch\Views\reports\_filter_validatepayment', $this->data);
                        else:
                                echo view('\Modules\Branch\Views\reports\validatepayment', $this->data);
                        endif;

                } 
                elseif ($obj == "quittancepaid") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\quittancepaid', $this->data);
                } 
                elseif ($obj == "report_paydgda") 
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->data['bulletins_from_reporting'] = $this->reportingModel->get_reports_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['display'] = $obj;

                        echo view('\Modules\Branch\Views\reports\report_paydgda', $this->data);
                }
                elseif ($obj == "report_deletedgda") 
                {
                        $status = $id;
                        $this->data['devises']   = $this->logirefModel->devises;
                        $this->data['offices']   = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['bulletins'] = $this->integrationModel->get_reports_deleted_bls();
                        $this->data['guichets']  = $this->branchModel->get_dropdown("guichets");
                        $this->data['services']  = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['users']     = $this->mainModel->get_dropdown('users_array');
                        $this->data['display']   = $obj;

                        if ($arg != NULL):
                                echo view('\Modules\Branch\Views\reports\_filter_deletedgda', $this->data);
                        else:
                                echo view('\Modules\Branch\Views\reports\report_deletedgda', $this->data);
                        endif;
                }
                elseif ($obj == "filter_deletedgda")
                {
                        $this->data['devises']   = $this->logirefModel->devises;
                        $this->data['offices']   = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['bulletins'] = $this->integrationModel->get_reports_deleted_bls();
                        $this->data['guichets']  = $this->branchModel->get_dropdown("guichets");
                        $this->data['services']  = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['users']     = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_filter_deletedgda', $this->data);
                }
                elseif ($obj == "report_dgi")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_dgi();
                        $this->data['encaissements_immatriculation'] = $this->reportsModel->get_paiements_dgi_immatriculation();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_dgi();
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['display'] = $obj;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\report_dgi', $this->data);
                }
                elseif ($obj == "report_dgrad")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_dgrad();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_dgrad();
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['display'] = $obj;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\report_dgrad', $this->data);
                } 
                elseif ($obj == "taxe_gardeinnage") 
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_taxegardiennage_dgrad();

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        #var_dump($this->data['encaissements']);die;

                        echo view('\Modules\Branch\Views\reports\taxe_gardeinnage', $this->data);
                } 
                elseif ($obj == "filter_taxegardiennage") 
                {
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_filter_taxegardiennage_dgrad($_POST);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        echo view('\Modules\Branch\Views\reports\_filter_taxegardiennage', $this->data);
                } 
                elseif ($obj == "penalities") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\penalities', $this->data);
                }
                elseif ($obj == "filter_penalites") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);

                        $this->data['encaissements'] = $this->reportsModel->get_penalities_filter($_POST);
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_filter_penalites', $this->data);
                } 
                elseif ($obj == "reverses") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('transferred');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\reverses', $this->data);
                } 
                elseif ($obj == "filter_reverse") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);

                        $this->data['encaissements'] = $this->reportsModel->get_reverse_filter($_POST);
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                } 
                elseif ($obj == "report_penalites") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\report_penalites', $this->data);
                } 
                elseif ($obj == "dropdowns") 
                {
                        $recettes = $this->logirefModel->get_dropdown('recettes', $id);

                        if (isset($recettes[$id])) 
                        {
                                echo form_dropdown('Typerecette_17', $recettes[$id], "", 'class="form-control"   id="recette" ');
                        } 
                        else
                        {
                                echo form_dropdown('Typerecette_17', [], "", 'class="form-control"   id="recette" ');
                        }
                } 
                elseif ($obj == "commissions") 
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['regles'] = $this->feesModel->get_regles("rgle");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");

                        echo view('\Modules\Branch\Views\reports\commissions', $this->data);
                }
                elseif ($obj == "commissions_filter")
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $commissions = $this->data['commissions'] = $this->reportsModel->get_commission_filter($_POST);
                        $_SESSION['commissions'] = $this->data['commissions'];
                        $data = array();
                        $this->data['regles'] = $this->feesModel->get_regles("rgle");

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");

                        echo view('\Modules\Branch\Views\reports\_commissions_filter', $this->data);
                }
                elseif ($obj == "alerts")
                {
                        $this->data['alerts'] = $this->integrationModel->get_logs_branchless();
                        echo view('\Modules\Branch\Views\reports\alerts', $this->data);
                }
                elseif ($obj == "report_agence")
                {
                        $this->data['agence'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchModel->get_branches();
                        $data = array();

                        foreach ($this->data['agences'] as $row) 
                        {
                                $data[$row->Id_0] = $this->encaissementModel->get_paiements_stats("guichet", $row->Id_0);
                                #var_dump($data[$row->Id_0]);die;
                        }
                        $this->data['data'] = $data;
                        $this->session->agences = $this->data['agences'];
                        $this->session->data = $data;
                        echo view('\Modules\Branch\Views\reports\report_agence', $this->data);
                } 
                elseif ($obj == "report_comptes") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['agences'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountModel->get_agence_accounts();

                        echo view('\Modules\Branch\Views\reports\report_comptes', $this->data);
                }
                elseif ($obj == "report_regles") 
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['regies'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->feesModel->get_agence_regles();

                        echo view('\Modules\Branch\Views\reports\report_regles', $this->data);
                } 
                elseif ($obj == "report_commissions")
                {
                        ini_set('max_input_vars', '3000');

                        $this->data['paiement'] = $this->encaissementModel->get_paiements();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['tva'] = $this->tva;

                        echo view('\Modules\Branch\Views\reports\report_commissions', $this->data);
                } 
                elseif ($obj == "agence_filter") 
                {
                        $this->data['agence'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchModel->get_branches();
                        $data = array();

                        if (isset($_POST['agence']) && $_POST['agence'] != "") 
                        {
                                $this->data['agences'] = $this->branchModel->get_branches($_POST['agence']);
                                $return = $this->encaissementModel->get_paiements_stats("guichet_filter", $_POST['agence']);
                                if (empty($return)) 
                                {
                                        $data = $return;
                                        $_SESSION['return_id'] = $_POST['agence'];
                                        $this->data['agences'] = [];
                                } 
                                else 
                                {
                                        $return['id_agence'] = $_POST['agence'];

                                        $_SESSION['return'] = $return;

                                        $data[$_POST['agence']] = $return;
                                }
                        } 
                        else 
                        {
                                foreach ($this->data['agences'] as $row) {
                                        $return = $this->encaissementModel->get_paiements_stats("guichet_filter", $row->Id_0);
                                        if (empty($return)) {
                                                $data = $return;
                                        } else {
                                                $data[$row->Id_0] = $return;
                                        }
                                }
                        }
                        $this->data['data'] = $data;
                        if (empty($data)) 
                        {
                                $this->data['agences'] = array();
                        }
                        $this->session->agences = $this->data['agences'];
                        $this->session->data = $this->data['data'];
                        echo view('\Modules\Branch\Views\reports\_agence_filter', $this->data);
                } 
                elseif ($obj == "regles_filter") 
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, TRUE);
                        $this->data['regies'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->feesModel->get_agence_regles_filtered($_POST);

                        echo view('\Modules\Branch\Views\reports\_regles_filter', $this->data);
                } 
                elseif ($obj == "report_clients") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->userModel->get_dropdown('operators', $users);
                        $this->session->encaissements = $this->data['encaissements'];
                        $this->session->bulletins = $this->data['bulletins'];
                        $this->session->users = $this->data['users'];
                        $this->session->beneficiaires = $this->data['beneficiaires'];

                        echo view('\Modules\Branch\Views\reports\report_clients', $this->data);
                } 
                elseif ($obj == "client_filter") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_filterd_paiements("virement", $_POST);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->session->encaissements = $this->data['encaissements'];
                        $this->session->bulletins = $this->data['bulletins'];
                        $this->session->users = $this->data['users'];
                        $this->session->beneficiaires = $this->data['beneficiaires'];

                        echo view('\Modules\Branch\Views\reports\_client_filter', $this->data);
                } 
                elseif ($obj == "report_users") 
                {
                        $this->data['statut'] = $this->userModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        #$this->data['members'] = $this->data("get_users");
                        $this->data['statutColor'] = $this->userModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        $this->data['agences'] = $this->branchModel->get_branches();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, TRUE);
                        $this->data['roles'] = $this->userModel->role;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['members'] = $this->data("get_users");
                        $this->session->roles = $this->data['roles'];

                        $this->session->members = $this->data['members'];

                        echo view('\Modules\Branch\Views\reports\_report_users', $this->data);
                } 
                elseif ($obj == "user_filter") 
                {
                        $this->data['statut'] = $this->userModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        $this->data['statutColor'] = $this->userModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();

                        if (isset($_POST['agence']) && $_POST['agence'] != "") 
                        {
                                $this->data['members'] = $this->data("get_users", $_POST['agence']);
                        } 
                        else 
                        {
                                $this->data['members'] = $this->data("get_users");
                        }

                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);

                        $this->data['roles'] = $this->userModel->role;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->session->roles = $this->data['roles'];
                        $this->session->members = $this->data['members'];
                        echo view('\Modules\Branch\Views\reports\_user_filter', $this->data);
                } 
                elseif ($obj == "account_filter") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['comptes'] = $this->accountModel->get_filtered_accounts($_POST);
                        $data['datas'] = $this->data['comptes'];

                        echo view('\Modules\Branch\Views\reports\_account_filter', $this->data);
                } 
                elseif ($obj == "report_bl") 
                {
                        $this->data['bulletins'] = $this->integrationModel->get_bulletins();
                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->session->bulletins = $this->data['bulletins'];
                        $this->session->users = $this->data['users'];
                        $this->session->agences = $this->data['agences'];
                        echo view('\Modules\Branch\Views\reports\_report_bl', $this->data);
                } 
                elseif ($obj == "bl_filter") 
                {
                        $this->data['bulletins'] = $this->integrationModel->get_bulletins($_POST);
                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->session->bulletins = $this->data['bulletins'];
                        $this->session->agences = $this->data['agences'];
                        $this->session->users = $this->data['users'];
                        echo view('\Modules\Branch\Views\reports\_bl_filter', $this->data);
                }
                elseif ($obj == "paiements_gu") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $tresor = $this->reportsModel->get_reports_gu_paiements_propres();
                        $propres = $this->reportsModel->get_reports_gu_paiements_tresor();

                        $payments = array_merge($tresor, $propres);

                        $bulletins = array();

                        foreach ($payments as $line):
                                $bl = trim(substr($line->Noteid_26, 4));
                                $bulletins[$bl][] = $line;
                        endforeach;

                        $this->data['bulletins'] = $bulletins;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\paiements_gu', $this->data);
                } 
                elseif ($obj == "filter_paiements_gu") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_filter_gu_paiements($_POST);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_paiements_gu', $this->data);
                } 
                elseif ($obj == "filter_gu_tresor") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $encaissements = $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor_gu();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_tresor_gu();
                        $_SESSION['encaissements'] = $encaissements;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_paiements_tresor_gu', $this->data);
                } 
                elseif ($obj == "filter_gu_prpores") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        $encaissements = $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        $this->data['encaissements_from_reporting'] = $this->reportingModel->get_paiements_propres_gu();
                        $_SESSION['encaissements'] = $encaissements;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_paiements_propres_gu', $this->data);
                } 
                elseif ($obj == "gu_bulletin")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');

                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns_dgda($id);
                        if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['bulletin'] = $this->integrationModel->get_paiement_sydonia($id);
                        $this->data['encaissementBl'] = $this->dataModel->sydonia_migrate_bl($id);

                        echo view('\Modules\Branch\Views\reports\gu_bulletin', $this->data);
                } 
                elseif ($obj == "situation_dgda") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d'); //$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements = $this->integrationModel->get_all_instructions_dgda($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $this->data['comptes'] = $this->accountModel->get_agence_comptes_array($agence, "'CGU','CFB','CSO','TVA'");
                        $this->data['comptes_dgda'] = $this->accountModel->get_dropdown("comptes", "'CGU','CSO'", $agence);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        $bank= ucfirst(str_replace('@', '', $this->bank));
                        
                        $this->data['bank']=$bank;
                        
                        echo view('\Modules\Branch\Views\reports\situation_dgda', $this->data);
                } 
                elseif ($obj == "situation_dgi") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d'); //$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements = $this->integrationModel->get_all_instructions_dgi($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accountModel->get_agence_comptes_array($agence, "'CPT','CFB','CSO','TVA'");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $bank= ucfirst(str_replace('@', '', $this->bank));
                        
                        $this->data['bank']=$bank;
                        //                    var_dump($this->data['bank']);die;
                        echo view('\Modules\Branch\Views\reports\situation_dgi', $this->data);
                } 
                elseif ($obj == "situation_dgrad") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d'); //$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements = $this->integrationModel->get_all_instructions_dgrad($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accountModel->get_agence_comptes_array($agence, "'CPT','CFB','CSO','TVA'");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $bank= ucfirst(str_replace('@', '', $this->bank));
                        
                        $this->data['bank']=$bank;
                        
                        
                        echo view('\Modules\Branch\Views\reports\situation_dgrad', $this->data);
                } 
                elseif ($obj == "failed_transactions") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d'); //$day = '2021-04-03';
                        //$day = '2021-05-15';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements = $this->integrationModel->get_failed_instructions_dgda($day);
                        $this->data['comptes'] = $this->accountModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'", $agence);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        echo view('\Modules\Branch\Views\reports\failed_transactions', $this->data);
                } 
                elseif ($obj == "unknown_status_transactions") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements = $this->integrationModel->get_unknown_status_instructions_dgda($day);
                        //$this->data['events'] = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $this->data['comptes'] = $this->accountModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'", $agence);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        echo view('\Modules\Branch\Views\reports\unknown_status_transactions', $this->data);
                } 
                elseif ($obj == "regularisations") 
                {
                        $day = gmdate('Y-m-d');
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['regularisations'] = $this->integrationModel->get_regularisations($day);

                        echo view('\Modules\Branch\Views\reports\regularisations', $this->data);
                } 
                elseif ($obj == "rbo_treat") 
                {
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/' . $obj, $this->data);

                        echo view('\Modules\Branch\Views\reports\_filter_isys', $this->data);
                }
                elseif ($obj == "operations_dgda")
                {
                        $this->data['bulletins'] = $this->integrationModel->get_initiated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\\' .$obj, $this->data);
                }
                elseif($obj == "paiement_integrated")
                {
                        $this->data['integrations'] = $this->integrationModel->get_integrations_sftp();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\payment_integrated', $this->data);
                }
                #################################################   Branchless payments treatment  #################################################
                #################################################                                  #################################################
                elseif ($obj == "paiements_rbo") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_current_nvalidated_paiements_rbo();
                        $this->data['bulletins'] = $this->reportsModel->get_current_unvalidated_rbo();
                        $this->data['prepayments'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\paiements_rbo', $this->data);
                } 
                elseif ($obj == "rbo_comptant") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['bulletins'] = $this->reportsModel->get_log_branchless_retrieves();

                        echo view('\Modules\Branch\Views\reports\rbo_comptant', $this->data);
                }
                elseif ($obj == "rbo_verification") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_nvalidated_paiements_rbo();
                        $this->data['bulletins'] = array(); //$this->integrationModel->get_unvalidated_bls();
                        $this->data['prepayments'] = array(); //$this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\rbo_verification', $this->data);
                } 
                elseif ($obj == "rbo_rejected") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_rbo_rejected();
                        $this->data['bulletins'] = array(); //$this->integrationModel->get_unvalidated_bls();
                        $this->data['prepayments'] = array(); //$this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\rbo_rejected', $this->data);
                } 
                elseif ($obj == "others_banks_taxes") 
                {
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $recette = $this->logirefModel->get_dropdown('recettesBl', 'DGDA');

                        $this->data['recettes'] = $recette;

                        $comptes = $this->accountModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                        $beneficiaries = $this->accountModel->get_dropdown("beneficiary_tax_others_banks");
                        $instructions = $this->comptabilisationModel->get_instructions_others_taxes();

                        $_SESSION['taxes_others_banks'] = $instructions;

                        $taxes = [];

                        foreach ($instructions as $row) {
                                $taxes[$row->Codetaxe_28][] = $row;
                        }

                        $this->data['taxes'] = $taxes;
                        $this->data['beneficiaries'] = $beneficiaries;
                        $this->data['comptes'] = $comptes;

                        echo view('\Modules\Branch\Views\reports\others_banks_taxes', $this->data);
                } 
                elseif ($obj == "filter_others_taxes") 
                {
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $recette = $this->logirefModel->get_dropdown('recettesBl', 'DGDA');
                        $this->data['recettes'] = $recette;

                        $comptes = $this->accountModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                        $beneficiaries = $this->accountModel->get_dropdown("beneficiary_tax_others_banks");

                        $instructions = $this->comptabilisationModel->get_filtre_others();

                        $_SESSION['taxes_others_banks'] = $instructions;

                        $taxes = [];

                        foreach ($instructions as $row) {
                                $taxes[$row->Codetaxe_28][] = $row;
                        }

                        $this->data['taxes'] = $taxes;
                        $this->data['beneficiaries'] = $beneficiaries;
                        $this->data['comptes'] = $comptes;

                        echo view('\Modules\Branch\Views\reports\search_others_taxes', $this->data);
                }
                elseif($obj=="reports_paiements_rbo")
                {
                        $this->data['bulletins'] = $this->reportsModel->get_paiements_rbo();

                        $this->data['prepayments'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\report_rbo', $this->data);
                }
                elseif($obj == "nvalidatedpassports")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_nvalidated_paiements_passports();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\nvalidatedpassports', $this->data);
                }
                elseif($obj == "validatedpassport")
                {
                       
                        
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_validated_paiements_passports();
                        //$this->data['bulletins'] = $this->integration_model->get_validated_bls();
                        //$this->data['prepayments'] = $this->prepayments_model->get_validated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\validatedpassport', $this->data);
                }
                elseif($obj == "passport")
                {
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements_agence'] = $this->reportsModel->get_paiements_passport_dgrad();
                        $this->data['encaissements_online'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        $this->data['display'] = $obj;

                        echo view('\Modules\Branch\Views\reports\\' . $obj, $this->data);

                }
                elseif($obj == "paiements_passports")
                {
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements_agence'] = $this->reportsModel->get_paiements_passport_dgrad();
                        $this->data['encaissements_online'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        $this->data['display'] = $obj;

                        echo view('\Modules\Branch\Views\reports\_paiements_passports', $this->data);
                }
                elseif($obj == "filterresult_passports")
                {
			$this->data['modes'] = $this->logirefModel->modes;

                        $this->data['encaissements'] = $this->reportsModel->get_paiements_filter_passport_dgrad($id);
                        
			$_SESSION['encaissements'] = $this->data['encaissements'];
                        $data = array();

                        $this->data['display'] = $obj;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        echo view('\Modules\Branch\Views\reports\_filter_passport', $this->data);
                }

		elseif($obj == "passports")
                {
                        echo view('\Modules\Branch\Views\reports\_passports', $this->data);
                }
                elseif($obj == "passport_agence")
                {
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad();
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        $this->data['display'] = "passports";

                        echo view('\Modules\Branch\Views\reports\_passport_agence', $this->data);
                }
                elseif($obj == "filter_passport_agence")
                {
                        
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad();
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['display'] = "passports";

                        echo view('\Modules\Branch\Views\reports\_filter_passport_agence', $this->data);
                }
                elseif($obj == "passport_online")
                {
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['types'] = "online";
                        $this->data['display'] = "passports";

                        echo view('\Modules\Branch\Views\reports\_passport_online', $this->data);
                }
                elseif($obj == "filter_passport_online")
                {
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                        $this->data['status'] = $this->reportsModel->status;
                        $this->data['colors'] = $this->reportsModel->status_color;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['display'] = "passports";
                        $this->data['types'] = "online";

                        echo view('\Modules\Branch\Views\reports\_filter_passport_online', $this->data);
                }
		elseif($obj=="online-taxes")
                {
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_reports_online_taxes_paiements();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\_online_taxes', $this->data);
                }
                elseif($obj=="filter_online_taxes")
                {
                        $data = $_POST;

                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_reports_online_taxes_paiements($data);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\reports\filterresult_online_taxes', $this->data);
                }
                #Default
                elseif ($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }

        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
         */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL) {
                if ($obj == "OBJ ") 
                {

                } 
                elseif ($obj == "OBJ ") 
                {

                } 
                elseif ($obj == "OBJ ") 
                {

                }
        }

    /*
     * Manages additional data manipuations
     * Arguments could of any type, arrays or strings
     * PS: A modifier uniquement si c'est necessaire!!
     * *  *************************************************************************************************************************SECTION 5
     */

        private function export_reversement_dgrk()
        {
                $ids = array_values(array_filter(array_map('intval', (array) $this->request->getPost('paiements'))));
                if (!$ids) return $this->response->setStatusCode(422)->setJSON(['message' => 'Sélectionnez au moins un paiement.']);
                $rows = $this->reportsModel->get_dgrk_reversement_by_ids($ids);
                $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $sheet->setTitle('DETAIL_RECETTES');
                $headers = ['Date_collecte','Banque_collectrice','Reference_paiement','Code_Service_Taxation','Nom_Service_Taxation','Code_budgétaire','Regie_Note_de_Perception','Note_de_perception','Contribuable','Devise','Montant'];
                foreach ($headers as $i => $header) $sheet->setCellValueByColumnAndRow($i + 1, 1, $header);
                $bank = strtoupper(ltrim((string) ($this->session->userdata['account_pageid'] ?? ''), '@'));
                $services = $this->logirefModel->get_dropdown('services', 'DGRK', null, true);
                $services = $services['DGRK'] ?? [];
                foreach ($rows as $i => $row) {
                        $serviceCode = trim((string) ($row->Service_11 ?? ''));
                        $serviceName = (string) ($services[$serviceCode] ?? '');
                        if (preg_match('/^(.*)\s+\(([^()]*)\)$/', $serviceName, $match)) {
                                $serviceName = trim($match[1]);
                                $serviceCode = trim($match[2]);
                        }
                        $values = [$row->Date_1 ?? '', $bank, $row->Reference_22 ?? $row->Logirefid_9 ?? '', $serviceCode, $serviceName, $row->Typerecette_12 ?? '', 'DGRK', $row->Declarationid_20 ?? '', $row->Designation_14 ?? '', $row->Devise_16 ?? '', number_format((float) ($row->Montant_15 ?? 0), 2, ',', ' ')];
                        foreach ($values as $i2 => $value) $sheet->setCellValueByColumnAndRow($i2 + 1, $i + 2, $value);
                }
                $last = max(1, count($rows) + 1);
                $sheet->getStyle('A1:K' . $last)->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
                $filename = 'Modele_Declaration_Banques_Platforme_CUT_Banque_' . $bank . '_Date_' . date('Ymd') . '_v4.xlsx';
                $this->response->setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                $this->response->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"');
                $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
                ob_start(); $writer->save('php://output'); $this->reportsModel->mark_dgrk_reversed($ids);
                return $this->response->setBody(ob_get_clean());
        }

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "normalize_reporting_dgda_date") {
                        $date = trim((string) $data);
                        $default = $arg;
                        if ($date == '') {
                                return $default;
                        }

                        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                                return $date;
                        }

                        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $date, $matches)) {
                                return $matches[3] . '-' . $matches[2] . '-' . $matches[1];
                        }

                        $timestamp = strtotime(str_replace('/', '-', $date));
                        if ($timestamp !== false) {
                                return date('Y-m-d', $timestamp);
                        }

                        return $default;
                }

                if ($obj == "export_reporting_immatriculation_excel") {
                        @set_time_limit(0);

                        $source = $data;
                        $params = is_array($arg) ? $arg : [];
                        $title = ($source == 'propre') ? "Rapport détaillé des plaques d'immatriculation propres" : "Rapport détaillé des plaques d'immatriculation Trésor";
                        $guichets = $this->branchModel->get_dropdown("guichets");

                        $spreadsheet = new Spreadsheet();
                        $sheet = $spreadsheet->getActiveSheet();
                        $sheet->setTitle(substr($source == 'propre' ? 'Plaques propres' : 'Plaques tresor', 0, 31));

                        $headers = ['Date', 'Statut', 'N° de la note', 'Montant note', 'Bénéficiaires', 'Taxe', 'Compte crédité', 'Montant crédité', 'Montant en dollars', 'Taux appliqué', 'Canal de paiement', 'Agence'];
                        $column = 'A';
                        foreach ($headers as $header) {
                                $sheet->setCellValue($column . '1', $header);
                                $column++;
                        }

                        $batchSize = 500;
                        $offset = 0;
                        $excelRow = 2;

                        do {
                                $report = $this->reportsModel->get_reporting_immatriculation_paiements_datatable($source, $params, $offset, $batchSize, '', 0, 'DESC');
                                $rows = $report['rows'];
                                $rowCount = count($rows);

                                foreach ($rows as $row) {
                                        $noteDevise = isset($row->Notedevise_13) ? trim($row->Notedevise_13) : '';
                                        $deviseCredit = isset($row->Devisecredit_15) ? trim($row->Devisecredit_15) : '';
                                        $noteMontant = number_format((float) $row->Notemontant_3, 2, '.', '');
                                        $montantCredite = number_format((float) $row->Montantcredite_6, 2, '.', '');

                                        $sheet->setCellValue('A' . $excelRow, $row->Date_1);
                                        $sheet->setCellValue('B' . $excelRow, $row->Integrationstatus_19);
                                        $sheet->setCellValue('C' . $excelRow, $row->Noteid_12);
                                        $sheet->setCellValue('D' . $excelRow, $noteMontant . ($noteDevise != '' ? ' ' . $noteDevise : ''));
                                        $sheet->setCellValue('E' . $excelRow, $row->Beneficiaire_4);
                                        $sheet->setCellValue('F' . $excelRow, $row->Taxe_8);
                                        $sheet->setCellValue('G' . $excelRow, $row->Comptecredite_5);
                                        $sheet->setCellValue('H' . $excelRow, $montantCredite . ($deviseCredit != '' ? ' ' . $deviseCredit : ''));
                                        $sheet->setCellValue('I' . $excelRow, (float) $row->Montantdollars_14);
                                        $sheet->setCellValue('J' . $excelRow, $row->Taux_7);
                                        $sheet->setCellValue('K' . $excelRow, $row->TypeTransmission_2);
                                        $sheet->setCellValue('L' . $excelRow, isset($guichets[$row->Agencebancaire_18]) ? $guichets[$row->Agencebancaire_18] : $row->Agencebancaire_18);
                                        $excelRow++;
                                }

                                $offset += $batchSize;
                        } while ($rowCount == $batchSize);

                        $lastRow = max(1, $excelRow - 1);
                        $sheet->getStyle('A1:L1')->getFont()->setBold(true);
                        $sheet->getStyle('A1:L' . $lastRow)->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
                        $sheet->getStyle('I2:I' . max(2, $lastRow))->getNumberFormat()->setFormatCode('#,##0.00');
                        $columnWidths = [
                                'A' => 20, 'B' => 38, 'C' => 24, 'D' => 18,
                                'E' => 24, 'F' => 16, 'G' => 28, 'H' => 18,
                                'I' => 20, 'J' => 16, 'K' => 20, 'L' => 22,
                        ];
                        foreach ($columnWidths as $column => $width) {
                                $sheet->getColumnDimension($column)->setWidth($width);
                        }

                        $fileName = ($source == 'propre' ? 'rapport_des_plaques_immatriculation_propres_' : 'rapport_des_plaques_immatriculation_tresor_') . (!empty($params['siop_report']) ? 'siop_' . $params['siop_report'] . '_' : '') . date('YmdHis') . '.xlsx';

                        while (ob_get_level() > 0) {
                                ob_end_clean();
                        }

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $fileName . '"');
                        header('Cache-Control: max-age=0');

                        $writer = new Xlsx($spreadsheet);
                        $writer->setPreCalculateFormulas(false);
                        $writer->save('php://output');
                        $spreadsheet->disconnectWorksheets();
                        return true;
                
                        return;
                }

                if ($obj === 'export_reversement_dgrk') return $this->export_reversement_dgrk();
                if ($obj == "get_users") {
                        if ($data != "" && $data != NULL) {
                                $members = $this->userModel->get_members($data);
                        } else {
                                $members = $this->userModel->get_members();
                        }

                        $members = $this->userModel->get_members();
                        #var_dump($members);die;

                        return $members;
                }
                elseif($obj=="export_paiement_integrated"){
                    
                        $paiement_ids=$_POST['paiement_ids'];
                        
                        $instructions= $this->integrationModel->get_instructions_dgda_by_paiement_id($paiement_ids);
                       
                        $table_columns=['Code Agence','Digit','Montant Débité','Libellé'];
                       
                        
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        
                        //name the worksheet
                        $worksheet->setTitle('PAIEMENTS INTEGRES');
                        
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($instructions);
                        
                        foreach ($instructions as $key=>$instruction)
                        {
                                $compte= explode('-',  $instruction->Compte_9);
                                $code_agence = $compte[0];
                                $digits = $compte[1];
                                
                                $worksheet->setCellValue('A'.$erow, $code_agence);

                                $worksheet->setCellValue('B'.$erow, $digits);
                                $worksheet->setCellValue('C'.$erow, $instruction->Montant_10);

                                $worksheet->setCellValue('D'.$erow, $instruction->Libelle_12);
                            
                                $i++;

                                if($i != $array_length)
                                {   
                                        $erow++;
                                }
                        }
                        
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        
                        $user_id = $this->session->userdata['user_id'];
                        
                        $filename=$user_id.'_fichier_paiement_integrer_sydonia_'.time().'.xlsx';

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                                $account_id = $this->session->userdata['account_id'];
                                
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/sydonia';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);   
                                
                                if(file_exists($path)){
                                    $response['code']=200;
                                    $response['path']=$path;
                                }else{
                                    $response['code']=400;
                                }
                                return json_encode($response);
                }
        }


        private function display_integrated_immatriculation_payments($obj)
        {
                $pending = strpos($obj, 'reporting_immatriculation_payments_pending') === 0;
                $title = $pending
                        ? "Rapport global des plaques d'immatriculation non envoyées vers Amplitude"
                        : "Rapport global des plaques d'immatriculation envoyées vers Amplitude";
                $endpoint = 'reporting_immatriculation_payments_' . ($pending ? 'pending' : 'sent');
                $statusLabel = static function ($row) use ($pending) {
                        if (!$pending) {
                                return 'Fichier SIOP envoyé';
                        }
                        $labels = [
                                1 => 'Note initialisée',
                                2 => 'Traité et non envoyé',
                                5 => 'En régularisation',
                                6 => 'En régularisation',
                                7 => 'Traité et non confirmé',
                        ];
                        $status = (int) $row->Status_2;
                        return $labels[$status] ?? ('Autre statut (' . $status . ')');
                };
                $params = $this->request->getGet();
                $params['siop_report'] = $pending ? 'pending' : 'sent';
                $params['filter_start'] = $this->data('normalize_reporting_dgda_date', $params['filter_start'] ?? '', ($pending ? date('Y-m-d') : date('Y-m-d', strtotime('-1 day'))));
                $params['filter_end'] = $this->data('normalize_reporting_dgda_date', $params['filter_end'] ?? '', date('Y-m-d'));
                $guichets = $pending ? $this->branchModel->get_reporting_agencies() : $this->branchModel->get_dropdown('guichets');
                if ($obj === $endpoint) {
                        $this->data['title'] = $title;
                        $this->data['pendingSiop'] = $pending;
                        $this->data['filters'] = $params;
                        $this->data['guichets'] = $guichets;
                        $this->data['dataEndpoint'] = base_url($this->module . '/taxreports/display/' . $endpoint . '_data');
                        $this->data['exportEndpoint'] = base_url($this->module . '/taxreports/display/' . $endpoint . '_export');
                        return view('\Modules\Branch\Views\reports\reporting_immatriculation_payments', $this->data);
                }

                $search = (string) ($params['search']['value'] ?? '');
                $orderColumn = (int) ($params['order'][0]['column'] ?? 0);
                $orderDir = (string) ($params['order'][0]['dir'] ?? 'DESC');
                $export = $obj === $endpoint . '_export';
                try {
                        if ($export) {
                                @set_time_limit(0);
                                $spreadsheet = new Spreadsheet();
                                $sheet = $spreadsheet->getActiveSheet();
                                $sheet->setTitle($pending ? 'Paiements non intégrés' : 'Paiements intégrés');
                                $headers = ['Date', 'N° de la note', 'NIF', 'Requérant', 'Montant', 'Devise', 'Référence Logiref', 'Agence', 'Statut'];
                                $sheet->fromArray($headers, null, 'A1');
                                $offset = 0;
                                $excelRow = 2;
                                do {
                                        $report = $this->reportsModel->get_reporting_immatriculation_integrated_payments($params, $offset, 500, $search, $orderColumn, $orderDir);
                                        foreach ($report['rows'] as $row) {
                                                $values = [$row->Date_1, $row->Reference_6, $row->Nif_8, $row->Requerant_9, $row->Montant, $row->Devise, $row->Logirefid_31, $guichets[$row->Guichet_32] ?? $row->Guichet_32, $statusLabel($row)];
                                                foreach ($values as $index => $value) {
                                                        $sheet->setCellValueExplicit(chr(65 + $index) . $excelRow, $index === 4 ? (float) $value : (string) $value,
                                                                $index === 4 ? \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_NUMERIC : \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                                                }
                                                $excelRow++;
                                        }
                                        $offset += 500;
                                } while (count($report['rows']) === 500);
                                $lastColumn = 'I';
                                $sheet->getStyle('A1:' . $lastColumn . '1')->getFont()->setBold(true);
                                $amountColumn = 'E';
                                $sheet->getStyle($amountColumn . '2:' . $amountColumn . max(2, $excelRow - 1))->getNumberFormat()->setFormatCode('#,##0.00');
                                $sheet->setAutoFilter('A1:' . $lastColumn . max(1, $excelRow - 1));
                                $sheet->freezePane('A2');
                                foreach (range('A', $lastColumn) as $column) {
                                        $sheet->getColumnDimension($column)->setAutoSize(true);
                                }
                                while (ob_get_level() > 0) {
                                        ob_end_clean();
                                }
                                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                                header('Content-Disposition: attachment;filename="paiements_plaques_' . ($pending ? 'non_integres' : 'integres') . '_amplitude_' . date('YmdHis') . '.xlsx"');
                                header('Cache-Control: max-age=0');
                                $writer = new Xlsx($spreadsheet);
                                $writer->setPreCalculateFormulas(false);
                                $writer->save('php://output');
                                $spreadsheet->disconnectWorksheets();
                                exit;
                        }
                        $report = $this->reportsModel->get_reporting_immatriculation_integrated_payments($params, (int) ($params['start'] ?? 0), 100, $search, $orderColumn, $orderDir);
                        $rows = [];
                        foreach ($report['rows'] as $row) {
                                $rows[] = [
                                        'date' => $row->Date_1,
                                        'note' => $row->Reference_6,
                                        'nif' => $row->Nif_8,
                                        'requerant' => $row->Requerant_9,
                                        'montant' => number_format((float) $row->Montant, 2, ',', ' '),
                                        'devise' => $row->Devise,
                                        'reference' => $row->Logirefid_31,
                                        'agence' => $guichets[$row->Guichet_32] ?? $row->Guichet_32,
                                        'statut' => $statusLabel($row),
                                        'statut_code' => (int) $row->Status_2,
                                ];
                        }
                        return $this->response->setJSON([
                                'draw' => (int) ($params['draw'] ?? 1),
                                'recordsTotal' => $report['recordsTotal'],
                                'recordsFiltered' => $report['recordsFiltered'],
                                'data' => $rows,
                        ]);
                } catch (\Throwable $e) {
                        log_message('error', 'Reporting paiements immatriculation intégrés: ' . $e->getMessage());
                        if ($export) {
                                return $this->response->setStatusCode(500)->setBody('Impossible de générer le rapport. Veuillez réessayer.');
                        }
                        return $this->response->setJSON([
                                'draw' => (int) ($params['draw'] ?? 1), 'recordsTotal' => 0, 'recordsFiltered' => 0,
                                'data' => [], 'error' => 'Impossible de charger les paiements. Veuillez réessayer.',
                        ]);
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
