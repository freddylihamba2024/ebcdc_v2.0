<?php

        namespace Modules\Branch\Controllers;

        use App\Controllers\BaseController;
        use Modules\Branch\Models\CurlModel;
        use Modules\Branch\Models\DataModel;
        use Modules\Branch\Models\RatesModel;
        use Modules\Admin\Models\AccountModel;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Branch\Models\IntegrationModel;
        use Modules\Branch\Models\EncaissementModel;
        use Modules\Admin\Models\FeesModel;
        use Modules\Services\Bsqr\Controllers\Bsqr;
        use Modules\Services\Igor\Controllers\Igor;
        use Modules\Services\Finacle\Controllers\Finacle;
        use Modules\Services\Flexcube\Controllers\Flexcube;
        use Modules\Services\Temenos\Controllers\Temenos;
        use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
        use Modules\Services\Amplitude\Controllers\Amplitude;
        use Modules\Services\Gesimpots\Controllers\Gesimpots;
        use Modules\Services\Synergies\Controllers\Synergies;
        use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
        use Modules\Services\Comptabilisation\Models\ComptabilisationModel;

        class TaxDgrk extends BaseController {
                /*
                * Presentation:
                * Last update:
                * By Don@ld K. on the 12.06.2025
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('','','');
                public $roles = '5';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'branch';
                public $folder = 'dgrk';
                public $logirefModel;
                public $encaissementModel;
                public $integrationModel;
                public $comptabilisationModel;
                public $accountModel;
                public $ratesModel;
                public $feesModel;
                public $curlModel;
                public $synergies;
                public $comptabilisation;
                public $functionalities;
                public $amplitude;
                public $igor;
                public $bsqr;
                public $bank;
                public $finacle;
                public $core_banking;
                public $temenos;
                public $gesimpots;
                public $dataModel;
                public $options;
                public $role;
                public $bank_uppercase;
                public $amplitude_solidairebanque;
                public $fibridge;
                public $flexcube;
                public $finacle_standardbank;
                public $temenoscrdb;

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */

                        $this->curlModel = new CurlModel();
                        $this->dataModel = new DataModel();
                        $this->encaissementModel = new EncaissementModel();
                        $this->integrationModel = new IntegrationModel();
                        $this->comptabilisationModel = new ComptabilisationModel();
                        $this->accountModel = new AccountModel();
                        $this->ratesModel = new RatesModel();
                        $this->logirefModel = new LogirefModel();
                        $this->feesModel = new FeesModel();
                        $this->bsqr = new Bsqr();
                        $this->igor = new Igor();
                        $this->finacle = new Finacle();
                        $this->amplitude = new Amplitude();
                        $this->gesimpots = new Gesimpots();
                        $this->synergies = new Synergies();
                        $this->comptabilisation = new Comptabilisation();
                        $this->amplitude_solidairebanque = null;
                        $this->fibridge = null;
                        $this->flexcube = new Flexcube();
                        $this->temenos = new Temenos();
                        $this->temenoscrdb = new TemenosCrdb();
                        $this->finacle_standardbank = null;
                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'taxdgrk';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->encaissementModel->documents;
                        $this->data['devises'] = $this->encaissementModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['moyens'] = $this->encaissementModel->moyens;
                        $this->data['infos'] = $this->encaissementModel->infos;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGRK", NULL, true);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes", "DGRK", NULL, true);
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                        $this->data['userid'] = $this->session->userdata["user_id"];
                        $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                        $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                        $this->data['i'] = 0;
                        $user_roles = $this->session->userdata['user_roles'];

                        if($this->bank != "")
                        {
                                # Enlever @ dans le pageid
                                # Tranformer la premiere lettre en majuscule
                                $this->bank = substr($this->bank, 1);
                                $this->bank_uppercase = ucfirst($this->bank);
                        }

                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        /*
                                * Control user access to this module
                                * If role is not set to access this module, then access denied
                        */
                        if($_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else
                        {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }

                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                }


                public function index()
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->data['subview'] = '\Modules\Branch\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }


                /*
                * Manages sidebar menu
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */

                public function set($needle)
                {
                                if(in_array($needle, $this->menus))
                                {
                                        if($_SESSION['Logiref_role']==4)
                                        {
                                                $this->data['sidebar'] = '';
                                        }
                                        $this->index();
                                }
                }


                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */


                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                                if($obj == "start")
                                {
                                        $this->data['step'] = 1;
                                        echo view('\Modules\Branch\Views\\'.$this->folder.'\_'.$obj, $this->data);
                                }
                                elseif($obj == "verification")
                                {
                                        $declarationId = trim((string) ($_POST['Noteid_26'] ?? ''));
                                        $declaration = $declarationId !== ''
                                                ? $this->encaissementModel->check_prepayment_propres_dgrk_by_declaration($declarationId)
                                                : null;

                                        if ($declaration === null || !isset($declaration->Id_0)) {
                                                // Référence non encore enregistrée : poursuivre
                                                // directement avec l'étape 2 pour la saisie.
                                                $this->data['encaissement'] = $this->encaissementModel->get_paiement_propres_dgrk_info();
                                        } else {
                                                $paymentStatus = (int) ($declaration->Status_2 ?? 0);
                                                if ($paymentStatus === 5) {
                                                        echo 'E405';
                                                        return;
                                                }
                                                if ($paymentStatus === 2 || $paymentStatus === 3) {
                                                        echo 'E409';
                                                        return;
                                                }
                                                $this->data['encaissement'] = $declaration;
                                        }

                                        $this->data['encaissement']->Declarationid_20 = $declarationId;

                                        echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);

                                }
                                elseif($obj == "create")
                                {
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRK", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRK");
                                        $this->data['recettes'] = $recettes["DGRK"];
                                        $this->data['client'] = $this->logirefModel->get_clients_by_nif($_POST['Nif_17']);
                                        $this->data['note_reference'] = $this->encaissementModel->get_paiement_by_reference($_POST['Reference_14']);
                                        $this->data['encaissement'] = $this->encaissementModel->get_paiement_propres_dgrk_info();
                                        $this->data['type_services'] = $this->logirefModel->get_dropdown("type_services");

                                        echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_2', $this->data);
                                }
                                elseif($obj == "edit")
                                {
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRK", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRK");
                                        $this->data['recettes'] = $recettes["DGRK"];
                                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                        $this->data['view'] = '';
                                        $this->data['type_services'] = $this->logirefModel->get_dropdown("type_services");
                                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                        $this->data['online_document'] = ($arg === 'online');

                                        if ($arg === 'online')
                                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_online_1', $this->data);
                                        else
                                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                                }
                                elseif($obj == "preview")
                                {
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRK", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRK");
                                        $this->data['recettes'] = $recettes["DGRK"];
                                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                        $this->data['view'] = 'view';
                                        // Consultation depuis les rapports validés : aucune action de validation.
                                        $this->data['report_view'] = $this->request->getGet('report') === '1';
                                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                        $this->data['online_document'] = ($arg === 'online');

                                        if ($arg === 'online')
                                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_online_1', $this->data);
                                        else
                                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_step_3', $this->data);
                                }
                                elseif($obj == "instructions_attestation")
                                {
                                        $end_execution = '';
                                        $data = $_POST;
                                        $instructions = $this->integrationModel->get_instructions_unvalidated_attestation_dgrk($id);

                                        if (empty($instructions))
                                        {
                                                #Taux de change
                                                if(isset($_POST['Taux_29']) && $_POST['Taux_29'] !="")
                                                {
                                                        $data['Taux_29'] = $_POST['Taux_29'];
                                                }
                                                else if($data['Devise_16']!='CDF')
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        if($data['Devise_16']=='USD') $data['Taux_29'] = $taux['Dollar_4'];
                                                        if($data['Devise_16']=='EUR') $data['Taux_29'] = $taux['Euro_5'];
                                                        if($data['Devise_16']=='ZAF') $data['Taux_29'] = $taux['Rand_6'];
                                                }

                                                $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                                $infos_exist = json_decode($encaissement->Decreference_26, true);

                                                $infos = $data['Infos'];

                                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                                else if (isset($infos_exist['PaidATTESTATION'])) $infos['PaidATTESTATION'] = $paid_attestation = $infos_exist['PaidATTESTATION'] ;

                                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];
                                                else if (isset($infos_exist['PaidDUPLICATA'])) $infos['PaidDUPLICATA'] = $paid_duplicata = $infos_exist['PaidDUPLICATA'];

                                                if (isset($infos['CommissionAttestation']))
                                                {
                                                        $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                                        $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);
                                                }
                                                else
                                                {
                                                        if (isset($infos_exist['CommissionAttestation']))
                                                                $infos['CommissionAttestation'] = $infos_exist['CommissionAttestation'];
                                                }

                                                if (isset($infos['CommissionDuplicata']))
                                                {
                                                        $infos['CommissionDuplicata'] = str_replace(' ','',$infos['CommissionDuplicata']);
                                                        $infos['CommissionDuplicata'] = str_replace(',','.',$infos['CommissionDuplicata']);
                                                }
                                                else
                                                {
                                                        if (isset($infos_exist['CommissionDuplicata']))
                                                                $infos['CommissionDuplicata'] = $infos_exist['CommissionDuplicata'];
                                                }

                                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                                                $data_attest['Decreference_26'] = json_encode($infos);
                                                $pid = $this->encaissementModel->update_payment_propres_dgrk($data_attest, $data['Logirefid_9']);

                                                if ($pid)
                                                {
                                                        #Impression des attestation - repartition
                                                        $commission = 0;
                                                        $devise_com = '';

                                                        if (isset($paid_duplicata) && $paid_duplicata == "FDA") $paid_attestation = "";

                                                        $types = [
                                                                'FIA' => $paid_attestation ?? null,
                                                                'FDA' => $paid_duplicata ?? null,
                                                        ];

                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        if($data['Devise_16']=='USD') $data['Taux_29'] = $taux['Dollar_4'];
                                                        if($data['Devise_16']=='EUR') $data['Taux_29'] = $taux['Euro_5'];
                                                        if($data['Devise_16']=='ZAF') $data['Taux_29'] = $taux['Rand_6'];

                                                        foreach ($types as $code => $paid)
                                                        {
                                                                if ($paid === $code)
                                                                {
                                                                        if ((float) $commission_attestation > 0) {
                                                                                $data['Commission_17'] = $commission_attestation;
                                                                                $data['Type_fees'] = $code;
                                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation_dgrk($data);
                                                                                $this->comptabilisationModel->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_9']);
                                                                                continue;
                                                                        }
                                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite']))
                                                                        {
                                                                                $commission = $rules['Valeur'];
                                                                                $devise_com = $rules['Unite'];

                                                                                if($data['Devise_25'] == $data['Devise_18'] && $data['Devise_25'] =='CDF')
                                                                                {
                                                                                        $data['Commission_17'] = $commission * $data['Taux_29'];
                                                                                }
                                                                                else
                                                                                {
                                                                                        $data['Commission_17'] = $commission;
                                                                                        $data['Devise_18'] = $devise_com;
                                                                                }

                                                                                $data['Type_fees'] = $code;

                                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation_dgrk($data);

                                                                                $end_execution = $this->comptabilisationModel->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_9']);
                                                                        }
                                                                }
                                                        }
                                                }

                                                #Return
                                                if(isset($end_execution) && $end_execution)
                                                {
                                                        $result['code'] = 'E200';
                                                        $result['id'] = $data['Id_0'];

                                                        echo json_encode($result);
                                                }
                                                else
                                                {
                                                        $result['code'] = 'E305';
                                                        $result['id'] = 0;

                                                        echo json_encode($result);
                                                }
                                        }
                                        else
                                        {
                                                $result['code'] = 'E405';
                                                $result['id'] = 0;

                                                echo json_encode($result);
                                        }
                                }
                                #Default
                                elseif($obj == "deny")
                                {
                                        $this->data['denied'] = TRUE;
                                        $this->data['country'] = $this->session->userdata['account_country'];
                                        echo view('\Modules\Branch\Views\\'.$this->lang.'_denial', $this->data);
                                }
                }


                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "comptant")
                        {
                                $commission_attestation = 0;

                                # Save payment
                                # Validate payment form
                                $error = $this->data("validate_paiments");

                                #If form could not be validate
                                if($error !='')
                                {
                                        echo '<div class="alert aDanger">Error! veuillez pr&eacute;&ccedil;iser le montant pay&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        die;
                                }
                                # If form is validate successfullly
                                else
                                {
                                        $data = array();
                                        $data_id_paiement = array();
                                        $arrondi = 0;

                                        $data = $_POST;
                                        $paymentExists = !empty($data['Id_0']);
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Datevaleur_23'] = strftime('%Y-%m-%d', strtotime($data['Datevaleur_23']));
                                        if($_SESSION['Logiref_role'] ==4) $data['Makerid_7'] = $this->session->userdata['user_id'];

                                        // Les champs cachés de la vue peuvent contenir 0
                                        // (ancienne page ou session non recopiée). Pour un
                                        // nouveau paiement, la session est la source fiable
                                        // de l'agence et du guichet de l'utilisateur.
                                        if ((int) ($data['Agence_27'] ?? 0) === 0
                                                && isset($_SESSION['Logiref_agence'])
                                                && $_SESSION['Logiref_agence'] !== '') {
                                                $data['Agence_27'] = $_SESSION['Logiref_agence'];
                                        }
                                        if ((int) ($data['Guichet_28'] ?? 0) === 0
                                                && isset($_SESSION['Logiref_guichet'])
                                                && $_SESSION['Logiref_guichet'] !== '') {
                                                $data['Guichet_28'] = $_SESSION['Logiref_guichet'];
                                        }

                                        $benificiaire = $data['Beneficaire_10'] = 'DGRK';
                                        $infos = $data['Infos'];

                                        // Un paiement en ligne peut déjà contenir les frais d'attestation
                                        // fournis par la plateforme. Les cases non cochées ne sont pas
                                        // postées par le navigateur : conserver donc les valeurs existantes.
                                        if (!empty($data['Id_0'])) {
                                                $existingPayment = $this->encaissementModel->get_paiement_propres_dgrk_info($data['Id_0']);
                                                $existingInfos = $existingPayment ? json_decode($existingPayment->Decreference_26, true) : [];
                                                if (is_array($existingInfos)) {
                                                        foreach (['PaidATTESTATION', 'PaidDUPLICATA', 'PaidAttest', 'PaidAttestDup', 'CommissionAttestation', 'CommissionDuplicata'] as $key) {
                                                                if ((!array_key_exists($key, $infos) || $infos[$key] === '' || $infos[$key] === null) && array_key_exists($key, $existingInfos)) {
                                                                        $infos[$key] = $existingInfos[$key];
                                                                }
                                                        }
                                                }
                                        }
                                        if ((!isset($infos['CommissionAttestation']) || $infos['CommissionAttestation'] === '') && isset($infos['commissionAttestation'])) {
                                                $infos['CommissionAttestation'] = $infos['commissionAttestation'];
                                        }
                                        if (empty($infos['PaidATTESTATION']) && !empty($infos['paidAttestation'])) {
                                                $infos['PaidATTESTATION'] = $infos['paidAttestation'];
                                        }
                                        if (empty($infos['PaidDUPLICATA']) && !empty($infos['paidDuplicata'])) {
                                                $infos['PaidDUPLICATA'] = $infos['paidDuplicata'];
                                        }

                                        // Test if the total_amount has been calculated
                                        if($infos['totalMontant'] == "")
                                        {
                                                $infos['totalMontant'] = $this->encaissementModel->get_montant_total_dgrk($data);
                                        }
                                        else
                                        {
                                                if($data['Mode_21'] == '5')
                                                {
                                                        if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                                        {
                                                                if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities']))
                                                                {
                                                                        $total_amount_payed = $infos['totalMontant'];
                                                                        $real_total_amount = $this->encaissementModel->get_montant_total_dgrk($data);

                                                                        $arrondi = $total_amount_payed - $real_total_amount;
                                                                }
                                                        }
                                                }
                                        }

                                        if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                        if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                                        if (isset($infos['CommissionAttestation']))
                                        {
                                                $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                                $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);

                                                $commission_attestation = $infos['CommissionAttestation'];
                                        }

                                        // Certains paiements en ligne portent déjà le montant des
                                        // frais, mais pas le marqueur de la case HTML. Dans ce cas,
                                        // le montant reçu suffit à conserver/générer les écritures FIA.
                                        if ((float) $commission_attestation > 0 && empty($paid_attestation) && empty($paid_duplicata)) {
                                                $paid_attestation = $infos['PaidATTESTATION'] = 'FIA';
                                        }
                                        if ((float) $commission_attestation <= 0 && !empty($data['Logirefid_9'])) {
                                                foreach ($this->comptabilisationModel->get_instructions_dgrk($data['Logirefid_9']) as $existingInstruction) {
                                                        if (($existingInstruction->TypeCompte_25 ?? '') === 'FA') {
                                                                $commission_attestation = abs((float) ($existingInstruction->Montant_10 ?? 0));
                                                                if ($commission_attestation > 0 && empty($paid_attestation) && empty($paid_duplicata)) {
                                                                        $paid_attestation = $infos['PaidATTESTATION'] = 'FIA';
                                                                }
                                                                break;
                                                        }
                                                }
                                        }

                                        #Invoque the API account.info to retrieve the client informations
                                        $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname'] ?? '');

                                        $data['Decreference_26'] = json_encode($infos);
                                        unset($data['Infos']);

                                        #Taux de change
                                        if(isset($_POST['Taux_29']) && $_POST['Taux_29'] !="")
                                        {
                                                $data['Taux_29'] = $_POST['Taux_29'];
                                        }
                                        else if($data['Devise_16']!='CDF')
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                if($data['Devise_16']=='USD') $data['Taux_29'] = $taux['Dollar_4'];
                                                if($data['Devise_16']=='EUR') $data['Taux_29'] = $taux['Euro_5'];
                                                if($data['Devise_16']=='ZAF') $data['Taux_29'] = $taux['Rand_6'];
                                        }

                                        //Formatting amount
                                        $data['Montant_15'] = str_replace(' ','',$data['Montant_15']);
                                        $data['Montant_15'] = str_replace(',','.',$data['Montant_15']);
                                        $data['Taux_29'] = str_replace(' ','',$data['Taux_29']);
                                        $data['Taux_29'] = str_replace(',','.',$data['Taux_29']);
                                        $data['Commission_17'] = str_replace(' ','',$data['Commission_17']);
                                        $data['Commission_17'] = str_replace(',','.',$data['Commission_17']);

                                        #Contre valeur en CDF
                                        $data['Devise_30'] = $data['Devise_16'];
                                        $data['Contrevaleur_19'] = ($data['Devise_16'] !='CDF') ? $data['Montant_15'] * $data['Taux_29'] : $data['Montant_15'];

                                        # SAVE PAYMENT
                                        # Check if it's a new payment

                                        if($data['Id_0']=="" || $data['Id_0']==0)
                                        {
                                                unset($data['Id_0']);
                                                $ref = $this->encaissementModel->get_id_by_reference_dgrk($data['Logirefid_9']);

                                                $data['Id_0'] = $ref;
                                        }


                                        # Encaissement existant
                                        if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                        {
                                                #Is this a validation? Yes if it's a validator or the supervisor
                                                if($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2)
                                                {
                                                        /*
                                                        * ------------------------------------------------
                                                        * Variable initialization for payment validation
                                                        * ------------------------------------------------
                                                        */
                                                        $id =  $data['Id_0'];

                                                        // Le connecteur Finacle utilise le nom normalisé
                                                        // Beneficaire_15, alors que la table DGRK expose
                                                        // Beneficaire_10. Sans cet alias il répond 405
                                                        // « Missing data in the request ».
                                                        $data['Beneficaire_15'] = 'DGRK';
                                                        $data['Paiementid_4'] = $id;
                                                        $data['Logirefid_4'] = $data['Logirefid_4'] ?? ($data['Logirefid_9'] ?? ($encaissement->Logirefid_9 ?? ''));
                                                        $data['Taux_41'] = $data['Taux_41'] ?? ($data['Taux_29'] ?? ($encaissement->Taux_29 ?? ''));
                                                        $data['Notereference_30'] = $data['Notereference_30'] ?? ($data['Decreference_26'] ?? ($encaissement->Decreference_26 ?? ''));

                                                        $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                                        $infos = json_decode($encaissement->Decreference_26, true);

                                                        $result = array();

                                                        # Nom du core banking
                                                        $core_banking = strtolower($this->core_banking);

                                                        # Vérifier si la méthode existe dans la classe
                                                        if (method_exists($this->{$core_banking}, 'validate_payment'))
                                                        {
                                                                $return = $this->{$core_banking}->validate_payment($data);
                                                   
                                                                $result = json_decode($return, true);
                                                                if (!is_array($result)) {
                                                                        $result = array();
                                                                }

                                                                // BSQR peut renvoyer 200 en entier ou "200" en chaîne.
                                                                // Normaliser la valeur permet d'exécuter le bloc de succès
                                                                // et de transmettre l'identifiant à _step_3/_step_online_1.
                                                                if ((string) ($result['code'] ?? '') === '200')
                                                                {
                                                                        $result['Notereference'] = json_decode($data['Decreference_26'], true);
                                                                        $result['Num_evenement'] = isset($result['Num_evenement']) ? $result['Num_evenement'] : "";
                                                                        $logirefid = $data['Logirefid_9'];

                                                                        // Pour eviter la modification du paeiment par le validateur
                                                                        $data = array();

                                                                        $data['Id_0'] = $id;
                                                                        // Le Core Banking a confirmé toutes les écritures :
                                                                        // le paiement DGRK doit quitter l'état initialisation.
                                                                        $data['Status_2'] = 2;
                                                                        $data['Checkerid_8'] = $this->session->userdata["user_id"];
                                                                        $data['Logirefid_9'] = $logirefid;
                                                                        $data['Decreference_26'] = json_encode($infos);
                                                                        $data['Validation_37'] = gmdate('Y-m-d H:i:s');

                                                                        if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                                                        {
                                                                                $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                                                                $infos = json_decode($encaissement->Decreference_26, true);

                                                                                if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                                                if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                                                $data['Decreference_26'] = json_encode( $infos);
                                                                        }

                                                                        $result['id'] = $id;

                                                                        // Mise à jour par la clé primaire de la nouvelle table DGRK.
                                                                        // La référence Logirefid_9 sert au lien métier, mais ne doit
                                                                        // pas remplacer Id_0 pour l'UPDATE du paiement.
                                                                        $this->encaissementModel->update_payment_propres_dgrk($data, $id);
                                                                }

                                                                echo json_encode($result); die;
                                                        }
                                                        else
                                                        {
                                                                //$result['code'] = 'E407';
                                                                echo json_encode($result); die;
                                                        }
                                                }
                                                else
                                                {
                                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $this->comptabilisationModel->delete_instructions_dgrk($data['Logirefid_9']);

                                                        # Save changes
                                                        $pid = $this->encaissementModel->update_payment_propres_dgrk($data, $data['Logirefid_9']);
                                                }
                                        }
                                        # Nouvel encaissement
                                        else
                                        {
                                                #Enregistrement
                                                $data['Date_1'] = gmdate('Y-m-d H:i:s');

                                                # Retrieve the last id
                                                $last_id = $this->encaissementModel->get_last_paiement_dgrk_id();
                                                $next_id = $last_id + 1;

                                                $pid = $next_id.$data['Typerecette_12'].$data['Service_11'];
                                                $data['Paiementkey_33'] = rand(1, 99).date('H').date('i').date('s').$pid.date('j').date('m').date('y').$this->session->userdata['user_id'];

                                                $instructions = array();
                                                if($data['Id_0'] == 0) $data['Id_0'] = NULL;

                                                $pid = $this->encaissementModel->save_payment_propres_dgrk($data, NULL);

                                                $data['Id_0'] = $pid;
                                        }

                                        if($_SESSION['Logiref_role'] == 4 && $pid == true)
                                        {
                                                // Marquer l'enregistrement en ligne : à la prochaine
                                                // ouverture, l'opérateur voit « Modifier » au lieu de
                                                // « Enregistrer / Rejeter ».
                                                if ($paymentExists) {
                                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $this->encaissementModel->update_payment_propres_dgrk($data, $data['Logirefid_9']);
                                                }

                                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                                {
                                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities']))
                                                        {
                                                                # Get the instruction for the roundings when the payment method is cash
                                                                if($arrondi > 0)
                                                                {
                                                                        $data ['arrondi'] = $arrondi;
                                                                }
                                                        }
                                                }

                                                if(isset($infos['correspondent_fees']))
                                                {
                                                        $data['correspondent_fees'] = $infos['correspondent_fees'];
                                                        $data['correspondent_fees_currency'] = $infos['correspondent_fees_currency'];
                                                }
                                                else
                                                {
                                                        $data['correspondent_fees'] = 0;
                                                        $data['correspondent_fees_currency'] = 'USD';
                                                }

                                                #Comptabilisation
                                                # Le générateur historique attend encore les anciens
                                                # alias de champs. La table DGRK utilise les noms *_20,
                                                # *_12, *_16, etc. On construit donc une copie adaptée
                                                # sans modifier les données du paiement.
                                                $comptabilisationData = $data;
                                                $comptabilisationData['Noteid_26'] = $data['Declarationid_20'] ?? '';
                                                $comptabilisationData['Typerecette_17'] = $data['Typerecette_12'] ?? '';
                                                $comptabilisationData['Service_16'] = $data['Service_11'] ?? '';
                                                $comptabilisationData['Montant_11'] = $data['Montant_15'] ?? 0;
                                                $comptabilisationData['Commission_23'] = $data['Commission_17'] ?? 0;
                                                $comptabilisationData['Devise_12'] = $data['Devise_16'] ?? '';
                                                $comptabilisationData['Devise_24'] = $data['Devise_25'] ?? '';
                                                $comptabilisationData['Devise_34'] = $data['Devise_30'] ?? '';
                                                $comptabilisationData['Compte_33'] = $data['Compte_24'] ?? '';
                                                $comptabilisationData['Guichet_21'] = $data['Guichet_28'] ?? '';
                                                $comptabilisationData['Taux_41'] = $data['Taux_29'] ?? '';
                                                $instructions = $this->comptabilisation->get_instructions_dgrk($comptabilisationData);

                                                if(isset($data['arrondi'])) unset($data ['arrondi']);

                                                if(!empty($instructions))
                                                {
                                                        $end_execution = $this->comptabilisationModel->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_9']);
                                                }

                                                #Impression des attestation - repartition
                                                if(isset($this->options['ALL']['bank-charges-attestation-printing']) &&  $commission_attestation >0)
                                                {
                                                        $commission = 0;
                                                        $devise_com = '';

                                                        $types = [
                                                                'FIA' => $paid_attestation ?? null,
                                                                'FDA' => $paid_duplicata ?? null,
                                                        ];

                                                        foreach ($types as $code => $paid)
                                                        {
                                                                if ($paid === $code)
                                                                {
                                                                        if ((float) $commission_attestation > 0) {
                                                                                $data['Commission_17'] = $commission_attestation;
                                                                                $data['Type_fees'] = $code;
                                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation_dgrk($data);
                                                                                $this->comptabilisationModel->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_9']);
                                                                                continue;
                                                                        }
                                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite']))
                                                                        {
                                                                                $commission = $rules['Valeur'];
                                                                                $devise_com = $rules['Unite'];

                                                                                if($data['Devise_25'] == $data['Devise_18'] && $data['Devise_25'] =='CDF')
                                                                                {
                                                                                        $data['Commission_17'] = $commission * $data['Taux_29'];
                                                                                }
                                                                                else
                                                                                {
                                                                                        $data['Commission_17'] = $commission;
                                                                                        $data['Devise_18'] = $devise_com;
                                                                                }

                                                                                $data['Type_fees'] = $code;

                                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation_dgrk($data);
                                                                                $this->comptabilisationModel->save_instructions_dgrk($data['Id_0'], $data, $instructions, $data['Logirefid_9']);
                                                                        }
                                                                }
                                                        }
                                                }
                                        }

                                        #Return
                                        if($pid)
                                        {
                                                $result['code'] = 'E200';
                                                $result['id'] = $data['Id_0'];

                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $result['code'] = 'E305';
                                                $result['id'] = 0;

                                                echo json_encode($result);
                                        }
                                }
                        }
                        elseif ($obj == "paid_attestation")
                        {
                                $data = $_POST;

                                #Is this a validation? Yes if it's a validator or the supervisor
                                if($_SESSION['Logiref_role'] ==3)
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Variable initialization for payment validation
                                        * ------------------------------------------------
                                        */

                                        $id =  $data['Id_0'];

                                        $encaissement = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                        $infos = json_decode($encaissement->Decreference_26, true);

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'validate_payment'))
                                        {
                                                $return = $this->{$core_banking}->virement_bank_charge_exception($data);

                                                $result = json_decode($return, true);

                                                if($result['code'] == '200')
                                                {
                                                        $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                        $logirefid = $data['Logirefid_9'];

                                                        if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                        if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                        $data_attest = array();
                                                        $data_attest['Id_0'] = $id;
                                                        $data_attest['Logirefid_9'] = $logirefid;
                                                        $data_attest['Decreference_26'] = json_encode( $infos);
                                                        $data_attest['Validation_37'] = gmdate('Y-m-d H:i:s');

                                                        $result['id'] = $id;

                                                        $pid = $this->encaissementModel->update_payment_propres_dgrk($data_attest, $data['Logirefid_9']);
                                                }

                                                echo $return; die;
                                        }
                                        else
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                                else
                                {
                                        $result['code'] = 'E405';
                                        echo json_encode($result); die;
                                }
                        }
                        elseif ($obj == "reject_online")
                        {
                                $payment = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                $accountId = $this->session->userdata['account_id'];

                                if (empty($payment)
                                    || (string) $payment->Account_3 !== (string) $accountId
                                    || empty($payment->Customercode_31)
                                    || (int) $_SESSION['Logiref_role'] !== 4
                                    || !in_array((int) $payment->Status_2, [1, 4, 7], true))
                                {
                                        echo 'E403';
                                        return;
                                }

                                $motifRejet = trim((string) $this->request->getPost('MotifRejet'));
                                if ($motifRejet === '')
                                {
                                        echo 'E422';
                                        return;
                                }

                                $infos = json_decode($payment->Decreference_26, true) ?: [];
                                $infos['Rejected'] = '1';
                                $infos['MotifRejet'] = $motifRejet;
                                $infos['RejectedBy'] = $this->session->userdata['user_id'];
                                $infos['RejectedAt'] = gmdate('Y-m-d H:i:s');

                                $data = [
                                        'Status_2' => 6,
                                        'Changes_5' => gmdate('Y-m-d H:i:s'),
                                        'Changer_6' => $this->session->userdata['user_id'],
                                        'Decreference_26' => json_encode($infos),
                                ];

                                $updated = $this->encaissementModel->update_payment_propres_dgrk($data, $payment->Logirefid_9);
                                echo $updated ? 'E200' : 'E305';
                                return;
                        }
                        elseif ($obj == "payment_validate_taux")
                        {
                                $result = array();
                                $data_to_taux = array();

                                $data = $_POST;

                                #Is this a validation? Yes if it's a the supervisor
                                if($_SESSION['Logiref_role']==2 || $_SESSION['Logiref_role']==3)
                                {
                                        $id =  $data['Id_0'];
                                        $data_to_taux['Tauxflag_38'] = 2;
                                        $tid = $this->encaissementModel->save_payment_propres_dgrk($data_to_taux, $id);

                                        if ($tid)
                                        {
                                                $result['code'] = 'E200';
                                                echo json_encode($result); die;
                                        }
                                        else
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                                else
                                {
                                        $result['code'] = 'E405';
                                }

                                echo json_encode($result); die;

                        }
                        elseif ($obj == "payment_dismissal_taux")
                        {
                                $result = array();
                                $data_to_taux = array();

                                #Is this a validation? Yes if it's a the supervisor
                                if($_SESSION['Logiref_role']==2 || $_SESSION['Logiref_role']==3)
                                {
                                        $data_to_taux['Tauxflag_38'] = 5;
                                        $tid = $this->encaissementModel->save_payment_propres_dgrk($data_to_taux, $id);

                                        if ($tid)
                                        {
                                                $result['code'] = 'E200';
                                                echo json_encode($result); die;
                                        }
                                        else
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                                else
                                {
                                        $result['code'] = 'E405';
                                }

                                echo json_encode($result); die;

                        }
                        elseif($obj == "delete")
                        {
                                $payment = $this->encaissementModel->get_paiement_propres_dgrk_info($id);
                                if (!$payment || in_array((int) ($payment->Status_2 ?? 0), [2, 3], true)) {
                                        echo 'E403';
                                        return;
                                }
                                $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");
                                //$code_recette = $this->input->get('recette');
                                //$rType = $RecetteTYPES[$arg];

                                $deleted = $this->encaissementModel->delete_paiement_propre_dgrk($id);

                                if (!$deleted) {
                                        echo 'E404';
                                        return;
                                }

                                // Les écritures comptables utilisent la même
                                // référence Logirefid_9 que le paiement.
                                $this->comptabilisationModel->delete_instructions_dgrk($payment->Logirefid_9 ?? '');

                                // Le JavaScript de la vue attend la référence
                                // supprimée pour confirmer le succès.
                                echo $id;
                                die;
                        }
                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "validate_paiments")
                        {
                                $error = '';
                                $montant = $_POST['Montant_15'] ?? '';
                                if($montant == '0' || $montant == '') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                                return $error;
                        }
                        elseif ($obj == "get_nif")
                        {
                                if(isset($_POST['nif']))
                                {
                                        $client = $this->logirefModel->get_clients_by_nif($_POST['nif']);
                                        $designation = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                        echo $designation;
                                }
                                else
                                {
                                        echo '';
                                }
                        }
                        elseif ($obj == "get_commission")
                        {
                                $cdata = $data;

                                $montant1 = str_replace(' ', '', $cdata['montant']);

                                $montant2 = str_replace(',', '.', $montant1);
                                $cdata['montant'] = $montant2;
                                $oDeivise = $cdata['devise'];

                                $rules = $this->feesModel->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                                $rules_with_account = $this->feesModel->get_customer_charges($cdata['regie'],$cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte']);
                                $rules_with_mode = $this->feesModel->get_charges_by_paiement_method($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['mode']);

                                if($rules_with_account['fees_found'] == true)
                                {
                                        $rules = $rules_with_account;
                                }

                                if($rules_with_mode['fees_found'] == true)
                                {
                                        $rules = $rules_with_mode;
                                }

                                if ($rules['Valeur'] != 0 && $rules['Unite'] == '%')
                                {
                                        $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                        $com['devise'] = $cdata['devise'];
                                }
                                elseif ($rules['Valeur'] != '' && $rules['Unite'] != '')
                                {
                                        $com['com'] = $rules['Valeur'];
                                        $com['devise'] = $rules['Unite'];
                                }

                                if (!empty($com) && $com['com'] != 0)
                                {
                                        $cdata['commission'] = $com['com'];
                                        $cdata['devise'] = $com['devise'];
                                }
                                else
                                {
                                        $cdata['commission'] = $cdata['montant'] * 0;
                                        $cdata['devise'] = $cdata['devise'];
                                }

                                if (isset($this->options['ALL']['client-exchange-rate-override']) && isset($cdata['taux']) && $cdata['taux'] !== "") 
                                {
                                        $taux['Dollar_4'] = $cdata['taux'];
                                }
                                else
                                {
                                        if (isset($_SESSION['Bank_rates'])) $taux = json_decode($_SESSION['Bank_rates'], true);
                                        else $taux['Dollar_4'] = 1;
                                }

                                if ($cdata['devise'] == $oDeivise && $oDeivise == 'CDF')
                                {
                                        $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                                }
                                else if ($cdata['devise'] == $oDeivise && $oDeivise == 'USD')
                                {
                                        if (isset($this->options['ALL']['client-exchange-rate-override']))
                                        {
                                                //$cdata['commission'] = $commission  =  $cdata['commission'];
                                                //$cdata['devise']     = $cdata['devise'];
                                                $cdata['tva']        = ($cdata['commission'] * 0.16);
                                        }
                                        else
                                        {
                                                $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                                $cdata['devise']     = 'CDF';
                                                $cdata['tva']        = ($cdata['commission'] * 0.16);
                                        }
                                }
                                else if ($cdata['devise'] == 'USD' && $oDeivise == 'CDF')
                                {
                                        # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                        $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                        $cdata['devise']     = 'CDF';
                                        $cdata['tva']        = ($cdata['commission'] * 0.16);
                                }
                                else if ($cdata['devise'] == 'CDF' && $oDeivise == 'USD')
                                {
                                        $cdata['tva'] = ($cdata['commission'] * 0.16);
                                }

                                $ar = array($cdata['commission'], $cdata['tva'], $cdata['devise']);

                                return $ar;
                                exit;
                        }
                        elseif($obj == "get_com_attestation")
                        {
                                $http_request = !is_array($data);
                                $data = $http_request ? $this->request->getPost() : $data;
                                #Impression des attestation - repartition
                                if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                {
                                        $cdata = $data;

                                        $commission = 0;
                                        $devise_com = '';

                                        $types = [
                                                'FIA' => $cdata['paid_attestation'] ?? null,
                                                'FDA' => $cdata['paid_duplicata'] ?? null,
                                        ];

                                        foreach ($types as $code => $paid)
                                        {
                                                if ($paid === $code)
                                                {
                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite']))
                                                        {
                                                                $commission = $rules['Valeur'];
                                                                $devise_com = $rules['Unite'];

                                                                if($cdata['devise'] == $cdata['devise_com'] && $cdata['devise'] =='CDF')
                                                                {
                                                                        $cdata['commission'] = $commission * $cdata['taux'];
                                                                }
                                                                else
                                                                {
                                                                        $cdata['commission'] = $commission;
                                                                }
                                                        }
                                                }
                                        }

                                        $cdata['montant'] = (float) str_replace([' ', ','], ['', '.'], $cdata['montant'] ?? 0);
                                        $cdata['commission'] = (float) ($cdata['commission'] ?? 0);
                                        $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);

                                        $return = array($cdata['commission'], $cdata['devise'], $cdata['total']);

                                        if ($http_request)
                                        {
                                                echo json_encode($return);
                                                return;
                                        }

                                        return $return;
                                        exit;
                                }
                        }
                        elseif ($obj == "get_account_balance")
                        {
                                $account_balance  = $data['account_balance'] ?? 0;
                                $currency_balance = $data['account_currency'] ?? '';

                                $amount_to_paid   = $data['total_to_paid'] ?? 0;
                                $currency_to_paid = $data['total_to_currency'] ?? '';

                                # Récupération des taux
                                $rates = json_decode($_SESSION['Bank_rates'] ?? '{}', true);
                                $taux  = $rates['Dollar_4'] ?? 1;

                                # Conversion si nécessaire
                                if ($currency_balance !== $currency_to_paid)
                                {
                                        if ($currency_balance == "USD" && $currency_to_paid == "CDF") :
                                                $account_balance *= $taux;
                                        elseif ($currency_balance == "CDF" && $currency_to_paid == "USD"):
                                                $account_balance /= $taux;
                                        endif;
                                }

                                # Vérification du solde
                                $code = ($account_balance >= $amount_to_paid) ? 'OK' : 'KO';

                                return [
                                        'code' => $code
                                ];
                        }

                }
        }

        /* End of file welcome.php  */
        /* Location: /project/activities  */
