<?php

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\AccountModel;
use Modules\Admin\Controllers\Elicense;
use Modules\Services\Logirad\Controllers\LogiradNotes;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Logirad\Controllers\Logirad;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;


class TaxNotes extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Glodi on the 05.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'notes';
        public $logirefModel;
        public $encaissementModel;
        public $integrationModel;
        public $comptabilisationModel;
        public $accountModel;
        public $ratesModel;
        public $curlModel;
        public $synergies;
        public $functionalities;
        public $comptabilisation;
        public $igor;
        public $amplitude;
        public $finacle;
        public $finacle_standardbank;
        public $bank;
        public $core_banking;
        public $temenos;
        public $dataModel;
        public $logirad;
        public $bsqr;
        public $fibridge;
        public $options;
        public $amplitude_solidairebanque;
        public $feesModel;
        public $flexcube;
        public $cyclone;
        public $temenoscrdb;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is Branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->logirefModel = new LogirefModel();
                $this->encaissementModel = new EncaissementModel();
                $this->integrationModel = new IntegrationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->dataModel = new DataModel();
                $this->accountModel = new AccountModel();
                $this->ratesModel = new RatesModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->synergies = new Synergies();
                $this->comptabilisation = new Comptabilisation();
                $this->igor = new Igor();
                // $this->logirad = new Logirad();
                $this->logirad = new LogiradNotes();
                $this->amplitude = new Amplitude();
                $this->finacle = new Finacle();
                $this->bsqr = new Bsqr();
                $this->fibridge=new FIBridge();
                $this->finacle_standardbank=new FinacleStandardBank();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->cyclone = new Cyclone();
                $this->temenoscrdb = new TemenosCrdb();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxnotes';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissementModel->documents;
                $this->data['devises'] = $this->encaissementModel->devises;
                $this->data['modes'] = $this->encaissementModel->modes;
                $this->data['moyens'] = $this->encaissementModel->moyens;
                $this->data['infos'] = $this->encaissementModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                
                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank_uppercase = ucfirst($this->bank);
                }
                
                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options'])) 
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                } 
                else 
                {
                        $this->data['options'] = $this->options = array();
                }
                
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options'])) 
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                } 
                else 
                {
                        $this->data['options'] = $this->options = array();
                }
	} 
	
        
	public function index()
	{
		$this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        $this->data['step'] = 1;
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        
                        echo view('\Modules\Branch\Views\notes\_'.$obj, $this->data);
                }
                elseif($obj == "verification")
                {
                        $data = $_POST;
                        $note_exist = $this->integrationModel->get_note_by_ref($data['Reference_8']);
                        
                        if(isset($note_exist->Id_0))
                        {   
                                $response['code']='200';
                                $response['message']= "La note de perception est récupérée avec succès";
                                $response['id'] = $note_exist->Id_0;
                                // $response = $note_exist->Id_0;
                        }
                        else
                        {
                                //$response = $this->logirad->get_note($data);

                                $response['code'] = $response['code'] ?? 'E000';
                                $response['message'] = $response['message'] ?? 'Aucune réponse réçu de la DGRAD lors de la récupération de la note';
                                $response['id'] = $response['id'] ?? 0;
                        }

                        if(($response['code'] ?? null ) != '200'):
                            
                                echo json_encode($response);
                        
                        else: 

                                $logirad_id = $response['id'];

                                $note = $this->integrationModel->get_paiement_logirad($logirad_id);

                                $check_note = $this->integrationModel->get_note_by_ref($data['Reference_8']);
                                if(isset($check_note->Id_0) && $check_note->Status_2==2)
                                {
                                        return json_encode(['code'=>'E201','message'=>'Cette note de perception a déjà été payée']);
                                }
                                
                                if(isset($note->Id_0))
                                {
                                        $this->ratesModel->get_exchange_rates();
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                        $this->data['recettes'] = $recettes["DGRAD"];
                                        $this->data['encaissement'] =  $this->dataModel->logirad_migrate_note($logirad_id);

                                        //$this->data['logirad'] = $response;
                                        $this->data['note'] = $this->integrationModel->get_paiement_logirad($logirad_id);

                                        $html = view('\Modules\Branch\Views\notes\_step_2', $this->data);

                                        echo json_encode(['code'=>'200','message'=>'success','html'=>$html]);
                                }
                                else
                                {
                                        echo json_encode(['code'=>'E406','message'=>'Une erreur inattendue est survenue lors de la récupération de la note']);
                                }
                        endif;
                }
                elseif($obj == "create")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        
                        //$beneficiary = "'$this->bank_uppercase'";
                        
                        //$agence = $_SESSION['Logiref_guichet'];
                        //$comptes = $this->comptabilisation->get_comptes_array_for_banks("'MAD'", $beneficiary, $agence, []);
                        
                        //$this->data['compte_mad'] = isset($comptes['MAD']) ? $comptes['MAD'] : "";
                        
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        echo view('\Modules\Branch\Views\notes\_step_2', $this->data);
                }
                elseif($obj == "edit")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        
                        $this->data['instructions'] = $instructions = $this->comptabilisationModel->get_instructions_dgrad($encaissement->Logirefid_4);
                        $this->data['compte_undefined'] = false;

                        foreach($instructions as $row)
                        {
                                if($row->Compte_9 == '000000000000000000000000' || $row->Compte_13 == '000000000000000000000000')
                                {
                                        $this->data['compte_undefined'] = true;
                                }
                        }
                        
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        $beneficiary = "'$this->bank_uppercase'";
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->comptabilisation->get_comptes_array_for_banks("'MAD'", $beneficiary, $agence, []);
                        
                        $this->data['compte_mad'] = isset($comptes['MAD']) ? $comptes['MAD'] : "";
                        
                        echo view('\Modules\Branch\Views\notes\_step_3', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
						
                        $this->data['instructions'] = $instructions = $this->comptabilisationModel->get_instructions_dgrad(isset($encaissement->Logirefid_4)?$encaissement->Logirefid_4:"");
                        $this->data['compte_undefined'] = false;

                        foreach($instructions as $row)
                        {
                                if($row->Compte_9 == '000000000000000000000000' || $row->Compte_13 == '000000000000000000000000')
                                {
                                        $this->data['compte_undefined'] = true;
                                }
                        }

                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                       
                        echo view('\Modules\Branch\Views\notes\_step_3', $this->data);
                }
                elseif($obj == "instructions_attestation")
                {
                        $end_execution = '';
                        $data = $_POST;

                        $instructions = $this->integrationModel->get_instructions_unvalidated_attestation_dgrad($id);

                        if (empty($instructions))
                        {
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                $infos_exist = json_decode($encaissement->Notereference_30, true);

                                $infos = $data['Infos'];

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                else if (isset($infos_exist['PaidATTESTATION'])) $infos['PaidATTESTATION'] = $paid_attestation = $infos_exist['PaidATTESTATION'] ;

                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];
                                else if (isset($infos_exist['PaidDUPLICATA'])) $infos['PaidDUPLICATA'] = $paid_duplicata = $infos_exist['PaidDUPLICATA'];

                                if (isset($infos['CommissionAttestation']))
                                {
                                        $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                        $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);
                                }
                                else
                                {
                                        if (isset($infos_exist['CommissionAttestation'])) 
                                                $infos['CommissionAttestation'] = $infos_exist['CommissionAttestation'];
                                }

                                if (isset($infos['CommissionDuplicata']))
                                {
                                        $infos['CommissionDuplicata'] = str_replace(' ','',$infos['CommissionDuplicata']);
                                        $infos['CommissionDuplicata'] = str_replace(',','.',$infos['CommissionDuplicata']);
                                }
                                else
                                {
                                        if (isset($infos_exist['CommissionDuplicata'])) 
                                                $infos['CommissionDuplicata'] = $infos_exist['CommissionDuplicata'];
                                }

                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                                $data_attest['Notereference_30'] = json_encode($infos);
                                $pid = $this->encaissementModel->update_payment_tresor_by_ref($data_attest, $data['Logirefid_4']);

                                if ($pid)
                                {
                                        #Impression des attestation - repartition
                                        $commission = 0;
                                        $devise_com = '';

                                        if (isset($paid_duplicata) && $paid_duplicata == "FDA") $paid_attestation = "";

                                        $types = [
                                                'FIA' => $paid_attestation ?? null,
                                                'FDA' => $paid_duplicata ?? null,
                                        ];

                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];

                                        foreach ($types as $code => $paid) 
                                        {
                                                if ($paid === $code) 
                                                {
                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                        {
                                                                $commission = $rules['Valeur'];
                                                                $devise_com = $rules['Unite'];

                                                                if($data['Devise_34'] == $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                                                {
                                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                                }
                                                                else
                                                                {
                                                                        $data['Commission_23'] = $commission;
                                                                        $data['Devise_24'] = $devise_com;
                                                                        
                                                                }

                                                                $data['Type_fees'] = $code;

                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation($data);

                                                                $end_execution = $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                                        }
                                                }
                                        }
                                }

                                #Return
                                if(isset($end_execution) && $end_execution)
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Id_0'];
                                        
                                        echo json_encode($result);
                                }
                                else 
                                {
                                        $result['code'] = 'E305';
                                        $result['id'] = 0;
                                        
                                        echo json_encode($result);
                                }
                        }
                        else
                        {
                                $result['code'] = 'E405';
                                $result['id'] = 0;
                                
                                echo json_encode($result);
                        }
                }
                elseif($obj == "batch_instructions_duplicata")
                {
                        $end_execution = '';
                        $data = $_POST;
                        $logirefid = $id;

                        $instructions = $this->integrationModel->get_instructions_unvalidated_attestation_dgrad($logirefid);

                        if (empty($instructions))
                        {
                                $batch_line = $this->encaissementModel->get_paiements_batch_by_logirefid($logirefid);
                                
                                $data['Taux'] = $batch_line->Taux_22;
                                $data['Devise_12'] = $batch_line->Devise_16;

                                $rules = $this->feesModel->get_charges_for_printed_payment('FDA');

                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                {
                                        $commission = $rules['Valeur'];
                                        $devise_com = $rules['Unite'];

                                        if($batch_line->Devise_20  == $devise_com  && $batch_line->Devise_20 =='CDF')
                                        {
                                                $commission = $commission * $data['Taux_41'];
                                        }

                                        # Base instructions
                                        $data_instructions = [
                                                'Designation_14' => $batch_line->Designation_12 ?? '',
                                                'Beneficaire_15' => $batch_line->Beneficaire_7 ?? '',
                                                'Service_16'     => $batch_line->Service_8 ?? '',
                                                'Typerecette_17' => 'Lot des notes',
                                                'Taux_41'        => $batch_line->Taux_22 ?? '',
                                                'Reference_32'   => $batch_line->Refop_18 ?? '',
                                                'Compte_33'      => $batch_line->Compte_19 ?? '',
                                                'Devise_34'      => $batch_line->Devise_20 ?? '',
                                                'Montant_11'     => $batch_line->Montant_13 ?? 0,
                                                'Devise_12'      => $batch_line->Devise_14 ?? '',
                                                'Commission_23'  => $commission ?? 0,
                                                'Devise_24'      => $devise_com ?? '',
                                                'Type_fees'      => 'FDA',
                                                'Agence_20'      => $_SESSION['Logiref_agence'] ?? '',
                                                'Guichet_21'     => $_SESSION['Logiref_guichet'] ?? '',
                                                'Mode_19'        => $batch_line->Mode_17,
                                        ];

                                        $instructions = $this->comptabilisation->get_instructions_printed_attestation($data_instructions);

                                        $end_execution = $this->comptabilisationModel->save_instructions_dgrad($id, $data_instructions, $instructions, $id);
                                }

                                #Return
                                if(isset($end_execution) && $end_execution)
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $id;
                                        
                                        echo json_encode($result);
                                }
                                else 
                                {
                                        $result['code'] = 'E305';
                                        $result['id'] = 0;
                                        
                                        echo json_encode($result);
                                }
                        }
                        else
                        {
                                $result['code'] = 'E405';
                                $result['id'] = 0;
                                
                                echo json_encode($result);
                        }
                }
                elseif ($obj == "batch_start") 
                {
                        $this->data['step'] = 1;
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];

                        echo view('\Modules\Branch\Views\notes\_batch_start', $this->data);
                } 
                elseif ($obj == "batch_step_2") 
                {
                        $response = [
                                'total_amount'     => 0,
                                'total_lines'      => 0,
                                'valid_lines'      => 0,
                                'invalid_lines'    => 0,
                                'lines'            => [],
                                'rejected'         => [] 
                        ];

                        $verification = [];

                        # Balance
                        $balance = $this->data('get_account_balance', [
                                'account_balance'   => $_POST['account_balance'] ?? '',
                                'account_currency'  => $_POST['account_currency'] ?? 0,
                                'total_to_paid'     => $_POST['Total_to_paid'] ?? '',
                                'total_to_currency' => $_POST['Notedevise'] ?? '',
                        ]);

                        if ($balance['code'] == "KO")
                        {
                                echo $balance['code'];
                                die;
                        }

                        $data_batch = $_POST['batch_excel_data'] ?? '';
                        $data_batch = html_entity_decode($data_batch, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                        $notes      = json_decode($data_batch, true) ?: [];

                        $verification = $this->data('batch_verification_notes', $notes);

                        $response['total_amount'] = $verification['total_amount'];

                        foreach ($verification['notes'] as $line) 
                        {
                                if ($line['status'] === 'error') 
                                {
                                        $response['invalid_lines']++;

                                        $response['rejected'][] = [
                                                'ligne'    => $line['ligne'],
                                                'recette'  => $line['recette'],
                                                'numero'   => $line['numero'],
                                                'montant'  => $line['montant'],
                                                'devise'   => $line['devise'],
                                                'raison'   => 'API_ERROR',
                                                'api_code' => $line['api_code']
                                        ];
                                } 
                                else 
                                {
                                        $response['validated'][] = [
                                                'ligne'     => $line['ligne'],
                                                'recette'  => $line['recette'],
                                                'numero'    => $line['numero'],
                                                'montant'   => $line['montant'],
                                                'devise'    => $line['devise'],
                                                'api_code'  => $line['api_code'],
                                                'status'    => $line['status']
                                        ];

                                        $response['valid_lines']++;
                                }

                                $response['lines'][] = [
                                        'ligne'    => $line['ligne'],
                                        'numero'   => $line['numero'],
                                        'recette'  => $line['recette'],
                                        'montant'  => $line['montant'],
                                        'devise'   => $line['devise'],
                                        'api_code' => $line['api_code'],
                                        'status'   => $line['status']
                                ];

                                $response['total_lines']++;
                        }
                        
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $services = $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);

                        $this->data['recettes']           = $recettes["DGRAD"];
                        $this->data['services']           =  $services;
                        $this->data['total_to_paid']      = $_POST["Total_to_paid"] ?? 0;
                        $this->data['totalpaid_currency'] = $_POST["TotalDevise"] ?? '';
                        $this->data['montant_note']       = $response['total_amount']  ??  ($_POST['Montant_11'] ?? 0);
                        $this->data['devise_note']        = $_POST["Notedevise"] ?? '';
                        $this->data['notes']              = $response['lines'] ?? [];
                        $this->data['total_lines']        = $response['total_lines'] ?? "";
                        $this->data['total_com']          = $_POST['Total_commission'] ?? 0;
                        $this->data['commission']         = $_POST['Commission'] ?? 0;
                        $this->data['commission_lot']     = $_POST['Commission_lot'] ?? 0;
                        $this->data['com_attestation']    = $_POST['Commission_attestation'] ?? 0;
                        $this->data['com_currency']       = $_POST['Commission_currency'] ?? "";
                        $this->data['account']            = $_POST['Compte'] ?? '';
                        $this->data['acurrency']          = $_POST['cDevise'] ?? '';
                        $this->data['accountname']        = $_POST['accountname'] ?? "";
                        $this->data['refOp']              = $_POST['Reference'] ?? "";
                        $this->data['mode']               = $_POST['Mode'] ?? "";
                        $this->data['taux']               = $_POST['Taux'] ?? '1';
                        $this->data['designation']        = $_POST['Designation'] ?? '';
                        $this->data['regie']              = $_POST['Beneficaire'] ?? '';
                        $this->data['service']            = $_POST['Service'] ?? '';
                        $this->data['recette']            = $_POST['Typerecette'] ?? '';
                        $this->data['nif']                = $_POST['Nif'] ?? '';
                        $this->data['notedate']           = $_POST['Notedate'] ?? '';
                        $this->data['paid_attestation']   = $_POST['PaidATTESTATION'] ?? '';
                        $this->data['tauxflag']           = $_POST['Tauxflag'] ?? 0;
                        
                        echo view('\Modules\Branch\Views\notes\_batch_step_2', $this->data);
                }
                elseif($obj=="preview_batch")
                {
                        $batch_lines = $this->encaissementModel->get_paiement_batch_info($id);

                        if(empty($batch_lines))
                        {
                                #batch inexistant
                                echo 0;
                        }
                        else
                        {
                                $notes = json_decode($batch_lines->Paiements_23, true);

                                $i = 1;
                                for($i=1; $i<=count($notes['references']); $i++) 
                                {
                                        $note = new \stdClass();

                                        $amount = str_replace(' ', '', $notes['amounts'][$i]);
                                        $amount = str_replace(',','.', $amount);

                                        $note->recette = $notes['recettes'][$i];
                                        $note->reference = $notes['references'][$i];
                                        $note->devise = $notes['devises'][$i];
                                        $note->amount = $amount;

                                        $tables[] = $note;
                                }

                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);

                                $this->data['failds'] = $tables;
                                $this->data['batch_lines'] = $batch_lines;

                                echo view('\Modules\Branch\Views\notes\_batch_step_3', $this->data);
                        }
                }
                elseif($obj == "edit_batch")
                {
                        $batch_lines = $this->encaissementModel->get_paiement_batch_info($id);
                        $notes = json_decode($batch_lines->Paiements_23, true);

                        $i = 1;
                        for($i=1; $i<=count($notes['references']); $i++) 
                        {
                                $note = new \stdClass();

                                $amount = str_replace(' ', '', $notes['amounts'][$i]);
                                $amount = str_replace(',','.', $amount);

                                $note->recette = $notes['recettes'][$i];
                                $note->reference = $notes['references'][$i];
                                $note->devise = $notes['devises'][$i];
                                $note->amount = $amount;

                                $tables[] = $note;
                        }

                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                        $this->data['failds'] = $tables;
                        $this->data['batch_lines'] = $batch_lines;

                        echo view('\Modules\Branch\Views\notes\_batch_step_2_process', $this->data);                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        $commission_attestation = 0;

                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if($error !='')
                        {
                                echo '<div class="alert aDanger">Error! veuillez pr&eacute;&ccedil;iser le montant pay&eacute;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        }
                        # If form is validate successfullly
                        else
                        {
                                $data = array();
                                $data_id_paiement = array();
                                $arrondi = 0;

                                $data = $_POST;
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Notedate_27'] = strftime('%Y-%m-%d', strtotime($data['Notedate_27']));
                                $data['Datevaleur_31'] = strftime('%Y-%m-%d', strtotime($data['Datevaleur_31']));
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true)) $data['Makerid_9'] = $this->session->userdata['user_id'];
                                $benificiaire = $data['Beneficaire_15'] = 'DGRAD';
                                $infos = $data['Infos'];
                                
                                // Test if the total_amount has been calculated
                                if($infos['totalMontant'] == "")
                                {
                                        $infos['totalMontant'] = $this->encaissementModel->get_montant_total($data);
                                }
                                else
                                {   
                                        if($data['Mode_19'] == '5')
                                        {
                                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                                {
                                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                                        {
                                                                $total_amount_payed = $infos['totalMontant'];
                                                                $real_total_amount = $this->encaissementModel->get_montant_total($data);

                                                                $arrondi = $total_amount_payed - $real_total_amount; 
                                                        }
                                                }
                                        }
                                }

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                                if (isset($infos['CommissionAttestation']))
                                {
                                        $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                        $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);

                                        $commission_attestation = $infos['CommissionAttestation'];
                                }
                                
                                #Invoque the API account.info to retrieve the client informations
                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);
                                
                                
                                $data['Artbudgetaire_18'] = $infos['standard'];
                                $data['Notereference_30'] = json_encode($infos);
                                unset($data['Infos']);
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                                $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                    
                                #Contre valeur en CDF
                                $data['Devise_42'] = $data['Devise_12'];
                                $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                                # SAVE PAYMENT
                                # Check if it's a new payment
                                
                                if($data['Id_0']=="" || $data['Id_0']==0)
                                {
                                        unset($data['Id_0']);
                                        $ref = $this->encaissementModel->get_id_by_reference($data['Logirefid_4']);
                                        
                                        $data['Id_0'] = $ref;
                                }
                                
                                # Encaissement existant
                                if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                                {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                                        {
                                                /*
                                                * ------------------------------------------------
                                                * Variable initialization for payment validation
                                                * ------------------------------------------------
                                                */
                                                $id =  $data['Id_0'];

                                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                                $infos = json_decode($encaissement->Notereference_30, true);

                                                $result = array();

                                                # Nom du core banking
                                                $core_banking = strtolower($this->core_banking);

                                                # Vérifier si la méthode existe dans la classe
                                                if (method_exists($this->{$core_banking}, 'validate_payment'))
                                                {
                                                        $return = $this->{$core_banking}->validate_payment($data);

                                                        $result = json_decode($return, true);

                                                        $validation_code = (string) ($result['response'] ?? $result['code'] ?? '');
                                                        if($validation_code === '200' || $result['code'] === 'E200')
                                                        {
                                                                $result['Notereference'] = json_decode($data['Notereference_30'], true);
                                                                $result['Num_evenement'] = isset($result['Num_evenement']) ? $result['Num_evenement'] : "";
                                                                $logirefid = $data['Logirefid_4'];

                                                                /*$logiradResponse = $this->logirad->confirm_note($data);

                                                                if(isset($logiradResponse['code']) && ($logiradResponse['code']==200 || $logiradResponse['code']==201))
                                                                {
                                                                        $logirad_data['Status_2'] = 2;
                                                                        $logirad_data['Changes_5'] = gmdate('Y-m-d h:i:s');
                                                                        $logirad_data['Changer_6'] = $this->session->userdata['user_id'] ?? "";
                                                                        $this->integrationModel->update_note_by_ref($logirad_data, $data['Noteid_26'] ?? "");
                                                                }*/

                                                                // Pour eviter la modification du paeiment par le validateur
                                                                $data = array();

                                                                $data['Id_0'] = $id;
                                                                $data['Logirefid_4'] = $logirefid;
                                                                $data['Status_2'] = 2;
                                                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                                $data['Notereference_30'] = json_encode($infos);
                                                                $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                                if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                                                {
                                                                        $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                                                        $infos = json_decode($encaissement->Notereference_30, true);

                                                                        if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                                        if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                                        $data['Notereference_30'] = json_encode( $infos);
                                                                }

                                                                $result['id'] = $id;

                                                                $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                                        }

                                                        // Uniformiser la réponse AJAX de validation : le service Temenos
                                                        // renvoie parfois `response`/`code` sans l'identifiant du paiement.
                                                        // L'étape 3 en a besoin pour charger l'aperçu.
                                                        $return_payload = is_string($return) ? json_decode($return, true) : $return;
                                                        if (!is_array($return_payload)) {
                                                                $return_payload = ['code' => 'E411'];
                                                        }
                                                        $return_code = (string) ($return_payload['response'] ?? $return_payload['code'] ?? '');
                                                        if ($return_code === '200' || ($return_payload['code'] ?? '') === 'E200') {
                                                                $return_payload['id'] = $id;
                                                                $return_payload['code'] = 'E200';
                                                                $return_payload['response'] = 200;
                                                        }
                                                        echo json_encode($return_payload, JSON_UNESCAPED_UNICODE); die;
                                                }
                                                else
                                                {
                                                        //$result['code'] = 'E407';
                                                        echo json_encode($result); die;
                                                }
                                        }
                                        else
                                        {
                                                $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                                $this->comptabilisationModel->delete_instructions_dgrad($data['Logirefid_4']);

                                                # Save changes
                                                $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                        }
                                }
                                # Nouvel encaissement
                                else
                                {
                                        #Enregistrement
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        
                                        # Retrieve the last id
                                        $last_id = $this->encaissementModel->get_last_paiement_id();
                                        $next_id = $last_id + 1;
                                        
                                        $pid = $next_id.$data['Typerecette_17'].$data['Service_16'];
                                        $data['Paiementkey_50'] = rand(1, 99).date('H').date('i').date('s').$pid.date('j').date('m').date('y').$this->session->userdata['user_id'];
                                        
                                        $instructions = array();
                                        $logiref_id = $data['Logirefid_4'];
                                        if($data['Id_0'] == 0) $data['Id_0'] = NULL;
                                        
                                        $return['response'] ='200';

                                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                                        $rType = $type_recettes[$data['Typerecette_17']];
                                        
                                        
                                        if($rType=='TRESOR' || $rType=='RFTRESD')
                                        {
                                                $pid = $this->encaissementModel->save_payment_tresor($data, NULL);
                                        }
                                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                                        {
                                                $pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                        }

                                        $data['Id_0'] = $pid;
                                } 
                                
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true) && $pid == true)
                                {
                                        if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                        {
                                                if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                                {
                                                        # Get the instruction for the roundings when the payment method is cash
                                                        if($arrondi > 0)
                                                        {
                                                                $data ['arrondi'] = $arrondi;
                                                        }
                                                }
                                        }
                                        
                                        if(isset($infos['correspondent_fees']))
                                        {
                                                $data['correspondent_fees'] = $infos['correspondent_fees'];
                                                $data['correspondent_fees_currency'] = $infos['correspondent_fees_currency'];
                                        }
                                        else
                                        {
                                                $data['correspondent_fees'] = 0;
                                                $data['correspondent_fees_currency'] = 'USD';
                                        }
                                                
                                        #Comptabilisation
                                        $instructions = $this->comptabilisation->get_instructions_dgrad($data);
                                        
                                        if(isset($data['arrondi'])) unset($data ['arrondi']);

                                        if(!empty($instructions))
                                        {
                                                $end_execution = $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                        }

                                        #Impression des attestation - repartition
                                        if(isset($this->options['ALL']['bank-charges-attestation-printing']) &&  $commission_attestation >0)
                                        {
                                                $commission = 0;
                                                $devise_com = '';

                                                $types = [
                                                        'FIA' => $paid_attestation ?? null,
                                                        'FDA' => $paid_duplicata ?? null,
                                                ];

                                                foreach ($types as $code => $paid) 
                                                {
                                                        if ($paid === $code) 
                                                        {
                                                                $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                                {
                                                                        $commission = $rules['Valeur'];
                                                                        $devise_com = $rules['Unite'];

                                                                        if($data['Devise_34'] == $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                                                        {
                                                                                $data['Commission_23'] = $commission * $data['Taux_41'];
                                                                        }
                                                                        else
                                                                        {
                                                                                $data['Commission_23'] = $commission;
                                                                                $data['Devise_24'] = $devise_com;
                                                                        }

                                                                        $data['Type_fees'] = $code;

                                                                        $instructions = $this->comptabilisation->get_instructions_printed_attestation($data);
                                                                        $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                                                }
                                                        }
                                                }
                                        }
                                }
                                
                                #Return
                                if($pid)
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Id_0'];

                                        echo json_encode($result);
                                }
                                else 
                                {
                                        $result['code'] = 'E305';
                                        $result['id'] = 0;
                                
                                        echo json_encode($result);
                                }
                        }
                }
                elseif ($obj == "paid_attestation")
                {
                        $data =$_POST;

                        #Is this a validation? Yes if it's a validator or the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true))
                        {
                                /*
                                * ------------------------------------------------
                                * Variable initialization for payment validation
                                * ------------------------------------------------
                                */
                                
                                $id =  $data['Id_0'];

                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                $infos = json_decode($encaissement->Notereference_30, true);
                                
                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);
                                
                                # Vérifier si la méthode existe dans la classe
                                if (method_exists($this->{$core_banking}, 'validate_payment')) 
                                { 
                                        $return = $this->{$core_banking}->virement_bank_charge_exception($data);

                                        $result = json_decode($return, true);
                                                        
                                        if($result['code'] == '200')
                                        {
                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                $logirefid = $data['Logirefid_4'];
                                                
                                                if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                $data_attest = array();
                                                $data_attest['Id_0'] = $id;
                                                $data_attest['Logirefid_4'] = $logirefid;
                                                $data_attest['Notereference_30'] = json_encode( $infos);
                                                $data_attest['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                $result['id'] = $id;
                                                
                                                $pid = $this->encaissementModel->update_payment_tresor_by_ref($data_attest, $data['Logirefid_4']);
                                        }
                                                                                        
                                        echo $return; die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                                echo json_encode($result); die;
                        }
                }
                elseif ($obj == "batch_attest_dup")
                {
                        $data =$_POST;

                        #Is this a validation? Yes if it's a validator or the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true))
                        {
                                $batch_line = $this->encaissementModel->get_paiement_batch_info($id);

                                $infos = json_decode($batch_line->Notereference_34, true);
                                
                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);
                                
                                # Vérifier si la méthode existe dans la classe
                                if (method_exists($this->{$core_banking}, 'validate_payment')) 
                                { 
                                        $data_api['Id_0']           = $batch_line->Lot_24;
                                        $data_api['Beneficaire_15'] = $batch_line->Beneficaire_7;
                                        $data_api['Designation_14'] = $batch_line->Designation_12;
                                        $data_api['Taux_41']        = $batch_line->Taux_22;
                                        $data_api['Logirefid_4']    = $batch_line->Lot_24;
                                        $data_api['Account_3']      = $_SESSION['userdata']['account_id'] ?? "";
                                        $data_api['Mode']           = 'Batch';

                                        $return = $this->{$core_banking}->virement_bank_charge_exception($data_api);

                                        $result = json_decode($return, true);
                                                        
                                        if($result['code'] == '200')
                                        {
                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                $logirefid = $batch_line->Lot_24;
                                                
                                                $infos['paid_attestation'] = "FDA";

                                                $data_attest = array();
                                                $data_attest['Notereference_34'] = json_encode( $infos);
                                                $data_attest['Validation_31'] = gmdate('Y-m-d H:i:s');

                                                $result['id'] = $id;

                                                $pid = $this->encaissementModel->save_payment_tresor_batch($data_attest, $id);
                                        }
                                                                                        
                                        echo $return; die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                                echo json_encode($result); die;
                        }
                }
                elseif ($obj == "payment_validate_taux")
                {
                        $result = array();
                        $data_to_taux = array();

                        $data = $_POST;

                        #Is this a validation? Yes if it's a the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                        {
                                if ($arg == 'batch')
                                {
                                        $data_to_taux['Tauxflag_28'] = 2;
                                        $tid = $this->encaissementModel->save_payment_tresor_batch($data_to_taux, $id);
                                }
                                else
                                {
                                        $id =  $data['Id_0'];

                                        $data_to_taux['Tauxflag_58'] = 2;
                                        $tid = $this->encaissementModel->update_payment_tresor($data_to_taux, $id);
                                }

                                if ($tid)
                                {
                                        $result['code'] = 'E200';
                                        echo json_encode($result); die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                        }

                        echo json_encode($result); die;

                }
                elseif ($obj == "payment_dismissal_taux")
                {
                        $result = array();
                        $data_to_taux = array();

                        #Is this a validation? Yes if it's a the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                        {
                                if ($arg == 'batch')
                                {
                                        $data_to_taux['Tauxflag_28'] = 5;
                                        $tid = $this->encaissementModel->save_payment_tresor_batch($data_to_taux, $id);
                                }
                                else
                                {
                                        $data_to_taux['Tauxflag_58'] = 5;
                                        $tid = $this->encaissementModel->update_payment_tresor($data_to_taux, $id);
                                }

                                if ($tid)
                                {
                                        $result['code'] = 'E200';
                                        echo json_encode($result); die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                        }

                        echo json_encode($result); die;

                }
                elseif ($obj == "save_batch")
                {
                        $error_code = 0; 
                        $error_description = ''; 
                        $data_return = [];

                        $data_validation = $this->encaissementModel->validate_batch_data();

                        if(($data_validation['code'] ?? '') == 200)
                        {
                                $data_to_batch = $this->encaissementModel->build_notes_batch_data();

                                $pid = $this->encaissementModel->save_payment_tresor_batch($data_to_batch, NULL);
                                
                                if ($pid)
                                {
                                        $instructions = $this->data('build_batch_notes_instructions', $data_to_batch);

                                        if(!empty($instructions))
                                        {
                                                $data_inst = [];

                                                $data_inst['Agence_20']  = $_SESSION['Logiref_agence'] ?? '' ;
                                                $data_inst['Guichet_21'] = $_SESSION['Logiref_guichet'] ?? '';
                                                $data_inst['Mode_19']    = $data_to_batch['Mode_17'];

                                                $logirefid = $data_to_batch['Lot_24'];

                                                $end_execution = $this->comptabilisationModel->save_instructions_dgrad($logirefid, $data_inst, $instructions, $logirefid);

                                                if ($end_execution)
                                                {
                                                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                                                        $notes = json_decode($data_to_batch['Paiements_23'], true);

                                                        $lines = [];
                                                        $count = count($notes['references']);

                                                        for ($i = 1; $i <= $count; $i++) 
                                                        {
                                                                $lines[] = [
                                                                        'recette' => $notes['recettes'][$i] ?? '',
                                                                        'numero'  => $notes['references'][$i] ?? '',
                                                                        'devise'  => $notes['devises'][$i] ?? '',
                                                                        'montant' => $notes['amounts'][$i] ?? 0,
                                                                ];
                                                        }

                                                        foreach ($lines as $line) 
                                                        {
                                                                $data_paiements = $this->encaissementModel->build_payment_data($line, $data_to_batch);
                                                                $rType = $type_recettes[$line['recette']] ?? '';

                                                                if (in_array($rType, ['TRESOR','RFTRESD'])) 
                                                                {
                                                                        $pid = $this->encaissementModel->save_payment_tresor($data_paiements, NULL);
                                                                } 
                                                                elseif (in_array($rType, ['PROPRES','RFPROPD'])) 
                                                                {
                                                                        $pid = $this->encaissementModel->save_payment_propres($data_paiements, NULL);
                                                                }
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = '402'; 
                                                        $error_description = 'Les instructions n’ont pas pu être sauvegardées. Veuillez réessayer.';
                                                }
                                        }
                                        else 
                                        { 
                                                $error_code = '403'; 
                                                $error_description = 'Aucune instruction construite pour ce lot. Veuillez réessayer.';
                                        }
                                }
                                else 
                                {
                                        $error_code = '401'; 
                                        $error_description = 'Paiement non enregistré, un problème est survenu. Veuillez ressaisir.';
                                }
                        }
                        else
                        {
                                $error_code = '405';
                                $error_description = $data_validation['message'];
                        }

                        # Retour utilisateur 
                        if ($error_code != 0) 
                        { 
                                $data_return = [ 
                                        'code'    => $error_code, 
                                        'id'      => '', 
                                        'message' => $error_description 
                                ]; 
                        } 
                        else 
                        { 
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $data_to_batch['Lot_24'], 
                                        'message' => 'Bravo ! Paiement enregistré avec succès.' 
                                ]; 
                        }

                        echo json_encode($data_return); exit;

                }
                elseif ($obj == "update_batch")
                {
                        $error_code = 0; 
                        $error_description = ''; 
                        $data_return = [];

                        $logirefid = $_POST['Logirefid'] ??"";

                        $data_validation = $this->encaissementModel->validate_batch_data();

                        if(($data_validation['code'] ?? '') == 200)
                        {
                                $data_to_batch = $this->encaissementModel->build_notes_batch_data_updated();

                                $pid = $this->encaissementModel->save_payment_tresor_batch($data_to_batch, $id);
                                
                                if ($pid)
                                {
                                        $this->comptabilisationModel->delete_instructions_dgrad($logirefid);

                                        $paiements = $this->encaissementModel->get_paiements_batch_by_logirefid($logirefid);
                                        $notereference = json_decode($paiements->Notereference_34, true);

                                        $_POST['Commission_lot'] = $notereference['commision_note'];
                                        $_POST['Com_attestation'] = $notereference['comm_attestation'];
                                        $_POST['PaidATTESTATION'] = $notereference['paid_attestation'];

                                        $instructions = $this->data('build_batch_notes_instructions', $data_to_batch);

                                        if(!empty($instructions))
                                        {
                                                $data_inst = [];

                                                $data_inst['Agence_20']  = $_SESSION['Logiref_agence'] ?? '' ;
                                                $data_inst['Guichet_21'] = $_SESSION['Logiref_guichet'] ?? '';
                                                $data_inst['Mode_19']    = $data_to_batch['Mode_17'];

                                                $end_execution = $this->comptabilisationModel->save_instructions_dgrad($logirefid, $data_inst, $instructions, $logirefid);

                                                if ($end_execution)
                                                {
                                                        $this->encaissementModel->delete_paiement_tresor($logirefid);

                                                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                                                        $notes = json_decode($data_to_batch['Paiements_23'], true);

                                                        $lines = [];
                                                        $count = count($notes['references']);

                                                        for ($i = 1; $i <= $count; $i++) 
                                                        {
                                                                $lines[] = [
                                                                        'recette' => $notes['recettes'][$i] ?? '',
                                                                        'numero'  => $notes['references'][$i] ?? '',
                                                                        'devise'  => $notes['devises'][$i] ?? '',
                                                                        'montant' => $notes['amounts'][$i] ?? 0,
                                                                ];
                                                        }

                                                        foreach ($lines as $line) 
                                                        {
                                                                $data_to_batch['Lot_24'] = $logirefid;
                                                                $data_paiements = $this->encaissementModel->build_payment_data($line, $data_to_batch);
                                                                
                                                                $rType = $type_recettes[$line['recette']] ?? '';

                                                                if (in_array($rType, ['TRESOR','RFTRESD'])) 
                                                                {
                                                                        $pid = $this->encaissementModel->save_payment_tresor($data_paiements, NULL);
                                                                } 
                                                                elseif (in_array($rType, ['PROPRES','RFPROPD'])) 
                                                                {
                                                                        $pid = $this->encaissementModel->save_payment_propres($data_paiements, NULL);
                                                                }
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = '402'; 
                                                        $error_description = 'Les instructions n’ont pas pu être sauvegardées. Veuillez réessayer.';
                                                }
                                        }
                                        else 
                                        { 
                                                $error_code = '403'; 
                                                $error_description = 'Aucune instruction construite pour ce lot. Veuillez réessayer.';
                                        }
                                }
                                else 
                                {
                                        $error_code = '401'; 
                                        $error_description = 'Paiement non enregistré, un problème est survenu. Veuillez ressaisir.';
                                }
                        }
                        else
                        {
                                $error_code = '405';
                                $error_description = $data_validation['message'];
                        }

                        # Retour utilisateur 
                        if ($error_code != 0) 
                        { 
                                $data_return = [ 
                                        'code'    => $error_code, 
                                        'id'      => '', 
                                        'message' => $error_description 
                                ]; 
                        } 
                        else 
                        { 
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $logirefid, 
                                        'message' => 'Bravo ! Paiement enregistré avec succès.' 
                                ]; 
                        }

                        echo json_encode($data_return); exit;

                }
                elseif ($obj == "validate_batch")
                {
                        $error_code = 0; 
                        $error_description = ''; 
                        $data_return = [];

                        if($id > 0 && in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true))
                        {
                                $data_api = [];

                                $batch_line = $this->encaissementModel->get_paiement_batch_info($id);

                                $data_api['Id_0']           = $batch_line->Id_0;
                                $data_api['Beneficaire_15'] = $batch_line->Beneficaire_7;
                                $data_api['Designation_14'] = $batch_line->Designation_12;
                                $data_api['Logirefid_4']    = $batch_line->Lot_24;
                                $data_api['Account_3']      = $_SESSION['userdata']['account_id'] ?? "";
                                $data_api['Mode']           = 'Batch';

                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);

                                # Vérifier si la méthode existe dans la classe
                                if (method_exists($this->{$core_banking}, 'validate_payment'))
                                {
                                        $return = $this->{$core_banking}->validate_payment($data_api);
                                        $result = json_decode($return, true);

                                        if($result['code'] == '200')
                                        {
                                                $data_batch_tresor = [];
                                                $data_batch_tresor['Status_2'] = '2';
                                                $data_batch_tresor['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $data_batch_tresor['Changer_6'] = $_SESSION['userdata']['user_id'] ?? "";
                                                $data_batch_tresor['Validation_31'] = gmdate('Y-m-d H:i:s');
                                                $data_batch_tresor['Checkerid_33'] = $_SESSION['userdata']['user_id'] ?? "";

                                                $batchid = $batch_line->Id_0;
                                                $pid = $this->encaissementModel->save_payment_tresor_batch($data_batch_tresor, $batchid);

                                                if ($pid)
                                                {
                                                        $data_tresor = [];
                                                        $data_tresor['Checkerid_10'] = $_SESSION['userdata']['user_id'] ?? "";
                                                        $data_tresor['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                        $logirefid = $batch_line->Lot_24;

                                                        if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                                        {
                                                                $encaissement = $this->encaissementModel->get_paiement_tresor_by_logirefid($logirefid);

                                                                $infos = json_decode($encaissement->Notereference_30, true);
                                                                if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                                if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                                $data_tresor['Notereference_30'] = json_encode( $infos);
                                                        }

                                                        $this->encaissementModel->update_payment_tresor_by_ref($data_tresor, $logirefid);
                                                }
                                                
                                                $error_description = $result['message'];
                                                
                                        }
                                        else
                                        { 
                                                $error_code = $result['code'];
                                                $error_description = $result['message'];
                                        }
                                }
                                else
                                {
                                        $error_code = '407'; 
                                        $error_description = 'Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.';
                                }
                        } 
                        else
                        {
                                $error_code = '409'; 
                                $error_description = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                        }

                        # Retour utilisateur 
                        if ($error_code != 0) 
                        { 
                                $data_return = [ 
                                        'code'    => $error_code, 
                                        'id'      => '', 
                                        'message' => $error_description 
                                ]; 
                        } 
                        else 
                        { 
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $batch_line->Lot_24, 
                                        'message' => $error_description, 
                                ]; 
                        }

                        echo json_encode($data_return); exit;
                } 
                elseif($obj == "delete")
                {
                        $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");                        
                        //$code_recette = $this->input->get('recette');
                        //$rType = $RecetteTYPES[$arg];

                        $rType = $RecetteTYPES[$arg];

                        $pid = 0;
                        
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_propre($id);
                        }
                        if(!$pid)
                        {
                                $this->comptabilisationModel->delete_instructions_dgrad($id);
                        }
                        
                        #Return
                        echo '<div class="alert aSuccess text-white"> Paiement supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        die;
                }
                elseif ($obj == "delete_batch") 
                {
                        $error_code = 0; 
                        $error_description = ''; 
                        $data_return = [];

                        $data_batch_tresor = [];
                        $data_batch_tresor['Status_2'] = '0';
                        $data_batch_tresor['Deletion_29'] = gmdate('Y-m-d H:i:s');
                        $data_batch_tresor['Deletedby_30'] = $_SESSION['userdata']['user_id'] ?? "";

                        $pid = $this->encaissementModel->save_payment_tresor_batch($data_batch_tresor, $id);

                        if ($pid)
                        {
                                $data_tresor = [];
                                $data_tresor['Status_2'] = '0';
                                $data_tresor['Suppression_40'] = gmdate('Y-m-d H:i:s');;

                                $logirefid = $arg;
                                $this->encaissementModel->update_payment_tresor_by_ref($data_tresor, $logirefid);
                        }
                        else 
                        {
                                $error_code = 'E002'; 
                                $error_description = 'Paiement non supprimé, un problème est survenu. Veuillez ressaisir.';
                        }

                        # Retour utilisateur 
                        if ($error_code != 0) 
                        { 
                                $data_return = [ 
                                        'code'    => $error_code, 
                                        'id'      => '', 
                                        'message' => $error_description 
                                ]; 
                        } 
                        else 
                        { 
                                $data_return = [ 
                                        'code'    => 200, 
                                        'id'      => $id, 
                                        'message' => 'Bravo ! Paiement supprimé avec succès.' 
                                ]; 
                        }

                        echo json_encode($data_return); exit;





                }
                elseif($obj == "OBj")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif ($obj == "get_nif") 
                {
                        if(isset($_POST['nif']))
                        {
                                $client = $this->logirefModel->get_clients_by_nif($_POST['nif']);
                                $designation = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                echo $designation;
                        }
                        else
                        {
                                echo '';
                        }
                }
                elseif ($obj == "handle_process_lot_excel_old")
                {
                        # Initialisation sécurisée 
                        $commission = 0; 
                        $com_attestation = 0; 
                        $return = []; 
                        $return_attestation = []; 
                        $response = [
                                'status'           => false,
                                'error'            => null,
                                'message'          => null,
                                'currency'         => null,
                                'commission'       => 0,
                                'com_attestation'  => 0,
                                'commission_total' => 0,
                                'frais_bcc'        => 0,
                                'total_amount'     => 0,
                                'grand_total'      => 0,
                                'total_lines'      => 0,
                                'valid_lines'      => 0,
                                'invalid_lines'    => 0,
                                'lines'            => [], // toutes les lignes valides
                                'rejected'         => [] // détails des lignes rejetées
                        ];

                        # Vérification fichier
                        if (!isset($_FILES['batch_file']) || $_FILES['batch_file']['error'] !== UPLOAD_ERR_OK) 
                        {
                                # fichier absent ou erreur upload
                                $response['error'] = 'E200'; 
                                echo json_encode($response); exit;
                        }

                        $file = $_FILES['batch_file'];
                        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                        if (!in_array($extension, ['xlsx', 'xls'])) 
                        {
                                # extension invalide
                                $response['error'] = 'E202'; 
                                echo json_encode($response); exit;
                        }

                        # Lecture Excel
                        try {
                                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($file['tmp_name']);
                                $reader->setReadDataOnly(true);

                                $spreadsheet = $reader->load($file['tmp_name']);
                                $worksheet   = $spreadsheet->getActiveSheet();
                                $rows        = $worksheet->toArray(null, true, true, true);

                        } catch (\Throwable $e) {

                                $response['error'] = 'E203'; // lecture impossible
                                echo json_encode($response); exit;
                        }

                        # Analyse des lignes
                        $line_index = 1;

                        foreach ($rows as $row) 
                        {
                                # skip header
                                if ($line_index === 1) 
                                { 
                                        $line_index++;
                                        continue;
                                }

                                $recette  = trim($row['A'] ?? '');
                                $numero  = trim($row['B'] ?? '');
                                $montant = (float) ($row['C'] ?? 0);
                                $devise  = strtoupper(trim($row['D'] ?? ''));

                                #Compter la ligne dans le total 
                                $response['total_lines']++;

                                if ($recette === '' || $numero === '' ||$montant <= 0 || $devise === '') 
                                {
                                        $response['invalid_lines']++;
                                        $response['rejected'][] = [ 
                                                'ligne'   => $line_index, 
                                                'recette' => $recette, 
                                                'numero'  => $numero, 
                                                'montant' => $montant, 
                                                'devise'  => $devise, 
                                                'raison'  => 'DONNEES_INVALIDES' 
                                        ];
                                        
                                        $line_index++;
                                        continue;
                                }
                                

                                if ($response['currency'] === null) 
                                        $response['currency'] = $devise;

                                if ($devise !== ($_POST['Notedevise'] ?? $response['currency'])) 
                                {
                                        $response['invalid_lines']++;
                                        $response['rejected'][] = [ 
                                                'ligne'   => $line_index, 
                                                'recette' => $recette, 
                                                'numero'  => $numero, 
                                                'montant' => $montant, 
                                                'devise'  => $devise, 
                                                'raison'  => 'DEVISE_DIFFERENTE' 
                                        ];
                                        
                                        $line_index++;
                                        continue;
                                }

                                # Ligne valide
                                $response['lines'][] = [
                                        'ligne'   => $line_index,
                                        'recette' => $recette, 
                                        'numero'  => $numero,
                                        'montant' => $montant,
                                        'devise'  => $devise
                                ];

                                $response['total_amount'] += $montant;
                                $response['valid_lines']++;

                                $line_index++;
                        }

                        # Résultat final
                        if ($response['total_lines'] === 0) 
                        {
                                $response['error'] = 'AUCUNE_LIGNE_VALIDE';
                                echo json_encode($response); exit;
                        }

                        # Construire un message clair si des rejets existent 
                        if ($response['invalid_lines'] > 0) 
                        { 
                                $msg_parts = []; 
                                
                                foreach ($response['rejected'] as $row) 
                                { 
                                        $raison = $row['raison'] === 'DEVISE_DIFFERENTE' ? "Devise différente ({$row['devise']})" : "Données invalides"; 
                                        $msg_parts[] = "Ligne {$row['ligne']} (Note: {$row['numero']}, Montant: {$row['montant']}) rejetée : {$raison}"; 
                                } 
                                
                                $response['message'] = implode("; ", $msg_parts); 
                        }

                        # Initialisation  
                        $total_amount = $response['total_amount'];

                        if ($response['total_amount'] > 0) 
                        {
                                if(isset($this->options['ALL']['bcc-fees-deduction']) && ($_POST['Notedevise'] ?? '') == 'CDF')
                                        $response['frais_bcc'] = ($response['total_amount'] * 0.5) / 1000;

                                # Commission principale
                                if ((($_POST['Commission'] ?? 0 ) == 0))
                                {
                                        $commission = 0;
                                }
                                else
                                {
                                        $return = $this->data('get_commission', [
                                                'regie'   => $_POST['Beneficaire'] ?? '',
                                                'service' => $_POST['Service'] ?? '',
                                                'recette' => $_POST['Typerecette'] ?? '',
                                                'devise'  => $_POST['Notedevise'] ?? '',
                                                'compte'  => $_POST['Compte'] ?? '',
                                                'mode'    => $_POST['Mode'] ?? '',
                                                'montant' => $response['total_amount'],
                                                'guichet' => $_SESSION['Logiref_guichet'] ?? '',
                                                'taux'    => $_POST['Taux'] ?? '',
                                        ]);

                                        $commission   = $return[0] ?? 0;
                                        $total_amount = $return[2] ?? $response['total_amount'];
                                }


                                # Commission attestation
                                if (!empty($_POST['PaidATTESTATION']))
                                {
                                        if ((($_POST['Commission_attestation'] ?? 0 ) == 0))
                                        {
                                                $com_attestation = 0;
                                        }
                                        else
                                        {
                                                $return_attestation = $this->data('get_com_attestation', [
                                                        'paid_attestation' => $_POST['PaidATTESTATION'] ?? '',
                                                        'paid_duplicata'   => $_POST['PaidDUPLICATA'] ?? '',
                                                        'montant'          => $total_amount ?? 0,
                                                        'devise'           => $response['currency'] ?? '',
                                                        'devise_com'       => $return[1] ?? '',
                                                        'taux'             => $_POST['Taux'] ?? '',
                                                ]);

                                                $com_attestation = $return_attestation[0] ?? 0;
                                        }
                                }
                        }

                        $response['commission']        = $commission ?? 0;
                        $response['com_attestation']   = $com_attestation ?? 0;
                        $response['commission_total']  = $commission + $com_attestation;
                        $response['commission_devise'] = ($return[1] ?? ($return_attestation[1] ?? ''));
                        $response['grand_total']       = ($return_attestation[2] ?? $total_amount) + $response['frais_bcc'];

                        # Balance
                        $return_balance = $this->data('get_account_balance', [
                                'account_balance'   => $_POST['account_balance'] ?? '',
                                'account_currency'  => $_POST['account_currency'] ?? 0,
                                'total_to_paid'     => $response['grand_total'] ?? '',
                                'total_to_currency' => $_POST['Notedevise'] ?? '',
                        ]);

                        $response['balance'] = $return_balance['code'];
                        $response['status'] = true;

                        echo json_encode($response); exit;
                }
                elseif ($obj == "handle_process_lot_excel")
                {
                        # Initialisation sécurisée 
                        $com_attestation = 0; 
                        $tva_attestation = 0;
                        $return = []; 
                        $return_attestation = []; 
                        $response = [
                                'status'           => false,
                                'error'            => null,
                                'message'          => null,
                                'currency'         => null,
                                'commission'       => 0,
                                'tva'              => 0,
                                'com_attestation'  => 0,
                                'commission_total' => 0,
                                'frais_bcc'        => 0,
                                'total_montant'    => 0, // somme des montants bruts
                                'grand_total'      => 0,
                                'total_lines'      => 0,
                                'valid_lines'      => 0,
                                'invalid_lines'    => 0,
                                'lines'            => [], // toutes les lignes valides
                                'rejected'         => []  // détails des lignes rejetées
                        ];

                        # Vérification fichier
                        if (!isset($_FILES['batch_file']) || $_FILES['batch_file']['error'] !== UPLOAD_ERR_OK) 
                        {
                                $response['error'] = 'E200'; 
                                echo json_encode($response); exit;
                        }

                        $file = $_FILES['batch_file'];
                        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                        if (!in_array($extension, ['xlsx', 'xls'])) 
                        {
                                $response['error'] = 'E202'; 
                                echo json_encode($response); exit;
                        }

                        # Lecture Excel
                        try {
                                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($file['tmp_name']);
                                $reader->setReadDataOnly(true);

                                $spreadsheet = $reader->load($file['tmp_name']);
                                $worksheet   = $spreadsheet->getActiveSheet();
                                $rows        = $worksheet->toArray(null, true, true, true);

                        } catch (\Throwable $e) {
                                $response['error'] = 'E203'; 
                                echo json_encode($response); exit;
                        }

                        # Analyse des lignes
                        $line_index = 1;
                        $total_commission = 0;
                        $total_tva        = 0;
                        $commission_line  = 0;

                        foreach ($rows as $row) 
                        {
                                if ($line_index === 1) 
                                {
                                        $line_index++; 
                                        continue; 
                                }

                                $recette  = trim($row['A'] ?? '');
                                $numero   = trim($row['B'] ?? '');
                                $montant  = (float) ($row['C'] ?? 0);
                                $devise   = strtoupper(trim($row['D'] ?? ''));

                                $response['total_lines']++;

                                if ($recette === '' || $numero === '' || $montant <= 0 || $devise === '') 
                                {
                                        $response['invalid_lines']++;
                                        $response['rejected'][] = [
                                                'ligne'   => $line_index,
                                                'recette' => $recette,
                                                'numero'  => $numero,
                                                'montant' => $montant,
                                                'devise'  => $devise,
                                                'raison'  => 'DONNEES_INVALIDES'
                                        ];

                                        $line_index++;
                                        continue;
                                }

                                if ($response['currency'] === null) $response['currency'] = $devise;
                                if ($devise !== ($_POST['Notedevise'] ?? $response['currency'])) 
                                {
                                        $response['invalid_lines']++;
                                        $response['rejected'][] = [
                                                'ligne'   => $line_index,
                                                'recette' => $recette,
                                                'numero'  => $numero,
                                                'montant' => $montant,
                                                'devise'  => $devise,
                                                'raison'  => 'DEVISE_DIFFERENTE'
                                        ];

                                        $line_index++;
                                        continue;
                                }

                                # Ligne valide
                                $response['valid_lines']++;

                                # Commission principale
                                if ((($_POST['Commission'] ?? 0 ) == 0))
                                {
                                        $commission = 0;
                                        $tva        = 0;
                                }
                                else
                                {
                                        # Calcul commission pour cette ligne
                                        $return = $this->data('get_commission', [
                                                'regie'   => $_POST['Beneficaire'] ?? '',
                                                'service' => $_POST['Service'] ?? '',
                                                'recette' => $recette,
                                                'devise'  => $devise,
                                                'compte'  => $_POST['Compte'] ?? '',
                                                'mode'    => $_POST['Mode'] ?? '',
                                                'montant' => $montant,
                                                'guichet' => $_SESSION['Logiref_guichet'] ?? '',
                                                'taux'    => $_POST['Taux'] ?? '',
                                        ]);

                                        $commission = $return[0] ?? 0;
                                        $tva        = $return[1] ?? 0;
                                }

                                $commission_line = $commission;
                                $tva_line        = $tva;

                                # Cumuler séparément
                                $response['total_montant'] += $montant;
                                $total_commission          += $commission_line;
                                $total_tva                 += $tva_line;

                                # Ajouter la ligne enrichie
                                $response['lines'][] = [
                                        'ligne'          => $line_index,
                                        'recette'        => $recette,
                                        'numero'         => $numero,
                                        'montant'        => $montant,
                                        'commission'     => $commission_line,
                                        'devise_comm'    => $return[1] ?? 0,
                                        'tva'            => $tva_line,
                                        'montant_corrige'=> $montant + $commission_line + $tva_line,
                                        'devise'         => $devise
                                ];

                                $line_index++;
                        }

                        if(isset($this->options['ALL']['bcc-fees-deduction']) && ($_POST['Notedevise'] ?? '') == 'CDF')
                                        $response['frais_bcc'] = ($response['total_montant'] * 0.5) / 1000;

                        # Commission attestation (une seule fois)
                        if (!empty($_POST['PaidATTESTATION'])) 
                        {
                                if ((($_POST['Commission_attestation'] ?? 0 ) != 0)) 
                                {
                                        $return_attestation = $this->data('get_com_attestation', [
                                                'paid_attestation' => $_POST['PaidATTESTATION'] ?? '',
                                                'paid_duplicata'   => $_POST['PaidDUPLICATA'] ?? '',
                                                'montant'          => $response['total_montant'] + $total_commission + $total_tva,
                                                'devise'           => $response['currency'] ?? '',
                                                'devise_com'       => $return[2] ?? '',
                                                'taux'             => $_POST['Taux'] ?? '',
                                        ]);

                                        $com_attestation = $return_attestation[0] ?? 0;
                                        $tva_attestation = ($return_attestation[0] ?? 0) * 0.16;
                                }
                        }

                        # Finalisation
                        $response['commission']        = $commission_line;
                        $response['com_attestation']   = $com_attestation;
                        $response['commission_lot']    = $total_commission;
                        $response['commission_total']  = $total_commission + $com_attestation;
                        $response['commission_devise'] = ($return[2] ?? ($return_attestation[1] ?? ''));
                        $response['tva']               = $total_tva + $tva_attestation;
                        $response['charges_total']     = $total_commission + $com_attestation + $total_tva + $tva_attestation;
                        $response['grand_total']       = $response['total_montant'] + $response['charges_total'] + $response['frais_bcc'];

                        # Balance
                        $return_balance = $this->data('get_account_balance', [
                                'account_balance'   => $_POST['account_balance'] ?? '',
                                'account_currency'  => $_POST['account_currency'] ?? 0,
                                'total_to_paid'     => $response['grand_total'] ?? '',
                                'total_to_currency' => $_POST['Notedevise'] ?? '',
                        ]);

                        $response['balance'] = $return_balance['code'];
                        $response['status'] = true;

                        echo json_encode($response); exit;
                }
                elseif ($obj == "get_commission") 
                {
                        $cdata = $data;

                        $montant1 = str_replace(' ', '', $cdata['montant']);

                        $montant2 = str_replace(',', '.', $montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];

                        $rules = $this->feesModel->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        $rules_with_account = $this->feesModel->get_customer_charges($cdata['regie'],$cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte']);
                        $rules_with_mode = $this->feesModel->get_charges_by_paiement_method($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['mode']);

                        if($rules_with_account['fees_found'] == true)
                        {
                                $rules = $rules_with_account;
                        }

                        if($rules_with_mode['fees_found'] == true)
                        {
                                $rules = $rules_with_mode;
                        }

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }
                        
                        if (!empty($com) && $com['com'] != 0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else 
                        {
                                $cdata['commission'] = $cdata['montant'] * 0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        if (isset($this->options['ALL']['client-exchange-rate-override']) && isset($cdata['taux']) && $cdata['taux'] !== "") 
                        {
                                $taux['Dollar_4'] = $cdata['taux'];
                        } 
                        else 
                        {
                                if (isset($_SESSION['Bank_rates'])) $taux = json_decode($_SESSION['Bank_rates'], true);
                                else $taux['Dollar_4'] = 1;
                        }

                        if ($cdata['devise'] == $oDeivise && $oDeivise == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        }
                        else if ($cdata['devise'] == $oDeivise && $oDeivise == 'USD')
                        {
                                if (isset($this->options['ALL']['client-exchange-rate-override']))
                                {
                                        //$cdata['commission'] = $commission  =  $cdata['commission'];
                                        //$cdata['devise']     = $cdata['devise'];
                                        $cdata['tva']        = ($cdata['commission'] * 0.16);
                                } 
                                else
                                {
                                        $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                        $cdata['devise']     = 'CDF';
                                        $cdata['tva']        = ($cdata['commission'] * 0.16);
                                }
                        }
                        else if ($cdata['devise'] == 'USD' && $oDeivise == 'CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission'] * $taux['Dollar_4'];
                                $cdata['devise']     = 'CDF';
                                $cdata['tva']        = ($cdata['commission'] * 0.16);
                        }
                        else if ($cdata['devise'] == 'CDF' && $oDeivise == 'USD')
                        {
                                $cdata['tva'] = ($cdata['commission'] * 0.16);
                        }

                        $ar = array($cdata['commission'] ?? 0, $cdata['tva'] ?? 0, $cdata['devise']);

                        return $ar;
                        exit;
                } 
                elseif($obj == "get_com_attestation")
                {
                        #Impression des attestation - repartition
                        if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                        {
                                $cdata = $data;
                                
                                $commission = 0;
                                $devise_com = '';

                                $types = [
                                        'FIA' => $cdata['paid_attestation'] ?? null,
                                        'FDA' => $cdata['paid_duplicata'] ?? null,
                                ];

                                foreach ($types as $code => $paid) 
                                {
                                        if ($paid === $code) 
                                        {
                                                $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                {
                                                        $commission = $rules['Valeur'];
                                                        $devise_com = $rules['Unite'];

                                                        if($cdata['devise'] == $cdata['devise_com'] && $cdata['devise'] =='CDF')
                                                        {
                                                                $cdata['commission'] = $commission * $cdata['taux'];
                                                        }
                                                        else
                                                        {
                                                                $cdata['commission'] = $commission;
                                                        }
                                                }
                                        }
                                }

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);

                                $return = array($cdata['commission'], $cdata['devise'], $cdata['total']);

                                return $return;
                                exit;
                        }
                }
                elseif($obj == "batch_verification_notes")
                {
                        $result = [
                                'error'         => false,
                                'total_amount'  => 0.0,
                                'notes'         => []
                        ];

                        # drapeau centralisé (mettre true quand l'API sera prête) 
                        $api_available = false;

                        $notes = $data;
                        foreach ($notes as $i => $line) 
                        {
                                # Normalisation et sécurité des champs
                                $ligne   = isset($line['ligne']) ? (int)$line['ligne'] : ($i + 1);
                                $recette = isset($line['recette']) ? trim((string)$line['recette']) : '';
                                $numero  = isset($line['numero']) ? trim((string)$line['numero']) : '';
                                $devise  = isset($line['devise']) ? strtoupper(trim((string)$line['devise'])) : '';

                                $amount  = $line['montant'] ?? 0;
                                $amount  = str_replace([' ', ','], ['', '.'], $amount);

                                $result['total_amount'] += $amount;

                                # Préparer entrée de résultat par défaut
                                $note_out = [
                                        'ligne'   => $ligne,
                                        'recette' => $recette,
                                        'numero'  => $numero,
                                        'montant' => $amount,
                                        'devise'  => $devise,
                                        'api_code'=> null,
                                        # valeur par défaut si API non dispo
                                        'status'  => 'manual_required' 
                                ];

                                # Si l'API est activée, tenter l'appel
                                if ($api_available) 
                                {
                                        try {
                                                $data_api = [];
                                                $data_api['Reference_8'] = $numero;

                                                $response = $this->logirad->get_note($data_api);

                                                // Normaliser la réponse API en string (sécuriser)
                                                $api_code = is_scalar($response) ? (string) $response : json_encode($response);

                                                $note_out['api_code'] = $api_code;

                                                $code_errors = ['E404','E406','E002','E405'];

                                                if (in_array($api_code, $code_errors, true)) 
                                                {
                                                        $note_out['status'] = 'error';

                                                        $result['error'] = true;
                                                }
                                                else 
                                                {
                                                        $note_out['status'] = 'OK';
                                                }

                                        } catch (\Throwable $e) {

                                                # L'appel a échoué (timeout, indisponibilité, exception) -> manual_required
                                                $note_out['api_code'] = 'API_ERROR_EXCEPTION';
                                                $note_out['status'] = 'manual_required';
                                        }
                                } 
                                else 
                                {
                                        # API désactivée : marquer manual_required et api_code explicite
                                        $note_out['api_code'] = 'API_UNAVAILABLE';
                                        $note_out['status']   = 'manual_required';
                                }

                                $result['notes'][] = $note_out;
                        }

                        return $result;
                }
                elseif ($obj == "get_account_balance") 
                {
                        $account_balance  = $data['account_balance'] ?? 0;
                        $currency_balance = $data['account_currency'] ?? '';
                        
                        $amount_to_paid   = $data['total_to_paid'] ?? 0;
                        $currency_to_paid = $data['total_to_currency'] ?? '';

                        # Récupération des taux
                        $rates = json_decode($_SESSION['Bank_rates'] ?? '{}', true);
                        $taux  = $rates['Dollar_4'] ?? 1;

                        # Conversion si nécessaire
                        if ($currency_balance !== $currency_to_paid) 
                        {
                                if ($currency_balance == "USD" && $currency_to_paid == "CDF") :
                                        $account_balance *= $taux;
                                elseif ($currency_balance == "CDF" && $currency_to_paid == "USD"):
                                        $account_balance /= $taux;
                                endif;
                        }

                        # Vérification du solde
                        $code = ($account_balance >= $amount_to_paid) ? 'OK' : 'KO';

                        return [
                                'code' => $code
                        ];
                }
                elseif($obj == "build_batch_notes_instructions")
                {
                        $instructions  = [];
                        $instructions2 = [];

                        # Base instructions
                        $data_instructions = [
                                'Designation_14' => $data['Designation_12'] ?? '',
                                'Beneficaire_15' => $data['Beneficaire_7'] ?? '',
                                'Service_16'     => $data['Service_8'] ?? '',
                                'Typerecette_17' => 'Lot des notes',
                                'Taux_41'        => $data['Taux_22'] ?? '',
                                'Reference_32'   => $data['Refop_18'] ?? '',
                                'Compte_33'      => $data['Compte_19'] ?? '',
                                'Devise_34'      => $data['Devise_20'] ?? '',
                                'Montant_11'     => $data['Montant_13'] ?? 0,
                                'Devise_12'      => $data['Devise_14'] ?? '',
                                'Commission_23'  => $_POST['Commission_lot'] ?? 0,
                                'Devise_24'      => $data['Devise_16'] ?? '',
                                'Noteid_26'      => $data['Noteid_26'] ?? '',
                                'Nif_13'      => $data['Nif_13'] ?? ''
                        ];

                        # Instructions principales
                        $instructions = $this->comptabilisation->get_instructions_dgrad($data_instructions); 
                        
                        # Cas attestation
                        if (isset($this->options['ALL']['bank-charges-attestation-printing']) && ($_POST['PaidATTESTATION'] ?? '') == "FIA") 
                        {
                                unset($data_instructions['Commission_23']);

                                $data_instructions['Commission_23'] = $_POST['Com_attestation'] ?? 0;
                                $data_instructions['Type_fees']     = $_POST['PaidATTESTATION'] ?? '';

                                if ($data_instructions['Commission_23'] > 0)
                                $instructions2 = $this->comptabilisation->get_instructions_printed_attestation($data_instructions);
                        }

                        # Fusionner les deux jeux d’instructions
                        return array_merge($instructions ?? [], $instructions2 ?? []);
                }

        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
