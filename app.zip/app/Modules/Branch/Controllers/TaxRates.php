<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;
use Modules\Services\Finacle\Controllers\Finacle;

class TaxRates extends BaseController {
        /*
        * Presentation: gestion des taux de change
        * Last update:
        * By Glodi on the 06.10.2023
        * *  *************************************************************************************************************************SECTION 1
        */
        /*
        * Presentation: gestion des taux de change
        * Last update:
        * By Glodi on the 06.10.2023
        * *  *************************************************************************************************************************SECTION 1
        */

        public $menus = array('list', 'taux', '');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'rates';
        public $igor;
        public $core_banking;
        public $temenos;
        public $options;
        public $ratesModel;
        public $branchModel;
        public $logirefModel;
        public $dataModel;
        public $mainModel;
        public $synergies;
        public $curlModel;
        public $integrationModel;
        public $amplitude_solidairebanque;
        public $fibridge;
        public $flexcube;
        public $finacle;
        public $temenoscrdb;

        /*
        * Presentation: gestion des taux de change
        * Last update:
        * By Glodi on the 06.10.2023
        * *  *************************************************************************************************************************SECTION 1
        */

        public function __construct()
        {

                parent::__construct();
                /*
                * Module is project
                * Submodule or application is activities
                * function will be set within display function
                * PS: A modifier au besoin!!
                */
                $this->ratesModel = new RatesModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->dataModel = new DataModel();
                $this->mainModel = new MainModel();
                $this->synergies = new Synergies();
                $this->integrationModel = new IntegrationModel();
                $this->options = new Igor();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->finacle = new Finacle();
                $this->temenoscrdb = new TemenosCrdb();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxrates';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();
                /*
                * Control user access to this module
                * If role is not set to access this module, then access denied
                */
                if ($_SESSION['Logiref_role'] > 2)
                {
                        $modules = isset($_SESSION['userdata']['modules']) ? json_decode($_SESSION['userdata']['modules'], true) : '';

                        if(array_key_exists('logiref', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("logiref",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("logiref",$_SESSION['Logiref_module'])))))
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else{
                                $this->data['sidebar'] = '';
                        }
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
        * Manages sidebar menu
        * Must match de third section of the URL
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 2
        */

        public function set($needle)
        {
                if (in_array($needle, $this->menus))
                {
                        $this->index();
                }
        }

        /*
        * Manages all the views
        * View calls are made here
        * * PS: A personnaliser !!
        * *  *************************************************************************************************************************SECTION 3
        */

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "taux")
                {
                        $this->data("default_values_new_taux");
                        $this->data("set_exchange_rates");

                        echo view('\Modules\Branch\Views\rates\_taux', $this->data);
                }
                elseif ($obj == "list")
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown('agences');
                        $this->data['taux'] = $this->ratesModel->get_taux();
                        $cumules = $this->dataModel->get_rates_by_day();
                        $cumulous = $this->dataModel->get_month_of_rates();
                        $this->data['chart'] = $this->dataModel->get_rates_of_last_days($cumules, $cumulous);
                        $this->data("set_exchange_rates");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Branch\Views\rates\taux', $this->data);
                }
                elseif ($obj == "taux_filter")
                {
                        $start = $_POST['start'];
                        $end = $_POST['end'];
                        $agence = $_POST['agence'];

                        $this->data['agences'] = $this->branchModel->get_dropdown('agences');
                        $this->data['taux'] = $this->ratesModel->get_taux_by_filter($agence, $start, $end);
                        //$this->load->model('MY_Main');
                        //$this->load->model('main/mainModel');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Branch\Views\rates\_' . $obj, $this->data);
                }
                #Default
                elseif ($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

                /*
        * Manages all database updates
        * Calls to model's saving methos are made here
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 4
        */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL) {

                if ($obj == 'taux')
                {
                        if ($_POST['usd'] == '0' || $_POST['usd'] == '')
                        {
                                $data_return['msg'] = '<div class="alert aDanger text-white">ERROR! Valeurs incorrectes...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $return = json_encode($data_return);
                                echo $return;
                                die;
                        }
                        elseif (($_SESSION['Logiref_role'] != 4 && $_SESSION['Logiref_role'] != 9) && $_POST['action'] != 'Confirmer')
                        {
                                $data_return['msg'] = '<div class="alert aWarning text-white">Vous ne pouvez pas publier un taux. Veuillez contacter la personne habilet&eacute;e &agrave; le faire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $return = json_encode($data_return);
                                echo $return;
                                die;
                        }
                        else
                        {
                                $dollar = str_replace(' ', '', $_POST['usd']);
                                $dollar = str_replace(',', '.', $dollar);

                                $euro = str_replace(' ', '', $_POST['eur']);
                                $euro = str_replace(',', '.', $euro);

                                $rand = str_replace(' ', '', $_POST['rand']);
                                $rand = str_replace(',', '.', $rand);

                                $pound = str_replace(' ', '', $_POST['pound']);
                                $pound = str_replace(',', '.', $pound);

                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Dollar_4'] = $dollar;
                                $data['Euro_5'] = $euro;
                                $data['Rand_6'] = $rand;
                                $data['Pound_7'] = $pound;
                                $data['Agence_8'] = $_SESSION['Logiref_agence'];
                                $data['Day_9'] = gmdate('Y-m-d');

                                if (isset($_POST['id_taux']) && $_POST['id_taux'] !== '') $id = $_POST['id_taux'];
                                if ($id === '') $id = null;

                                if ($_POST['is_checker'] == 1 && $id !== null)
                                {
                                        $data['Checkerid_11'] = $this->session->userdata['user_id'];
                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');
                                }
                                else
                                {
                                        $this->options = json_decode($_SESSION['userdata']['options'], true);

                                        if(isset($this->options['ALL']['Enabling_rate_publishing_users']))
                                        {
                                                $data['Checkerid_11'] = $data['Makerid_10'] = $this->session->userdata['user_id'];
                                        }
                                        else
                                                {
                                                $data['Checkerid_11'] = 0;
                                                $data['Makerid_10'] = $this->session->userdata['user_id'];
                                        }
                                }

                                if (isset($_POST['id_taux']) && $_POST['id_taux'] != "")
                                {
                                        $id = $_POST['id_taux'];
                                }

                                try {
                                        $cid = $this->ratesModel->save_taux($data, $id);
                                } catch (\Throwable $e) {
                                        log_message('error', '[Rates] Save failed: ' . get_class($e));
                                        $cid = false;
                                }

                                if ($cid !== false && $cid !== null && $cid !== '')
                                {
                                        $data_return = array();

                                        if ($id !== null)
                                        {
                                                $data_return['msg'] = '<div class="alert aSuccess text-white">Bravo! Modification enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $data_return['id'] = $cid;
                                        }
                                        else
                                        {
                                                $data_return['msg'] = '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $data_return['id'] = $cid;
                                        }

                                        try {
                                                $this->data("set_exchange_rates");
                                        } catch (\Throwable $e) {
                                                log_message('error', '[Rates] Saved rate session refresh failed: ' . get_class($e));
                                        }
                                        return $this->response->setJSON($data_return);
                                }
                                return $this->response->setStatusCode(500)->setJSON(['msg' => '<div class="alert aDanger text-white">Le taux n’a pas pu être enregistré. Veuillez réessayer.</div>']);
                        }
                }
                elseif ($obj == "OBJ ")
                {

                }
                elseif ($obj == "OBJ ")
                {

                }
        }

        /*
        * Manages additional data manipuations
        * Arguments could of any type, arrays or strings
        * PS: A modifier uniquement si c'est necessaire!!
        * *  *************************************************************************************************************************SECTION 5
        */

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL) 
        {
                # Exchange rates
                #
                ################################################################################
                if ($obj == "default_values_new_taux")
                {
                        if (isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0) 
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] = '<div class="alert aDanger text-white">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0) 
                        {
                                $this->data['msg'] = '<div class="alert aSuccess text-white">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                if ($bank['Checkerid_11'] == 0):
                                        $this->data['id'] = $bank['Id_0'];
                                else :
                                        $this->data['id'] = '';
                                        $this->data['reset'] = 1;
                                endif;

                                $this->data['bank'] = $bank;
                        }
                        elseif (isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0) 
                        {
                                $this->data['msg'] = '<div class="alert aDanger text-white">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else {
                                $this->data['msg'] = '<div class="alert aWarning text-white">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }

                        $this->data['action'] = '...';

                        if (isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 0) {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;
                        $this->data['id_taux'] = (!empty($bank["Id_0"]))?$bank["Id_0"]:"";

                        if (($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 10) && isset($_SESSION['Exchange_rates'])) {

                                $this->data['action'] = 'Confirmer';
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] = '<div class="alert aDanger text-white">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif (($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 9) && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 1) {

                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] = '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 9) {

                                if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }

                }
                elseif($obj == "set_exchange_rates")
                {
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];
                        $this->ratesModel->get_exchange_rates();
                        # Retrieve options configured based on the bank connected
                        if(isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        if(!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates']=='0')
                        {
                                if (isset($this->options['ALL']['manuel-input-exchange-rate']) || (!isset($this->options['ALL']['manuel-input-exchange-rate']) && !isset($this->options['ALL']['auto-fetch-exchange-rate'])))
                                {
                                        $this->ratesModel->get_exchange_rates();
                                }
                                else
                                {

                                        # ------------------------------------------------
                                        # Initialization
                                        # ------------------------------------------------

                                        $usd = '';
                                        $pound = '';
                                        $eur = '';
                                        $rand = '';

                                        $data['from_currency'] = 'USD';
                                        $data['to_currency'] = 'CDF';
                                        $data['type'] = 'TTB';
                                        $data['language'] = 'P';

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'get_exchange_rate')) 
                                        {
                                                $return = $this->{$core_banking}->get_exchange_rate($data);
                                        }
                                        else
                                        {
                                                $result['code'] = '407';
                                                echo json_encode($result); die;
                                        }

                                        $return = json_decode($return, true);

                                        if(isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                        {
                                                $usd = $return['exchange_rate'];

                                                $data['from_currency'] = 'EUR';
                                                $data['to_currency'] = 'CDF';

                                                $return = $this->igor->get_exchange_rate($data);

                                                $return = json_decode($return, true);

                                                $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                $_POST['usd'] = $usd;
                                                $_POST['eur'] = $eur;
                                                $_POST['rand'] = "";
                                                $_POST['pound'] = "";

                                                $this->save('taux');

                                                $this->ratesModel->get_exchange_rates();
                                        }
                                        elseif(isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                        {
                                                foreach($return['ExchangeRateList'] as $row)
                                                {
                                                        if(isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                        {
                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                        {
                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                        {
                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                        {
                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                }

                                                if($usd != "" && $eur !="")
                                                {
                                                        $_POST['usd'] = $usd;
                                                        $_POST['eur'] = $eur;
                                                        $_POST['rand'] = $rand;
                                                        $_POST['pound'] = $pound;

                                                        $this->save('taux');

                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                        else
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                }
                        }
                }

        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
