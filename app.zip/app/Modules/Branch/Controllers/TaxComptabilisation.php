<?php 
namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;

use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\ComptabilisationModel;

class TaxComptabilisation extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'comptabilisation';
        public $logirefModel;
        public $integrationModel;
        public $comptabilisationModel;
        
        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->logirefModel = new LogirefModel();
                $this->integrationModel = new IntegrationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxcomptabilisation';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                
                
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "get_details")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);
                        
                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgi") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgi($ref);
                        
                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgda") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgda($ref);
                        
                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation_dgda', $this->data);
                }
                elseif($obj == "get_details_dgi_amr_b") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgi_amr_b($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgrad")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgrad($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgrk")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgrk($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation_dgrk', $this->data);
                }
                elseif($obj == "get_details_dgpek")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgpek($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation_dgpek', $this->data);
                }
                elseif($obj == "get_details_passeport")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_passeport($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation_passeport', $this->data);
                }
                elseif($obj == "get_details_permis")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_permis($ref);

                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_immatriculation")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_immatriculation($ref);
                       
                        echo view('\Modules\Branch\Views\comptabilisation\_comptabilisation_immatriculation', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}



        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */