<?php
namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Gesimpots\Controllers\Gesimpots;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

class TaxDeclaration extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Glodi on the 05.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'declarations';
        public $logirefModel;
        public $encaissementModel;
        public $integrationModel;
        public $comptabilisationModel;
        public $accountModel;
        public $ratesModel;
        public $curlModel;
        public $synergies;
        public $comptabilisation;
        public $functionalities;
        public $amplitude;
        public $amplitude_solidairebanque;
        public $igor;
        public $bsqr;
        public $bank;
        public $finacle;
        public $finacle_standardbank;
        public $fibridge;
        public $core_banking;
        public $temenos;
        public $gesimpots;
        public $dataModel;
        public $options;
        public $bank_uppercase;
        public $feesModel;
        public $flexcube;
        public $cyclone;
        public $temenoscrdb;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->logirefModel = new LogirefModel();
                $this->encaissementModel = new EncaissementModel();
                $this->integrationModel = new IntegrationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->dataModel = new DataModel();
                $this->accountModel = new AccountModel();
                $this->ratesModel = new RatesModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->synergies = new Synergies();
                $this->igor = new Igor();
                $this->bsqr = new Bsqr();
                $this->finacle = new Finacle();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->fibridge =new FIBridge();
                $this->gesimpots = new Gesimpots();
                $this->amplitude = new Amplitude();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->comptabilisation = new Comptabilisation();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->cyclone = new Cyclone();
                $this->temenoscrdb = new TemenosCrdb();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxdeclaration';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->encaissementModel->documents;
                $this->data['devises'] = $this->encaissementModel->devises;
                $this->data['modes'] = $this->encaissementModel->modes;
                $this->data['moyens'] = $this->encaissementModel->moyens;
                $this->data['infos'] = $this->encaissementModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];

                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank_uppercase = ucfirst($this->bank);
                }

                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;

                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
	}


	public function index()
	{
                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}


        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
	public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {
                        $this->data['step'] = 1;

                        echo view('\Modules\Branch\Views\declarations\_'.$obj, $this->data);
                }
                if($obj == "start_amr")
                {
                        $this->data['step'] = 1;
                        echo view('\Modules\Branch\Views\declarations\_'.$obj, $this->data);
                }
                elseif($obj == "verification")
                {
                        $data = $_POST;

                        $user = $this->session->userdata["user_id"];
                        $account = $this->session->userdata["account_id"];

                        $data['user'] = $user;
                        $data['account'] = $account;
                        $data['agence'] = $_SESSION['Logiref_guichet'];
                        $data['reference'] = $_POST['Reference_14'];

                        $declaration_exist = $this->integrationModel->get_declaration_by_ref($data['Reference_14']);

                        if(isset($declaration_exist->Id_0))
                        {
                                if($declaration_exist->Status_2 == 2)
                                {
                                        $response = 'E202';
                                }
                                elseif($declaration_exist->Status_2 == 3)
                                {
                                        $response = 'E203';
                                }
                                else{
                                        $response = $declaration_exist->Id_0;
                                }
                        }
                        else
                        {
                                $response = $this->gesimpots->get_declaration($data);
                        }

                        if($response == 'E202' || $response == 'E203' || $response == 'E404' || $response == 'E406' || $response == 'E500' || $response == 'E302'):
                                echo $response;
                        elseif($response == false || $response == ''):
                                # Connexion issues
                                echo "E405";
                        else:

                                $declaration = $this->integrationModel->get_paiement_dgidec($response);

                                if(isset($declaration->Id_0))
                                {
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                                        $this->data['recettes'] = $recettes["DGI"];
                                        $this->data['encaissement'] =  $this->dataModel->dgidec_migrate_declaration($response);
                                        $this->data['declaration'] = $this->integrationModel->get_paiement_dgidec($response);

                                        echo view('\Modules\Branch\Views\declarations\_step_2', $this->data);
                                }
                                else
                                {
                                        echo "E406";
                                }

                        endif;
                }
                elseif($obj == "verification_amr")
                {
                        $data = $_POST;

                        $user = $this->session->userdata["user_id"];
                        $account = $this->session->userdata["account_id"];

                        $data['user'] = $user;
                        $data['account'] = $account;
                        $data['agence'] = $_SESSION['Logiref_guichet'];
                        $data['reference'] = $_POST['Reference_14'];
                        
                        $declaration_exist = $this->integrationModel->get_declaration_by_ref($data['Reference_14']);
                        
                        if(isset($declaration_exist->Id_0))
                        {
                                $response = $declaration_exist->Id_0;
                        }
                        else
                        {
                                //$response = $this->gesimpots->get_declaration($data);
                        }
                        
                        $response = 'E404';
                        
                        if($response == 'E404' || $response == 'E406' || $response == 'E500' || $response == 'E302'):
                                echo $response;
                        elseif($response == false || $response == ''):
                                # Connexion issues
                                echo "E405";
                        else: 
                            
                                $declaration = $this->integrationModel->get_paiement_dgidec($response);
                        
                                if(isset($declaration->Id_0))
                                {
                                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                                        $this->data['recettes'] = $recettes["DGI"];
                                        $this->data['encaissement'] =  $this->dataModel->dgidec_migrate_declaration($response);
                                        
                                        echo view('\Modules\Branch\Views\declarations\_step_2', $this->data);
                                }
                                else
                                {
                                        echo "E406";
                                }
                                
                        endif;
                }
                elseif($obj == "create")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        
                        $this->data['client'] = '';
                        
                        $this->data['encaissement'] = $this->encaissementModel->get_paiement_tresor_info();
                        $this->data['step'] = 2;
                        echo view('\Modules\Branch\Views\declarations\_step_2', $this->data);
                }
                elseif($obj == "create_amr")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        
                        $this->data['client'] = '';
                        
                        $this->data['encaissement'] = $this->encaissementModel->get_paiement_tresor_info();
                        $this->data['step'] = 2;
                        echo view('\Modules\Branch\Views\declarations\_step_2_amr', $this->data);
                }
                elseif($obj == "edit")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        if (!$encaissement) {
                                $this->response->setStatusCode(404);
                                echo '<div class="alert alert-warning">Paiement introuvable.</div>';
                                return;
                        }
                        $this->data['instructions'] = $instructions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);
                        $this->data['compte_undefined'] = false;

                        foreach($instructions as $row)
                        {
                                if($row->Compte_9 == '000000000000000000000000' || $row->Compte_13 == '000000000000000000000000')
                                {
                                        $this->data['compte_undefined'] = true;
                                }
                        }
                        
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        $beneficiary = "'$this->bank_uppercase'";
                        
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->comptabilisation->get_comptes_array_for_banks("'MAD'", $beneficiary, $agence, []);
                        
                        $this->data['compte_mad'] = isset($comptes['MAD']) ? $comptes['MAD'] : "";
                        
                        echo view('\Modules\Branch\Views\declarations\_step_3', $this->data);
                }
                elseif($obj == "edit_amr_a")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = '';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        echo view('\Modules\Branch\Views\declarations\_step_3_amr', $this->data);
                }
                elseif($obj == "preview")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if (!$encaissement) {
                                $this->response->setStatusCode(404);
                                echo '<div class="alert alert-warning">Paiement introuvable.</div>';
                                return;
                        }
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
						
                        $this->data['instructions'] = $instructions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);
                        $this->data['compte_undefined'] = false;

                        foreach($instructions as $row)
                        {
                                if($row->Compte_9 == '000000000000000000000000' || $row->Compte_13 == '000000000000000000000000')
                                {
                                        $this->data['compte_undefined'] = true;
                                }
                        }
                        
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        echo view('\Modules\Branch\Views\declarations\_step_3', $this->data);
                }
                elseif($obj == "preview_amr_a")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        
                        echo view('\Modules\Branch\Views\declarations\_step_3_amr', $this->data);
                }
                elseif($obj == "preview_amr_b")
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        
                        echo view('\Modules\Branch\Views\declarations\_step_3_amr_b', $this->data);
                }
                elseif($obj == "branchless_verification")
                {
                        $this->ratesModel->get_exchange_rates();
                        
                        $recettes = $this->logirefModel->get_dropdown('recettes',"DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province=NULL, true);
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                        $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                        $this->data['view'] = 'view';
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";

                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        echo view('\Modules\Branch\Views\declarations\_branchless_verification', $this->data);

                }
                elseif($obj == "instructions_attestation")
                {
                        $end_execution = '';
                        $data = $_POST;

                        $instructions = $this->integrationModel->get_instructions_unvalidated_attestation_dgi($id);

                        if (empty($instructions))
                        {
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = $_POST['Taux_41'];
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }

                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                $infos_exist = json_decode($encaissement->Notereference_30, true);

                                $infos = $data['Infos'];

                                if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                                else if (isset($infos_exist['PaidATTESTATION'])) $infos['PaidATTESTATION'] = $paid_attestation = $infos_exist['PaidATTESTATION'] ;

                                if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];
                                else if (isset($infos_exist['PaidDUPLICATA'])) $infos['PaidDUPLICATA'] = $paid_duplicata = $infos_exist['PaidDUPLICATA'];

                                if (isset($infos['CommissionAttestation']))
                                {
                                        $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                        $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);
                                }
                                else
                                {
                                        if (isset($infos_exist['CommissionAttestation'])) 
                                                $infos['CommissionAttestation'] = $infos_exist['CommissionAttestation'];
                                }

                                if (isset($infos['CommissionDuplicata']))
                                {
                                        $infos['CommissionDuplicata'] = str_replace(' ','',$infos['CommissionDuplicata']);
                                        $infos['CommissionDuplicata'] = str_replace(',','.',$infos['CommissionDuplicata']);
                                }
                                else
                                {
                                        if (isset($infos_exist['CommissionDuplicata'])) 
                                                $infos['CommissionDuplicata'] = $infos_exist['CommissionDuplicata'];
                                }

                                $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                                $data_attest['Notereference_30'] = json_encode($infos);
                                $pid = $this->encaissementModel->update_payment_tresor_by_ref($data_attest, $data['Logirefid_4']);

                                if ($pid)
                                {
                                        #Impression des attestation - repartition
                                        $commission = 0;
                                        $devise_com = '';

                                        if (isset($paid_duplicata) && $paid_duplicata == "FDA") $paid_attestation = "";

                                        $types = [
                                                'FIA' => $paid_attestation ?? null,
                                                'FDA' => $paid_duplicata ?? null,
                                        ];

                                        foreach ($types as $code => $paid) 
                                        {
                                                if ($paid === $code) 
                                                {
                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                                                        {
                                                                $commission = $rules['Valeur'];
                                                                $devise_com = $rules['Unite'];

                                                                if($data['Devise_34'] == $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                                                {
                                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                                }
                                                                else
                                                                {
                                                                        $data['Commission_23'] = $commission;
                                                                        $data['Devise_24'] = $devise_com;
                                                                        
                                                                }

                                                                $data['Type_fees'] = $code;

                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation($data);

                                                                $end_execution = $this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                                        }
                                                }
                                        }
                                }

                                #Return
                                if(isset($end_execution) && $end_execution)
                                {
                                        $result['code'] = 'E200';
                                        $result['id'] = $data['Id_0'];
                                        
                                        echo json_encode($result);
                                }
                                else 
                                {
                                        $result['code'] = 'E305';
                                        $result['id'] = 0;
                                        
                                        echo json_encode($result);
                                }
                        }
                        else
                        {
                                $result['code'] = 'E405';
                                $result['id'] = 0;
                                
                                echo json_encode($result);
                        }
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        
                        $data = array();
                        $data_id_paiement = array();
                        $result = array();
                        $arrondi = 0;
                        $commission_attestation = 0;

                        if(isset($_POST['Ndeclaration']))
                        {
                                $declaration = $_POST['Ndeclaration'];
                                unset($_POST['Ndeclaration']);
                        }

                        $data = $_POST;

                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Notedate_27'] = strftime('%Y-%m-%d', strtotime($data['Notedate_27']));
                        $data['Datevaleur_31'] = strftime('%Y-%m-%d', strtotime($data['Datevaleur_31']));
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true)) $data['Makerid_9'] = $this->session->userdata['user_id'];
                        $benificiaire = $data['Beneficaire_15'] = 'DGI';
                        $infos = $data['Infos'];

                        // Test if the total_amount has been calculated
                        if($infos['totalMontant'] == "")
                        {
                                $infos['totalMontant'] = $this->encaissementModel->get_montant_total($data);
                        }
                        else
                        {
                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                {
                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities']))
                                        {
                                                if($data['Mode_19'] == '5')
                                                {
                                                        $total_amount_payed = $infos['totalMontant'];
                                                        $real_total_amount = $this->encaissementModel->get_montant_total($data);

                                                        $arrondi = $total_amount_payed - $real_total_amount;
                                                }
                                        }
                                }
                        }

                        // formatage des valeurs des quotas de chaque beneficiaire pour un paiement IPRIER
                        if(isset($data['Typerecette_17'], $infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM'], $infos['QuotasDGI']) && $data['Typerecette_17'] == "IPRIER" && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="" && $infos['QuotasDGI'] !="")
                        {
                                $infos['QuotasINPP'] = str_replace([' ', ','], ['', '.'], $infos['QuotasINPP']);
                                $infos['QuotasINSS'] = str_replace([' ', ','], ['', '.'], $infos['QuotasINSS']);
                                $infos['QuotasONEM'] = str_replace([' ', ','], ['', '.'], $infos['QuotasONEM']);
                                $infos['QuotasDGI'] = str_replace([' ', ','], ['', '.'], $infos['QuotasDGI']);
                        }
                        elseif($data['Typerecette_17'] == "IPRIER" && $infos['QuotasDGI'] != "")
                        {
                                $infos['QuotasDGI'] = str_replace(' ','',$infos['QuotasDGI']);
                                $infos['QuotasDGI'] = str_replace(',','.',$infos['QuotasDGI']);
                        }

                        // formatage des valeurs des quotas de chaque beneficiaire pour un paiement de vente des plaques  
                        if(($data['Typerecette_17'] == "REIMATTRIC" || $data['Typerecette_17'] == "IMMATRIC" || $data['Typerecette_17'] == "MUTATION"  ) && ($infos['MontantTresor'] != "" && $infos['MontantSYNTELL'] !="" && $infos['MontantUTSCH'] !="" && $infos['MontantDGI'] !="" && $infos['MontantSONAS'] !="" && $infos['MontantHOLOGRAMME'] !="" && $infos['MontantRTNC'] !=""))
                        {

                                $infos['MontantTresor'] = str_replace(' ','',$infos['MontantTresor']);
                                $infos['MontantTresor'] = str_replace(',','.',$infos['MontantTresor']);

                                $infos['MontantSYNTELL'] = str_replace(' ','',$infos['MontantSYNTELL']);
                                $infos['MontantSYNTELL'] = str_replace(',','.',$infos['MontantSYNTELL']);

                                $infos['MontantUTSCH'] = str_replace(' ','',$infos['MontantUTSCH']);
                                $infos['MontantUTSCH'] = str_replace(',','.',$infos['MontantUTSCH']);

                                $infos['MontantDGI'] = str_replace(' ','',$infos['MontantDGI']);
                                $infos['MontantDGI'] = str_replace(',','.',$infos['MontantDGI']);

                                $infos['MontantSONAS'] = str_replace(' ','',$infos['MontantSONAS']);
                                $infos['MontantSONAS'] = str_replace(',','.',$infos['MontantSONAS']);

                                $infos['MontantHOLOGRAMME'] = str_replace(' ','',$infos['MontantHOLOGRAMME']);
                                $infos['MontantHOLOGRAMME'] = str_replace(',','.',$infos['MontantHOLOGRAMME']);

                                $infos['MontantRTNC'] = str_replace(' ','',$infos['MontantRTNC']);
                                $infos['MontantRTNC'] = str_replace(',','.',$infos['MontantRTNC']);
                        }

                        // formatage des valeurs des quotas de chaque beneficiaire pour un paiement IRPPDR11
                        if(isset($data['Typerecette_17'], $infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM'], $infos['QuotasDGI']) && $data['Typerecette_17'] == "IRPPDR11" && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="" && $infos['QuotasDGI'] !="")
                        {
                                $infos['QuotasINPP'] = str_replace([' ', ','], ['', '.'], $infos['QuotasINPP']);
                                $infos['QuotasINSS'] = str_replace([' ', ','], ['', '.'], $infos['QuotasINSS']);
                                $infos['QuotasONEM'] = str_replace([' ', ','], ['', '.'], $infos['QuotasONEM']);
                                $infos['QuotasDGI'] = str_replace([' ', ','], ['', '.'], $infos['QuotasDGI']);
                        }
                        elseif($data['Typerecette_17'] == "IRPPDR11" && $infos['QuotasDGI'] != "")
                        {
                                $infos['QuotasDGI'] = str_replace(' ','',$infos['QuotasDGI']);
                                $infos['QuotasDGI'] = str_replace(',','.',$infos['QuotasDGI']);
                        }

                        if (isset($infos['PaidATTESTATION'])) $paid_attestation = $infos['PaidATTESTATION'];
                        if (isset($infos['PaidDUPLICATA'])) $paid_duplicata = $infos['PaidDUPLICATA'];

                        if (isset($infos['CommissionAttestation']))
                        {
                                $infos['CommissionAttestation'] = str_replace(' ','',$infos['CommissionAttestation']);
                                $infos['CommissionAttestation'] = str_replace(',','.',$infos['CommissionAttestation']);

                                $commission_attestation = $infos['CommissionAttestation']; 
                        }

                        $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                        #Taux de change
                        if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                        {
                                $data['Taux_41'] = $_POST['Taux_41'];
                        }
                        else if($data['Devise_12']!='CDF')
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                        }

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                        $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                        $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                        $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);

                        $data['Notereference_30'] = json_encode($infos);

                        unset($data['Infos']);

                        #Contre valeur en CDF
                        $data['Devise_42'] = $data['Devise_12'];
                        $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                        # SAVE PAYMENT
                        # Check if it's a new payment

                        if($data['Id_0']=="" || $data['Id_0']==0)
                        {

                                unset($data['Id_0']);
                                $ref = $this->encaissementModel->get_id_by_reference($data['Logirefid_4']);

                                $data['Id_0'] = $ref;
                        }

                        $persistence = $this->encaissementModel->persistenceConnection();
                        if (!(($data['Id_0'] ?? 0) > 0 && in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true)) && !$persistence->transBegin()) {
                                echo json_encode(['code' => 'E305', 'id' => 0]);
                                return;
                        }
                        try {
                        # Encaissement existant
                        if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Variable initialization for payment validation
                                        * ------------------------------------------------
                                        */

                                        $id =  $data['Id_0'];

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'validate_payment'))
                                        {
                                                $return = $this->{$core_banking}->validate_payment($data);

                                                $result = json_decode($return, true);

                                                if($result['code'] == '200')
                                                {
                                                        $result['Notereference'] = json_decode($data['Notereference_30'], true);
                                                        $result['Num_evenement'] = isset($result['Num_evenement']) ? $result['Num_evenement'] : "";
                                                        $logirefid = $data['Logirefid_4'];

                                                        // Pour eviter la modification du paiement par le validateur
                                                        $data = array();
                                                        $data['Id_0'] = $id;
                                                        $data['Logirefid_4'] = $logirefid;
                                                        $data['Status_2'] = 2;
                                                        $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                        if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                                        {
                                                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                                                $infos = json_decode($encaissement->Notereference_30, true);

                                                                if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                                if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                                $data['Notereference_30'] = json_encode( $infos);
                                                        }

                                                        $result['id'] = $id;

                                                        $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                        $pid = $pid ? $data['Id_0'] : false;

                                                        if($pid){
                                                                $declaration_data['Status_2'] = 3;
                                                                $this->integrationModel->update_declaration_by_ref($declaration_data, $_POST['Noteid_26']);
                                                        }
                                                }

                                                echo $return; die;
                                        }
                                        else
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                                else
                                {

                                        $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                        $this->comptabilisationModel->delete_instructions_dgi($data['Logirefid_4']);

                                        # Save changes
                                        $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                }
                        }
                        # Nouvel encaissement
                        else
                        {
                                #Enregistrement
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $instructions = array();
                                $logiref_id = $data['Logirefid_4'];
                                if($data['Id_0'] == 0) $data['Id_0'] = NULL;

                                $pid = false;
                                $data['Paiementkey_50'] = $data['Logirefid_4'];

                                $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");

                                $rType = $RecetteTYPES[$data['Typerecette_17']];

                                if($rType=='TRESOR' || $rType=='RFTRESD')
                                {
                                       $pid = $this->encaissementModel->save_payment_tresor($data, NULL);
                                }
                                elseif($rType=='PROPRES' || $rType=='RFPROPD')
                                {
                                       $pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                }

                                $data['Id_0'] = $pid;

                                if($pid)
                                {
                                        $declaration_data['Status_2'] = 2;
                                        $this->integrationModel->update_declaration_by_ref($declaration_data, $data['Noteid_26']);
                                }
                        }

                        if (!$pid || !is_numeric($pid) || $pid <= 0) throw new \RuntimeException('Payment persistence failed.');

                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                if($data['Typerecette_17'] == "IPRIER" || $data['Typerecette_17'] == 'IRPPDR11')
                                {
                                        $quotas = ['QuotasINPP', 'QuotasINSS', 'QuotasONEM', 'QuotasDGI'];

                                        if (isset($this->options['DGI']['credit-iprier-total-amount-to-transit-for-institutions']) || isset($this->options['ALL']['credit-first-account-transit-to-credit-institutions-accounts'])) 
                                        {
                                                $data['Montant_11'] = 0;
                                                foreach ($quotas as $quota)
                                                {
                                                        if (isset($infos[$quota]) && $infos[$quota]!= "")
                                                        {
                                                                $data['Montant_11'] += $infos[$quota];
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                $data['Montant_11'] = $infos['QuotasDGI'];
                                        }
                                }

                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                {
                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities']))
                                        {
                                                # Get the instruction for the roundings when the payment method is cash
                                                if($arrondi > 0)
                                                {
                                                        $data ['arrondi'] = $arrondi;
                                                }
                                        }
                                }

                                #Comptabilisation
                                $instructions = $this->comptabilisation->get_instructions_dgi($data);


                                if(isset($data ['arrondi'])) unset($data ['arrondi']);

                                if (empty($instructions)) throw new \RuntimeException('DGI instructions unavailable.');
                                if(!empty($instructions))
                                {
                                        if (!$this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4'])) throw new \RuntimeException('DGI instructions persistence failed.');
                                }

                                #Guichet Unique DGI - repartition
                                if(isset($data['Typerecette_17'], $infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM']) && ($data['Typerecette_17'] == 'IPRIER' || $data['Typerecette_17'] == 'IRPPDR11') && $infos['QuotasINPP'] != "" && $infos['QuotasINSS'] !="" && $infos['QuotasONEM'] !="")
                                {
                                        $instructions = $this->comptabilisation->get_instructions_gu_dgi($data);

                                        if (!$this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4'])) throw new \RuntimeException('DGI instructions persistence failed.');
                                }
                                #Vente Plaque - repartition
                                if(($data['Typerecette_17'] == "REIMATTRIC" || $data['Typerecette_17'] == "IMMATRIC" || $data['Typerecette_17'] == "MUTATION"  ) && ($infos['MontantTresor'] != "" && $infos['MontantSYNTELL'] !="" && $infos['MontantUTSCH'] !="" && $infos['MontantDGI'] !="" && $infos['MontantSONAS'] !="" && $infos['MontantHOLOGRAMME'] !="" && $infos['MontantRTNC'] !=""))
                                {
                                        $instructions = $this->comptabilisationModel->get_instructions_vente_gu_dgi($data, null, null);
                                        if (!$this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4'])) throw new \RuntimeException('DGI instructions persistence failed.');
                                }
                                #Impression des attestation - repartition
                                if(isset($this->options['ALL']['bank-charges-attestation-printing']) && $commission_attestation > 0)
                                {
                                        $commission = 0;
                                        $devise_com = '';

                                        $types = [
                                                'FIA' => $paid_attestation ?? null,
                                                'FDA' => $paid_duplicata ?? null,
                                        ];

                                        foreach ($types as $code => $paid)
                                        {
                                                if ($paid === $code)
                                                {
                                                        $rules = $this->feesModel->get_charges_for_printed_payment($code);

                                                        if (!empty($rules['Valeur']) && !empty($rules['Unite']))
                                                        {
                                                                $commission = $rules['Valeur'];
                                                                $devise_com = $rules['Unite'];

                                                                if($data['Devise_34'] == $data['Devise_24'] && $data['Devise_34'] =='CDF')
                                                                {
                                                                        $data['Commission_23'] = $commission * $data['Taux_41'];
                                                                }
                                                                else
                                                                {
                                                                        $data['Commission_23'] = $commission;
                                                                        $data['Devise_24'] = $devise_com;
                                                                }

                                                                $data['Type_fees'] = $code;

                                                                $instructions = $this->comptabilisation->get_instructions_printed_attestation($data);

                                                                if (!$this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4'])) throw new \RuntimeException('DGI instructions persistence failed.');
                                                        }
                                                }
                                        }
                                }
                        }

                        #Return
                        if ($pid > 0 && $persistence->transStatus() && $persistence->transCommit())
                        {
                                $result['code'] = 'E200';
                                $result['id'] = $data['Id_0'];

                                echo json_encode($result);
                        }
                        else
                        {
                                $persistence->transRollback();
                                $result['code'] = 'E305';
                                $result['id'] = 0;

                                echo json_encode($result);
                        }
                        } catch (\Throwable $e) {
                                $persistence->transRollback();
                                log_message('error', 'Declaration persistence failed: {error}', ['error' => $e->getMessage()]);
                                echo json_encode(['code' => 'E305', 'id' => 0]);
                        }
                }
                elseif ($obj == "paid_attestation")
                {
                        $data = $_POST;

                        #Is this a validation? Yes if it's a validator or the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                        {
                                /*
                                * ------------------------------------------------
                                * Variable initialization for payment validation
                                * ------------------------------------------------
                                */
                                
                                $id =  $data['Id_0'];

                                $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                $infos = json_decode($encaissement->Notereference_30, true);
                                
                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);
                                
                                # Vérifier si la méthode existe dans la classe
                                if (method_exists($this->{$core_banking}, 'validate_payment'))
                                {
                                        $return = $this->{$core_banking}->virement_bank_charge_exception($data);

                                        $result = json_decode($return, true);

                                        if($result['code'] == '200')
                                        {
                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                $logirefid = $data['Logirefid_4'];

                                                if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                $data_attest = array();
                                                $data_attest['Id_0'] = $id;
                                                $data_attest['Logirefid_4'] = $logirefid;
                                                $data_attest['Notereference_30'] = json_encode($infos);
                                                $data_attest['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                $result['id'] = $id;

                                                if(isset($this->options['ALL']['bank-charges-attestation-printing']))
                                                {
                                                        $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                                                        $infos = json_decode($encaissement->Notereference_30, true);

                                                        if (isset($infos['PaidATTESTATION']))  $infos['PaidAttest'] = "1";
                                                        if (isset($infos['PaidDUPLICATA'])) $infos['PaidAttestDup'] = "1";

                                                        $data['Notereference_30'] = json_encode( $infos);
                                                }

                                                $pid = $this->encaissementModel->update_payment_tresor_by_ref($data_attest, $data['Logirefid_4']);
                                        }

                                        echo $return; die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                                echo json_encode($result); die;
                        }
                }
                elseif ($obj == "payment_validate_taux")
                {
                        $result = array();
                        $data_to_taux = array();

                        $data = $_POST;

                        #Is this a validation? Yes if it's a the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                        {
                                $id =  $data['Id_0'];
                                $data_to_taux['Tauxflag_58'] = 2;

                                $tid = $this->encaissementModel->update_payment_tresor($data_to_taux, $id);

                                if ($tid)
                                {
                                        $result['code'] = 'E200';
                                        echo json_encode($result); die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                        }

                        echo json_encode($result); die;

                }
                elseif ($obj == "payment_dismissal_taux")
                {
                        $result = array();
                        $data_to_taux = array();

                        #Is this a validation? Yes if it's a the supervisor
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                        {
                                $data_to_taux['Tauxflag_58'] = 5;

                                $tid = $this->encaissementModel->update_payment_tresor($data_to_taux, $id);

                                if ($tid)
                                {
                                        $result['code'] = 'E200';
                                        echo json_encode($result); die;
                                }
                                else 
                                {
                                        $result['code'] = 'E407';
                                        echo json_encode($result); die;
                                }
                        }
                        else 
                        {
                                $result['code'] = 'E405';
                        }

                        echo json_encode($result); die;

                }
                elseif($obj == "comptant_amr")
                {
                        # Save payment
                          
                        $data = array();
                        $data_id_paiement = array();
                        $instructions = array();
                        $instruction = array();
                        $arrondi = 0;
                        $tresorid = 0;
                        $properid = 0;
                        $return = array();

                        $data = $_POST;

                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true)) $data['Makerid_9'] = $this->session->userdata['user_id'];
                        $benificiaire = $data['Beneficaire_15'] = 'DGI';
                        $infos = $data['Infos'];

                        // Test if the total_amount has been calculated
                        if($infos['totalMontant'] == "")
                        {
                                $infos['totalMontant'] = $this->encaissementModel->get_montant_total($data);
                        }
                        else
                        {   
                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                {
                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                        {
                                                if($data['Mode_19'] == '5')
                                                {
                                                        $total_amount_payed = $infos['totalMontant'];
                                                        $real_total_amount = $this->encaissementModel->get_montant_total($data);

                                                        $arrondi = $total_amount_payed - $real_total_amount; 
                                                }
                                        } 
                                }
                        }
                        
                        $infos['montant_amr_b'] = str_replace(' ','',$infos['montant_amr_b']);
                        $infos['montant_amr_b'] = str_replace(',','.',$infos['montant_amr_b']);
                        
                        $data['Devise_12'] = $data['Notedevise_29'];
                        
                        $infos['accountname'] = str_replace(" V/C CDF", "", $infos['accountname']);

                        #Taux de change
                        if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                        {
                                $data['Taux_41'] = $_POST['Taux_41'];
                        }
                        else if($data['Devise_12']!='CDF')
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                        }

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ','',$data['Notemontant_28']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                        $data['Notemontant_28'] = str_replace(' ','',$data['Notemontant_28']);
                        $data['Notemontant_28'] = str_replace(',','.',$data['Notemontant_28']);
                        $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                        $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);


                        $data['Notereference_30'] = json_encode($infos);
                        unset($data['Infos']);

                        #Contre valeur en CDF
                        $data['Devise_42'] = $data['Devise_12'];
                        $data['Contrevaleur_22'] = ($data['Devise_12'] !='CDF') ? $data['Montant_11'] * $data['Taux_41'] : $data['Montant_11'];

                        # SAVE PAYMENT
                        # Check if it's a new payment

                        if($data['Id_0']=="" || $data['Id_0']==0)
                        {
                                unset($data['Id_0']);
                                $ref = $this->encaissementModel->get_id_by_reference($data['Logirefid_4']);

                                $data['Id_0'] = $ref;
                        }
                        
                        # Encaissement existant
                        if(isset($data['Id_0']) && $data['Id_0']>0 && $data['Id_0'] != NULL)
                        {     
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                                {
                                        $id =  $data['Id_0'];
                                        $result = array();

                                        //$data_to_update['Status_2'] = 5;
                                        //$this->encaissementModel->update_payment_tresor($data_to_update, $id);

                                        #Invocation of the api transfer
                                        $core_banking = strtolower($this->core_banking);
                                        
                                        $return = $this->{$core_banking}->virement($data);
                                        
                                        
                                        
                                        if(isset($return['response']) && $return['response'] =='200')
                                        {
                                                $result = json_decode($data['Notereference_30'], true);

                                                $result['Num_evenement'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "";
                                                $logirefid = $data['Logirefid_4'];

                                                // Pour eviter la modification du paiment par le validateur 
                                                $data = array();
                                                $data['Notereference_30'] = json_encode($result);
                                                $data['Id_0'] = $id;
                                                $data['Logirefid_4'] = $logirefid;
                                                $data['Status_2'] = 1;
                                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                $data['Validation_36 '] = gmdate('Y-m-d H:i:s');

                                                $result['code'] = 'E200';
                                                $result['id'] = $id;
                                                $result['type'] = 'amr-a';
                                                

                                                $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                        }
                                        elseif(isset($return['response']) && ($return['response'] =='300' || $return['response']=='404' || $return['response']=='405' || $return['response']=='411'))
                                        {
                                                // update payment status
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);

                                                $result['code'] = 'E'.$return['response'];
                                        }
                                        elseif(isset($return['message']) && $return['message'] != "")
                                        {
                                                // update payment status
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);

                                                $result = array();

                                                $result['code'] = $return['code'];
                                                $result['message'] = $return['message'].".";
                                        }
                                        elseif($return==false || $return==NULL)
                                        {   
                                                // update payment status
                                                $data = array();
                                                $data['Status_2'] = 5;
                                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);

                                                $result['code'] = 'E412';
                                        }
                                        
                                        echo json_encode($result);
                                        die;
                                }
                                else 
                                {
                                        $data['Changement_35'] = gmdate('Y-m-d H:i:s');
                                        $this->comptabilisationModel->delete_instructions_dgi($data['Logirefid_4']);

                                        # Save changes
                                        $pid = $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                                }
                        }
                        # Nouvel encaissement
                        else
                        {
                                
                                #Enregistrement
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                $logiref_id = $data['Logirefid_4'];
                                if($data['Id_0'] == 0) $data['Id_0'] = NULL;


                                $pid = $next_id.$data['Typerecette_17'].$data['Service_16'];
                                $data['Paiementkey_50'] = rand(1, 99).date('H').date('i').date('s').$pid.date('j').date('m').date('y').$this->session->userdata['user_id'];
                                
                                if($data['Notemontant_28'] > 0)
                                {
                                       $tresorid = $this->encaissementModel->save_payment_tresor($data, NULL);
                                }
                                
                                if(isset($infos['montant_amr_b']) && $infos['montant_amr_b'] > 0)
                                {
                                        $data['Montant_11'] = $infos['montant_amr_b'];
                                        $data['Devise_12'] = $infos['devise_amr_b'];
                                        
                                        $properid = $this->encaissementModel->save_payment_propres($data, NULL);
                                }

                                if($tresorid > 0)
                                {
                                        $data['Id_0'] = $tresorid;
                                }
                                else
                                {
                                        $data['Id_0'] = $properid;
                                }
                        }

                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true) && $pid > 0)
                        {
                                if(isset($this->functionalities['functionalities']) && $this->functionalities['functionalities'] != "")
                                {
                                        if (in_array('rounding-for-cash-register-payments', $this->functionalities['functionalities'])) 
                                        {
                                                # Get the instruction for the roundings when the payment method is cash
                                                if($arrondi > 0)
                                                {
                                                        $data ['arrondi'] = $arrondi;
                                                }
                                        }
                                }
                                
                                #Comptabilisation
                                if(isset($infos['montant_amr_b']) && $infos['montant_amr_b'] > 0 ) 
                                {
                                        $result = $this->comptabilisation->get_instructions_dgi_amr($data);
                                        
                                        foreach($result as $row)
                                        {
                                                $instruction = $row;
                                        }
                                        
                                        $instructions[] = $instruction;
                                        
                                        # Au cas ou le client paie uniquement l'amr B
                                        if($data['Notemontant_28'] == 0)
                                        {
                                                $data['Notemontant_28'] = 0;
                                                $data['Montant_11'] = 0;
                                                
                                                $result = $this->comptabilisation->get_instructions_dgi($data);
                                                
                                                foreach($result as $row)
                                                {
                                                        $instructions[] = $row;
                                                }
                                        }
                                }
                                
                                if($data['Notemontant_28'] > 0) 
                                {
                                        $result = $this->comptabilisation->get_instructions_dgi($data);
                                        
                                        foreach($result as $row)
                                        {
                                                $instructions[] = $row;
                                        }
                                }
                                
                                if(isset($data ['arrondi'])) unset($data ['arrondi']);

                                if(!empty($instructions))
                                {
                                        $this->comptabilisationModel->save_instructions_dgi($data['Id_0'], $data, $instructions, $data['Logirefid_4']);
                                }
                        }

                        #Return
                        if($properid> 0 || $tresorid > 0)
                        {
                                if($tresorid > 0)
                                {
                                        $return['code'] = 'E200';
                                        $return['id'] = $data['Id_0'];
                                        $return['type'] = 'amr-a';
                                       
                                        echo json_encode($return);
                                }
                                else
                                {
                                        $return['code'] = 'E200';
                                        $return['id'] = $data['Id_0'];
                                        $return['type'] = 'amr-b';
                                        
                                        echo json_encode($return);
                                }
                        }
                        else 
                        {
                                $return['code'] = 'E305';
                                $return['id'] = '0';
                                $return['type'] = '';
                                
                                echo json_encode($return);
                        }
                }
                elseif($obj == "delete")
                {
                        $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;
                        
                        
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_tresor($id);
                                 //var_dump($pid); die;
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_propre($id);
                        }
                        
                        if(!$pid)
                        {
                                $this->comptabilisationModel->delete_instructions_dgi($id);
                        }
                        
                       
                        #Return
                        echo '<div class="alert aSuccess text-white"> Paiement supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        die;
                } 
                elseif($obj == "rbo_reverse")
                {
                        $data = $_POST;
                        $id =  $data['Id_0'];
                        $data_to_update['Status_2'] = 5;
                       
                        #Invocation of the api transfer
                        // $this->encaissementModel->update_payment_tresor($data_to_update, $id);

                        //$response = $this->curl_model->call_bank_reverse_rbo_virement($data);
                        
                        //$return = json_decode($response, true);

                        $return['response'] ='200';
                        
                        if(isset($return['response']) && $return['response'] =='200')
                        {
                                // $result = json_decode($data['Notereference_30'], true);
                                  $result=$data['Infos'];

                                // foreach ($result as $row)
                                // {
                                //         $result['Num_evenement'] = $row['Num_evenement'];
                                                
                                //         break;
                                // }
                               
                                $logirefid = $data['Logirefid_4'];
                               
                                // Pour eviter la modification du paiment par le validateur 
                                $data = array();
                                // $result['Rejet'] = $_POST['motif'];
                                $result['Motif']=$_POST['motif'];
                                $data['Notereference_30'] = json_encode($result);
                                $data['Id_0'] = $id;
                                $data['Logirefid_4'] = $logirefid;
                                $data['Status_2'] = 9;
                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);
                                #Return
                                echo $data['Id_0'];
                                die;
                        }
                        elseif(isset($return['response']) && ($return['response'] =='300' || $return['response']=='404' || $return['response']=='405' || $return['response']=='411'))
                        {
                                // update payment status
                                $data = array();
                                $data['Status_2'] = 5;
                                $data['Checkerid_10'] = $this->session->userdata("user_id");
                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);

                                echo 'E'.$return['response'];
                                die;
                        }
                        elseif($return==false || $return==NULL)
                        {
                                // update payment status
                                $data = array();
                                $data['Status_2'] = 5;
                                $data['Checkerid_10'] = $this->session->userdata("user_id");
                                $pid = $this->encaissementModel->update_payment_tresor($data, $id);

                                echo 'E412';
                                die;
                        }
                        
                        # Save changes
                        $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                }
                
                elseif($obj == "OBJ ")
                {
                    
                }
        }
           
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        
                        return $error;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}
