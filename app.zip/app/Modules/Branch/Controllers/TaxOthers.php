<?php 

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Branch\Models\RatesModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\AccountModel;
use Modules\Branch\Models\OthersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\BulletinsModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Branch\Models\EncaissementModel;
use Modules\Services\Finacle\Controllers\Finacle;
//use Modules\Branch\Models\ComptabilisationModel;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;

class TaxOthers extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Glodi on the 17.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'others';

        public $integrationModel;
        public $logirefModel;
        public $bulletinsModel;
        public $dataModel;
        public $usersModel;
        public $ratesModel;
        public $accountModel;
        public $feesModel;
        public $stakeholderModel;
        public $encaissementModel;
        public $othersModel;
        public $igor;
        public $synergies;
        public $amplitude;
        public $comptabilisationModel;
        public $comptabilisation;
        public $functionalities;
        public $bank;
        public $amplitude_solidairebanque;
        public $fibridge;
        public $curlModel;
        public $role;
        public $bank_uppercase;
        public $accountid;
        public $core_banking;
        public $temenos;
        public $options;
        public $deny;
        public $bsqr;
        public $stakeholdersModel;
        public $flexcube;
        public $finacle_standardbank;
        public $finacle;
        public $temenoscrdb;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->bulletinsModel = new BulletinsModel();
                $this->dataModel = new DataModel();
                $this->usersModel = new UsersModel();
                $this->ratesModel = new RatesModel();
                $this->accountModel = new AccountModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->encaissementModel = new EncaissementModel();
                $this->othersModel = new OthersModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->comptabilisation = new Comptabilisation();
                $this->igor = new Igor();
                $this->synergies = new Synergies();
                $this->amplitude = new Amplitude();
                $this->bsqr = new Bsqr();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->finacle = new Finacle();
                $this->temenoscrdb = new TemenosCrdb();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxothers';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->encaissementModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking= $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;

                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
	}


	public function index()
	{
		$this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [4, 7], true))
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "start")
                {   
                        
                        $this->data['step'] = 0;
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                       
                        $this->data['encaissement'] = $this->encaissementModel->get_paiement_tresor_info();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        
                        echo view('\Modules\Branch\Views\others\_step_1', $this->data);
                }
                elseif($obj == "verification") 
                {
                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        
                        $response = $this->curl_model->call_dgda_checkbl_credit($credentials);
                        $response = trim($response);
                        if($response == NULL || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000')
                        {
                            
                                if($response == 'E404')
                                {
                                        $message = " Error 404 : Sydonia not available ";
                                        //$this->curl_model->call_set_log($message, "sydonia");
                                }
                                
                                echo $response; die;
                        }
                        elseif($response == NULL )
                        {
                            
                        }
                        else
                        {
                            
                                $amount = str_replace(' ','',$_POST['Amount']);
                                $amount = str_replace(',','.',$amount);
                                $devise = $_POST['devise'];
                                $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                                $service = $_POST['Office'];
                                $agence = $_SESSION['Logiref_guichet'];
                                $mode = $_POST['Mode'];

                                $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                if($devise !='CDF')
                                {
                                        if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        }
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                }
                                else
                                {
                                        $devise_taux = 1;
                                }

                                if(isset($_POST['Nif']))
                                {
                                        $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);
                                        $this->data['designation'] = ($client != NULL && isset($client->Designation_5))? $client->Designation_5 :''; 
                                }


                                if(!isset($_POST['Commission']))
                                {
                                        $rules = $this->feesModel->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                                $com['com'] = ($amount * $rules['Valeur'])/100;
                                                $com['devise'] = $devise;
                                        }
                                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }
                                        if(!empty($com) && $com['com']!=0)
                                        {
                                                if($com['devise'] !='CDF')
                                                {
                                                        $this->data['commission'] = $com['com'] * $devise_taux;
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                                else
                                                {
                                                        $this->data['commission'] = $com['com'];
                                                        $this->data['$commission_devise'] = $com['devise'];

                                                        $this->data['total_amount'] = $amount + $this->data['commission'];
                                                }
                                        }
                                        else
                                        {
                                                $this->data['commission'] = $amount*0;
                                                $this->data['commission_devise'] = $devise;
                                                $this->data['total_amount'] = $amount + $this->data['commission'];
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                else 
                                {
                                        $commission = str_replace(' ','',$_POST['Commission']);
                                        $commission = str_replace(',','.',$commission);
                                        
                                        $this->data['commission'] = $commission;
                                        $this->data['commission_devise'] = $_POST['Devise_commission'];

                                        if($_POST['Devise_commission'] !="CDF")
                                        {
                                                if(isset($_POST['Taux']) && $_POST['Taux'] !="")
                                                {
                                                        $devise_taux = $_POST['Taux'];
                                                }
                                                else
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                                        $devise_taux = $taux['Dollar_4'];
                                                }
                                                $commission = $this->data['commission'] * $devise_taux;
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        else
                                        {
                                                $this->data['total_amount'] = $amount + $commission;
                                        }
                                        $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                                }
                                
                                $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);

                                $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";

                                if($mode =='7')
                                {
                                        $this->data['referenceOP'] = (isset($_POST['reference']))? $_POST['reference'] : "";
                                        $this->data['disabled'] = "";
                                }
                                else 
                                {
                                        $this->data['referenceOP'] = "";
                                        $this->data['disabled'] = "disabled";
                                }

                                echo view('\Modules\Branch\Views\offline\_step_1_details', $this->data);
                        }
                }
                elseif ($obj == "create_note") 
                {
                        # reference of the payment.
                        $data = array();
                        $result = array();

                        $data['Logirefid_4'] = $this->encaissementModel->generate_unique_reference();
                        
                        $return = $this->save('note', $data['Logirefid_4'], $id);

                        if ($return != 0) 
                        {
                                $result['code'] = $return['code'];
                                $result['id'] = $return['id'];
                                $result['logirefid'] = $return['logirefid'];

                                echo json_encode($result);
                        } 
                        else 
                        {
                                $result['code'] = $return;
                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "create_bulletin") 
                {
                        # reference of the payment.
                        $data = array();
                        $result = array();

                        $data['Logirefid_4'] = $this->encaissementModel->generate_unique_reference();
                        
                        $return = $this->save('note', $data['Logirefid_4'], $id);

                        if ($return != 0) 
                        {
                                $result['code'] = $return['code'];
                                $result['id'] = $return['id'];
                                $result['logirefid'] = $return['logirefid'];

                                echo json_encode($result);
                        } 
                        else 
                        {
                                $result['code'] = $return;
                                echo json_encode($result);
                        }
                }
                elseif ($obj == "initiate_transaction") 
                {
                        $id = isset($_POST['bulletin_id']) ? $_POST['bulletin_id'] : "";

                        # Retrieve the bl informations
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);

                        $result = array();
                        $data = array();

                        if (isset($bulletin->Id_0)) 
                        {
                                $data['Sydonia_44'] = $bulletin->Id_0;
                                $data['Designation_14'] = $bulletin->Designation_23;
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Devise_12'] = 'CDF';
                                $data['Compte_33'] = $bulletin->Account_28;
                                $data['Devise_34'] = $bulletin->Devise_29;
                                $data['Taux_41'] = $bulletin->Taux_31;
                                $data['Logirefid_4'] = $bulletin->Logirefid_34;
                                $data['Priority'] = 0;

                                $response = $this->igor->reservation_with_instructions($data);

                                $return = json_decode($response, true);

                                if (isset($return['response']) && $return['response'] == "200") 
                                {
                                        #Update the bulletin in order to indicate that it's already treated
                                        $data_to_update = array();
                                        $data_to_update['Treated_45'] = 1;
                                        $this->integrationModel->save_bulletin($data_to_update, $id);

                                        echo $response;
                                }
                                else 
                                {
                                        echo $response;
                                }
                        } 
                        else 
                        {
                                # Failure attempt
                                $msg = '<div class="alert aDanger text-white">Le paiement n\'a pas été enregistré; un problème est survenu. Veuillez reprendre s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                echo $msg;
                        }
                }
                elseif ($obj == "debit_client") 
                {                        
                        $data['Logirefid_4'] = isset($_POST['logirefid']) ? $_POST['logirefid'] : "";

                        $id = $_POST['bulletin_id'];
                        
                        $data['Sydonia_44'] = $id;
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        $data['Priority'] = 0;

                        # Update the bulletin in order to indicate that it's already treated
                        //$data_to_update['Treated_45'] = 1;
                        //$this->integrationModel->save_bulletin($data_to_update, $id);

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'debit_customer_bulletin_single')) 
                        {
                                $return = $this->{$core_banking}->debit_customer_bulletin_single($data);

                                # Update the bulletin in order to indicate that it's already treated
                                $data_to_update = array();
                                $data_to_update['Treated_45'] = (isset($return['code']) && $return['code'] =='200') ? '1' : '0';
                                $this->integrationModel->save_bulletin($data_to_update, $id);

                                echo $return;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                else if($obj == "verify")
                {
                        /*
                        * ------------------------------------------------
                        * Variable initialization
                        * ------------------------------------------------
                        */
                        $data = array();
                        $return = array();
                        $result = array();
                        
                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['Designation_14'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];
                        
                        $data['Priority'] = 0;
                        
                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'bulletin_single_verification_treatment')) 
                        {
                                $return = $this->{$core_banking}->bulletin_single_verification_treatment($data);
                                
                                echo $return; die;     
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result); die;
                        }
                }
                elseif ($obj == "verify_transaction_single") 
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */
                        $data = array();
                        $return = array();
                        $result = array();

                        $data['Sydonia_44'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'bulletin_single_verification_treatment')) 
                        {
                                $return = $this->{$core_banking}->bulletin_single_verification_treatment($data);

                                echo $return;
                                die;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif($obj == "confirmation") 
                {
                       
                        $taxes = array();
                        $Taxes = $_POST['taxes'];
                        $Amount = $_POST['amounts'];

                        for($i = 0; $i < count($Taxes); $i++)
                        {
                                $taxe = new \stdClass();
                                $amount = str_replace(' ','',$Amount[$i]);
                                $taxe->taxeAmount = str_replace(',','.',$amount);
                                $taxe->taxeCode = $Taxes[$i];
                                $taxes[] = $taxe;
                        }
                        // All taxes
                        $_POST['Infos']['taxesPaid'] = json_encode($taxes);
                       
                        
                        $_POST['Paiementid'] = $id  = $this->save('bulletin');
                                        
                        $data['Sydonia_44'] = $id;
                        # reference of the transaction.
                        $data['Logirefid_4'] = round(1000,9999).mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Designation_14'] = $_POST['designation'];  
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Priority'] = 0;
                        $response = $this->curl_model->call_bank_virement($data);
                                    
                        $return = json_decode($response, true);
                       
                        if($return['response']=='200')
                        {
                                if(isset($_POST['Mode']) && $_POST['Mode'] =="5")
                                {
                                        foreach ($return as $row)
                                        {
                                                $_POST['reference'] = $row['Num_evenement'];
                                                break;
                                        }
                                }
                                
                                $user = $this->session->userdata['user_id'];
                                $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                                $response = $this->curl_model->call_bank_comptant_single($credentials);
                                $response = trim($response);
                        }
                        elseif($return['response']=='300') 
                        {
                                $response = 'E300';
                        }
                        elseif($return['response']=='404') 
                        {
                                $response = 'E406';
                        }
                        elseif($return==false || $return==NULL)
                        {
                                $response = 'E412';
                        }
                        else 
                        {       
                                $response = 'E411';
                        }
                        
                        if($response=='E003' || $response=='E22' || $response=='E11' || $response=='E34' || $response == 'E404' || $response == 'E13' || $response == 'E000' || $response == 'E406' || $response == 'E300' || $response == 'E411' || $response == 'E412')
                        {
                                if($response == 'E404')
                                {
                                        $message = " Error 404 : Sydonia not available ";
                                        //$this->curl_model->call_set_log($message, "sydonia");
                                }
                                echo $response; die;
                        }
                        else
                        {
                                $message = "Success : Connection to sydonia for payment confirmation was successful ";
                                //$this->curl_model->call_set_log($message, "sydonia");
                                echo $response; die;
                        }
                        
                }
                elseif($obj == "edit")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);
                        $agence_src= $_SESSION['Logiref_guichet'];
                                
                        $case = $this->comptabilisationModel->get_use_case($data);
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, NULL);
                        
                        switch ($case)
                        {
                                case "case_1": 
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                                case "case_2": 
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_2($data, $comptes,"DGDA");
                                        break;
                                case "case_3": 
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_3($data, $comptes,"DGDA");
                                        break;
                                case "case_4": 
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_4($data, $comptes,"DGDA");
                                        break;
                                default: 
                                        //$instructions = $this->comptabilisationModel->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }
                        $info = $encaissement->Notereference_30;
                        
                        $guichet = $this->session->userdata["Logiref_guichet"];
                        $compte_cpt = isset($comptes['Rawbank']['CSO'][$data['Devise_12']]) ? $comptes['Rawbank']['CSO'][$data['Devise_12']] : '00000000000000000000000'; 
                        $compte_cgu = isset($comptes['DGDA']['CGU'][$data['Devise_12']]) ? $comptes['DGDA']['CGU'][$data['Devise_12']] : '00000000000000000000000';
                        
                        #Taxes comptes
                        $comptes = array();
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $instructions2 = array();

                        $comptes = $this->accountModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholdersModel->get_dropdown("beneficiaires");

                        $taxes = $info['taxesPaid'];

                        foreach($taxes as $taxe)
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisationModel->get_instructions_gu_dgda($data, $comptes, $compte_cpt, $compte_cgu, "TRESOR");
                                $instructions2[] = $instruction;
                        }
                       
                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = $this->input->get('mode');
                        $this->data['cCompte'] = $this->input->get('compte');
                        $this->data['cDevise'] = $this->input->get('devise');
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_step_2', $this->data);
                        
                        echo view('\Modules\Branch\Views\offline\_step_2', $this->data);
                }
                elseif($obj == "preview")
                {
                        $bl = $id;
                        
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);
                        $this->ratesModel->get_exchange_rates();
                        
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_dgda($id);
                        
                        #Taxes comptes
                        $liste = ("'CGU'");
                        $agence = $_SESSION['Logiref_guichet'];
                        
                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);
                        
                        $data = json_encode($encaissement);
                        $data = json_decode($data, true);
                        
                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);
                        
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';
                        
                        $this->data['compte_cgu'] = $compte_cgu;
                        
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\others\_step_3', $this->data);
                }
                elseif($obj == "getquittance")
                {
                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encrytions = json_decode($credentials->Password_18);
                        #initialisation
                        $apidata = array();
                        $bl = $id;
                        
                        $bulletin = $this->integrationModel->get_paiement_sydonia($bl);
                        
                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                        {
                                $quittance = $bulletin->Pdfcontent_18;
                                echo $quittance;
                        }
                        else
                        {
                                $declaration = json_decode($bulletin->Results_13);
                                $apidata['ReceiptSerial'] = $declaration->receiptSerial;
                                $apidata['ReceiptNumber'] = $declaration->receiptNumber;
                                $apidata['ReceiptDate'] = $declaration->receiptDate;
                                $apidata['Office'] = $bulletin->Office_6;
                                $apidata['Account'] = $this->session->userdata['account_id'];
                                $apidata['Paiementid'] = $bl;
                                $apidata['User'] = $this->session->userdata['user_id'];
                                $apidata['login'] = (isset($credentials->Login_17))? $credentials->Login_17:'';
                                $apidata['password'] = (isset($encrytions->encryption))? $encrytions->encryption:'';
                                
                                $response = $this->curl_model->call_dgda_quittance($apidata);
                                
                                if($response == "E41" || $response == "E003" || $response == "E001" || $response == "E11" || $response == 'E404' || $response == "E000")
                                {
                                        echo $response;
                                }
                                else
                                {
                                        $bulletin = $this->integrationModel->get_paiement_sydonia($bl);

                                        if(isset($bulletin->Pdfcontent_18) && $bulletin->Pdfcontent_18 !="")
                                        {
                                                $quittance = $bulletin->Pdfcontent_18;
                                                echo $quittance;
                                        }
                                        else
                                        {
                                                echo "E406";
                                        }
                                }
                        }
                       
                }
                elseif($obj == "selectTaxes")
                {
                        $recettes = $this->logirefModel->get_dropdown('recettes');
                        
                        $html = '
                            <select name="taxes[]" class="selecttaxes form-control itemgrid iwtd" required="required">
                                <option value="" selected disabled></option>';

                        foreach ($recettes as $regie => $row) {
                            foreach ($row as $key => $value) {
                                $html .= '<option value="' . htmlspecialchars($key) . '">' . htmlspecialchars($value) . '</option>';
                            }
                        }

                        $html .= '</select>';

                        echo $html; 
                }
                elseif($obj == "encaissement")
                {
                        # Verification de des montants de taxe et du montant du bulletin
                        $tax_amounts = str_replace(' ','',$_POST['amounts']);
                        $tax_amounts = str_replace(',','.',$tax_amounts);

                        $total_amount_taxe = array_sum(array_map('intval', $tax_amounts));
                        
                        $bl_amount = str_replace(' ','',$_POST['Montant_11']);
                        $bl_amount = str_replace(',','.',$bl_amount);
                        
                        if(($total_amount_taxe > $bl_amount) || ($total_amount_taxe < $bl_amount))
                        {
                                echo 'E412'; die;
                        }
                        elseif($total_amount_taxe == $bl_amount)
                        {
                                $bulletin = $this->othersModel->check_bl_exist();
                                $bulletin = current($bulletin);

                                if(isset($bulletin->Id_0) && $bulletin->Id_0 > 0)
                                {
                                        echo "E402"; die;
                                }
                                else
                                {
                                        $taxeCodes =  $_POST['taxes'];
                                        $amounts = $_POST['amounts'];
                                        $taxes = array();
                                        $amount = 0;
                                        $agence = $_SESSION['Logiref_guichet'];
                                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);

                                        for($i = 0; $i < count($taxeCodes); $i++):

                                            $taxe = new \stdClass();

                                            $taxe->taxeCode = $taxeCodes[$i];

                                            $Amount = str_replace(' ','',$amounts[$i]);
                                            $taxe->taxeAmount = str_replace(',','.',$Amount);
                                            $taxes[] = $taxe;

                                            $amount = $amount + $taxe->taxeAmount;

                                        endfor;

                                        $_POST['Notemontant_28'] = $amount;
                                        $_POST['Infos']['taxesPaid'] = $taxes; 

                                        $_POST['Infos']['quittanceid'] = $_POST['Infos']['Qserie'].$_POST['Infos']['Qnumber'];
                                        $_POST['Noteid_26'] = $_POST['Infos']['serie'].$_POST['Infos']['number'];

                                        $_POST['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";

                                        unset($_POST['taxes']);
                                        unset($_POST['amounts']);

                                        // save bulletin
                                        if(isset($_POST['notemanuelle']) && $_POST['notemanuelle'] != ""):

                                                $_POST['Sydonia_44'] = $id = $_POST['bulletin_id'];
                                                unset($_POST['notemanuelle']);
                                        else:
                                                $_POST['Sydonia_44'] = $id =  $this->save('bulletin');

                                        endif;

                                        $_POST['Infos']['Paiementid'] = $_POST['Sydonia_44']; 

                                        if($id > 0)
                                        {
                                                $taxes = json_encode($taxes);
                                                $_POST['Infos']['taxesPaid'] = $taxes; 

                                                unset($_POST['taxes']);
                                                unset($_POST['amounts']);
                                                unset($_POST['commission']);
                                                unset($_POST['devise']);
                                                unset($_POST['Paiementid']);
                                                unset($_POST['account_name']);
                                                unset($_POST['account_cgu']);
                                                unset($_POST['action']);
                                                unset($_POST['logirefid']);
                                                unset($_POST['bulletin_id']);
                                                unset($_POST['transaction_id']);
                                                unset($_POST['error_code']);

                                                // save taxes payments
                                                $result = $this->save('comptant');

                                                if($result == 'E406')
                                                {
                                                        echo 'E406';
                                                }
                                                else
                                                {
                                                        echo  $result;
                                                }
                                        }
                                        else
                                        {

                                        }
                                }
                        }
                        else
                        {
                                echo 'E412'; die;
                        }
                }
                elseif($obj == "input_new_tax")
                {
                        echo form_input('taxes[]', '', 'class="form-control" required="required"'); 
                }
                elseif($obj == "ComptantTaxesDetails")
                {
                        $ref = $id;
                        $paiment = $this->bank_model->get_paiement_tresor_bl($ref);
                        
                        if(empty($paiment))
                        {
                               $paiment = $this->bank_model->get_paiement_propres_bl($ref); 
                        }
                        
                        if($paiment != NULL):
                            $bulletin = json_decode($paiment->Notereference_30);
                            $taxes = json_decode($bulletin->taxesPaid);
                        else:
                            $taxes = array();
                        endif;
                        $this->data['recettes'] = $this->bank_model->get_dropdown("recettes");
                        $this->data['beneficiaires'] = $this->bank_model->get_dropdown("beneficiaires");
                        $this->data['taxesPaid'] = $taxes;
                        
                        echo view('\Modules\Branch\Views\bulletins\_taxesDetails', $this->data);
                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "comptant")
                {
                        $data = array();
                        $data_id_paiement = array();
                        $frais_bcc = 0;
                        $fbc_propres = 0;

                        $data = $_POST;
                        $data['Status_2'] = 1;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        $infos = $data['Infos'];
                        $infos['quittanceid'] = $infos['Qserie'].$infos['Qnumber'];

                        $data['Notereference_30'] = json_encode($infos);
                        unset($data['Infos']);

                        #Taux de change
                        if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                        {
                                $data['Taux_41'] = str_replace(' ','',$data['Taux_41']);
                                $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                        }
                        else if($data['Devise_12']!='CDF')
                        {
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                        }

                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);

                        $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                        $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);

                        #Contre valeur en CDF
                        $data['Devise_42'] = $data['Devise_12'];
                        $data['Contrevaleur_22'] = $data['Montant_11'] * $data['Taux_41'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Service_16'] = isset($data['Service_16']) ? $data['Service_16'] : "";

                        # SAVE PAYMENT
                        $results = $infos;
                        $prefix = 1;
                        $logirefid = $data['Logirefid_4'];
                        $end_execution = NULL;

                        #Taxes comptes
                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);
                        $instructions = array();

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholdersModel->get_dropdown("beneficiaires");

                        $taxes = json_decode($results['taxesPaid']);

                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        $amount = $taxe->taxeAmount * 0.0005;
                                                        $frais_bcc = $amount + $frais_bcc;
                                                }
                                        }
                                }
                        }

                        # Verify in the options tab if the bcc fees is deduced after the validation with an exception
                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation-with_exception'])) 
                        {
                                # initialization of the treasury tax value 
                                $is_there_taxe_tresor = false;

                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                {
                                                        if ($taxe->taxeAmount > 0) 
                                                        {
                                                                $is_there_taxe_tresor = true;
                                                        }
                                                }
                                        }
                                }

                                # Deduce the remote compensation 
                                # If the bulletin there is a treasury taxe
                                if ($is_there_taxe_tresor) 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.002;
                                } 
                                else 
                                {
                                        $data['frais_bcc'] = $data['Montant_11'] * 0.0015;
                                }

                                # Contruct the instructions for frais bcc
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                
                                $instruction = current($instruction);

                                if (!empty($instruction)) 
                                {
                                        $instructions[] = $instruction;
                                }
                        }


                        if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $taxe_code = $taxe->taxeCode; 
                                                $taxe_amount = $taxe->taxeAmount;

                                                $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                //$frais_bcc += $fees_bcc['Valeur'];
                                                if (($_SESSION['userdata']['account_id']) == "36")
                                                        $fbc_propres += $fees_bcc['Valeur'];
                                                else
                                                        $frais_bcc += $fees_bcc['Valeur'];
                                        }
                                }
                        }

                        if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                        {
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($taxe->taxeCode)) 
                                        {
                                                $data['Typerecette_17'] = $taxe->taxeCode;

                                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                if($type_comptes['CPI'] == '000000000000000000000000')
                                                {
                                                        $frais_bcc += $taxe->taxeAmount * 0.002;
                                                }
                                        }
                                }
                        }

                        # Reference operation for the payment
                        $data['refOp'] = $data['Reference_32'];

                        # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                        if ($frais_bcc > 0) 
                        {
                                $data['frais_bcc'] = $frais_bcc;
                                
                                # Comptes à utiliser, selon ce qui est disponible
                                if (!isset($comptes_fbc)) 
                                {
                                        $comptes_fbc = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                }
                                
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc, $data, 'DGDA');
                                $instruction = current($instruction);
                                
                                if (!empty($instruction)) 
                                {
                                        $instructions[] = $instruction;
                                }
                        }

                        # FINALISATION : Calculer les instructions une seule fois avec frais BCC total
                        if ($fbc_propres > 0) 
                        {
                                $comptes_fbc_propes = $this->accountModel->get_comptes_dgda("'FBC'", NULL, $agence);
                                $data['frais_bcc'] = $fbc_propres;
                                $data['RFPROPD'] = "PROPRES";
                                
                                $instruction = $this->comptabilisation->get_exception_instructions($comptes_fbc_propes, $data, 'DGDA');
                                $instruction = current($instruction);
                                
                                if (!empty($instruction)) 
                                        $instructions[] = $instruction;

                                unset($data['RFPROPD']);
                        }

                        if (isset($data['frais_bcc']))
                                unset($data['frais_bcc']);

                        if (isset($data['refOp']))
                                unset($data['refOp']);

                        foreach($taxes as $taxe)
                        {
                                $data['Logirefid_4'] = $logirefid.'-'.$prefix;
                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $pid = $data['Sydonia_44'].$data['Typerecette_17'].$data['Service_16'];
                                $data['Paiementkey_50'] = rand(1, 99).date('H').date('i').date('s').$pid.date('j').date('m').date('y').$this->session->userdata['user_id'];

                                if(isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                {
                                        $data['Tresor_45'] = '1';
                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                        $pid = $this->encaissementModel->save_payment_tresor($data, NULL);
                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                        $instructions[] = $instruction;
                                }
                                else if(isset($beneficiaires[$taxe->taxeCode]))
                                {
                                        $data['Tresor_45'] = '0';
                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                        $pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                        $instructions[] = $instruction;
                                }
                                else
                                {
                                        $data['Missmatch_46'] = 1;
                                        $data['Tresor_45'] = '0';
                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                        $pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                        $instructions[] = $instruction;
                                }
                                $data['Id_0'] = $pid;

                                $prefix++;
                        }

                        if(!empty($instructions))
                        {
                                # priority for integrating the counting in cbs
                                $priority = 1;

                                $end_execution = $this->comptabilisationModel->save_instructions($data['Sydonia_44'], $data, $instructions, $logirefid, $priority);
                                unset($instructions);
                        }

                        if($end_execution)
                        {
                                $bl_data['Status_2'] = '2';
                                $bl_data['Treated_45'] = '2';
                                $this->integrationModel->update_bulletin($bl_data, $data['Sydonia_44']);
                        }

                        return $data['Sydonia_44'];
                }
                elseif ($obj == "validate_single_bl") 
                {
                        if (isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "") 
                        {
                                $data = $_POST;
                                $code = '';
                                $id = $_POST['Sydonia_44'];

                                #Is this a validation? Yes if it's a validator or the supervisor
                                if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true)) 
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['type'] = 'comptant';
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['Designation_14'];
                                        $data['Account_3'] = $this->session->userdata['account_id'];

                                        $agence = $_SESSION['Logiref_guichet'];
                                        $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);
                                        $data['compte_guichet'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'validate_payment')) 
                                        {
                                                $return = $this->{$core_banking}->validate_payment($data);

                                                $result = json_decode($return, true);

                                                if ($result['code'] == '200') 
                                                {
                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                        if ($tid) 
                                                        {
                                                                $bl_data['Status_2'] = '3';
                                                                $bl = $this->integrationModel->save_bulletin($bl_data, $id);
                                                        }
                                                }

                                                echo $return;
                                        } 
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result);
                                                die;
                                        }
                                } 
                                else 
                                {
                                        $result['code'] = 'E408';
                                        echo json_encode($result);
                                        die;
                                }
                        } 
                        else 
                        {
                                $result['code'] = 'E409';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif($obj == "validate")
                {
                        $data = $_POST;
                        $code = '';
                        
                        if(isset($_POST['Sydonia_44']) && $_POST['Sydonia_44'] != "")
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true))
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['Type'] = 'others';
                                        
                                        #Invocation of the api transfer
                                        @set_time_limit(300);
                                        
                                        $response = $this->curl_model->call_bank_virement($data);
                                        $return = json_decode($response, true);
                                        if(isset($return['response']) && $return['response'] == "200")
                                        {
                                                $code = 200;
                                                $id = $_POST['Sydonia_44'];
                                                
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                if($tid)
                                                {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->integrationModel->update_bulletin($bl_data, $id);
                                                }
                                        }
                                        elseif(isset($return['response']) && $return['response'] == "300")
                                        {
                                                $code = 300;
                                                $id = $_POST['Sydonia_44'];
                                                
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];
                                                
                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                
                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->integrationModel->update_bulletin($bl_data, $id);
                                                
                                        }
                                        elseif(isset($return['response']) && $return['response'] == "404")
                                        {
                                                $code = 404;
                                                $id = $_POST['Sydonia_44'];
                                                
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];
                                                
                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                
                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->integrationModel->update_bulletin($bl_data, $id);
                                                
                                        }
                                        elseif(isset($return['response']) && $return['response'] == "411")
                                        {
                                                $code = 411;
                                                $id = $_POST['Sydonia_44'];
                                                
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];
                                                
                                                
                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                
                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->integrationModel->update_bulletin($bl_data, $id);
                                                
                                        }
                                        elseif(isset($return['response']) && $return['response'] == "405")
                                        {
                                                # Aucune ecriture trouvE 
                                                $code = 405;
                                                $id = $bl = $_POST['Sydonia_44'];
                                        }
                                        elseif($return==false || $return ==NULL)
                                        {
                                                $code = 202;
                                                $id = $_POST['Sydonia_44'];
                                                
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];
                                                
                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);

                                                if($tid)
                                                {
                                                        $bl_data['Status_2'] = '5';
                                                        $bl = $this->integrationModel->update_bulletin($bl_data, $id);
                                                }
                                        }
                                        
                                }
                                if(isset($bl) && $bl > 0) 
                                {
                                        $retour = array('code'=>$code, 'id'=>$id);
                                        echo json_encode($retour);
                                }
                                else
                                {
                                        echo 0;
                                }
                                
                        }
                }
                elseif($obj == "bulletin")
                {
                        $infos = $_POST['Infos'];
                        
                        $data['Status_2'] = 2;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        //Formatting amount
                        $data['Amount_12'] = str_replace(' ','',$_POST['Notemontant_28']);
                        $data['Amount_12'] = str_replace(',','.',$data['Amount_12']);


                        $data['Taux_31'] = str_replace(' ','',$_POST['Taux_41']);
                        $data['Taux_31'] = str_replace(',','.',$data['Taux_31']);

                        $data['Year_5'] = $infos['year'];
                        $data['Serie_7'] = $infos['serie'];
                        $data['Number_8'] = $infos['number'];
                        $data['Office_6'] = $_POST['Service_16'];
                        $data['Nif_9'] = $_POST['Nif_13'];
                        $data['Agent_10'] = $infos['Agent'];
                        $data['Bank_11'] = $infos['bank'];
                        
                        # The unique key of the payment
                        $montant =  intval($data['Amount_12']);
                        $data['Paiementkey_42'] = $data['Year_5'].$data['Office_6'].$data['Serie_7'].$data['Number_8'].$data['Nif_9'].$data['Bank_11'].$montant;

                        // result constuction 
                        $result = new \stdClass();
                        $result->receiptDate = str_replace('-', '/', $infos['receiptdate']);
                        $result->receiptSerial = $infos['Qserie'];
                        $result->receiptNumber = $infos['Qnumber'];
                        $result->declarationsPaid = new \stdClass();
                       
                        $result->declarationsPaid->registrationYear = $infos['year'];
                        $result->declarationsPaid->assessmentSerial = $infos['serie'];
                        $result->declarationsPaid->assessmentNumber =  $infos['number'];
                        $result->declarationsPaid->amountToBePaid = $data['Amount_12'];
                        $result->declarationsPaid->taxesPaid = $_POST['Infos']['taxesPaid'];
                        
                        $data['Results_13'] = json_encode($result);
                        $data['Error_14'] = '0';
                        $data['User_15'] = $this->session->userdata['user_id'];
                        $data['Integration_16'] = gmdate('Y-m-d H:i:s');
                        $data['Printing_17'] = gmdate('Y-m-d H:i:s');
                        $data['Reference_19'] = $_POST['Reference_32'];
                        $data['Designation_23'] = $_POST['Designation_14'];
                        $data['Account_24'] = $_POST['account_cgu'];  // compte GU
                        $data['Amount_25'] = (float)$data['Amount_12'] + (float)$_POST['Commission_23'];  // Total amount
                        $data['Commission_26'] = $_POST['Commission_23'];
                        $data['Devise_27'] = $_POST['Devise_24'];
                        $data['Account_28'] = $_POST['Compte_33'];
                        $data['Devise_29'] = $_POST['Devise_34'];
                        $data['Mode_30'] = $_POST['Mode_19'];
                        $data['Taux_31'] = $_POST['Taux_41'];
                        $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                        $data['Accountholder_33'] = (isset($_POST['Infos']['accountname']) && $_POST['Infos']['accountname'] != "")? $_POST['Infos']['accountname'] : '';
                        $data['Lot_22'] = 'saisi';
                        
                        $id = $this->integrationModel->save_bulletin($data, NULL);
                        
                        if($id > 0)
                        {
                                $data = array();

                                $data['Designation_14'] = $_POST['Designation_14'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Agence_20']=$_SESSION['Logiref_agence'];
                                $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                $data['Mode_19'] = $_POST['Mode_19'];
                                $data['Typerecette_17'] = $infos['serie'].$infos['number'];
                                $data['Devise_34'] = $_POST['Devise_34'];
                                
                                #Taux de change
                                if(isset($_POST['Taux_41']) && $_POST['Taux_41'] !="")
                                {
                                        $data['Taux_41'] = str_replace(' ','',$_POST['Taux_41']);
                                        $data['Taux_41'] = str_replace(',','.',$data['Taux_41']);
                                }
                                else if($data['Devise_12']!='CDF')
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);
                                        if($data['Devise_12']=='USD') $data['Taux_41'] = $taux['Dollar_4'];
                                        if($data['Devise_12']=='EUR') $data['Taux_41'] = $taux['Euro_5'];
                                        if($data['Devise_12']=='ZAF') $data['Taux_41'] = $taux['Rand_6'];
                                }
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$_POST['Notemontant_28']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                
                                $data['Devise_12'] = $_POST['Devise_12'];
                                $data['Compte_33'] = $_POST['Compte_33'];
                                $data['Noteid_26'] = $infos['serie'].$infos['number'];
                                
                                
                                //Formatting amount
                                $data['Commission_23'] = str_replace(' ','',$_POST['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                $data['Devise_24'] = $_POST['Devise_24'];
                                $data['Nif_13'] = $_POST['Nif_13'];
                                $data['Notedate_27'] = gmdate('Y-m-d');
                                
                                $data['Service_16'] = isset($_POST['Service_16']) ? $_POST['Service_16'] : "";
                                
                                # Comptabilisation
                                $instructions = $this->comptabilisation->get_instructions_dgda($data);
                                
                                if(!empty($instructions))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = (($_SESSION['userdata']['account_id']) == "36") ? 1 : 0; 
                                        $logirefid = isset($_POST['Logirefid_4']) ? $_POST['Logirefid_4'] : 0;
                                        $type = 'others';
                                        
                                        $this->comptabilisationModel->save_first_instructions_dgda($id, $data, $instructions, $logirefid, $priority);
                                }
                        }
                        
                        return $id;
                }
                elseif($obj == "note")
                {
                        #Taxes comptes
                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];
                        $infos = $_POST['Infos'];
                        
                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);
                        
                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($_POST, $comptes);
                        
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';
                        
                        $taxeCodes =  $_POST['taxes'];
                        $amounts = $_POST['amounts'];
                        $taxes = array();
                        $amount = 0;
                        
                        for($i = 0; $i < count($taxeCodes); $i++):
                            
                            $taxe = new \stdClass();
                        
                            $taxe->taxeCode = $taxeCodes[$i];
                            
                            $Amount = str_replace(' ','',$amounts[$i]);
                            $taxe->taxeAmount = str_replace(',','.',$Amount);
                            $taxes[] = $taxe;
                            
                            $amount = $amount + $taxe->taxeAmount;
                            
                        endfor;
                      
                        $logirefid = $id;
                        
                        $data['Status_2'] = 0;
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Account_3'] = $this->session->userdata['account_id'];
                       
                        $data['Year_5'] = $infos['year'];
                        $data['Serie_7'] = $infos['serie'];
                        $data['Number_8'] = $infos['number'];
                        $data['Office_6'] = $_POST['Service_16'];
                        $data['Nif_9'] = $_POST['Nif_13'];
                        $data['Agent_10'] = $infos['Agent'];
                        $data['Bank_11'] = $infos['bank'];
                        
                        //Formatting amount
                        $data['Amount_12'] = str_replace(' ','',$_POST['Montant_11']);
                        $data['Amount_12'] = str_replace(',','.',$data['Amount_12']);
                        
                        $data['Commission_26'] = str_replace(' ','',$_POST['Commission_23']);
                        $data['Commission_26'] = str_replace(',','.',$data['Commission_26']);
                        
                        # The unique key of the payment
                        $montant =  intval($data['Amount_12']);
                        $data['Paiementkey_42'] = $data['Year_5'].$data['Office_6'].$data['Serie_7'].$data['Number_8'].$data['Nif_9'].$data['Bank_11'].$montant;
                       
                        // Details du bulletin
                        $result = new \stdClass();
                        $result->receiptDate = str_replace('-', '/', $_POST['Infos']['receiptdate']);
                        $result->receiptSerial = $_POST['Infos']['Qserie'];
                        $result->receiptNumber = $_POST['Infos']['Qnumber'];
                        $result->declarationsPaid = new \stdClass();
                       
                        $result->declarationsPaid->registrationYear = $_POST['Infos']['year'];
                        $result->declarationsPaid->assessmentSerial = $_POST['Infos']['serie'];
                        $result->declarationsPaid->assessmentNumber =  $_POST['Infos']['number'];
                        $result->declarationsPaid->amountToBePaid = $data['Amount_12'];
                        $result->declarationsPaid->taxesPaid = $taxes;
                        
                        
                        $data['Results_13'] = json_encode($result);
                        $data['Error_14'] = '0';
                        $data['User_15'] = $this->session->userdata['user_id'];
                        $data['Integration_16'] = gmdate('Y-m-d H:i:s');
                        $data['Printing_17'] = gmdate('Y-m-d H:i:s');
                        $data['Reference_19'] = $_POST['Reference_32'];
                        $data['Lot_22'] = 'saisi';
                        $data['Designation_23'] = $_POST['Designation_14'];
                        $data['Account_24'] = isset($comptes['DGDA']['CGU']['CDF']) ?  $comptes['DGDA']['CGU']['CDF'] : "";  // compte GU
                        $data['Amount_25'] = $data['Amount_12'] + $data['Commission_26'];  // Total amount
                        $data['Devise_27'] = $_POST['Devise_24'];
                        $data['Account_28'] = $_POST['Compte_33'];
                        $data['Devise_29'] = $_POST['Devise_34'];
                        $data['Mode_30'] = $_POST['Mode_19'];
                        $data['Taux_31'] = $_POST['Taux_41'];
                        $data['Agence_32'] = $_SESSION['Logiref_guichet'];
                        $data['Accountholder_33'] = (isset($_POST['Infos']['accountname']) && $_POST['Infos']['accountname'] != "")? $_POST['Infos']['accountname'] : '';
                        $data['Logirefid_34'] = $logirefid;
                        
                        
                        $id = $this->integrationModel->save_bulletin($data, NULL);
                        
                        //$id = 1;
                        
                        if($id != "")
                        {
                                $data = array();

                                $data['Designation_14'] = $_POST['Designation_14'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Agence_20']=$_SESSION['Logiref_agence'];
                                $data['Guichet_21']=$_SESSION['Logiref_guichet'];
                                $data['Mode_19'] = $_POST['Mode_19'];
                                $data['Typerecette_17'] = $_POST['Infos']['serie'].$_POST['Infos']['number'];
                                $data['Devise_34'] = 'CDF';
                                
                                //Formatting amount
                                $data['Montant_11'] = str_replace(' ','',$_POST['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                
                                $data['Devise_12'] = $_POST['Devise_34'];
                                $data['Compte_33'] = $_POST['Compte_33'];
                                $data['Noteid_26'] = $_POST['Infos']['serie'].$_POST['Infos']['number'];
                                $data['Notedate_27'] = gmdate('Y-m-d');
      
                                //Formatting amount
                                $data['Commission_23'] = str_replace(' ','',$_POST['Commission_23']);
                                $data['Commission_23'] = str_replace(',','.',$data['Commission_23']);
                                
                                $data['Devise_24'] = $_POST['Devise_24'];
                                $data['Nif_13'] = $_POST['Nif_13'];
                                $data['Service_16'] = isset($_POST['Service_16']) ? $_POST['Service_16'] : "";


                                # Reference operation for the payment
                                $data['refOp'] = $_POST['Reference_32'] ?? "";

                                # Comptabilisation
                                $instructions = $this->comptabilisation->get_instructions_dgda($data);

                                if (isset($data['refOp']))
                                        unset($data['refOp']);
                                
                                if(!empty($instructions))
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 0; 
                                        $this->comptabilisationModel->save_first_instructions_dgda($id, $data, $instructions, $logirefid, $priority);
                                }
                                
                                $return['id'] = $id;
                                $return['logirefid'] = $logirefid;
                                //$return['logirefid'] = '085035230325b884';
                                $return['code'] = 'E200';

                                return $return;
                        }
                        else 
                        {
                                return 0;
                        }
                }
                elseif($obj == "delete")
                {
                        $pid = 0;
                        // supression du bulletin 
                        $idBL = $this->othersModel->delete_bulletin($id);

                        // supression de l'eclatement 
                        if($idBL > 0)
                        {
                                $pid = $this->encaissementModel->delete_paiement_tresor_dgda_for_other_bl_type($id);
                                $pid = $this->encaissementModel->delete_paiement_propre_dgda_for_other_bl_type($id);
                        }
                        
                        // supression des écritutes du bulletin 
                        if($pid > 0)
                        {
                                $sup = $this->comptabilisationModel->delete_instructions_dgda($id);
                        }
                        
                        #Return
                        echo $idBL;
                        die;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "validate_paiments")
                {
                        $error = '';
                        if($_POST['Montant_11']=='0' || $_POST['Montant_11']=='') $error = "Veuillez pr&eacute;&ccedil;iser le montant pay&eacute;<br/>";
                        return $error;
                }
                elseif($obj == "get_commission")
                {
                        $cdata = $data;
                        $montant1 = str_replace(' ','',$cdata['montant']);
                        $montant2 = str_replace(',','.',$montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $rules = $this->feesModel->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur'])/100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif($rules['Valeur'] !='' && $rules['Unite'] !='')
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if(!empty($com) && $com['com']!=0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else
                        {
                                $cdata['commission'] = $cdata['montant']*0;
                                $cdata['devise'] = $cdata['devise'];
                        }
                        
                        if(isset($_SESSION['Bank_rates'])):
                            $taux = json_decode($_SESSION['Bank_rates'], true);
                        else: 
                            $taux['Dollar_4']  = 1;
                        endif;
                        
                        if($cdata['devise'] == $oDeivise)
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'];
                        }
                        else if($cdata['devise'] == 'USD')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']*$taux['Dollar_4']);
                        }
                        else if(result[1] == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + ($cdata['commission']/$taux['Dollar_4']);
                        }
                        else 
                        {
                                $cdata['total'] = 0;
                        }
                        
                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar; exit;
                }
                elseif ($obj == "get_feesbcc_tax") 
                {
                        $fees_bcc = 0;

                        $montant  = $arg;
                        $montant1 = str_replace(' ', '', $montant);
                        $montant2 = str_replace(',', '.', $montant1);
                        $taxe_amount = $montant2;

                        $recette = $data;

                        if (($_SESSION['userdata']['account_id'] ?? "") == "36") 
                        {
                                $result_taux = json_decode($_SESSION['Bank_rates'], true);
                                $taux = $result_taux['Dollar_4'];

                                $amount = round($taxe_amount/$taux, 2);

                                $rules = $this->feesModel->get_charges_by_fees_bcc(NULL, NULL, $recette, 'USD', $amount, NULL, 'BCC');
                        }
                        else
                        {
                                $rules = $this->feesModel->get_charges_by_fees_bcc(NULL, NULL, $recette, NULL, NULL, NULL, 'BCC');
                        }

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $fees_bcc = $taxe_amount * $rules['Valeur'];
                        } 

                        $ar = array('Valeur' => $fees_bcc);
                        return $ar;
                        exit;

                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
