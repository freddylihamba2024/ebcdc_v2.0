<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\accountModel;
use Modules\Branch\Models\OfflineModel;
use Modules\Branch\Models\ReportsModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\BulletinsModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Admin\Controllers\Stakeholders;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Branch\Models\ReversementModel;
use Modules\Branch\Models\EncaissementModel;
use Modules\Branch\Models\ComptabilisationModel;



class TaxOffline extends BaseController {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Glodi on the 17.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('beneficiaries','extractions','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'offline';

        public $integrationModel;
        public $logirefModel;   
        public $bulletinsModel;
        public $dataModel;
        public $comptabilisationMdel;
        public $usersModel;
        public $ratesModel;
        public $accountModel;
        public $feesModel;
        public $curlModel;
        public $prepaymentsModel;
        public $branchModel;
        public $mainModel;
        public $reportsModel;
        public $reversementModel;       
        public $offlineModel;
        public $stakeholderModel;
        public $encaissementModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is Branch 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->bulletinsModel = new BulletinsModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationMdel = new ComptabilisationModel();
                $this->usersModel = new UsersModel();
                $this->ratesModel = new RatesModel();
                $this->accountModel = new accountModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->feesModel = new FeesModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();
                $this->reportsModel = new ReportsModel();
                $this->reversementModel = new ReversementModel();
                $this->offlineModel = new OfflineModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->encaissementModel = new EncaissementModel();
                
                
                $this->folder = 'offline';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxoffline';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
	} 
	
        
	public function index()
	{
		$this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle) 
        {
                if (in_array($needle, $this->menus)) 
                {
                        $this->index();
                }
        }
   
        /*
         * Manages all the views
         * View calls are made here  
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "paiements")
                {   
                        
                        ini_set('memory_limit','8192M');
                        
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        $this->data['encaissements'] = $this->encaissementModel->get_nvalidated_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_to_export();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Branch\Views\offline\paiements', $this->data);
                }
                elseif($obj == "nvalidated_paiements")
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        $this->data['encaissements'] = $this->encaissementModel->get_nvalidated_to_integrate();
                        $this->data['bulletins'] = $this->integrationModel->get_bulletin_to_integrate();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_integrate();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Branch\Views\offline\nvalidated_paiements', $this->data);
                }
                elseif($obj == "nvalidated")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['integrations'] = $this->offlineModel->get_integrations("nvalidated");
                        
                        echo view('\Modules\Branch\Views\offline\nvalidated', $this->data);
                }
                elseif($obj == "validated")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['integrations'] = $this->offlineModel->get_integrations("validated");
                        $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_'.$obj, $this->data);
                        
                        echo view('\Modules\Branch\Views\offline\validated', $this->data);
                }
                elseif($obj =="integrations")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['integrations'] = $this->offlineModel->get_integrations("nvalidated");
                        
                        echo view('\Modules\Branch\Views\offline\integrations', $this->data);
                }
                elseif($obj =="extractions")
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        //$this->data['encaissements'] = $this->encaissementModel->get_nvalidated_to_integrate();
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_bulletin_to_extract();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_extract();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        if ($id ==NULL): 
                                echo view('\Modules\Branch\Views\offline\extractions', $this->data);
                        elseif ($id ==="search"):
                                echo view('\Modules\Branch\Views\offline\_filter_extractions', $this->data);
                        endif;
                        
                        //echo view('\Modules\Branch\Views\offline\extractions', $this->data);
                }
                elseif($obj == "search")
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        unset($this->data['beneficiaires']['RFP']);
                        
                        if($_POST['regie'] =="DGRAD" || $_POST['regie'] =="DGI")
                        {
                                $this->data['encaissements'] = $this->encaissementModel->filter_nvalidated_paiements($_POST['regie']);
                                $this->data['bulletins'] = array();
                                $this->data['prepayments'] = array();
                        }
                        else
                        {
                                $this->data['encaissements']  = array();
                                $this->data['bulletins'] = $this->integrationModel->get_unvalidated_to_export();
                                $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        }
                        
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Branch\Views\offline\_nvalidated', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "instructions")
                {
                        $return = array();
                        
                        if(!empty($_POST))
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                //Global
                                $total_instructions = 0;
                                $all_paiements = 0;
                                $total_amount = 0;
                                $paiements_dgi = '';
                                $paiements_dgrad = '';
                                $bulletins = '';
                                $prepayments = '';
                                
                                // DGI et DGRAD
                                $total_paiements = 0;
                                $total_paiements_instructions = 0;
                                $paiements_instructions = array();
                                
                                // BL
                                $total_bulletins = 0;
                                $total_instructions_bulletins = 0;
                                $bulletins_instructions = array();
                                
                                //Prepayments
                                $total_prepayments = 0;
                                $total_instructions_prepayments = 0;
                                $prepayments_instruction = array();
                                
                                if(isset($_POST['paiements']) && !empty($_POST['paiements']))
                                {
                                        $instructions_dgrad = array();
                                        $instructions_dgi = array();
                                        $total_dgi = 0;
                                        $total_dgrad = 0;
                                        
                                        if(isset($_POST['paiements']['DGI']) && !empty($_POST['paiements']['DGI']))
                                        {
                                                $total_dgi = count($_POST['paiements']['DGI']);
                                                $paiements_dgi =  implode(',', $_POST['paiements']['DGI']);
                                                $instructions_dgi = $this->offlineModel->get_dgi_instructions($paiements_dgi);
                                        }
                                        
                                        if(isset($_POST['paiements']['DGRAD']) && !empty($_POST['paiements']['DGRAD']))
                                        {
                                                $total_dgrad = count($_POST['paiements']['DGRAD']);
                                                $paiements_dgrad =  implode(',', $_POST['paiements']['DGRAD']);
                                                $instructions_dgrad = $this->offlineModel->get_dgrad_instructions($paiements_dgrad);
                                        }
                                        
                                        
                                        $paiements_instructions = array_merge($instructions_dgi,$instructions_dgrad); 
                                        $total_paiements_instructions =  count($paiements_instructions);
                                        
                                        $total_paiements = $total_dgi + $total_dgrad;
                                        $all_paiements = $all_paiements + $total_paiements;
                                        $total_amount = $total_amount + array_sum($_POST['amounts_paiements']);
                                       
                                }
                                
                                if(isset($_POST['bulletins']) && !empty($_POST['bulletins']))
                                {
                                        $total_bulletins = count($_POST['bulletins']);
                                        $all_paiements = $all_paiements + $total_bulletins;
                                        
                                        $bulletins = implode(',', $_POST['bulletins']);
                                        $bulletins_instructions = $this->offlineModel->get_bulletins_instructions($bulletins);
                                        
                                        $total_instructions_bulletins = count($bulletins_instructions);
                                        $total_amount = $total_amount + array_sum($_POST['amounts_bulletins']);
                                }
                                                                
                                if(isset($_POST['prepayments']) &&!empty($_POST['prepayments']))
                                {
                                        $total_prepayments = count($_POST['prepayments']);
                                        $all_paiements = $all_paiements + $total_prepayments;
                                        
                                        $prepayments = implode(',', $_POST['prepayments']);
                                        $prepayments_instruction = $this->offlineModel->get_prepayments_instructions($prepayments);
                                        
                                        $total_instructions_prepayments = count($prepayments_instruction);
                                        $total_amount = $total_amount + array_sum($_POST['amounts_prepayments']);
                                }
                                
                                $total_instructions = $total_paiements_instructions + $total_instructions_bulletins + $total_instructions_prepayments;
                                
                                $instructions = array_merge($paiements_instructions,$bulletins_instructions,$prepayments_instruction);
                                
                                if(!empty($instructions))
                                {
                                        $data['Instructions_7'] = json_encode($instructions);
                                        $data['Paiements_10'] = $all_paiements;
                                        $data['Instructions_11'] = $total_instructions;
                                        $data['Agence_14'] = $_SESSION['Logiref_guichet'];
                                        $data['Montant_12'] = $total_amount;
                                        $data['Regie_13'] = 'TOUTES';
                                        $data['Devise_16'] = 'CDF';
                                        
                                        $paiements = array();
                                        $paiements['bls']= $bulletins;
                                        $paiements['prepayments']= $prepayments;
                                        $paiements['DGI']= $paiements_dgi;
                                        $paiements['DGRAD']= $paiements_dgrad;
                                        
                                        $data['Paiements_17'] = json_encode($paiements);
                                        
                                        $pid = $this->offlineModel->save_integrations($data, $id);
                                        
                                        if($pid > 0)
                                        {
                                                $return['code'] = '200';
                                                $return['pid'] = $pid;
                                                $return['message'] = 'Bravo! enregistrement eff&eacute;ctu&eacute; avec succ&egrave;s...!';
                                        }
                                        else
                                        {
                                                $return['code'] = '202';
                                                $return['pid'] = 0;
                                                $return['message'] = 'Echec de l\'enregistrement, veuillez r&eacute;essayer...!';
                                        }
                                }
                                else
                                {
                                        $return['code'] = '400';
                                        $return['pid'] = 0;
                                        $return['message'] = 'Aucune instrcution n&apos;a &eacute;t&eacute; trouv&eacute;e!...rassurez-vous que les paiements s&eacute;l&eacute;ctionn&eacute;es ne sont pas valid&eacute;es...!';
                                }
                                
                        }
                        else
                        {
                                $return['code'] = '501';
                                $return['pid'] = 0;
                                $return['message'] = 'Aucune donn&eacute;e &agrave; enregistrer...!';
                        }

                        echo json_encode($return);
                }
                elseif($obj == "updatepath")
                {
                        if($id != "")
                        {
                                $data['Pathexcel_8'] = $arg;
                                $pid = $this->offlineModel->save_integrations($data, $id);
                                
                                if($pid > 0)
                                {
                                        
                                        if(isset($_POST['bulletins']) && !empty($_POST['bulletins']))
                                        {
                                                $data = array();
                                                $data['Status_2'] = 7;
                                                $ids = implode(",", $_POST['bulletins']);

                                                $this->integrationModel->update_bulletin($data, $ids);
                                        }

                                        if(isset($_POST['paiements']['DGI']) && !empty($_POST['paiements']['DGI']))
                                        {
                                                $data = array();
                                                $data['Status_2'] = 7;
                                                $ids = implode(",", $_POST['paiements']['DGI']);

                                                $this->reversementModel->update_payment_tresor($data, $ids);
                                        }

                                        if(isset($_POST['paiements']['DGRAD']) && !empty($_POST['paiements']['DGRAD']))
                                        {
                                                $data = array();
                                                $data['Status_2'] = 7;
                                                $ids = implode(",", $_POST['paiements']['DGRAD']);

                                                $this->reversementModel->update_payment_tresor($data, $ids);
                                        }

                                        if(isset($_POST['prepayments']) &&!empty($_POST['prepayments']))
                                        {

                                                $data = array();
                                                $data['Status_2'] = 7;
                                                $ids = implode(",", $_POST['prepayments']);

                                                $this->prepaymentsModel->update_prepayement($data, $ids);

                                        }
                                        return $pid;
                                }
                                else
                                {
                                       return '404';
                                }
                                
                        }
                        else
                        {
                                echo '501'; die;
                        }
                }
                elseif($obj == "confirmation")
                {
                        $lot = $this->offlineModel->get_integration_offline_info($id);
                        
                        $paiements = json_decode($lot->Paiements_17, true); 
                       
                        
                        if(isset($paiements['bls']) && !empty($paiements['bls']))
                        {
                                $data = array();
                                $data['Status_2'] = 3;
                                $ids = $paiements['bls'];

                               $bid =  $this->integrationModel->update_bulletin($data, $ids);
                        }

                        if(isset($paiements['DGI']) && !empty($paiements['DGI']))
                        {
                                $data = array();
                                $data['Status_2'] = 1;
                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                $data['Validation_36'] = gmdate('Y-m-d H:i:s');
                                $ids = $paiements['DGI'];

                               $pid = $this->reversementModel->update_payment_tresor($data, $ids);
                        }

                        if(isset($paiements['DGRAD']) && !empty($paiements['DGRAD']))
                        {
                                $data = array();
                                $data['Status_2'] = 1;
                                $data['Checkerid_10'] = $this->session->userdata["user_id"];
                                $data['Validation_36'] = gmdate('Y-m-d H:i:s');
                                $ids = $paiements['DGRAD'];

                                $pid = $this->reversementModel->update_payment_tresor($data, $ids);
                        }

                        if(isset($paiements['prepayments']) &&!empty($paiements['prepayments']))
                        {

                                $data = array();
                                
                                $ids = $paiements['prepayments'];
                                
                                $quittances = $this->prepaymentsModel->get_prepayments_by_lot($ids);
                                $messagekeys = array();
                                
                                foreach($quittances as $quittance)
                                {
                                    $messagekeys[] = $quittance->MessageKey_7;
                                }
                                
                                
                                $_POST['messageKey'] = $messagekeys;
                                $_POST['codeTr'] = "OK";

                                //Sydonia credantials

                                $user = $this->session->userdata['user_id'];
                                $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);

                                $response = $this->curl_model->call_dgda_send_ack_prepayments($credentials);
                                if($response == "OK")$data['Status_2']  = 6;
                                else $data['Status_2']  = 3;
                                
                                $this->prepaymentsModel->update_prepayement($data, $ids);
                                
                                $data_to_validate['Status_2'] = 1;
                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                $tid = $this->encaissementModel->update_prepayment_tresor_dgda($data_to_validate, $ids);

                        }
                        
                        $data = array();
                        $data['Status_2'] = 2;
                        $rid = $this->offlineModel->update_integrations($data, $id);
                        
                        echo $rid; 
                }
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        { 
                if($obj == "_export_to_excel")
                {
                        $carct = array('-','&');
                        $data = str_replace('v', '', $data);
                        $integrations = $this->offlineModel->get_integration_offline_info($data);
                        $comptes = $this->accountModel->get_comptes_inter_agence_array("'CIA'");
                        $lines = json_decode($integrations->Instructions_7);
                        $regie = 'DGDA';

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        
                        //name the worksheet
                        $worksheet->setTitle('bkMvtl12032021');
                        
                        $erow = 1;
                        $i = 0;
                        
                        $array_length = count($lines);
                        
                        foreach($lines as $row)
                        { 
                            
                            $compte_source = explode('-', $row->Compte_9);
                            $agence_source =  isset($compte_source[0]) ? $compte_source[0] : "";
                            
                            $compte_destination = explode('-', $row->Compte_13);
                            $agence_destination =  isset($compte_destination[0]) ? $compte_destination[0] : "";
                            
                           
                            if($row->Montant_10 > 0)
                            {
                                
                                if($row->Devise_11 == 'CDF')
                                {
                                    $devise = '181';
                                }
                                else
                                {
                                    $devise = '179';
                                }

                                $worksheet->getStyle('E')->getNumberFormat()->setFormatCode('#,##0.00');

                                if($agence_source != $agence_destination)
                                {
                                       
                                        /** Agence source **/
                                        ############################# Debit row ####################################
                                        
                                        $result = explode('-', $row->Compte_9);
                                        $account = isset($result[1]) ? $result[1] : "";
                                        $agence =  isset($result[0]) ? $result[0] : "";
                                        $cle = isset($result[2]) ? $result[2] : "";

                                        $worksheet->setCellValueByColumnAndRow(0, $erow, $agence);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $account);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $cle);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, '0106');

                                        
                                        ############################# Credit row ####################################
                                        $erow++;
                                        $compte_cia_source = isset($comptes[$agence_source]['CIA']['CDF'])? $comptes[$agence_source]['CIA']['CDF'] :'' ;
                                        $result = ($compte_cia_source != 0)? explode('-', $compte_cia_source) : "";
                                        $account_CIA_source = isset($result['1'])? $result['1'] :""; 
                                        $key_source = isset($result['2'])? $result['2'] : "";
 
                                        $worksheet->setCellValueByColumnAndRow(0, $erow, $agence_source);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $account_CIA_source);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $key_source);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, '0106');
                                        
                                        /** Agence destination **/
                                         ############################# Debit row #####################################
                                        $erow++;
                                        $compte_cia_destination = isset($comptes[$agence_destination]['CIA']['CDF'])? $comptes[$agence_destination]['CIA']['CDF'] :'';
                                        $result = ($compte_cia_destination !=0)? explode('-', $compte_cia_destination) :"";
                                        $account_CIA_destination = isset($result['1']) ? $result['1'] :""; 
                                        $key_destination = isset($result['2'])? $result['2'] :"" ;

                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence_destination);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $account_CIA_destination);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $key_source);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');
                                        
                                        ############################# Credit row ####################################
                                        $erow++;
                                        $result = explode('-', $row->Compte_13);
                                        $account = isset($result[1]) ? $result[1] : "";
                                        $agence =  isset($result[0]) ? $result[0] : "";
                                        $cle = isset($result[2]) ? $result[2] : "";

                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $account);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $cle);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');
                                        $i++;
                                }
                                else
                                {
                                        ############################# Debit row #####################################

                                        $result = explode('-', $row->Compte_9);
                                        $account = isset($result[1]) ? $result[1] : "";
                                        $agence =  isset($result[0]) ? $result[0] : "";
                                        $cle = isset($result[2]) ? $result[2] : "";

                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $account);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $cle);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');
                                        ############################# Credit row #####################################
                                        $erow++;
                                        
                                        $result = explode('-', $row->Compte_13);
                                        $account = isset($result[1]) ? $result[1] : "";
                                        $agence =  isset($result[0]) ? $result[0] : "";
                                        $cle = isset($result[2]) ? $result[2] : "";

                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $account);
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $cle);
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');
                                       
                                        $i++;

                                }


                                if($i != $array_length)
                                {   
                                        $erow++;
                                }
                            }
                        }

                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];
                        
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_integration_'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        
                        $account_id = $this->session->userdata['account_id'];
                        $path = "./drive/logiref/".$account_id."/".date('Y-m').'/integration';
                        
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $path = $path."/".$filename;
                        //save the file on the server's HD
                        $objWriter->save($path);
                        
                        //$writer = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        //$writer->save('php://output');
                        
                       $rerturn =  $this->save('updatepath', $data, $path);
                        
                       if($rerturn > 0 && $rerturn!= '404' && $rerturn!= '501')
                       {
                                echo $path;
                       }
                       else
                       {
                           echo $rerturn;
                       }
                }
                elseif ($obj == "export_to_excel") 
                {
                        $carct = array('-', '&');
                        $data = str_replace('v', '', $data);
                        $integrations = $this->offlineModel->get_integration_offline_info($data);
                        $comptes = $this->accountModel->get_comptes_inter_agence_array("'CIA'");
                        $lines = json_decode($integrations->Instructions_7);
                        $regie = 'DGDA';

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; // Colonne H
                        
                        // Activate first sheet
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        $worksheet->setTitle('bkMvtl' . date('dmY'));

                        $erow = 1;
                        $i = 0;
                        $array_length = count($lines);

                        foreach ($lines as $row) 
                        {
                                $compte_source = explode('-', $row->Compte_9);
                                $agence_source = isset($compte_source[0]) ? $compte_source[0] : "";

                                $compte_destination = explode('-', $row->Compte_13);
                                $agence_destination = isset($compte_destination[0]) ? $compte_destination[0] : "";

                                if ($row->Montant_10 > 0) {
                                $devise = ($row->Devise_11 == 'CDF') ? '181' : '179';

                                $worksheet->getStyle('E')->getNumberFormat()->setFormatCode('#,##0.00');

                                if ($agence_source != $agence_destination) 
                                {
                                        /** -------- Agence source -------- */
                                        // Debit row
                                        $result = explode('-', $row->Compte_9);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $result[0] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        // Credit row (CIA source)
                                        $erow++;
                                        $compte_cia_source = $comptes[$agence_source]['CIA']['CDF'] ?? '';
                                        $result = ($compte_cia_source != '') ? explode('-', $compte_cia_source) : [];
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence_source);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        /** -------- Agence destination -------- */
                                        // Debit row (CIA destination)
                                        $erow++;
                                        $compte_cia_destination = $comptes[$agence_destination]['CIA']['CDF'] ?? '';
                                        $result = ($compte_cia_destination != '') ? explode('-', $compte_cia_destination) : [];
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $agence_destination);
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        // Credit row (Compte destination)
                                        $erow++;
                                        $result = explode('-', $row->Compte_13);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $result[0] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        $i++;
                                } 
                                else 
                                {
                                        /** -------- Même agence -------- */
                                        // Debit row
                                        $result = explode('-', $row->Compte_9);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $result[0] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'D');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        // Credit row
                                        $erow++;
                                        $result = explode('-', $row->Compte_13);
                                        $worksheet->setCellValueByColumnAndRow(1, $erow, $result[0] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(2, $erow, $result[1] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(3, $erow, $result[2] ?? "");
                                        $worksheet->setCellValueByColumnAndRow(4, $erow, $devise);
                                        $worksheet->setCellValueByColumnAndRow(5, $erow, $row->Montant_10);
                                        $worksheet->setCellValueByColumnAndRow(6, $erow, 'C');
                                        $worksheet->setCellValueByColumnAndRow(7, $erow, str_replace($carct, '', $row->Libelle_12));
                                        $worksheet->setCellValueByColumnAndRow(8, $erow, '0106');

                                        $i++;
                                }

                                        if ($i != $array_length) 
                                        {
                                                $erow++;
                                        }
                                }
                        }

                        // Auto-size columns
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        // Apply borders
                        $styleArray = [
                                'borders' => [
                                        'allBorders' => [
                                                'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                                'color' => ['argb' => '000000'],
                                        ],
                                ],
                        ];
                        
                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        // Build filename + save path
                        $user_id = $this->session->userdata['user_id'];
                        $filename = $user_id . '_' . $regie . '_extraction_' . time() . '.xlsx';
                        $account_id = $this->session->userdata['account_id'];
                        $path = "./drive/logiref/" . $account_id . "/" . date('Y-m') . '/extraction';

                        if (!is_dir($path)) 
                        {
                                mkdir($path, 0777, true);
                        }
                        
                        $path = $path . "/" . $filename;

                        // Save Excel file
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        // retourne l’URL publique
                        echo base_url(str_replace("./", "", $path));
                }
                elseif($obj == "OBJ ")
                {
                        
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */