<?php

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\ImmatriculationModel;
use Modules\Logiref\Models\InvLogirefModel;

class TaxImmatriculationOnline extends BaseController
{
        public $menus = array('payments_to_regularize', 'payments_to_treat');
        public $module = 'branch';
        public $folder = 'immatriculation_online';
        public $data = [];
        public $branchModel;
        public $immatriculationModel;
        public $invLogirefModel;

        public function __construct()
        {
                parent::__construct();

                $this->branchModel = new BranchModel();
                $this->immatriculationModel = new ImmatriculationModel();
                $this->invLogirefModel = new InvLogirefModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taximmatriculationonline';
                $this->data['function'] = '';
                $this->data['folder'] = $this->folder;
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        public function set($needle)
        {
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
        }

        public function display($obj = null, $id = null, $arg = null, $param = null)
        {
                if($obj == 'payments_to_regularize')
                {
                        $this->data['payments'] = $this->immatriculationModel->get_online_immatriculation_payments_by_status(10, 500);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['immatriculationRegularizationStatus'] = $this->invLogirefModel->immatriculationRegularizationStatus;

                        echo view('\Modules\Branch\Views\immatriculation_online\payments_to_regularize', $this->data);
                }
                elseif($obj == 'payments_to_treat')
                {
                        $this->data['payments'] = $this->immatriculationModel->get_online_immatriculation_payments_by_status(9, 500);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['immatriculationRegularizationStatus'] = $this->invLogirefModel->immatriculationRegularizationStatus;

                        echo view('\Modules\Branch\Views\immatriculation_online\payments_to_treat', $this->data);
                }
        }

        public function save($obj = null, $id = null, $arg = null, $param = null)
        {
                if($obj == 'process_payment')
                {
                        $response = $this->immatriculationModel->process_online_immatriculation_payment($id);

                        return $this->response->setJSON($response);
                }
        }
}
