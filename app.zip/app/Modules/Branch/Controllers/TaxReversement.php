<?php

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Branch\Models\ReversementModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Branch\Models\ReportsModel;


class TaxReversement extends BaseController {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Glodi on the 20.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('beneficiaries','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'reversement';
        public $integrationModel;
        public $comptabilisationModel;
        public $logirefModel;
        public $prepaymentsModel;
        public $reversementModel;
        public $reportsModel;
        public $bank;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->reversementModel = new ReversementModel();
                $this->reportsModel = new ReportsModel();

                $this->folder = 'reversement';

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxreversement';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;

                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
	}


	public function index()
	{
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
	}


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
	public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if ($obj === 'dgrk') {
                        $options = json_decode($_SESSION['userdata']['options'] ?? '{}', true);
                        if (!array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                                echo '<div class="alert aWarning text-white">La fonctionnalité Taxes provinciales n’est pas activée.</div>';
                                return;
                        }
                        $offset = max(0, (int) ($id ?? 0));
                        $this->data['encaissements_dgrk'] = $this->reportsModel->get_dgrk_reversement_page($offset, 100);
                        $this->data['dgrk_offset'] = $offset;
                        $this->data['dgrk_has_next'] = count($this->data['encaissements_dgrk']) === 100;
                        echo view('\\Modules\\Branch\\Views\\reversement\\reversement_dgrk', $this->data);
                        return;
                }
                if($obj == "start")
                {
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reversementModel->get_paiements_to_reverse();
                        $this->data['encaissements_immatriculation'] = [];

                        # Retrieve the data_submitted from the form in order to put them in the session variable for export.
                        $_SESSION['data_submitted'] = $_POST;

                        echo view('\Modules\Branch\Views\reversement\_reverse', $this->data);
                }
                elseif($obj == "start_passports")
                {
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reversementModel->get_paiements_passports_to_reverse();
                        $this->data['encaissements_immatriculation'] = [];
                       
                        # Retrieve the data_submitted from the form in order to put them in the session variable for export.
                        $_SESSION['data_submitted'] = $_POST;

                        echo view('\Modules\Branch\Views\reversement\_reverse_passport', $this->data);
                }
                elseif($obj == "start_inv")
                {
                        $request = service('request');

                        if (!$request->isAJAX()) {
                                return redirect()->back();
                        }

                        $ids = $request->getPost('ids');
                        if (empty($ids)) {
                                $ids = $request->getPost('paiements');
                        }

                        if (empty($ids)) {
                                echo '<div class="alert alert-warning">Aucun paiement sélectionné.</div>';
                                return;
                        }

                        if (!is_array($ids)) {
                                $ids = [$ids];
                        }

                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['encaissements'] = [];
                        $this->data['encaissements_immatriculation'] = $this->reversementModel->get_paiements_by_ids($ids);

                        $_SESSION['data_submitted'] = $_POST;

                        echo view('\Modules\Branch\Views\reversement\_reverse', $this->data);
                }
                elseif($obj == "export")
                {
                        if($id != NULL)
                        {
                                $reversements = $this->integrationModel->get_reversement_info($id);

                                $paiements = json_decode($reversements->Paiementids_23, true);

                                if(isset($paiements['autres']) && $paiements['autres'] !="")
                                {
                                        $_POST['paiements'] = $paiements['autres'];
                                }
                                elseif($paiements['dgda'] && $paiements['dgda'] !="")
                                {
                                        $_POST['bulletins'] = $paiements['dgda'];
                                }
                                elseif($paiements['dgda_prepayments'] && $paiements['dgda_prepayments'] !="")
                                {
                                        $_POST['prepayments'] = $paiements['dgda_prepayments'];
                                }

                                $reversements = $this->reversementModel->get_paiements_to_reverse();

                        }
                        else
                        {
                                $_POST = $_SESSION['data_submitted'];
                                //unset($_SESSION['data_submitted']);
                                # New paiement to reverse into ISYS-REGIES
                                $reversements = $this->reversementModel->get_paiements_to_reverse();
                        }

                        $regie = "";
                        $periode_mois = "";
                        $periode_paiement = "";

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[15];

                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('V_REG_NOTE_PERCEPTION');

                        //set cell A1 content with some text

                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = ["Numero Relevé Paiement", "Numero Titre de Perception", "Numero Impot", "Désignation", "Période", "Montant Note", "Date Note", "Numero Quittance", "Numero Paiement", "Montant", "Devise", "Date de Paiement", "Regie", "Code Service Recouvrement", "Code Type Recette Etat", "Message Retour"];
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {
                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);

                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;

                        $array_length = count($reversements);

                        $province = $this->logirefModel->get_dropdown('code_province');

                        $my_tab = array();
                        $numero_amplitude_dgda = array();

                        foreach($reversements as $row)
                        {
                                if($row->Montant_11 > 0)
                                {
                                        $code_province = isset($province[$_SESSION['Logiref_province']]) ? $province[$_SESSION['Logiref_province']] : "";
                                        $regie = $row->Beneficaire_15;

                                        # Get the bank name
                                        $bank = str_replace('@', '', $this->data['bank']);
                                        $bank = ucfirst($bank);

                                        $numero_releve = $bank."".$code_province."".$regie."".gmdate('Y')."".gmdate('m')."".gmdate('d');

                                        $Infos = json_decode($row->Notereference_30, true);

                                        if((isset($Infos['standard']) && $Infos['standard'] !="") && $regie =='DGI')
                                        {
                                                #$Infos['standard'] = strftime('%d-%m-%Y',strtotime($Infos['standard']));
                                                $date = explode("-", $Infos['standard']);
                                                if(count($date) == 3)
                                                {
                                                        $periode_mois = $date[1]."-".$date[0];
                                                }
                                                elseif(count($date) == 2)
                                                {
                                                        $periode_mois = $date[0]."-".$date[1];
                                                }

                                        }
                                        else
                                        {
                                                $periode_mois = "";
                                        }

                                        if($regie=='DGRAD' || $regie=='DGI')
                                        {
                                                if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                                {
                                                        $numero_paiement = $Infos['Num_evenement'];
                                                }
                                                else
                                                {
                                                        $numero_paiement = $row->Id_0;
                                                }
                                        }
                                        else
                                        {
                                                $recette_tresor_dgda = $this->logirefModel->get_dropdown('recettes_dgda_tresor');


                                                if(isset($row->Sydonia_44) && $row->Sydonia_44 !="")
                                                {
                                                        $istructions = $this->comptabilisationModel->get_instructions_dgda($row->Sydonia_44);
                                                }

                                                // for prepayments
                                                elseif(isset($row->Sydonia_49) && $row->Sydonia_49 !="")
                                                {
                                                        $istructions = $this->comptabilisationModel->get_instructions_dgda_prepayment($row->Sydonia_49);
                                                }

                                                foreach ($istructions as $line)
                                                {
                                                        foreach($recette_tresor_dgda as $needle)
                                                        {
                                                                $str = substr_count($line->Libelle_12, $row->Noteid_26." - ".$needle);
                                                                if($str !=0)
                                                                {
                                                                        $my_tab[$line->Id_0] = $needle;
                                                                }
                                                        }
                                                }


                                                if(isset($row->Sydonia_44) && $row->Sydonia_44 !="")
                                                {
                                                        $cbs_returns = $this->integrationModel->get_cbs_returns_dgda($row->Sydonia_44);
                                                }
                                                // for prepayments
                                                elseif(isset($row->Sydonia_49) && $row->Sydonia_49 !="")
                                                {
                                                        $cbs_returns = $this->integrationModel->get_cbs_returns_dgda_prepayments($row->Sydonia_49);
                                                }

                                                if(isset($cbs_returns->Result_6))
                                                {
                                                        $cbs_returns = json_decode($cbs_returns->Result_6, true);
                                                }
                                                else
                                                {
                                                        $cbs_returns = array();
                                                }

                                                if(!empty($cbs_returns))
                                                {
                                                        foreach($cbs_returns as $key=>$turn)
                                                        {
                                                                foreach($my_tab as $cle=>$ligne)
                                                                {
                                                                        if($key == $cle)
                                                                        {
                                                                                if(isset($turn['Num_evenement']) && $turn['Num_evenement'] !="")
                                                                                {
                                                                                        $numero_amplitude_dgda[$ligne] = $turn['Num_evenement'];
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }

                                                if(!empty($numero_amplitude_dgda))
                                                {
                                                        if(isset($numero_amplitude_dgda[$row->Typerecette_17]) && $numero_amplitude_dgda[$row->Typerecette_17] !="")
                                                        {
                                                                $numero_paiement = $numero_amplitude_dgda[$row->Typerecette_17];
                                                        }
                                                        else
                                                        {
                                                                $numero_paiement = $row->Id_0;
                                                        }
                                                }
                                                else
                                                {
                                                        $numero_paiement = $row->Id_0;
                                                }
                                        }

                                        if($row->Designation_14 !="") $designation = $row->Designation_14;
                                        else $designation = $row->Nif_13;

                                        if($row->Sydonia_44 !="" || $row->Sydonia_49 !="")
                                        {
                                                if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                {
                                                        $numquittance = $Infos['quittanceid'];
                                                }
                                                else
                                                {
                                                        $numquittance = "";
                                                }
                                        }

                                        #Periode quand il s'agit de paiement DGI et DGRAD d'un BL
                                        if(($regie =='DGI' || $regie == 'DGRAD') && ($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0'))
                                        {
                                                $date_valeur = explode('-',$row->Datevaleur_31 );

                                                if(count($date_valeur) == 3)
                                                {
                                                        $periode_paiement = $date_valeur[1]."".$date_valeur[0];
                                                }
                                        }
                                        # Montant paye
                                        $montant = $row->Montant_11;


                                        if($row->Typerecette_17 =='IPRIER' || $row->Typerecette_17 =='IRPPDR11')
                                        {
                                                if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                {
                                                        $montant = $Infos['QuotasDGI'];
                                                }
                                        }

                                        $note_montant = $row->Notemontant_28;

                                        $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));

                                        $cellCoordinateN = 'N';
                                        $worksheet->getStyle($cellCoordinateN)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                                        // Exemple pour définir le format de colonne E en tant que texte
                                        $cellCoordinateE = 'E';
                                        $worksheet->getStyle($cellCoordinateE)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);

                                        $cellCoordinateG = 'G';
                                        $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                        $cellCoordinateG = 'L';
                                        $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                        $cellCoordinateJ = 'J';
                                        $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                        $cellCoordinateJ = 'F';
                                        $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                        $worksheet->setCellValue('A'.$erow, $numero_releve);
                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Nif_13);
                                        $worksheet->setCellValue('D'.$erow, $designation);
                                        if(($regie =='DGI' || $regie == 'DGRAD') && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('E'.$erow, $periode_paiement.' ');
                                        else $worksheet->setCellValue('E'.$erow, $periode_mois.' ');
                                        $worksheet->setCellValue('F'.$erow, $row->Notemontant_28);
                                        //if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_paiement);
					if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_note);
                                        else $worksheet->setCellValue('G'.$erow, $date_note);
                                        $worksheet->setCellValue('H'.$erow, $numquittance);
                                        $worksheet->setCellValue('I'.$erow, $numero_paiement.' ');
                                        $worksheet->setCellValue('J'.$erow, $montant);
                                        $worksheet->setCellValue('K'.$erow, $row->Devise_12);
                                        $worksheet->setCellValue('L'.$erow, $date_paiement);
                                        $worksheet->setCellValue('M'.$erow, $row->Beneficaire_15);
										if($row->Beneficaire_15 == 'DGRAD' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow, ' GU-DGRAD ');
										elseif($row->Beneficaire_15 == 'DGI' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow,' GU-DGI');
                                        else $worksheet->setCellValue('N'.$erow, $row->Service_16);
                                        $worksheet->setCellValue('O'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('P'.$erow, "");
                                        $i++;

                                        if($i != $array_length)
                                        {
                                            $erow++;
                                        }
                                }
                        }

                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_fichier_isys_'.time().'.xlsx';

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');


                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/isys-regies';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;


                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                $_POST['Filepath_24'] = $path;
                                $_POST['paiements_list'] = $reversements;

                                $pid = $this->save("reversement");

                                if($pid > 0)
                                {
                                         return $path;
                                }
                                else
                                {
                                    return 'E201';
                                }
                        }
                        else
                        {
                                return 'E401';
                        }
                }
                elseif($obj == "export_immatriculation")
                {
                        if($id != NULL)
                        {
                                $reversements = $this->integrationModel->get_reversement_info($id);

                                $paiements = json_decode($reversements->Paiementids_23, true);

                                if(isset($paiements['autres']) && $paiements['autres'] !="")
                                {
                                        $_POST['paiements'] = $paiements['autres'];
                                }
                                elseif($paiements['dgda'] && $paiements['dgda'] !="")
                                {
                                        $_POST['bulletins'] = $paiements['dgda'];
                                }
                                elseif($paiements['dgda_prepayments'] && $paiements['dgda_prepayments'] !="")
                                {
                                        $_POST['prepayments'] = $paiements['dgda_prepayments'];
                                }

                                $reversements = $this->reversementModel->get_paiements_immatriculation_to_reverse();

                        }
                        else
                        {
                                $_POST = $_SESSION['data_submitted'];
                                //unset($_SESSION['data_submitted']);
                                # New paiement to reverse into ISYS-REGIES
                                $reversements = $this->reversementModel->get_paiements_immatriculation_to_reverse();
                        }

                        $regie = "";
                        $periode_mois = "";
                        $periode_paiement = "";

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[15];

                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('V_REG_NOTE_PERCEPTION');

                        //set cell A1 content with some text

                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = ["Numero Relevé Paiement", "Numero Titre de Perception", "Numero Impot", "Désignation", "Période", "Montant Note", "Date Note", "Numero Quittance", "Numero Paiement", "Montant", "Devise", "Date de Paiement", "Regie", "Code Service Recouvrement", "Code Type Recette Etat", "Message Retour"];
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {
                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);

                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;

                        $array_length = count($reversements);

                        $province = $this->logirefModel->get_dropdown('code_province');

                        $my_tab = array();
                        $numero_amplitude_dgda = array();

                        foreach($reversements as $row)
                        {
                                if($row->Montant_11 > 0)
                                {
                                        $code_province = isset($province[$_SESSION['Logiref_province']]) ? $province[$_SESSION['Logiref_province']] : "";
                                        $regie = $row->Beneficaire_15;

                                        # Get the bank name
                                        $bank = str_replace('@', '', $this->data['bank']);
                                        $bank = ucfirst($bank);

                                        $numero_releve = $bank."".$code_province."".$regie."".gmdate('Y')."".gmdate('m')."".gmdate('d');

                                        $Infos = json_decode($row->Notereference_30, true);

                                        if((isset($Infos['standard']) && $Infos['standard'] !="") && $regie =='DGI')
                                        {
                                                #$Infos['standard'] = strftime('%d-%m-%Y',strtotime($Infos['standard']));
                                                $date = explode("-", $Infos['standard']);
                                                if(count($date) == 3)
                                                {
                                                        $periode_mois = $date[1]."-".$date[0];
                                                }
                                                elseif(count($date) == 2)
                                                {
                                                        $periode_mois = $date[0]."-".$date[1];
                                                }

                                        }
                                        else
                                        {
                                                $periode_mois = "";
                                        }

                                        if($regie=='DGRAD' || $regie=='DGI')
                                        {
                                                if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                                {
                                                        $numero_paiement = $Infos['Num_evenement'];
                                                }
                                                else
                                                {
                                                        $numero_paiement = $row->Id_0;
                                                }
                                        }
                                        else
                                        {
                                                $recette_tresor_dgda = $this->logirefModel->get_dropdown('recettes_dgda_tresor');


                                                if(isset($row->Sydonia_44) && $row->Sydonia_44 !="")
                                                {
                                                        $istructions = $this->comptabilisationModel->get_instructions_dgda($row->Sydonia_44);
                                                }

                                                // for prepayments
                                                elseif(isset($row->Sydonia_49) && $row->Sydonia_49 !="")
                                                {
                                                        $istructions = $this->comptabilisationModel->get_instructions_dgda_prepayment($row->Sydonia_49);
                                                }

                                                foreach ($istructions as $line)
                                                {
                                                        foreach($recette_tresor_dgda as $needle)
                                                        {
                                                                $str = substr_count($line->Libelle_12, $row->Noteid_26." - ".$needle);
                                                                if($str !=0)
                                                                {
                                                                        $my_tab[$line->Id_0] = $needle;
                                                                }
                                                        }
                                                }


                                                if(isset($row->Sydonia_44) && $row->Sydonia_44 !="")
                                                {
                                                        $cbs_returns = $this->integrationModel->get_cbs_returns_dgda($row->Sydonia_44);
                                                }
                                                // for prepayments
                                                elseif(isset($row->Sydonia_49) && $row->Sydonia_49 !="")
                                                {
                                                        $cbs_returns = $this->integrationModel->get_cbs_returns_dgda_prepayments($row->Sydonia_49);
                                                }

                                                if(isset($cbs_returns->Result_6))
                                                {
                                                        $cbs_returns = json_decode($cbs_returns->Result_6, true);
                                                }
                                                else
                                                {
                                                        $cbs_returns = array();
                                                }

                                                if(!empty($cbs_returns))
                                                {
                                                        foreach($cbs_returns as $key=>$turn)
                                                        {
                                                                foreach($my_tab as $cle=>$ligne)
                                                                {
                                                                        if($key == $cle)
                                                                        {
                                                                                if(isset($turn['Num_evenement']) && $turn['Num_evenement'] !="")
                                                                                {
                                                                                        $numero_amplitude_dgda[$ligne] = $turn['Num_evenement'];
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }

                                                if(!empty($numero_amplitude_dgda))
                                                {
                                                        if(isset($numero_amplitude_dgda[$row->Typerecette_17]) && $numero_amplitude_dgda[$row->Typerecette_17] !="")
                                                        {
                                                                $numero_paiement = $numero_amplitude_dgda[$row->Typerecette_17];
                                                        }
                                                        else
                                                        {
                                                                $numero_paiement = $row->Id_0;
                                                        }
                                                }
                                                else
                                                {
                                                        $numero_paiement = $row->Id_0;
                                                }
                                        }

                                        if($row->Designation_14 !="") $designation = $row->Designation_14;
                                        else $designation = $row->Nif_13;

                                        if($row->Sydonia_44 !="" || $row->Sydonia_49 !="")
                                        {
                                                if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                {
                                                        $numquittance = $Infos['quittanceid'];
                                                }
                                                else
                                                {
                                                        $numquittance = "";
                                                }
                                        }

                                        #Periode quand il s'agit de paiement DGI et DGRAD d'un BL
                                        if(($regie =='DGI' || $regie == 'DGRAD') && ($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0'))
                                        {
                                                $date_valeur = explode('-',$row->Datevaleur_31 );

                                                if(count($date_valeur) == 3)
                                                {
                                                        $periode_paiement = $date_valeur[1]."".$date_valeur[0];
                                                }
                                        }
                                        # Montant paye
                                        $montant = ($row->Devise_34 == "USD")?$row->Montant_11:$row->Contrevaleur_22;


                                        if($row->Typerecette_17 =='IPRIER')
                                        {
                                                if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                {
                                                        $montant = $Infos['QuotasDGI'];
                                                }
                                        }

                                        $note_montant = $row->Notemontant_28;

                                        $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));

                                        $cellCoordinateN = 'N';
                                        $worksheet->getStyle($cellCoordinateN)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                                        // Exemple pour définir le format de colonne E en tant que texte
                                        $cellCoordinateE = 'E';
                                        $worksheet->getStyle($cellCoordinateE)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);

                                        $cellCoordinateG = 'G';
                                        $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                        $cellCoordinateG = 'L';
                                        $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                        $cellCoordinateJ = 'J';
                                        $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                        $cellCoordinateJ = 'F';
                                        $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                        $worksheet->setCellValue('A'.$erow, $numero_releve);
                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Nif_13);
                                        $worksheet->setCellValue('D'.$erow, $designation);
                                        if(($regie =='DGI' || $regie == 'DGRAD') && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('E'.$erow, $periode_paiement.' ');
                                        else $worksheet->setCellValue('E'.$erow, $periode_mois.' ');
                                        $worksheet->setCellValue('F'.$erow, $row->Notemontant_28);
                                        //if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_paiement);
										if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_note);
                                        else $worksheet->setCellValue('G'.$erow, $date_note);
                                        $worksheet->setCellValue('H'.$erow, $numquittance);
                                        $worksheet->setCellValue('I'.$erow, $numero_paiement.' ');
                                        $worksheet->setCellValue('J'.$erow, $montant);
                                        $worksheet->setCellValue('K'.$erow, $row->Devise_34);
                                        $worksheet->setCellValue('L'.$erow, $date_paiement);
                                        $worksheet->setCellValue('M'.$erow, $row->Beneficaire_15);
										if($row->Beneficaire_15 == 'DGRAD' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow, ' GU-DGRAD ');
										elseif($row->Beneficaire_15 == 'DGI' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow,' GU-DGI');
                                        else $worksheet->setCellValue('N'.$erow, $row->Service_16);
                                        $worksheet->setCellValue('O'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('P'.$erow, "");
                                        $i++;

                                        if($i != $array_length)
                                        {
                                            $erow++;
                                        }
                                }
                        }

                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_fichier_isys_'.time().'.xlsx';

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');


                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/isys-regies';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;

                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                $paiement_ids = [];
                                $totaux = [];
                                $devise = '';
                                $regie = '';

                                foreach ($reversements as $item) {
                                        $paiement_ids[] = $item->Id_0;
                                        $totaux[] = isset($item->Montant_11) ? (float) $item->Montant_11 : 0;

                                        if ($devise === '' && isset($item->Devise_12)) {
                                            $devise = $item->Devise_12;
                                        }
                                        if ($regie === '' && isset($item->Beneficaire_15)) {
                                            $regie = $item->Beneficaire_15;
                                        }
                                }

                                $_POST['Filepath_24'] = $path;
                                $_POST['paiements'] = $paiement_ids;
                                $_POST['total'] = $totaux;
                                $_POST['devise_paiement'] = $devise;
                                $_POST['regie'] = $regie;

                                $pid = $this->save("reversement_immatriculation");

                                if($pid > 0)
                                {
                                         return $path;
                                }
                                else
                                {
                                    return 'E201';
                                }
                        }
                        else
                        {
                                return 'E401';
                        }
                }
                elseif($obj == "export_passeports")
                {
                        if($id != NULL)
                        {
                                $reversements = $this->integrationModel->get_reversement_info($id);

                                $paiements = json_decode($reversements->Paiementids_23, true);

                                if(isset($paiements['autres']) && $paiements['autres'] !="")
                                {
                                        $_POST['paiements'] = $paiements['autres'];
                                }
                                elseif($paiements['dgda'] && $paiements['dgda'] !="")
                                {
                                        $_POST['bulletins'] = $paiements['dgda'];
                                }
                                elseif($paiements['dgda_prepayments'] && $paiements['dgda_prepayments'] !="")
                                {
                                        $_POST['prepayments'] = $paiements['dgda_prepayments'];
                                }

                                $reversements = $this->reversementModel->get_paiements_passeports_to_reverse();

                        }
                        else
                        {
                                $_POST = $_SESSION['data_submitted'];
                                //unset($_SESSION['data_submitted']);
                                # New paiement to reverse into ISYS-REGIES
                                $reversements = $this->reversementModel->get_paiements_passeports_to_reverse();
                        }


                        $regie = "";
                        $periode_mois = "";
                        $periode_paiement = "";

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[15];

                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('V_REG_NOTE_PERCEPTION');

                        //set cell A1 content with some text

                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = ["Numero Relevé Paiement", "Numero Titre de Perception", "Numero Impot", "Désignation", "Période", "Montant Note", "Date Note", "Numero Quittance", "Numero Paiement", "Montant", "Devise", "Date de Paiement", "Regie", "Code Service Recouvrement", "Code Type Recette Etat", "Message Retour"];
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName)
                        {
                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);

                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        //Data: raws/lignes
                        $erow = 2;
                        $i = 0;

                        $array_length = count($reversements);

                        $province = $this->logirefModel->get_dropdown('code_province');

                        $my_tab = array();
                        $numero_amplitude_dgda = array();

                        foreach($reversements as $row)
                        {
                                if($row->Montant_11 > 0)
                                {
                                        if(($row->Typerecette_17 =='27022470' || $row->Typerecette_17 =='27421600' || $row->Typerecette_17 =='27022450') && $row->Devise_12 =='USD')
                                        {
                                                $code_province = isset($province[$_SESSION['Logiref_province']]) ? $province[$_SESSION['Logiref_province']] : "";
                                                $regie = $row->Beneficaire_15;

                                                # Get the bank name
                                                $bank = str_replace('@', '', $this->data['bank']);
                                                $bank = ucfirst($bank);

                                                $numero_releve = $bank."".$code_province."".$regie."".gmdate('Y')."".gmdate('m')."".gmdate('d');

                                                $Infos = json_decode($row->Notereference_30, true);

                                                if(isset($Infos['standard']) && $Infos['standard'] !="")
                                                {
                                                        $data_1 = explode("/", $Infos['standard']);

                                                        if(isset($data_1[1]) && $data_1[1] !="")
                                                        {
                                                                $periode_Paiement = $data_1[0]."".$data_1[1];
                                                        }
                                                        else
                                                        {
                                                                $periode_Paiement = "";
                                                        }

                                                }

                                                if(isset($Infos['Num_evenement']) && $Infos['Num_evenement'] !="")
                                                {
                                                        $date_num = gmdate('d-m-Y');
                                                        $date_num = str_replace('-', '', $date_num);

                                                        if($row->Sydonia_44 !="0" || $row->Sydonia_49 !="0")
                                                        {
                                                                $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                                $numero_paiement = $Infos['Num_evenement']."/".$row->Id_0."-".$date_num;
                                                        }
                                                        else
                                                        {
                                                                $Infos['Num_evenement']= str_replace(' ','',$Infos['Num_evenement']);
                                                                $numero_paiement = $Infos['Num_evenement'].'-'.$date_num;
                                                        }
                                                }
                                                else
                                                {
                                                        $numero_paiement = $row->Id_0;
                                                }

                                                if(isset($Infos['accountname']) && $Infos['accountname'] !="")
                                                {
                                                        if(isset($Infos['pourcompte']) == "1")
                                                        {
                                                                $designation = $Infos['accountname']." P/C ".$row->Designation_14;

                                                        }
                                                        else
                                                        {
                                                                $designation = $row->Designation_14;	
                                                        }
                                                }
                                                else 
                                                {
                                                        if($row->Designation_14 !="") $designation = $row->Designation_14;
                                                        else $designation = $row->Nif_13;
                                                }

                                                if($row->Sydonia_44 !="" || $row->Sydonia_49 !="") 
                                                {
                                                        if(isset($Infos['quittanceid']) && $Infos['quittanceid'] !="")
                                                        {
                                                                $numquittance = $Infos['quittanceid'];
                                                        }
                                                        else 
                                                        {
                                                                $numquittance = "";
                                                        }
                                                }

                                                if($regie =='DGI' && $row->Sydonia_44 != '0')
                                                {
                                                        $date = explode("-", $row->Notedate_27);

                                                        if(isset($date[1]) && $date[1] != '')
                                                        {
                                                                $periode_Paiement = $date[1]."".$date[0];
                                                        }

                                                        $row->Service_16 = 'GU-DGI';
                                                }
                                                if($regie =='DGRAD' && $row->Sydonia_44 != '0')
                                                {
                                                        $row->Service_16 = 'GU-DGRAD';
                                                }

                                                # Montant paye
                                                $montant = $row->Montant_11;

                                                if($row->Typerecette_17 =='IPRIER')
                                                {
                                                        if(isset($Infos['QuotasDGI']) && $Infos['QuotasDGI'] != "")
                                                        {
                                                                $montant = $Infos['QuotasDGI'];
                                                        }
                                                }
                                                                                        
                                                if($row->Typerecette_17 =='27421600')
                                                {
                                                        if(isset($Infos['QuotasTresor']) && $Infos['QuotasTresor'] != "")
                                                        {
                                                                $montant = $Infos['QuotasTresor'];
                                                        }
                                                        else
                                                        {	
                                                                $montant = 21;
                                                        }
                                                }

                                                $note_montant = $row->Notemontant_28;

                                                if(isset($row->Sydonia_44) && $row->Sydonia_44 != '0')
                                                {
                                                        $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                                }
                                                else
                                                {
                                                        $date_note = strftime('%d/%m/%Y',strtotime($row->Notedate_27));
                                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Datevaleur_31));
                                                }

                                                $cellCoordinateN = 'N';
                                                $worksheet->getStyle($cellCoordinateN)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);
                                                // Exemple pour définir le format de colonne E en tant que texte
                                                $cellCoordinateE = 'E';
                                                $worksheet->getStyle($cellCoordinateE)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_TEXT);

                                                $cellCoordinateG = 'G';
                                                $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                                $cellCoordinateG = 'L';
                                                $worksheet->getStyle($cellCoordinateG)->getNumberFormat()->setFormatCode('dd/mm/yyyy');

                                                $cellCoordinateJ = 'J';
                                                $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                                $cellCoordinateJ = 'F';
                                                $worksheet->getStyle($cellCoordinateJ)->getNumberFormat()->setFormatCode('#,##0.00');

                                                $worksheet->setCellValue('A'.$erow, $numero_releve);
                                                $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                                $worksheet->setCellValue('C'.$erow, $row->Nif_13);
                                                $worksheet->setCellValue('D'.$erow, $designation);
                                                if(($regie =='DGI' || $regie == 'DGRAD') && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('E'.$erow, $periode_paiement.' ');
                                                else $worksheet->setCellValue('E'.$erow, $periode_mois.' ');
                                                $worksheet->setCellValue('F'.$erow, $row->Notemontant_28);
                                                //if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_paiement);
                                                                                        if($row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0') $worksheet->setCellValue('G'.$erow, $date_note);
                                                else $worksheet->setCellValue('G'.$erow, $date_note);
                                                $worksheet->setCellValue('H'.$erow, $numquittance);
                                                $worksheet->setCellValue('I'.$erow, $numero_paiement.' ');
                                                $worksheet->setCellValue('J'.$erow, $montant);
                                                $worksheet->setCellValue('K'.$erow, $row->Devise_34);
                                                $worksheet->setCellValue('L'.$erow, $date_paiement);
                                                $worksheet->setCellValue('M'.$erow, $row->Beneficaire_15);
                                                                                        if($row->Beneficaire_15 == 'DGRAD' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow, ' GU-DGRAD ');
                                                                                        elseif($row->Beneficaire_15 == 'DGI' && $row->Sydonia_44 != '0'  || $row->Sydonia_49 != '0')$worksheet->setCellValue('N'.$erow,' GU-DGI');
                                                else $worksheet->setCellValue('N'.$erow, $row->Service_16);
                                                $worksheet->setCellValue('O'.$erow, $row->Typerecette_17);
                                                $worksheet->setCellValue('P'.$erow, "");
                                                $i++;

                                                if($i != $array_length)
                                                {
                                                        $erow++;
                                                }
                                        }
                                }
                        }

                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_fichier_isys_'.time().'.xlsx';

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');


                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/isys-regies';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;

                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                $paiement_ids = [];
                                $totaux = [];
                                $devise = '';
                                $regie = '';

                                foreach ($reversements as $item) {
                                        $paiement_ids[] = $item->Id_0;
                                        $totaux[] = isset($item->Montant_11) ? (float) $item->Montant_11 : 0;

                                        if ($devise === '' && isset($item->Devise_12)) {
                                            $devise = $item->Devise_12;
                                        }
                                        if ($regie === '' && isset($item->Beneficaire_15)) {
                                            $regie = $item->Beneficaire_15;
                                        }
                                }

                                $_POST['Filepath_24'] = $path;
                                $_POST['paiements'] = $paiement_ids;
                                $_POST['total'] = $totaux;
                                $_POST['devise_paiement'] = $devise;
                                $_POST['regie'] = $regie;

                                $pid = $this->save("reversement_passeport");

                                if($pid > 0)
                                {
                                        readfile($path);
                                        exit;
                                        //  return $path;
                                }
                                else
                                {
                                    return 'E201';
                                }
                        }
                        else
                        {
                                return 'E401';
                        }
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "reversement")
                {
                        if(isset($_POST) && $_POST != "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Makerid_7']=$this->session->userdata['user_id'];

                                if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                                {
                                        $bulletins = $_POST['bulletins'];
                                        $data['Nombrepaiement_22']= count($_POST['bulletins']);
                                        $data['Contrevaleur_16'] = array_sum($_POST['total_dgda']);
                                        $data['Devise_9'] = 'CDF';
                                        $paiement_ids['dgda'] = $_POST['bulletins'];
                                }
                                elseif(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                {
                                        $paiements = $_POST['paiements'];
                                        $data['Nombrepaiement_22']= count($_POST['paiements']);
                                        $data['Contrevaleur_16'] = array_sum($_POST['total']);
                                        $data['Devise_9'] = $_POST['devise_paiement'];
                                        $paiement_ids['autres'] = $_POST['paiements'];
                                }
                                elseif(isset($_POST['prepayments']) && $_POST['prepayments'] !="")
                                {
                                        $prepayments = $_POST['prepayments'];
                                        $total_prepayment = array_sum($_POST['total_prepayments']);
                                        $total_prepayment = str_replace(' ','',$total_prepayment);
                                        $total_prepayment = str_replace(',','.',$total_prepayment);
                                        $paiement_ids['dgda_prepayments'] = $_POST['prepayments'];
                                }
                                $data['Description_6'] = json_encode($_POST['paiements_list']);
                                $data['Paiementids_23'] = json_encode($paiement_ids);
                                $data['Journee_13'] = gmdate('Y-m-d');
                                $data['Beneficiaire_10'] = $_POST['regie'];
                                $data['Filepath_24'] = $_POST['Filepath_24'];

                                $rid = $this->integrationModel->save_integrations_isys($data, NULL); 

                                if($rid > 0)
                                {
                                        if(isset($bulletins) && $bulletins !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                
                                                $this->integrationModel->update_bulletin($data, $bulletins);
                                        }
                                        if(isset($paiements) && $paiements !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;
                                                
                                                $this->reversementModel->update_payment_tresor($data, $paiements);
                                        }
                                        if(isset($prepayments) && $prepayments !="")
                                        {
                                                
                                                $data = array();
                                                $data['Status_2'] = 4;
                                                
                                                $this->prepaymentsModel->update_prepayement($data, $prepayments);
                                        }
                                        
                                        
                                }
                                
                                return $rid;
                                
                        }
                }
                elseif($obj == "reversement_immatriculation")
                {
                        if(isset($_POST) && $_POST != "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Makerid_7']=$this->session->userdata['user_id'];

                                
                                if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                {
                                        $paiements = $_POST['paiements'];
                                        $data['Nombrepaiement_22']= count($_POST['paiements']);
                                        $data['Contrevaleur_16'] = array_sum($_POST['total']);
                                        $data['Devise_9'] = $_POST['devise_paiement'];
                                        $paiement_ids['autres'] = $_POST['paiements'];
                                }

                                $data['Description_6'] = json_encode($_POST['paiements']);
                                $data['Paiementids_23'] = json_encode($paiement_ids);
                                $data['Journee_13'] = gmdate('Y-m-d');
                                $data['Beneficiaire_10'] = $_POST['regie'];
                                $data['Filepath_24'] = $_POST['Filepath_24'];

                                $rid = $this->integrationModel->save_integrations_isys($data, NULL);

                                if($rid > 0)
                                {
                                        if(isset($paiements) && $paiements !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;

                                                $this->reversementModel->update_payment_tresor_immatriculation($data, $paiements);
                                        }
                                }

                                return $rid;

                        }
                }
                elseif($obj == "reversement_passeport")
                {
                        if(isset($_POST) && $_POST != "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Makerid_7']=$this->session->userdata['user_id'];

                                if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                                {
                                        $paiements = $_POST['paiements'];
                                        $data['Nombrepaiement_22']= count($_POST['paiements']);

                                        if (isset($_POST['total']) && is_array($_POST['total'])) {
                                            $data['Contrevaleur_16'] = array_sum($_POST['total']);
                                        } else {
                                            $data['Contrevaleur_16'] = 0;
                                            if (is_array($paiements) && !empty($paiements)) {
                                                $total = 0;
                                                foreach ($paiements as $item) {
                                                    if (is_object($item) && isset($item->Montant_11)) {
                                                        $total += (float) $item->Montant_11;
                                                    } elseif (is_numeric($item)) {
                                                        // fallback when only IDs are provided
                                                        $total += 0;
                                                    }
                                                }
                                                $data['Contrevaleur_16'] = $total;
                                            }
                                        }

                                        if(isset($_POST['devise_paiement']) && $_POST['devise_paiement'] != "") {
                                            $data['Devise_9'] = $_POST['devise_paiement'];
                                        } elseif (is_array($paiements) && !empty($paiements) && is_object($paiements[0]) && isset($paiements[0]->Devise_12)) {
                                            $data['Devise_9'] = $paiements[0]->Devise_12;
                                        } else {
                                            $data['Devise_9'] = 'CDF';
                                        }

                                        $paiement_ids['autres'] = $_POST['paiements'];
                                }

                                $data['Description_6'] = json_encode($_POST['paiements']);
                                $data['Paiementids_23'] = json_encode($paiement_ids);
                                $data['Journee_13'] = gmdate('Y-m-d');
                                $data['Beneficiaire_10'] = isset($_POST['regie']) ? $_POST['regie'] : '';
                                $data['Filepath_24'] = isset($_POST['Filepath_24']) ? $_POST['Filepath_24'] : '';

                                $rid = $this->integrationModel->save_integrations_isys($data, NULL);

                                if($rid > 0)
                                {
                                        if(isset($paiements) && $paiements !="")
                                        {
                                                $data = array();
                                                $data['Status_2'] = 3;

                                                $this->reversementModel->update_payment_tresor_passeport($data, $paiements);
                                        }
                                }

                                return $rid;

                        }
                }
                elseif($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }



        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
