<?php

namespace Modules\Branch\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Branch\Models\CurlModel;
use Modules\Branch\Models\DataModel;
use Modules\Branch\Models\RatesModel;
use Modules\Branch\Models\UsersModel;
use Modules\Admin\Models\accountModel;
use Modules\Branch\Models\OfflineModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\BulletinsModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\PrepaymentsModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Services\Sftp\Controllers\Siop;
use Modules\Branch\Models\EncaissementModel;
use Modules\Services\Cyclone\Controllers\Cyclone;
use Modules\Services\Finacle\Controllers\Finacle;
use Modules\Services\Sydonia\Controllers\Sydonia;
use Modules\Services\Crons\Controllers\Prepayments;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Crdbbank\Controllers\TemenosCrdb;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Amplitude\Solidairebanque\Controllers\AmplitudeSolidaireBanque;


class TaxPrepayments extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Glodi on the 12.10.2023
         * *  **************************************************************************************************************************SECTION 1
         */

        public $menus = array('prepaids', 'prepayments', 'prepaymentlist','integration');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'branch';
        public $folder = 'prepayments';
        public $integrationModel;
        public $logirefModel;
        public $bulletinsModel;
        public $dataModel;
        public $comptabilisationModel;
        public $comptabilisation;
        public $usersModel;
        public $ratesModel;
        public $accountModel;
        public $feesModel;
        public $prepaymentsModel;
        public $stakeholdersModel;
        public $offlineModel;
        public $curlModel;
        public $mainModel;
        public $encaissementModel;
        public $sydonia;
        public $amplitude;
        public $virmul;
        public $bank;
        public $core_banking;
        public $temenos;
        public $temenoscrdb;
        public $prepaymentCrons;
        public $siop;
        public $bank_uppercase;
        public $options;
        public $functionalities;
        public $bsqr;
        public $amplitude_solidairebanque;
        public $fibridge;
        public $flexcube;
        public $finacle_standardbank;
        public $finacle;
        public $cyclone;

        //public $comptabilisationModel;
        //public $comptabilisation;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                 */

                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->bulletinsModel = new BulletinsModel();
                $this->dataModel = new DataModel();
                $this->comptabilisation = new Comptabilisation();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->usersModel = new UsersModel();
                $this->ratesModel = new RatesModel();
                $this->accountModel = new accountModel();
                $this->feesModel = new FeesModel();
                $this->curlModel = new CurlModel();
                $this->mainModel = new MainModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->offlineModel = new OfflineModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->prepaymentCrons = new Prepayments();
                $this->siop = new Siop();
                $this->bsqr = new Bsqr();
                $this->amplitude_solidairebanque = new AmplitudeSolidaireBanque();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->finacle = new Finacle();
                $this->cyclone = new Cyclone();
                $this->temenoscrdb = new TemenosCrdb();

                //$this->comptabilisationModel = new ComptabilisationModel();
                //$this->comptabilisation = new Comptabilisation();

                $this->sydonia = new Sydonia();

                $this->amplitude = new Amplitude();
                //$this->virmul = new Virmul();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxprepayments';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $this->session->userdata["account_id"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);

                $guichet=$this->logirefModel->get_guichet_by_id(isset($_SESSION['Logiref_guichet'])?$_SESSION['Logiref_guichet']:0);

                $this->data['agence_options'] = isset($guichet->Options_13) && $guichet->Options_13 != '' ? json_decode($guichet->Options_13, true) : array();
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;
                $this->data['alerts'] = $this->integrationModel->get_logs_branchless();
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                 */
                if ($_SESSION['Logiref_role'] > 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }

                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank_uppercase = ucfirst($this->bank);
                }
        }

        public function index() 
        {
                $this->data['subview'] = '\Modules\Branch\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
         */

        public function set($needle) 
        {
                if (in_array($needle, $this->menus)) 
                {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
         */

        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL) 
        {
                $this->_checkAuthorization();

                if ($obj == "prepayments") 
                {

                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_treated();

                        echo view('\Modules\Branch\Views\prepayments\prepayments', $this->data);
                } 
                elseif ($obj == "integration") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        
                        $treatment_on_going = $this->prepaymentsModel->get_integrations_sftp_treatment_in_progress();
                        
                        if(!empty($treatment_on_going))
                        {
                                $treatment_on_going = current($treatment_on_going);
                                $offices_data = json_decode($treatment_on_going->Officesdata_10);
                                $files_instructions_data = $this->data("construct_files_instructions_data", $offices_data);
                                
                                $this->data['files_instructions_data'] = $files_instructions_data;
                                $this->data['treatment_on_going'] = $treatment_on_going;
                        }
                        else
                        {
                                $raw_instructions = $this->prepaymentsModel->get_instructions_to_treat_for_sftp_dgda();
                                $this->data['files_instructions_data'] = $this->data("aggregate_instructions_by_office", $raw_instructions);
                                
                                $this->data['treatment_on_going'] = '';
                        }

                        echo view('\Modules\Branch\Views\prepayments\integrations', $this->data);
                }
                elseif ($obj == "new") 
                {
                        echo view('\Modules\Branch\Views\prepayments\__result', $this->data);
                } 
                elseif ($obj == "new2") 
                {
                        echo view('\Modules\Branch\Views\prepayments\__result', $this->data);
                } 
                elseif ($obj == "prepaymentlist") 
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_customers('new');
                        $this->data['processed'] = $this->prepaymentsModel->get_all_prepayments('processed');

                        echo view('\Modules\Branch\Views\prepayments\prepaymentlist', $this->data);
                } 
                elseif ($obj == "prepayment") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence, NULL);
                        
                        $this->data['cguichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayment'] = $prepayment = $this->prepaymentsModel->get_prepayments_treated_by_id($id);
                        //$this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_treated_by_lot($prepayment->Lot_11);
			$this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_unvalidated_by_lot($prepayment->Lot_11);
                        $_SESSION['paiement_result'] = [];

                        echo view('\Modules\Branch\Views\prepayments\_prepayment', $this->data);
                }  
                elseif ($obj == "__prepayment") 
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $total_amount = 0;
                        $total_bulletin = 0;
                        $total_instruction = 0;
                        $prepaymentids = array();
                        $prepayments = array();
                        $instructions_non_integrated = array();

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $lot = sprintf("'%s'", implode("','", $_POST['batch']));

                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_by_lot_to_integrate($lot);

                        $prepayments_list = array();

                        foreach ($this->data['prepayments'] as $row)
                        {
                                $prepayments_list[$row->AccountRef_14][]= $row;
                        }

                        $this->data['prepayments_list'] = $prepayments_list;

                        $this->data['lot_selected'] = $lot_selected = $this->prepaymentsModel->get_prepayments_treatment_by_lot_to_integrate($lot);
                        $prepayments = $this->prepaymentsModel->get_prepayments_by_lot_to_integrate($lot);

                        $this->data['prepayment'] = current($lot_selected);

                        $total_amount = 0;
                        $total_bulletin = 0;

                        foreach ($lot_selected as $row) 
                        {
                                $total_amount = $total_amount + $row->Amout_12;
                                $total_bulletin = $total_bulletin + $row->Declarations_10;
                        }

                        foreach ($prepayments as $row) 
                        {   
                                $prepaymentids[] += $row->Id_0; 
                        }

                        $prepaymentids = sprintf("'%s'", implode("','", $prepaymentids));
                        $instructions_non_integrated = $this->prepaymentsModel->get_prepayments_instructions_to_integrate_by_lot($prepaymentids);

                        $this->data['total_amount'] = $total_amount;
                        $this->data['total_bulletin'] = $total_bulletin;
                        $this->data['total_instruction'] = count($instructions_non_integrated);

                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda([], $comptes);

                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $this->data['compte_guichet_unique'] = $compte_cgu;

                        echo view('\Modules\Branch\Views\prepayments\__prepayment', $this->data);
                }
                elseif ($obj == "result_integration_xml") 
                {
                        $this->data['integration'] = $this->integrationModel->get_integration_sftp_by_id($id);
                        $this->data['batch_reference'] = isset($_POST['lot_id']) ? $_POST['lot_id'] : "";

                        echo view('\Modules\Branch\Views\prepayments\__result_integration_xml', $this->data);
                }
                elseif ($obj == "result") 
                {
                        $this->data['lot_id'] = isset($_POST['lot_id']) ? $_POST['lot_id'] : "";
                        $this->data['action'] = isset($_POST['action']) ? $_POST['action'] : "";
                        $instruction_file_id = isset($_POST['instruction_file_id']) ? $_POST['instruction_file_id'] : '';
                        $this->data['file_lines'] = $this->offlineModel->get_integration_offline_info($instruction_file_id);

                        echo view('\Modules\Branch\Views\prepayments\_result', $this->data);
                } 
                elseif ($obj == "__result") 
                {
                        $this->data['paiementid'] = $_POST['lot'];
                        $this->data['paiement_result'] = $_SESSION['paiement_result'];

                        echo view('\Modules\Branch\Views\prepayments\__result', $this->data);
                } 
                elseif ($obj == "start")
                {
                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_customers('new');
           
                        $this->data['processed'] = $this->prepaymentsModel->get_all_prepayments('processed');

                        echo view('\Modules\Branch\Views\prepayments\_start', $this->data);
                }
                elseif ($obj == "historique") 
                {
                        $day = gmdate('Y-m-d');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $this->data['prepaiement_logs'] = $this->integrationModel->get_prepaiements_log($day);

                        echo view('\Modules\Branch\Views\prepayments\historique', $this->data);
                } 
                elseif ($obj == "extractList") 
                {
                        $user = $this->session->userdata["user_id"];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        $encryption = json_decode($credentials->Password_18);

                        $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                        $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                        $apidata['bank'] = (isset($encryption->codebank)) ? $encryption->codebank : '';
                        $apidata['User'] = $this->session->userdata['user_id'];
                        $apidata['Account'] = $this->session->userdata['account_id'];
                        $apidata['Agence'] = $_SESSION['Logiref_guichet'];

                        $response = $this->prepaymentCrons->prepaymentslist($apidata);

                        $this->data['step'] = 0;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_customers('new');

                        $this->data['processed'] = $this->prepaymentsModel->get_all_prepayments('processed');

                        echo view('\Modules\Branch\Views\prepayments\__start', $this->data);
                } 
                elseif ($obj == "treatment_customer") 
                {
                        $account_reference = $_GET['compte'];
                        $office = $_GET['office'];

                        $cdata['compte'] = $account_reference;

                        if(isset($this->options['DGDA']['prepayment-fee-global-deduction']))
                        {
                                $return = $this->data('get_commission', $cdata, 'prelevement_global');
                                
                        }
                        else if(isset($this->options['DGDA']['prepayment-fee-detailed-deduction']))
                        {
                                $return = $this->data('get_commission', $cdata, 'prelevement_detail');
                                
                        }
                        else
                        {
				$return = $this->data('get_commission', $cdata);
                                
                        }

                        $return = json_decode($return, true);

                        $this->data['tota_to_paid'] = isset($return['total_amount']) ? $return['total_amount']:0;
                        $this->data['commission'] = isset($return['commission'])?$return['commission']:0;
                        $this->data['cdevise'] = isset($return['commission_devise'])?$return['commission_devise']:'';
                        $this->data['frais_bcc'] = isset($return['frais_bcc']) ? $return['frais_bcc']:0;
                        $this->data['fees_amount'] = isset($return['fees_amount'])?$return['fees_amount']:0 ;
                        $this->data['nbr_total'] = isset($return['nbr_total'])?$return['nbr_total']:0;

                        $agence = $_SESSION['Logiref_guichet'];

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $prepayments = $this->prepaymentsModel->get_prepayments_customers('new');
                        $this->data['prepayments'] = $prepayments[$_GET["compte"]];

                        $bl_info = $this->data['object_info'] = $object_info = isset($this->data['prepayments'][$office]) ? $this->data['prepayments'][$office] : "";
                        
                        #Get and set prepaid account
                        $comptes_ps = $this->accountModel->get_prepaid_comptes_array($agence, "'CPS'");
                      
                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence, NULL);

                        if (isset($bl_info->Nif_15) && $bl_info->Nif_15 != "") 
                        {
                                $client = $this->logirefModel->get_clients_by_nif($bl_info->Nif_15);
                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5) && $client->Designation_5!= " ") ? $client->Designation_5 : $bl_info->Nif_15;
                        }

                        $compte_client = (isset($comptes_ps[$account_reference]['CPS']['CDF'])) ? $comptes_ps[$account_reference]['CPS']['CDF'] : '';

                        $this->data['account'] = $compte_client;
                        $this->data['cguichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $this->data['account_reference'] = $account_reference;
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";

                        echo view('\Modules\Branch\Views\prepayments\_step_1_customer', $this->data);
                } 
                elseif ($obj == "treatment_office") 
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence, NULL);

                        #Get and set prepaid account
                        $comptes_ps = $this->accountModel->get_prepaid_comptes_array($agence, "'CPS'");

                        $prepayments = $this->prepaymentsModel->get_prepayments_by_reference($_GET);

                        $bureaux = array();
                        $counts = array();
                        $amounts = array();
                      
                        foreach ($prepayments as $line)
                        {
                                $key = $line->Office_8 . $line->AccountRef_14;

                                if (key_exists($key, $counts)) 
                                {
                                        $counts[$key] += 1;
                                        $amounts[$key] += $line->Amount_18;
                                } 
                                else 
                                {
                                        $counts[$key] = 1;
                                        $amounts[$key] = $line->Amount_18;
                                }

                                $line->total = $counts[$key];
                                $line->amounts = $amounts[$key];
                                $bureaux[$line->Office_8][$line->AccountRef_14] = $line;
                        }

                        $this->data['prepayments'] = $bureaux;
                        $this->data['comptes_ps'] = $comptes_ps;

                        //$compte_client = (isset($comptes_ps[$line->AccountRef_14]['CPS']['CDF'])) ? $comptes_ps[$line->AccountRef_14]['CPS']['CDF'] : '';
                        //$this->data['prepayment_treated'] = $this->prepaymentsModel->check_prepayments_treated_office($_GET);

                        $this->data['office'] = $_GET['office'];
                        $this->data['cguichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['account_reference'] = '';

                        echo view('\Modules\Branch\Views\prepayments\_step_1_office', $this->data);
                } 
                elseif($obj == "treatment_process")
                {  
                        $prepayments= array();
                        $counts = array();
                        $amounts = array();
                        $integration_status = [];
                        $integrations = [];
                        $treated_status= [];
                        $prepayments_treated= [];

                        $account_reference = isset($_GET['compte']) ? $_GET['compte'] : "";
                        $office = isset($_GET['office']) ? $_GET['office']:"";
                        $lot_id = isset($_GET['lotid']) ? $_GET['lotid'] : "";

                        $payments = $this->prepaymentsModel->get_prepayments_treated_by_lot($lot_id);

                        foreach($payments as $line)
                        {
                                $key = $line->AccountRef_14.$line->Office_8;

                                if(key_exists($key, $counts))
                                {
                                        $counts[$key] += 1;
                                        $amounts[$key]+= $line->Amount_18;
                                }
                                else
                                {
                                        $counts[$key] = 1;
                                        $amounts[$key] = $line->Amount_18;
                                }

                                $line->total = $counts[$key];
                                $line->amounts = $amounts[$key];
                                $prepayments[$line->AccountRef_14][$line->Office_8] = $line;
                        }

                        $integrations = $this->comptabilisationModel->get_gu_prepayment_instructions($lot_id);
                        
                        foreach($integrations as $row)
                        {
                                if ($row->Montant_10 > 0) 
                                {
                                        $integration_status[] = $row->Status_2;
                                }
                        }

                        $prepayments_treated = $this->prepaymentsModel->get_prepayments_treated_by_lots_selected($lot_id);

                        if (!empty($prepayments_treated))
                        {
                                foreach($prepayments_treated as $row)
                                {
                                        $treated_status[] = $row->Status_2;
                                }

                                $infos = $prepayments_treated[0]->Additionalinfo_19;
                                
                                if ($infos !="")
                                {
                                        $result = json_decode($infos, true);

                                        $feesbcc = isset($result["feesbcc"]) ? $result["feesbcc"] : 0;
                                        $total_fees = isset($result ["total_fees"]) ? $result ["total_fees"]:0;
                                }

                                $tota_to_paid = $prepayments_treated[0]->Total_14;
                                $comm =  $prepayments_treated[0]->Commission_13;
                                $nbr_total = $prepayments_treated[0]->Declarations_10;
                        }

                        $this->data['prepayments_treated'] = $prepayments_treated;
                        $this->data['integrations'] = $integrations;
                        $this->data['integration_status'] = $integration_status;
                        $this->data['treated_status'] = $treated_status;
                        
                        $this->data['lot_id'] = $lot_id;
                        $this->data['tota_to_paid'] = isset($tota_to_paid) ? $tota_to_paid : 0;
                        $this->data['commission'] =  isset($comm) ? $comm : 0;
                        $this->data['cdevise'] = 'CDF';
                        $this->data['frais_bcc'] = isset($feesbcc) ? $feesbcc : 0;
                        $this->data['fees_amount'] = isset($total_fees) ? $total_fees : 0 ;
                        $this->data['nbr_total'] = isset($nbr_total) ? $nbr_total : 0;

                        $agence = $_SESSION['Logiref_guichet'];

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $prepayments;

                        $this->data['prepayments'] = $prepayments[$_GET["compte"]];

                        $bl_info = $this->data['object_info'] = $object_info = isset($this->data['prepayments'][$office]) ? $this->data['prepayments'][$office] : "";

                        #Get and set prepaid account
                        $comptes_ps = $this->accountModel->get_prepaid_comptes_array($agence, "'CPS'");

                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence, NULL);

                        if (isset($bl_info->Nif_15) && $bl_info->Nif_15 != "") 
                        {
                                $client = $this->logirefModel->get_clients_by_nif($bl_info->Nif_15);
                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : $bl_info->Nif_15;
                        }

                        $compte_client = (isset($comptes_ps[$account_reference]['CPS']['CDF'])) ? $comptes_ps[$account_reference]['CPS']['CDF'] : '';

                        $this->data['account'] = $compte_client;
                        $this->data['cguichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $this->data['account_reference'] = $account_reference;
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";

                        echo view('\Modules\Branch\Views\prepayments\_step_1_process', $this->data);
                }
                elseif ($obj == '_bulletins') 
                {
                        $data = $_GET;

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_by_reference($data);

                        echo view('\Modules\Branch\Views\prepayments\_bulletins', $this->data);
                } 
                elseif ($obj == '_bulletins_by_lot') 
                {
                        $lot = $id;

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_treated_by_lot($lot);

                        echo view('\Modules\Branch\Views\prepayments\_bulletins', $this->data);
                } 
                elseif ($obj == "debit_client") 
                {
                        $data['Sydonia_44'] = $_POST['logirefid'] ?? "";

                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = ($_POST['designation'] != '') ? $_POST['designation'] : 'Pas fourni';
                        $data['Account_3'] = $this->session->userdata['account_id'] ?? "";
                        $data['Logirefid_4'] = $_POST['logirefid'] ?? "";
                        $data['branch_code'] = $_POST['branch_code'] ?? "";
                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'debit_customer_prepayment')) 
                        {
                                $return = $this->{$core_banking}->debit_customer_prepayment($data);
                                
                                echo $return;
                        } 
                        else 
                        {
                   
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif ($obj == "verify_transaction") 
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */

                        $data = array();
                        $return = array();
                        $result = array();

                        $data['Sydonia_44'] = $_POST['logirefid'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = ($_POST['designation'] != '') ? $_POST['designation'] : 'Pas fourni';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = isset($_POST['error_code'])?$_POST['error_code']:"";
                        $data['transaction_id'] = $_POST['transaction_id'];
                        $data['Type'] = 'prepayment';

                        $data['Priority'] = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode check_bulletin_single existe dans la classe
                        if (method_exists($this->{$core_banking}, 'bulletin_prepayment_verification_treatment')) 
                        {
                                $return = $this->{$core_banking}->bulletin_prepayment_verification_treatment($data);
                                echo $return;
                                die;
                        } 
                        else 
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                } 
                elseif ($obj == "reservation") 
                {
                        $prepayment_treated = $this->prepaymentsModel->check_prepayments_treated();
                        // var_dump($prepayment_treated);die;
                        if(!empty($prepayment_treated)) 
                        {
                                if ($_POST['designation'] == "")
                                $_POST['designation'] = $_POST['Nif'];

                                $agence = $_SESSION['Logiref_guichet'];
                                $ref = $this->encaissementModel->generate_unique_reference();

                                //Enrgistrement d'ecriture : débit compte PS et crédit compte guichet unique.
                                // $id = $this->save('batch_reservation', $ref);

                                // Debit compte repaiement et crédit guiche unique
                                // $data['Sydonia_49'] = $id;
                                $data['Sydonia_49'] = $_POST['logirefid'];
                                $data['Beneficaire_15'] = 'DGDA';
                                $data['Designation_14'] = (isset($_POST['account_name']) && $_POST['account_name'] != "") ? str_replace(" V/C CDF", "", $_POST['account_name']) : $_POST['designation'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Type'] = 'prepayment';
                                $data['Priority'] = 0;
                                
                                # Nom du core banking
                                $core_banking = strtolower($this->core_banking);
                                $return = $this->{$core_banking}->reservation_prepayment($data);
                               
                                if ($return['response'] == '200')
                                {
                                        $result['code'] = 'E200';

                                        $result['id'] = $_POST['logirefid'];

                                        $lot_id=$_POST['logirefid'];
                                     
                                        $result['reference'] = $ref;

                                        $traitement_data = array();
                                        $traitement_data['Status_2'] = 1;

                                        
                                        $info['lien_id'] = $return['lien'];
                                        $info['date_lien'] = $return['date'];
                                        
                                        $traitement_data['Reservation_20'] = json_encode($info);

                                        $tid = $this->prepaymentsModel->update_traitement_by_lot($traitement_data, $lot_id);

                                        if ($tid > 0) 
                                        {
                                                echo json_encode($result);
                                        }
                                } 
                                elseif ($return['response'] == '301')
                                {
                                        $result['code'] = 'E301';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '302') 
                                {
                                        $result['code'] = 'E302';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '303') 
                                {
                                        $result['code'] = 'E303';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '304') 
                                {
                                        $result['code'] = 'E304';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                } 
                                elseif ($return['response'] == '305') 
                                {
                                        $result['code'] = 'E305';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                }
                                elseif ($return['response'] == '306') 
                                {
                                        $result['code'] = 'E306';

                                        $result['reference'] = $ref;

                                        $result['id'] = $id;

                                        $result['transaction_id'] = $return['transaction_id'];

                                        echo json_encode($result);
                                }
                        } 
                        else 
                        {
                                $id = $ref = isset($prepayment_treated[0]->Lot_11) ? $prepayment_treated[0]->Lot_11 : "";

                                $result['code'] = 'E500';

                                $result['id'] = $id;

                                $result['reference'] = $ref;

                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "verify") 
                {
                        $data['Sydonia_49'] = $_POST['bulletin_id'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];
                        $data['Type'] = 'prepayment';
                        $data['Priority'] = 0;

                        $response = $this->curl_model->call_prepayement_verify_reservation($data);
                        $return = json_decode($response, true);
                        if ($return['response'] == '200') 
                        {
                                $traitement_data = array();
                                $traitement_data['Status_2'] = 1;
                                $tid = $this->prepaymentsModel->update_traitement_by_lot($traitement_data, $_POST['logirefid']);

                                if ($tid > 0) 
                                {
                                        echo 'E200';
                                }
                        } 
                        elseif ($return['response'] == '304') 
                        {
                                echo 'E304';
                        }
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) 
                        {
                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "verification") 
                {
                        $custom = array('');
                        $amount = $_POST['Amount'];
                        $devise = $_POST['devise'];
                        $account_devise = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                        $service = $_POST['Office'];
                        $agence = $_SESSION['Logiref_guichet'];
                        $mode = $_POST['Mode'];

                        $account_client = isset($_POST['Account']) ? $_POST['Account'] : "";

                        $taux = json_decode($_SESSION['Bank_rates'], true);

                        if ($devise != 'CDF') 
                        {
                                if (isset($_POST['Taux']) && $_POST['Taux'] != "")
                                {
                                        $devise_taux = $_POST['Taux'];
                                } 
                                else 
                                {
                                        $taux = json_decode($_SESSION['Bank_rates'], true);

                                        $devise_taux = $taux['Dollar_4'];
                                }
                        } 
                        else 
                        {
                            $devise_taux = 1;
                        }

                        if (isset($_POST['Nif'])) 
                        {
                                $client = $this->logirefModel->get_clients_by_nif($_POST['Nif']);
                                $this->data['designation'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';
                        }

                        if (!isset($_POST['Commission'])) 
                        {
                                $this->data['commission'] = $amount * 0;
                                $this->data['commission_devise'] = $devise;
                                $this->data['total_amount'] = $amount + $this->data['commission'];
                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        } 
                        else 
                        {
                                $this->data['commission'] = $_POST['Commission'];
                                $this->data['commission_devise'] = $_POST['Devise_commission'];

                                if ($_POST['Devise_commission'] != "CDF") 
                                {
                                        if (isset($_POST['Taux']) && $_POST['Taux'] != "") 
                                        {
                                                $devise_taux = $_POST['Taux'];
                                        } 
                                        else
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                $devise_taux = $taux['Dollar_4'];
                                        }
                                        $commission = $this->data['commission'] * $devise_taux;
                                        $this->data['total_amount'] = $amount + $commission;
                                } 
                                else 
                                {
                                        $this->data['total_amount'] = $amount + $_POST['Commission'];
                                }

                                $this->data['bank_rate_applied'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux['Dollar_4'];
                        }

                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU'", $agence);

                        $this->data['compte_guichet'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : "";

                        if ($mode == '7')
                        {
                                $this->data['referenceOP'] = (isset($_POST['reference'])) ? $_POST['reference'] : "";
                                $this->data['disabled'] = "";
                        } 
                        else 
                        {
                                $this->data['referenceOP'] = "";
                                $this->data['disabled'] = "disabled";
                        }

                        echo view('\Modules\Branch\Views\prepayments\_step_1_details', $this->data);
                } 
                elseif ($obj == "edit") 
                {
                        $bl = $id;
                        $agence = $_SESSION['Logiref_guichet'];
                        $devise = 'CDF';

                        $bulletin = $this->integrationModel->get_prepaiement_sydonia($bl);

                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($bl);

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        $instructions1 = $this->comptabilisation->get_instructions_dgda($data);

                        $info = $encaissement->Notereference_30;

                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                        $agence = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                        # Get the account CGU & CS0
                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholdersModel->get_dropdown("beneficiaires");

                        $taxes = $info['taxesPaid'];

                        foreach ($taxes as $taxe) 
                        {
                                $data['Typerecette_17'] = $taxe->taxeCode;
                                $data['Montant_11'] = $taxe->taxeAmount;
                                $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);

                                $instructions2[] = $instruction;
                        }

                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['bulletin'] = $bulletin;
                        $this->data['comptes'] = $comptes;
                        $this->data['compte_cgu'] = $compte_cgu;
                        #$this->data['mode'] = $this->input->get('mode');
                        #$this->data['cCompte'] = $this->input->get('compte');
                        #$this->data['cDevise'] = $this->input->get('devise');
                        #$this->data['view'] = $arg;
                        $this->data['bulletin'] = $bulletin;
                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        echo view('\Modules\Branch\Views\prepayments\_step_2', $this->data);
                } 
                elseif ($obj == "preview") 
                {
                        $bl = $id;
                       
                        $bulletin = $this->integrationModel->get_prepaiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\prepayments\_step_3', $this->data);
                        // echo view('\Modules\Branch\Views\prepaiements\_start', $this->data);
                } 
                elseif ($obj == "preview_details_tax") 
                {
                        $bl = $id;

                        $bulletin = $this->integrationModel->get_prepaiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;

                        echo view('\Modules\Branch\Views\prepayments\_step_3_details_tax', $this->data);
                }
                elseif ($obj == "_prepayments") 
                {
                        $response = $id;
                        $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_by_lot($response);
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['step'] = 0;

                        echo view('\Modules\Branch\Views\prepayments\_prepayments', $this->data);
                } 
                elseif ($obj == "new") 
                {

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['status'] = $this->prepaymentsModel->prepayments_status;
                        $this->data['color'] = $this->prepaymentsModel->prepayments_status_color;
                        $this->data['prepayments'] = $this->prepaymentsModel->get_all_prepayments("new");

                        echo view('\Modules\Branch\Views\prepayments\_allprepayments', $this->data);
                }
                elseif ($obj == "nvalidated") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['status'] = $this->prepaymentsModel->prepayments_status;
                        $this->data['color'] = $this->prepaymentsModel->prepayments_status_color;
                        $this->data['payments'] = $this->prepaymentsModel->get_traitements('new');

                        echo view('\Modules\Branch\Views\prepayments\_nvalidated', $this->data);
                } 
                elseif ($obj == "validated") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['status'] = $this->prepaymentsModel->prepayments_status;
                        $this->data['color'] = $this->prepaymentsModel->prepayments_status_color;
                        $this->data['payments'] = $this->prepaymentsModel->get_traitements('done');

                        echo view('\Modules\Branch\Views\prepayments\_validated', $this->data);
                } 
                elseif ($obj == "prepaymentsAck") 
                {
                        $id = $_POST['id'];
                        $messagekeys = $_POST['messageskeys'];
                        $message = $_POST['message'];
                        $message = ($message == "OK") ? 'OK' : 'KO';

                        unset($_POST['messageskeys']);
                        unset($_POST['message']);

                        $_POST['messageKey'] = $messagekeys;
                        $_POST['codeTr'] = $message;

                        // Sydonia credantials

                        $user = $this->session->userdata['user_id'];
                        $credentials = $this->usersModel->get_sydoniaccount_by_accountid($user);

                        $response = $this->curl_model->call_dgda_send_ack_prepayments($credentials);
                        if ($response == "E404" || $response == "E401" || $response == "E37" || $response == "E38" || $response == "E39" || $response == "E43" || $response == "E42") 
                        {
                                echo $response;
                                die;
                        } 
                        elseif ($response == "OK")
                        {
                                $status = ($message == 'OK') ? 6 : 0;
                                $update = $this->save("updateprepayment", $id, $status);
                                if ($update > 0) {
                                    echo '41';
                                } else {
                                    echo '401';
                                }
                        }
                } 
                elseif ($obj == 'prepayments_filter') 
                {
                        $item = $id;

                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);

                        if ($item == "office"):
                            $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_office('new');
                            echo view('\Modules\Branch\Views\prepayments\_filter_office', $this->data);
                        elseif ($item == "customer"):
                            $this->data['prepayments'] = $this->prepaymentsModel->get_prepayments_customers('new');
                            echo view('\Modules\Branch\Views\prepayments\_filter_customer', $this->data);
                        else:
                            $this->data['prepayments'] = $this->prepaymentsModel->get_all_prepayments('new');
                            echo view('\Modules\Branch\Views\prepayments\_filter_all', $this->data);
                        endif;
                }
                #Default
                elseif ($obj == "deny") 
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
         */

        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL) 
        {
                $this->_checkAuthorization();

                if ($obj == "comptant") 
                { 
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();
                        $prefix = 1;

                        $end_execution = NULL;
                        $return = "";

                        $Missmatch['Missmatch_32'] = 0;

                        if (isset($_POST["logirefid"]) && $_POST["logirefid"] != ''):
                            $reference = $_POST["logirefid"];
                        endif;

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");

                        $beneficiaires = $this->stakeholdersModel->get_dropdown("beneficiaires");

                        $prepayments = $this->prepaymentsModel->get_prepayments_treated_by_lot($reference);

                        foreach ($prepayments as $row) 
                        {
                                $encaissement = $this->dataModel->sydonia_migrate_prepayment($row->Id_0);

                                $agence_src = $_SESSION['Logiref_guichet'];

                                $object = json_encode($encaissement);
                                $data = json_decode($object, true);

                                $data['Compte_33'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                $data['Devise_34'] = 'CDF';
                                $amount = $data['Montant_11'];

                                $client = $this->logirefModel->get_clients_by_nif($encaissement->Nif_13);

                                $data['Designation_14'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                $data['Commission_23'] = 0;
                                $data['Devise_24'] = "CDF";
                                $commission = 0;
                                $commission_devise = "CDF";
                             
                                # Comptabilisation
                                $instructions = $this->comptabilisation->get_instructions_dgda($data);
                                
                                if (!empty($instructions)) 
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 0;
                                        $end_execution = $this->comptabilisationModel->save_prepayments_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);
                                        unset($instructions);
                                }

                                $agence = $_SESSION['Logiref_guichet'];
                                $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");

                                $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                # Get the account CGU & CS0
                                $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);
                      
                                #SAVE PAYMENT DE CHAQUE TAXE
                                #Comptes CGU & CPT

                                $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                                $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                $info = $encaissement->Notereference_30;

                                $taxesPaid = $info['taxesPaid'];

                                if (is_array($taxesPaid) && count($taxesPaid) > 0) 
                                {
                                        $taxes = $taxesPaid;
                                } 
                                elseif (is_object($taxesPaid) && $taxesPaid != "") 
                                {
                                        $taxes = array();

                                        $taxes[] = $taxesPaid;
                                }

                                if (isset($data['CGU']))  unset($data['CGU']);
                                if (isset($data['Total'])) unset($data['Total']);
                                
                                $pkeys_tresor = array();
                                $pkeys_propre = array();
                                
                                $year = substr($row->DateL_11, -4);
                                
                                $row->Year_5 = $year;
                                
                                foreach ($taxes as $taxe) 
                                {
                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                $pkeys_tresor[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_49'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        } 
                                        else 
                                        {
                                                $pkeys_propre[] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_49'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;
                                        }
                                }
                                
                                if (!empty($pkeys_tresor)) 
                                {
                                        $pkeys_tresor = sprintf("'%s'", implode("','", $pkeys_tresor));
                                        $pkeys_tresor_exist = $this->encaissementModel->check_bulletin_tresor($pkeys_tresor);

                                        if (!empty($pkeys_tresor_exist)) 
                                        {
                                                foreach ($pkeys_tresor_exist as $ligne) 
                                                {
                                                        $pkeys_tresor_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }
                                if (!empty($pkeys_propre)) 
                                {
                                        $pkeys_propre = sprintf("'%s'", implode("','", $pkeys_propre));
                                        $pkeys_propre_exist = $this->encaissementModel->check_bulletin_propres($pkeys_propre);

                                        if (!empty($pkeys_propre_exist)) 
                                        {
                                                foreach ($pkeys_propre_exist as $ligne) 
                                                {
                                                        $pkeys_propre_exist[] = $ligne->Paiementkey_50;
                                                }
                                        }
                                }
                                
                                $data_tresor = array();
                                $data_propre = array();

                                foreach ($taxes as $taxe) 
                                {
                                        $data['Logirefid_4'] = $data['Logirefid_4'] . '-' . $prefix;
                                        $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                        $data['Montant_11'] = $taxe->taxeAmount;
                                        $data['Typerecette_17'] = $taxe->taxeCode;
                                        $data['Commission_23'] = $commission;
                                        $data['Devise_24'] = $commission_devise;
                                        $data['Status_2'] = '1';
                                        $pid = $data['Sydonia_49'] . $data['Typerecette_17'] . $data['Service_16'];
                                        $data['Paiementkey_50'] = $data['Noteid_26'] . "" . $taxe->taxeCode . "" . $data['Sydonia_49'] . "" . $data['Service_16'] . "" . $data['Notedate_27'] . $row->Year_5;

                                        $prefix++;
                                        
                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode]))
                                        {
                                                if(!in_array($data['Paiementkey_50'], $pkeys_tresor_exist))
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        //$pid = $this->encaissementModel->save_payment_tresor($data, NULL);
                                                        $data_tresor[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else if (isset($beneficiaires[$taxe->taxeCode])) 
                                        {
                                                if(!in_array($data['Paiementkey_50'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 0;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        //$pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        } 
                                        else 
                                        {
                                                if(!in_array($data['Paiementkey_50'], $pkeys_propre_exist))
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        //$pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                                        $data_propre[] = $data;
                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        }
                                }
                                
                                $return = false;
                                
                                if (!empty($data_tresor))
                                {
                                        $return = $this->encaissementModel->save_payment_tresor_dgda($data_tresor, NULL);
                                }
                                if (!empty($data_propre))
                                {
                                        $return = $this->encaissementModel->save_payment_propres_dgda($data_propre, NULL);
                                }
                                
                                if ($return) 
                                {
                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                $end_execution = $this->comptabilisationModel->save_prepayments_instructions($row->Id_0, $data, $instructions, $_POST['logirefid'], $priority);

                                                unset($instructions);
                                        }

                                        if ($end_execution) 
                                        {
                                                $bl_data['Status_2'] = '2';
                                                $bl_data['Lot_19'] = $_POST['logirefid'];
                                                $bl_data['Designation_21'] = $data['Designation_14'];
                                                $bl_data['Account_22'] = $compte_cgu;
                                                $bl_data['Taux_23'] = $data['Taux_41'];
                                                $bl_data['Commission_24'] = $data['Commission_23'];
                                                $bl_data['Devise_25'] = $data['Devise_24'];
                                                $bl_data['Amount_26'] = $amount + $data['Commission_23'];
                                                $bl_data['Account_27'] = $data['Compte_33'];
                                                $bl_data['Devise_28'] = $data['Devise_34'];

                                                $bl_data['Agence_30'] = $_SESSION['Logiref_guichet'];
                                                $this->prepaymentsModel->update_prepayement($bl_data, $row->Id_0);
                                        }
                                }
                        }
                        
                        if ($return) 
                        {
                                $data_to_update_treatment['Status_2'] = 2;
                                $batch_reference = $_POST['logirefid'];
                                
                                $result = $this->prepaymentsModel->update_traitement_by_lot($data_to_update_treatment, $batch_reference);

                                echo $result;
                        }
                        else
                        {
                                if (!empty($pkeys_tresor_exist) || !empty($pkeys_propre_exist)) 
                                {
                                        #Payment exist already
                                        echo 'E500';
                                } 
                                else 
                                {
                                        echo 0;
                                }
                        }
                }
                if ($obj == "comptant_office") 
                {
                        # Save payment
                        $data = array();
                        $data_id_paiement = array();
                        $prefix = 1;
                        $pid = '';

                        $end_execution = NULL;

                        $Missmatch['Missmatch_32'] = 0;

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");

                        $beneficiaires = $this->stakeholdersModel->get_dropdown("beneficiaires");
                        die;
                        $data_office = json_decode($_POST['data_office'], true);

                        foreach ($data_office as $aKey => $lines) 
                        {
                                $data_payment['account_reference'] = $aKey;
                                $data_payment['Office'] = $lines["Office"];

                                $prepayments = $this->prepaymentsModel->get_payment_to_save($data_payment);

                                foreach ($prepayments as $row) 
                                {
                                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($row->Id_0);

                                        $agence_src = $_SESSION['Logiref_guichet'];

                                        $object = json_encode($encaissement);
                                        $data = json_decode($object, true);

                                        $data['Compte_33'] = $lines["Compte_client"];
                                        $data['Devise_34'] = 'CDF';
                                        $amount = $data['Montant_11'];

                                        $client = $this->logirefModel->get_clients_by_nif($encaissement->Nif_13);

                                        $data['Designation_14'] = ($client != NULL && isset($client->Designation_5)) ? $client->Designation_5 : '';

                                        $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                        $data['Commission_23'] = 0;
                                        $data['Devise_24'] = "CDF";
                                        $commission = 0;
                                        $commission_devise = "CDF";

                                        # Comptabilisation
                                        $instructions = $this->comptabilisation->get_instructions_dgda($data);

                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                $end_execution = $this->comptabilisationModel->save_prepayments_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);
                                                unset($instructions);
                                        }

                                        $agence = $_SESSION['Logiref_guichet'];
                                        $liste = "'CGU', 'CSO'";

                                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                        # Get the account CGU & CS0
                                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                        #SAVE PAYMENT DE CHAQUE TAXE
                                        #Comptes CGU & CPT

                                        $compte_cpt = isset($type_comptes['CSO']) ? $type_comptes['CSO'] : '00000000000000000000000';
                                        $compte_cgu = isset($type_comptes['CGU']) ? $type_comptes['CGU'] : '00000000000000000000000';

                                        $info = $encaissement->Notereference_30;

                                        $taxes = $info['taxesPaid'];

                                        if (isset($data['CGU']))
                                            unset($data['CGU']);
                                        if (isset($data['Total']))
                                            unset($data['Total']);

                                        foreach ($taxes as $taxe)
                                        {
                                                $data['Logirefid_4'] = $data['Logirefid_4'] . '-' . $prefix;
                                                $data['Contrevaleur_22'] = $taxe->taxeAmount;
                                                $data['Montant_11'] = $taxe->taxeAmount;
                                                $data['Typerecette_17'] = $taxe->taxeCode;
                                                $data['Commission_23'] = $commission;
                                                $data['Devise_24'] = $commission_devise;
                                                $data['Status_2'] = '1';
                                                $pid = $data['Sydonia_49'] . $data['Typerecette_17'] . $data['Service_16'];
                                                $data['Paiementkey_50'] = rand(1, 99) . date('H') . date('i') . date('s') . $pid . date('j') . date('m') . date('y') . $this->session->userdata['user_id'];

                                                $prefix++;

                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD") && isset($beneficiaires[$taxe->taxeCode])) 
                                                {
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $type_rectte = $type_recettes[$taxe->taxeCode];

                                                        $pid = $this->encaissementModel->save_payment_tresor($data, NULL);

                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                } 
                                                else if (isset($beneficiaires[$taxe->taxeCode])) 
                                                {
                                                        $data['Tresor_45'] = '0';

                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->taxeCode];

                                                        $pid = $this->encaissementModel->save_payment_propres($data, NULL);

                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                } else 
                                                {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->taxeCode;

                                                        $pid = $this->encaissementModel->save_payment_propres($data, NULL);

                                                        $instruction = $this->comptabilisation->get_instructions_gu_dgda($data, $comptes);
                                                        $instructions[] = $instruction;
                                                }
                                        }

                                        if (!empty($instructions)) 
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                $end_execution = $this->comptabilisationModel->save_prepayments_instructions($row->Id_0, $data, $instructions, $lines['Logirefid'], $priority);

                                                unset($instructions);
                                        }

                                        if ($end_execution) 
                                        {
                                                $bl_data['Status_2'] = '2';
                                                $bl_data['Lot_19'] = $lines['Logirefid'];
                                                $bl_data['Designation_21'] = $data['Designation_14'];
                                                $bl_data['Account_22'] = $compte_cgu;
                                                $bl_data['Taux_23'] = $data['Taux_41'];
                                                $bl_data['Commission_24'] = $data['Commission_23'];
                                                $bl_data['Devise_25'] = $data['Devise_24'];
                                                $bl_data['Amount_26'] = $amount + $data['Commission_23'];
                                                $bl_data['Account_27'] = $data['Compte_33'];
                                                $bl_data['Devise_28'] = $data['Devise_34'];

                                                $bl_data['Agence_30'] = $_SESSION['Logiref_guichet'];
                                                $this->prepaymentsModel->update_prepayement($bl_data, $row->Id_0);
                                        }
                                }

                                if (!empty($instructions)) 
                                {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;
                                        $end_execution = $this->comptabilisationModel->save_prepayments_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);

                                        unset($instructions);
                                }
                        }

                        echo $pid;
                } 
                elseif ($obj == "validate") 
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */
                        $data = array();
                        $return = array();
                        $retour = array();

                        $data = $_POST;
                        $code = '';

                        if (isset($_POST['Sydonia_49']) && $_POST['Sydonia_49'] != "") 
                        {
								
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [2, 3, 8], true)) 
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Logirefid_4'] =  $_POST['lot'] ?? "";
                                        $data['branch_code'] = $_POST['branch_code'] ?? "";
                                        $data['Type'] = 'prepayment';
                                       
                                        #Invocation of the api transfer
                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);
                                        
                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'virement')) 
                                        {
                                                $return = $this->{$core_banking}->virement($data);

                                                if (is_string($return)) 
                                                {
                                                        $return = json_decode($return, true);
                                                } 
                                        } 
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result);
                                                die;
                                        }
                               
                                        if(isset($return['response']) && $return['response'] =='200')
                                        {
                                                $code = 200;
                                                $message = isset($return['message']) ? $return['message'] : "";
                                                $id = $_POST['Sydonia_49'];
                                                $_SESSION['paiement_result'][$id] = $code;

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_prepayment_tresor_dgda($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_prepayment_propres_dgda($data_to_validate, $id);
                                               
                                                if ($tid) 
                                                {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->prepaymentsModel->update_prepayement($bl_data, $id); 
                                                }
                                        }
                                        elseif (isset($return['response']) && $return['response'] != "") 
                                        {
                                                $id = $_POST['Sydonia_49'];
                                                $code = $return['response'];

                                                $_SESSION['paiement_result'][$id] = $code;

                                                //$message = isset($return['message']) ? $return['message'] : "";

                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->prepaymentsModel->update_prepayement($bl_data, $id);
                                        }
                                }

                                $prepayments = $this->prepaymentsModel->get_prepayments_treated_by_lot($_POST['lot']);
                                $return = $this->data('get_view', $prepayments, $_POST);

                                echo $return;
                        }
                } 
                elseif ($obj == "debit_client") 
                {
                        /*
                         * ------------------------------------------------
                         * Variable initialization
                         * ------------------------------------------------
                         */

                        $data = array();
                        $return = array();
                        $result = array();


                        if (!empty($_POST['lot_id'])) 
                        {
                                foreach ($_POST['lot_id'] as $row) 
                                {
                                        # Get the prepayment uniqueid
                                        $lot_id = $row;

                                        # Data construction
                                        $data['Beneficaire_15'] = 'DGDA';
                                        $data['Designation_14'] = isset($_POST['designation']) ? $_POST['designation'] : '';
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Sydonia_49'] = $lot_id;
                                        $data['Priority'] = 0;

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'debit_customer_prepayment')) 
                                        {
                                                $return = $this->{$core_banking}->debit_customer_prepayment($data);
                                        }
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result);
                                                die;
                                        }

                                        $return = is_array($return) ? $return : json_decode($return,true);

                                        if (isset($return['response']) && $return['response'] == "200") 
                                        {
                                                $result['code'] = '200';
                                                $result['message'] = isset($return['response']) ? $return['response'] : "";
                                        } 
                                        elseif (isset($return['response']) && $return['response'] != '') 
                                        {
                                                $result['code'] = $return['response'];
                                                $result['message'] = isset($return['response']) ? $return['response'] : "";
                                        } 
                                        else 
                                        {
                                                $result['code'] = 'E405';
                                                $result['message'] = '';
                                        }
                                }

                                if (isset($result['code']) && $result['code'] != '')
                                {
                                        echo json_encode($result);
                                } 
                                else 
                                {
                                        $result['code'] = 'E405';
                                        $result['message'] = '';

                                        echo json_encode($result);
                                }
                        } 
                        else 
                        {
                                $result['code'] = 'E405';
                                $result['message'] = '';

                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "updateprepayment") 
                {
                        $status = $arg;
                        $ordData['Status_2'] = $status;
                        $ordData['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $ordData['Changer_6'] = $this->session->userdata['user_id'];
                        $ref = $this->prepaymentsModel->update_prepayement($ordData, $id);
                        return $ref;
                } 
                elseif ($obj == "batch_reservation") 
                {
                        // Enregistrement du traitement.
                        $traitement_data = array();

                        $traitement_data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $traitement_data['Status_2'] = 0;
                        $traitement_data['Account_3'] = $this->session->userdata['account_id'];
                        $traitement_data['Creator_4'] = $this->session->userdata['user_id'];
                        $traitement_data['Office_7'] = $_POST['Office'];
                        $traitement_data['Declarant_8'] = $_POST['Declarant'];
                        $traitement_data['AccountRef_9'] = $_POST['account_reference'];
                        $traitement_data['Declarations_10'] = $_POST['Npaiements'];
                        $traitement_data['Lot_11'] = $id;
                        $traitement_data['Amout_12'] = $_POST['total_amount'];
                        $traitement_data['Commission_13'] = $_POST['Commission'];
                        $traitement_data['Total_14'] = $_POST['total_amount'] + $_POST['Commission'];
                        $traitement_data['Account_15'] = $_POST['Compte_33'];
                        $traitement_data['Agence_16'] = $_SESSION['Logiref_guichet'];

                        $tid = $this->prepaymentsModel->save_traitement($traitement_data, NULL);

                        //Enregristrement des ecritures pour debit du compte prepaiement et credit du compte guichet unique.
                        $data = array();
                        $data['Designation_14'] = (isset($_POST['account_name']) && $_POST['account_name'] != "") ? str_replace(" V/C CDF", "", $_POST['account_name']) : $_POST['designation'];
                        $data['Beneficaire_15'] = 'DGDA';
                        $data['Agence_20'] = $_SESSION['Logiref_agence'];
                        $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                        $data['Mode_19'] = '8';
                        $data['Typerecette_17'] = 'OP' . $id;
                        $data['Service_16'] = isset($_POST['Office']) ? $_POST['Office'] : "";
                        $data['Devise_34'] = 'CDF';
                        $data['Notedate_27'] = gmdate('Y-m-d');
                        //Formatting amount
                        $data['Montant_11'] = str_replace(' ', '', $_POST['tota_to_paid']);
                        $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                        $data['Devise_12'] = 'CDF';
                        $data['Compte_33'] = $_POST['Compte_33'];
                        $logirefid = $data['Noteid_26'] = $id;

                        //Formatting amount
                        $data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                        $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                        $data['Devise_24'] = 'CDF';
                        $data['Nif_13'] = '';

                        $agence_src = $_SESSION['Logiref_guichet'];

                        $instructions = $this->comptabilisation->get_instructions_dgda($data);

                        if (!empty($instructions)) {
                            # priority for integrating the counting in cbs
                            $priority = 0;
                            $pid = $this->comptabilisationModel->save_prepayments_instructions($id, $data, $instructions, $logirefid, $priority);
                        }

                        return $id;
                } 
                elseif ($obj == "batch_customer") 
                {
                        $commission = 0;
                        $frais_bcc = 0;

                        $return = $this->prepaymentsModel->check_bulletin_prepayment_by_customer();
                      
                        if(empty($return)) 
                        {
                                $pid = '';
                                $infos =  [];

                                $agence = $_SESSION['Logiref_guichet'];

                                # reference de la transaction
                                $ref_unique = $this->encaissementModel->generate_unique_reference();

                                // $offices = json_encode($_POST['Office']);
                                $commission = $_POST['Commission'] ?? 0;

                                if (!empty($_POST['Infos']))
                                {
                                        $infos =  $_POST['Infos'];

                                        if (isset($infos['fees']) && $infos['fees']!="")
                                        {
                                                $infos['feesbcc'] = str_replace(' ','',$infos['feesbcc']);
                                                $infos['feesbcc'] = str_replace(',','.',$infos['feesbcc']);

                                                $infos['total_fees'] = str_replace(' ','',$infos['total_fees']);
                                                $infos['total_fees'] = str_replace(',','.',$infos['total_fees']);

                                                $infos['accountc'] = isset($_POST["Customer_current_account"]) ? $_POST["Customer_current_account"] : "";
                                                $infos['currencyc'] = isset($_POST["Devise_account_c"]) ? $_POST["Devise_account_c"] : "";
                                                $infos['accountc_name'] = str_replace(" V/C CDF", "", $infos['accountc_name']);

                                                $frais_bcc = isset($_POST['frais_bcc']) ? $_POST['frais_bcc'] : 0;
                                        }
                                }

                                // Enregistrement du traitement.
                                $traitement_data = array();

                                $traitement_data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $traitement_data['Status_2'] = 1;
                                $traitement_data['Account_3'] = $this->session->userdata['account_id'];
                                $traitement_data['Creator_4'] = $this->session->userdata['user_id'];
                                // $traitement_data['Office_7'] = $offices;
                                $traitement_data['Office_7']=isset($_POST['Office']) ? $_POST['Office'] :'';
                                $traitement_data['Declarant_8'] = $_POST['Declarant'];

                                $traitement_data['AccountRef_9'] = $account_ref = $_POST['account_reference'];

                                $traitement_data['Declarations_10'] = $_POST['Npaiements'];
                                $traitement_data['Lot_11'] = $ref_unique;
                                $traitement_data['Amout_12'] = $_POST['total_amount'];
                                $traitement_data['Commission_13'] = $commission;
                                //$traitement_data['Total_14'] =  $_POST['total_amount'] + $_POST['Commission'];
                                $traitement_data['Total_14'] = $_POST['tota_to_paid'];
                                $traitement_data['Account_15'] = $_POST['Compte_33'];
                                $traitement_data['Agence_16'] = $_SESSION['Logiref_guichet'];
                                $traitement_data['Additionalinfo_19'] = json_encode($infos);

                                $tid = $this->prepaymentsModel->save_traitement($traitement_data, NULL);
                               
                                if($tid) 
                                {
                                        $ids_string = $_POST["Ids"]; 
                                        $ids_array  = explode(',', $ids_string); 

                                        # Update sur base de la reference uique .
                                        $data_prepayment = [];
                                        $data_prepayment['Lot_19'] = $ref_unique;
                                        //$data_prepayment['Treated_31'] = '1';

                                        $prid = $this->prepaymentsModel->update_prepayement_by_ids($data_prepayment, $ids_array);
                                       
                                        if ($prid) 
                                        {
                                                //Enregristrement des ecritures pour debit du compte prepaiement et credit du compte guichet unique.
                                                $data = array();
                                                $data['Designation_14'] = (isset($_POST['account_name']) && $_POST['account_name'] != "") ? str_replace(" V/C CDF", "", $_POST['account_name']) : $_POST['designation'];
                                                $data['Beneficaire_15'] = 'DGDA';
                                                $data['Agence_20'] = $_SESSION['Logiref_agence'];
                                                $data['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                                $data['Mode_19'] = '8';
                                                $data['Typerecette_17'] = 'OP' . $ref_unique;
                                                $data['Service_16'] = isset($_POST['Office']) ? $_POST['Office'] : "";
                                                // $data['Service_16'] = $offices;
                                                $data['Devise_34'] = 'CDF';
                                                $data['Notedate_27'] = gmdate('Y-m-d');
                                                //Formatting amount
                                                $data['Montant_11'] = str_replace(' ', '', $_POST['tota_to_paid']);
                                                $data['Montant_11'] = str_replace(',', '.', $data['Montant_11']);

                                                $data['Devise_12'] = 'CDF';
                                                $data['Compte_33'] = $_POST['Compte_33'];
                                                $logirefid = $data['Noteid_26'] = $ref_unique;

                                                //Formatting amount
                                                //$data['Commission_23'] = str_replace(' ', '', $_POST['Commission']);
                                                $data['Commission_23'] = str_replace(' ', '', $commission);
                                                $data['Commission_23'] = str_replace(',', '.', $data['Commission_23']);

                                                $data['frais_bcc'] = str_replace(' ', '', $frais_bcc);
                                                $data['frais_bcc'] = str_replace(',', '.', $data['frais_bcc']);

                                                $data['Devise_24'] = 'CDF';
                                                $data['Nif_13'] = '';

                                                $agence_src = $_SESSION['Logiref_guichet'];

                                                if(isset($this->options['DGDA']['prepayment-fee-deduction-current-account']))
                                                {
                                                        if(isset($_POST['Customer_current_account']) && $_POST['Customer_current_account'] != '' )
                                                        {
                                                                $instructions1 = $this->comptabilisation->get_first_instructions_gu_dgda($data);

                                                                $data['Compte_33'] = $_POST['Customer_current_account'];
                                                                
                                                                $instructions2 = $this->comptabilisation->get_fees_instructions_prepayment_customer($data);

                                                                $instructions = array_merge($instructions1, $instructions2);
                                                        }
                                                        else
                                                        {
                                                                $instructions = $this->comptabilisation->get_instructions_dgda($data);
                                                        }
                                                }
                                                else
                                                {
                                                        $instructions = $this->comptabilisation->get_instructions_dgda($data);
                                                }
                                                if (!empty($instructions)) 
                                                {
                                                        # priority for integrating the counting in cbs
                                                        $priority = 0;
                                                        $pid = $this->comptabilisationModel->save_prepayments_instructions($ref_unique, $data, $instructions, $logirefid, $priority);
                                                }
                                            
                                                if ($pid) 
                                                {
                                                        $result['code'] = 'E200';
                                                        $result['id'] = $ref_unique;
                                                        $result['reference'] = $ref_unique;
                                                }
                                        } 
                                        else 
                                        {
                                                $result['code'] = 'E401';
                                                $result['id'] = $ref_unique;
                                                $result['reference'] = $ref_unique;
                                        }
                                } 
                                else 
                                {
                                        $result['code'] = 'E401';
                                        $result['id'] = $ref_unique;
                                        $result['reference'] = $ref_unique;
                                }

                                echo json_encode($result);
                        } 
                        else 
                        {
                                $return = current($return);
                                $result['code'] = 'E500';
                                $result['id'] = $return->Lot_11;
                                $result['reference'] = $return->Lot_11;

                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "batch_office") 
                {
                        $commission = 0;
                        $frais_bcc = 0;
                        $infos =  [];
                        
                        $prepayments = json_decode($_POST['Prepayments'], true);

                        $return = $this->prepaymentsModel->check_bulletin_prepayment_by_office();

                        $data_treatment = [];
                        $data_instruction = [];
                        $data_refunique = [];
                        $data_office = [];

                        $pid = "";

                        $prepayments = json_decode($_POST['Prepayments'], true);

                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes_ps = $this->accountModel->get_prepaid_comptes_array($agence, "'CPS'");

                        foreach ($prepayments as $office => $payments) 
                        {
                                $i = 1;

                                foreach ($payments as $payment) 
                                {
                                        $odata['compte'] = $payment['AccountRef_14'];
                                        $account_ref = $payment['AccountRef_14'];

                                        if(isset($this->options['DGDA']['prepayment-fee-global-deduction']))
                                        {
                                                $return = $this->data('get_commission', $odata, 'prelevement_global');
                                        }
                                        else if(isset($this->options['DGDA']['prepayment-fee-detailed-deduction']))
                                        {
                                                $return = $this->data('get_commission', $odata, 'prelevement_detail');
                                        }
                                        else
                                        {
                                                //$return = '{}'; // une chaîne JSON vide
												$return = $this->data('get_commission', $odata);
                                        }

                                        $return = json_decode($return, true);

                                        $infos =  !empty($_POST['Infos']) ? $_POST['Infos']:[];

                                         if(isset($this->options['DGDA']['prepayment-fee-deduction-current-account']))
                                         {
                                                if (isset($infos['fees']) && $infos['fees']!="")
                                                {
                                                        $tota_to_paid = isset($return['total_amount']) ? $return['total_amount'] : 0;
                                                        $commission = isset($return['commission']) ? $return['commission']:0;
                                                        $cdevise = isset($return['commission_devise']) ? $return['commission_devise'] : '';
                                                        $frais_bcc = isset($return['frais_bcc']) ? $return['frais_bcc']:0;
                                                        $fees_amount = isset($return['fees_amount'])?$return['fees_amount']:0 ;

                                                        $infos['feesbcc'] = str_replace(' ','',$frais_bcc);
                                                        $infos['feesbcc'] = str_replace(',','.',$infos['feesbcc']);

                                                        $infos['total_fees'] = str_replace(' ','',$fees_amount);
                                                        $infos['total_fees'] = str_replace(',','.',$infos['total_fees']);

                                                        $infos['fees'] = "1";
                                                        $infos['customercode'] = isset($_POST['customerNumber'][$account_ref]) ? $_POST['customerNumber'][$account_ref] : '';
                                                        $infos['accountc'] = isset($_POST["Customer_current_account"][$account_ref]) ? $_POST["Customer_current_account"][$account_ref] : "";
                                                        $infos['currencyc'] = isset($_POST["Devise_account_c"][$account_ref]) ? $_POST["Devise_account_c"][$account_ref] : "";
                                                        $infos['accountc_name'] = str_replace(" V/C CDF", "", $_POST['accountc_name'][$account_ref]);
                                                }
                                        }
                                        else
                                        {

                                        }

                                        if (isset($tota_to_paid) && $tota_to_paid > 0):
                                                $tota_to_paid = $return['total_amount'];
                                        else:
                                                $tota_to_paid = $payment['amounts'] + $commission;
                                        endif;

                                        # Obtient le timestamp avec des microsecondes
                                        $timestamp = microtime(true);

                                        # Convertit le timestamp en une chaîne sans caractères non numériques
                                        $timestamp = str_replace('.', '', (string) $timestamp);

                                        # Prend les 7 premiers chiffres du timestamp pour limiter la longueur
                                        $timestamp_part = substr($timestamp, 0, 7);

                                        $random_number = mt_rand(1, 99) . date('HisdmY') . mt_rand(1, 99);

                                        # Crée la référence unique
                                        $ref_unique = $agence . $random_number . $timestamp_part;

                                        # Limite la longueur de la référence entre 10 et 15 caractères
                                        if (strlen($ref_unique) > 16):
                                                $ref_unique = substr($ref_unique, 0, 16);
                                        endif;

                                        # reference de la transaction
                                        //$ref_unique = $this->encaissementModel->generate_unique_reference();
                                        # Créez une référence unique en utilisant des éléments aléatoires, temporels, et l'identifiant d'agence
                                        $ref_unique = $ref_unique . $i;

                                        $compte_client = (isset($comptes_ps[$payment['AccountRef_14']]['CPS']['CDF'])) ? $comptes_ps[$payment['AccountRef_14']]['CPS']['CDF'] : '';

                                        $data_treatment['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_treatment['Status_2'] = 1;
                                        $data_treatment['Account_3'] = $this->session->userdata['account_id'];
                                        $data_treatment['Creator_4'] = $this->session->userdata['user_id'];
                                        $data_treatment['Office_7'] = json_encode($office);
                                        $data_treatment['Declarant_8'] = $payment['Declarant_16'];
                                        $data_treatment['AccountRef_9'] = $account_ref = $payment['AccountRef_14'];
                                        $data_treatment['Declarations_10'] = $payment['total'];
                                        $data_treatment['Lot_11'] = $ref_unique;
                                        $data_treatment['Amout_12'] = $payment['amounts'];
                                        $data_treatment['Commission_13'] = $commission;
                                        //$data_treatment['Total_14'] =  $payment['amounts'] + $payment['Commission_24'];
                                        $data_treatment['Total_14'] = $tota_to_paid;
                                        $data_treatment['Account_15'] = $compte_client;
                                        $data_treatment['Agence_16'] = $_SESSION['Logiref_guichet'];
                                        $data_treatment['Additionalinfo_19'] = json_encode($infos);

                                        $tid = $this->prepaymentsModel->save_traitement($data_treatment, NULL);
                        
                                        if ($tid) 
                                        {
                                                $data_prepayment['Lot_19'] = $ref_unique;
                                                //$data_prepayment['Treated_31'] = '1';

                                                $prid = $this->prepaymentsModel->update_prepayement_by_reference($data_prepayment, $account_ref);

                                                if ($prid) 
                                                {
                                                        # Enregristrement des ecritures pour debit du compte prepaiement et credit du compte guichet unique.
                                                        $data_instruction['Designation_14'] = $account_ref;
                                                        $data_instruction['Beneficaire_15'] = 'DGDA';
                                                        $data_instruction['Agence_20'] = $_SESSION['Logiref_agence'];
                                                        $data_instruction['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                                        $data_instruction['Mode_19'] = '8';
                                                        $data_instruction['Typerecette_17'] = 'OP' . $ref_unique;
                                                        $data_instruction['Service_16'] = $office;
                                                        $data_instruction['Devise_34'] = 'CDF';
                                                        $data_instruction['Notedate_27'] = gmdate('Y-m-d');

                                                        #Formatting amount
                                                        //$data_instruction['Montant_11'] = str_replace(' ', '', $_POST['tota_to_paid']);
                                                        $data_instruction['Montant_11'] = str_replace(' ', '', $payment['amounts']);
                                                        $data_instruction['Montant_11'] = str_replace(',', '.', $data_instruction['Montant_11']);

                                                        $data_instruction['Devise_12'] = 'CDF';
                                                        $data_instruction['Compte_33'] = $compte_client;
                                                        $logirefid = $data_instruction['Noteid_26'] = $ref_unique;

                                                        #Formatting amount
                                                        $data_instruction['Commission_23'] = str_replace(' ', '', $commission);
                                                        $data_instruction['Commission_23'] = str_replace(',', '.', $data_instruction['Commission_23']);

                                                        $data_instruction['frais_bcc'] = str_replace(' ', '', $frais_bcc);
                                                        $data_instruction['frais_bcc'] = str_replace(',', '.', $data_instruction['frais_bcc']);

                                                        $data_instruction['Devise_24'] = 'CDF';
                                                        $data_instruction['Nif_13'] = '';

                                                        $agence_src = $_SESSION['Logiref_guichet'];
                                                        $customer_current_account = $_POST['Customer_current_account'][$account_ref];

                                                        if(isset($this->options['DGDA']['prepayment-fee-deduction-current-account']))
                                                        {
                                                                if (isset($_POST['Customer_current_account'][$account_ref]) && $_POST['Customer_current_account'][$account_ref]!="")
                                                                {
                                                                        $instructions1 = $this->comptabilisation->get_first_instructions_gu_dgda($data_instruction);

                                                                        $data_instruction['Compte_33'] = $_POST['Customer_current_account'][$account_ref];

                                                                        $instructions2 = $this->comptabilisation->get_fees_instructions_prepayment_customer($data_instruction);

                                                                        $instructions = array_merge($instructions1, $instructions2);
                                                                }
                                                                else
                                                                {
                                                                        $instructions = $this->comptabilisation->get_instructions_dgda($data_instruction);
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $instructions = $this->comptabilisation->get_instructions_dgda($data_instruction);
                                                        }

                                                        if (!empty($instructions)) 
                                                        {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 0;

                                                                $pid = $this->comptabilisationModel->save_prepayments_instructions($ref_unique, $data_instruction, $instructions, $logirefid, $priority);
                                                        }
                                                }
                                        }

                                        $data_office[$account_ref]['Logirefid'] = $logirefid;
                                        $data_office[$account_ref]['Compte_client'] = $compte_client;
                                        $data_office[$account_ref]['Office'] = $office;

                                        $i++;
                                }
                        }

                        if ($pid) 
                        {

                                $result['code'] = 'E200';
                                $result['office'] = $data_office;

                                echo json_encode($result);
                        } 
                        else 
                        {
                                $result['code'] = 'E401';
                                //$result['id'] = $ref;
                                //$result['reference'] = $ref;

                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "instructions") 
                {
                        if (!empty($_POST)) 
                        {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];

                                $lots = implode(',', $_POST['lot_id']);

                                $response = $this->prepaymentsModel->get_declarations_by_ref($lots);

                                $bulletins = implode(',', $response['bulletins']);

                                // Nombre des bulletins
                                $all_paiements = count($response['bulletins']);

                                $prepayments_instruction = $this->prepaymentsModel->get_prepayments_instructions_by_ref($lots);

                                // Total des instructions de tous les bulletins
                                $total_instructions_prepayments = count($prepayments_instruction);

                                // Montant total des tous les bulletins
                                $total_amount = array_sum($response['amounts']);

                                if (!empty($prepayments_instruction)) 
                                {
                                        $data['Instructions_7'] = json_encode($prepayments_instruction);
                                        $data['Paiements_10'] = $all_paiements;
                                        $data['Instructions_11'] = $total_instructions_prepayments;
                                        $data['Agence_14'] = $_SESSION['Logiref_guichet'];
                                        $data['Montant_12'] = $total_amount;
                                        $data['Regie_13'] = 'DGDA';
                                        $data['Devise_16'] = 'CDF';

                                        $paiements = array();
                                        $paiements['bls'] = array();
                                        $paiements['prepayments'] = $bulletins;
                                        $paiements['DGI'] = array();
                                        $paiements['DGRAD'] = array();

                                        $data['Paiements_17'] = json_encode($paiements);

                                        $pid = $this->offlineModel->save_integrations($data, $id);

                                        if ($pid > 0) 
                                        {
                                                echo $pid;
                                                $_SESSION['paiementid'] = $pid;
                                                $_SESSION['datas'] = $_POST;
                                        } 
                                        else 
                                        {
                                                echo '202';
                                        }
                                } 
                                else 
                                {
                                        echo '400';
                                        die;
                                }
                        } 
                        else 
                        {
                                echo '501';
                                die;
                        }
                } 
                elseif ($obj == "updatepath")
                {
                        if ($id != "") 
                        {
                                $data['Pathexcel_8'] = $arg;
                                $pid = $this->offlineModel->save_integrations($data, $id);

                                if ($pid > 0) 
                                {
                                        //Prepayments Update  
                                        $data = array();
                                        $data['Status_2'] = 7;
                                        $ids = $_POST['lot_id'];

                                        $this->prepaymentsModel->update_prepayement_by_lot($data, $ids);

                                        return $pid;
                                } 
                                else 
                                {
                                        return '404';
                                }
                        } 
                        else 
                        {
                                echo '501';
                                die;
                        }
                } 
                else if ($obj == "initraitement")
                {

                }
                elseif($obj == "integration_sftp")
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $integration = array();
                        $prepaymentids = array();

                        if(isset($_POST['lot_id']))
                        {                   
                                $lot = sprintf("'%s'", implode("','", $_POST['lot_id']));

                                $prepayments = $this->prepaymentsModel->get_prepayments_by_lot_to_integrate($lot);
                                $prepayment = current($prepayments); 

                                $_POST['nombre_total'] = count($prepayments);
                                $_POST['nif'] = isset($prepayment->Nif_15) ? $prepayment->Nif_15 : '';
                                $_POST['office'] = isset($prepayment->Office_8) ? $prepayment->Office_8 : '';
                                $_POST['serial'] = isset($prepayment->Serial_9) ? $prepayment->Serial_9 : '';
                                $_POST['number'] = isset($prepayment->Number_10) ? $prepayment->Number_10 : '';

                                $integration = $this->integrationModel->check_integration_sftp();

                                if(isset($integration[0]->Id_0))
                                {
                                        echo $integration[0]->Id_0;
                                }
                                else
                                {
                                        foreach ($prepayments as $row) 
                                        {   
                                                $prepaymentids[] += $row->Id_0; 
                                        }

                                        $data = array();

                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        $data['Office_7'] = isset($prepayment->Office_8) ? $prepayment->Office_8 : '';
                                        $data['Amount_8'] = $_POST['total_amount'];
                                        $data['Commission_9'] = $_POST['commission'];
                                        $data['Account_10'] = $_POST['cGuichet'];
                                        $data['Agence_13'] = $_SESSION['Logiref_guichet'];
                                        $data['Paymentid_11'] = json_encode($prepaymentids);
                                        $data['Nbtotal_14'] = count($prepayments);
                                        $data['Date_15'] = gmdate('Y-m-d');
                                        $data['Nif_16'] = isset($prepayment->Nif_15) ? $prepayment->Nif_15 : '';
                                        $data['Serial_17'] = isset($prepayment->Serial_9) ? $prepayment->Serial_9 : '';
                                        $data['Number_18'] = isset($prepayment->Number_10) ? $prepayment->Number_10 : '';
                                        $data['Type_19'] = 'Prepayment';

                                        $id = $this->integrationModel->save_integration_sftp($data, NULL);

                                        if($id > 0)
                                        {
                                                echo $id;
                                        }
                                        else
                                        {
                                                return false;
                                        }
                                }
                        }
                        else
                        {
                                echo 'E404';
                        }
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
         */

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                $this->_checkAuthorization();

                if ($obj == "validate_paiments") 
                {
                        $error = '';
                        if ($_POST['account_reference'] == '' || $_POST['account_reference'] == NULL)
                            $error = '<div class="alert alert-danger">Le compte de pr&eacute;paiement ne peut pas &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        return $error;
                } 
                elseif ($obj == "create_file") 
                {
                        $data_to_save = array();
                        $id = $data;
                        $ids = array();
                        $path = '';
                        $request = array();
                        $designations = array();
                        $tax_payer = array();

                        $data = $_SESSION['paiementid'];
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $users = $this->mainModel->get_dropdown('users_array');
                        $user = $this->session->userdata['user_id'];
                        $account_id = $this->session->userdata['account_id'];
                        $operateur = $users[$user];
                        $ref_integration = $this->integrationModel->generate_unique_reference();

                        $name = str_replace(' ', '-', $operateur);
                        $fname = explode('-', $name)[0];

                        $comptes = $this->accountModel->get_comptes_array(NULL, $agence_src, 'DGDA');

                        $compte_cgu = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';
                        $compte_cgu = "0501-09876543-01";
                        $CGU = explode('-', $compte_cgu);

                        $day = str_replace('-', '', gmdate("d-m-Y"));
                        $carct = array('-', '&');
                        $data = str_replace('v', '', $data);

                        $integrations = $this->offlineModel->get_integration_offline_info($data);


                        $code = 1; // 1 digit
                        $refOder = $this->data('ordercode', 5);  // 8 digit aleatoir de A à Z
                        $refOder = str_pad($refOder, 8);  // 8 digit aleatoir de A à Z

                        $datevirment = date('d') . date('m') . substr(date('Y'), -2, 2); // 6 digit
                        $designation = str_pad('LGIREF', 36);  // 36 digit
                        $codebank = '05100'; // 5 digit
                        $codeagence = $CGU[0]; // 5 digit
                        $compte = str_pad($CGU[1], 16); // 11 digit
                        $cle = $CGU[2]; // 2 digit

                        //for XML
                        $prepayments_instructions= json_decode($integrations->Instructions_7);

                        foreach($prepayments_instructions as $row)
                        {
                                $designations[$row->Id_0] = $row->Libelle_12;
                                $tax_payer[$row->Id_0] = '';
                        }

                        $request['paiement_ids'] = $integrations->Paiements_10;
                        $request['total_amount'] = $integrations->Montant_12;
                        $request['debit_account'] = $integrations->Account_3;
                        $request['debit_account_currency'] = 'CDF';
                        $request['designations'] = $designations;
                        $request['tax_payer'] = $tax_payer;
                        $request['type'] = 'prepayment';

                        $return = $this->siop->create_xml_request($request);


                        if($return != 405 && $return != 406)
                        {

                                $xml = $return;
                                $name =str_replace(' ','-', $operateur);
                                $fname = explode('-',$name)[0]; 

                                $filename = 'SIOP_LOGIREF'.date('d').date('m').$fname.substr(explode('-',$name)[1],0,1)."_".$ref_integration;


                                $path = './drive/logiref/'.$account_id.'/'.date('Y-m').'/integration/siop';




                                if (is_dir($path)== false)
                                {
                                        mkdir($path,0777,true);

                                }

                                $f_dir = $path.'/'.$filename.'.xml';

                                // Si le fichier portant ce non existe.
                                if(is_file($f_dir) == true)
                                {
                                        // On recupère ledernier caractère du nom du fichier.
                                        $f = substr($filename,-1);

                                        // Si le dernier caractère est un numerique.
                                        if(is_numeric($f))
                                        {
                                                // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                                $f +=1;
                                                $filename = $filename.$f;

                                        }
                                        else
                                        {
                                                $filename.'1';
                                        }

                                        $path = $path.'/'.$filename.'.xml';

                                }
                                else
                                {
                                        $path = $f_dir;
                                }


                                // Charger le contenu XML dans DOMDocument pour le formater.
                                $dom = new \DOMDocument();
                                $dom->preserveWhiteSpace = false;
                                $dom->formatOutput = true;
                                $dom->loadXML($xml);

                                # Ecrire le contenu XML dans le fichier
                                if ($dom->save($path) !== false) 
                                {
                                        #Update the table integration_sftp to save the file path
                                        // $data_to_save['Path_12'] = $path;
                                        $return = $this->save('updatepath', $data, $path);
                                        // $id = $this->integrationModel->save_integration_sftp($data_to_save, $id);

                                        if($return)
                                        {
                                               echo 200; 
                                        }
                                        else
                                        {
                                               echo 501;
                                        }
                                } 
                                else 
                                {
                                        echo 500;
                                }
                        }
                        else
                        {
                                echo $return;
                        }

                        //        $tdebit = $integrations->Montant_12;
                
                        //        $lines = json_decode($integrations->Instructions_7);
                        //        $filename = 'VIRMUL_LGIREF' . date('d') . date('m') . $fname . substr(explode('-', $name)[1], 0, 1);
                        //        $path = "./drive/logiref/" . $account_id . "/" . date('Y-m') . '/integration';
                
                        //        if (is_dir($path) == false):
                        //            mkdir($path, 0777, true);
                        //        endif;
                
                        //        $path = $path . "/" . mb_strimwidth($filename, 0, 29, '') . '.txt';
                
                        //        $handle = fopen($path, "w");
                
                        //        // Debit guichet unique
                        //        $code = 1; // 1 digit
                        //        $refOder = $this->data('ordercode', 5);  // 8 digit aleatoir de A à Z
                        //        $refOder = str_pad($refOder, 8);  // 8 digit aleatoir de A à Z
                
                        //        $datevirment = date('d') . date('m') . substr(date('Y'), -2, 2); // 6 digit
                        //        $designation = str_pad('LGIREF', 36);  // 36 digit
                        //        $codebank = '05100'; // 5 digit
                        //        $codeagence = $CGU[0]; // 5 digit
                        //        $compte = str_pad($CGU[1], 16); // 11 digit
                        //        $cle = $CGU[2]; // 2 digit
                        //        $nbinstuctions = str_pad(count($lines), 6, 0, STR_PAD_LEFT); // 6 digit partie entier et 2 digit partie decimale
                
                        //        $amouts = explode('.', $tdebit);
                        //        $entier = $amouts[0];
                
                        //        if (isset($amouts[1]) && $amouts[1] > 0):
                        //            $decimal = substr($amouts[1], 0, 2);
                        //        else:
                        //            $decimal = '00';
                        //        endif;
                
                        //        $total_amount = str_pad($entier . $decimal, 20); // 20 digit
                
                        //        $motif = str_pad('PREPAIEMENTS DU ' . str_replace('-', '', date('d-m-Y')), 30); // 30 digit
                        //        $filler = str_pad('', 6); // 7digit
                        //        $devise_code = str_pad('181', 115); // 3 digit
                
                        //        $instructions = $code . $refOder . $datevirment . $designation . $codebank . $codeagence . $compte . $cle . $nbinstuctions . $total_amount . $motif . $filler . $devise_code;
                
                        //        fwrite($handle, $instructions . "\n");
                
                        //        foreach ($lines as $row) {
                        //            if ($row->Montant_10 > 0) {
                        //                ############################# Virmul, preparation des donnees ####################################
                        //                $compte_source = explode('-', $row->Compte_13);
                        //                $agence = isset($compte_source[0]) ? $compte_source[0] : "";
                        //                $compte = isset($compte_source[1]) ? $compte_source[1] : "";
                        //                $cle = isset($compte_source[2]) ? $compte_source[2] : "";
                        //                $montants = explode('.', $row->Montant_10);
                        //                $entier = $montants[0];
                
                        //                if (isset($montants[1]) && $montants[1] > 0) :
                        //                    $decimal = substr($montants[1], 0, 2);
                        //                else:
                        //                    $decimal = '00';
                        //                endif;
                
                        //                $amount = $entier . $decimal;
                        //                $code = 2;
                        //                $refvirement = str_pad($refOder, 12);
                        //                $designation = str_pad('BENEFICIAIRE', 36); // 36 digit
                        //                $Bank = str_pad('RAWBANK', 24); //24 digit
                        //                $codebank = '05100'; // 5 digit
                        //                $codeagence = $agence; //  5 digit
                        //                $account = str_pad($compte, 16);
                        //                $key = str_pad($cle, 2);
                        //                // taille du montant 
                        //                $taxeamount = str_pad($amount, 20, ' ', STR_PAD_LEFT);
                        //                $libelle = str_pad(str_replace(array('/', '&', '-'), ' ', $row->Libelle_12), 30);
                
                        //                $instructions = $code . $refvirement . $designation . $Bank . $codebank . $codeagence . $account . $key . $taxeamount . $libelle;
                
                        //                fwrite($handle, $instructions . "\n");
                        //            }
                        //        }
                
                        //        fclose($handle);
                
                        //        $_POST = isset($_SESSION['datas']) ? $_SESSION['datas'] : "";
                
                        //        $rerturn = $this->save('updatepath', $data, $path);

                        echo $return;
                } 
                elseif($obj == "create_file_xml")
                {   
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $data_to_save = array();
                        $id = $data;
                        $ids = array();
                        $path = '';
                        $request = array();
                        $designations = array();
                        $tax_payer = array();
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $users = $this->mainModel->get_dropdown('users_array');
                        $user = $this->session->userdata['user_id'];
                        $account_id = $this->session->userdata['account_id'];
                        $operateur = $users[$user];
                        $ref_integration = $this->integrationModel->generate_unique_reference();

                        $integration = $this->integrationModel->get_integration_sftp_by_id($id);

                        # Creation of tab containing all designations of each payment
                        $ids = json_decode($integration->Paymentid_11, true);

                        $ids = sprintf("'%s'", implode("','", $ids));

                        $prepayments = $this->prepaymentsModel->get_prepayments_by_id($ids);

                        foreach($prepayments as $row)
                        {
                               $designations[$row->Id_0] = $row->Designation_21;
                               $tax_payer[$row->Id_0] = $row->Nif_15;
                        }

                        $request['paiement_ids'] = $integration->Paymentid_11;
                        $request['total_amount'] = $integration->Amount_8;
                        $request['debit_account'] = $integration->Account_10;
                        $request['debit_account_currency'] = 'CDF';
                        $request['designations'] = $designations;
                        $request['tax_payer'] = $tax_payer;
                        $request['type'] = 'prepayment';

                        $return = $this->siop->create_xml_request($request);

                        if($return != 405 && $return != 406)
                        {
                                $xml = $return;
                                $name =str_replace(' ','-', $operateur);
                                $fname = explode('-',$name)[0]; 

                                $filename = 'SIOP_LOGIREF'.date('d').date('m').$fname.substr(explode('-',$name)[1],0,1)."_".$ref_integration;
                                $path = './drive/logiref/'.$account_id.'/'.date('Y-m').'/integration/siop';

                                if (is_dir($path)== false)
                                {
                                        mkdir($path,0777,true);
                                }

                                $f_dir = $path.'/'.$filename.'.xml';

                                // Si le fichier portant ce non existe.
                                if(is_file($f_dir) == true)
                                {
                                        // On recupère ledernier caractère du nom du fichier.
                                        $f = substr($filename,-1);

                                        // Si le dernier caractère est un numerique.
                                        if(is_numeric($f))
                                        {
                                                // On incremente le denier caractère numérque à 1 pour créer un autre fichier.
                                                $f +=1;
                                                $filename = $filename.$f;

                                        }
                                        else
                                        {
                                                $filename.'1';
                                        }

                                        $path = $path.'/'.$filename.'.xml';

                                }
                                else
                                {
                                        $path = $f_dir;
                                }


                                // Charger le contenu XML dans DOMDocument pour le formater.
                                $dom = new \DOMDocument();
                                $dom->preserveWhiteSpace = false;
                                $dom->formatOutput = true;
                                $dom->loadXML($xml);

                                # Ecrire le contenu XML dans le fichier
                                if ($dom->save($path) !== false) 
                                {
                                        #Update the table integration_sftp to save the file path
                                        $data_to_save['Path_12'] = $path;
                                        $id = $this->integrationModel->save_integration_sftp($data_to_save, $id);

                                        if($id)
                                        {
                                               echo 200; 
                                        }
                                        else
                                        {
                                               echo 501;
                                        }
                                } 
                                else 
                                {
                                        echo 500;
                                }
                        }
                        else
                        {
                                echo $return;
                        }
                }
                elseif ($obj == "send_file") 
                {
                        //$response = $this->curl_model->call_bank_upload_virmul($path);
                        //$response = $this->virmul->virmul_upload($path);

                        $response = '200';

                        if ($response == '200') 
                        {
                                //Batch traitment Update
                                $data = array();
                                $data['Status_2'] = 2;
                                $ids = $_POST['lot_id'];
                                $this->prepaymentsModel->update_traitement_by_lot($data, $ids);
                        }

                        echo $response;
                } 
                elseif ($obj == "send_file_integration") 
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $request = array();
                        $data_to_update_integration = array();
                        $data_to_update_bulletin = array();
                        $data_to_update_treatment = array();
                        $batch_reference = array();
                        $bulletinids = array();
                        $request['path'] = $_POST['path'];
                        $request['integrationid'] = $_POST['integrationid'];
                        $id = $_POST['integrationid'];
                        $bulletinids = array();

                        $return = $this->siop->send_file($request);
                        //$return['code'] = 200;
                        //$return['msg'] = '<div class="alert aSuccess text-white">Bravo, fichier envoy&eacute; avec succ&egrave;s, veuillez cliquer sur télécharger pour visualiser le fichier envoyé.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                        if(isset($return['code']) &&  $return['code'] == 200) 
                        {
                                $data_to_update_integration['Status_2'] = 2;
                                $this->integrationModel->save_integration_sftp($data_to_update_integration, $id);

                                $integration = $this->integrationModel->get_integration_sftp_by_id($id);

                                # Get the list of bl integrated
                                $ids = json_decode($integration->Paymentid_11, true);
                                $ids = implode(',', $ids);

                                $prepayments = $this->prepaymentsModel->get_prepayments_integrated_by_id($ids);

                                if(!empty($prepayments))
                                {
                                        foreach ($prepayments as $row) 
                                        {
                                                $prepaymentids[] = $row->Id_0;
                                        }

                                        $data_to_update_prepayment['Status_2'] = 3;

                                        $this->prepaymentsModel->update_prepayement($data_to_update_prepayment, $prepaymentids);
                                }

                                # Change the status of treatment line in table logiref_prepayments_traitements
                                $data_to_update_treatment['Status_2'] = 3;
                                $batch_reference = $_POST['batch_reference'];
                                $this->prepaymentsModel->update_traitement_by_lot($data_to_update_treatment, $batch_reference);
                        }

                        echo json_encode($return);
                }
                elseif ($obj == "ordercode") 
                {
                        $Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZ';
                        $QuantidadeCaracteres = strlen($Caracteres);
                        $QuantidadeCaracteres--;

                        $Hash = NULL;

                        for ($x = 1; $x <= $data; $x++) 
                        {
                                $Posicao = rand(0, $QuantidadeCaracteres);
                                $Hash .= substr($Caracteres, $Posicao, 1);
                        }

                        return $Hash;
                } 
                elseif ($obj == "get_commission") 
                {
                        $item = $arg;

                        $taux = json_decode($_SESSION['Bank_rates'], true);

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $prepayments = $this->prepaymentsModel->get_prepayments_by_reference($data);

                        if ($item == "prelevement_detail") 
                        {
                                $frais_bcc = 0;
                                $total_commission = 0;
                                $total_amount = 0;

                                #Taxes comptes
                                $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                                $agence = $_SESSION['Logiref_guichet'];

                                $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                if (!empty($prepayments)) 
                                {
                                        foreach ($prepayments as $row) 
                                        {
                                                $encaissement = $this->dataModel->sydonia_migrate_prepayment($row->Id_0);

                                                $info = $encaissement->Notereference_30;

                                                $object = json_encode($encaissement);
                                                $data = json_decode($object, true);

                                                $taxes = $info['taxesPaid'];

                                                foreach ($taxes as $taxe) 
                                                {
                                                        if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                        {
                                                                $taxe_amount = $taxe->taxeAmount * 0.0005;

                                                                $frais_bcc = $taxe_amount + $frais_bcc;
                                                        }

                                                        if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes']))  
                                                        {
                                                                if (isset($taxe->taxeCode)) 
                                                                {
                                                                        $taxe_code = $taxe->taxeCode; 
                                                                        $taxe_amount = $taxe->taxeAmount;

                                                                        $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                                        $frais_bcc += $fees_bcc['Valeur'];
                                                                }
                                                        }

                                                        if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                                                        {
                                                                if (isset($taxe->taxeCode)) 
                                                                {
                                                                        $data['Typerecette_17'] = $taxe->taxeCode;

                                                                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                                        if($type_comptes['CPI'] == '000000000000000000000000')
                                                                        {
                                                                                $frais_bcc += $taxe->taxeAmount * 0.002;
                                                                        }
                                                                } 
                                                        }
                                                }

                                                $amount = isset($row->Amount_18) ? $row->Amount_18 : 0;

                                                $devise = "CDF";
                                                //$service = isset($row->Office_8) ? $row->Office_8 : "";
                                                $service = '';
                                                $agence = $_SESSION['Logiref_guichet'];

                                                $taux = json_decode($_SESSION['Bank_rates'], true);

                                                if ($devise != 'CDF') 
                                                {
                                                        $taux = json_decode($_SESSION['Bank_rates'], true);

                                                        $devise_taux = $taux['Dollar_4'];
                                                } 
                                                else 
                                                {
                                                        $devise_taux = 1;
                                                }

                                                $rules = $this->feesModel->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                                if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                                                {
                                                        $com['com'] = ($amount * $rules['Valeur']) / 100;
                                                        $com['devise'] = $devise;
                                                } 
                                                elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                                                {
                                                        $com['com'] = $rules['Valeur'];
                                                        $com['devise'] = $rules['Unite'];
                                                }

                                                if (!empty($com) && $com['com'] != 0) 
                                                {
                                                        if ($com['devise'] != 'CDF') 
                                                        {
                                                                $commission = $com['com'] * $devise_taux;
                                                                $commission_devise = $com['devise'];

                                                                $total_amount = $amount + $commission;
                                                        } 
                                                        else 
                                                        {
                                                                $commission = $com['com'];
                                                                $commission_devise = $com['devise'];

                                                                $total_amount = $amount + $commission;
                                                        }
                                                }

                                                $total_commission = $com['com'] + $total_commission;
                                                $total_amount = $amount + $total_amount;
                                        }

                                        $return['total_amount'] = $total_commission + $total_amount + $frais_bcc;
                                        $return['commission'] = $total_commission;
                                        $return['commission_devise'] = $com['devise'] = $devise;
                                        $return['frais_bcc'] = $frais_bcc;
                                        $return['fees_amount'] = $total_commission + ($total_commission * 0.16) + $frais_bcc;
                                        $return['nbr_total'] = count($prepayments);
                                } 
                                else 
                                {
                                        $return['commission'] = 0;
                                        $return['commission_devise'] = $devise = "CDF";
                                        $return['total_amount'] = 0;
                                        $return['frais_bcc'] = 0;
                                        $return['fees_amount'] = 0;
                                        $return['nbr_total'] = 0;
                                }

                                return json_encode($return);
                        } 
                        elseif ($item == "prelevement_global") 
                        {
                                if (!empty($prepayments)) 
                                {
                                        $frais_bcc = 0;
                                        $total_commission = 0;
                                        $total_amount = 0;

                                        $global_amount = [];
                                        $service = '';

                                        #Taxes comptes
                                        $liste = ("'CPT', 'CPI', 'CSO', 'CGU' ");
                                        $agence = $_SESSION['Logiref_guichet'];

                                        $comptes = $this->accountModel->get_comptes_dgda($liste, NULL, $agence);

                                        foreach ($prepayments as $row) 
                                        {
                                                $encaissement = $this->dataModel->sydonia_migrate_prepayment($row->Id_0);

                                                $info = $encaissement->Notereference_30;

                                                $object = json_encode($encaissement);
                                                $data = json_decode($object, true);

                                                $taxes = $info['taxesPaid'];

                                                foreach ($taxes as $taxe) 
                                                {
                                                        # Verify in the options tab if the bcc fees is deduced after the validation in sydonia
                                                        if (isset($this->options['DGDA']['bcc-fees-deduction-after-validation'])) 
                                                        {
                                                                if (isset($type_recettes[$taxe->taxeCode]) && ($type_recettes[$taxe->taxeCode] == "TRESOR" || $type_recettes[$taxe->taxeCode] == "RFTRESD")) 
                                                                {
                                                                        $taxe_amount = $taxe->taxeAmount * 0.0005;
                                                                        $frais_bcc = $taxe_amount + $frais_bcc;
                                                                }  
                                                        }

                                                        if (isset($this->options['ALL']['bcc-fees-deduction-on-funds-taxes']))  
                                                        {
                                                                if (isset($taxe->taxeCode)) 
                                                                {
                                                                        $taxe_code = $taxe->taxeCode; 
                                                                        $taxe_amount = $taxe->taxeAmount;

                                                                        $fees_bcc = $this->data("get_feesbcc_tax", $taxe_code, $taxe_amount);

                                                                        $frais_bcc += $fees_bcc['Valeur'];
                                                                }
                                                        }

                                                        if (isset($this->options['ALL']['bcc-fees-deduction-new-taxes'])) 
                                                        {
                                                                if (isset($taxe->taxeCode)) 
                                                                {
                                                                        $data['Typerecette_17'] = $taxe->taxeCode;

                                                                        $type_comptes = $this->comptabilisation->get_comptes_array_gu_dgda($data, $comptes);

                                                                        if($type_comptes['CPI'] == '000000000000000000000000')
                                                                        {
                                                                                $frais_bcc += $taxe->taxeAmount * 0.002;
                                                                        }
                                                                } 
                                                        }
                                                }

                                                $global_amount[] = isset($row->Amount_18) ? $row->Amount_18 : 0;

                                                $service = isset($row->Office_8) ? $row->Office_8 : "";
                                        }

                                        $amount = array_sum($global_amount);

                                        $devise = "CDF";
                                        $agence = $_SESSION['Logiref_guichet'];

                                        $taux = json_decode($_SESSION['Bank_rates'], true);

                                        if ($devise != 'CDF') 
                                        {
                                                $taux = json_decode($_SESSION['Bank_rates'], true);
                                                $devise_taux = $taux['Dollar_4'];
                                        } 
                                        else 
                                        {
                                                $devise_taux = 1;
                                        }

                                        $rules = $this->feesModel->get_bank_charges('DGDA', $service, NULL, $devise, $amount, $agence);

                                        if($this->bank == '@rawbank')
                                        {
                                                $rules['Valeur'] = '';
                                                $rules['Unite'] = '';
                                        }

                                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                                        {
                                                $com['com'] = ($amount * $rules['Valeur']) / 100;
                                                $com['devise'] = $devise;
                                        } 
                                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                                        {
                                                $com['com'] = $rules['Valeur'];
                                                $com['devise'] = $rules['Unite'];
                                        }
                                        else
                                        {

                                                $com['com'] = 0;
                                                $com['devise'] = 0;
                                        }

                                        if (!empty($com) && $com['com'] != 0) 
                                        {
                                                if ($com['devise'] != 'CDF') 
                                                {
                                                        $commission = $com['com'] * $devise_taux;
                                                        $commission_devise = $com['devise'];

                                                        $total_amount = $amount + $commission + $frais_bcc;
                                                } 
                                                else 
                                                {
                                                        $commission = $com['com'];
                                                        $commission_devise = $com['devise'];

                                                        $total_amount = $amount + $commission + ($commission * 0.16) + $frais_bcc;
                                                }
                                        }
                                        else
                                        {
                                                $commission = 0;
                                                $commission_devise = 'CDF';

                                                $total_amount = $amount;
                                        }

                                        $return['total_amount'] = $total_amount;
                                        $return['commission'] = $commission;
                                        $return['commission_devise'] = $com['devise'] = $devise;
                                        $return['frais_bcc'] = $frais_bcc;
                                        $return['fees_amount'] = $commission + ($commission * 0.16) + $frais_bcc;
                                        $return['nbr_total'] = count($prepayments);
                                } 
                                else 
                                {
                                        $return['commission'] = 0;
                                        $return['commission_devise'] = $devise = "CDF";
                                        $return['total_amount'] = 0;
                                        $return['frais_bcc'] = 0;
                                        $return['fees_amount'] = 0;
                                        $return['nbr_total'] = 0;
                                }

                                return json_encode($return);
                        }
                        else
                        {
                                $return['commission'] = 0;
                                $return['commission_devise'] = $devise = "CDF";
                                $return['frais_bcc'] = 0;
                                $return['fees_amount'] = 0;
                                $return['nbr_total'] = count($prepayments);
                                
                                return json_encode($return);
                        }
                } 
                elseif ($obj == "get_view") 
                {
                        $prepayments = $data;
                        $_POST = $arg;
                        $paiementid_next = $_POST['Sydonia_49_next'];
                        $index = (int) $_POST['index'];
                        $iteration = $_POST['iteration'];

                        $paiementid = $_POST['paimentid'];
                        $last_value = end($paiementid);

                        $paiement_treated = $_POST['paiement_treated'];

                        if ($index % 10 == 0) 
                        {
                                if (isset($paiement_treated[$iteration])) 
                                {
                                        $data_to_update = array();
                                        $data_to_update['Treated_31'] = 2;
                                        $this->prepaymentsModel->update_prepayement($data_to_update, $paiement_treated[$iteration]);
                                }
                        }

                        ob_start();
                        ?>
                        <table id="dataTable" class="table table-hover table-striped">
                            <thead>
                                <tr class="bg-gray">
                                    <th></th>
                                    <th width="50">Date</th>
                                    <th>D&eacute;signation</th>
                                    <th>B&eacute;n&eacute;ficiaire</th>
                                    <th>Recette</th>
                                    <th>Montant</th>
                                    <th class="text-center">Message</th>
                                    <th class="text-center">Statut</th>
                                    <th width="30" class="text-center">action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($prepayments as $row) 
                                {
                                        if ($row->Treated_31 == 0) 
                                        {
                                                ?>
                                                        <tr>
                                                                <td width="5"><b>#</b></td>
                                                                <td width="80">
                                                                        <?php echo strftime('%d-%m-%Y', strtotime($row->Date_1)); ?>
                                                                </td>
                                                                <td class="text-blue">
                                                                        <?php
                                                                                if (isset($row->Designation_21) && $row->Designation_21 != "")
                                                                                        echo $row->Designation_21;
                                                                                else
                                                                                        echo "Bulletin de liquidation / " . $row->Nif_15;
                                                                        ?>
                                                                </td>
                                                                <input type="hidden" name="designation" value="<?php if (isset($row->Designation_21) && $row->Designation_21 != "") echo $row->Designation_21; else echo $row->Nif_15;?>" >
                                                                <td width="20"><b><?php echo 'DGDA'; ?></b></td>
                                                                <td><?php echo $row->Serial_9 . '-' . $row->Number_10; ?></td>
                                                                <td class="text-blue"><?php echo 'CDF ' . number_format($row->Amount_18, 2, ",", " "); ?></td>

                                                                <?php if (isset($_SESSION['paiement_result'][$row->Id_0]) && $_SESSION['paiement_result'][$row->Id_0] === 200): ?>
                                                                        <td class="text-center"><span class='text-green bold'>Bulletin validé avec succès </span></td>
                                                                <?php elseif(isset($_SESSION['paiement_result'][$row->Id_0]) && $_SESSION['paiement_result'][$row->Id_0] !== 200): ?>
                                                                        <td class="text-center"><span class='text-red bold'>Bulletin validé partiellement </span></td>
                                                                <?php else: ?>
                                                                        <td class="text-center"><span class='text-yellow bold'>Bulletin en attente de validation</span></td>
                                                                <?php endif;?>
                                                                
                                                                <?php if ($row->Id_0 == $paiementid_next): ?>
                                                                        <td class="text-center"><span id="" class=""><img align="middle" height="18px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" /></span></td>
                                                                <?php else:?>
                                                                        <?php if (isset($_SESSION['paiement_result'][$row->Id_0]) && $_SESSION['paiement_result'][$row->Id_0] == 200): ?>
                                                                                <td class="text-center"><span id="" class="fa fa-fw text-green fa-check-circle f20"></span></td>
                                                                        <?php elseif(isset($_SESSION['paiement_result'][$row->Id_0]) && $_SESSION['paiement_result'][$row->Id_0] != 200): ?>
                                                                                <td class="text-center"><span id="" class="fa fa-times-circle text-danger f20"></span></td>
                                                                        <?php else:?>
                                                                                <td class="text-center"><span id="" class="fa fa-fw text-gray fa-question f20"></span></td>
                                                                        <?php endif; ?>
                                                                <?php endif; ?>
                                                                <td class="text-center">
                                                                        <a style="cursor:pointer" onclick="viewPrepayment('<?php echo $row->Id_0; ?>', 'DGDA')" id="item<?php echo $row->Id_0; ?>" data-id-item="<?php echo $row->Id_0; ?>" class="item">
                                                                                <span class="fa fa-fw text-green fa-pencil f14"></span>
                                                                        </a>
                                                                </td>
                                                        </tr>
                                                <?php
                                        }
                                }
                                ?>
                                </tbody>    
                        </table>
                        <script type="text/javascript">
                            $(document).ready(function () 
                            {
                                    table = $('#dataTable').DataTable();
                            });

                        </script>
                        <?php

                        if ($paiementid_next == $last_value) 
                        {
                                $data_to_update = array();
                                $data_to_update['Status_2'] = '3';
                                $batch_reference = $_POST['lot']; 
                                $this->prepaymentsModel->update_traitement_by_lot($data_to_update, $batch_reference);  
                        }

                        $tableHTML = ob_get_clean();
                        return $tableHTML;
                }
                elseif ($obj == "get_feesbcc_tax") 
                {
                        $fees_bcc = 0;

                        $montant  = $arg;
                        $montant1 = str_replace(' ', '', $montant);
                        $montant2 = str_replace(',', '.', $montant1);
                        $taxe_amount = $montant2;

                        $recette = $data;
                        $rules = $this->feesModel->get_charges_by_fees_bcc(NULL, NULL, $recette, NULL, NULL, NULL, 'BCC');

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $fees_bcc = $taxe_amount * $rules['Valeur'];
                        } 

                        $ar = array('Valeur' => $fees_bcc);
                        return $ar;
                        exit;

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
