<?php

namespace Modules\Branch\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\ComptabilisationModel;
use Modules\Branch\Models\ImmatriculationModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\RatesModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Services\Amplitude\Controllers\AmplitudeInv;

class TaxEqualizeInv extends BaseController
{
        public $menus = array('immatriculation');
        public $module = 'branch';
        public $folder = 'equalize';
        public $data = [];
        public $immatriculationModel;
        public $comptabilisationModel;
        public $integrationModel;
        public $ratesModel;
        public $logirefModel;
        public $branchModel;
        public $mainModel;
        public $core_banking;

        public function __construct()
        {
                parent::__construct();

                $this->immatriculationModel = new ImmatriculationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->integrationModel = new IntegrationModel();
                $this->ratesModel = new RatesModel();
                $this->logirefModel = new LogirefModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'taxequalizeinv';
                $this->data['function'] = '';
                $this->data['folder'] = $this->folder;
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['group'] = 'banks';
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->admin_logiref();
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }

        public function set($needle)
        {
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
        }

        public function display($obj = null, $id = null, $arg = null, $param = null)
        {
                if($obj == 'immatriculation')
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", "DGI", null, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['controller'] = 'taxequalizeinv';
                        $this->data['from'] = 'payments_to_regularize';
                        $this->data['view'] = 'view';

                        $immatriculation = $this->immatriculationModel->get_integration_immatriculation($id);

                        if(empty($immatriculation))
                        {
                                echo '<div class="alert aDanger text-white">Seul l’utilisateur ayant initié ce paiement peut accéder à sa régularisation.</div>';
                                return;
                        }

                        $firstInstructionStatus = $this->immatriculationModel->get_first_immatriculation_instruction_status($immatriculation->Id_0);
                        $this->data['validate'] = ((int) $firstInstructionStatus === 2) ? '' : 'disabled';
                        $this->data['encaissement'] = $this->immatriculationModel->immatriculation_migrate_note($immatriculation->Id_0);

                        echo view('\Modules\Branch\Views\equalize\_immatriculation', $this->data);
                }
                elseif($obj == 'get_details_immatriculation')
                {
                        $ref = $id;
                        $immatriculation = $this->immatriculationModel->get_integration_immatriculation_by_logirefid($ref);

                        if($immatriculation->ValidateBySiop_39 == 1):
                                $this->data['lines'] = $this->comptabilisationModel->get_instructions_immatriculation_siop($ref);
                        else:
                                $this->data['lines'] = $this->comptabilisationModel->get_instructions_immatriculation($ref);
                        endif;

                        echo view('\Modules\Branch\Views\equalize\_details_immatriculation', $this->data);
                }
                elseif($obj == 'payments_to_regularize')
                {
                        return redirect()->to(base_url('branch/taximmatriculationonline/set/payments_to_regularize'));
                }
                elseif($obj == 'check_first_instruction_status')
                {
                        $status = $this->immatriculationModel->get_first_immatriculation_instruction_status($id);

                        return $this->response->setJSON([
                                'code' => 200,
                                'status' => $status,
                                'can_save' => ((int) $status === 2)
                        ]);
                }
        }

        public function save($obj = null, $id = null, $arg = null, $param = null)
        {
                if($obj == "regularize_payment_immatriculation")
                {
                        $data = $_POST;
                        $action = $data['action'] ?? "";
                        $regie  = $data ["regie"] ?? "";
                        $transactionId = $data["transactionid"] ?? "";
                        $paiementId = $data["paiementid"] ?? "";
                        $immatriculation = $this->immatriculationModel
                                ->get_integration_immatriculation($paiementId);

                        if(empty($immatriculation)
                                || (int) $immatriculation->User_34 !== (int) $this->session->userdata['user_id'])
                        {
                                echo json_encode([
                                        'response' => 'E403',
                                        'msg' => '<div class="alert aDanger text-white">Seul l’utilisateur ayant initié ce paiement peut le régulariser.</div>'
                                ]);
                                return;
                        }

                        $this->save('regularisation_immatriculation', $transactionId, $action, $regie);

                        $amplitudeInv = new AmplitudeInv();

                        if(method_exists($amplitudeInv, 'regularize_payment'))
                        {
                                echo $amplitudeInv->regularize_payment($data);
                        }
                        else
                        {
                                echo json_encode(['code' => 'E407']);
                                die;
                        }
                }
                elseif($obj == "validateImmatriculation")
                {
                        $firstInstructionStatus = $this->immatriculationModel->get_first_immatriculation_instruction_status($id);

                        if((int) $firstInstructionStatus !== 2)
                        {
                                echo "E002";
                                return;
                        }

                        $pid = $this->immatriculationModel->update_integration_immatriculation_validation($id, 2);
                        $pidTresor = true;
                        $pidPropres = true;

                        if(isset($_POST['Noteid_26']) && $_POST['Noteid_26'] != "")
                        {
                                $pidTresor = $this->immatriculationModel->update_payment_tresor_by_reference($_POST['Noteid_26'], 2);
                                $pidPropres = $this->immatriculationModel->update_payment_propre_by_reference($_POST['Noteid_26'], 2);
                        }

                        $pidJournalisation = $this->immatriculationModel->update_online_immatriculation_journalisation($id);

                        if($pid && $pidTresor && $pidPropres && $pidJournalisation):
                                echo $id;
                        else:
                                echo "E002";
                        endif;
                }
                elseif($obj == "regularisation_immatriculation")
                {
                        $lines = $this->immatriculationModel->get_instructions_immatriculation_by_id($id);

                        if(!empty($lines))
                        {
                                $data['Status_2'] = 1;
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Paiementid_4'] = $lines->Paiementid_4;
                                $data['Agence_6'] = $lines->Agence_6;
                                $data['Guichet_7'] = $lines->Guichet_7;
                                $data['Operation_8'] = $lines->Operation_8;
                                $data['Compte_9'] = $lines->Compte_9;
                                $data['Montant_10'] = $lines->Montant_10;
                                $data['Devise_11'] = $lines->Devise_11;
                                $data['Libelle_12'] = $lines->Libelle_12;
                                $data['Compte_13'] = $lines->Compte_13;
                                $data['Reference_14'] = $lines->Reference_14;
                                $data['Mode_15'] = $lines->Mode_15;
                                $data['Makerid_16'] = $lines->Makerid_16;
                                $data['Checkerid_17'] = $lines->Checkerid_17;
                                $data['Validation_18'] = $lines->Validation_18;
                                $data['Integration_20'] = gmdate('Y-m-d H:i:s');

                                if($arg == 'reverse') $data['Action_21'] = 'Extourne';
                                elseif($arg == 'forcing') $data['Action_21'] = 'Regularisation';
                                elseif($arg == 'verify') $data['Action_21'] = 'Verification';
                                else $data['Action_21'] = '';

                                $this->integrationModel->save_regularisations($data, null);
                        }
                }
                elseif($obj == "verify_batch")
                {
                        echo '200';
                }
        }
}
