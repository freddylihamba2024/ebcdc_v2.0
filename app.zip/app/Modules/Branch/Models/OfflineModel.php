<?php

    namespace Modules\Branch\Models;

    use App\Models\MY_Transaction;
    use stdClass;

    class OfflineModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        
        
	public function __construct()
	{
		parent::__construct();
                
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        public function get_integration_offline_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();

                        $obj->Instructions_7 = '';
                        $obj->Pathexcel_8 = '';
                        $obj->Pathxml_9 = '';
                        $obj->Paiements_10 = '';
                        $obj->Instructions_11	 = '';
                        $obj->Montant_12 = '';
                        $obj->Regie_13 = '';
                        $obj->Agence_14	 = '';
                        $obj->Checker_15 = '';
                        $obj->Devise_16 = '';
                        $obj->Paiements_17 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_cbs_integration_offline', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_bulletins_instructions($ids) 
        {
                $st = "Paiementid_4 IN($ids) AND Status_2 = '1' AND Priority_24 > 0";
                $query = $this->db->table('logiref_cbs_instructions_dgda')
                                ->select('logiref_cbs_instructions_dgda.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_instructions($ids) 
        {
                $st = "Paiementid_4 IN($ids) AND Status_2 = '1' AND Priority_24 > 0";
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                                ->select('logiref_cbs_prepayments_instructions.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        
        public function get_dgi_instructions($ids) 
        {
                $st = " Paiementid_4 IN($ids) AND Status_2 ='1'";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                                ->select('logiref_cbs_instructions_dgi.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        public function get_dgrad_instructions($ids) 
        {
                $st = " Paiementid_4 IN($ids) AND Status_2 = '1'";
                $query = $this->db->table('logiref_cbs_instructions_dgrad')
                                ->select('logiref_cbs_instructions_dgrad.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_integrations($status = NULL)
        {
                $user = $this->session->userdata['user_id'];
                $account = $this->session->userdata['account_id'];
                
                $st = "Creator_4 ='".$user."' AND Account_3='" . $account . "'";
                if($status == "nvalidated" || $status == NULL) $st .= " AND Status_2 = 1";
                if($status == "validated") $st .= " AND Status_2 = 2";
                
                $query = $this->db->table('logiref_cbs_integration_offline')
                        ->select('logiref_cbs_integration_offline.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */
       
        public function save_integrations($data, $id)
        {
                $this->set_table('logiref_cbs_integration_offline', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        
        public function update_integrations($data, $ref) 
        {
                $this->set_table('logiref_cbs_integration_offline', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $ref); 
        }
                
      
}

