<?php
namespace Modules\Branch\Models;

use stdClass;
use App\Models\MY_Transaction;

use Modules\Admin\Models\BranchModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Branch\Models\EncaissementModel;

class DataModel extends MY_Transaction {
        /* Presentation: 
         * Last update
         * By Glodi on the 12.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
	protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';
        public $integrationModel;
        public $logirefModel;
        public $ratesModel;
        public $accountModel;
        public $encaissementModel;
        public $stakeholdersModel;
        public $branchModel;

        public $months = array('',"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov", "Dec");

	public function __construct()
	{
		parent::__construct();
                $this->integrationModel = new IntegrationModel();
                $this->logirefModel = new LogirefModel();
                $this->accountModel = new AccountModel();
                $this->ratesModel = new RatesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->branchModel = new BranchModel();
	}

        protected function normalize_sydonia_result($raw)
        {
                
                if (is_string($raw)) {
                        $decoded = json_decode($raw);
                        if (json_last_error() === JSON_ERROR_NONE) {
                                $raw = $decoded;
                        }
                        return $raw;
                }

                if (is_object($raw)) {
                        if (isset($raw->declarationPaymentResult) && is_object($raw->declarationPaymentResult)) {
                                return $raw->declarationPaymentResult;
                        }

                        if (isset($raw->checkDeclarationPaymentResult) && is_object($raw->checkDeclarationPaymentResult)) {
                                return $raw->checkDeclarationPaymentResult;
                        }

                        return $raw;
                }

                return new stdClass();
        }

        protected function get_sydonia_taxes_paid($bulletin): array
        {
                $taxesPaid = $bulletin->declarationsPaid->taxesPaid ?? [];
    
                if (is_array($taxesPaid)) {
                        return $taxesPaid;
                }

                if (is_object($taxesPaid)) {
                        return [$taxesPaid];
                }

                return [];
        }

        protected function build_sydonia_receipt_id($bulletin): string
        {
                $receiptSerial = is_object($bulletin) ? (string) ($bulletin->receiptSerial ?? '') : '';
                $receiptNumber = is_object($bulletin) ? (string) ($bulletin->receiptNumber ?? '') : '';

                return $receiptSerial . $receiptNumber;
        }

        public function bulletins_extraction($data = NULL)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/sydonia/comptant.batch.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($_POST);
                $response = $this->curl->execute();
                return $response;
        }

        public function confirm_bulltin($bl)
        {
                $_POST['Series'] = $bl->Serie_7;
                $_POST['Number'] = $bl->Number_8;
                $_POST['Agent'] = $bl->Agent_10;
                $_POST['Year'] = $bl->Year_5;
                $_POST['Office'] = $bl->Office_6;
                $_POST['Amount'] = $bl->Amount_12;
                $_POST['Nif'] = $bl->Nif_9;
                $_POST['Bank'] = $bl->Bank_11;
                $_POST['Account'] = $this->session->userdata['account_id'];
                $_POST['User'] =  $this->session->userdata['user_id'];
                $_POST['Paiementid'] = $bl->Id_0;
                $_POST['Logirefid_4'] = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                $_POST['Email'] = '';
                $_POST['Phone'] = '';
                $_POST['Designation'] = $bl->Desigantion;
                $_POST['Datepaiement'] = gmdate('Y-m-d');
                $_POST['Commission'] = '';
                $_POST['Devise'] = 'CDF';
                $url = base_url('api/endpoints/sydonia/comptant.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($_POST);
                $response = $this->curl->execute();
                if($response == 'E003' || $response == 'E22' || $response == 'E002' || $response == 'E34' || $response == 'E13' || $response == 'E404'):
                        return $response;
                else:
                        # appelle de l'api sydinia pour la quittance
                        set_time_limit(250);
                        $url = base_url('api/endpoints/sydonia/quittance.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($_POST);
                        $Qresponse = $this->curl->execute();
                        if($Qresponse == "E41" || $Qresponse == "E003" || $Qresponse == "E001" || $Qresponse == "E11" || $Qresponse == 'E404'):
                            return $Qresponse;
                        else:
                           return $response;
                        endif;
                endif;

        }

        public function get_penalites()
        {
                $usd = $eur = $rand = $pound = 0;
    
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_4'];
                        $eur = $bank['Euro_5'];
                        $rand = $bank['Rand_6'];
                        $pound = $bank['Pound_7'];
                }

                

                $paiements= $this->encaissementModel->get_paiements();
                $guichets= $this->branchModel->get_guichets();
                $agences= $this->branchModel->get_agences();

                $regles_usd= $this->encaissementModel->get_regle_penalites("USD");
                
                $regles_cdf= $this->encaissementModel->get_regle_penalites("CDF");
                

                $pc_dgi = $pc_dgda = $pc_dgrad = $pu_dgi = $pu_dgda = $pu_dgrad = 0;

                $montant_usd =0;
                $montant_cdf =0;

                foreach ($regles_cdf as $obj)
                {
                        if($obj->Unite_10=='%')
                        {
                            if($obj->Beneficiaire_5=='DGI')
                            {
                                    $pc_dgi = $obj->Value_9/100;
                            }
                            elseif($obj->Beneficiaire_5=='DGDA')
                            {
                                    $pc_dgda = $obj->Value_9/100; 
                            }
                            elseif($obj->Beneficiaire_5=='DGRAD')
                            {
                                    $pc_dgrad = $obj->Value_9/100;
                            }
                        }
                        else
                        {

                        }
                }
                foreach ($regles_usd as $obj)
                {
                        if($obj->Beneficiaire_5=='DGI')
                        {
                                $pu_dgi = $obj->Value_9/100;
                        }
                        elseif($obj->Beneficiaire_5=='DGDA')
                        {
                                $pu_dgda = $obj->Value_9/100; 
                        }
                        elseif($obj->Beneficiaire_5=='DGRAD')
                        {
                                $pu_dgrad = $obj->Value_9/100;
                        }
                }
                $datas = array();
                $tab = array();
                $i=0;

                foreach ($paiements as $row)
                {
                        $contrevaleur = $penalites_cdf = 0;
                        $dateString = '2023-10-19 12:30:12';
                        $timestamp = strtotime($dateString);
                        $timestamp += 86400; // Ajoute 1 jour (86400 secondes)
                        $deadline = date('Y-m-d', $timestamp);

                        if($row->Status_2=='1' && $deadline < gmdate('Y-m-d') || $row->Status_2=='3' && $deadline < $row->Reversement_38)
                        {
                                $datas = array(
                                            'Beneficaire_15' => $row->Beneficaire_15,
                                            'Service_16' => $row->Service_16,
                                            'Devise_12' => $row->Devise_12,
                                            'Montant_11' => $row->Montant_11,
                                            'Guichet_21' => $row->Guichet_21
                                        );

                                $rules = $this->get_regles($datas);
                                
                                if($row->Devise_12=='USD')
                                {       
                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                            $contrevaleur = ($row->Montant_11 * $usd * $rules['Valeur'])/100;
                                        }
                                        elseif($rules['Valeur'] !=0 && $rules['Unite'] !='')
                                        {
                                            $contrevaleur = $rules['Valeur'];
                                        }

                                        $montant_usd = $row->Montant_11 + $montant_usd;
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        if($rules['Valeur'] !=0 && $rules['Unite'] =='%')
                                        {
                                            
                                            $penalites_cdf = ($row->Montant_11 * $rules['Valeur'])/100;
                                            
                                        }
                                        elseif($rules['Valeur'] !=0 && $rules['Unite'] !='')
                                        {
                                           
                                            $penalites_cdf = $rules['Valeur'];
                                            
                                        }
                                        $montant_cdf = $row->Montant_11 + $montant_cdf;
                                        
                                }
                                if($row->Beneficaire_15=='DGI')
                                {
                                        if($row->Devise_12=='USD')
                                        {
                                                $tab['DGI'][$i]= $contrevaleur;
                                        }
                                        elseif($row->Devise_12=='CDF')
                                        {
                                                $tab['DGI'][$i]= $penalites_cdf;
                                        }
                                        
                                }
                                if($row->Beneficaire_15=='DGDA')
                                {
                                        if($row->Devise_12=='USD')
                                        {
                                                $tab['DGDA'][$i]= $contrevaleur;
                                        }
                                        elseif($row->Devise_12=='CDF')
                                        {
                                                $tab['DGDA'][$i]= $penalites_cdf;
                                        }
                                        
                                }
                                if($row->Beneficaire_15=='DGRAD')
                                {
                                        if($row->Devise_12=='USD')
                                        {
                                                $tab['DGRAD'][$i]= $contrevaleur;
                                        }
                                        elseif($row->Devise_12=='CDF')
                                        {
                                                $tab['DGRAD'][$i]= $penalites_cdf;
                                        }
                                        
                                }

                                foreach($guichets as $obj)
                                {
                                        if($obj->Id_0==$row->Guichet_21)
                                        {

                                                if($row->Devise_12=='USD')
                                                {
                                                        $guichet[$obj->Id_0][$i]= $contrevaleur;
                                                }
                                                elseif($row->Devise_12=='CDF')
                                                {
                                                        $guichet[$obj->Id_0][$i]= $penalites_cdf;
                                                }
                                        }
                                }
                                foreach($agences as $obj)
                                {
                                        if($obj->Id_0==$row->Agence_20)
                                        {

                                                if($row->Devise_12=='USD')
                                                {
                                                        $agence[$obj->Id_0][$i]= $contrevaleur;
                                                }
                                                elseif($row->Devise_12=='CDF')
                                                {
                                                        $agence[$obj->Id_0][$i]= $penalites_cdf;
                                                }
                                        }
                                }
                        $i++;
                        }

                }
                $paiement = $i;
                
                $dgi = !empty($tab['DGI']) ? array_sum($tab['DGI']) : 0;  
                $dgda = !empty($tab['DGDA']) ? array_sum($tab['DGDA']) : 0;
                $dgrad = !empty($tab['DGRAD']) ? array_sum($tab['DGRAD']) : 0;
                
                $som = 0;
                $guichet_montant= array();
                $agence_montant = array();
                foreach($guichets as $row)
                {

                        if(!empty($guichet[$row->Id_0]))
                        {
                                $guichet_montant[$row->Id_0]= array_sum($guichet[$row->Id_0]);
                        }

                }
                foreach($agences as $row)
                {

                        if(!empty($agence[$row->Id_0]))
                        {
                               $agence_montant[$row->Id_0]= array_sum($agence[$row->Id_0]);
                        }

                }
                $contrevaleur = $montant_usd * $usd;
                $paiement_total = $montant_cdf + $contrevaleur;

                $total = $dgi + $dgda + $dgrad;
                $datas['DGI']= $dgi;
                $datas['DGDA']= $dgda;
                $datas['DGRAD']= $dgrad;
                $datas['Total'] = $total;
                $datas['Paiement']= $paiement;
                $datas['Paiement_total']= $paiement_total;
                $datas['Guichet']= $guichet_montant;
                $datas['Agence']= $agence_montant;
                

                return $datas;
        }
        
        public function get_regles($data = NULL)
        {
                $regles= $this->encaissementModel->get_regle_penalites();
                
                $regie= $data['Beneficaire_15'];
                $service= $data['Service_16'];
                $devise= $data['Devise_12'];
                $guichet = $data['Guichet_21'];
                $montant = $data['Montant_11'];
                
                $valeur = 0;
                $unite = 0;
                
                $ddmenu = array();
                
                foreach ($regles as $row)
                {
                        #Priorit� 1
                        if($row->Beneficiaire_5 == $regie && $row->Service_6 == $service && $row->Guichet_8 == $guichet && ($row->Min_11 <= $montant) && ($montant <= $row->Max_12))
                        {
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                        #Priorit� 2
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == $service && $row->Guichet_8 == $guichet && ($row->Min_11 == 0 && $montant == 0))
                        {
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;      
                        }
                        #Priorit� 3
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == $service && $row->Guichet_8 == $guichet)
                        {
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        } 
                        #Priorit� 4
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == $service && ($row->Min_11 <= $montant) && ($montant < $row->Max_12))
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                        #Priorit� 5
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == $service)
                        {     
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;    
                        }
                        #Priorit� 6
                        elseif($row->Beneficiaire_5 == $regie && ($row->Min_11 <= $montant) && ($montant < $row->Max_12) && $row->Service_6 == '')
                        {
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                        #Priorit� 7
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == '' && $row->Min_11==0 && $row->Max_12==0)
                        {
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;    
                        }
                        #Priorit� 8
                        elseif($row->Beneficiaire_5 == $regie && $row->Service_6 == $service && ($row->Min_11 <= $montant) && ($montant < $row->Max_12) && $row->Recette_7 == '')
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                        #Priorit� 9
                        elseif($row->Beneficiaire_5 == $regie && ($row->Min_11 <= $montant) && ($montant < $row->Max_12) && $row->Recette_7 == '' && $row->Service_6 == '')
                        { 
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;    
                        }
                        #Priorit� 10
                        elseif($row->Beneficiaire_5 == $regie && $row->Recette_7 == '' && $row->Service_6 == '' && $row->Min_11==0 && $row->Max_12==0)
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break; 
                        }
                        #Priorit� 10
                        elseif(($row->Beneficiaire_5 == 0 || $row->Beneficiaire_5 =='') && $row->Recette_7 == '' && $row->Service_6 == '' && $row->Min_11==0 && $row->Max_12==0)
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break; 
                        }
                        #Priorit� 10
                        elseif($row->Beneficiaire_5 == $regie && $row->Recette_7 == '' && $row->Service_6 == '' && $row->Min_11==0 && $row->Max_12==0)
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                        #Priorit� 10
                        elseif(($row->Beneficiaire_5 == 0 || $row->Beneficiaire_5 =='') && $row->Recette_7 == '' && $row->Service_6 == '' && $row->Min_11==0 && $row->Max_12==0)
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break; 
                        }
                        elseif(($row->Beneficiaire_5 == 0 || $row->Beneficiaire_5 =='') && $row->Recette_7 == '' && $row->Service_6 == '' && ($row->Min_11 <= $montant) && ($montant <= $row->Max_12))
                        {    
                                $valeur = $row->Value_9;
                                $unite = $row->Unite_10;
                                break;
                        }
                }
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite);
                
                
                return $ddmenu;
        }
        
        public function get_payment_integrated()
        {
                $paiements= $this->encaissementModel->get_paiements('integrated');
                        
                $paiement_integrated = array(
                            'pay_dgi_cdf'=>0,
                            'pay_dgi_usd'=>0,
                            'pay_dgda_cdf'=>0,
                            'pay_dgda_usd'=>0,
                            'pay_dgrad_cdf'=>0,
                            'pay_dgrad_usd'=>0

                            );

                foreach ($paiements as $row)
                {
                        if($row->Beneficaire_15=='DGI')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        $paiement_integrated['pay_dgi_usd'] += $row->Montant_11;
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        $paiement_integrated['pay_dgi_cdf'] += $row->Montant_11;

                                }
                        }
                        elseif($row->Beneficaire_15=='DGDA')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        $paiement_integrated['pay_dgda_usd'] += $row->Montant_11; 
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        $paiement_integrated['pay_dgda_cdf'] += $row->Montant_11;
                                }

                        }
                        elseif($row->Beneficaire_15=='DGRAD')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        $paiement_integrated['pay_dgrad_usd'] += $row->Montant_11;
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        $paiement_integrated['pay_dgrad_cdf'] += $row->Montant_11;
                                }

                        }
                }
                return $paiement_integrated;
        }
        
        public function get_payment_integrated_to_validate()
        {
                $list = implode(",", $_SESSION['ids']);
                        
                $paiements= $this->encaissementModel->get_paiements('integrated',$list);

                $paiement_integrated = array(

                            'pay_dgi_cdf'=>0,
                            'pay_dgi_usd'=>0,
                            'pay_dgda_cdf'=>0,
                            'pay_dgda_usd'=>0,
                            'pay_dgrad_cdf'=>0,
                            'pay_dgrad_usd'=>0,
                            'id_dgi_cdf'=>0,
                            'id_dgi_usd'=>0,
                            'id_dgda_cdf'=>0,
                            'id_dgda_usd'=>0,
                            'id_dgrad_cdf'=>0,
                            'id_dgrad_usd'=>0
                );
                $id_dgi_cdf = $id_dgi_usd = $id_dgda_cdf = $id_dgda_usd = $id_dgrad_cdf = $id_dgrad_usd = [];

                $dgi_cdf_paiement = $dgi_usd_paiement = $dgda_cdf_paiement = $dgda_usd_paiement = $dgrad_cdf_paiement = $dgrad_usd_paiement =0; 

                $dgi_cdf_number = $dgi_usd_number = $dgda_cdf_number = $dgda_usd_number = $dgrad_cdf_number = $dgrad_usd_number =0;

                foreach ($paiements as $row)
                {
                        if($row->Beneficaire_15=='DGI')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgi_usd_paiement++;
                                                }
                                        }
                                        $dgi_usd_number++;
                                        $paiement_integrated['pay_dgi_usd'] += $row->Montant_11;
                                        array_push($id_dgi_usd, $row->Id_0);
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgi_cdf_paiement++;
                                                }
                                        }
                                        $dgi_cdf_number++;
                                        $paiement_integrated['pay_dgi_cdf'] += $row->Montant_11;
                                        array_push($id_dgi_cdf, $row->Id_0);
                                }
                        }
                        elseif($row->Beneficaire_15=='DGDA')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgda_usd_paiement++;
                                                }
                                        }
                                        $dgda_usd_number++;
                                        $paiement_integrated['pay_dgda_usd'] += $row->Montant_11;
                                        array_push($id_dgda_usd, $row->Id_0);
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgda_cdf_paiement++;
                                                }
                                        }
                                        $dgda_cdf_number++;
                                        $paiement_integrated['pay_dgda_cdf'] += $row->Montant_11;
                                        array_push($id_dgda_cdf, $row->Id_0);
                                }

                        }
                        elseif($row->Beneficaire_15=='DGRAD')
                        {
                                if($row->Devise_12=='USD')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgrad_usd_paiement++;
                                                }
                                        }
                                        $dgrad_usd_number++;
                                        $paiement_integrated['pay_dgrad_usd'] += $row->Montant_11;
                                        array_push($id_dgrad_usd, $row->Id_0);
                                }
                                elseif($row->Devise_12=='CDF')
                                {
                                        if($row->Isysvalidation_48 !="")
                                        {
                                                if($row->Isysvalidation_48=='200')
                                                {
                                                    $dgrad_cdf_paiement++;
                                                }
                                        }
                                        $dgrad_cdf_number++;
                                        $paiement_integrated['pay_dgrad_cdf'] += $row->Montant_11;
                                        array_push($id_dgrad_cdf, $row->Id_0);
                                }

                        }
                }

                $paiement_integrated['dgi_cdf_paiement'] = $dgi_cdf_paiement;
                $paiement_integrated['dgi_usd_paiement'] = $dgi_usd_paiement;
                $paiement_integrated['dgda_cdf_paiement'] = $dgda_cdf_paiement;
                $paiement_integrated['dgda_usd_paiement'] = $dgda_usd_paiement;
                $paiement_integrated['dgrad_cdf_paiement'] = $dgrad_cdf_paiement;
                $paiement_integrated['dgrad_usd_paiement'] = $dgrad_usd_paiement;

                $paiement_integrated['dgi_cdf_number'] = $dgi_cdf_number;
                $paiement_integrated['dgi_usd_number'] = $dgi_usd_number;
                $paiement_integrated['dgda_cdf_number'] = $dgda_cdf_number;
                $paiement_integrated['dgda_usd_number'] = $dgda_usd_number;
                $paiement_integrated['dgrad_cdf_number'] = $dgrad_cdf_number;
                $paiement_integrated['dgrad_usd_number'] = $dgrad_usd_number;

                $paiement_integrated['id_dgi_cdf'] = $id_dgi_cdf;
                $paiement_integrated['id_dgi_usd'] = $id_dgi_usd;
                $paiement_integrated['id_dgda_cdf'] = $id_dgda_cdf;
                $paiement_integrated['id_dgda_usd'] = $id_dgda_usd;
                $paiement_integrated['id_dgrad_cdf'] = $id_dgrad_cdf;
                $paiement_integrated['id_dgrad_usd'] = $id_dgrad_usd;

                return $paiement_integrated;
        }
        
        public function get_month_of_rates()
        {
                $current_day = gmdate('Y-m-d');
                $next_due_date = date('Y-m-d', strtotime($current_day. ' -30 days'));

                $taux = $this->ratesModel->get_all_taux($next_due_date, $current_day);
                $taux_reverse = array_reverse($taux);

                $data = array();

                foreach($taux_reverse as $row):
                        if($row->Day_9 ==$current_day)
                        {
                                $aKey = explode('-',$row->Date_1);
                                $m = $aKey[1]*1;
                                $days = explode(' ',$aKey[2]);
                                $time = explode(':',$days[1]);
                                $h = $time[0]*1+1;

                                $m=$this->months[$m];
                                $value = $days[0].' '.$m.' '.$h.'h'.$time[1];
                                if(!isset($data[$row->Date_1]))
                                {
                                        $data[$row->Date_1] = 0;
                                }
                                if($row->Day_9!="")
                                {
                                        $data[$row->Date_1] = $value;
                                }
                        }
                        else
                        {
                                $aKey = explode('-',$row->Day_9);
                                $m = $aKey[1]*1;
                                $days = explode(' ',$aKey[2]);
                                $m=$this->months[$m];
                                $value = $days[0].' '.$m;
                                if(!isset($data[$row->Day_9]))
                                {
                                        $data[$row->Day_9] = 0;
                                }
                                if($row->Day_9!="")
                                {
                                         $data[$row->Day_9] = $value;
                                }
                        }
                endforeach;

                return $data;
        }
        
        public function get_rates_by_day()
        {
                
                $current_day = gmdate('Y-m-d');
                $next_due_date = date('Y-m-d', strtotime($current_day. ' -30 days'));

                $taux = $this->ratesModel->get_all_taux($next_due_date, $current_day);
                
                $taux_reverse = array_reverse($taux);
                
                $data = array();
                $return = array();

                foreach($taux_reverse as $row):
                        if($row->Day_9 ==$current_day)
                        {
                                if(!isset($data[$row->Date_1]))
                                {
                                        $data[$row->Date_1] = 0;
                                }
                                if($row->Dollar_4!="")
                                {
                                         $data[$row->Date_1] = $row->Dollar_4;
                                }
                        }
                        else
                        {
                                if(!isset($data[$row->Day_9]))
                                {
                                        $data[$row->Day_9] = 0;
                                }
                                if($row->Dollar_4!="")
                                {
                                         $data[$row->Day_9] = $row->Dollar_4;
                                }
                        }
                endforeach;
                $return['Dollar'] = $data;
                $data = array();

                foreach($taux as $row):

                        if($row->Day_9 ==$current_day)
                        {

                                if(!isset($data[$row->Date_1]))
                                {
                                        $data[$row->Date_1] = 0;
                                }
                                if($row->Euro_5!="")
                                {
                                        $data[$row->Date_1] = $row->Euro_5;
                                }
                        }
                        else
                        {
                                if(!isset($data[$row->Day_9]))
                                {
                                        $data[$row->Day_9] = 0;
                                }
                                if($row->Euro_5!="")
                                {
                                        $data[$row->Day_9] = $row->Euro_5;
                                }
                        }
                endforeach;
                $return['Euro'] = $data;
                $data = array();

                foreach($taux as $row):

                        if($row->Day_9 ==$current_day)
                        {
                                if(!isset($data[$row->Date_1]))
                                {
                                        $data[$row->Date_1] = 0;
                                }
                                if($row->Rand_6!="")
                                {
                                         $data[$row->Date_1] = $row->Rand_6;
                                }
                        }
                        else
                        {
                                if(!isset($data[$row->Day_9]))
                                {
                                        $data[$row->Day_9] = 0;
                                }
                                if($row->Rand_6!="")
                                {
                                         $data[$row->Day_9] = $row->Rand_6;
                                }
                        }
                endforeach;
                $return['Rand'] = $data;
                $data = array();

                foreach($taux as $row):

                        if($row->Day_9 ==$current_day)
                        {
                                if(!isset($data[$row->Date_1]))
                                {
                                        $data[$row->Date_1] = 0;
                                }
                                if($row->Pound_7!="")
                                {
                                        $data[$row->Date_1] = $row->Pound_7;
                                }
                        }
                        else
                        {
                                if(!isset($data[$row->Day_9]))
                                {
                                        $data[$row->Day_9] = 0;
                                }
                                if($row->Pound_7!="")
                                {
                                        $data[$row->Day_9] = $row->Pound_7;
                                }
                        }
                endforeach;
                $return['Pound'] = $data;
                $data = array();

                return $return;
        }
        
        public function get_rates_of_last_days($data=NULL, $arg=NULL)
        {
                $i=0;
                $taux = $data;
                $month = $arg; 
                
                foreach($month as $key => $val)
                {
                        if(isset($taux['Dollar'][$key]))
                        {
                                $aList['Dollar'][]=$taux['Dollar'][$key];
                                $aList['Euro'][]=$taux['Euro'][$key];
                                $aList['Rand'][]=$taux['Rand'][$key];
                                $aList['Pound'][]=$taux['Pound'][$key];
                                $aList['months'][$i] = '"'.$val.'"';
                        }
                        
                        $i++;
                }
                if(isset($aList))
                {
                        $iList['months']=implode(',',$aList['months']);
                        $iList['Dollar']=implode(',',$aList['Dollar']);
                        $iList['Euro']=implode(',',$aList['Euro']);
                        $iList['Rand']=implode(',',$aList['Rand']);
                        $iList['Pound']=implode(',',$aList['Pound']);
                            
                        return $iList;
                }
        }
        
        public function get_declaration_paiement()
        {
                $declaration = $data;
                $encaissement = new stdClass();
                $encaissement->Id_0 = NULL;
                $encaissement->Date_1 = gmdate('Y-m-d H:i:s');
                $encaissement->Status_2 = '';
                $encaissement->Account_3 = $this->session->userdata['account_id'];
                $encaissement->Logirefid_4 = round(1000,9999).mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                $encaissement->Banqueid_5 = ''; //Core Banking ID
                $encaissement->Chequeid_6 = '';
                $encaissement->Isysid_7 = '';
                $encaissement->Rtgsid_8 = '';
                $encaissement->Makerid_9 = '';

                $encaissement->Checkerid_10 = '';
                $encaissement->Montant_11 = $declaration->Amount_10;
                $encaissement->Devise_12 = '';
                $encaissement->Nif_13 = $declaration->Nif_17;
                $encaissement->Designation_14 = '';
                $encaissement->Beneficaire_15 = 'DGI';
                $encaissement->Service_16 = '';
                $encaissement->Typerecette_17 = '';
                $encaissement->Mode_19 = '';
                $encaissement->Artbudgetaire_18 = '';

                $encaissement->Agence_20 = $_SESSION['Logiref_agence'];
                $encaissement->Guichet_21 = $_SESSION['Logiref_guichet'];
                $encaissement->Contrevaleur_22 = ''; // Tjrs en CDF
                $encaissement->Commission_23= '';
                $encaissement->Devise_24= '';
                $encaissement->Notetype_25 = '5';
                $encaissement->Noteid_26 = '';
                $encaissement->Notedate_27 = gmdate('Y-m-d H:i:s');
                $encaissement->Notemontant_28 = $declaration->Amount_10;
                $encaissement->Notedevise_29 = $declaration->Currency_11;

                $encaissement->Notereference_30 = ''; 
                $encaissement->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                $encaissement->Reference_32 = '';
                $encaissement->Compte_33 = '';
                $encaissement->Devise_34 = '';
                $encaissement->Changement_35 = ''; //Date
                $encaissement->Validation_36 = '';
                $encaissement->Integration_37 = '';
                $encaissement->Reversement_38 = '';
                $encaissement->Nivellement_39 = '';

                $encaissement->Suppression_40 = '';
                $encaissement->Taux_41 = '';
                $encaissement->Devise_42 = '';
                $encaissement->Attestation_43 = '';
                $encaissement->Sydonia_44 = '0';
                $encaissement->Tresor_45 = '0';
                return $encaissement;
        }
        
        public function get_order_content($data=NULL, $arg=NULL)
        {
                $order = $this->encaisement_model->get_order_info($data);
                $encaissement = $this->encaisement_model->get_paiement_info(NULL);
                $encaissement->Ordreid = $data;
                if($order->Regie_7 =="DGI"):

                    $item = $this->integrationModel->get_declaration_info($order->Object_13);

                    $content = json_decode($item->Content_16);
                    if(isset($content->paiement))
                    {
                            $paiement = json_decode($content->paiement);
                            $notemontant = $paiement->Notemontant;
                    }
                    else
                    {
                            $paiement = "";
                            $notemontant = "";
                    }
                    $notedevise = 'CDF';
                    $amount = $order->Amount_12;
                    $account = $order->Account_10;
                    $currency = $order->Currency_11;
                    $Nif = $item->Nif_17;
                    $encaissement->Notetype_25 = '1';
                    $service = isset($content->Service) ? $content->Service : "";
                    $encaissement->Ndeclaration = $order->Object_13;
                    $encaissement->Id_0 = $order->Paiementid_15;

                elseif($order->Regie_7 =="DGDA"):
                    $bl = $order->Object_13;
                    $amountDGDA = 0;
                    $amountDGI = 0;
                    $amountPRDGDA = 0;
                    $amountDGRAD = 0;
                    $amountSERVICES = array();
                    $autreTaxes = 0;
                    $encaissement = $this->encaisement_model->get_paiement_info(NULL);
                    $taxesDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "TRESOR", 100);
                    $propresDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "PROPRES", 100);
                    $taxesDGRAD = $this->logirefModel->get_dropdown("recettes", "DGRAD", "RFTRESD", 100);
                    $taxesSERVICES = $this->logirefModel->get_dropdown("recettes", NULL, "RFPROPD", 100);

                    $declaration = $this->integrationModel->get_paiement_sydonia($bl);
                    $bulletin = $this->normalize_sydonia_result($declaration->Results_13 ?? null);
              
                    $receiptId = $this->build_sydonia_receipt_id($bulletin);
                    $taxes = $this->get_sydonia_taxes_paid($bulletin);
                    /* Initialisation */
                    $encaissement->Designation_14 = '';
                    $encaissement->Nif_13 = $declaration->Nif_9;                        
                    $encaissement->Beneficaire_15 = 'DGDA';
                    $encaissement->Service_16 = $declaration->Office_6;
                    $encaissement->Typerecette_17 = 'DDI';
                    $encaissement->Mode_19= '7';
                    $encaissement->Agence_20 = $_SESSION['Logiref_agence'];
                    $encaissement->Contrevaleur_22 = $bulletin->declarationsPaid->amountToBePaid ?? 0; // Tjrs en CDF
                    $encaissement->Notetype_25= '3';
                    $encaissement->Noteid_26 = ($bulletin->declarationsPaid->assessmentSerial ?? '').($bulletin->declarationsPaid->assessmentNumber ?? '');
                    $recieptDate = explode("/", (string) ($bulletin->receiptDate ?? ""));
                    $encaissement->Notedate_27= (count($recieptDate) === 3) ? $recieptDate[2]."-".$recieptDate[1]."-".$recieptDate[0] : '';
                    $encaissement->Notemontant_28= $bulletin->declarationsPaid->amountToBePaid ?? 0;
                    $encaissement->Notedevise_29= 'CDF';
                    $encaissement->Datevaleur_31 = gmdate('Y-m-d');
                    $encaissement->Reference_32 = 'Paiement BL/DGDA/'.$receiptId;
                    $encaissement->Compte_33 = $order->Account_10;
                    $encaissement->Devise_34 = $order->Currency_11;
                    /* Amount for DGDA */

                    $total = 0;
                    foreach( $taxes as $tax)
                    {
                            if(isset($taxesDGDA['DGDA'][$tax->taxeCode])) $amountDGDA = $amountDGDA + $tax->taxeAmount;
                            if(isset($taxesDGRAD['DGRAD'][$tax->taxeCode])) $amountDGRAD = $amountDGRAD + $tax->taxeAmount;
                            if(isset($taxesDGRAD['DGI'][$tax->taxeCode])) $amountDGI = $amountDGI + $tax->taxeAmount;
                            if(isset($propresDGDA['DGDA'][$tax->taxeCode])) $amountPRDGDA = $amountPRDGDA + $tax->taxeAmount;
                            if(!isset($taxesDGDA['DGDA'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) && !isset($taxesDGRAD['DGI'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) )$autreTaxes = $autreTaxes + $tax->taxeAmount;
                    }
                    /* Autres Taxes Fond Propres */
                    $services = array_keys($taxesSERVICES);
                    foreach( $services as $service)
                    {
                            foreach( $taxes as $tax)
                            {
                                    if(isset($taxesSERVICES[$service][$tax->taxeCode]) && !isset($amountSERVICES[$service])) $amountSERVICES[$service] = 0;
                                    if(isset($taxesSERVICES[$service][$tax->taxeCode])) $amountSERVICES[$service] = $amountSERVICES[$service] + $tax->taxeAmount; 
                            }
                    }
                    //echo "Total2: ".$total; die;
                    //Initialisation
                    $encaissement->Devise_12 = 'CDF';
                    $encaissement->Notereference_30 = array(
                                                    'standard' => $declaration->Agent_10,
                                                    'year' => $declaration->Year_5,
                                                    'serie' => $declaration->Number_8,
                                                    'moyen' => $declaration->Type_4,
                                                    'agence' => '',
                                                    'serial' => $declaration->Serie_7,
                                                    'bank' => $declaration->Bank_11,
                                                    'amountDGDA'=>$amountDGDA,
                                                    'amountDGI'=>$amountDGI,
                                                    'amountPRDGDA' =>$amountPRDGDA,
                                                    'amountDGRAD'=>$amountDGRAD,
                                                    'amountSERVICES'=>$amountSERVICES,
                                                    'autresTaxes' => $autreTaxes,
                                                    'quittance' => $declaration->Pdfcontent_18,
                                                    'taxesPaid'=>$taxes,
                                                    'Paiementid'=>$bl,
                                                    'Ordreid' => $order->Id_0
                                                );
                    $encaissement->Montant_11 = $bulletin->totalAmount ?? $declaration->Amount_12;
                    $encaissement->Ordreid = $order->Id_0;
                    return $encaissement; die;

                elseif($order->Regie_7 =="DGRAD"):
                    # extraction de la note de perception pour recuperer la devise et le montant de la note
                    $item = $this->integrationModel->get_note_info($order->Object_13);
                    $service = $item->Service_9;
                    $notemontant = '';
                    $notedevise = $order->Currency_11;
                    $amount =$order->Amount_12;
                    $account =$order->Account_10;
                    $currency = '';
                    $Nif = '';
                    $encaissement->Id_0 = $order->Paiementid_15;
                endif;

                $encaissement->Montant_11 = $amount;
                $encaissement->Devise_12 = $currency;
                $encaissement->Nif_13 = $Nif;
                $encaissement->Service_16 = $service;
                $encaissement->Beneficaire_15 = $order->Regie_7;
                $encaissement->Mode_19 = '7';
                $encaissement->Agence_20 = $_SESSION['Logiref_agence'];
                $encaissement->Guichet_21 = $_SESSION['Logiref_guichet'];
                $encaissement->Notedate_27 = gmdate('Y-m-d H:i:s');
                $encaissement->Notemontant_28 = $notemontant;
                $encaissement->Notedevise_29 = $notedevise;
                $encaissement->Compte_33 = $account;
                $encaissement->Devise_34 = $currency;
                return $encaissement;
        }
        
        public function get_commision($data=NULL, $arg=NULL, $param=NULL)
        {
            # Verification comptabilisation($pid, $logirefid, $paiement
            # ($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
            $integrations = array();
            $pid = $data;
            $logirefid = $arg;
            $paiement = $param;

            $data = array();
            //InitialisationContrevaleur_22
            $pTypeRecette = (isset($paiement['Typerecette_17']))?$paiement['Typerecette_17']: '';
            $institution = (isset($paiement['Beneficaire_15']))?$paiement['Beneficaire_15']: '';
            $pMode=$paiement['Mode_19'];
            $pMontant=$paiement['Montant_11'];
            $pDevise=$paiement['Devise_12'];
            $pContrevaleur=$paiement['Contrevaleur_22']; //Contre valeur du montant en CDF
            $pCommission=$paiement['Commission_23']; //Commission 
            $fDevise=$paiement['Devise_24']; //Devise de la commission
            if(isset($paiement['Compte_33'])) $cCompte=$paiement['Compte_33']; else $cCompte=''; //Compte du client
            if(isset($paiement['Devise_34'])) $cDevise=$paiement['Devise_34']; else $cDevise=''; //Devise du compte client
            $taux = $paiement['Taux_41'];
            $refclient = $paiement['Reference_32'];
            //Variable d'integration
            $data['Date_1'] = gmdate('Y-m-d H:i:s');
            $data['Status_2']=1;
            $data['Account_3']= $this->session->userdata['account_id'];
            $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
            $data['Agence_6']=$paiement['Agence_20'];
            $data['Guichet_7']=$paiement['Guichet_21'];
            $data['Date_13']=$paiement['Datevaleur_31'];
            $data['Reference_14']=$logirefid; //TBD
            $data['Mode_15']=$pMode;
            $data['Makerid_16']=$this->session->userdata['user_id'];
            $libelle = $paiement['Beneficaire_15'].' '.$paiement['Typerecette_17'].' '.$paiement['Designation_14'].' '.$paiement['Nif_13'];

            //Comptes//La banque
            $aBanque = $this->stakeholdersModel->get_dropdown("beneficiaries","BKC");

            $banque = array_keys($aBanque["BKC"]);
            $banque = $banque[0];
            $comptes = $this->accountModel->get_comptes_array("'CPT', 'CPU', 'TVA', 'CCV'");
            if($pTypeRecette != NULL && $pTypeRecette != "")
            $comptescomm = $this->accountModel->get_comptescfb_recette_array("'CFB'",$pTypeRecette, $institution);
            else $comptescomm = $this->accountModel->get_comptescfb_agence_array("'CFB'", $institution);
          
           
            
            ##################### Cas 1 ###########################################################
            //Paiment au comptant en CDF | Mode is ESPECE

            if($pMode=="5" && $pDevise=="CDF")
            {
                    $results = array();

                    //Operation 1: crediter le compte commission de la banque en CDF
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte TVA de la banque en CDF
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise];
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;
            }

            ##################### Cas 2 ############################################
            //Paiment au comptant en USD | Mode is ESPECE
            elseif($pMode=="5" && $pDevise=="USD")
            {
                    $results = array();

                    //Operation 1: crediter le compte commission de la banque en USD
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte TVA de la banque en USD
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;
            }

            ##################### Cas 3 ############################################
            //Ordre de paiement d'un compte client en CDF d'une recette en CDF
            elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="CDF")
            {
                    $results = array();

                    //Operation 1: debiter le compte commission de la banque en CDF
                    $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>'Commission > '.$paiement['Designation_14'], 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte commission de la banque en CDF
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 3: crediter le compte TVA de la banque en CDF
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

            }

            ##################### Cas 4 ############################################
            //Ordre de paiement d'un compte client en USD d'une recette en USD
            elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="USD")
            {
                    $results = array();

                    //Operation 1: debiter la compte commission de la banque en USD
                    $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>'Commission > '.$paiement['Designation_14'], 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte commission de la banque en USD
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 3: crediter le compte TVA de la banque en USD
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;
            }

            ##################### Cas 5 ############################################
            //Ordre de paiement d'un compte client en CDF d'une recette en USD
            elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="USD")
            {
                    $results = array();

                    //Operation 1: debiter la commission du compte client
                    if($fDevise == 'CDF')
                        $com = $pCommission; 
                    else 
                        $com = $pCommission * $taux;
                    $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>'Commission > '.$paiement['Designation_14'], 'Montant_10'=>$com, 'Devise_11'=>$cDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte commission de la banque
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 3: crediter le compte TVA de la banque
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;
            }

            ##################### Cas 6 ############################################
            //Ordre de paiement d'un compte client en USD d'une recette en CDF
            elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="CDF")
            {
                    $results = array();
                    $taux = json_decode($_SESSION['Bank_rates'], true);
                    $tauxd = $taux['Dollar_4'];
                    //Operation 1: debiter la commission du compte du client
                    if($fDevise == 'USD')
                        $com = $pCommission; 
                    else 
                        $com = $pCommission / $tauxd;
                    $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>'Commission > '.$paiement['Designation_14'], 'Montant_10'=>$com, 'Devise_11'=>$cDevise);
                    $results[] = $instruction;

                    //Operation 2: crediter le compte commission de la banque
                    if(isset($comptescomm[$banque][$fDevise])) 
                        $bCompte = $comptescomm[$banque][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;

                    //Operation 3: crediter le compte TVA de la banque
                    if(isset($comptes[$banque]['TVA'][$fDevise])) 
                        $bCompte = $comptes[$banque]['TVA'][$fDevise]; 
                    else 
                        $bCompte='00000000000000000000000';
                    $tva = $pCommission * $this->tva;
                    $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                    $results[] = $instruction;
            }

            //Generer les instructions
            if(!empty($results))
            {       /* Save datas in DB Integration*/

                    foreach($results as $instruction)
                    {
                            $elements = array_merge($instruction,$data);
                            $integrations[] = $elements;
                            $cid = $this->integrationModel->save_integrations($elements, NULL);
                    }
            }
                
                return $integrations;
        }
        
        public function get_comptabilisation($data=NULL, $arg=NULL, $param=NULL)
        {
                # Verification comptabilisation($pid, $logirefid, $paiement
                # ($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                $integrations = array();
                $pid = $data;
                $logirefid = $arg;
                $paiement = $param;
                $data = array();
                if($pid!=NULL && $pid=="")
                {
                        echo '<div class="alert alert-danger text-white">Avertissement! paiement non comptabilis&eacute;..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        die;
                }
                else 
                {
                        //InitialisationContrevaleur_22
                        $pTypeRecette = (isset($paiement['Typerecette_17']))?$paiement['Typerecette_17']: '';
                        $institution = (isset($paiement['Beneficaire_15']))?$paiement['Beneficaire_15']: '';
                        $pMode=$paiement['Mode_19'];
                        $pMontant=$paiement['Montant_11'];
                        $pDevise=$paiement['Devise_12'];
                        $pContrevaleur=$paiement['Contrevaleur_22']; //Contre valeur du montant en CDF
                        $pCommission=$paiement['Commission_23']; //Commission 
                        $fDevise=$paiement['Devise_24']; //Devise de la commission
                        if(isset($paiement['Compte_33'])) $cCompte = $paiement['Compte_33']; else $cCompte=''; //Compte du client
                        if(isset($paiement['Devise_34'])) $cDevise = $paiement['Devise_34']; else $cDevise=''; //Devise du compte client
                        $taux = $paiement['Taux_41'];
                        $refclient = $paiement['Reference_32'];
                        //Variable d'integration
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Date_13']=$paiement['Datevaleur_31'];
                        $data['Reference_14']=$logirefid; //TBD
                        $data['Mode_15']=$pMode;
                        $data['Makerid_16']=$this->session->userdata['user_id'];
                        $libelle = $paiement['Beneficaire_15'].' '.$paiement['Typerecette_17'].' '.$paiement['Designation_14'].' '.$paiement['Nif_13'];
                }

                //Comptes//La banque
                $aBanque = $this->stakeholdersModel->get_dropdown("beneficiaries","BKC");

                $banque = array_keys($aBanque["BKC"]);
                $banque = $banque[0];

                $comptes = $this->accountModel->get_comptes_array("'CPT'");
                $comptesExchange = $this->accountModel->get_comptes_by_type_array("'CCV','CPU'", $institution);
                ##################### Cas 1 ###########################################################
                //Paiment au comptant en CDF | Mode is ESPECE

                if($pMode=="5" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 2 ############################################
                //Paiment au comptant en USD | Mode is ESPECE
                elseif($pMode=="5" && $pDevise=="USD")
                {
                        $results = array();
                        //Operation 1: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }


                ##################### Cas 3 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en CDF
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 4 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="USD")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en USD
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 5 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="USD")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en CDF du montant paye
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pContrevaleur, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 3: debiter compte position en USD
                        if(isset($comptesExchange[$banque]['CPU']['USD'])) 
                            $bCompte = $comptesExchange[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 4: crediter compte contre valeur en CDF
                        if(isset($comptesExchange[$banque]['CCV']['CDF'])) 
                            $bCompte = $comptesExchange[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $pContrevaleur;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 5: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 6 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en USD du montant paye
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $tauxd = $taux['Dollar_4'];

                        $aMontant = $pMontant / $tauxd;
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$aMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;
                        //Operation 2: debiter compte contre-valeur en CDF
                        if(isset($comptesExchange[$banque]['CCV']['CDF'])) 
                            $bCompte = $comptesExchange[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 3: crediter compte position en USD
                        if(isset($comptesExchange[$banque]['CPU']['USD'])) 
                            $bCompte = $comptesExchange[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $aMontant;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 4: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPT']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPT']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;


                }
                //Generer les instructions
                if(!empty($results))
                {       /* Save datas in DB Integration*/
                        foreach($results as $instruction)
                        {
                                $elements = array_merge($instruction,$data);
                                $integrations[] = $elements;
                                $cid = $this->integrationModel->save_integrations($elements, NULL);
                        }

                }
                return $integrations;
        }
        
        
        public function get_comptablisations_fonds_propres($data=NULL, $arg=NULL, $param=NULL)
        {
                # Verification comptabilisation($pid, $logirefid, $paiement
                # ($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                $integrations = array();
                $pid = $data;
                $logirefid = $arg;
                $paiement = $param;
                $data = array();
                if($pid!=NULL && $pid=="")
                {
                        echo '<div class="alert alert-danger text-white">Avertissement! paiement non comptabilis&eacute;..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        die;
                }
                else 
                {
                        //InitialisationContrevaleur_22
                        $pMode=$paiement['Mode_19'];
                        $pMontant=$paiement['Montant_11'];
                        $pDevise=$paiement['Devise_12'];
                        $pContrevaleur=$paiement['Contrevaleur_22']; //Contre valeur du montant en CDF
                        $pCommission=$paiement['Commission_23']; //Commission 
                        $fDevise=$paiement['Devise_24']; //Devise de la commission
                        if(isset($paiement['Compte_33'])) $cCompte = $paiement['Compte_33']; else $cCompte=''; //Compte du client
                        if(isset($paiement['Devise_34'])) $cDevise = $paiement['Devise_34']; else $cDevise=''; //Devise du compte client
                        $taux = $paiement['Taux_41'];
                        $refclient = $paiement['Reference_32'];
                        //Variable d'integration
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Date_13']=$paiement['Datevaleur_31'];
                        $data['Reference_14']=$logirefid; //TBD
                        $data['Mode_15']=$pMode;
                        $data['Makerid_16']=$this->session->userdata['user_id'];
                        $libelle = $paiement['Beneficaire_15'].' '.$paiement['Typerecette_17'].' '.$paiement['Designation_14'].' '.$paiement['Nif_13'];
                }

                //Comptes//La banque
                $aBanque = $this->stakeholdersModel->get_dropdown("beneficiaries","BKC");

                $banque = array_keys($aBanque["BKC"]);
                $banque = $banque[0];

                $comptes = $this->accountModel->get_comptes_array("'CPI', 'CPU', 'TVA', 'CFB', 'CCV'");
                $comptesExchange = $this->accountModel->get_comptes_by_type_array("'CCV','CPU'");
                ##################### Cas 1 ###########################################################
                //Paiment au comptant en CDF | Mode is ESPECE
                
                if($pMode=="5" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 2 ############################################
                //Paiment au comptant en USD | Mode is ESPECE
                elseif($pMode=="5" && $pDevise=="USD")
                {
                        $results = array();

                        //Operation 1: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }


                ##################### Cas 3 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en CDF
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 4 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="USD")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en USD
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 5 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="USD")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en CDF du montant paye
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pContrevaleur, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 3: debiter compte position en USD
                        if(isset($comptes[$banque]['CPU']['USD'])) 
                            $bCompte = $comptes[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 4: crediter compte contre valeur en CDF
                        if(isset($comptes[$banque]['CCV']['CDF'])) 
                            $bCompte = $comptes[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $pContrevaleur;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 5: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 6 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en USD du montant paye
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $tauxd = $taux['Dollar_4'];

                        $aMontant = $pMontant / $tauxd;
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$aMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;
                        //Operation 2: debiter compte contre-valeur en CDF
                        if(isset($comptes[$banque]['CCV']['CDF'])) 
                            $bCompte = $comptes[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 3: crediter compte position en USD
                        if(isset($comptes[$banque]['CPU']['USD'])) 
                            $bCompte = $comptes[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $aMontant;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 4: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['CPI']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['CPI']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;


                }
                //Generer les instructions
                if(!empty($results))
                {       /* Save datas in DB Integration*/
                        foreach($results as $instruction)
                        {
                                $elements = array_merge($instruction,$data);
                                $integrations[] = $elements;
                                $cid = $this->integrationModel->save_integrations($elements, NULL);
                        }

                }
                return $integrations;
        }
        
        
        
        public function get_sydonia_migrate_bl_lot($lotid)
        {
            $bl = $lotid;
            $amountDGDA = 0;
            $amountDGI = 0;
            $amountPRDGDA = 0;
            $amountDGRAD = 0;
            $amountSERVICES = array();
            $obj = $this->encaissementModel->get_paiement_info(NULL);

            $taxesDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "TRESOR", 100);
            $propresDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "PROPRES", 100);
            $taxesDGRAD = $this->logirefModel->get_dropdown("recettes", "DGRAD", "RFTRESD", 100);
            $taxesSERVICES = $this->logirefModel->get_dropdown("recettes", NULL, "RFPROPD", 100);
            $autreTaxes = 0;
            /* Get data from DB Integration*/
            $declaration = $this->integrationModel->get_paiement_sydonia($bl);
            $bulletin = $this->normalize_sydonia_result($declaration->Results_13 ?? null);
            $receiptId = $this->build_sydonia_receipt_id($bulletin);
            $taxes = $this->get_sydonia_taxes_paid($bulletin);
            /* Initialisation */
            $obj->Designation_14 = '';
            $obj->Nif_13 = $declaration->Nif_9;                        
            $obj->Beneficaire_15 = 'DGDA';
            $obj->Service_16 = $declaration->Office_6;
            $obj->Typerecette_17 = 'DDI';
            $obj->Mode_19= '';
            $obj->Agence_20 = $_SESSION['Logiref_agence'];
            $obj->Contrevaleur_22 = $bulletin->totalAmount ?? 0; // Tjrs en CDF
            $obj->Notetype_25= '3';
            $recieptDate = explode("/", (string) ($bulletin->receiptDate ?? ""));
            $obj->Noteid_26 = (count($recieptDate) === 3 ? $recieptDate[2].' ' : '').trim(($bulletin->receiptSerial ?? '').' '.($bulletin->receiptNumber ?? ''));
            $obj->Notedate_27= (count($recieptDate) === 3) ? $recieptDate[2]."-".$recieptDate[1]."-".$recieptDate[0] : '';
            $obj->Notemontant_28= $bulletin->totalAmount ?? 0;
            $obj->Account_28= $bulletin->Account_28;
            $obj->Notedevise_29= 'CDF';
            $obj->Datevaleur_31 = gmdate('Y-m-d');
            $obj->Reference_32 = 'Paiement BL/DGDA/'.$receiptId;
            /* Amount for DGDA */
            if (empty($taxes) && isset($bulletin->declarationsPaid) && is_iterable($bulletin->declarationsPaid)) {
                foreach($bulletin->declarationsPaid as $dec)
                {
                    if (isset($dec->taxesPaid) && is_object($dec->taxesPaid)) {
                        $taxes[] = $dec->taxesPaid;
                    }
                }
            }

            $total = 0;
            foreach( $taxes as $taxe)
            {
                foreach($taxe as $tax):
                    if(isset($taxesDGDA['DGDA'][$tax->taxeCode])) $amountDGDA = $amountDGDA + $tax->taxeAmount;
                    if(isset($taxesDGRAD['DGRAD'][$tax->taxeCode])) $amountDGRAD = $amountDGRAD + $tax->taxeAmount;
                    if(isset($taxesDGRAD['DGI'][$tax->taxeCode])) $amountDGI = $amountDGI + $tax->taxeAmount;
                    if(isset($propresDGDA['DGDA'][$tax->taxeCode])) $amountPRDGDA = $amountPRDGDA + $tax->taxeAmount;
                    if(!isset($taxesDGDA['DGDA'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) && !isset($taxesDGRAD['DGI'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) )$autreTaxes = $autreTaxes + $tax->taxeAmount;
                endforeach;
            }
            /* Autres Taxes Fond Propres */
            $services = array_keys($taxesSERVICES);
            foreach( $services as $service)
            {
                    foreach( $taxes as $taxe)
                    {
                        foreach($taxe as $tax):
                            if(isset($taxesSERVICES[$service][$tax->taxeCode]) && !isset($amountSERVICES[$service])) $amountSERVICES[$service] = 0;
                            if(isset($taxesSERVICES[$service][$tax->taxeCode])) $amountSERVICES[$service] = $amountSERVICES[$service] + $tax->taxeAmount; 
                        endforeach;
                    }
            }

            $allTaxes = array();
            foreach($taxes as $taxe)
            {
                foreach($taxe as $tax):
                    $oneTaxe = new stdClass();
                    if(key_exists($tax->taxeCode, $allTaxes))
                    {
                        $allTaxes[$tax->taxeCode]->taxeAmount += $tax->taxeAmount;
                    }
                    else
                    {
                        $oneTaxe->taxeCode = $tax->taxeCode;
                        $oneTaxe->taxeDescription =$tax->taxeDescription;
                        $oneTaxe->taxeAmount = $tax->taxeAmount;
                        $allTaxes[$tax->taxeCode] = $oneTaxe;
                    }
                endforeach;
            }

            //echo "Total2: ".$total; die;
            //Initialisation
            $obj->Devise_12 = 'CDF';
            $obj->Notereference_30 = array(
                                            'standard' => $declaration->Agent_10,
                                            'year' => $declaration->Year_5,
                                            'serie' => $bulletin->receiptNumber,
                                            'moyen' => $declaration->Type_4,
                                            'agence' => '',
                                            'serial' => $declaration->Serie_7,
                                            'bank' => $declaration->Bank_11,
                                            'amountDGDA'=>$amountDGDA,
                                            'amountDGI'=>$amountDGI,
                                            'amountPRDGDA' =>$amountPRDGDA,
                                            'amountDGRAD'=>$amountDGRAD,
                                            'amountSERVICES'=>$amountSERVICES,
                                            'quittance' => $declaration->Pdfcontent_18,
                                            'taxesPaid'=>$allTaxes,
                                            'Paiementid'=>$bl,
                                            'autresTaxes' => $autreTaxes,
                                            'number' => $declaration->Number_8 
                                        );
            $obj->Montant_11 = (isset($bulletin->totalAmount))? $bulletin->totalAmount : $declaration->Amount_12;
            return $obj; 
                       
        }
        
        public function get_first_comptabilisation_guichet_unique($data=NULL, $arg=NULL, $param=NULL)
        {
                # Verification comptabilisation($pid, $logirefid, $paiement
                # ($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                $integrations = array();
                $pid = $data;
                $logirefid = $arg;
                $paiement = $param;
                $data = array();
                if($pid!=NULL && $pid=="")
                {
                        echo '<div class="alert alert-danger text-white">Avertissement! paiement non comptabilis&eacute;..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        die;
                }
                else 
                {
                        //InitialisationContrevaleur_22
                        $pTypeRecette = (isset($paiement['Typerecette_17']))?$paiement['Typerecette_17']: '';
                        $institution = (isset($paiement['Beneficaire_15']))?$paiement['Beneficaire_15']: '';
                        $pMode=$paiement['Mode_19'];
                        $pMontant=$paiement['Montant_11'];
                        $pDevise=$paiement['Devise_12'];
                        $pContrevaleur=$paiement['Contrevaleur_22']; //Contre valeur du montant en CDF
                        $pCommission=$paiement['Commission_23']; //Commission 
                        $fDevise=$paiement['Devise_24']; //Devise de la commission
                        if(isset($paiement['Compte_33'])) $cCompte = $paiement['Compte_33']; else $cCompte=''; //Compte du client
                        if(isset($paiement['Devise_34'])) $cDevise = $paiement['Devise_34']; else $cDevise=''; //Devise du compte client
                        $taux = $paiement['Taux_41'];
                        $refclient = $paiement['Reference_32'];
                        //Variable d'integration
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Date_13']=$paiement['Datevaleur_31'];
                        $data['Reference_14']=$logirefid; //TBD
                        $data['Mode_15']=$pMode;
                        $data['Makerid_16']=$this->session->userdata['user_id'];
                        $libelle = 'DGDA '.$paiement['Typerecette_17'].' '.$paiement['Designation_14'].' '.$paiement['Nif_13'];
                }

                //Comptes//La banque
                $aBanque = $this->stakeholdersModel->get_dropdown("beneficiaries","BKC");

                $banque = array_keys($aBanque["BKC"]);
                $banque = $banque[0];
                $guichet = $_SESSION['Logiref_guichet'];
                $banksComptes = $this->accountModel->get_agence_comptes_array("'TVA','CCV','CPU','CFB'", $guichet);
                $comptes = $this->accountModel->get_agence_comptes_array("'GU'", $guichet);
                $comptesTaxes = $this->accountModel->get_recette_comptes_array("'CPI','CPT'", $guichet);
                ##################### Cas 1 ###########################################################
                //Paiment au comptant en CDF | Mode is ESPECE

                if($pMode=="5" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        
                        //Operation 2: crediter le compte commission de la banque en CDF
                        if(isset($banksComptes[$banque]['CFB'][$pDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$pDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        
                        //Operation 3: crediter le compte TVA de la banque en CDF
                        if(isset($banksComptes[$banque]['TVA'][$pDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][pfDevise];
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 2 ############################################
                //Paiment au comptant en USD | Mode is ESPECE
                elseif($pMode=="5" && $pDevise=="USD")
                {
                        $results = array();
                        //Operation 1: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        //Operation 2: crediter le compte commission de la banque en USD
                        
                        if(isset($banksComptes[$banque]['CFB'][$pDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$pDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                        //Operation 3: crediter le compte TVA de la banque en USD
                        if(isset($banksComptes[$banque]['TVA'][$pDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][$pDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                }


                ##################### Cas 3 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="CDF")
                {
                        $results = array();
                        $tMontant = $pMontant + $pCommission;
                        //Operation 1: debiter le compte du client en CDF
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        
                         //Operation 3: crediter le compte commission de la banque en CDF
                        if(isset($banksComptes[$banque]['CFB'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$fDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;
                        
                        //Operation 4: crediter le compte TVA de la banque en CDF
                        if(isset($banksComptes[$banque]['TVA'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][$fDevise];
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 4 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="USD")
                {
                        $results = array();
                        $tMontant = $pMontant + $pCommission;
                        //Operation 1: debiter le compte du client en USD
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 2: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        
                        //Operation 3: crediter le compte commission de la banque en USD
                        if(isset($banksComptes[$banque]['CFB'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$fDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;
                        
                        //Operation 4: crediter le compte TVA de la banque en USD
                        if(isset($banksComptes[$banque]['TVA'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][$fDevise];
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 5 ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en USD
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="CDF" && $pDevise=="USD")
                {
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $tauxd = $taux['Dollar_4'];
                        $results = array();
                        $tMontant = ($pCommission * $tauxd) + $pContrevaleur;
                        //Operation 1: debiter le compte du client en CDF du montant paye
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 2: debiter compte position en USD
                        if(isset($banksComptes[$banque]['CPU']['USD'])) 
                            $bCompte = $banksComptes[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>($pMontant + $pCommission), 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 3: crediter compte contre valeur en CDF
                        if(isset($banksComptes[$banque]['CCV']['CDF'])) 
                            $bCompte = $banksComptes[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $pContrevaleur;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 5: crediter le compte de passage du tresor du montant paye en USD
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['USD']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        
                        //Operation 6: crediter le compte commission de la banque en USD
                        if(isset($banksComptes[$banque]['CFB'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$fDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;
                        
                        //Operation 7: crediter le compte TVA de la banque en USD
                        if(isset($banksComptes[$banque]['TVA'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][$fDevise];
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;

                }

                ##################### Cas 6 ############################################
                //Ordre de paiement d'un compte client en USD d'une recette en CDF
                elseif(($pMode=="7" || $pMode=="8") && $cDevise=="USD" && $pDevise=="CDF")
                {
                        $results = array();

                        //Operation 1: debiter le compte du client en USD du montant paye
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $tauxd = $taux['Dollar_4'];

                        $aMontant = ($pMontant + $pCommission) / $tauxd;
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$cCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$aMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;
                        //Operation 2: debiter compte contre-valeur en CDF
                        if(isset($banksComptes[$banque]['CCV']['CDF'])) 
                            $bCompte = $banksComptes[$banque]['CCV']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>($pMontant + $pCommission), 'Devise_11'=>$pDevise);
                        $results[] = $instruction;

                        //Operation 3: crediter compte position en USD
                        if(isset($banksComptes[$banque]['CPU']['USD'])) 
                            $bCompte = $banksComptes[$banque]['CPU']['USD']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $tMontant = $aMontant + $pCommission;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$tMontant, 'Devise_11'=>$cDevise);
                        $results[] = $instruction;

                        //Operation 4: crediter le compte de passage du tresor du montant paye en CDF
                        if(isset($comptes[$paiement['Beneficaire_15']]['GU']['CDF']))
                            $bCompte = $comptes[$paiement['Beneficaire_15']]['GU']['CDF']; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                        $results[] = $instruction;
                        
                        //Operation 5: crediter le compte commission de la banque en USD
                        if(isset($banksComptes[$banque]['CFB'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['CFB'][$fDevise]; 
                        else 
                            $bCompte='00000000000000000000000';
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'Frais bancaire '.$refclient, 'Montant_10'=>$pCommission, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;
                        
                        //Operation 6: crediter le compte TVA de la banque en USD
                        if(isset($banksComptes[$banque]['TVA'][$fDevise])) 
                            $bCompte = $banksComptes[$banque]['TVA'][$fDevise];
                        else 
                            $bCompte='00000000000000000000000';
                        $tva = $pCommission * $this->tva;
                        $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>'TVA '.$libelle, 'Montant_10'=>$tva, 'Devise_11'=>$fDevise);
                        $results[] = $instruction;


                }
                //Generer les instructions
                if(!empty($results))
                {       /* Save datas in DB Integration*/
                        foreach($results as $instruction)
                        {
                                $elements = array_merge($instruction,$data);
                                $integrations[] = $elements;
                                $cid = $this->integrationModel->save_integrations($elements, NULL);
                        }

                }
                return $integrations;
        }
        
        public function get_second_comptabilisation_guichet_unique($data=NULL, $arg=NULL, $param=NULL)
        {
                # Verification comptabilisation($pid, $logirefid, $paiement
                # ($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                $integrations = array();
                $pid = $data;
                $logirefid = $arg;
                $paiement = $param;
                $data = array();
                if($pid!=NULL && $pid=="")
                {
                        echo '<div class="alert alert-danger text-white">Avertissement! paiement non comptabilis&eacute;..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        die;
                }
                else 
                {
                        //InitialisationContrevaleur_22
                        $pTypeRecette = (isset($paiement['Typerecette_17']))?$paiement['Typerecette_17']: '';
                        $institution = (isset($paiement['Beneficaire_15']))?$paiement['Beneficaire_15']: '';
                        $pMode=$paiement['Mode_19'];
                        $pMontant=$paiement['Montant_11'];
                        $pDevise=$paiement['Devise_12'];
                        $pContrevaleur=$paiement['Contrevaleur_22']; //Contre valeur du montant en CDF
                        $pCommission=$paiement['Commission_23']; //Commission 
                        $fDevise=$paiement['Devise_24']; //Devise de la commission
                        if(isset($paiement['Compte_33'])) $cCompte = $paiement['Compte_33']; else $cCompte=''; //Compte du client
                        if(isset($paiement['Devise_34'])) $cDevise = $paiement['Devise_34']; else $cDevise=''; //Devise du compte client
                        $taux = $paiement['Taux_41'];
                        $refclient = $paiement['Reference_32'];
                        //Variable d'integration
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6']=$paiement['Agence_20'];
                        $data['Guichet_7']=$paiement['Guichet_21'];
                        $data['Date_13']=$paiement['Datevaleur_31'];
                        $data['Reference_14']=$logirefid; //TBD
                        $data['Mode_15']=$pMode;
                        $data['Makerid_16']=$this->session->userdata['user_id'];
                        $beneficiaires = $this->logirefModel->get_dropdown("beneficiaires"); 
                        $titulaire = (isset($beneficiaires[$paiement['Beneficaire_15']]))?$beneficiaires[$paiement['Beneficaire_15']]:$paiement['Beneficaire_15'];
                        $libelle = 'DGDA '.$titulaire.' '.$paiement['Beneficaire_15'].' '.$paiement['Designation_14'].' '.$paiement['Nif_13'];;
                }

                //Comptes//La banque
                $aBanque = $this->stakeholdersModel->get_dropdown("beneficiaries","BKC");

                $banque = array_keys($aBanque["BKC"]);
                $banque = $banque[0];
                $guichet = $_SESSION['Logiref_guichet'];
                $comptes = $this->accountModel->get_agence_comptes_array("'GU'", $guichet);
                $comptesTaxes = $this->accountModel->get_recette_comptes_array("'CPI','CPT'", $guichet);
                

                
                ##################### Cas unique ############################################
                //Ordre de paiement d'un compte client en CDF d'une recette en CDF
                $results = array();

                //Operation 1: debiter le compte du guichet unique en CDF
                if(isset($comptes['DGDA']['GU']['CDF']))
                    $bCompte = $comptes['DGDA']['GU']['CDF']; 
                else 
                    $bCompte='00000000000000000000000';
                $instruction=array('Operation_8'=>'D', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>($pMontant + $pCommission), 'Devise_11'=>$pDevise);
                $results[] = $instruction;

                //Operation 2: crediter le compte du participant du montant paye en CDF
                if(isset($comptesTaxes[$paiement['Beneficaire_15']]['CPT']['CDF']))
                    $bCompte = $comptesTaxes[$paiement['Beneficaire_15']]['CPT']['CDF']; 
                else 
                    $bCompte='00000000000000000000000';
                $instruction=array('Operation_8'=>'C', 'Compte_9'=>$bCompte, 'Libelle_12'=>$libelle, 'Montant_10'=>$pMontant, 'Devise_11'=>$pDevise);
                $results[] = $instruction;

                //Generer les instructions
                if(!empty($results))
                {       /* Save datas in DB Integration*/
                        foreach($results as $instruction)
                        {
                                $elements = array_merge($instruction,$data);
                                $integrations[] = $elements;
                                $cid = $this->integrationModel->save_integrations($elements, NULL);
                        }

                }
                return $integrations;
        }
        
        public function get_bl_comptant($obj, $data = NULL, $parm = NULL)
        {
                $encaissement = $this->encaissementModel->get_paiement_info(NULL);
                if($obj =="blencaissement" && $data !=NULL)
                {
                        $declaration = new stdClass();
                        $declaration->Nif_9 = $data['Nif'];
                        $declaration->Office_6 = $data['Office'];
                        $declaration->Year_5 = $data['Year'];
                        $declaration->Serie_7 = $data['Series'];
                        $declaration->Number_8 = $data['Number'];
                        $declaration->Agent_10 = $data['Agent'];
                        $declaration->Bank_11 = $data['Bank'];
                        $declaration->Amount_12 = $data['Amount'];
                        $bl  = '';
                        $encaissement->Designation_14 = $data['Client'];
                }
                elseif($obj == "checkbl")
                {
                        $declaration = $data;
                        $bl = $parm;
                }
                
                $encaissement->Nif_13 = $declaration->Nif_9;
                $encaissement->Service_16 = $declaration->Office_6;
                $encaissement->Typerecette_17 = 'DDI';
                $encaissement->Mode_19= '10';
                $encaissement->Beneficaire_15 = 'DGDA';
                $encaissement->Notetype_25= '3';
                $encaissement->Notedevise_29= 'CDF';
                $encaissement->Notemontant_28 = $declaration->Amount_12;
                $encaissement->Montant_11 = $declaration->Amount_12;
                $encaissement->Devise_12 = 'CDF';
                $encaissement->Noteid_26 = $declaration->Year_5.''.$declaration->Serie_7.''.$declaration->Number_8;
                $encaissement->Notereference_30 = array(
                    'standard' => $declaration->Agent_10,
                    'quittance' => '',
                    'serie' => $declaration->Serie_7,
                    'number' => $declaration->Number_8,
                    'year' => $declaration->Year_5,
                    'bank' => $declaration->Bank_11,
                    'agence' => '',
                    'moyen' => '10',
                    'Paiementid'=> $bl,
                );
                $encaissement->Reference_32 = 'Paiement BL/DGDA/'.$declaration->Serie_7.''.$declaration->Number_8;
                return $encaissement;
        }
        
        public function sydonia_migrate_bl($data)
        { 
                $bl = $data;
                $amountDGDA = 0;
                $amountDGI = 0;
                $amountPRDGDA = 0;
                $amountDGRAD = 0;
                $amountSERVICES = array();
                $obj = $this->encaissementModel->get_paiement_info(NULL);
                
                $taxesDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "TRESOR", 100);
                $propresDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "PROPRES", 100);
                $taxesDGRAD = $this->logirefModel->get_dropdown("recettes", "DGRAD", "RFTRESD", 100);
                $taxesSERVICES = $this->logirefModel->get_dropdown("recettes", NULL, "RFPROPD", 100);
                $autreTaxes = 0;
                /* Get data from DB Integration*/
                $declaration = $this->integrationModel->get_paiement_sydonia($bl);

                $bulletin = $this->normalize_sydonia_result($declaration->Results_13 ?? null);
         
                $receiptId = $this->build_sydonia_receipt_id($bulletin);
                $taxes = $this->get_sydonia_taxes_paid($bulletin);
                $recieptDate = explode("/", (string) ($bulletin->receiptDate ?? ""));
                /* Initialisation */
                $obj->Makerid_9 = $declaration->User_15;
                $obj->Designation_14 = $declaration->Designation_23;
                $obj->Logirefid_4 = $declaration->Logirefid_34;
                $obj->Nif_13 = $declaration->Nif_9;                        
                $obj->Beneficaire_15 = 'DGDA';
                $obj->Service_16 = $declaration->Office_6;
                $obj->Typerecette_17 = $declaration->Serie_7.$declaration->Number_8;
                $obj->Mode_19= $declaration->Mode_30;
                $obj->Agence_20 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_22 = $bulletin->declarationsPaid->amountToBePaid ?? 0; // Tjrs en CDF
                $obj->Notetype_25= '3';
                $obj->Noteid_26 = $declaration->Serie_7.$declaration->Number_8;
                $obj->Notedate_27= $bulletin->DateLi ?? '';
                $obj->Notemontant_28= $bulletin->declarationsPaid->amountToBePaid ?? 0;
                $obj->Notedevise_29= 'CDF';
                $obj->Datevaleur_31 = gmdate('Y-m-d');
                //$obj->Reference_32 = 'Paiement BL/DGDA/'.$bulletin->receiptSerial.''.$bulletin->receiptNumber;
                $obj->Reference_32 = $declaration->Reference_19;
                $obj->CGU = $declaration->Account_24;
                $obj->Total = $declaration->Amount_25 + ($declaration->Commission_26 * 0.16);
                $obj->Commission_23 = $declaration->Commission_26;
                $obj->Devise_24 = $declaration->Devise_27;
                $obj->Compte_33 = $declaration->Account_28;
                $obj->Devise_34 = $declaration->Devise_29;
                /* Amount for DGDA */
                $total = 0;
                foreach( $taxes as $tax)
                {
                        if(isset($taxesDGDA['DGDA'][$tax->taxeCode])) $amountDGDA = $amountDGDA + $tax->taxeAmount;
                        if(isset($taxesDGRAD['DGRAD'][$tax->taxeCode])) $amountDGRAD = $amountDGRAD + $tax->taxeAmount;
                        if(isset($taxesDGRAD['DGI'][$tax->taxeCode])) $amountDGI = $amountDGI + $tax->taxeAmount;
                        if(isset($propresDGDA['DGDA'][$tax->taxeCode])) $amountPRDGDA = $amountPRDGDA + $tax->taxeAmount;
                        if(!isset($taxesDGDA['DGDA'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) && !isset($taxesDGRAD['DGI'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) )$autreTaxes = $autreTaxes + $tax->taxeAmount;
                }
                /* Autres Taxes Fond Propres */
                $services = array_keys($taxesSERVICES);
                foreach( $services as $service)
                {
                        foreach( $taxes as $tax)
                        {
                                if(isset($taxesSERVICES[$service][$tax->taxeCode]) && !isset($amountSERVICES[$service])) $amountSERVICES[$service] = 0;
                                if(isset($taxesSERVICES[$service][$tax->taxeCode])) $amountSERVICES[$service] = $amountSERVICES[$service] + $tax->taxeAmount; 
                        }
                }

                if (isset($_SESSION["userdata"]["account_id"]) && $_SESSION["userdata"]["account_id"] == 45):
                        $account = explode('-', $declaration->Account_24);
                        $branch_code = $account[0];
                endif;

                //echo "Total2: ".$total; die;
                //Initialisation
                $obj->Devise_12 = 'CDF';
                $obj->Taux_41 = $declaration->Taux_31;
                $obj->Sydonia_44 = $bl;
                $obj->Notereference_30 = array(
                                                'standard' => $declaration->Agent_10,
                                                'year' => $declaration->Year_5,
                                                'serie' => $declaration->Number_8,
                                                'moyen' => $declaration->Type_4,
                                                'agence' => '',
                                                'serial' => $declaration->Serie_7,
                                                'bank' => $declaration->Bank_11,
                                                'amountDGDA'=>$amountDGDA,
                                                'amountDGI'=>$amountDGI,
                                                'amountPRDGDA' =>$amountPRDGDA,
                                                'amountDGRAD'=>$amountDGRAD,
                                                'amountSERVICES'=>$amountSERVICES,
                                                'quittance' => $declaration->Pdfcontent_18,
                                                'quittanceid' =>  $receiptId,
                                                'taxesPaid'=> $taxes,
                                                'Paiementid'=>$bl,
                                                'autresTaxes' => $autreTaxes,
                                                'accountname' => $declaration->Accountholder_33,
                                                'Branch_code' => $branch_code  ?? "",
                                            );
                $obj->Montant_11 = $bulletin->totalAmount ?? $declaration->Amount_12;
                return $obj; 
                /*Get data from DB Integration*/
        }
        
        public function sydonia_migrate_prepayment($data)
        {
                 $bl = $data;
                $amountDGDA = 0;
                $amountDGI = 0;
                $amountPRDGDA = 0;
                $amountDGRAD = 0;
                $amountSERVICES = array();
                $obj = $this->encaissementModel->get_paiement_info(NULL);

                $taxesDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "TRESOR", 100);
                $propresDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "PROPRES", 100);
                $taxesDGRAD = $this->logirefModel->get_dropdown("recettes", "DGRAD", "RFTRESD", 100);
                $taxesSERVICES = $this->logirefModel->get_dropdown("recettes", NULL, "RFPROPD", 100);
                $autreTaxes = 0;
                /* Get data from DB Integration*/
                $declaration = $this->integrationModel->get_prepaiement_sydonia($bl);
                if ($declaration !== null && isset($declaration->Quittance_12)) 
                {
                    $quittance = json_decode($declaration->Quittance_12);
                }
                //$quittance = json_decode($declaration->Quittance_12);
                $recieptDate = explode("/",$declaration->DateL_11);
                /* Initialisation */
                $obj->Makerid_9 = $declaration->Creator_4;
                $obj->Designation_14 = $declaration->Designation_21;
                $obj->Nif_13 = $declaration->Nif_15;                        
                $obj->Beneficaire_15 = 'DGDA';
                $obj->Service_16 = $declaration->Office_8;
                $obj->Typerecette_17 = $recieptDate[2].$declaration->Serial_9.$declaration->Number_10;
                $obj->Mode_19= '7';
                $obj->Agence_20 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_22 = $declaration->Amount_18; // Tjrs en CDF
                $obj->Notetype_25= '3';
                $obj->Noteid_26 = $recieptDate[2].' '.$declaration->Serial_9.' '.$declaration->Number_10;
                $obj->Notedate_27= $recieptDate[2]."-".$recieptDate[1]."-".$recieptDate[0];
                $obj->Notemontant_28= $declaration->Amount_18;
                $obj->Notedevise_29= 'CDF';
                $obj->Datevaleur_31 = gmdate('Y-m-d');
                $obj->Reference_32 = 'Prepaiement BL/DGDA/'.$quittance->serQuit.''.$quittance->numQuit;
                $obj->CGU = $declaration->Account_22;
                $obj->Total = $declaration->Amount_26;
                $obj->Commission_23 = $declaration->Commission_24;
                $obj->Devise_24 = $declaration->Devise_25;
                $obj->Compte_33 = $declaration->Account_27;
                $obj->Devise_34 = $declaration->Devise_28;
                /* Amount for DGDA */
                $TaxesInfo = json_decode($declaration->TaxesInfo_17);

                $taxes = array();
                if(is_array($TaxesInfo) && count($TaxesInfo) > 1):
                    foreach($TaxesInfo as $taxe):
                        $taxInfo = new stdClass();
                        $taxInfo->taxeCode = $taxe->codTaxe;
                        $taxInfo->taxeAmount = $taxe->mntTaxe;
                        $taxInfo->taxeDescription = $taxe->libTaxe;
                        $taxes[] = $taxInfo;
                    endforeach;
                elseif(is_object($TaxesInfo) && $TaxesInfo !=""):
                        $taxInfo = new stdClass();
                        $taxInfo->taxeCode = $TaxesInfo->codTaxe;
                        $taxInfo->taxeAmount = $TaxesInfo->mntTaxe;
                        $taxInfo->taxeDescription = $TaxesInfo->libTaxe;
                        $taxes[] = $taxInfo;
                endif;
              
                $total = 0;
                foreach( $taxes as $tax)
                {
                        if(isset($taxesDGDA['DGDA'][$tax->taxeCode])) $amountDGDA = $amountDGDA + $tax->taxeAmount;
                        if(isset($taxesDGRAD['DGRAD'][$tax->taxeCode])) $amountDGRAD = $amountDGRAD + $tax->taxeAmount;
                        if(isset($taxesDGRAD['DGI'][$tax->taxeCode])) $amountDGI = $amountDGI + $tax->taxeAmount;
                        if(isset($propresDGDA['DGDA'][$tax->taxeCode])) $amountPRDGDA = $amountPRDGDA + $tax->taxeAmount;
                        if(!isset($taxesDGDA['DGDA'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) && !isset($taxesDGRAD['DGI'][$tax->taxeCode]) && !isset($propresDGDA['DGDA'][$tax->taxeCode]) )$autreTaxes = $autreTaxes + $tax->taxeAmount;
                }
                /* Autres Taxes Fond Propres */
                $services = array_keys($taxesSERVICES);
                foreach( $services as $service)
                {
                        foreach( $taxes as $tax)
                        {
                                if(isset($taxesSERVICES[$service][$tax->taxeCode]) && !isset($amountSERVICES[$service])) $amountSERVICES[$service] = 0;
                                if(isset($taxesSERVICES[$service][$tax->taxeCode])) $amountSERVICES[$service] = $amountSERVICES[$service] + $tax->taxeAmount; 
                        }
                }
                //echo "Total2: ".$total; die;
                //Initialisation
                $obj->Devise_12 = 'CDF';
                $obj->Taux_41 = $declaration->Taux_23;
                $obj->Sydonia_49 = $bl;
                $obj->Notereference_30 = array(
                                                'standard' => $declaration->Declarant_16,
                                                'year' => $recieptDate[0],
                                                'serie' => $declaration->Serial_9,
                                                'moyen' => 10,
                                                'agence' => '',
                                                'serial' => $declaration->Serial_9,
                                                'bank' => $declaration->CodeBank_13,
                                                'amountDGDA'=>$amountDGDA,
                                                'amountDGI'=>$amountDGI,
                                                'amountPRDGDA' =>$amountPRDGDA,
                                                'amountDGRAD'=>$amountDGRAD,
                                                'amountSERVICES'=>$amountSERVICES,
                                                'quittance' => '',
                                                'quittanceid' => $quittance->serQuit.$quittance->numQuit,
                                                'taxesPaid'=> $taxes,
                                                'Paiementid'=> $bl,
                                                'AccountRef'=>$declaration->AccountRef_14,
                                                'autresTaxes' =>$autreTaxes,
                                                'accountname'=> $declaration->Accountholder_29
                                            );
                $obj->Montant_11 =  $declaration->Amount_18;
                return $obj;
        }

        public function sydonia_migrate_other($data)
        {
                $bl = $data;
                $amountDGDA = 0;
                $amountDGI = 0;
                $amountPRDGDA = 0;
                $amountDGRAD = 0;
                $amountSERVICES = array();
                $obj = $this->encaissementModel->get_paiement_info(NULL);

                $taxesDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "TRESOR", 100);
                $propresDGDA = $this->logirefModel->get_dropdown("recettes", "DGDA", "PROPRES", 100);
                $taxesDGRAD = $this->logirefModel->get_dropdown("recettes", "DGRAD", "RFTRESD", 100);
                $taxesSERVICES = $this->logirefModel->get_dropdown("recettes", NULL, "RFPROPD", 100);
                $autreTaxes = 0;
                /* Get data from DB Integration*/
                $declaration = $this->integrationModel->get_paiement_sydonia($bl);

                $note = json_decode($declaration->Results_13);
                $recieptDate = explode("/",$note->receiptDate);
        }

        // public function logirad_migrate_note($data)
        // {
        //         $idnote = $data;
        //         $obj = $this->encaissementModel->get_paiement_info(NULL);
        //         $declaration = $this->integrationModel->get_paiement_logirad($idnote);
        //         $note = json_decode($declaration->Result_8);



        //         $noteDate = explode("-",$declaration->Dateordonance_13);
        //         $obj->Makerid_9 = $declaration->Creator_4;
        //         $obj->Montant_11 = $declaration->Montantdu_15;
        //         $obj->Devise_12 = $declaration->Devise_18;
        //         $obj->Designation_14 = $declaration->Requerant_11;
        //         $obj->Nif_13 = $declaration->Nif_22;
        //         $obj->Beneficaire_15 = 'DGRAD';
        //         $obj->Service_16 = $declaration->Service_19;
        //         $obj->Typerecette_17 = $declaration->Article_12;
        //         $obj->Agence_20 = $_SESSION['Logiref_agence'];
        //         $obj->Contrevaleur_22 = $declaration->Montantdu_15; // Tjrs en CDF
        //         $obj->Noteid_26 = $declaration->Reference_21;
        //         $obj->Notedate_27= $noteDate[2]."-".$noteDate[1]."-".$noteDate[0];
        //         $obj->Notemontant_28= $declaration->Solde_17;
        //         $obj->Notedevise_29= $declaration->Devise_18;

        //         $Notereference = array(
        //                         'standard' => $declaration->Article_12,
        //                         'totalDevise' => $declaration->Devise_18,
        //                         'accountname' => ''
        //                 );

        //         $obj->Notereference_30 = json_encode($Notereference);
        //         $obj->Datevaleur_31 = gmdate('Y-m-d');

        //         return $obj;
        // }

        public function logirad_migrate_note($data) {
                $idnote = $data;
                $obj = $this->encaissementModel->get_paiement_info(NULL);
                $declaration = $this->integrationModel->get_paiement_logirad($idnote);
                $note = json_decode($declaration->Result_8);
                $note_reference = json_decode($declaration->Notereference_24, true);

                $email = isset($note->logiradData->detailAssujetti->email) ? $note->logiradData->detailAssujetti->email : "";
                $phone = isset($note->logiradData->detailAssujetti->telephone) ? $note->logiradData->detailAssujetti->telephone : "";
				
                $noteDate = explode("-",$declaration->Dateordonance_13);
                $obj->Makerid_9 = $declaration->Creator_4;
                $obj->Montant_11 = $declaration->Montantdu_15;
                $obj->Devise_12 = $declaration->Devise_18;
                $obj->Designation_14 = $declaration->Requerant_11;
                $obj->Nif_13 = $declaration->Nif_22;                        
                $obj->Beneficaire_15 = 'DGRAD';
                $obj->Service_16 = $declaration->Service_19;
                $obj->Typerecette_17 = $declaration->Article_12;
                $obj->Agence_20 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_22 = $declaration->Montantdu_15; // Tjrs en CDF
                $obj->Noteid_26 = $declaration->Reference_21;  
                $obj->Notedate_27= $noteDate[2]."-".$noteDate[1]."-".$noteDate[0];
                $obj->Notemontant_28= ($declaration->Solde_17 == 0) ? $declaration->Montantdu_15 : $declaration->Solde_17;
                $obj->Notedevise_29= $declaration->Devise_18;
                $obj->Logirad_53= $idnote;
                
                $Notereference = array(
                        'standard' => $declaration->Article_12,
                        'totalDevise' => $declaration->Devise_18,
                        'accountname' => '',
                        'noteQuotas' => isset($note_reference['tresor_public']) ? $note_reference['tresor_public'] :'',
                        'QuotasTresor' => isset($note_reference['tresorPublic']) ? $note_reference['tresorPublic'] : '',
                        'QuotasComite' => isset($note_reference['comite'])?$note_reference['comite']:'',
                        'QuotasPrestataire' => isset($note_reference['prestataire'])?$note_reference['prestataire']:'',
                        'QuotasService' => isset($note_reference['service'])?$note_reference['service']:'',
                        'Email' => $email,
                        'Phone' => $phone
                );
                $obj->Notereference_30 = json_encode($Notereference);
                $obj->Datevaleur_31 = gmdate('Y-m-d');
                
                return $obj; 
        }

        public function logirad_migrate_note_passeport($data) {
                $idnote = $data;
                $obj = $this->encaissementModel->get_paiement_info(NULL);
                $declaration = $this->integrationModel->get_paiement_logirad_passeport($idnote);
                $note = json_decode($declaration->Result_8);
                $note_reference = json_decode($declaration->Notereference_23, true);

                $email = isset($note->logiradData->detailAssujetti->email) ? $note->logiradData->detailAssujetti->email : "";
                $phone = isset($note->logiradData->detailAssujetti->telephone) ? $note->logiradData->detailAssujetti->telephone : "";
				
                $noteDate = explode("-",$declaration->Dateordonance_13);
                $obj->Makerid_9 = $declaration->Creator_4;
                $obj->Montant_11 = $declaration->Montantdu_15;
                $obj->Devise_12 = $declaration->Devise_18;
                $obj->Designation_14 = $declaration->Requerant_11;
                $obj->Nif_13 = $declaration->Nif_22;                        
                $obj->Beneficaire_15 = 'DGRAD';
                $obj->Service_16 = $declaration->Service_19;
                $obj->Typerecette_17 = $declaration->Article_12;
                $obj->Agence_20 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_22 = $declaration->Montantdu_15; // Tjrs en CDF
                $obj->Noteid_26 = $declaration->Reference_21;  
                $obj->Notedate_27= $noteDate[2]."-".$noteDate[1]."-".$noteDate[0];
                $obj->Notemontant_28= ($declaration->Solde_17 == 0) ? $declaration->Montantdu_15 : $declaration->Solde_17;
                $obj->Notedevise_29= $declaration->Devise_18;
                $obj->Logirad_53= $idnote;
                
                $Notereference = array(
                        'standard' => $declaration->Article_12,
                        'totalDevise' => $declaration->Devise_18,
                        'accountname' => '',
                        'noteQuotas' => isset($note_reference['tresor_public']) ? $note_reference['tresor_public'] :'',
                        'QuotasTresor' => isset($note_reference['tresorPublic']) ? $note_reference['tresorPublic'] : '',
                        'QuotasComite' => isset($note_reference['comite'])?$note_reference['comite']:'',
                        'QuotasPrestataire' => isset($note_reference['prestataire'])?$note_reference['prestataire']:'',
                        'QuotasService' => isset($note_reference['service'])?$note_reference['service']:'',
                        'Email' => $email,
                        'Phone' => $phone
                );
                $obj->Notereference_30 = json_encode($Notereference);
                $obj->Datevaleur_31 = gmdate('Y-m-d');
                
                return $obj; 
        }

        public function dgidec_migrate_declaration($data)
        {
                $declaration_id = $data;
                $obj = $this->encaissementModel->get_paiement_info(NULL);
                $declaration = $this->integrationModel->get_paiement_dgidec($declaration_id);

                $dec_reference = json_decode($declaration->Notereference_16);

                if(isset($dec_reference->mois) && strlen($dec_reference->mois)==1)
                {
                        $date = $dec_reference->exercice."-"."0".$dec_reference->mois."-"."01";
                        $periode = "0".$dec_reference->mois."/".$dec_reference->exercice;
                }
                else
                {
                        $date = $dec_reference->exercice."-".$dec_reference->mois."-"."01";
                        $periode = $dec_reference->mois."/".$dec_reference->exercice;
                }

                $quota_inss = $dec_reference->MontantONEM ? $dec_reference->MontantONEM : 0;
                $quota_inpp = $dec_reference->MontantINSS ? $dec_reference->MontantINSS : 0;
                $quota_onem = $dec_reference->MontantINPP3 ? $dec_reference->MontantINPP3 : 0;

                if(isset($declaration->Recette_13) && $declaration->Recette_13 == 'IPRIER')
                {
                        $quota_dgi = $declaration->Montant_7;
                        $declaration->Montant_7 = $quota_dgi + $quota_inpp + $quota_onem + $quota_inss;
                }
                else
                {
                        $quota_dgi = 0;
                }

                $obj->Makerid_9 = $declaration->Creator_4;
                $obj->Montant_11 = $declaration->Montant_7;
                $obj->Devise_12 = $declaration->Devise_8;
                $obj->Designation_14 = $declaration->Designation_11;
                $obj->Nif_13 = $declaration->Nif_14;
                $obj->Beneficaire_15 = 'DGI';
                $obj->Mode_19 = '7';
                $obj->Service_16 = $declaration->Service_12;
                $obj->Typerecette_17 = $declaration->Recette_13;
                $obj->Agence_20 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_22 = $declaration->Montant_7; // Tjrs en CDF
                $obj->Noteid_26 = $declaration->Noteid_9; 
                $obj->Notedate_27= $declaration->Date_1;
                $obj->Notemontant_28= $declaration->Montant_7;
                $obj->Notedevise_29= $declaration->Devise_8;

                $Notereference = array(
                                    'standard' => $periode,
                                    'totalDevise' => 'CDF',
                                    'accountname' => '',
                                    'RefINSS' => '',
                                    'RefINPP' => '',
                                    'RefONEM' => '',
                                    'QuotasINSS' => $quota_inss,
                                    'QuotasINPP' => $quota_inpp,
                                    'QuotasONEM' => $quota_onem,
                                    'QuotasDGI' => $quota_dgi,
                                );

                $obj->Notereference_30 = json_encode($Notereference);
                $obj->Datevaleur_31 = gmdate('Y-m-d');

                return $obj;
        }

        public function array_to_obj($array)
        {
                $object= new stdClass();
                foreach ($array as $key => $value)
                {
                        $object->$key = $value;
                }
                return $object;
        }


        public function immatriculation_migrate_note($data)
        {
                $idnote = $data;
              
                $obj = $this->encaissementModel->get_paiement_info(NULL);
                $declaration = $this->integrationModel->get_integration_immatriculation($idnote);
    
                $note_percetion = json_decode($declaration->Notedata_25,true);
                $applicant = json_decode($declaration->Applicant_12,true);
                $beneficiaires=json_decode($declaration->Beneficiaries_13);
                
                // $noteDate = explode("-",$declaration->Dateordonance_13);
                $obj->Id_0 = isset($declaration->Id_0) ? $declaration->Id_0:"";
                $obj->Status_2 = $declaration->Status_2;
                $obj->Logirefid_4 = $declaration->Logirefid_31;
                $obj->Makerid_9 = $declaration->User_34;
                $obj->Checkerid_10 = $declaration->Checkerid_36;
                $obj->Montant_11 = $declaration->Amount_10;
                $obj->Devise_12 = $declaration->Devise_11;
                $obj->Designation_14 = $declaration->Requerant_9;
                $obj->Nif_13 = $declaration->Nif_8;
                $obj->Beneficaire_15 = 'DGI';
                $obj->Service_16 = $declaration->Servicetype_19;
                $obj->Typerecette_17 = $declaration->Typerecette_16;
                $obj->Artbudgetaire_18 = $declaration->Article_23;
                $obj->Mode_19=$declaration->Mode_17;
                $obj->Agence_20 = $_SESSION['Logiref_agence'];

                $obj->Contrevaleur_22 = null; // Tjrs en CDF
                $obj->Commission_23=$declaration->Commission_14;
                $obj->Devise_24=$declaration->Devise_15;
                $obj->Noteid_26 = $declaration->Reference_6;
                
                $date_note = date('Y-m-d',strtotime($note_percetion['date_emission']));

                $obj->Notedate_27= $date_note;
                $obj->Notemontant_28= $declaration->Amount_10;
                $obj->Notedevise_29= $declaration->Devise_11;
                
                $beneficiaries=[];
                
                foreach($beneficiaires as $beneficiary)
                {
                        $ben['beneficiary_code']=$beneficiary->BeneficiaryCode_16;
                        $ben['beneficiary_name']=$beneficiary->BeneficiaryName_17;
                        $ben['amount']=$beneficiary->Amount_10;
                        $ben['currency']=$beneficiary->Currency_11;
                        $beneficiaries[] = $ben;
                }

                $references['noteperception']=$note_percetion;
                $references['applicant']=$applicant;
                $references['beneficiaries']=$beneficiaries;
                
                $obj->Notereference_30 = json_encode($references,JSON_UNESCAPED_UNICODE);
                $obj->Datevaleur_31 = gmdate('Y-m-d');
                $obj->Reference_32=$declaration->Refop_18;
                $obj->Compte_33 = $declaration->Accountholder_26;
                $obj->Devise_34 = $declaration->Devise_27;

                return $obj;
        }
}
