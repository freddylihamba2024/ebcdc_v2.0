<?php

        namespace Modules\Branch\Models;

        use App\Models\MY_Transaction;
        use stdClass;

        class ReversementModel extends MY_Transaction {

                /* Presentation:
                * Last update
                * By Papin  on the 25.12.2020
                *  *************************************************************************************************************************SECTION 1
                */

                /*
                * Protected and public variables
                * Use: forms validation constraintes, dropdowns static array, contextual variable etc
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
                * *************************************************************************************************************************SCETION 2
                */
                protected $_table_name = '';
                protected $_primary_key = '';
                protected $_order_by = '';
                protected $_timestamps = FALSE;
                protected $_date_created = '';
                protected $_date_modified = '';
                
                
                public function __construct()
                {
                        parent::__construct();
                }
                
                /*
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
                * *************************************************************************************************************************SCETION 2
                */
                public function get_OBJE_info($oid=NULL)
                {
                        if($oid==NULL)
                        {
                                $obj = new stdClass();
                                $obj->Id_0='';
                                $obj->Date_1=gmdate('Y-m-d H:i:s');
                                $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                                $obj->Account_3='';
                                $obj->Creator_4='';
                                $obj->Changes_5='';
                                $obj->Changer_6='';
                        
                                #Add more here
                                return $obj;
                        }
                        else
                        {
                                $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }
                
                
                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
                *  *************************************************************************************************************************SECTION 3
                */
                public function get_dropdown($item)
                {
                        $account_id = $this->session->userdata['account_id'];
                        
                        if($item=="OBJECT NAME")
                        {
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('main_countries');
                                $ddmenu_country = array();
                                $ddmenu_country['0'] = ' ';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                                }
                                return $ddmenu_country;
                        }
                        
                        elseif($item=="OBJECT NAME")
                        {
                                $where ="(Account_3='".$account_id."' OR Account_3='0')";
                                $where ="Status_2 !='0'";
                                $this->db->where($where, NULL, FALSE); 
                                $this->db->order_by('NAME');
                                $query = $this->db->get('TABLE_NAME');
                                $ddmenu = array();
                                foreach ($query->result_array() as $row) {
                                        $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                                }
                                return $ddmenu;;
                        }
                }
                
                
                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * P.S: Ajoutez vous methodes ci-dessous!!
                *  *************************************************************************************************************************SECTION 4
                */
                
                public function get_paiements_to_reverse($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
                {
                        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                        
                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                        
                        #Filtre de recuperation
                        if(isset($_POST['paiements']) && $_POST['paiements'] !=""):
                        
                                $data1 = implode(",", $_POST['paiements']);
                                $st .= " AND Status_2 !='0' AND Id_0 IN (".$data1.") ";
                        endif;
                        
                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !=""):
                        
                                $data2 = implode(",", $_POST['bulletins']);
                                
                                if(!isset($_POST['paiements'])) $st .= " AND (Status_2 !='0' AND Sydonia_44 IN (".$data2.")) ";
                                
                                else $st .= " OR (Status_2 !='0' AND Sydonia_44 IN (".$data2.")) ";
                        endif;
                        
                        if(isset($_POST['prepayments']) && $_POST['prepayments'] !=""):
                                
                                $data2 = implode(",", $_POST['prepayments']);
                                
                                if(!isset($_POST['paiements']) && !isset($_POST['bulletins'])) $st .= " AND Sydonia_49 IN (".$data2.")";
                                
                                else $st .= " OR Sydonia_49 IN (".$data2.") ";
                                
                        endif;
                        
                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 4, 7, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        $query = $this->db->table('logiref_paiements_tresor')
                                        ->select('logiref_paiements_tresor.*')
                                        ->where($st)
                                        ->orderBy('Date_1', 'DESC')
                                        ->get();

                        return  $query->getResult();
                }

                public function get_paiements_passports_to_reverse($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
                {
                        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                        
                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
                        
                        #Filtre de recuperation
                        if(isset($_POST['paiements']) && $_POST['paiements'] !=""):
                        
                                $data1 = implode(",", $_POST['paiements']);
                                $st .= " AND Status_2 !='0' AND Id_0 IN (".$data1.") ";
                        endif;
                        
                        
                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 4, 7, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        $query = $this->db->table('logiref_paiements_tresor_passeport')
                                        ->select('logiref_paiements_tresor_passeport.*')
                                        ->where($st)
                                        ->orderBy('Date_1', 'DESC')
                                        ->get();

                        return  $query->getResult();
                }

                public function get_paiements_immatriculation_to_reverse($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
                {
                        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        #Filtre de recuperation
                        if(isset($_POST['paiements']) && $_POST['paiements'] !=""):

                                $data1 = implode(",", $_POST['paiements']);
                                $st .= " AND Status_2 !='0' AND Id_0 IN (".$data1.") ";
                        endif;

                #Restriction
                if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        $query = $this->db->table('logiref_paiements_tresor_immatriculation')
                                        ->select('logiref_paiements_tresor_immatriculation.*')
                                        ->where($st)
                                        ->orderBy('Date_1', 'DESC')
                                        ->get();

                return  $query->getResult();
        }

                public function get_paiements_passeports_to_reverse($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
                {
                        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        #Filtre de recuperation
                        if(isset($_POST['paiements']) && $_POST['paiements'] !=""):

                                $data1 = implode(",", $_POST['paiements']);
                                $st .= " AND Status_2 ='2' AND Checkerid_10 != '0' AND Id_0 IN (".$data1.") ";
                        endif;

                        #Restriction
                        if(in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 4, 7, 8], true)) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

                        $query = $this->db->table('logiref_paiements_tresor_passeport')
                                        ->select('logiref_paiements_tresor_passeport.*')
                                        ->where($st)
                                        ->orderBy('Date_1', 'DESC')
                                        ->get();

                        return  $query->getResult();
                }
        
        public function get_paiements_by_ids($ids)
        {
                if (empty($ids)) {
                        return [];
                }

                if (!is_array($ids)) {
                        $ids = [$ids];
                }

                $builder = $this->db->table('logiref_paiements_tresor_immatriculation')
                                ->select('logiref_paiements_tresor_immatriculation.*')
                                ->where('Account_3', $this->session->userdata['account_id'])
                                ->where('Status_2 !=', '0')
                                ->whereIn('Id_0', $ids);

                if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==4) {
                        $builder->where('Guichet_21', $_SESSION['Logiref_guichet']);
                }

                $query = $builder->orderBy('Date_1', 'DESC')->get();
                return $query->getResult();
        }

                /*
                * Save Information: insert or update an array
                * Use: inserting or updating
                * P.S: Ajoutez vous methodes ci-dessous!!
                *  *************************************************************************************************************************SECTION 5
                */

                public function update_payment_tresor($data, $ids) {
                        $return = $this->db->table('logiref_paiements_tresor')
                                ->whereIn('Id_0', $ids)
                                ->update($data);
                        return $return;
                }
        public function update_payment_tresor_immatriculation($data, $ids) {
                $return = $this->db->table('logiref_paiements_tresor_immatriculation')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                return $return;
        }
                public function update_payment_tresor_passeport($data, $ids) {
                        $return = $this->db->table('logiref_paiements_tresor_passeport')
                                ->whereIn('Id_0', $ids)
                                ->update($data);
                        return $return;
                }

        }
