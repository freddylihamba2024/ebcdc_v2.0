<?php

namespace Modules\Branch\Models;

use stdClass;
use App\Models\MY_Transaction;

class reportsModel extends MY_Transaction {
    private $reportingSentImmatriculationIds = [];

    /* Presentation: 
     * Last update
     * By Papin  on the 25.12.2020
     *  *************************************************************************************************************************SECTION 1
     */

    /*
     * Protected and public variables 
     * Use: forms validation constraintes, dropdowns static array, contextual variable etc
     * Get Information: return a single item
     * Use: for creation, for display, for updates
     * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
     * *************************************************************************************************************************SCETION 2
     */

    protected $_table_name = '';
    protected $_primary_key = '';
    protected $_order_by = '';
    protected $_timestamps = FALSE;
    protected $_date_created = '';
    protected $_date_modified = '';
    public $regies = array(
        '' => '',
        'DGI' => 'DGI',
        'DGRAD' => 'DGRAD'
    );

    public $status = [
            ''=>'',
            '1' => 'Initialis&eacute;',
            '2' => 'Valid&eacute & confirm&eacute;',
            '3' => 'Revers&eacute',
            '4' => 'Non reconnue',
            '5' => 'Regularisation',
            '6' => 'Non r&eacute;parti',
            '7' => 'Non confirm&eacute;'
    ];

    public $status_color = array(
            ''  => '',
            '1' => 'label-primary',
            '2' => 'label-success',
            '3' => 'label-warning',
            '4' => 'label-upcoming',
            '5' => 'label-danger',
            '6' => 'label-dark',
            '7' => 'label-info',
    );

    public function __construct() {
        parent::__construct();
    }

    protected function get_logiref_role(): int
    {
        return (int) ($_SESSION['Logiref_role'] ?? 0);
    }

    protected function restrict_to_current_guichet(): bool
    {
        return in_array($this->get_logiref_role(), [3, 4, 7], true);
    }

    protected function restrict_to_current_agence(): bool
    {
        $role = $this->get_logiref_role();
        return $role > 2 && $role !== 8;
    }

    protected function is_maker_role(): bool
    {
        return in_array($this->get_logiref_role(), [4, 7], true);
    }

    protected function is_global_validator(): bool
    {
        return in_array($this->get_logiref_role(), [2, 8], true);
    }

    /*
     * Get Information: return a single item
     * Use: for creation, for display, for updates
     * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
     * *************************************************************************************************************************SCETION 2
     */

    public function get_OBJE_info($oid = NULL) {
        if ($oid == NULL) {
            $obj = new stdClass();
            $obj->Id_0 = '';
            $obj->Date_1 = gmdate('Y-m-d H:i:s');
            $obj->Status_2 = ''; //0: Deleted, 1: In Progress, 2: Completed
            $obj->Account_3 = '';
            $obj->Creator_4 = '';
            $obj->Changes_5 = '';
            $obj->Changer_6 = '';

            #Add more here
            return $obj;
        } else {
            $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
            return $this->get_by(array('Id_0' => $oid), TRUE);
        }
    }

    /*
     * Get Information: returns an array
     * Use: for indexation, for dropdon etc
     * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
     *  *************************************************************************************************************************SECTION 3
     */

    public function get_dropdown($item) {
        $account_id = $this->session->userdata['account_id'];

        if ($item == "OBJECT NAME") {
            $this->db->order_by('Id_0');
            $query = $this->db->get('main_countries');
            $ddmenu_country = array();
            $ddmenu_country['0'] = ' ';
            foreach ($query->result_array() as $row) {
                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
            }
            return $ddmenu_country;
        } elseif ($item == "OBJECT NAME") {
            $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
            $where = "Status_2 !='0'";
            $this->db->where($where, NULL, FALSE);
            $this->db->order_by('NAME');
            $query = $this->db->get('TABLE_NAME');
            $ddmenu = array();
            foreach ($query->result_array() as $row) {
                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
            }
            return $ddmenu;
            ;
        }
    }

    /*
     * Get Information: returns an array
     * Use: for indexation, for dropdon etc
     * P.S: Ajoutez vous methodes ci-dessous!!
     *  *************************************************************************************************************************SECTION 4
     */

    public function get_validated_paiements($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
	{
        $date = gmdate('Y-m-d');
		$yesterday = gmdate('Y-m-d', strtotime('-1 day'));

        //$st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Sydonia_44=0 AND Sydonia_49=0 AND (Customercode_51 = '' OR Customercode_51 IS NULL) AND IsBatchflag_59!=1";
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Sydonia_44=0 AND Sydonia_49=0 AND (Customercode_51 = '' OR Customercode_51 IS NULL)";
        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= "  AND (Status_2=2 OR Status_2=3) AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
        if ($status == 'reversement_dgi')
            $st .= " AND (Status_2=2 OR Status_2=3) AND Beneficaire_15='DGI' ";
        if ($status == 'reversement_dgrad')
            $st .= " AND (Status_2=2 OR Status_2=3) AND Beneficaire_15='DGRAD'";
        if ($status == 'dailly')
            //$st .= " AND Date_1 LIKE '%" . $date . "%' ";
			$st .= " AND Status_2=2 AND (Date_1 LIKE '%" . $date . "%' OR Date_1 LIKE '%" . $yesterday . "%')";

        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17 ='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Date_1 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";



        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_validated_payments($status = NULL) 
    {
        $date = gmdate('Y-m-d');
        $yesterday = gmdate('Y-m-d', strtotime('-1 day'));
        
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' 
            AND Checkerid_10>'0' 
            AND Sydonia_44=0 
            AND Sydonia_49=0 
            AND (Customercode_51 = '' OR Customercode_51 IS NULL) 
            AND (IsBatchflag_59!=1 OR IsBatchflag_59 IS NULL)";
        
        # Restriction
        if ($this->restrict_to_current_guichet()) {
            $st .= " AND (Status_2=1 OR Status_2=3) 
                    AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
        }

        # PRIORITÉ : filtre personnalisé (date range)
        if (!empty($_POST['start']) && !empty($_POST['end'])) {
            $st .= " AND Date_1 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "'";
        } 
        # Sinon appliquer dailly
        elseif ($status == 'dailly') {
            $st .= " AND Status_2=1 
                    AND (Date_1 LIKE '%" . $date . "%' 
                    OR Date_1 LIKE '%" . $yesterday . "%')";
        }

        # Autres filtres
        if (!empty($_POST['user'])) {
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";
        }

        if (!empty($_POST['Typerecette_17'])) {
            $st .= " AND Typerecette_17 ='" . $_POST['Typerecette_17'] . "'";
        }

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_validated_paiements_immatriculation($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
	{
        $date = gmdate('Y-m-d');
		$yesterday = gmdate('Y-m-d', strtotime('-1 day'));
		
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44=0 AND Sydonia_49=0 AND (Customercode_51 = '' OR Customercode_51 IS NULL)";
        #Restriction
        if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4)
            $st .= " AND Status_2=2 AND  Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17 ='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Date_1 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

        $query = $this->db->table('logiref_paiements_tresor_immatriculation')
                ->select('logiref_paiements_tresor_immatriculation.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_isysextract_paiements($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $date = gmdate('Y-m-d');
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND (Status_2=3 AND Sydonia_44=0 AND Sydonia_49=0) OR (Status_2=3 AND Sydonia_44 !=0 AND Sydonia_49 !=0) AND (Customercode_51 = '' OR Customercode_51 IS NULL)";
    
        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();
        # var_dump($query->getResult());die;

        return $query->getResult();
    }
    public function filter_isysextract_paiements($data) {
        $user = $this->session->userdata['user_id'];
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Status_2=3  AND (Customercode_51 = '' OR Customercode_51 IS NULL)";
        
        #Filtre d'affichage
        if (isset($data['Regie']) && $data['Regie'] != '')
            $st .= " AND Beneficaire_15='" . $data['Regie'] . "'";
        if (isset($data['Office']) && $data['Office'] != '')
            $st .= " AND Service_16='" . $data['Office'] . "'";
        if (isset($data['Recette']) && $data['Recette'] != '')
            $st .= " AND Typerecette_17='" . $data['Recette'] . "'";
        if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
            $st .= " AND Datevaleur_31 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";
 
        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND (Customercode_51 = '' OR Customercode_51 IS NULL)";

        #Restriction
        if ($this->get_logiref_role() === 3)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND Tauxflag_58!='5' AND IsBatchflag_59=0";
        if ($this->get_logiref_role() === 4)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND IsBatchflag_59=0";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_batch() 
    {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=1 AND (Beneficaire_7='DGI' OR Beneficaire_7='DGRAD')";

        #Restriction
        if ($this->get_logiref_role() === 3)
            $st .= " AND Guichet_25='" . $_SESSION['Logiref_guichet'] . "' AND Tauxflag_28!='5'";
        if ($this->get_logiref_role() === 4)
            $st .= " AND Guichet_25='" . $_SESSION['Logiref_guichet'] . "'";


        $query = $this->db->table('logiref_paiements_tresor_batchs ')
                ->select('logiref_paiements_tresor_batchs .*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_validated_paiements_batch() 
    {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=2 AND (Beneficaire_7='DGI' OR Beneficaire_7='DGRAD')";

        #Restriction
        if ($this->get_logiref_role() === 3)
            $st .= " AND Guichet_25='" . $_SESSION['Logiref_guichet'] . "' AND Tauxflag_28!='5'";
        if ($this->get_logiref_role() === 4)
            $st .= " AND Guichet_25='" . $_SESSION['Logiref_guichet'] . "'";


        $query = $this->db->table('logiref_paiements_tresor_batchs ')
                ->select('logiref_paiements_tresor_batchs .*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_permis($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND (Paymentchannel_57 = '' OR Paymentchannel_57 IS NULL)";

        if ($this->get_logiref_role() === 4)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor_permis')
                ->select('logiref_paiements_tresor_permis.*')
                ->where($st)
                ->orderBy('Date_1', 'ASC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_immatriculation($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND  (Status_2=2 OR Status_2=7)";

        if ($_SESSION['Logiref_role'] == 4)
            $st .= " AND Guichet_32='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_integration_immatriculation')
                ->select('logiref_integration_immatriculation.*')
                ->where($st)
                ->orderBy('Date_1', 'ASC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_immatriculation_agence($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2=2 OR Status_2=7) AND Type_38 IS NULL";

        if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_32='" . $_SESSION['Logiref_guichet'] . "'";

        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND ValidateBySiop_39=0";

        $query = $this->db->table('logiref_integration_immatriculation')
                ->select('logiref_integration_immatriculation.*')
                ->where($st)
                ->orderBy('Date_1', 'ASC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_immatriculation_enligne($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2=2 OR Status_2=7) AND Type_38 IS NOT NULL";

        if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_32='" . $_SESSION['Logiref_guichet'] . "'";

        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND ValidateBySiop_39=0";

        $query = $this->db->table('logiref_integration_immatriculation')
                ->select('logiref_integration_immatriculation.*')
                ->where($st)
                ->orderBy('Date_1', 'ASC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_nvalidated_paiements_permis_online($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $user = $this->session->userdata['user_id'];

        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND Paymentchannel_57 IS NOT NULL";

        if ($this->get_logiref_role() === 4)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor_permis')
                ->select('logiref_paiements_tresor_permis.*')
                ->where($st)
                ->orderBy('Date_1', 'ASC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    // public function get_nvalidated_paiements($status = NULL, $param = NULL, $type = NULL, $arg = NULL)
    // {
    //     $user = $this->session->userdata['user_id'];
    //     $account_id = $this->session->userdata['account_id'];

    //     $st = "Account_3='{$account_id}'
    //         AND Checkerid_10='0'
    //         AND Status_2=1
    //         AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')
    //         AND Sydonia_44=0
    //         AND Sydonia_49=0
    //         AND (Customercode_51 = '' OR Customercode_51 IS NULL)";

    //     if ($_SESSION['Logiref_role'] == 2) {
    //         $st .= " AND Tauxflag_58='1'";
    //     }
    //     if ($_SESSION['Logiref_role'] == 3) {
    //         $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'
    //                 AND (Tauxflag_58='0' OR Tauxflag_58='2')";
    //     }
    //     if ($_SESSION['Logiref_role'] == 4) {
    //         $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
    //     }

    //     $columns_tresor = $this->db->getFieldNames('logiref_paiements_tresor');
    //     $columns_permis = $this->db->getFieldNames('logiref_paiements_tresor_permis');

    //     $common_columns = array_intersect($columns_tresor, $columns_permis);

    //     $columns_list = implode(',', $common_columns);

    //     $sql = "
    //         (SELECT {$columns_list} FROM logiref_paiements_tresor WHERE {$st})
    //         UNION ALL
    //         (SELECT {$columns_list} FROM logiref_paiements_tresor_permis WHERE {$st})
    //         ORDER BY Date_1 ASC
    //         LIMIT 500
    //     ";

    //     $query = $this->db->query($sql);
    //     return $query->getResult();
    // }

    public function filter_nvalidated_paiements($regie) {
        $user = $this->session->userdata['user_id'];

        $this->_table_name = '';
        #Query
        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
        $this->db->from('logiref_paiements_tresor');
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND Beneficaire_15='$regie' AND Sydonia_44=0 AND Sydonia_49=0 AND (Customercode_51 = '' OR Customercode_51 IS NULL)";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();
    }

    public function get_paiements_to_regulate($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_immatriculation_to_regulate($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 IN (5, 6)";

        #Restriction
        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_32='" . $_SESSION['Logiref_guichet'] . "'";
        if ($_SESSION['Logiref_role'] == 4)
            $st .= " AND Guichet_32='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_integration_immatriculation')
                ->select('logiref_integration_immatriculation.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_batchs_to_regulate()
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=5 AND (Beneficaire_7='DGI' OR Beneficaire_7='DGRAD') AND Guichet_25='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor_batchs')
                ->select('logiref_paiements_tresor_batchs.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_to_regularized_DGI($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_55=5 AND Beneficaire_15='DGI'";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_to_regularized_DGRAD($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_55=5 AND Beneficaire_15='DGRAD'";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_to_regularized_DGDA($status = NULL, $param = NULL, $type = NULL, $arg = NULL) {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_39=5";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Agence_32='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_integration_sydonia')
                ->select('logiref_integration_sydonia.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_tresor($type = NULL, $data = NULL) {

        $account_id = $this->session->userdata['account_id'];
        $user_id = $this->session->userdata['user_id'];

        $st = " Account_3='" . $account_id . "' AND Beneficaire_15 = 'DGI' AND  Checkerid_10 != 0 AND Sydonia_44 = 0 AND Sydonia_49 = 0 ";

        #Filtre d'affichage
        //if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17 ='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";

        #Restriction
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_tresor_dgrad($type = NULL, $data = NULL) {
        $account_id = $this->session->userdata['account_id'];
        $user_id = $this->session->userdata['user_id'];

        $st = " Account_3='" . $account_id . "' AND Beneficaire_15 = 'DGRAD' AND Sydonia_44 = 0 AND Sydonia_49 = 0 ";

        #Filtre d'affichage
        if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
            $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";

        #Restriction
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_taxegardiennage_dgrad() {
        $account_id = $this->session->userdata['account_id'];
        $user_id = $this->session->userdata['user_id'];

        $st = " Account_3='" . $account_id . "'AND  (Typerecette_17 = 27022470 || Typerecette_17 = 27022450)  AND Devise_12 = 'CDF' AND Checkerid_10 <> 0 ";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(200)
                ->get();
        #var_dump($query->getResult());die;

        return $query->getResult();
    }

    public function get_paiements_filter_taxegardiennage_dgrad($type = NULL, $data = NULL) {

        $agence = $this->session->userdata['Logiref_agence'];

        $st = " Agence_20='" . $agence . "' AND  (Typerecette_17 = 27022470 || Typerecette_17 = 27022450) AND Devise_12 = 'CDF' AND  Checkerid_10 <> 0";
        #Filtre d'affichage
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 = '" . $_POST['start'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";
        #Run

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(200)
                ->get();
        return $query->getResult();
    }

    public function get_paiements_passport_dgrad($type=null)
    {
            $agence = $_SESSION['Logiref_agence'];

            $st = '';

            if (isset($_POST['Status_2']) && $_POST['Status_2'] !='')
            {
                    if ($_POST['Status_2'] =='1') $st .= " Status_2='1' AND Checkerid_10 = 0";
                    if ($_POST['Status_2'] =='2') $st .= " Status_2='2'  AND Checkerid_10 <>  0";
                    if ($_POST['Status_2'] =='3') $st .= " (Status_2='3' AND Checkerid_10 <>  0)";
                    if ($_POST['Status_2'] =='4') $st .= " Status_2='4'";
                    if ($_POST['Status_2'] =='5') $st .= " Status_2='5'";
                    if ($_POST['Status_2'] =='6') $st .= " Status_2='6'";
                    if ($_POST['Status_2'] =='7') $st .= " Status_2='7'";
            }
            else
            {
                    $st .= " Status_2 !='0'";
            }

            $st .= " AND Typerecette_17 = '27421600'";

            #Restriction
            if($this->is_maker_role()) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
            if($_SESSION['Logiref_role'] == 3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";

            if(isset($_POST['start']) && $_POST['start']!='')
            {
                    $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
            }
            elseif(isset($_POST['start']) && $_POST['start']=='')
            {}
            else
            {
                    $st .= " AND Datevaleur_31 ='".gmdate('Y-m-d')."'";
            }

            if(isset($_POST['Noteid_26']) && $_POST['Noteid_26']!='') $st .= " AND Noteid_26 LIKE '%" . $_POST['Noteid_26'] . "%'";

            if($type=='mobile') $st.=" AND Type_57='mobile'";
            else $st.=" AND (Type_57 IS NULL OR Type_57='')";

            $query = $this->db->table('logiref_paiements_tresor_passeport')
                    ->select('logiref_paiements_tresor_passeport.*')
                    ->where($st)
                    ->orderBy('logiref_paiements_tresor_passeport.Id_0','DESC')
                    ->limit(1000)
                    ->get();

            return $query->getResult();
            
    }

    public function get_paiements_filter_passport_dgrad($type=NULL, $data=NULL)
    {
            $agence = $_SESSION['Logiref_agence'];

            $st = " Typerecette_17 = 27421600  AND  Checkerid_10 <> 0";

            if($type=='online')
            {
                $st.=" AND Type_57='mobile'";
            }
            else
            {
                $st.=" AND Type_57 IS NULL";
            }

            #Restriction
            if($this->is_maker_role()) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";
            if($_SESSION['Logiref_role'] == 3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";

            #Filtre d'affichage
            if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";

            #Run
            $query = $this->db->table('logiref_paiements_tresor_passeport')
                        ->select('logiref_paiements_tresor_passeport.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();

            return $query->getResult();
    }

    public function get_paiements_tresor_gu(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // BASE OBLIGATOIRE
        $st = "Account_3 = '{$accountId}'  AND Status_2 != 0 AND (Sydonia_44 != 0 OR Sydonia_49 != 0)";

        // FILTRES D'AFFICHAGE
        if (!empty($_POST['Regie'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Regie']}'";

        if (!empty($_POST['Office'])) 
            $st .= " AND Service_16 = '{$_POST['Office']}'";

        if (!empty($_POST['Recette']))
            $st .= " AND Typerecette_17 = '{$_POST['Recette']}'";

        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";


        // GESTION DES DATES (POINT CLÉ)
        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Date_1 AS DATE) = CURRENT_DATE";
    
        // RESTRICTION PAR RÔLE
        if ($restrictions && $this->restrict_to_current_guichet())
            $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";

        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }


    // public function get_paiements_tresor_gu(bool $restrictions = true)
    // {
    //     $accountId = $this->session->userdata['account_id'];

    //     // BASE OBLIGATOIRE
    //     $st = "Account_3 = '{$accountId}'  AND Status_2 != 0 AND (Sydonia_44 != 0 OR Sydonia_49 != 0)";

    //     // FILTRES D'AFFICHAGE
    //     if (!empty($_POST['Regie'])) 
    //         $st .= " AND Beneficaire_15 = '{$_POST['Regie']}'";

    //     if (!empty($_POST['Office'])) 
    //         $st .= " AND Service_16 = '{$_POST['Office']}'";

    //     if (!empty($_POST['Recette']))
    //         $st .= " AND Typerecette_17 = '{$_POST['Recette']}'";

    //     if (!empty($_POST['guichet']))
    //         $st .= " AND Guichet_21 = '{$_POST['guichet']}'";


    //     // GESTION DES DATES (POINT CLÉ)
    //     if (!empty($_POST['start']) && !empty($_POST['end']))
    //         $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
    //     else
    //         $st .= " AND CAST(Date_1 AS DATE) = CURRENT_DATE";
    
    //     // RESTRICTION PAR RÔLE
    //     if ($restrictions && $_SESSION['Logiref_role'] > 2)
    //         $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";

    //     return $this->db->table('logiref_paiements_tresor')
    //             ->select('*')
    //             ->where($st)
    //             ->orderBy('Id_0', 'DESC')
    //             ->get()
    //             ->getResult();
    // }

    public function filter_paiements_gu_propres($data) {
        $user = $this->session->userdata['user_id'];

        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

        #Filtre d'affichage
        if (isset($data['Regie']) && $data['Regie'] != '')
            $st .= " AND Beneficaire_15='" . $data['Regie'] . "'";
        if (isset($data['Office']) && $data['Office'] != '')
            $st .= " AND Service_16='" . $data['Office'] . "'";
        if (isset($data['Recette']) && $data['Recette'] != '')
            $st .= " AND Typerecette_17='" . $data['Recette'] . "'";
        if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

        #Restriction
        //if($_SESSION['Logiref_role']>2) $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21='".$guichet."' AND (Sydonia_44 != 0  || Sydonia_49 != 0) AND Status_2 != 0";


        $query = $this->db->table('logiref_paiements_propres')
                ->select('logiref_paiements_propres.*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_penalities_filter($type = NULL, $data = NULL) {
        $st = " Account_3='" . $this->session->userdata['account_id'] . "' ";
        #Filtre d'affichage
        if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
            $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Agence_20='" . $_POST['guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_propres_gu(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        $st = "Account_3 = '{$accountId}' AND Status_2 != 0 AND (Sydonia_44 != 0 OR Sydonia_49 != 0)";

        if (!empty($_POST['Regie'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Regie']}'";
        if (!empty($_POST['Office'])) 
            $st .= " AND Agence_20 = '{$_POST['Office']}'";
        if (!empty($_POST['Recette']))
            $st .= " AND Typerecette_17 = '{$_POST['Recette']}'";
        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";

        // GESTION DES DATES
        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if ($restrictions) 
        {
            if ($this->restrict_to_current_agence())
                $st .= " AND Agence_20 = '{$_SESSION['Logiref_agence']}'";
            if ($this->is_maker_role())
                $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        return $this->db->table('logiref_paiements_propres')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }

    public function get_paiements_propres($type = NULL, $data = NULL) {
        $user = $this->session->userdata['user_id'];
        #Query
        $this->db->select('logiref_paiements_propres.*', 'logiref_paiements_propres.Id_0 DESC');
        $this->db->from('logiref_paiements_propres');
        $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44 = '0' AND Sydonia_49 ='0' ";

        #Filtre d'affichage
        if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
            $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

        #Restriction
        if ($this->restrict_to_current_agence())
            $st .= " AND Agence_20='" . $_SESSION['Logiref_agence'] . "'";
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND Makerid_9 ='" . $user . "'";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();
    }

    public function get_fond_propres($type = NULL, $data = NULL) 
    {
        $user = $this->session->userdata['user_id'];
        $accountId = $this->session->userdata['account_id'];

        $st = "Account_3='{$accountId}' AND Beneficaire_15 != 'DGDA' AND Sydonia_44 != 0 AND Status_2 != 0";

        if (!empty($_POST['start']) && !empty($_POST['end'])) 
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";
        
        if (!empty($_POST['Beneficaire_15'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Beneficaire_15']}'";
        if (!empty($_POST['Typerecette_17'])) 
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";
        if ($this->restrict_to_current_agence()) 
            $st .= " AND Agence_20 = '{$_SESSION['Logiref_agence']}'";
        if ($this->is_maker_role()) 
            $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}' AND Makerid_9 = '{$user}'";

        return $this->db->table('logiref_paiements_propres')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();

    }

     public function get_fond_propres_immatriculation()
    {
         $user = $this->session->userdata['user_id'];
        $accountId = $this->session->userdata['account_id'];

        $st = "Account_3='{$accountId}'  AND Status_2 = 2";

        if (!empty($_POST['start']) && !empty($_POST['end'])) 
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Date_1 AS DATE) = CURRENT_DATE";
        
        if (!empty($_POST['Beneficaire_15'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Beneficaire_15']}'";
        if (!empty($_POST['Typerecette_17'])) 
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";
        if ($_SESSION['Logiref_role'] > 2) 
            $st .= " AND Agence_20 = '{$_SESSION['Logiref_agence']}'";
        if ($_SESSION['Logiref_role'] == 4) 
            $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";

        return $this->db->table('logiref_paiements_propres_immatriculation')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }


    public function get_fond_tresor($type = NULL, $data = NULL) {
        $user = $this->session->userdata['user_id'];
        $this->_table_name = '';
        #Query
        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
        $this->db->from('logiref_paiements_tresor');
        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

        #Filtre d'affichage
        if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
            $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";

        #Restriction
        if ($this->restrict_to_current_agence())
            $st .= " AND Agence_20='" . $_SESSION['Logiref_agence'] . "'";
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND Makerid_9 ='" . $user . "'";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();
    }

    public function get_report_paiements_dgi($type = NULL, $data = NULL) {

        //$st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' AND  Checkerid_10 != 0) AND (Sydonia_44 =0 || Sydonia_49 != 0) AND CAST(Date_1 as date)=CURRENT_DATE";
        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' AND  Checkerid_10 != 0) AND (Sydonia_44 =0 || Sydonia_49 != 0)";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get();

        return $query->getResult();
    }

    public function get_paiements_dgi(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition : paiements DGI validés
        $st = "Status_2 <> '0' AND Account_3 = '{$accountId}' AND Beneficaire_15 = 'DGI' AND Checkerid_10 <> 0";

        // Différenciation selon Sydonia
        // - get_report_paiements_dgi : (Sydonia_44 = 0 OR Sydonia_49 != 0)
        // - get_paiements_tresor     : Sydonia_44 = 0 AND Sydonia_49 = 0
        if (!empty($_POST['mode']) && $_POST['mode'] === 'report')
            $st .= " AND (Sydonia_44 = 0 OR Sydonia_49 != 0)";
        else 
            $st .= " AND Sydonia_44 = 0 AND Sydonia_49 = 0";

        // Filtres dynamiques
        if (!empty($_POST['Typerecette_17']))
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if (!empty($_POST['user']))
            $st .= " AND Makerid_9 = '{$_POST['user']}'";



        // Restrictions par rôle
        if ($restrictions) 
        {
            if (isset($_POST['guichet']) && $_POST['guichet'] != '')
                $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
            else
                if (in_array($this->get_logiref_role(), [3, 4, 7], true))
                    $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Datevaleur_31', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }
    
    public function get_paiements_dgi_immatriculation(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition : paiements DGI validés
        $st = "Status_2 <> 0 AND Account_3 = '{$accountId}' AND Beneficaire_15 = 'DGI'";

        // Filtres dynamiques
        if (!empty($_POST['Typerecette_17']))
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if (!empty($_POST['user']))
            $st .= " AND Makerid_9 = '{$_POST['user']}'";

        // Restrictions par rôle
        if ($restrictions) 
        {
            if (isset($_POST['guichet']) && $_POST['guichet'] != '')
                $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
            else
                if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 3)
                    $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_paiements_tresor_immatriculation')
                ->select('*')
                ->where($st)
                ->orderBy('Datevaleur_31', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }

    public function get_paiements_dgrad(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition : paiements DGI validés
        $st = "Status_2 <> 0 AND Account_3 = '{$accountId}' AND Beneficaire_15 = 'DGRAD' AND Checkerid_10 <> 0";

        // Différenciation selon Sydonia
        // - get_report_paiements_dgi : (Sydonia_44 = 0 OR Sydonia_49 != 0)
        // - get_paiements_tresor     : Sydonia_44 = 0 AND Sydonia_49 = 0
        if (!empty($_POST['mode']) && $_POST['mode'] === 'report')
            $st .= " AND (Sydonia_44 = 0 OR Sydonia_49 != 0)";
        else 
            $st .= " AND Sydonia_44 = 0 AND Sydonia_49 = 0";

        // Filtres dynamiques
        if (!empty($_POST['Typerecette_17']))
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if (!empty($_POST['user']))
            $st .= " AND Makerid_9 = '{$_POST['user']}'";

        // Restrictions par rôle
        if ($restrictions) 
        {
            if (isset($_POST['guichet']) && $_POST['guichet'] != '')
                $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
            else
                if (in_array($this->get_logiref_role(), [3, 4, 7], true))
                    $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Datevaleur_31', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }

    public function get_unvalidated_paiements_dgnk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
    {
            return $this->get_dgrk_paiements_by_status([1], false);
    }

    public function get_unvalidated_paiements_dgnk_online($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
    {
            return $this->get_dgrk_paiements_by_status([1], true);
    }


    public function get_unvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id = $this->session->userdata['account_id'];
		$builder = $this->db->table('logiref_paiements_propres')
                ->select('logiref_paiements_propres.*')
                ->where("logiref_paiements_propres.Account_3 ='".$account_id."' AND (Beneficaire_15 = 'DGRK' OR Beneficaire_15 = 'DGPEK') AND Checkerid_10='0' AND Status_2=1 ")
                ->orderBy('Id_0','ASC')
                ->get();

        return $builder->getResult();
	}

	public function get_validated_paiements_dgnk($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		return $this->get_dgrk_paiements_by_status([2, 3], false);
	}

    public function get_validated_paiements_dgnk_online($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
    {
            return $this->get_dgrk_paiements_by_status([2, 3], true);
    }

    private function get_dgrk_paiements_by_status(array $statuses, bool $online = false): array
    {
            $builder = $this->db->table('logiref_paiements_propres_dgrk')
                    ->where('Account_3', $this->session->userdata['account_id'])
                    ->whereIn('Status_2', $statuses);
            if (in_array((int) ($_SESSION['Logiref_role'] ?? 0), [3, 4], true)) {
                    $builder->where('Guichet_28', $_SESSION['Logiref_guichet'] ?? '');
            }
            if ($online) {
                    $builder->groupStart()
                            ->where('File_32 IS NOT NULL', null, false)->where('File_32 !=', '')
                            ->orGroupStart()->where('Customercode_31 IS NOT NULL', null, false)->where('Customercode_31 !=', '')
                            ->groupEnd()->groupEnd();
            } else {
                    $builder->groupStart()->where('File_32', null)->orWhere('File_32', '')->groupEnd()
                            ->groupStart()->where('Customercode_31', null)->orWhere('Customercode_31', '')->groupEnd();
            }
            return $builder->orderBy('Date_1', 'DESC')->limit(800)->get()->getResult();
    }

    public function get_paiements_dgnkreports($type = null): array
    {
            return $this->get_dgrk_paiements_by_status([2, 3]);
    }

    /** Paiements DGRK validés séparés entre agence et paiement en ligne. */
    public function get_paiements_dgrk_report(bool $online = false): array
    {
            return $this->get_dgrk_paiements_by_status([2, 3], $online);
    }

    /** Paiements DGRK en régularisation (Status_2 = 5). */
    public function get_paiements_dgrk_to_regulate(): array
    {
            return $this->get_dgrk_paiements_by_status([5], false);
    }

    public function get_dgrk_reversement_page(int $offset = 0, int $limit = 100): array
    {
            $rows = $this->db->table('logiref_paiements_propres_dgrk')
                    ->where('Account_3', $this->session->userdata['account_id'])
                    ->where('Status_2', 2)
                    ->orderBy('Date_1', 'DESC')->get()->getResult();
            return array_slice($rows, max(0, $offset), $limit);
    }

    public function get_dgrk_transferred_page(int $offset = 0, int $limit = 10): array
    {
            $rows = $this->db->table('logiref_paiements_propres_dgrk')
                    ->where('Account_3', $this->session->userdata['account_id'])
                    ->where('Status_2', 3)
                    ->orderBy('Date_1', 'DESC')->get()->getResult();
            return array_slice($rows, max(0, $offset), $limit);
    }

    public function get_dgrk_reversement_by_ids(array $ids): array
    {
            if (!$ids) return [];
            return $this->db->table('logiref_paiements_propres_dgrk')
                    ->where('Account_3', $this->session->userdata['account_id'])
                    ->where('Status_2', 2)->whereIn('Id_0', array_map('intval', $ids))
                    ->get()->getResult();
    }

    public function mark_dgrk_reversed(array $ids): bool
    {
            if (!$ids) return false;
            return (bool) $this->db->table('logiref_paiements_propres_dgrk')
                    ->where('Account_3', $this->session->userdata['account_id'])
                    ->where('Status_2', 2)->whereIn('Id_0', array_map('intval', $ids))
                    ->update(['Status_2' => 3]);
    }

    public function get_report_paiements_dgrad($type = NULL, $data = NULL)
    {
        //        //$st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGRAD') AND (Sydonia_44 =0 AND Sydonia_49 = 0) AND CAST(Date_1 as date)=CURRENT_DATE";

        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGRAD') AND (Sydonia_44 =0 AND Sydonia_49 = 0) ";


        #Filtre d'affichage
        if (isset($_POST['Recette']) && $_POST['Recette'] != '')
            $st .= " AND Typerecette_17='" . $_POST['Recette'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9='" . $_POST['user'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get();

        return $query->getResult();
    }

    public function get_commission_filter($data) {
        $this->_table_name = '';
        $user = $this->session->userdata['user_id'];
        #Query
        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
        $this->db->from('logiref_paiements_tresor');
        $st = " Account_3='" . $this->session->userdata['account_id'] . "' ";

        #Filtre d'affichage
        if (isset($data['guichet']) && $data['guichet'] != '')
            $st .= " AND Guichet_21='" . $data['guichet'] . "'";
        if (isset($data['start']) && $data['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();
    }

    ######################################################################
    ################## RBO methods #######################################
    ######################################################################

    public function get_validated_paiements_rbo($customer, $regie = NULL) 
    {
        $customer_code = $customer;

        $this->_table_name = '';
        #Query
        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Date_1 DESC');
        $this->db->from('logiref_paiements_tresor');
        #$st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0";
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2>'0' AND Beneficaire_15 = '" . $regie . "' AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51='" . $customer_code . "'";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();

        $role = $_SESSION['Logiref_role'];
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";

        if (!in_array((int) $role, [4, 7], true))
            $st .= "AND Status_2 = '2'";
        if (in_array((int) $role, [4, 7], true))
            $st .= "AND (Status_2 = '1' OR Status_2 = '2') AND Customercode_35 = '' ";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_current_nvalidated_paiements_rbo($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=6 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' ";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_current_unvalidated_rbo() 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=6 AND Customercode_35 !='' AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "' ";

        $query = $this->db->table('logiref_integration_sydonia')
                ->select('logiref_integration_sydonia.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_payments_rbo($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
        //$st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=6 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' ";
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=6 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND  Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' ";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }
    
    public function get_payments_nvalidated_rbo($user_id=NULL,$status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
            $role=$_SESSION['Logiref_role'];
            //$st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=6 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' ";
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND  Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' AND Status_55=2 ";

            if(!in_array((int) $role, [4, 7], true))
            {
                    $st .=" AND Status_2=6";
            }
            else
            {
                    $st .=" AND (Makerid_9 <> $user_id OR Status_2=6)";
            }

            $query = $this->db->table('logiref_paiements_tresor')
                    ->select('logiref_paiements_tresor.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            return $query->getResult();
    }
    
    public function get_encaissements_validated_rbo()
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=1 AND Checkerid_10 <> 0 AND Customercode_51 <> '' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') OR (Guichet_21='" . $_SESSION['Logiref_guichet'] . "') AND  Sydonia_44=0 AND Sydonia_49=0 ";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }
    
    public function get_validated_bls_rbo()
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=3 AND Customercode_35!=''";

        $query = $this->db->table('logiref_integration_sydonia')
                ->select('logiref_integration_sydonia.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }
    
    public function get_paiements_rbo() 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1' AND Status_39='2' AND Customercode_35!=''";

        $query = $this->db->table('logiref_integration_sydonia')
                ->select('logiref_integration_sydonia.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_batchs_rbo() 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1'  AND Status_31='2' AND Customercode_27!=''";

        $query = $this->db->table(' logiref_integration_sydonia_batchs')
                ->select('logiref_integration_sydonia_batchs.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }
    
    public function get_paiements_batchs() 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2 = '1' OR Status_2 = '2') AND (Customercode_27 = '' OR Customercode_27 IS NULL OR Customercode_27 = '') ";

        $query = $this->db->table(' logiref_integration_sydonia_batchs')
                ->select('logiref_integration_sydonia_batchs.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_current_bl_batch_treatments() 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2 = '4' OR Status_2 = '5') AND (Customercode_27 = '' OR Customercode_27 IS NULL OR Customercode_27 = '') ";

        $query = $this->db->table(' logiref_integration_sydonia_batchs')
                ->select('logiref_integration_sydonia_batchs.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_current_batch_verification_treatments()
    {
        $builder = $this->db->table('logiref_sydonia_bulletin_verifications');

        $builder->select('logiref_sydonia_bulletin_verifications.*');
        $builder->where('AccountId', $this->session->userdata['account_id']);
        $builder->groupStart()
                ->whereIn('Status_8', ['PENDING', 'PROCESSING'])
                ->orWhere('VerificationStatus_9', 'FINISHED')
                ->groupEnd();
        $builder->where('Status_8 !=', 'TREATED');

        if ($this->is_maker_role()) {
            $builder->where('UserId', $this->session->userdata['user_id']);
        }

        $builder->orderBy('CreatedAt_11', 'DESC');

        return $builder->get()->getResult();
    }

    public function get_paiements_rbo_rejected($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10 !='0' AND Status_2=9 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51 !='' ";

        #Restriction
        if ($this->restrict_to_current_guichet())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(500)
                ->get();

        return $query->getResult();
    }

    public function get_report_paiements_dgi_iprier($type = NULL, $data = NULL) {
        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI') AND (Typerecette_17 ='IPRIER') AND (Sydonia_44 =0 || Sydonia_49 != 0)";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get();

        return $query->getResult();
    }

    public function get_log_branchless_retrieves() {
        $agence = $_SESSION['Logiref_guichet'];
//                $this->_table_name = '';
//                $this->db->select('logiref_log_branchless_retrieves.*', 'logiref_log_branchless_retrieves.Id_0 ASC');
//                $this->db->from('logiref_log_branchless_retrieves');
        $st = "Status_2='0' AND Agence_14 = '" . $agence . "' ";
//                $this->db->where($st, NULL, FALSE);
//                $this->db->order_by('Id_0 DESC');
        $query = $this->db->table('logiref_log_branchless_retrieves')
                ->select('logiref_log_branchless_retrieves.*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_validated_paiements_passports_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
            $user = $this->session->userdata['user_id'];
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND (Status_2 = 2 OR Status_2 = 3) AND (Beneficaire_15='DGRAD') AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0";

            if($this->restrict_to_current_guichet()) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";

            #Run
            $query = $this->db->table('logiref_paiements_tresor_passeport')
                    ->select('logiref_paiements_tresor_passeport.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(2000)
                    ->get();

            return $query->getResult();
	}

    public function get_validated_paiements_passports($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
            $user = $this->session->userdata['user_id'];
            $agence = $_SESSION['Logiref_agence'];
            $guichet = $_SESSION['Logiref_guichet'];

            # Get the name of the current day
            $today_date = date('Y-m-d');
            $day_of_week = date('l', strtotime($today_date));

            if ($agence == '1' && $guichet == '62')
            {
                    #Query
                    $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Status_2=2 AND Beneficaire_15='DGRAD' AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0";

                    #Restriction
                    // if($_SESSION['Logiref_role']==3) $st .= " AND Agence_20='".$_SESSION['Logiref_agence']."'";
                    // if($_SESSION['Logiref_role']==4) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."' AND Makerid_9 ='".$user."'";

                    #Run
                    $query = $this->db->table('logiref_paiements_tresor_passeport')
                                ->select('logiref_paiements_tresor_passeport.*')
                                ->where($st);

                    if ($day_of_week === 'Monday')
                    {
                            $query->where('Date_1 >=', date('Y-m-d', strtotime('-3 days')));
                    }
                    else
                    {
                            $query->where('Date_1 >=', date('Y-m-d', strtotime('-1 days')));
                    }

                    $result = $query->orderBy('Date_1','DESC')
                            ->limit(1000)
                            ->get();

                    return $result->getResult();
            }
            
	}

    public function get_nvalidated_paiements_passports($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
            $user = $this->session->userdata['user_id'];

            #Query
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGRAD') AND Typerecette_17 = '27421600' AND Sydonia_44=0 AND Sydonia_49=0 AND (Type_57 IS NULL OR Type_57='')";
      
            #Restriction
            if($this->restrict_to_current_guichet()) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

            #Run
            $query = $this->db->table('logiref_paiements_tresor_passeport')
                    ->select('logiref_paiements_tresor_passeport.*')
                    ->where($st)
                    ->orderBy('Date_1','DESC')
                    ->limit(2000)
                    ->get();

            return $query->getResult();
	}

    public function get_paiements_passports_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
    {
            $user = $this->session->userdata['user_id'];

            #Query
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2=4 OR Status_2=5 OR Status_2=6 OR Status_2=7) AND Beneficaire_15='DGRAD'";

            #Restriction
            if($this->restrict_to_current_guichet()) $st .= " AND Guichet_21='".$_SESSION['Logiref_guichet']."'";

            #Run
            $query = $this->db->table('logiref_paiements_tresor_passeport')
                        ->select('logiref_paiements_tresor_passeport.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();

            return $query->getResult();
    }

    /*
     * Save Information: insert or update an array
     * Use: inserting or updating
     * P.S: Ajoutez vous methodes ci-dessous!!
     *  *************************************************************************************************************************SECTION 5
     */

    public function save_objects_name($data, $id) {
        $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
        return $this->saveData($data, $id);
    }


    private function hydrate_reporting_immatriculation_credit_accounts($rows)
    {
        if (empty($rows)) {
            return $rows;
        }

        $immatriculationIds = [];

        foreach ($rows as $row) {
            if (!empty($row->Immatriculationid_10)) {
                $immatriculationIds[] = $row->Immatriculationid_10;
            }
        }

        $immatriculationIds = array_values(array_unique($immatriculationIds));

        if (empty($immatriculationIds)) {
            return $rows;
        }

        $instructions = $this->db->table('logiref_cbs_instructions_immatriculation')
                ->select('Id_0, Paiementid_4, Compte_13, Montant_10, Devise_11')
                ->whereIn('Paiementid_4', $immatriculationIds)
                ->orderBy('Paiementid_4', 'ASC')
                ->orderBy('Id_0', 'ASC')
                ->get()
                ->getResult();

        $instructionsByPaiement = [];

        foreach ($instructions as $instruction) {
            $instructionsByPaiement[$instruction->Paiementid_4][] = $instruction;
        }

        foreach ($rows as $row) {
            $beneficiary = isset($row->Beneficiaire_4) ? strtoupper(trim($row->Beneficiaire_4)) : '';
            $useRank = in_array($beneficiary, ['DGI PROPRE', 'COMITE']);
            $rank = ($useRank && isset($row->Paymentrank_17)) ? (int) $row->Paymentrank_17 : 1;
            $rank = $rank > 0 ? $rank : 1;
            $candidates = $this->get_reporting_immatriculation_instruction_candidates(
                    isset($instructionsByPaiement[$row->Immatriculationid_10]) ? $instructionsByPaiement[$row->Immatriculationid_10] : [],
                    $row->Expectedcredit_16
            );

            if (isset($candidates[$rank - 1])) {
                $instruction = $candidates[$rank - 1];
                $row->Comptecredite_5 = $instruction->Compte_13;
                $row->Montantcredite_6 = $instruction->Montant_10;
                $row->Devisecredit_15 = $instruction->Devise_11;
            }
        }

        return $rows;
    }


    private function hydrate_reporting_immatriculation_payment_ranks($source, $rows)
    {
        if (empty($rows)) {
            return $rows;
        }

        $config = $this->get_reporting_immatriculation_config($source);
        $immatriculationIds = [];

        foreach ($rows as $row) {
            if (!empty($row->Immatriculationid_10)) {
                $immatriculationIds[] = (int) $row->Immatriculationid_10;
            }
        }

        $immatriculationIds = array_values(array_unique($immatriculationIds));

        if (empty($immatriculationIds)) {
            return $rows;
        }

        $rankPayments = $this->db->table($config['paiement_table'])
                ->select(
                        'Id_0, ' . $config['immatriculation_field']
                        . ', Montant_11, Devise_34, Taux_41'
                )
                ->whereIn($config['immatriculation_field'], $immatriculationIds)
                ->whereIn('Beneficaire_15', ['DGI PROPRE', 'COMITE'])
                ->orderBy($config['immatriculation_field'], 'ASC')
                ->orderBy('Id_0', 'ASC')
                ->get()
                ->getResult();

        $counters = [];
        $ranksByPaymentId = [];

        foreach ($rankPayments as $payment) {
            $amount = ($payment->Devise_34 === 'CDF')
                    ? (float) $payment->Montant_11 * (float) $payment->Taux_41
                    : (float) $payment->Montant_11;
            $rankKey = $payment->{$config['immatriculation_field']} . '|' . number_format(round($amount, 2), 2, '.', '');
            $counters[$rankKey] = isset($counters[$rankKey]) ? $counters[$rankKey] + 1 : 1;
            $ranksByPaymentId[(int) $payment->Id_0] = $counters[$rankKey];
        }

        foreach ($rows as $row) {
            $paymentId = isset($row->Paiementid_11) ? (int) $row->Paiementid_11 : 0;
            $row->Paymentrank_17 = isset($ranksByPaymentId[$paymentId])
                    ? $ranksByPaymentId[$paymentId]
                    : 0;
        }

        return $rows;
    }


    private function get_reporting_dgda_filter_value($data, $keys, $default = '')
    {
        foreach ($keys as $key) {
            if (isset($data[$key]) && $data[$key] !== '') {
                return $data[$key];
            }
        }

        return $default;
    }


    private function get_reporting_sent_immatriculation_ids($accountId)
    {
        if (isset($this->reportingSentImmatriculationIds[$accountId])) {
            return $this->reportingSentImmatriculationIds[$accountId];
        }
        $files = $this->db->table('logiref_integration_sftp_immatriculation')
                ->select('Noteids_14')->where('Account_3', $accountId)->where('Status_2', 2)
                ->get()->getResult();
        $ids = [];
        foreach ($files as $file) {
            $notes = json_decode($file->Noteids_14 ?? '', true);
            if (is_string($notes)) {
                $notes = json_decode($notes, true);
            }
            if (!is_array($notes)) {
                continue;
            }
            foreach ($notes as $id) {
                if ((is_int($id) || is_string($id)) && ctype_digit((string) $id) && (int) $id > 0) {
                    $ids[(int) $id] = (int) $id;
                }
            }
        }
        return $this->reportingSentImmatriculationIds[$accountId] = array_values($ids);
    }


    private function get_reporting_immatriculation_instruction_candidates($instructions, $expectedAmount)
    {
        $candidates = [];
        $expectedAmount = round((float) $expectedAmount, 2);

        foreach ($instructions as $instruction) {
            if (abs(round((float) $instruction->Montant_10, 2) - $expectedAmount) <= 0.011) {
                $candidates[] = $instruction;
            }
        }

        return $candidates;
    }


    public function get_reporting_immatriculation_integrated_payments($data, $offset = 0, $limit = 100, $search = '', $orderColumn = 0, $orderDir = 'DESC')
    {
        $builder = $this->db->table('logiref_integration_immatriculation i');
        $amount = "COALESCE(NULLIF(i.Totalamount_28, ''), i.Amount_10, 0)";
        $currency = "COALESCE(NULLIF(i.Devise_29, ''), i.Devise_11)";
        $builder->where('i.Account_3', $this->session->userdata['account_id']);
        $builder->where('i.Date_1 >=', $data['filter_start'] . ' 00:00:00');
        $builder->where('i.Date_1 <=', $data['filter_end'] . ' 23:59:59');
        if (!empty($data['Agence'])) {
            $builder->where('i.Guichet_32', $data['Agence']);
        }
        if (($data['siop_report'] ?? 'sent') === 'pending') {
            $statuses = ['1' => [1], '2' => [2], 'regularization' => [5, 6], '7' => [7]];
            $status = (string) ($data['payment_status'] ?? '');
            if (isset($statuses[$status])) {
                $builder->whereIn('i.Status_2', $statuses[$status]);
            } elseif ($status !== '') {
                // Un filtre inconnu ne doit pas retourner tous les paiements.
                return ['recordsTotal' => 0, 'recordsFiltered' => 0, 'rows' => []];
            }
        }
        // Réduire d'abord aux paiements de la période. La sous-requête JSON
        // corrélée relisait tous les fichiers pour chaque paiement/comptage.
        $candidateBuilder = clone $builder;
        $candidateBuilder->select('i.Id_0');
        $candidateIds = array_column($candidateBuilder->get()->getResultArray(), 'Id_0');
        $sentIds = empty($candidateIds) ? [] : $this->get_reporting_sent_immatriculation_ids($this->session->userdata['account_id']);
        $pending = ($data['siop_report'] ?? 'sent') === 'pending';
        $paymentIds = array_values($pending ? array_diff($candidateIds, $sentIds) : array_intersect($candidateIds, $sentIds));
        if (empty($paymentIds)) {
            return ['recordsTotal' => 0, 'recordsFiltered' => 0, 'rows' => []];
        }
        $builder->whereIn('i.Id_0', $paymentIds);
        $builder->select('i.Id_0, i.Date_1, i.Status_2, i.Reference_6, i.Nif_8, i.Requerant_9, i.Logirefid_31, i.Guichet_32');
        $builder->select($amount . ' AS Montant, ' . $currency . ' AS Devise', false);
        $totalBuilder = clone $builder;
        $total = $totalBuilder->countAllResults();
        if ($search !== '') {
            $builder->groupStart()
                    ->like('i.Reference_6', $search)
                    ->orLike('i.Nif_8', $search)
                    ->orLike('i.Requerant_9', $search)
                    ->orLike('i.Logirefid_31', $search)
                    ->groupEnd();
        }
        $filteredBuilder = clone $builder;
        $filtered = $search === '' ? $total : $filteredBuilder->countAllResults();
        $columns = ['i.Date_1', 'i.Reference_6', 'i.Nif_8', 'i.Requerant_9', 'Montant', 'Devise', 'i.Logirefid_31', 'i.Guichet_32', 'i.Id_0'];
        $builder->orderBy($columns[(int) $orderColumn] ?? 'i.Date_1', strtoupper($orderDir) === 'ASC' ? 'ASC' : 'DESC');
        $builder->orderBy('i.Id_0', 'DESC');
        return [
            'recordsTotal' => $total,
            'recordsFiltered' => $filtered,
            'rows' => $builder->limit(max(1, (int) $limit), max(0, (int) $offset))->get()->getResult(),
        ];
    }


    private function get_reporting_immatriculation_amount_expression($alias)
    {
        return "CASE WHEN " . $alias . ".Devise_34 = 'CDF' THEN COALESCE(" . $alias . ".Montant_11, 0) * COALESCE(" . $alias . ".Taux_41, 0) ELSE COALESCE(" . $alias . ".Montant_11, 0) END";
    }


    private function get_reporting_immatriculation_config($source = 'tresor')
    {
        if ($source == 'propre') {
            return [
                'paiement_table' => 'logiref_paiements_propres_immatriculation',
                'immatriculation_field' => 'Immatriculation_52',
            ];
        }

        return [
            'paiement_table' => 'logiref_paiements_tresor_immatriculation',
            'immatriculation_field' => 'Immatriculation_57',
        ];
    }


    private function get_reporting_immatriculation_builder($source = 'tresor', $data = null, $search = '', $withSelect = false)
    {
        $config = $this->get_reporting_immatriculation_config($source);
        $data = is_array($data) ? $data : [];
        $start = $this->get_reporting_dgda_filter_value($data, ['filter_start', 'period_start', 'start_date', 'start'], date('Y-m-d', strtotime('-1 day')));
        $end = $this->get_reporting_dgda_filter_value($data, ['filter_end', 'period_end', 'end_date', 'end'], date('Y-m-d'));
        $agence = $this->get_reporting_dgda_filter_value($data, ['Agence']);
        $amountExpression = $this->get_reporting_immatriculation_amount_expression('p');
        $siopReport = $data['siop_report'] ?? '';
        $integrationStatus = $siopReport === 'sent' ? "'Fichier SIOP envoyé'"
                : ($siopReport === 'pending' ? "'Séquestre crédité — SIOP non envoyé'" : "CASE
                    WHEN i.Status_2 = 3 THEN 'Intégré'
                    WHEN i.Status_2 = 6 THEN 'En régularisation - débit principal réussi'
                    ELSE 'Non intégré'
                END");

        $builder = $this->db->table($config['paiement_table'] . ' p');

        if ($withSelect) {
            $builder->select("
                p.Date_1 AS Date_1,
                'Agence' AS TypeTransmission_2,
                COALESCE(p.Notemontant_28, 0) AS Notemontant_3,
                p.Beneficaire_15 AS Beneficiaire_4,
                '' AS Comptecredite_5,
                0 AS Montantcredite_6,
                COALESCE(p.Taux_41, 0) AS Taux_7,
                p.Typerecette_17 AS Taxe_8,
                p.Agence_20 AS Agence_9,
                i.Id_0 AS Immatriculationid_10,
                p.Id_0 AS Paiementid_11,
                p.Noteid_26 AS Noteid_12,
                p.Notedevise_29 AS Notedevise_13,
                COALESCE(p.Montant_11, 0) AS Montantdollars_14,
                p.Devise_34 AS Devisecredit_15,
                ROUND(" . $amountExpression . ", 2) AS Expectedcredit_16,
                i.Guichet_32 AS Agencebancaire_18,
                " . $integrationStatus . " AS Integrationstatus_19,
                0 AS Paymentrank_17
            ");
        } else {
            $builder->select('COUNT(*) AS aggregate_count', false);
        }

        $builder->join('logiref_integration_immatriculation i', 'i.Id_0 = p.' . $config['immatriculation_field'], 'inner');
        if (in_array($siopReport, ['sent', 'pending'], true)) {
            $this->apply_reporting_immatriculation_siop_filter($builder, $siopReport);
        } else {
            $builder->whereIn('i.Status_2', [3, 6]);
        }
        $builder->where('p.' . $config['immatriculation_field'] . ' IS NOT NULL');
        $builder->where('p.' . $config['immatriculation_field'] . " != ''");
        $builder->where('p.' . $config['immatriculation_field'] . " != '0'");
        if ($siopReport === '') {
            $builder->where(
                    'EXISTS (SELECT 1 FROM logiref_cbs_instructions_immatriculation ci'
                    . ' WHERE ci.Paiementid_4 = CAST(i.Id_0 AS CHAR))',
                    null,
                    false
            );
        }
        $builder->where('p.Date_1 >=', $start . ' 00:00:00');
        $builder->where('p.Date_1 <=', $end . ' 23:59:59');

        if ($agence != '') {
            $builder->where('p.Agence_20', $agence);
        }

        if ($this->get_reporting_dgda_filter_value($data, ['Taxe']) != '') {
            $builder->where('p.Typerecette_17', $this->get_reporting_dgda_filter_value($data, ['Taxe']));
        }

        if ($this->get_reporting_dgda_filter_value($data, ['Beneficiaire', 'Beneficiaire_15']) != '') {
            $builder->where('p.Beneficaire_15', $this->get_reporting_dgda_filter_value($data, ['Beneficiaire', 'Beneficiaire_15']));
        }

        if ($search != '') {
            $builder->groupStart()
                    ->like('p.Date_1', $search)
                    ->orLike('p.Noteid_26', $search)
                    ->orLike('p.Notemontant_28', $search)
                    ->orLike('p.Notedevise_29', $search)
                    ->orLike('p.Beneficaire_15', $search)
                    ->orLike('p.Montant_11', $search)
                    ->orLike('p.Taux_41', $search)
                    ->orLike('p.Typerecette_17', $search)
                    ->orLike('p.Agence_20', $search)
                    ->groupEnd();
        }

        return $builder;
    }


    public function get_immatriculation_payments_by_statuses(array $statuses, $limit = 1000)
    {
        $statuses = array_values(array_unique(array_map('intval', $statuses)));

        if (empty($statuses)) {
            return [];
        }

        return $this->db->table('logiref_integration_immatriculation')
                ->select('*')
                ->where('Account_3', $this->session->userdata['account_id'])
                ->whereIn('Status_2', $statuses)
                ->orderBy('Date_1', 'DESC')
                ->limit((int) $limit)
                ->get()
                ->getResult();
    }


    public function get_reporting_immatriculation_paiements_datatable($source = 'tresor', $data = null, $offset = 0, $limit = 100, $search = '', $orderColumn = 0, $orderDir = 'DESC')
    {
        $config = $this->get_reporting_immatriculation_config($source);
        $columns = [
            0 => 'p.Date_1',
            1 => 'i.Status_2',
            2 => 'p.Noteid_26',
            3 => 'p.Notemontant_28',
            4 => 'p.Beneficaire_15',
            5 => 'p.Typerecette_17',
            6 => 'p.Date_1',
            7 => 'p.Montant_11',
            8 => 'p.Montant_11',
            9 => 'p.Taux_41',
            10 => 'p.Date_1',
            11 => 'i.Guichet_32',
        ];

        $orderBy = isset($columns[$orderColumn]) ? $columns[$orderColumn] : 'p.Date_1';
        $orderDir = strtoupper($orderDir) == 'ASC' ? 'ASC' : 'DESC';
        $limit = ($limit > 0) ? (int) $limit : 100;
        $offset = ($offset > 0) ? (int) $offset : 0;

        $rows = $this->get_reporting_immatriculation_builder($source, $data, $search, true)
                ->orderBy($orderBy, $orderDir)
                ->limit($limit + 1, $offset)
                ->get()
                ->getResult();
        $hasNext = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $rows = $this->hydrate_reporting_immatriculation_payment_ranks($source, $rows);
        $rows = $this->hydrate_reporting_immatriculation_credit_accounts($rows);
        $progressiveTotal = $offset + count($rows) + ($hasNext ? 1 : 0);

        return [
            'recordsTotal' => $progressiveTotal,
            'recordsFiltered' => $progressiveTotal,
            'rows' => $rows,
        ];
    }


    private function apply_reporting_immatriculation_siop_filter($builder, $mode)
    {
        // Noteids_14 est historiquement un tableau JSON encodé deux fois.
        // Accepter aussi les tableaux simples et ignorer les valeurs invalides.
        $decoded = "CASE WHEN JSON_VALID(sf.Noteids_14) THEN JSON_UNQUOTE(sf.Noteids_14) ELSE '[]' END";
        $noteIds = "CASE WHEN JSON_VALID($decoded) THEN $decoded ELSE '[]' END";
        $sent = "EXISTS (SELECT 1 FROM logiref_integration_sftp_immatriculation sf"
                . " WHERE sf.Status_2 = 2 AND sf.Account_3 = i.Account_3"
                . " AND (JSON_CONTAINS($noteIds, CAST(i.Id_0 AS CHAR))"
                . " OR JSON_CONTAINS($noteIds, JSON_QUOTE(CAST(i.Id_0 AS CHAR)))))";

        $builder->where($mode === 'sent' ? $sent : 'NOT ' . $sent, null, false);
        if ($mode === 'pending') {
            // La première instruction de priorité 0 crédite le séquestre.
            // Une autre écriture réussie (frais, TVA) ne suffit pas.
            $builder->where("(SELECT CASE WHEN first_ci.Status_2 = 2 AND first_ci.Montant_10 > 0 THEN 1 ELSE 0 END"
                    . " FROM logiref_cbs_instructions_immatriculation first_ci"
                    . " WHERE first_ci.Paiementid_4 = CAST(i.Id_0 AS CHAR) AND first_ci.Priority_27 = 0"
                    . " ORDER BY first_ci.Id_0 ASC LIMIT 1) = 1", null, false);
        }
    }
}
