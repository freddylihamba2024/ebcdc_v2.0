<?php
namespace Modules\Branch\Models;

use App\Models\MY_Transaction;
use stdClass;

class OthersModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='".$account_id."'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
	}
        
        
        public function  get_prepayments_by_lot($ids)
        {
                $account = $this->session->userdata['account_id'];
                $st = "Account_3='" . $account . "'  AND Status_2!='0' AND Id_0 IN (".$ids.") ";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();

                return  $query->getResult();
        }
        
        
        public function check_bl_exist()
        {
                $account = $this->session->userdata['account_id'];
                $st = "Account_3='" . $account . "'  AND Status_2 > '0'";
                
                if(isset($_POST['Service_16'])) $st .= " AND Office_6 ='".$_POST['Service_16']."'";
                if(isset($_POST['Infos']['year']))   $st .= " AND Year_5 ='".$_POST['Infos']['year']."'";
                if(isset($_POST['Nif_13']))    $st .= " AND Nif_9 ='".$_POST['Nif_13']."'";
                if(isset($_POST['Infos']['serie'])) $st .= " AND Serie_7 ='".$_POST['Infos']['serie']."'";
                if(isset($_POST['Infos']['number'])) $st .= " AND Number_8 ='".$_POST['Infos']['number']."'";
                if(isset($_POST['Montant_11'])) $st .= " AND Amount_12 ='".$_POST['Montant_11']."'";
                if(isset($_POST['Infos']['bank'])) $st .= " AND Bank_11 ='".$_POST['Infos']['bank']."'";
                if(isset($_POST['Infos']['Agent'])) $st .= " AND Agent_10 ='".$_POST['Infos']['Agent']."'";
                
                $query = $this->db->table('logiref_integration_sydonia')
                                ->select('logiref_integration_sydonia.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();

                return  $query->getResult();
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function delete_bulletin($id)
	{
                $builder = $this->db->table('logiref_integration_sydonia');
                $condition = ['Id_0' => $id];
                
                $deletedId = $id;
                
                $builder->where($condition);
                $builder->delete();
                
                return $deletedId;
	}
}
