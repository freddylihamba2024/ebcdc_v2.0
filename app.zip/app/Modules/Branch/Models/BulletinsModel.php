<?php
namespace Modules\Branch\Models;
use App\Models\MY_Transaction;
use stdClass;

class BulletinsModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE); 
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='".$account_id."'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
	}
        
        public function  get_bulletins_by_lot($ids)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2!='0' AND Account_3='".$account."' AND Id_0 IN (".$ids.")";
                
                $query = $this->db->table('logiref_integration_sydonia')
                                ->select('logiref_integration_sydonia.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->limit(500)
                                ->get();
                
                return  $query->getResult();
        }
        
        public function  get_bulletins_by_logiredid($ids)
        {
                $account = $this->session->userdata['account_id'];

                $st = "Status_2!='0' AND Account_3='".$account."' AND Logirefid_34 IN ('".$ids."')";
                
                $query = $this->db->table('logiref_integration_sydonia')
                        ->select('logiref_integration_sydonia.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return  $query->getResult();
        }
        
        public function get_declarations_instructions_by_ref($ids) 
        {
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = "Paiementid_4 IN($ids) AND Status_2 = '1' AND Priority_24 > 0 AND Montant_10 > 0";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                return $this->get_all();
        }
        
        public function get_declaration_to_treat()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->userdata['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*');
                $this->db->from('logiref_integration_sydonia');
                
                $st = "Status_2 = 2 AND Account_3='".$account."' AND Customercode_35 != '' AND Agence_32 ='".$agence."'";
                 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                $payments = $this->get_all();
                       
                $tableau = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                    $key = $line->Customercode_35;
                    
                    if(key_exists($key, $counts))
                    {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_25;
                    }
                    else
                    {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_25;
                    }
                    
                    $line->total = $counts[$key];
                    $line->amounts = $amounts[$key];
                    $tableau[$key] = $line;
                    
                endforeach;
                
                return $tableau;
        }
        
        public function get_all_payments_rbo($status)
        {
            
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->userdata['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*');
                $this->db->from('logiref_integration_sydonia');
                
                $st = "Account_3='".$account."' AND Customercode_35 != '' AND Agence_32 ='".$agence."'";
                
                if($status == "new"):
                    
                        $st.= " AND Status_2 ='1' ";
                
                else:
                    
                        $st.= " AND Status_2 = 2  ";
                
                endif;
                 
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                $payments = $this->get_all();
                       
                $bureaux = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                    $key = $line->Office_6.$line->Customercode_35;
                    
                    if(key_exists($key, $counts))
                    {
                        $counts[$key] += 1;
                        $amounts[$key]+= $line->Amount_25;
                    }
                    else
                    {
                        $counts[$key] = 1;
                        $amounts[$key] = $line->Amount_25;
                    }
                    
                    $line->total = $counts[$key];
                    $line->amounts = $amounts[$key];
                    $bureaux[$line->Office_6][$line->Customercode_35] = $line;
                    
                endforeach;
                
                return $bureaux;
        }
        
        public function  get_rbo_declarations_by_customer($customer)
        {
                $day = Date('Y-m-d');
                $account = $this->session->userdata['account_id'];
                $agence = $this->session->userdata['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 ASC');
                $this->db->from('logiref_integration_sydonia');
                $st = "Status_2!='0'  AND Account_3='".$account."' AND Agence_32 = '".$agence."'AND Customercode_35 = '".$customer."'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        
        public function batch_update($data, $ids) 
        {
                $this->db->where("logiref_integration_sydonia.Id_0 IN (".$ids.")");
                return $this->db->update('logiref_integration_sydonia', $data);
        }
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}