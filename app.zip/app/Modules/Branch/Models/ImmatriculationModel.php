<?php

        namespace Modules\Branch\Models;

        use App\Models\MY_Transaction;
        use Modules\Logiref\Models\InvLogirefModel;
        use stdClass;

        class ImmatriculationModel extends MY_Transaction
        {
                private $invLogirefModel = null;

                /*
                * Protected and public variables
                * Use: forms validation constraintes, dropdowns static array, contextual variable etc
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
                * *************************************************************************************************************************SCETION 2
                */

                public $banks = array(
                        '' => '',
                        '36'    => 'Standard Bank',
                        '44'    => 'Rawbank',
                        '45'    => 'Tmb',
                        '46'    => 'Ebcdc',
                        '9082'  => 'Boa',
                        '9083'  => 'Solidaire',
                        '9084'  => 'Sofibank',
                        '9085'  => 'Firstbank',
                        '9096'  => 'Crdbbank'
                );
                public $bank;

                private $role = null;

                public function __construct()
                {
                        parent::__construct();

                        $this->role = $_SESSION['Logiref_role'];

                        $this->invLogirefModel = new InvLogirefModel();

                        $account = $this->session->userdata['account_id'] ?? '';
                        $this->bank = $this->banks[$account];
                }

                private function is_license_plate_web_service_validation_enabled()
                {
                        $options = $_SESSION['userdata']['options'] ?? array();

                        if(is_string($options))
                        {
                                $options = json_decode($options, true);
                        }

                        if(!is_array($options))
                        {
                                return false;
                        }

                        return isset($options['ALL']['license-plate-payment-validation-by-web-service'])
                                || isset($options['DGI']['license-plate-payment-validation-by-web-service']);
                }

                private function are_license_plate_sequences_completed($instructions)
                {
                        $primary_count = 0;
                        $secondary_count = 0;

                        foreach($instructions as $instruction)
                        {
                                $priority = (int) $instruction->Priority_27;
                                $amount = (float) $instruction->Montant_10;
                                $status = (int) $instruction->Status_2;

                                if($priority === 0) $primary_count++;
                                if($priority === 1) $secondary_count++;

                                if(($amount > 0 && $status !== 2)
                                        || ($amount == 0.0 && !in_array($status, [1, 2], true)))
                                {
                                        return false;
                                }
                        }

                        return $primary_count === 3 && $secondary_count > 0;
                }

                /*
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
                * *************************************************************************************************************************SCETION 2
                */
                public function get_OBJE_info($oid=NULL)
                {
                        if($oid==NULL)
                        {
                                $obj = new stdClass();
                                $obj->Id_0='';
                                $obj->Date_1=gmdate('Y-m-d H:i:s');
                                $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                                $obj->Account_3='';
                                $obj->Creator_4='';
                                $obj->Changes_5='';
                                $obj->Changer_6='';

                                #Add more here
                                return $obj;
                        }
                        else
                        {
                                $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }

                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * P.S: Ajoutez vous methodes ci-dessous!!
                *  *************************************************************************************************************************SECTION 4
                */

                public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
                {
                        $account_id = $this->session->userdata['account_id'];
                        $builder = $this->db->table('TABLE_NAME')
                                ->select('TABLE_NAME.*')
                                ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                                ->orderBy('TABLE_NAME.COL_NAME','ASC')
                                ->get();

                        return $builder->getResult();
                }

                public function get_paiement_info($id=NULL)
                {
                        if ($id == NULL)
                        {
                                $obj = new stdClass();
                                $obj->Id_0 = NULL;
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = $this->session->userdata['account_id'];
                                $obj->Logirefid_4 = rand(1, 999).date('H').date('i').date('s').date('j').date('m').date('y').rand(1, 999);
                                $obj->Banqueid_5 = ''; //Core Banking ID
                                $obj->Chequeid_6 = '';
                                $obj->Isysid_7 = '';
                                $obj->Rtgsid_8 = '';
                                $obj->Makerid_9 = '';

                                $obj->Checkerid_10 = '';
                                $obj->Montant_11 = '';
                                $obj->Devise_12 = '';
                                $obj->Nif_13 = '';
                                $obj->Designation_14 = '';
                                $obj->Beneficaire_15 = '';
                                $obj->Service_16 = '';
                                $obj->Typerecette_17 = '';
                                $obj->Artbudgetaire_18 = '';
                                $obj->Mode_19 = '';
                                $obj->Agence_20 = '';

                                $obj->Guichet_21 = '';
                                $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                                $obj->Commission_23= '';
                                $obj->Devise_24= '';
                                $obj->Notetype_25 = '5';
                                $obj->Noteid_26 = '';
                                $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                                $obj->Notemontant_28 = '';
                                $obj->Notedevise_29 = '';

                                $obj->Notereference_30 = '';
                                $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                                $obj->Reference_32 = '';
                                $obj->Compte_33 = '';
                                $obj->Devise_34 = '';
                                $obj->Changement_35 = ''; //Date
                                $obj->Validation_36 = '';
                                $obj->Integration_37 = '';
                                $obj->Reversement_38 = '';
                                $obj->Nivellement_39 = '';

                                $obj->Suppression_40 = '';
                                $obj->Taux_41 = '';
                                $obj->Devise_42 = '';
                                $obj->Attestation_43 = '';
                                $obj->Sydonia_44 = '0';
                                $obj->Tresor_45 = '0';
                                $obj->Missmatch_46 = '';
                                $obj->Isyserrors_47 = '';
                                $obj->Isysvalidation_48 = '';
                                $obj->Sydonia_49 = '';
                                $obj->Paiementkey_50 = '';
                                $obj->Customercode_51 = '';
                                $obj->Notefile_52 = '';
                                $obj->Seguice_53 = '';
                                $obj->Invoice_54 = '';
                                $obj->Status_55 = '';
                                $obj->Region_56 = '';
                                $obj->Environment_56 = '';
                                $obj->Printattestation_57 = '';
                                $obj->Tauxflag_58 = '';
                                $obj->Email_54 = '';
                                $obj->Phone_55 = '';
                                $obj->Immatriculation_57 = '';
                                $obj->Type_58 = '';

                                return $obj;
                        }
                        else
                        {
                                $this->set_table('logiref_paiements_tresor_immatriculation p', 'p.Id_0', 'p.Id_0 DESC');
                                return $this->get_by(array('Id_0' => $id), TRUE);
                        }
                }

                public function get_paiement_tresor_by_logiref_id($logiref_id=NULL)
                {
                        if ($logiref_id != NULL)
                        {
                                $this->set_table('logiref_paiements_tresor_immatriculation p', 'p.Id_0', 'p.Id_0 DESC');
                                return $this->get_by(array('Logirefid_4' => $logiref_id), TRUE);
                        }
                }

                public function get_integration_sftp_summary_by_id($id = NULL)
                {
                $this->set_table('logiref_cbs_treatment_sftp_immatriculation i', 'i.Id_0', 'i.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
                }

                public function get_paiement_tresor_immatriculation_by_reference($reference=NULL)
                {
                        if($reference != "")
                        {
                                $this->set_table('logiref_paiements_tresor_immatriculation I', 'I.Id_0', 'I.Id_0 DESC');

                                return $this->get_by(array('Noteid_26' => $reference,'Status_2 !='=>0), TRUE);
                        }
                }

                public function get_paiement_tresor_by_transactionid($ref)
                {
                        $st = " Date_1 LIKE '%" . gmdate('Y-m-d') . "%' AND Status_2 >=3  AND Mode_19 ='5' AND Reference_32='".$ref."'";
                        $builder = $this->db->table('logiref_paiements_tresor_immatriculation')
                                ->select('logiref_paiements_tresor_immatriculation.*')
                                ->where($st)
                                ->orderBy('logiref_paiements_tresor_immatriculation.Id_0','DESC')
                                ->get();

                        return $builder->getResult();
                }

                public function get_paiement_propre_by_transactionid($ref)
                {
                        $st = " Date_1 LIKE '%" . gmdate('Y-m-d') . "%' AND Status_2 >= 3 AND Mode_19 ='5' AND Reference_32='".$ref."'";
                        $builder = $this->db->table('logiref_paiements_propres_immatriculation')
                                ->select('logiref_paiements_propres_immatriculation.*')
                                ->where($st)
                                ->orderBy('logiref_paiements_propres_immatriculation.Id_0','DESC')
                                ->get();

                        return $builder->getResult();
                }

                public function get_montant_total($data=NULL)
                {
                        $total_montant = 0;

                        if(!empty($data))
                        {
                                $data['Montant_11'] = str_replace(' ','',$data['Montant_11']);
                                $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                $data['Montant_11'] = intval($data['Montant_11']);
                                $data['Commission_23'] = str_replace(' ','',$data['Commission_23']);
                                $data['Commission_23'] = str_replace(',','',$data['Commission_23']);
                                $data['Commission_23'] = intval($data['Commission_23']);
                                $total_montant = $data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23']*0.16);
                        }
                        return  $total_montant;
                }

                public function get_data_validation_immatriculation($id=null)
                {

                        $return = array();
                        $formdata = $_POST;
                        $errors = array();

                        $integration = $this->get_integration_immatriculation($id);
                        $paiement_info = $this->immatriculation_migrate_note($integration->Id_0);

                        if (empty($formdata) || !is_array($formdata))
                        {
                                $errors[]='Les données sont manquantes ou invalides.';
                        }

                        if (isset($this->role) && !in_array($this->role,[2,3,4]) )
                        {
                                $errors[] = 'Vous n\'avez pas les droits nécessaires pour effectuer cette action.';
                        }

                        // Check if required fields are present
                        if(!isset($formdata['Id_0']) || empty($formdata['Id_0']))
                        {
                                $errors[] = 'L\'ID du paiement de immatriculation est manquant.';
                        }

                        if(!isset($formdata['Logirefid_4']) || empty($formdata['Logirefid_4']))
                        {
                                $errors[] = 'La référence Logiref est manquante.';
                        }

                        $data = [
                                'Id_0' => isset($formdata['Id_0']) ? $formdata['Id_0'] : '',
                                'Logirefid_4' => isset($formdata['Logirefid_4']) ? $formdata['Logirefid_4'] : '',
                                'Priority_27' => 1,
                                'Account_3' => $integration->Account_3,
                                'Designation_14' =>  isset($paiement_info->Designation_14) ? $paiement_info->Designation_14 : '',
                                'Beneficaire_15' => isset($formdata['Beneficaire_15']) ? $formdata['Beneficaire_15'] : '',
                                'Typerecette_17' =>  isset($paiement_info->Typerecette_17) ? $paiement_info->Typerecette_17 : '',
                                'Statut_2'=> $paiement_info->Status_2
                        ];

                        if($this->is_license_plate_web_service_validation_enabled())
                        {
                                $sequence_data = $data;
                                $sequence_data['Taux_41'] = $formdata['Taux_41'] ?? ($paiement_info->Taux_41 ?? '');
                                $sequence_data['Notereference_30'] = $formdata['Notereference_30']
                                        ?? ($paiement_info->Notereference_30 ?? '');

                                $first_transaction = $sequence_data;
                                $first_transaction['Trans'] = 'firstTrans';
                                $first_transaction['Priority_27'] = 0;

                                $second_transaction = $sequence_data;
                                $second_transaction['Trans'] = 'secondTrans';
                                $second_transaction['Priority_27'] = 1;

                                $data = [
                                        'firstTrans' => $first_transaction,
                                        'secondTrans' => $second_transaction
                                ];
                        }

                        if (!empty($errors))
                        {
                                $return=['code' => 404, 'message' => implode(', ', $errors), 'data' => []];
                        }
                        else
                        {
                                $return= ['code' => 200, 'message' => 'valid', 'data' => $data];
                        }

                        return $return;
                }

                public function acquire_integration_lock($scope, $timeout = 10)
                {
                        $lockName = 'immatric:' . substr(hash('sha256', $scope), 0, 48);
                        $row = $this->db->query(
                                'SELECT GET_LOCK(?, ?) AS lock_acquired',
                                [$lockName, (int) $timeout]
                        )->getRow();

                        return isset($row->lock_acquired) && (int) $row->lock_acquired === 1
                                ? $lockName
                                : false;
                }

                public function release_integration_lock($lockName)
                {
                        if (!empty($lockName))
                        {
                                $this->db->query('SELECT RELEASE_LOCK(?)', [$lockName]);
                        }
                }

                public function get_active_integration_summaries($date, $type)
                {
                        return $this->db->table('logiref_cbs_treatment_sftp_immatriculation')
                                ->select('logiref_cbs_treatment_sftp_immatriculation.*')
                                ->where('Branch_11', $_SESSION['Logiref_guichet'])
                                ->where('Type_13', 'immatric')
                                ->where('Type_16', $type)
                                ->whereIn('Status_2', [1, 2])
                                ->like('Date_1', $date, 'after')
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getResult();
                }

                public function get_integrations_sftp_by_treatmentid($treatmentid)
                {
                        return $this->db->table('logiref_integration_sftp_immatriculation')
                                ->select('logiref_integration_sftp_immatriculation.*')
                                ->where('Treatmentid_18', $treatmentid)
                                ->orderBy('Id_0', 'ASC')
                                ->get()
                                ->getResult();
                }

                public function get_data_confirmation_immatriculation()
                {
                        $guichets = $this->invLogirefModel->get_dropdown("guichets");
                        $code_agences = $this->invLogirefModel->get_dropdown("codeagences");

                        $apidata = array();

                        $apidata['numeroNotePerception'] = $_POST['Noteid_26'] ?? "";
                        $apidata['transactionId']        = $_POST['Id_0'] ?? 0;
                        $apidata['amount']               = $this->formatage_amount($_POST['Notemontant'] ?? "0");
                        $apidata['currency']             = $_POST['Notedevise_29'] ?? "";
                        $apidata['transactionReference'] = $_POST['Logirefid_4'] ?? "";
                        $apidata['paymentDate']          = gmdate('Y-m-d\TH:i:s\Z');
                        $apidata['bankName']             = $this->bank;
                        $apidata['metadata']             = ["x" => 1, "y" => 2];

                        $required = ['numeroNotePerception', 'transactionId', 'amount', 'currency', 'transactionReference','paymentDate','bankName'];

                        foreach ($required as $field) 
                        {
                                if (empty($apidata[$field])) 
                                {
                                        return [
                                                'code' => 404,
                                                'message' => "Le champ {$field} est manquant ou vide"
                                        ];
                                }
                        }

                        return [
                                'code' => 200,
                                'data' => $apidata
                        ];
                }

                public function get_data_immatriculation()
                {
                        $formdata = $_POST;
                        $errors = [];
                        $clean = [];
                        $notereferences=null;

                        $return = array();

                        if (empty($formdata) || !is_array($formdata))
                        {
                                $errors[] ='Les données du formulaire sont manquantes ou invalides.';
                        }

                        // Fields to skip validation/formatting
                        $exceptions = [
                                'Id_0','Logiradid', 'Sydonia_44', 'Tresor_45'
                        ];

                        // Required fields (add/remove as needed)
                        $required = [
                                'Beneficaire_15',
                                'Service_16', 'Noteid_26', 'Notetype_25', 'Notedate_27',
                                'Typerecette_17', 'Notemontant_28', 'Notedevise_29',
                                'Nif_13', 'Designation_14', 'Mode_19', 'Taux_41',
                                'Datevaleur_31', 'Reference_32', 'Compte_33',
                                'Montant_11', 'Commission_23', 'Devise_34', 'Devise_12', 'Devise_24'
                        ];

                        // Required fields for Infos
                        $required_infos = [
                                'standard',
                                'QuotasComite', 'QuotasPrestataire',
                                'QuotasService', 'QuotasTresor', 'Email', 'Phone'
                        ];

                        if(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] != 4)
                        {
                                $errors[] = 'Vous n\'avez pas les droits nécessaires pour effectuer cette action.';
                        }

                        foreach ($formdata as $key => $value)
                        {
                                if (in_array($key, $exceptions))
                                {
                                        $clean[$key] = $value;
                                        continue;
                                }

                                // Required field check
                                if (in_array($key, $required) && ($value === '' || $value === null))
                                {
                                        $variable = explode("_",$key);
                                        $errors[] = $variable[0] . ' est requis';
                                        continue;
                                }

                                // Numeric formatting
                                if (in_array($key, ['Montant_11', 'Commission_23', 'Notemontant_28', 'Taux_41']))
                                {
                                        $clean[$key] = floatval(str_replace([',', ''], ['.', ''], $value));
                                        if ($clean[$key] < 0)
                                        {
                                                $variable = explode("_",$key);
                                                $errors[] = $variable[0]." doit être un nombre positif";
                                                continue;
                                        }
                                        continue;
                                }

                                // Default: trim text
                                $clean[$key] = is_string($value) ? trim($value) : $value;
                        }

                        // Validate Infos sub-array if present
                        if (isset($formdata['Infos']) && is_array($formdata['Infos']))
                        {
                                $notereferences = json_encode($formdata['Infos']);
                        }

                        if (!empty($errors))
                        {
                                $return= ['code'=>404,'message' => implode(', ', $errors),'data' => []];
                        }
                        else
                        {
                                $formdata['Montant_11'] = $this->formatage_amount($formdata['Montant_11']);
                                $contrevaleur = ($formdata['Devise_12'] !='CDF') ? round(($formdata['Montant_11'] * $formdata['Taux_41']),2) : $formdata['Montant_11'];

                                $data=[ 'Id_0' => $formdata['Id_0'],
                                        'Date_1' => gmdate('Y-m-d H:i:s'),
                                        'Status_2' => 1,
                                        'Account_3' => $this->session->userdata['account_id'],
                                        'Logirefid_4' => $this->generate_unique_reference().$this->session->userdata['user_id'],
                                        'Makerid_9' => $this->session->userdata['user_id'],
                                        'Montant_11' => $formdata['Montant_11'],
                                        'Devise_12' => $formdata['Devise_12'],
                                        'Nif_13' => $formdata['Nif_13'],
                                        'Designation_14' => $formdata['Designation_14'],
                                        'Beneficaire_15' => 'DGI',
                                        'Service_16' => $formdata['Service_16'],
                                        'Typerecette_17' => $formdata['Typerecette_17'],
                                        'Mode_19' => $formdata['Mode_19'],
                                        'Artbudgetaire_18' => $formdata['Typerecette_17'],
                                        'Agence_20' =>$_SESSION['Logiref_agence'],
                                        'Guichet_21' =>$_SESSION['Logiref_guichet'],
                                        'Contrevaleur_22' => $contrevaleur,
                                        'Commission_23' => $this->formatage_amount($formdata['Commission_23']),
                                        'Devise_24' => $formdata['Devise_24'],
                                        'Notetype_25' =>'5',
                                        'Noteid_26' => $formdata['Noteid_26'],
                                        'Notedate_27' =>$formdata['Notedate_27'],
                                        'Notemontant_28' => $this->formatage_amount($formdata['montantTotal']),
                                        'Notedevise_29' => $formdata['Notedevise_29'],
                                        'Notereference_30' => $notereferences,
                                        'Datevaleur_31' =>  gmdate('Y-m-d'),
                                        'Reference_32' => $formdata['Reference_32'],
                                        'Compte_33' => $formdata['Compte_33'],
                                        'Devise_34' => $formdata['Devise_34'],
                                        'Taux_41' => $formdata['Taux_41'],
                                        'Devise_42' => $formdata['Devise_12']
                                ];

                                if(isset($formdata['Infos']['applicant']['Email'])){
                                        $data['Email_54'] = $formdata['Infos']['applicant']['Email'];
                                        $data['Phone_55'] = $formdata['Infos']['applicant']['Phone'];
                                }
                                else{
                                        $data['Email_54'] = $formdata['Infos']['Email'];
                                        $data['Phone_55'] = $formdata['Infos']['Phone'];
                                }

                                $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                        }
                        return $return;

                }

                public function get_data_immatriculation_by_type_beneficiaire($beneficiaire_data,$main_data,$type=null, $post_data)
                {
                        $formdata = $_POST;
                        $errors = [];
                        $clean = [];
                        $notereferences= ($post_data["Notereference_30"] ?? null) ?? [];


                        $return = array();

                        if (empty($formdata) || !is_array($formdata))
                        {
                                $errors[] ='Les données du formulaire sont manquantes ou invalides.';
                        }

                        // Fields to skip validation/formatting
                        $exceptions = [
                                'Id_0','Logiradid', 'Sydonia_44', 'Tresor_45'
                        ];

                        // Required fields (add/remove as needed)
                        $required = [
                                'Beneficaire_15',
                                'Service_16', 'Noteid_26', 'Notetype_25', 'Notedate_27',
                                'Typerecette_17', 'Notemontant_28', 'Notedevise_29',
                                'Nif_13', 'Designation_14', 'Mode_19', 'Taux_41',
                                'Datevaleur_31', 'Reference_32', 'Compte_33',
                                'Montant_11', 'Commission_23', 'Devise_34', 'Devise_12', 'Devise_24'
                        ];

                        if(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] != 4)
                        {
                                $errors[] = 'Vous n\'avez pas les droits nécessaires pour effectuer cette action.';
                        }

                        foreach ($formdata as $key => $value) 
                        {
                                if (in_array($key, $exceptions)) 
                                {
                                        $clean[$key] = $value;
                                        continue;
                                }

                                // Required field check
                                if (in_array($key, $required) && ($value === '' || $value === null))
                                {
                                        $variable = explode("_",$key);
                                        $errors[] = $variable[0] . ' est requis';
                                        continue;
                                }

                                // Numeric formatting
                                if (in_array($key, ['Montant_11', 'Commission_23', 'Notemontant_28', 'Taux_41']))
                                {
                                        $clean[$key] = floatval(str_replace([',', ''], ['.', ''], $value));
                                        if ($clean[$key] < 0)
                                        {
                                                $variable = explode("_",$key);
                                                $errors[] = $variable[0]." doit être un nombre positif";
                                                continue;
                                        }
                                        continue;
                                }

                                // Email validation
                                // if ($key === 'Email_54' && !filter_var($value, FILTER_VALIDATE_EMAIL))
                                // {
                                //         $errors[] = 'L\'adresse mail est invalide';
                                //         continue;
                                // }

                                // Default: trim text
                                $clean[$key] = is_string($value) ? trim($value) : $value;
                        }

                        if (!empty($errors))
                        {
                                $return = ['code'=>404,'message' => implode(', ', $errors),'data' => []];
                        }
                        else
                        {
                                $formdata['Montant_11'] = $this->formatage_amount($formdata['Montant_11']);
                                $contrevaleur = ($formdata['Devise_12'] !='CDF') ? round(($beneficiaire_data['Amount_10'] * $formdata['Taux_41']),2) : $beneficiaire_data['Amount_10'];
                                $customer = json_decode($main_data->Applicant_12, true);

                                if($type=="RGF")
                                {
                                        $data=[ 'Id_0' => $formdata['Id_0'],
                                                'Date_1' => gmdate('Y-m-d H:i:s'),
                                                'Status_2' => 1,
                                                'Account_3' => $this->session->userdata['account_id'],
                                                'Logirefid_4' => $main_data->Logirefid_31."-".$beneficiaire_data['suffix'],
                                                'Makerid_9' => $this->session->userdata['user_id'],
                                                'Montant_11' => (isset($beneficiaire_data['Amount_10']))?$beneficiaire_data['Amount_10']:0,
                                                'Devise_12' => (isset($beneficiaire_data['Currency_11']))?$beneficiaire_data['Currency_11']:"",
                                                'Nif_13' => $formdata['Nif_13'],
                                                'Designation_14' => $formdata['Designation_14'],
                                                'Beneficaire_15' => (isset($beneficiaire_data['BeneficiaryCode_16']))?$beneficiaire_data['BeneficiaryCode_16']:"",
                                                'Service_16' => $formdata['Service_16'],
                                                'Typerecette_17' => $formdata['Typerecette_17'],
                                                'Mode_19' => $formdata['Mode_19'],
                                                'Artbudgetaire_18' => $formdata['Typerecette_17'],
                                                'Agence_20' =>$_SESSION['Logiref_agence'],
                                                'Guichet_21' =>$_SESSION['Logiref_guichet'],
                                                'Contrevaleur_22' => $contrevaleur,
                                                'Commission_23' => $this->formatage_amount($formdata['Commission_23']),
                                                'Devise_24' => $formdata['Devise_24'],
                                                'Notetype_25' =>'5',
                                                'Noteid_26' => $formdata['Noteid_26'],
                                                'Notedate_27' =>$formdata['Notedate_27'],
                                                'Notemontant_28' => $this->formatage_amount($formdata['montantTotal']),
                                                'Notedevise_29' => $formdata['Notedevise_29'],
                                                'Notereference_30' => json_encode($notereferences, JSON_UNESCAPED_UNICODE),
                                                'Datevaleur_31' =>  gmdate('Y-m-d'),
                                                'Reference_32' => $formdata['Reference_32'],
                                                'Compte_33' => $formdata['Compte_33'],
                                                'Devise_34' => $formdata['Devise_34'],
                                                'Taux_41' => $formdata['Taux_41'],
                                                'Devise_42' => $formdata['Devise_12'],
                                                'Email_54' => $customer['Email_16'],
                                                'Phone_55' => $customer['Phone_17'],
                                                'Immatriculation_57'=>$main_data->Id_0
                                        ];
                                }
                                elseif($type=="AIP")
                                {
                                        $data=[ 'Id_0' => $formdata['Id_0'],
                                                'Date_1' => gmdate('Y-m-d H:i:s'),
                                                'Status_2' => 1,
                                                'Account_3' => $this->session->userdata['account_id'],
                                                'Logirefid_4' => $main_data->Logirefid_31."-".$beneficiaire_data['suffix'],
                                                'Makerid_9' => $this->session->userdata['user_id'],
                                                'Montant_11' => (isset($beneficiaire_data['Amount_10']))?$beneficiaire_data['Amount_10']:0,
                                                'Devise_12' => (isset($beneficiaire_data['Currency_11']))?$beneficiaire_data['Currency_11']:"",
                                                'Nif_13' => $formdata['Nif_13'],
                                                'Designation_14' => $formdata['Designation_14'],
                                                'Beneficaire_15' => (isset($beneficiaire_data['BeneficiaryCode_16']))?$beneficiaire_data['BeneficiaryCode_16']:"",
                                                'Service_16' => $formdata['Service_16'],
                                                'Typerecette_17' => $formdata['Typerecette_17'],
                                                'Mode_19' => $formdata['Mode_19'],
                                                'Artbudgetaire_18' => $formdata['Typerecette_17'],
                                                'Agence_20' =>$_SESSION['Logiref_agence'],
                                                'Guichet_21' =>$_SESSION['Logiref_guichet'],
                                                'Contrevaleur_22' => $contrevaleur,
                                                'Commission_23' => $this->formatage_amount($formdata['Commission_23']),
                                                'Devise_24' => $formdata['Devise_24'],
                                                'Notetype_25' =>'5',
                                                'Noteid_26' => $formdata['Noteid_26'],
                                                'Notedate_27' =>$formdata['Notedate_27'],
                                                'Notemontant_28' => $this->formatage_amount($formdata['montantTotal']),
                                                'Notedevise_29' => $formdata['Notedevise_29'],
                                                'Notereference_30' => json_encode($notereferences, JSON_UNESCAPED_UNICODE),
                                                'Datevaleur_31' =>  gmdate('Y-m-d'),
                                                'Reference_32' => $formdata['Reference_32'],
                                                'Compte_33' => $formdata['Compte_33'],
                                                'Devise_34' => $formdata['Devise_34'],
                                                'Taux_41' => $formdata['Taux_41'],
                                                'Devise_42' => $formdata['Devise_12'],
                                                'Immatriculation_52'=>$main_data->Id_0
                                        ];
                                }

                                $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                        }
                        return $return;
                }

                public function get_integrations_sftp_treatment_in_progress($type=null)
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $date = gmdate('Y-m-d');

                        $st = " Branch_11 ='" . $agence . "' AND (Status_2 = 1 OR Status_2 = 2) AND Type_16='".$type."' AND Date_1 LIKE '%".$date."%' ";

                        $query = $this->db->table('logiref_cbs_treatment_sftp_immatriculation')
                                ->select('logiref_cbs_treatment_sftp_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->limit(1)
                                ->get();

                        $result = $query->getResult();

                        return $result;
                }

                public function get_integrations_sftp_treatment_by_filter($date, $type)
                {
                        $treatments = $this->db->table('logiref_cbs_treatment_sftp_immatriculation')
                                ->select('logiref_cbs_treatment_sftp_immatriculation.*')
                                ->where('Branch_11', $_SESSION['Logiref_guichet'])
                                ->where('Type_13', 'immatric')
                                ->where('Type_16', $type)
                                ->like('Date_1', $date, 'after')
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getResult();

                        foreach ($treatments as $treatment)
                        {
                                // Le résumé existe, mais les fichiers par bureau ne sont pas
                                // encore créés : il faut reprendre ce traitement.
                                if ((int) $treatment->Status_2 === 1)
                                {
                                        return [$treatment];
                                }

                                // L'état réel des fichiers enfants prime sur le statut du résumé.
                                // Cela récupère aussi les traitements marqués prématurément comme
                                // terminés alors qu'au moins un bureau reste encore à envoyer.
                                if (!empty($this->get_integrations_sftp_on_pending_by_treatmentid($treatment->Id_0)))
                                {
                                        return [$treatment];
                                }
                        }

                        return [];
                }

                public function get_latest_integration_sftp_treatment_by_filter($date, $type)
                {
                        $result = $this->db->table('logiref_cbs_treatment_sftp_immatriculation')
                                ->select('logiref_cbs_treatment_sftp_immatriculation.*')
                                ->where('Branch_11', $_SESSION['Logiref_guichet'])
                                ->where('Type_13', 'immatric')
                                ->where('Type_16', $type)
                                ->like('Date_1', $date, 'after')
                                ->orderBy('Id_0', 'DESC')
                                ->limit(1)
                                ->get()
                                ->getResult();

                        return !empty($result) ? current($result) : null;
                }

                public function get_instructions_to_treat_for_sftp_immatriculation_by_date($date, $type)
                {
                        $builder = $this->db
                                ->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->select('logiref_cbs_integration_journalisation_immatriculation.*')
                                ->where('Branch_15', $_SESSION['Logiref_guichet'])
                                ->whereIn('Status_2', [1, 2])
                                ->like('Date_1', $date, 'after');

                        if ($type === 'branchless')
                        {
                                $builder->where('Type_19', 'branchless');
                        }
                        else
                        {
                                $builder->groupStart()
                                        ->where('Type_19', 'branch')
                                        ->orWhere('Type_19', '')
                                        ->groupEnd();
                        }

                        $journalisations = $builder
                                ->orderBy('Id_0', 'ASC')
                                ->get()
                                ->getResult();

                        return $this->filter_journalisations_with_first_instruction_completed($journalisations);
                }

                public function has_pending_immatriculation_journalisations_by_date($date, $type)
                {
                        $builder = $this->db
                                ->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->where('Branch_15', $_SESSION['Logiref_guichet'])
                                ->whereIn('Status_2', [1, 2])
                                ->like('Date_1', $date, 'after');

                        if ($type === 'branchless')
                        {
                                $builder->where('Type_19', 'branchless');
                        }
                        else
                        {
                                $builder->groupStart()
                                        ->where('Type_19', 'branch')
                                        ->orWhere('Type_19', '')
                                        ->groupEnd();
                        }

                        return $builder->countAllResults() > 0;
                }

                public function get_integrations_sftp_on_pending_by_treatmentid($treatmentid)
                {
                        $st = " Treatmentid_18 ='" .$treatmentid. "' AND Status_2 = '1' ";

                        $query = $this->db->table('logiref_integration_sftp_immatriculation')
                                ->select('logiref_integration_sftp_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        $result = $query->getResult();

                        return $result;
                }

                public function get_summary_by_id($treatmentid)
                {
                        $agence = $_SESSION['Logiref_guichet'];

                        $st = " Id_0 ='" .$treatmentid. "' ";

                        $query = $this->db->table('logiref_cbs_treatment_sftp_immatriculation')
                                ->select('logiref_cbs_treatment_sftp_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        $result = $query->getResult();

                        return $result;
                }

                public function get_instructions_to_treat_for_sftp_dgda($type=null)
                {
                        if($type == 'branchless')
                        {
                                $date = gmdate('Y-m-d');

                                $branch = $_SESSION['Logiref_guichet'];

                                $st = "(Status_2 = '1' OR Status_2 = '2') AND Branch_15 = '".$branch."' AND Type_19='branchless' AND Date_1 LIKE '%".$date."%' ";

                                $query = $this->db->table('logiref_cbs_integration_journalisation_immatriculation')
                                        ->select('logiref_cbs_integration_journalisation_immatriculation.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        }
                        else
                        {
                                $date = gmdate('Y-m-d');

                                $branch = $_SESSION['Logiref_guichet'];

                                $st = " (Status_2 = '1' OR Status_2 = '2') AND (Type_19 = 'branch' OR Type_19 = '') AND Branch_15 = '".$branch."' AND Date_1 LIKE '%".$date."%' ";

                                $query = $this->db->table('logiref_cbs_integration_journalisation_immatriculation')
                                        ->select('logiref_cbs_integration_journalisation_immatriculation.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        }

                        $journalisations = $query->getResult();

                        return $this->filter_journalisations_with_first_instruction_completed($journalisations);
                }

                private function filter_journalisations_with_first_instruction_completed($journalisations)
                {
                        if (empty($journalisations))
                        {
                                return [];
                        }

                        $paiementIds = [];

                        foreach ($journalisations as $journalisation)
                        {
                                if (isset($journalisation->Noteid_14) && $journalisation->Noteid_14 !== '')
                                {
                                        $paiementIds[] = $journalisation->Noteid_14;
                                }
                        }

                        $paiementIds = array_values(array_unique($paiementIds));

                        if (empty($paiementIds))
                        {
                                return [];
                        }

                        $instructions = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('Paiementid_4, Status_2')
                                ->whereIn('Paiementid_4', $paiementIds)
                                ->where('Priority_27', 0)
                                ->orderBy('Paiementid_4', 'ASC')
                                ->orderBy('Id_0', 'ASC')
                                ->get()
                                ->getResult();

                        $firstInstructionStatuses = [];

                        foreach ($instructions as $instruction)
                        {
                                if (!isset($firstInstructionStatuses[$instruction->Paiementid_4]))
                                {
                                        $firstInstructionStatuses[$instruction->Paiementid_4] = $instruction->Status_2;
                                }
                        }

                        $eligibleJournalisations = [];

                        foreach ($journalisations as $journalisation)
                        {
                                $paiementId = isset($journalisation->Noteid_14) ? $journalisation->Noteid_14 : null;

                                if ($paiementId !== null && isset($firstInstructionStatuses[$paiementId]) && (int) $firstInstructionStatuses[$paiementId] === 2)
                                {
                                        $eligibleJournalisations[] = $journalisation;
                                }
                        }

                        return $eligibleJournalisations;
                }

                public function get_formatage_data_immatriculation($data = NULL)
                {
                        if (!is_array($data))
                        {
                                return [];
                        }

                        $amountFields = [
                                'Montant_11', 'Contrevaleur_22', 'Commission_23', 'Notemontant_28', 'Taux_41',
                                'QuotasComite', 'QuotasPrestataire', 'QuotasService', 'QuotasTresor'
                        ];

                        foreach ($amountFields as $field)
                        {
                                if (isset($data[$field]))
                                {
                                        $data[$field] = $this->formatage_amount($data[$field]);
                                }
                        }

                        if (!empty($data['Notereference_30']))
                        {
                                $infos = json_decode($data['Notereference_30'], true);

                                if (is_array($infos))
                                {
                                        foreach ($amountFields as $field)
                                        {
                                                if (isset($infos[$field]))
                                                {
                                                        $infos[$field] = $this->formatage_amount($infos[$field]);
                                                }
                                        }
                                        $data['Notereference_30'] = json_encode($infos, JSON_UNESCAPED_UNICODE);
                                }
                        }

                        return $data = array('code'=>200, 'data'=> $data);
                }

                public function get_integrations_sftp_by_treatmentid_and_office($integrationid, $office)
                {
                        $agence = $_SESSION['Logiref_guichet'];

                        $st = " Id_0 ='" .$integrationid. "' AND Status_2 = '1' AND Office_7 ='" .$office. "' ";

                        $query = $this->db->table('logiref_integration_sftp_immatriculation')
                                ->select('logiref_integration_sftp_immatriculation.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        $result = $query->getResult();

                        $return = current($result);

                        return $return;
                }

                public function get_data_deletion_immatriculation()
                {
                        $data['Status_2'] = 0;
                        $data['Suppression_40'] = gmdate('Y-m-d H:i:s');

                        return [
                                'code' => 200,
                                'data' => [
                                        'Status_2' => 0,
                                        'Suppression_40' => gmdate('Y-m-d H:i:s'),
                                ]
                        ];
                }

                public function check_existing_payments($integrations, $data)
                {
                        $result = [
                                'code'        => null,
                                'html'        => null,
                                'checked'     => false,
                                'encaissement'=> null
                        ];

                        $encaissement = $this->get_paiement_tresor_immatriculation_by_reference($data['Reference_8']);
                        $result['encaissement'] = $encaissement;

                        if (!empty($integrations) && !empty($encaissement))
                        {
                                if (($encaissement->Status_2 == 1) && $encaissement->Checkerid_10 == '0' && $encaissement->Type_57 == 'mobile') 
                                {

                                        $result['code'] = $integrations->Id_0;
                                        $result['checked'] = true;
                                }
                                elseif ($encaissement->Status_2 == '1' && $encaissement->Checkerid_10 == '0')
                                {
                                        $result['code'] = "E503";
                                        $result['html'] = $this->format_warning_message("Cette note de perception a déjà été initialisée et enregistrée", $encaissement->Date_1);
                                }
                                elseif ($encaissement->Status_2 == '2' && $encaissement->Checkerid_10 != '0')
                                {
                                        $result['code'] = "E505";
                                        $result['html'] = $this->format_warning_message("Cette note de perception a déjà été validée dans <strong>Finacle</strong>", $encaissement->Validation_36);
                                }
                                elseif ($encaissement->Status_2 == '3')
                                {
                                        $result['code'] = "E506";
                                        $result['html'] = $this->format_warning_message("Cette note de perception a déjà été reversée", $encaissement->Validation_36, "+1 day");
                                }
                                elseif ($encaissement->Status_2 == '5' || $encaissement->Status_2 == '6')
                                {
                                        $result['code'] = "E507";
                                        $result['html'] = $this->format_warning_message("Cette note de perception est en régulation mais déjà enregistrée ", $encaissement->Date_1);
                                }
                                elseif ($encaissement->Status_2 == '7')
                                {
                                        $result['code'] = "E508";
                                        $result['html'] = $this->format_warning_message("Cette note de perception est en régulation, en attente de confirmation dans Logirad, mais déjà enregistrée ", $encaissement->Date_1);
                                }
                                else
                                {
                                        $result['code'] = "E999";
                                        $result['html'] = $this->format_warning_message("Un problème est survenu ou la note est introuvable — aucun traitement applicable disponible");
                                }
                        }
                        elseif (isset($integrations->Id_0) && $integrations->Status_2 == 1)
                        {
                                $result['code'] = $integrations->Id_0;
                        }
                        elseif (isset($integrations->Id_0) && $integrations->Status_2 == 2)
                        {
                                $result['html'] = $this->format_warning_message("Cette note de perception a déjà été payée et confirmée avec succès dans Logirad");
                                $result['code'] = "E504";
                        }
                        else
                        {
                                $result['code'] = "E200";
                        }

                        return $result;
                }

                public function check_paiement_tresor_immatriculation_by_reference($reference)
                {
                        $encaissement = $this->get_paiement_tresor_immatriculation_by_reference($reference);
                        $result = [];

                        if (!empty($encaissement) || $encaissement != NULL)
                        {
                                $result['code'] = "E409";
                                $result['message'] = $this->format_warning_message("Cette note de perception existe déjà.", $encaissement->Date_1);
                                $result['id'] = $encaissement->Id_0;
                        }
                        else
                        {
                                $result['code'] = "E200";
                                $result['message'] = "La référence de la note de perception est disponible.";
                                $result['id'] = null;
                        }
                        return $result;
                }

                public function check_integration_immatriculation_by_reference($reference)
                {
                        $immatriculation = $this->get_integration_immatriculation_by_reference($reference);

                        $result = [];

                        if ((!empty($immatriculation) || $immatriculation != NULL) && $immatriculation->Status_2==2)
                        {
                                $result['code'] = "E409";
                                $result['message'] = $this->format_warning_message("Cette note de perception existe déjà ou a été déjà traitée.", $immatriculation->Date_1);
                                $result['id'] = $immatriculation->Id_0;
                        }
                        else
                        {
                                $result['code'] = "E200";
                                $result['message'] = "La référence de la note de perception est disponible.";
                                $result['id'] = null;
                        }

                        return $result;
                }

                public function format_warning_message($text, $date = null, $modif = null)
                {
                        if ($date !== null)
                        {
                                if (!is_int($date))  $date = strtotime($date);
                                if ($modif) $date = strtotime($modif, $date);

                                $date_formatted = strftime('%d/%m/%Y', $date);
                        }

                        return '<div class="alert aWarning text-white">Désolé!... '
                                . $text
                                . ((isset($date_formatted)) ? ', le <strong>' . $date_formatted . '</strong>' : ' !')
                                . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }


                public function formatage_amount($amount)
                {
                        return str_replace([',', ' '], ['.', ''], $amount);
                }

                public function generate_unique_reference()
                {
                        $datetimePart = date('ymdHis'); // 6 (ymd) + 6 (His) = 12 caractères
                        $randomPart = substr(bin2hex(random_bytes(4)), 0, 8); // 8 caractères aléatoires

                        return $datetimePart . $randomPart; // total : 12 + 8 = 20 caractères
                }

                public function generate_unique_reference_for_sftp()
                {
                        // Horodatage haute résolution (microsecondes)
                        $timePart = microtime(true);

                        // Génère un hash unique à partir du temps + random
                        $hash = hash('sha256', $timePart . random_bytes(8));

                        // On prend les 24 premiers caractères du hash
                        $unique_ref = substr($hash, 0, 16).$this->session->userdata['user_id'];

                        return $unique_ref;
                }

                public function formatage_text($data=NULL)
                {
                        return $data;
                }

                public function get_data_cbs_journalisation($paiement_data, $instructions, $note, $type)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        if(!empty($paiement_data) && !empty($instructions))
                        {
                                $total_amount_debited = $this->sum_instructions_amount_debited($instructions);
                                $total_amount_credited = $this->sum_instructions_amount_credited($instructions);

                                $data = array();

                                $data ['Date_1'] = gmdate('Y-m-d h:i:s');
                                $data ['Status_2'] = '1';
                                $data ['Account_3'] = $this->session->userdata['account_id'];
                                $data ['Creator_4'] = $this->session->userdata['user_id'];
                                $data ['Office_7'] = $note->Servicetype_19;
                                $data ['Amountdebited_8'] = $total_amount_debited;
                                $data ['Amountcredited_9'] = $total_amount_credited;
                                $data ['Instructions_11'] = json_encode($instructions);
                                $data ['Nbinstructions_12'] = count($instructions);
                                $data ['Noteamount_13'] = $note->Amount_10;
                                $data ['Noteid_14'] = $note->Id_0;
                                $data ['Branch_15'] = $note->Guichet_32;

                                $data ['Account_16'] = $this->get_account_to_debit($instructions);

                                $data ['Designation_17'] = $this->remove_all_special_characters($note->Requerant_9);
                                $data ['Nif_18'] = $note->Nif_8;
                                $data ['Type_19'] = $type;

                                $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                        }
                        else
                        {
                                $return = ['code' => 404,'message'=>'valid'];
                        }

                        return $return;
                }

                public function get_account_to_debit($instructions)
                {
                        $account = array();

                        foreach($instructions as $row)
                        {
                                $account = $row['Compte_9'];

                                break;
                        }

                        return $account;
                }

                public function clean_array_special_characters(array $data)
                {
                        foreach ($data as $key => $value)
                        {
                                if (is_array($value))
                                {
                                        // Appel récursif pour sous-tableaux
                                        $data[$key] = $this->clean_array_special_characters($value);
                                }
                                else
                                {
                                        // Nettoyage de la valeur (si string uniquement)
                                        if (is_string($value))
                                        {
                                                if($key == 'Libelle_12')
                                                {
                                                        $data[$key] = $this->remove_all_special_characters($value);
                                                }
                                        }
                                }
                        }

                        return $data;
                }

                public function get_data_integration_sftp($office_data, $path, $id, $reference)
                {
                        $data = [];

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Creator_4'] = $this->session->userdata['user_id'];
                        $data['Office_7'] = $office_data['office'];
                        $data['Amountdebited_8'] = $office_data['amount_debited'];
                        $data['Amountcredited_9'] = $office_data['amount_credited'];
                        $data['Bankaccount_10'] = $office_data['bankaccount'];
                        $data['Nbinstructions_11'] = $office_data['nbinstructions'];
                        $data['Nnotes_12'] = $office_data['nnotes'];
                        $data['Journalisationid_13'] = json_encode($office_data['journalisationid']);
                        $data['Noteids_14'] = json_encode($office_data['noteids']);
                        $data['Branch_15'] = $_SESSION['Logiref_guichet'];
                        $data['Path_16'] = $path;
                        $data['Paymenttype_17'] = 'comptant';
                        $data['Treatmentid_18'] = $id;
                        $data['Logirefid_19'] = $reference;


                        return $data;
                }

                public function get_instructions_by_office_from_journalisation($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $instructions_by_office = [];

                        foreach($data as $row)
                        {
                                $ids[] = json_decode($row['journalisationid'], true);
                        }

                        $tab = array_merge(...$ids);

                        # implode le tableau pour avoir une chaine des ids
                        $ids = implode(',',$tab);

                        $raw_journalisation = $this->get_instructions_from_journalisation_by_id($ids);

                        # aggregate instructions by office
                        foreach($raw_journalisation as $row)
                        {
                                $instructions_by_office[$row->Office_7][] = $row;
                        }

                        return $instructions_by_office;
                }

                public function sum_instructions_amount_debited($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $total_amount_debited = 0;

                        foreach($data as $row)
                        {
                                $total_amount_debited = $row['Montant_10'] + $total_amount_debited;
                        }

                        return $total_amount_debited;
                }

                public function sum_instructions_amount_credited($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $total_amount_credited = 0;

                        foreach($data as $row)
                        {
                                $total_amount_credited = $row['Montant_10'] + $total_amount_credited;
                        }

                        return $total_amount_credited;
                }

                public function sum_instructions_amount_debited_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */

                        $total_amount_debited_by_office = 0;

                        foreach($data as $row)
                        {
                                $total_amount_debited_by_office = $row->Amountdebited_8 + $total_amount_debited_by_office;
                        }

                        return $total_amount_debited_by_office;
                }

                public function sum_instructions_amount_credited_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $total_amount_credited_by_office = 0;

                        foreach($data as $row)
                        {
                                $total_amount_credited_by_office = $row-> Amountcredited_9  + $total_amount_credited_by_office;
                        }

                        return $total_amount_credited_by_office;
                }

                public function sum_nb_notes_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $nb_notes_by_office = 0;

                        foreach($data as $row)
                        {
                                $nb_notes_by_office = $nb_notes_by_office  + 1;
                        }

                        return $nb_notes_by_office;
                }

                public function sum_nb_instructions_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $nb_instructions_by_office = 0;

                        foreach($data as $row)
                        {
                                $nb_instructions_by_office = $row->Nbinstructions_12  + $nb_instructions_by_office;
                        }

                        return $nb_instructions_by_office;
                }

                public function construct_instructions_id_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $instructions_id_by_office = [];

                        foreach($data as $row)
                        {

                                $instructions_id_by_office[] = $row->Id_0;
                        }

                        return $instructions_id_by_office;
                }

                public function construct_notes_id_by_office($data)
                {
                        /*
                        * --------------------------------------------
                        * Variable initialization
                        * --------------------------------------------
                        */
                        $notes_id_by_office = [];

                        foreach($data as $row)
                        {

                                $notes_id_by_office[] = $row->Noteid_14;
                        }

                        return $notes_id_by_office;
                }

                public function save_cbs_journalisation($data, $id)
                {
                        $this->set_table('logiref_cbs_integration_journalisation_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function update_cbs_journalisation_by_noteid($data, $id)
                {
                        $this->set_table('logiref_cbs_integration_journalisation_immatriculation', 'Noteid_14', 'Noteid_14 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function get_first_immatriculation_instruction_status($paiementId)
                {
                        $row = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('Status_2')
                                ->where('Paiementid_4', $paiementId)
                                ->where('Priority_27', 0)
                                ->orderBy('Id_0', 'ASC')
                                ->get(1)
                                ->getRow();

                        return isset($row->Status_2) ? (int) $row->Status_2 : null;
                }

                public function has_partially_completed_primary_instructions($paiementId)
                {
                        $instructions = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('Status_2, Montant_10')
                                ->where('Paiementid_4', $paiementId)
                                ->where('Priority_27', 0)
                                ->orderBy('Id_0', 'ASC')
                                ->limit(3)
                                ->get()
                                ->getResult();

                        if (empty($instructions))
                        {
                                return false;
                        }

                        $isCompleted = static function ($instruction)
                        {
                                $amount = (float) $instruction->Montant_10;
                                $status = (int) $instruction->Status_2;

                                return ($amount > 0 && $status === 2)
                                        || ($amount == 0.0 && $status === 1);
                        };

                        // Le statut 6 est réservé au scénario où le débit principal
                        // (première écriture) a réussi, mais pas toutes les suivantes.
                        if (!$isCompleted($instructions[0]))
                        {
                                return false;
                        }

                        if (count($instructions) < 3)
                        {
                                return true;
                        }

                        foreach (array_slice($instructions, 1) as $instruction)
                        {
                                if (!$isCompleted($instruction))
                                {
                                        return true;
                                }
                        }

                        return false;
                }

                public function update_online_immatriculation_journalisation($paiementId)
                {
                        return $this->db->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->where('Noteid_14', $paiementId)
                                ->update([
                                        'Status_2' => 2,
                                        'Date_1' => date('Y-m-d H:i:s')
                                ]);
                }

                /*
                * Save Information: insert or update an array
                * Use: inserting or updating
                * P.S: Ajoutez vous methodes ci-dessous!!
                *  *************************************************************************************************************************SECTION 5
                */

                public function check_print_attestation($reference)
                {
                        $builder = $this->db->table("logiref_cbs_instructions_immatriculation")
                                ->where('Reference_14', $reference);

                        if(!$this->is_license_plate_web_service_validation_enabled())
                        {
                                $builder->where('Priority_27', 0);
                        }

                        $paiement = $builder->orderBy('Id_0', 'ASC')->get()->getResult();

                        if($this->is_license_plate_web_service_validation_enabled())
                        {
                                return $this->are_license_plate_sequences_completed($paiement);
                        }

                        $count_check = 0;

                        foreach ($paiement as $item)
                        {
                                if(($item->Montant_10 > 0 && $item->Status_2 == 2) || ($item->Montant_10 == 0 && $item->Status_2 == 1))
                                {
                                        $count_check++;
                                }
                        }

                        $check_print_attestation = ($count_check == 3) ? true : false;

                        return $check_print_attestation;
                }

               public function get_return_immatriculation_code($id)
               {
                        $builder = $this->db->table('logiref_cbs_instructions_immatriculation')
                                ->select('Id_0, Montant_10, Status_2, Priority_27')
                                ->where('Paiementid_4', $id);

                        if(!$this->is_license_plate_web_service_validation_enabled())
                        {
                                $builder->where('Priority_27', 0);
                        }

                        $instructions = $builder->orderBy('Id_0', 'ASC')->get()->getResult();

                        if($this->is_license_plate_web_service_validation_enabled())
                        {
                                return $this->are_license_plate_sequences_completed($instructions) ? 200 : 411;
                        }

                        // Un paiement d'immatriculation est constitué de trois
                        // instructions principales (montant, frais et TVA). Le JSON
                        // CBS reste un historique des tentatives et ne doit pas
                        // bloquer une confirmation lorsque les instructions ont été
                        // vérifiées puis marquées comme intégrées.
                        if(count($instructions) !== 3)
                        {
                                return 411;
                        }

                        foreach($instructions as $instruction)
                        {
                                $amount = (float) $instruction->Montant_10;
                                $status = (int) $instruction->Status_2;

                                if($amount > 0 && $status !== 2)
                                {
                                        return 411;
                                }

                                // Les anciennes instructions sans montant ne sont
                                // pas envoyées à Amplitude et peuvent rester à 1.
                                if($amount == 0.0 && !in_array($status, [1, 2], true))
                                {
                                        return 411;
                                }
                        }

                        return 200;
               }

                public function save_paiement_tresor($data)
                {
                        $this->set_table('logiref_paiements_tresor_immatriculation', 'Id_0', 'Id_0 DESC');
                        $return = $this->saveDataInv($data);
                        return $return;
                }

                public function save_paiement_propre($data)
                {
                        $this->set_table('logiref_paiements_propres_immatriculation', 'Id_0', 'Id_0 DESC');
                        $return = $this->saveDataInv($data);
                        return $return;
                }

                public function save_email_log($data)
                {
                        $this->set_table('logiref_email_logs_immatriculation', 'Id_0', 'Id_0 DESC');
                        $return = $this->saveDataInv($data);
                        return $return;
                }

                public function update_payment_tresor($data, $id) {
                        $this->set_table('logiref_paiements_tresor_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function update_integration_immatriculation_validation($id,$validation_status)
                {
                        $validation_data['Status_2'] = $validation_status;
                        $validation_data['Validation_30'] =date('Y-m-d H:i:s');
                        $validation_data['Checkerid_36'] = $this->session->userdata['user_id'];
                        $this->set_table('logiref_integration_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($validation_data, $id);
                }

                public function get_online_immatriculation_payments_by_status($status, $limit = 500)
                {
                        return $this->db->table('logiref_integration_immatriculation')
                                ->select('*')
                                ->where('Status_2', $status)
                                ->where('ValidateBySiop_39', 1)
                                ->orderBy('Date_1', 'ASC')
                                ->limit((int) $limit)
                                ->get()
                                ->getResult();
                }

                public function process_online_immatriculation_payment($id)
                {
                        $note = $this->get_integration_immatriculation($id);

                        if(empty($note) || empty($note->Id_0))
                        {
                                return [
                                        'code' => 404,
                                        'status' => false,
                                        'message' => 'Paiement introuvable.'
                                ];
                        }

                        if((int) $note->Status_2 !== 9)
                        {
                                return [
                                        'code' => 409,
                                        'status' => false,
                                        'message' => 'Ce paiement n’est pas en attente de traitement.'
                                ];
                        }

                        $now = date('Y-m-d H:i:s');
                        $userId = isset($this->session->userdata['user_id']) ? $this->session->userdata['user_id'] : 0;

                        $onlineJournalisationsCount = $this->db
                                ->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->where('Noteid_14', $note->Id_0)
                                ->groupStart()
                                        ->whereIn('Type_19', ['branchless', ''])
                                        ->orWhere('Type_19 IS NULL', null, false)
                                ->groupEnd()
                                ->countAllResults();

                        if ($onlineJournalisationsCount === 0)
                        {
                                return [
                                        'code' => 409,
                                        'status' => false,
                                        'message' => 'Aucune journalisation de paiement en ligne valide n’a été trouvée.'
                                ];
                        }

                        $this->db->transStart();

                        $this->db->table('logiref_integration_immatriculation')
                                ->where('Id_0', $note->Id_0)
                                ->update([
                                        'Status_2' => 2,
                                        'Checkerid_36' => $userId,
                                        'Validation_30' => $now
                                ]);

                        $this->db->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->where('Noteid_14', $note->Id_0)
                                ->groupStart()
                                        ->whereIn('Type_19', ['branchless', ''])
                                        ->orWhere('Type_19 IS NULL', null, false)
                                ->groupEnd()
                                ->update([
                                        'Status_2' => 2,
                                        'Date_1' => $now,
                                        'Type_19' => 'branchless'
                                ]);

                        $this->db->transComplete();

                        if($this->db->transStatus() === false)
                        {
                                return [
                                        'code' => 500,
                                        'status' => false,
                                        'message' => 'Le traitement du paiement a échoué.'
                                ];
                        }

                        return [
                                'code' => 200,
                                'status' => true,
                                'message' => 'Paiement traité avec succès.'
                        ];
                }

                public function update_integration_immatriculation_journalisation()
                {
                        // Get the note lines by reference
                        $immatriculation = $this->get_integration_immatriculation_by_reference($_POST['Noteid_26']);

                        if($immatriculation->Id_0)
                        {
                                $data['Status_2'] = 2;
                                $this->update_cbs_journalisation_by_noteid($data, $immatriculation->Id_0);
                        }
                        else
                        {
                                log_message('error_journalisation_immatriculation', 'l\'update de la jounalidation n\'a pas abouti, noteid manquant ');
                        }
                }

                public function update_payment_validation($id,$validation_status)
                {
                        $validation_data['Status_2'] = $validation_status;
                        $validation_data['Checkerid_10'] = $this->session->userdata['user_id'];
                        $validation_data['Validation_36'] =date('Y-m-d H:i:s');
                        $this->set_table('logiref_paiements_tresor_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($validation_data, $id);
                }
                public function update_payment_tresor_by_reference($reference,$validation_status=null)
                {
                        $validation_data['Status_2'] = $validation_status;
                        $validation_data['Checkerid_10'] = $this->session->userdata['user_id'];
                        $validation_data['Validation_36'] =date('Y-m-d H:i:s');
                        $builder=$this->db->table("logiref_paiements_tresor_immatriculation");
                        return $builder->update($validation_data,['Noteid_26'=>$reference]);
                }

                public function update_payment_propre_by_reference($reference,$validation_status=null)
                {
                        $validation_data['Status_2'] = $validation_status;
                        $validation_data['Checkerid_10'] = $this->session->userdata['user_id'];
                        $validation_data['Validation_36'] =date('Y-m-d H:i:s');
                        $builder=$this->db->table("logiref_paiements_propres_immatriculation");
                        return $builder->update($validation_data,['Noteid_26'=>$reference]);
                }

                public function update_payment_tresor_data($reference,$data)
                {
                        $builder = $this->db->table("logiref_paiements_tresor_immatriculation");
                        return $builder->update($data,['Noteid_26'=> $reference]);
                }

                public function update_payment_propre_data($reference,$data)
                {
                        $builder=$this->db->table("logiref_paiements_propres_immatriculation");
                        return $builder->update($data,['Noteid_26'=> $reference]);
                }

                public function save_objects_name($data, $id)
                {
                        $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function save_integration_summary($data, $id)
                {
                        $this->set_table('logiref_cbs_treatment_sftp_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function save_integration_sftp($data, $id)
                {
                        $this->set_table('logiref_integration_sftp_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv($data, $id);
                }

                public function update_journalisation_by_ids($data, $ids)
                {
                        if (!is_array($ids))
                        $ids = array($ids);

                        $return = $this->db->table('logiref_cbs_integration_journalisation_immatriculation')
                                ->whereIn('Id_0', $ids)
                                ->update($data);

                        return $return;
                }

                public function update_notes($data, $ids, $requiredStatus = null) {
                        if (!is_array($ids))
                        $ids = array($ids);

                        $builder = $this->db->table('logiref_integration_immatriculation')
                                ->whereIn('Id_0', $ids);

                        if ($requiredStatus !== null)
                        {
                                $builder->where('Status_2', $requiredStatus);
                        }

                        $return = $builder->update($data);

                        return $return;
                }

                public function delete_paiement_tresor($id)
                {
                        $this->set_table('logiref_paiements_tresor_immatriculation', 'Id_0', 'Id_0 DESC');
                        return $this->saveDataInv(array('Status_2' => '0'), $id);
                }

                public function delete_propres_immatriculation($noteId)
                {
                        try {
                                if (empty($noteId)) {
                                        return false;
                                }

                                $builder = $this->db->table('logiref_paiements_propres_immatriculation');

                                $builder->where('Noteid_26', $noteId);
                                $builder->delete();

                                return $this->db->affectedRows();

                        } catch (\Exception $e) {
                                log_message('error', 'DELETE PROPRES ERROR: ' . $e->getMessage());
                                return false;
                        }
                }

                public function delete_tresor_immatriculation($noteId)
                {
                        try {
                                if (empty($noteId)) {
                                        return false;
                                }

                                $builder = $this->db->table('logiref_paiements_tresor_immatriculation');

                                $builder->where('Noteid_26', $noteId);
                                $builder->delete();

                                return $this->db->affectedRows();

                        } catch (\Exception $e) {
                                log_message('error', 'DELETE TRESOR ERROR: ' . $e->getMessage());
                                return false;
                        }
                }

                public function delete_immatriculation_journalisation($noteId)
                {
                        try {
                                if (empty($noteId)) {
                                        return false;
                                }

                                $builder = $this->db->table('logiref_cbs_integration_journalisation_immatriculation');

                                $builder->where('Noteid_14', $noteId);
                                $builder->delete();

                                return $this->db->affectedRows();

                        } catch (\Exception $e) {   
                                log_message('error', 'DELETE TRESOR ERROR: ' . $e->getMessage());
                                return false;
                        }
                }

                public function delete_instructions_by_note($id_plaque)
                {
                        try {
                                if (empty($id_plaque)) {
                                        return false;
                                }

                                $builder = $this->db->table('logiref_cbs_instructions_immatriculation');

                                $builder->where('Paiementid_4', $id_plaque);
                                $builder->delete();

                                return $this->db->affectedRows();

                        } catch (\Exception $e) {
                                log_message('error', 'DELETE INSTRUCTIONS ERROR: ' . $e->getMessage());
                                return false;
                        }
                }

                public function get_integration_immatriculation($id)
                {
                        $builder=$this->db->table("logiref_integration_immatriculation");
                        $result=$builder->select('*')->where("Id_0",$id)->get()->getRow();
                        return $result;
                }

                public function get_integration_immatriculation_by_reference($numero_note)
                {
                        $builder = $this->db->table("logiref_integration_immatriculation");

                        $result = $builder->select('*')
                                        ->where("Reference_6", $numero_note)
                                        ->where("Status_2 !=", 0)
                                        ->get()
                                        ->getRow();

                        return $result;
                }

                public function get_integration_immatriculation_by_logirefid($logirefid)
                {
                        $builder=$this->db->table("logiref_integration_immatriculation");
                        $result=$builder->select('*')->where("Logirefid_31",$logirefid)->get()->getRow();
                        return $result;
                }

                public function get_instructions_immatriculation_by_id($id)
                {
                        $this->set_table('logiref_cbs_instructions_immatriculation d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $id), TRUE);

                        return $lines;
                }

                public function get_instructions_from_journalisation_by_id($ids)
                {
                        $this->set_table('logiref_cbs_integration_journalisation_immatriculation d', 'd.Id_0', 'd.Id_0 DESC');
                        $lines = $this->get_by(array('Id_0' => $ids), TRUE);

                        return $lines;
                }

                public function get_cbs_returns_immatriculation($id) {
                        if($this->is_license_plate_web_service_validation_enabled())
                        {
                                $returns = $this->db->table('logiref_cbs_returns_immatriculation')
                                        ->where('Paiementid_4', $id)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get()
                                        ->getResult();

                                if(empty($returns))
                                {
                                        return null;
                                }

                                $merged_result = array();

                                foreach($returns as $return)
                                {
                                        $result = json_decode($return->Result_6 ?? '', true);

                                        if(is_array($result))
                                        {
                                                $merged_result = array_replace($merged_result, $result);
                                        }
                                }

                                $latest_return = end($returns);
                                $latest_return->Result_6 = json_encode($merged_result);

                                return $latest_return;
                        }

                        $this->set_table('logiref_cbs_returns_immatriculation I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Paiementid_4' => $id), TRUE);
                }

                public function get_paiement_immatriculation_attempts($id = NULL,$priority = NULL)
                {
                        $this->set_table('logiref_cbs_instructions_immatriculation I', 'I.Id_0', 'I.Id_0 DESC');
                        $data= $this->get_by(array('Paiementid_4' => $id,'Priority_27'=>$priority), TRUE);
                        if(!empty($data))
                        {
                                return $data->Attempts_29;
                        }
                        else
                        {
                                return 0;
                        }
                }

                public function update_integration_immatriculation_attempts($paiement_id, $priority)
                {
                        $attempts = $this->get_paiement_immatriculation_attempts($paiement_id, $priority);
                        $data = array(
                                'Attempts_29' => $attempts + 1,
                        );

                        $return = $this->db->table('logiref_cbs_instructions_immatriculation')
                        ->where('Paiementid_4', $paiement_id)
                        ->where('Priority_27',$priority);

                        return  $return->update($data);
                }

                public function save_immatriculation($data)
                {
                        $this->set_table("logiref_integration_immatriculation","Id_0","Id_0 DESC");
                        return $this->saveDataInv($data);
                }

                public function update_immatriculation($data,$id)
                {
                        $this->set_table("logiref_integration_immatriculation","Id_0","Id_0 DESC");
                        return $this->saveDataInv($data,$id);
                }

                public function immatriculation_migrate_note($data)
                {
                        $idnote = $data;

                        $obj = $this->get_paiement_info();
                        $declaration = $this->get_integration_immatriculation($idnote);

                        $note_percetion = json_decode($declaration->Notedata_25,true);
                        $applicant = json_decode($declaration->Applicant_12,true);
                        $beneficiaires = json_decode($declaration->Beneficiaries_13);
                        $vehicule = json_decode($declaration->Vehicule_41,true);

                        // $noteDate = explode("-",$declaration->Dateordonance_13);
                        $obj->Id_0 = isset($declaration->Id_0) ? $declaration->Id_0:"";
                        $obj->Status_2 = $declaration->Status_2;
                        $obj->Logirefid_4 = $declaration->Logirefid_31;
                        $obj->Makerid_9 = $declaration->User_34;
                        $obj->Checkerid_10 = $declaration->Checkerid_36;
                        $obj->Montant_11 = $declaration->Amount_10;
                        $obj->Devise_12 = $declaration->Devise_11;
                        $obj->Designation_14 = $declaration->Requerant_9;
                        $obj->Nif_13 = $declaration->Nif_8;
                        $obj->Beneficaire_15 = 'DGI';
                        $obj->Service_16 = $declaration->Servicetype_19;
                        $obj->Typerecette_17 = $declaration->Typerecette_16;
                        $obj->Artbudgetaire_18 = $declaration->Article_23;
                        $obj->Mode_19=$declaration->Mode_17;
                        $obj->Agence_20 = $_SESSION['Logiref_agence'];

                        $obj->Contrevaleur_22 = null; // Tjrs en CDF
                        $obj->Commission_23=$declaration->Commission_14;
                        $obj->Devise_24=$declaration->Devise_15;
                        $obj->Noteid_26 = $declaration->Reference_6;

                        $date_note = date('Y-m-d',strtotime($note_percetion['date_emission']));

                        $obj->Notedate_27= $date_note;
                        $obj->Notemontant_28= $declaration->Totalamount_28;
                        $obj->Notedevise_29= $declaration->Devise_11;

                        $beneficiaries=[];

                        foreach($beneficiaires as $beneficiary)
                        {
                                $ben['beneficiary_code']=$beneficiary->BeneficiaryCode_16;
                                $ben['beneficiary_name']=$beneficiary->BeneficiaryName_17;
                                $ben['amount']=$beneficiary->Amount_10;
                                $ben['currency']=$beneficiary->Currency_11;
                                $beneficiaries[] = $ben;
                        }

                        $references['noteperception']=$note_percetion;
                        $references['applicant']=$applicant;
                        $references['beneficiaries']=$beneficiaries;
                        $references['validateBySiop'] = $declaration->ValidateBySiop_39;
                        $references['vehicule'] = $vehicule;

                        $obj->Notereference_30 = json_encode($references,JSON_UNESCAPED_UNICODE);
                        $obj->Datevaleur_31 = gmdate('Y-m-d');
                        $obj->Reference_32 = $declaration->Refop_18;
                        $obj->Compte_33 = $declaration->Accountholder_26;
                        $obj->Devise_34 = $declaration->Devise_27;
                        $obj->Taux_41 = $declaration->Taux_22;

                        return $obj;
                }

                public function build_integration_data($json_data)
                {
                        $immatriculation_data = array();

                        if(!empty($json_data))
                        {

                                $note_data=array();

                                $account_id=(isset($this->session->userdata['account_id']))?$this->session->userdata['account_id']:"";

                                $note_perception_data = json_decode($json_data,true);

                                if(isset($note_perception_data['note_perception']))
                                {
                                        $reference = $note_perception_data['note_perception']['NumeroNote_7'];
                                        $amount = (float) $note_perception_data['note_perception']['AmountApplication_14'] + (float) $note_perception_data['note_perception']['AmountInsurance_16'];
                                        $currency = $note_perception_data['note_perception']['Currency_11'];
                                        $note_data = $note_perception_data['note_perception'];
                                        $note_data['date_emission'] = $note_perception_data['date_emission'];
                                        $commission_frais = $note_perception_data['note_perception']['CommisionFeeApplication_15'];
                                        $devise_commission_frais = $note_perception_data['note_perception']['Currency_11'];
                                        $commission_frais_tva = $note_perception_data['note_perception']['CommisionFeeApplicationTva_18'];
                                        $montant_assurance = $note_perception_data['note_perception']['AmountInsurance_16'];
                                        $commission_frais_assurance = $note_perception_data['note_perception']['CommisionFeeInsurance_17'];
                                        $commission_frais_assurance_tva = $note_perception_data['note_perception']['CommisionFeeInsuranceTva_19'];
                                        $taux = $note_perception_data['note_perception']['AppliedRate_20'];
                                }

                                if(isset($note_perception_data['applicant']))
                                {
                                        $nif = $note_perception_data['applicant']['Nif_8'];

                                        if(isset($note_perception_data['applicant']['EntrepriseDesignation_23']) && !empty($note_perception_data['applicant']['EntrepriseDesignation_23'])) :
                                                $designation = $note_perception_data['applicant']['EntrepriseDesignation_23'];
                                        else:
                                                $designation = $note_perception_data['applicant']['Firstname_9']."  ".$note_perception_data['applicant']['Lastname_10']."  ".$note_perception_data['applicant']['Postname_11'];
                                        endif;

                                        $applicant=json_encode($note_perception_data['applicant']);
                                }

                                if(isset($note_perception_data['beneficiaries']))
                                {
                                        if(!empty($note_perception_data['beneficiaries']))
                                        {
                                                $beneficiaries=$note_perception_data['beneficiaries'];
                                        }
                                        else
                                        {
                                                $beneficiaries=[];
                                        }
                                }

                                if(isset($note_perception_data['nature_paiement']))
                                {
                                        $recette_code=$note_perception_data['nature_paiement']['RecetteCode_9'];
                                        $recette=$note_perception_data['nature_paiement']['TypeName_8'];
                                }

                                $province = array();
                                if(isset($note_perception_data['province']))
                                {
                                        $province_code=$note_perception_data['province']['ProvinceCode_8'];
                                        $province_name=$note_perception_data['province']['ProvinceName_7'];

                                        $province['province_code']=$province_code;
                                        $province['province_name']=$province_name;
                                }

                                $vehicule = json_encode($note_perception_data['vehicle']);

                                if(isset($note_perception_data['insurance_beneficiary']))
                                {
                                        if(!empty($note_perception_data['insurance_beneficiary']))
                                        {
                                                $insurance = new stdClass();
                                                $insurance->Id_0 = $note_perception_data['insurance_beneficiary']['Id_0'];
                                                $insurance->Date_1 = $note_perception_data['insurance_beneficiary']['Date_1'];
                                                $insurance->Status_2 = $note_perception_data['insurance_beneficiary']['Status_2'];
                                                $insurance->Account_3 = $note_perception_data['insurance_beneficiary']['Account_3'];
                                                $insurance->Creator_4 = null;
                                                $insurance->Changes_5 = $note_perception_data['insurance_beneficiary']['Changes_5'];
                                                $insurance->Changer_6 = null;
                                                $insurance->ApplicationTypeId_7 = "";
                                                $insurance->ApplicantType_8 = "";
                                                $insurance->PlateTypeId_9 = "";
                                                //$insurance->Amount_10 = $note_perception_data['insurance_beneficiary']['InsuranceAmount_13'];
                                                $insurance->Amount_10 = $montant_assurance;
                                                $insurance->Currency_11 = $note_perception_data['insurance_beneficiary']['Currency_14'];
                                                $insurance->ValidFrom_12 = "";
                                                $insurance->ValidTo_13 = "";
                                                $insurance->TariffId_14 = "";
                                                $insurance->BeneficiaryId_15 = $note_perception_data['insurance_beneficiary']['InsuranceProvider_11'];
                                                $insurance->BeneficiaryCode_16 = $note_perception_data['insurance_beneficiary']['InsuranceProvider_11'];
                                                $insurance->BeneficiaryName_17 = $note_perception_data['insurance_beneficiary']['InsuranceProvider_11'];

                                                $beneficiaries[]= $insurance;
                                        }
                                }

                                $immatriculation_data['Id_0']='';
                                $immatriculation_data['Date_1']=date("Y-m-d h:i:s");
                                $immatriculation_data['Status_2']=1;
                                $immatriculation_data['Account_3']=$account_id;
                                $immatriculation_data['Changer_4']='';
                                $immatriculation_data['Changes_5']='';
                                $immatriculation_data['Reference_6']=$reference;
                                $immatriculation_data['Nif_8']=$nif;
                                $immatriculation_data['Requerant_9'] = $this->sanitize_requester_name($designation);
                                $immatriculation_data['Amount_10']=$amount;
                                $immatriculation_data['Devise_11']=$currency;
                                $immatriculation_data['Applicant_12']=html_entity_decode($applicant);
                                $immatriculation_data['Beneficiaries_13']=!empty($beneficiaries) ? json_encode($beneficiaries) : null;
                                $immatriculation_data['Commission_14']=$commission_frais;
                                $immatriculation_data['Devise_15']=$devise_commission_frais;
                                $immatriculation_data['Typerecette_16']=$recette_code;
                                $immatriculation_data['Servicetype_19']=$province_code;
                                $immatriculation_data['Taux_22']=$taux;
                                $immatriculation_data['Article_23']= $immatriculation_data['Article_23'] = html_entity_decode(html_entity_decode($recette, ENT_QUOTES | ENT_HTML5, 'UTF-8'),ENT_QUOTES | ENT_HTML5, 'UTF-8');
                                $immatriculation_data['Articlecode_24']=$recette_code;
                                $immatriculation_data['Notedata_25']=json_encode($note_data);
                                $immatriculation_data['Logirefid_31']=$this->generate_unique_reference().$this->session->userdata['user_id'];
                                $immatriculation_data['Guichet_32']=isset($_SESSION['Logiref_guichet'])?$_SESSION['Logiref_guichet']:"";
                                $immatriculation_data['User_34']=isset($this->session->userdata['user_id'])?$this->session->userdata['user_id']:0;
                                $immatriculation_data['Province_37']=json_encode($province);
                                $immatriculation_data['Vehicule_41']=html_entity_decode($vehicule);
                        }

                        return $immatriculation_data;
                }

                public function saveDataInv($data, $id = NULL, $escape = TRUE)
                {
                        //Set timestamps
                        if ($this->useTimestamps == TRUE) {
                                $now = date('Y-m-d H:i:s');
                                $id || $data[$this->createdField] = $now;
                                (empty($this->updatedField)) || $data[$this->updatedField] = $now;
                        }

                        if ($escape) {
                                foreach ($data as $key => $value) {

                                        if (is_string($value) && !$this->is_json($value)) {

                                                // Supprimer les balises HTML (anti XSS)
                                                $value = strip_tags($value);

                                                // Supprimer caractères invisibles dangereux
                                                $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);

                                                // Nettoyage espaces
                                                $value = trim($value);

                                                $data[$key] = $value;
                                        }
                                }
                        }

                        //Insert
                        if ($id === NULL) {
                                !isset($data[$this->primaryKey]) || $data[$this->primaryKey] = NULL;
                                $this->db->table($this->table)->insert($data);
                                $id = $this->db->insertID();
                        }

                        //Update
                        else {
                                unset($data[$this->primaryKey]);
                                $this->db->table($this->table)->update($data, [$this->primaryKey => $id]);
                        }

                        return $id;
                }

                public function remove_all_special_characters($texte)
                {
                        // 1. Décoder les entités HTML (&lt; &gt; &amp; etc.)
                        $texte = html_entity_decode($texte, ENT_QUOTES | ENT_HTML5, 'UTF-8');

                        // 2. Supprimer les accents
                        $texte = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texte);

                        // 3. Supprimer tous les caractères spéciaux
                        $texte = preg_replace('/[^a-zA-Z0-9]/', ' ', $texte);

                        // 4. Nettoyer les espaces multiples
                        $texte = preg_replace('/\s+/', ' ', trim($texte));

                        return $texte;
                }

                public function sanitize_requester_name($name)
                {
                        $name = html_entity_decode(
                                html_entity_decode((string) $name, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                                ENT_QUOTES | ENT_HTML5,
                                'UTF-8'
                        );

                        $transliterated = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name);
                        if ($transliterated !== false)
                        {
                                $name = $transliterated;
                        }

                        $name = preg_replace('/[^a-zA-Z0-9\s]/', '', $name);
                        return preg_replace('/\s+/', ' ', trim($name));
                }

                //Save Log
                public function save_log($data, $prefix = NULL)
                {
                        $name = gmdate('Y-m-d');
                        $file = ROOTPATH . "drive/logs/immatriculation/" .$name."_".$prefix.".log";

                        if (!is_dir(dirname($file))) {
                                mkdir(dirname($file), 0777, true);
                        }

                        file_put_contents(
                                $file,
                                date('Y-m-d H:i:s') . " => " . $data . "\n\n",
                                FILE_APPEND
                        );
                }

        }
