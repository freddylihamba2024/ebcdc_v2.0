<?php

    namespace Modules\Branch\Models;

use stdClasslass;
use App\Models\MY_Transaction;

    class IntegrationModel extends MY_Transaction {
        /* Presentation: 
        * Last update
        * By Glodi on the 12.10.2023
        *  *************************************************************************************************************************SECTION 1
        */

        /*
        * Protected and public variables 
        * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */

        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_ordƒer_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';
        public $options;
        public $ackmessages = array(
            'OK' => 'Cl&ocirc;turer la transaction',
            'KO' => 'Paiement non valid&eacute;',
            '' => ''
        );
        public $bl_status = array(
            '1' => 'Nouveau',
            '2' => 'Ordre de paiement',
            '3' => 'Pay&eacute;',
            '' => ''
        );
        public $prepayments_status = array(
            '1' => 'Non valid&eacute;',
            '2' => 'Paiement valid&eacute;',
            '3' => 'Transaction cl&ocirc;r&eacute;e',
            '4' => 'Paiement non cl&ocirc;tur&eacute;'
        );
        public $declarations_status = array(
            '1' => 'Non valid&eacute;',
            '2' => 'D&eacute;claration valid&eacute;',
            '3' => 'Transaction cl&ocirc;r&eacute;e',
            '4' => 'Paiement non cl&ocirc;tur&eacute;'
        );
        public $prepayments_status_color = array(
            '1' => 'label-upcoming',
            '2' => 'label-ongoing',
            '3' => 'label-completed',
            '4' => 'label-muted'
        );
        public $declarations_status_color = array(
            '1' => 'label-upcoming',
            '2' => 'label-ongoing',
            '3' => 'label-completed',
            '4' => 'label-muted'
        );
        public $note_status = array(
            '1' => 'Nouveau',
            '2' => 'Ordre de paiement',
            '3' => 'Pay&eacute;',
            '' => ''
        );
        public $di_status = array(
            '1' => 'Nouveau',
            '2' => 'Ordre de paiement',
            '3' => 'Confirm&eacute;',
            '4' => 'Pay&eacute;',
            '' => ''
        );
        public $bl_statuscolor = array(
            '1' => 'label-upcoming',
            '2' => 'label-completed',
            '3' => 'label-ongoing'
        );
        public $note_statuscolor = array(
            '1' => 'label-upcoming',
            '2' => 'label-completed',
            '3' => 'label-ongoing'
        );
        public $di_statuscolor = array(
            '1' => 'label-muted',
            '2' => 'label-upcoming',
            '3' => 'label-completed',
            '4' => 'label-ongoing'
        );
        public $sydonia_error_code = array(
            '11' => 'Montant &agrave; payer incorrect',
            '13' => 'D&eacute;claration est introuvable',
            '34' => 'Bulletin de liquidation d&eacute;j&agrave; pay&eacute;',
            '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
            'Ok' => 'Bulltin confirm&eacute;',
            '0' => 'Bulltin confirm&eacute;',
            '' => ''
        );
        public $sydonia_error_message = array(
            'en' => array(
                "1" => 'daybook',
                "2" => 'server',
                "3" => 'modified by a post-entry operation',
                "4" => 'the document is already used',
            ),
            'fr' => array(
                "1" => 'Le journal de caisse pour ce bureau n\'est pas ouvert.',
                "2" => 'SYDONIA ne réponds pas, veuillez refaire l\'operation s\'il vous pla&icirc;t',
                "3" => 'Ce bulletin de liquidation a &eacute;t&eacute; modifi&eacute; par une op&eacute;ration post-entr&eacute;e',
                "4" => 'Ce bulletin est déjà en cours de traitement par vous m&ecirc;me, vous aviez déjà commenc&eacute; le traitement de ce bulletin dans SYDONIA World.'
            )
        );

        public function __construct() {
            parent::__construct();

            # Retrieve options configured based on the bank connected
            if (isset($_SESSION['userdata']['options'])) {
                $this->options = json_decode($_SESSION['userdata']['options'], true);
            } else {
                $this->options = array();
            }
        }

        protected function get_logiref_role(): int
        {
            return (int) ($_SESSION['Logiref_role'] ?? 0);
        }

        protected function restrict_to_current_guichet(): bool
        {
            return in_array($this->get_logiref_role(), [3, 4, 7], true);
        }

        protected function restrict_to_current_agence(): bool
        {
            $role = $this->get_logiref_role();
            return $role > 2 && $role !== 8;
        }

        protected function is_maker_role(): bool
        {
            return in_array($this->get_logiref_role(), [4, 7], true);
        }

        protected function is_validator_role(): bool
        {
            return in_array($this->get_logiref_role(), [3, 8], true);
        }

        /*
        * Get Information: return a single item
        * Use: for creation, for display, for updates
        * List:
        * *************************************************************************************************************************SCETION 2
        */

        public function get_integration_isys_info($id = NULL) {

            if ($id == NULL) {
                $obj = new stdClass();
                $obj->Id_0 = '';
                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                $obj->Status_2 = '';
                $obj->Account_3 = '';
                $obj->Logirefid_4 = $this->generate_unique_reference();
                $obj->Banqueid_5 = ''; //Core Banking ID
                $obj->Description_6 = '';
                $obj->Makerid_7 = '';

                $obj->Montant_8 = '0';
                $obj->Devise_9 = '';
                $obj->Beneficaire_10 = '';
                $obj->Service_11 = '';
                $obj->Typerecette_12 = '';
                $obj->Journee_13 = gmdate('Y-m-d H:i:s');
                $obj->Designation_14 = '';
                $obj->Agence_15 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_16 = ''; // Tjrs en CDF

                $obj->Reference_isys_17 = '';
                $obj->Retourids_18 = '';
                $obj->Retourdetails_19 = '';

                $obj->Taux_20 = '';
                $obj->Devise_21 = '';
                $obj->Nombrepaiement_22 = '';

                return $obj;
            } else {
                $this->set_table('logiref_integration_isys I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_bulletin_info($number = NULL) {
            if ($number == NULL) {
                $bulletin = new stdClass;
                $bulletin->Id_0 = '';
                $bulletin->Date_1 = '';
                $bulletin->Status_2 = '';
                $bulletin->Account_3 = '';
                $bulletin->Designation_27 = '';
                $bulletin->Commission_28 = '';
                $bulletin->Datepaiement_29 = '';
                return $bulletin;
            } else {
                $this->set_table('logiref_bulletins b', 'b.Id_0', 'b.Id_0 DESC');
                return $this->get_by(array('Declaration_12' => $number), TRUE);
            }
        }

        public function get_note_info($id = NULL) {
            if ($id == NULL) {
                $note = new stdClass;
                $note->Id_0 = '';
                $note->Date_1 = '';
                $note->Status_2 = '';
                $note->Account_3 = '';
                $note->Nifclient_7 = '';
                $note->Reference_8 = '';
                $note->Service_9 = '';
                $note->Amount_10 = '';
                $note->Typerecette_12 = '';
                $note->Devise_17 = '';
                $note->Datepaiement_18 = '';
                $note->Document_path_19 = '';
                $note->Banque_20 = '';
                $note->Notedate_21 = '';
                $note->Notemontant_22 = '';
                $note->Notedevise_23 = '';
                $note->Mode_24 = '';
                $note->Ref_titre_25 = '';
                $note->Notereference_26 = '';
                return $note;
            } else {
                $this->set_table('logiref_notes n', 'n.Id_0', 'n.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }
        
        public function get_bulletin_batch_info($id)
        {
                if($id == NULL)
                {
                    $bulletin = new stdClass;
                    $bulletin->Id_0 = '';
                    $bulletin->Date_1 = '';
                    $bulletin->Status_2 = '';
                    $bulletin->Account_3 = '';
                    $bulletin->Designation_15 = '';
                    $bulletin->Commission_20  = '';
                    $bulletin->Bulletins_22  = '';
                    return $bulletin;
                }
                else
                {
                        $this->set_table('logiref_integration_sydonia_batchs b', 'b.Id_0', 'b.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_integration_cbs_info($id = NULL) {

            if ($id == NULL) {
                $obj = new stdClass();
                $obj->Id_0 = NULL;
                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                $obj->Status_2 = '';
                $obj->Account_3 = '';
                $obj->Logirefid_4 = $this->generate_unique_reference();
                $obj->Nombrepaiement_7 = ''; //Core Banking ID
                $obj->Montant_8 = '';
                $obj->Devise_9 = '';
                $obj->Beneficiaire_0 = '';
                $obj->Agence_10 = $_SESSION['Logiref_agence'];
                $obj->Contrevaleur_11 = '';

                $obj->Retourids_13 = '';
                $obj->Retourdetails_14 = '';
                $obj->Retourcbs_15 = '';

                return $obj;
            } else {
                $this->set_table('logiref_integration_cbs p', 'p.Id_0', 'p.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_declaration_info($did = NULL) {
            if ($did == NULL) {
                $declaration = new stdClass();
                $declaration->Id_0 = '';
                $declaration->Date_1 = '';
                $declaration->Status_2 = '';
                $declaration->Account_3 = '';
                $declaration->Creator_4 = '';
                $declaration->Changes_5 = '';
                $declaration->Changer_6 = '';
                $declaration->Subscriber_7 = '';
                $declaration->Category_8 = '';
                $declaration->Information_9 = '';
                $declaration->Amount_10 = '';
                $declaration->Currency_11 = '';
                $declaration->Period_12 = '';
                $declaration->Deadline_13 = '';
                $declaration->Reference_14 = '';
                $declaration->Province_15 = '';
                $declaration->Content_16 = '';
                $declaration->Nif_17 = '';
                $declaration->Nature_18 = '';
                $declaration->Paiementid_19 = '';
                $declaration->Banque_20 = '';
                return $declaration;
            } else {
                $this->set_table('logiref_declarations  d', 'd.Id_0', 'd.Id_0 DESC');
                return $this->get_by(array('Id_0' => $did), TRUE);
            }
        }

        public function get_reversement_info($id = NULL) {

            if ($id == NULL) {
                $obj = new stdClass();
                $obj->Id_0 = NULL;
                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                $obj->Status_2 = '';
                $obj->Account_3 = '';
                $obj->Logirefid_4 = $this->generate_unique_reference();
                $obj->Banqueid_5 = ''; //Core Banking ID
                $obj->Description_6 = '';
                $obj->Makerid_7 = '';
                $obj->Montant_8 = '';
                $obj->Devise_9 = '';

                $obj->Beneficiaire_10 = '';
                $obj->Service_11 = '';
                $obj->Typerecette_12 = '';
                $obj->Journee_13 = gmdate('Y-m-d H:i:s');
                $obj->Designation_14 = '';
                $obj->Agence_15 = $_SESSION['Logiref_agence'];

                $obj->Contrevaleur_16 = '';
                $obj->Reference_isys_17 = '';
                $obj->Retourids_18 = '';
                $obj->Retourdetails_19 = ''; // Tjrs en CDF

                $obj->Taux_20 = '';
                $obj->Nombrepaiement_22 = '';
                $obj->Paiementids_23 = '';

                return $obj;
            } else {
                $this->set_table('logiref_integration_isys s', 's.Id_0', 's.Id_0 DESC');
                return $this->get_by(array('s.Id_0' => $id), TRUE);
            }
        }

        public function get_log_brancless_info($id = NULL) {
            $this->set_table('logiref_log_branchless_retrieves b', 'b.Id_0', 'b.Id_0 DESC');
            return $this->get_by(array('Id_0' => $id), TRUE);
        }

        public function get_note_by_ref($ref) {
            $this->set_table('logiref_integration_logirad I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('PerceptionNumber_10' => $ref), TRUE);
        }

        public function get_note_passeport_by_ref($ref) {
            $this->set_table('logiref_integration_logirad_passeport I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Reference_21' => $ref), TRUE);
        }

        public function get_declaration_by_ref($ref) {
            $this->set_table('logiref_integration_declaration I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Noteid_9' => $ref), TRUE);
        }

        public function get_paiement_dgidec($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_integration_declaration I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_log_brancless_by_bl($bl_id = NULL) {
            $this->set_table('logiref_log_branchless_retrieves b', 'b.Id_0', 'b.Id_0 DESC');
            return $this->get_by(array('Paiementid_11' => $bl_id), TRUE);
        }

        public function get_integration_sftp_by_id($id = NULL) {
            $this->set_table('logiref_integration_sftp i', 'i.Id_0', 'i.Id_0 DESC');
            return $this->get_by(array('Id_0' => $id), TRUE);
        }

        public function get_integration_sydonia_by_logirefid($id = NULL) {
            $this->set_table('logiref_integration_sydonia i', 'i.Id_0', 'i.Id_0 DESC');
            return $this->get_by(array('Logirefid_34' => $id), TRUE);
        }

        public function get_isys_account_info() {
            $this->_table_name = '';
            $bank = $this->session->userdata['account_id'];
            $this->set_table('logiref_isys_accounts c', 'c.Id_0', 'c.Id_0 DESC');
            $account = $this->get_by(array('Account_3' => $bank), TRUE);

            if (empty($account)) {

                return NULL;
            } else {
                return $account;
            }
        }

        public function get_sydonia_account_info() {
            $this->_table_name = '';
            $bank = $this->session->userdata['account_id'];
            $this->set_table('logiref_sydonia_accounts c', 'c.Id_0', 'c.Id_0 DESC');
            $account = $this->get_by(array('Account_3' => $bank), TRUE);

            if (empty($account)) {
                return NULL;
            } else {
                return $account;
            }
        }

        /*
        * Get Information: returns an array
        * Use: for indexation, for dropdon etc
        * List
        *  *************************************************************************************************************************SECTION 3
        */

        public function get_all_instructions_dgi($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgi')
                    ->select('logiref_cbs_instructions_dgi.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_all_instructions_dgrad($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgrad')
                    ->select('logiref_cbs_instructions_dgrad.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_integrations_sftp()
        {
                $agence = $_SESSION['Logiref_guichet'];

                $st = " Agence_13 ='" . $agence . "' AND Status_2 <> 0 ";
                $query = $this->db->table('logiref_integration_sftp')
                        ->select('logiref_integration_sftp.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function check_integration_sftp()
        {
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                if(isset($_POST['total_amount']))
                {
                        $_POST['total_amount'] = str_replace(' ', '', $_POST['total_amount']);
                        $_POST['total_amount'] = str_replace(',','.', $_POST['total_amount']);
                }
                elseif(isset($_POST['commission']))
                {
                        $_POST['commission'] = str_replace(' ', '', $_POST['commission']);
                        $_POST['commission'] = str_replace(',','.', $_POST['commission']);
                }

                if(isset($_POST['office'])) $st .= " AND Office_7 ='".$_POST['office']."'";
                if(isset($_POST['total_amount'])) $st .= " AND Amount_8 ='".$_POST['total_amount']."'";
                if(isset($_POST['commission'])) $st .= " AND Commission_9 ='".$_POST['commission']."'";
                if(isset($_POST['nombre_total'])) $st .= " AND Nbtotal_14 ='".$_POST['nombre_total']."'";
                if(isset($_POST['nif'])) $st .= " AND Nif_16 ='".$_POST['nif']."'";
                if(isset($_POST['serial'])) $st .= " AND Serial_17 ='".$_POST['serial']."'";
                if(isset($_POST['number'])) $st .= " AND Number_18 ='".$_POST['number']."'";

                $st .= " AND Date_15 ='". gmdate('Y-m-d')."'";


                $query = $this->db->table('logiref_integration_sftp')
                        ->select('logiref_integration_sftp.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function get_regularisations($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_regularisations')
                    ->select('logiref_cbs_regularisations.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_batch_bulletin_by_infos() {
            $user = $this->session->userdata['user_id'];
            $account = $this->session->userdata['account_id'];
            $st = " Account_3='" . $account . "' AND Creator_4 = '" . $user . "'";

            if (isset($_POST['office']))
                $st .= " AND Office_7 ='" . $_POST['office'] . "'";
            if (isset($_POST['Nif']))
                $st .= " AND Nif_8 ='" . $_POST['Nif'] . "'";
            if (isset($_POST['total_amount']))
                $st .= " AND Amount_11 ='" . $_POST['total_amount'] . "'";
            if (isset($_POST['bank']))
                $st .= " AND Bank_10 ='" . $_POST['bank'] . "'";
            if (isset($_POST['agent']))
                $st .= " AND Agent_9 ='" . $_POST['agent'] . "'";
            if (isset($_POST['ref']))
                $st .= " AND Refop_25 ='" . $_POST['ref'] . "'";

            #Query
            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_cbs_returns_dgi_dgrad_array($encaissements) {

            $ids = array();
            $stop = array();

            if (!empty($encaissements)) {
                foreach ($encaissements as $id => $line) {
                    if (!isset($stop[$line->Paiementid_4])) {
                        $stop[$line->Paiementid_4] = 0;
                        $ids[] = $line->Paiementid_4;
                    }
                }
            }

            if (!empty($ids))
                $ids_list = implode("','", $ids);

            $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

            $query = $this->db->table('logiref_cbs_returns')
                    ->select('logiref_cbs_returns.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $ddmenu = array();
            foreach ($query->getResultArray() as $row) {
                $returns_ids = json_decode($row['Result_6'], true);
                $ddmenu[$row['Paiementid_4']] = $returns_ids;
            }
            return $ddmenu;
        }

        public function get_ack_by_message_id($meeage_id = NULL)
        {
                $this->set_table('logiref_integration_sftp_ack a', 'a.Id_0', 'a.Id_0 DESC');
                return $this->get_by(array('Msgid_7' => $meeage_id), TRUE);
        }

        public function get_instructions_dgi_by_id($id)
        {
                $this->set_table('logiref_cbs_instructions_dgi d', 'd.Id_0', 'd.Id_0 DESC');
                $lines = $this->get_by(array('Id_0' => $id), TRUE);

                return $lines;
        }

        public function  get_instructions_dgrad_by_id($id)
        {
                $this->_table_name = '';
                $this->set_table('logiref_cbs_instructions_dgrad d', 'd.Id_0', 'd.Id_0 DESC');
                $lines = $this->get_by(array('Id_0' => $id), TRUE);

                return $lines;
        }

        public function get_instructions_dgda_by_id($id)
        {
            $this->set_table('logiref_cbs_instructions_dgda d', 'd.Id_0', 'd.Id_0 DESC');
            $lines = $this->get_by(array('Id_0' => $id), TRUE);

            return $lines;
        }

        public function  get_instructions_dgda_prepayment_by_id($id)
        {
                $this->_table_name = '';
                $this->set_table('logiref_cbs_prepayments_instructions d', 'd.Id_0', 'd.Id_0 DESC');
                $lines = $this->get_by(array('Id_0' => $id), TRUE);

                return $lines;
        }

        public function get_instructions_dgda_by_paiement_id($paiement_id){
                    
                    $agence = $_SESSION['Logiref_guichet'];

                    $st = "Status_2!='0' AND Guichet_7='" . $agence . "' AND Paiementid_4 IN($paiement_id)";
                    
                    $query = $this->db->table('logiref_cbs_instructions_dgda')
                                    ->select('logiref_cbs_instructions_dgda.*')
                                    ->where($st)
                                    ->orderBy('Date_1', 'DESC')
                                    ->get();

                    return  $query->getResult();
        }

        public function get_all_instructions_dgda($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgda')
                    ->select('logiref_cbs_instructions_dgda.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_instructions_unvalidated_attestation_dgi($pid)
        {
                $st = " Paiementid_4 ='" . $pid . "' AND Status_2 = 1 AND (TypeCompte_25 = 'FA' OR TypeCompte_25 = 'TA') AND Montant_10 > 0";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                        ->select('logiref_cbs_instructions_dgi.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function get_instructions_unvalidated_attestation_dgrad($pid)
        {
                $st = " Paiementid_4 ='" . $pid . "' AND Status_2 = 1 AND (TypeCompte_25 = 'FA' OR TypeCompte_25 = 'TA') AND Montant_10 > 0";
                $query = $this->db->table('logiref_cbs_instructions_dgrad')
                        ->select('logiref_cbs_instructions_dgrad.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function get_instructions_unvalidated_attestation_dgda($pid)
        {
                $st = " Paiementid_4 ='" . $pid . "' AND Status_2 = 1 AND (TypeCompte_29 = 'FA' OR TypeCompte_29 = 'TA') AND Montant_10 > 0";
                $query = $this->db->table('logiref_cbs_instructions_dgda ')
                        ->select('logiref_cbs_instructions_dgda .*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function get_sucess_instructions_dgda($day) 
        {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2='2' AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgda')
                    ->select('logiref_cbs_instructions_dgda.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_failed_instructions_dgda($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2='2' AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgda')
                    ->select('logiref_cbs_instructions_dgda.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_unknown_status_instructions_dgda($day) {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Guichet_7 ='" . $agence . "' AND Status_2='2' AND Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_cbs_instructions_dgda')
                    ->select('logiref_cbs_instructions_dgda.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_cbs_returns_dgda_array($encaissements) {
            //Get IDs
            $ids = array();
            $stop = array();

            if (!empty($encaissements)) {
                foreach ($encaissements as $id => $line) {
                    if (!isset($stop[$line->Paiementid_4])) {
                        $stop[$line->Paiementid_4] = 0;
                        $ids[] = $line->Paiementid_4;
                    }
                }
            }

            $agence = $_SESSION['Logiref_guichet'];

            $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

            if (isset($ids_list))
                $st .= " AND Sydonia_5 IN ('" . $ids_list . "')";

            $query = $this->db->table('logiref_cbs_returns')
                    ->select('logiref_cbs_returns.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_declarations($bank = NULL, $type = NULL) {
            if ($type == "banque") {
                #var_dump("tres");die;
                $this->_table_name = '';
                $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                $this->db->from('logiref_declarations');
                $st = "Status_2 != '0' AND  Banque_20 ='" . $bank . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } elseif ($bank == "ordre") {
                $this->_table_name = '';
                $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                $this->db->from('logiref_declarations');
                $st = "Status_2 == '1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } elseif (isset($bank)) {
                #var_dump("tres");die;
                $this->_table_name = '';
                $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                $this->db->from('logiref_declarations');
                $st = "Status_2 <> '1' AND Changer_6 ='" . $bank . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } elseif ($type == "tous") {
                $this->_table_name = '';
                $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                $this->db->from('logiref_declarations');
                $st = "Status_2!='0'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } else {
                $this->_table_name = '';
                $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                $this->db->from('logiref_declarations');
                $st = "Status_2!='0' AND Status_2!='4' OR Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            }
        }

        public function get_declarations_content($dis = NULL) {
            $account_id = $this->session->userdata['account_id'];
            $this->db->select('logiref_declarations.Id_0, logiref_declarations.Content_16');
            $this->db->from('education_categories');
            $this->db->where("logiref_declarations.Account_3 ='" . $account_id . "'");
            $this->db->where("logiref_declarations.Status_2 = 1");
            $this->db->distinct();
            if ($dis != NULL)
                $this->db->where("logiref_declarations.Id_0 IN ('" . $dis . "')");
            $this->db->order_by('logiref_declarations.Id_0');
            $results = $this->get_all();
            return $results;
        }

        public function get_last_declarations() {
            $this->_table_name = '';
            $this->db->select('Id_0', 'logiref_declarations.Id_0 DESC');
            $this->db->from('logiref_declarations');
            $this->db->order_by('Id_0 DESC');
            $this->db->limit(1);
            return $this->db->get()->result();
        }

        public function get_unvalidated_bls() 
        {
            $role = $this->get_logiref_role();
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            if (isset($this->options['DGDA']['pre-payment-validation']))
            {
                if ($this->is_maker_role() || $this->is_validator_role())
                    $st .= "AND (Status_2 = '1' OR Status_2 = '2') AND (Lot_22 = 'saisi' OR Lot_22 IS NULL OR Lot_22 = '' OR Lot_22 != '') AND (Customercode_35 = '' OR Customercode_35 IS NULL OR Customercode_35 = '') ";
                    if ($this->is_validator_role()) $st .= " AND Treated_45 = '2' ";
                    elseif ($this->is_maker_role()) $st .= " AND Treated_45 >= '0'";

                else 
                    $st .= " AND Status_2 > '2' ";
            } 
            else 
            {
                if ($this->is_maker_role() || $this->is_validator_role())
                    $st .= " AND (Status_2 = '1' OR Status_2 = '2') AND (Customercode_35 = '' OR Customercode_35 IS NULL OR Customercode_35 = '') AND (Lot_22 = 'saisi' OR Lot_22 IS NULL OR Lot_22 != 'batch') ";
                    if ($this->is_validator_role()) $st .= " AND Treated_45 = '2' ";
                    elseif ($this->is_maker_role()) $st .= " AND (Treated_45 >= '0')";
                else
                    $st .= " AND Status_2 > '2' ";
            }

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(500)
                    ->get();

            return $query->getResult();
        }

        public function get_unvalidated_bls_to_integrate() {
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            $st .= "AND Status_2 = '2'";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(800)
                    ->get();

            $payments = $query->getResult();

            $bureaux = array();
            $counts = array();
            $amounts = array();
            $commissions = array();

            foreach ($payments as $line):

                $key = $line->Office_6;

                if (key_exists($key, $counts)) {
                    $counts[$key] += 1;
                    $amounts[$key] += $line->Amount_12;

                    $commissions[$key] += $line->Commission_26;
                } else {
                    $counts[$key] = 1;
                    $amounts[$key] = $line->Amount_12;
                    $commissions[$key] = $line->Commission_26;
                }

                $line->total = $counts[$key];
                $line->amounts = $amounts[$key];
                $line->commissions = $commissions[$key];
                $bureaux[$line->Office_6] = $line;

            endforeach;

            return $bureaux;
        }

        public function get_unsaved_bls() {
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=1 AND Lot_22 IS NULL";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(500)
                    ->get();

            return $query->getResult();
        }
        
        public function get_unsaved_bls_batchs(){
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=1";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_24 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(500)
                    ->get();

            return $query->getResult();
        }

        public function get_unvalidated_bls_to_regulate() {
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=5";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'";
            }

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            return $query->getResult();
        }

        public function get_bulletin_to_integrate($statut = NULL) {
            $account = $this->session->userdata['account_id'];
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
            $this->db->from('logiref_integration_sydonia');
            $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
            if ($this->restrict_to_current_guichet()) {
                $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
            }
            $this->db->where("logiref_integration_sydonia.Status_2 = '7'");
            $this->db->order_by('Date_1 DESC');
            return $this->get_all();
        }

        public function get_unvalidated_to_export() {
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'";
            }
            if ($this->is_maker_role())
                $st .= " AND Status_2=2  ";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            return $query->getResult();
        }

        public function get_validated_bls($type = NULL) {
            $date = gmdate('Y-m-d');

            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '3'";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            if ($type == 'dailly')
                $st .= " AND Date_1 LIKE '%" . $date . "%' ";

            if ($type == 'penalities')
                $st .= "AND DATEDIFF('" . gmdate('Y-m-d H:i:s') . "', Date_1) >= 1 ";
        
            if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
            if(isset($_POST['start']) && $_POST['start']!='') 
            {
                $formattedStartDate = date('Y-m-d', strtotime($_POST['start']));
                $formattedEndDate = date('Y-m-d', strtotime($_POST['end']));

                $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
            }

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(800)
                    ->get();

            return $query->getResult();
        }

        
        public function get_validated_bulletins() 
        {
            $account = $this->session->userdata['account_id'];

            $st = "Status_2 = '3' AND Account_3='" . $account . "'";

            if ($this->restrict_to_current_guichet()) {
                $st .= " AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "'";
            }

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(800)
                    ->get();

            return $query->getResult();
        }


        public function get_reports_deleted_bls(bool $restrictions = true)
        {
            $accountId = $this->session->userdata['account_id'];

            // Base condition
            $st = "Status_2 = 0 AND Account_3 = '0' AND Agence_32 = '{$_SESSION['Logiref_guichet']}'";

            if (!empty(($_POST['Office'])))
                $st .= " AND Office_6 ='" . $_POST['Office'] . "'";

            if (!empty($_POST['start']) && !empty($_POST['end']))
                $st .= " AND Deletion_48 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
            else
                $st .= " AND CAST(Deletion_48 AS DATE) = CURRENT_DATE";

            if (!empty(($_POST['user'])))
                $st .= " AND User_15 ='" . $_POST['user'] . "'";

            // Exécution
            return $this->db->table('logiref_integration_sydonia')
                    ->select('*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->limit(800)
                    ->get()
                    ->getResult();
        }


        public function get_reports_bls(bool $restrictions = true)
        {
            $accountId = $this->session->userdata['account_id'];

            // Base condition
            $st = "Status_2 != 0 AND Account_3 = '{$accountId}'";

            if (isset($_POST['Service']) && $_POST['Service'] != '')
                $st .= " AND Office_6 ='" . $_POST['Service'] . "'";

            if (!empty($_POST['start']) && !empty($_POST['end']))
                $st .= " AND Integration_16 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
            else
                $st .= " AND CAST(Integration_16 AS DATE) = CURRENT_DATE";

            if (isset($_POST['user']) && $_POST['user'] != '')
                $st .= " AND User_15 ='" . $_POST['user'] . "'";
            
            // Restrictions selon rôle
            if ($restrictions) 
            {
                if ($this->restrict_to_current_agence())
                    $st .= " AND Agence_32 = '{$_SESSION['Logiref_agence']}'";
                elseif ($this->get_logiref_role() <= 2)
                    $st .= " AND Agence_32 = '{$_SESSION['Logiref_agence']}'";
                if ($this->restrict_to_current_guichet())
                    $st .= " AND Agence_32 = '{$_SESSION['Logiref_guichet']}'";
            }

            // Exécution
            return $this->db->table('logiref_integration_sydonia')
                    ->select('*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->limit(800)
                    ->get()
                    ->getResult();
        }


        public function get_reports_filter($type = NULL) {
            $this->_table_name = '';
            $user = $this->session->userdata['user_id'];
            #Query
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
            $this->db->from('logiref_integration_sydonia');
            $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

            #Filtre d'affichage
            if (isset($_POST['operator']) && $_POST['operator'] != '')
                $st .= " AND User_15 ='" . $_POST['user'] . "'";
            if (isset($_POST['start']) && $_POST['start'] != '')
                $st .= " AND Integration_16 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

            #Restriction
            if ($this->restrict_to_current_guichet())
                $st .= " AND Agence_32='" . $_SESSION['Logiref_guichet'] . "'";

            #Run
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Date_1 DESC');
            return $this->get_all();
        }

        public function get_reports_filter_dgda($data) {
            $user = $this->session->userdata['user_id'];
            #Query
            $st = " Account_3='" . $this->session->userdata['account_id'] . "' ";

            #Filtre d'affichage
            if (isset($data['guichet']) && $data['guichet'] != '')
                $st .= " AND Agence_32='" . $data['guichet'] . "'";
            if (isset($data['start']) && $data['start'] != '')
                $st .= " AND Integration_16 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

            #Run
            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC')
                    ->where($st)
                    ->orderBy('Date_1 DESC')
                    ->get();
            return $query->getResult();
        }

        public function get_bulletins($data = NULL) {
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            #Filtre d'affichage
            if (isset($data['agence']) && $data['agence'] != '')
                $st .= "AND Agence_32 ='" . $data['agence'] . "'";
            if (isset($data['start']) && isset($data['end']) && ($data['start'] != '' && $data['end'] != ''))
                $st .= "AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(800)
                    ->get();
            return $query->getResult();
        }

        public function get_notes($type = NULL, $nif = NULL, $bank = NULL) {
            if ($type == "tous") {
                $this->_table_name = '';
                $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                $this->db->from('logiref_notes');
                $st = "Status_2!='0' AND Nifclient_7='" . $nif . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } elseif ($type == "banque") {
                $this->_table_name = '';
                $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                $this->db->from('logiref_notes');
                $st = "Status_2 != '0' AND  Banque_20 ='" . $bank . "' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            } else {
                $this->_table_name = '';
                $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                $this->db->from('logiref_notes');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                //$st = "Status_2!='0'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
            }
        }

        public function get_all_bulletins($nif = NULL) {
            $this->_table_name = '';
            $this->db->select('logiref_bulletins.*', 'logiref_bulletins.Id_0 ASC');
            $this->db->from('logiref_bulletins');
            #var_dump($nif); die;
            $st = "Status_2!='0' AND Nifimportateur_10='" . $nif . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0 DESC');
            return $this->get_all();
        }

        public function get_logs_branchless() {
            
            $agence = $_SESSION['Logiref_guichet'];

            $st = "Status_2='1' AND Agence_14 = '" . $agence . "' ";

            $query = $this->db->table('logiref_log_branchless_retrieves')
                    ->select('logiref_log_branchless_retrieves.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            return $query->getResult();
        }

        public function get_bulletins_by_lot_to_validate($lot) 
        {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='" . $account . "' AND  Logirefid_34 = '" . $lot . "' AND Treated_45 <= 2";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Id_0', 'ASC')
                    ->get();
            return $query->getResult();
        }


        public function get_bulletins_by_lot($lot) {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='" . $account . "' AND  Logirefid_34 = '" . $lot . "' AND Treated_45 = 0";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Id_0', 'ASC')
                    ->get();
            return $query->getResult();
        }

        public function get_bulletins_by_logirefid($lot) {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='" . $account . "' AND  Logirefid_34 = '" . $lot . "' ";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Id_0', 'ASC')
                    ->get();
            return $query->getResult();
        }
        
        public function get_bulletins_by_many_logirefid($lot) {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='" . $account . "' AND  Logirefid_34 IN($lot) ";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Id_0', 'ASC')
                    ->get();
            return $query->getResult();
        }

        public function get_integrations_cbs($type = NULL) {
            $this->_table_name = '';
            #Query
            $this->db->select('logiref_integration_cbs.*', 'logiref_integration_cbs.Id_0 DESC');
            $this->db->from('logiref_integration_cbs');
            $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
            #Run
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Date_1 DESC');
            return $this->get_all();
        }

        public function get_integrations_isys($type = NULL) {
            $role = $_SESSION['Logiref_role'];

            $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

            $query = $this->db->table('logiref_integration_isys')
                    ->select('logiref_integration_isys.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(800)
                    ->get();

            return $query->getResult();
        }

        public function get_integrations_rtgs($type = NULL) {
            $this->_table_name = '';
            #Query
            $this->db->select('logiref_integration_rtgs.*', 'logiref_integration_rtgs.Id_0 DESC');
            $this->db->from('logiref_integration_rtgs');
            $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
            #Run
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Date_1 DESC');
            return $this->get_all();
        }

        public function get_bulletins_instructions_by_ids($ids) {
            $st = "Status_2 = '1' AND Paiementid_4 IN($ids) AND Priority_24 > 0 AND Montant_10 > 0";

            $query = $this->db->table('logiref_cbs_instructions_dgda')
                    ->select('logiref_cbs_instructions_dgda.*')
                    ->where($st)
                    ->orderBy('Id_0', 'ASC')
                    ->get();
            return $query->getResult();
        }
        
        public function get_instructions_to_treat_for_sftp_dgda($type=null) 
        {
                if($type == 'branchless')
                {
                        $date = gmdate('Y-m-d');

                        $branch = $_SESSION['Logiref_guichet'];

                        $st = "Status_2 = '1' AND Branch_15 = '".$branch."' AND Type_19='branchless' AND Date_1 LIKE '%".$date."%' ";

                        $query = $this->db->table('logiref_cbs_integration_journalisation_dgda_comptant')
                                ->select('logiref_cbs_integration_journalisation_dgda_comptant.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                }
                else
                {
                        $date = gmdate('Y-m-d');

                        $branch = $_SESSION['Logiref_guichet'];

                        $st = "Status_2 = '1' AND (Type_19 = 'branch' OR Type_19 = '') AND Date_1 LIKE '%".$date."%' ";

                        $query = $this->db->table('logiref_cbs_integration_journalisation_dgda_comptant')
                                ->select('logiref_cbs_integration_journalisation_dgda_comptant.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                }

                return $query->getResult();
        }

        /*
        * Get Information: returns an array
        * Use: for indexation, for dropdon etc
        * List
        *  *************************************************************************************************************************SECTION 4
        */

        public function get_paiement_sydonia($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_integration_sydonia I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_paiement_sydonia_batchs($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_integration_sydonia_batchs I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_prepaiement_sydonia($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_sydonia_prepayments I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_bulletin_by_ref($ref = NULL) {
            if ($ref != NULL) {
                $this->set_table('logiref_bulletin I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Reference_19' => $ref), TRUE);
            }
        }

        public function get_cbs_returns($id) {
            $this->set_table('logiref_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Paiementid_4' => $id), TRUE);
        }

        public function get_cbs_returns_dgda($id) {
            $this->set_table('logiref_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Sydonia_5' => $id), TRUE);
        }

        public function get_bulletin_confirmed($ref = NULL) {
            $this->_table_name = '';
            #Query
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
            $this->db->from('logiref_integration_sydonia');
            $st = " (Status_2= 1 OR Status_2 = 2) AND Error_14 !=0";

            if (isset($_POST['Office']) && $_POST['Office'] != '')
                $st .= " AND Office_6='" . $_POST['Office'] . "'";
            if (isset($_POST['Year']) && $_POST['Year'] != '')
                $st .= " AND Year_5='" . $_POST['Year'] . "'";
            if (isset($_POST['Bank']) && $_POST['Bank'] != '')
                $st .= " AND Bank_11='" . $_POST['Bank'] . "'";
            if (isset($_POST['Nif']) && $_POST['Nif'] != '')
                $st .= " AND Nif_9='" . $_POST['Nif'] . "'";
            if (isset($_POST['Agent']) && $_POST['Agent'] != '')
                $st .= " AND Agent_10='" . $_POST['Agent'] . "'";
            if (isset($_POST['Series']) && $_POST['Series'] != '')
                $st .= " AND Serie_7='" . $_POST['Series'] . "'";
            if (isset($_POST['Amount']) && $_POST['Amount'] != '')
                $st .= " AND Amount_12='" . $_POST['Amount'] . "'";
            #Run

            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Date_1 ASC');
            $this->db->limit(1);
            return $this->get_all();
        }

        public function get_clients_by_nif($nif = NULL) {
            if ($nif != NULL) {
                $this->set_table('logiref_nifs N', 'N.Id_0', 'N.Id_0 DESC');
                return $this->get_by(array('Nif_4' => $nif), TRUE);
            }
        }

        public function get_paiement_sydonia_by_ref($ref = NULL) {
            if ($ref != NULL) {
                $this->set_table('logiref_integration_sydonia I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $ref), TRUE);
            }
        }
        public function get_paiement_sydonia_by_logirefid($ref = NULL) {
            if ($ref != NULL) {
                $this->set_table('logiref_integration_sydonia I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Logirefid_34' => $ref), TRUE);
            }
        }

        public function get_token_isys() {
            $date = gmdate('Y-m-d');
            $this->set_table('logiref_integration_tokens I', 'I.Id_0', 'I.Id_0 DESC');
            $result = $this->get_by(array('Account_3' => $this->session->userdata['account_id'], 'Date_9' => $date), TRUE);

            $message = "";

            if (!empty($result)) {
                $_SESSION['token_isys'] = $result->Token_8;
                $_SESSION['token_time'] = $result->Time_10;

                $token_time = $_SESSION['token_time'];
                $current_time = gmdate('H:i:s');

                $token_time_1 = strtotime($token_time);
                $token_time_2 = strtotime($current_time);

                $diff = $token_time_2 - $token_time_1;

                $hour = floor(date('H:i:s', $diff));

                if ($hour > 3) {
                    $message = "expired";
                }
            } else {
                $message = "expired";
                $_SESSION['token_isys'] = '';
                $_SESSION['token_time'] = '';
            }


            return $message;
        }

        public function get_sydonia_logs() {
            $this->_table_name = '';
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 ASC');
            $this->db->from('logiref_integration_sydonia');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0');
            return $this->get_all();
        }

        public function get_isys_logs() {
            $this->_table_name = '';
            $this->db->select('logiref_integration_isys.*', 'logiref_integration_isys.Id_0 ASC');
            $this->db->from('logiref_integration_isys');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0');
            return $this->get_all();
        }

        public function get_rtgs_logs() {
            $this->_table_name = '';
            $this->db->select('logiref_integration_rtgs.*', 'logiref_integration_rtgs.Id_0 ASC');
            $this->db->from('logiref_integration_rtgs');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0');
            return $this->get_all();
        }

        public function get_cbs_logs() {
            $this->_table_name = '';
            $this->db->select('logiref_integration_cbs.*', 'logiref_integration_cbs.Id_0 ASC');
            $this->db->from('logiref_integration_cbs');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0');
            return $this->get_all();
        }

        public function get_last_paiement_id() {
            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->orderBy('Id_0', 'DESC')
                    ->limit(1)
                    ->get();

            $return = $query->getResult();

            if (isset($return[0]->Id_0))
                $lastid = $return[0]->Id_0;
            else
                $lastid = 0;

            return $lastid;
        }

        public function filter_logs_sydonia($data) {
            $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
            if (!empty($data)) {
                if (isset($data['Error_14']) && !empty($data['Error_14'])) {
                    $st0 .= " AND Error_14 ='" . $data['Error_14'] . "'";
                }

                if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                    $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                }

                $this->db->select('logiref_integration_sydonia.*');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where($st0, NULL, FALSE);
                $this->db->order_by('logiref_integration_sydonia.Id_0', 'logiref_integration_sydonia.Id_0 DESC');
                return $this->get_all();
            }
        }

        public function retrieve_bulletin_by_log_info() {

            $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

            if (isset($_POST['Office']))
                $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
            if (isset($_POST['Year']))
                $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
            if (isset($_POST['Nif']))
                $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
            if (isset($_POST['Series']))
                $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
            if (isset($_POST['Number']))
                $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
            if (isset($_POST['Amount']))
                $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";
            if (isset($_POST['Bank']))
                $st .= " AND Bank_11 ='" . $_POST['Bank'] . "'";
            if (isset($_POST['Agent']))
                $st .= " AND Agent_10 ='" . $_POST['Agent'] . "'";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();
            
            return $query->getResult();
        }

        public function filter_logs_isys($data) {
            $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
            if (!empty($data)) {
                if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                    $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                }

                if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                    $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                }

                $this->db->select('logiref_integration_isys.*');
                $this->db->from('logiref_integration_isys');
                $this->db->where($st0, NULL, FALSE);
                $this->db->order_by('logiref_integration_isys.Id_0', 'logiref_integration_sydonia.Id_0 DESC');
                return $this->get_all();
            }
        }

        public function filter_logs_rtgs($data) {
            $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
            if (!empty($data)) {
                if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                    $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                }

                if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                    $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                }

                $this->db->select('logiref_integration_rtgs.*');
                $this->db->from('logiref_integration_rtgs');
                $this->db->where($st0, NULL, FALSE);
                $this->db->order_by('logiref_integration_rtgs.Id_0', 'logiref_integration_rtgs.Id_0 DESC');
                return $this->get_all();
            }
        }

        public function filter_logs_cbs($data) {
            $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
            if (!empty($data)) {
                if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                    $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                }

                if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                    $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                }

                $this->db->select('logiref_integration_cbs.*');
                $this->db->from('logiref_integration_cbs');
                $this->db->where($st0, NULL, FALSE);
                $this->db->order_by('logiref_integration_cbs.Id_0', 'logiref_integration_cbs.Id_0 DESC');
                return $this->get_all();
            }
        }

        public function get_initiated_bls()
        {
            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $role = $_SESSION['Logiref_role'];
            
            $builder = $this->db->table('logiref_integration_sydonia');
            $builder->select('*');
            $builder->where('Account_3', $account);
            $builder->whereNotIn('Status_2', [3, 4]);  // ⚡ ici
            $builder->orderBy('Date_1', 'DESC');

            $query = $builder->get();
            return $query->getResult();
        }

        public function get_initiated_bls_checker()
        {
            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $role = $_SESSION['Logiref_role'];
            $guichet = $_SESSION['Logiref_guichet'];
            
            $builder = $this->db->table('logiref_integration_sydonia');
            $builder->select('*');
            $builder->where('Account_3', $account);
            $builder->where('Agence_32', $guichet);
            $builder->whereNotIn('Status_2', [3, 4]);  // ⚡ ici
            $builder->orderBy('Date_1', 'DESC');

            $query = $builder->get();
            return $query->getResult();
        }

        public function get_prepayments_by_lot($ids) {
            $account = $this->session->userdata['account_id'];
            $this->_table_name = '';
            $this->db->select('logiref_sydonia_prepayments.*', 'logiref_sydonia_prepayments.Id_0 ASC');
            $this->db->from('logiref_sydonia_prepayments');
            $st = "Status_2!='0' AND Account_3='" . $account . "' AND Id_0 IN (" . $ids . ")";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0 DESC');
            return $this->get_all();
        }

        public function get_bulletins_by_id($ids) {
            $account = $this->session->userdata['account_id'];

            $st = "Status_2 ='2' AND Account_3='" . $account . "' AND Id_0 IN (" . $ids . ")";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            return $query->getResult();
        }
        
        public function get_integrations_sftp_treatment_in_progress($type=null)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $date = gmdate('Y-m-d');

                $st = " Branch_11 ='" . $agence . "' AND (Status_2 = 1 OR Status_2 = 2) AND Type_16='".$type."' AND Date_1 LIKE '%".$date."%' ";
                
                $query = $this->db->table('logiref_cbs_treatment_sftp_dgda')
                        ->select('logiref_cbs_treatment_sftp_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->limit(1)
                        ->get();

                $result = $query->getResult();

                return $result;
        }
        
        public function get_integrations_sftp_treatment_by_filter()
        {
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = " Branch_11 ='" . $agence . "' AND Type_13 = 'comptant' ";
                
                #Filtre d'affichage
                if (isset($_POST['filter_date']) && $_POST['filter_date'] != '')
                    $st .= " AND Date_1 LIKE '%" . $_POST['filter_date'] . "%' ";
                if (isset($_POST['payment_type']) && $_POST['payment_type'] != '')
                    $st .= " AND Type_16='" . $_POST['payment_type'] . "'";
                
                
                $query = $this->db->table('logiref_cbs_treatment_sftp_dgda')
                        ->select('logiref_cbs_treatment_sftp_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->limit(1)
                        ->get();

                $result = $query->getResult();

                return $result;
        }

        public function get_bulletins_to_integrate_by_office() {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='" . $account . "' AND Agence_32 = '" . $_SESSION['Logiref_guichet'] . "' AND Status_2 ='2' AND Office_6 = '" . $_POST['office'] . "' ";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            return $query->getResult();
        }

        public function get_declarations_by_lot($lot) {
            $account = $this->session->userdata['account_id'];

            $this->db->select('logiref_sydonia_declarations.*');
            $this->db->from('logiref_sydonia_declarations');
            $this->db->where("logiref_sydonia_declarations.Status_2 > 0 AND logiref_sydonia_declarations.Account_3 ='" . $account . "'AND logiref_sydonia_declarations.Lot_18 =" . $lot . " ");
            $this->db->distinct();
            $this->db->order_by('logiref_sydonia_declarations.Id_0', 'logiref_sydonia_declarations.Id_0 DESC');
            return $this->get_all();
        }

        public function get_douane_declarations() {
            $account = $this->session->userdata['account_id'];

            $this->db->select('logiref_sydonia_declarations.*');
            $this->db->from('logiref_sydonia_declarations');
            $this->db->where("logiref_sydonia_declarations.Status_2 > 0 AND logiref_sydonia_declarations.Account_3 ='" . $account . "' ");
            $this->db->distinct();
            $this->db->order_by('logiref_sydonia_declarations.Id_0', 'logiref_sydonia_declarations.Id_0 DESC');
            return $this->get_all();
        }

        public function get_declaration_detail($id = NULL) {
            $this->set_table('logiref_sydonia_declarations s', 's.Id_0', 's.Id_0 DESC');
            return $this->get_by(array('s.Id_0' => $id), TRUE);
        }

        public function get_prepayments() {
            $account = $this->session->userdata['account_id'];
            $this->db->select('logiref_sydonia_prepayments.*');
            $this->db->from('logiref_sydonia_prepayments');
            $this->db->where("logiref_sydonia_prepayments.Status_2 > 0 AND logiref_sydonia_prepayments.Account_3 ='" . $account . "' ");
            $this->db->order_by('Id_0', 'Id_0 ASC');
            return $this->get_all();
        }

        public function get_paiement_logirad($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_integration_logirad I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_paiement_logirad_passeport($id = NULL) {
            if ($id != NULL) {
                $this->set_table('logiref_integration_logirad_passeport I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
            }
        }

        public function get_filter_gu_paiements($data) {
            $this->_table_name = '';
            $user = $this->session->userdata['user_id'];
            $guichet = $_SESSION['Logiref_guichet'];

            #Query
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
            $this->db->from('logiref_integration_sydonia');
            $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_32='" . $guichet . "'  AND Status_2 IN (3,4)";

            #Filtre d'affichage
            if (isset($data['Office']) && $data['Office'] != '')
                $st .= " AND Office_6='" . $data['Office'] . "'";
            if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
                $st .= " AND Date_1 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

            #Run
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Date_1 DESC');
            return $this->get_all();
        }

        public function get_reports_gu_paiements($type = NULL) {
            $account = $this->session->userdata['account_id'];
            $guichet = $_SESSION['Logiref_guichet'];

            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
            $this->db->from('logiref_integration_sydonia');
            $this->db->where("logiref_integration_sydonia.Status_2 IN (3,4) AND logiref_integration_sydonia.Account_3 ='" . $account . "' AND Agence_32 ='" . $guichet . "'");
            $this->db->order_by('Date_1 DESC');
            $this->db->limit(10);
            return $this->get_all();
        }

        public function get_prepayments_cbs_returns($id) {
            $this->set_table('logiref_prepayments_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Sydonia_5' => $id), TRUE);
        }

        public function check_bulletin_sydonia() {
            $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

            if (isset($_POST['Amount'])) {
                $_POST['Amount'] = str_replace(' ', '', $_POST['Amount']);
                $_POST['Amount'] = str_replace(',', '.', $_POST['Amount']);
            } elseif (isset($_POST['montant'])) {
                $_POST['montant'] = str_replace(' ', '', $_POST['montant']);
                $_POST['montant'] = str_replace(',', '.', $_POST['montant']);
            }

            if (isset($_POST['Office']))
                $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
            if (isset($_POST['montant']))
                $st .= " AND Amount_12 ='" . $_POST['montant'] . "'";
            if (isset($_POST['Year']))
                $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
            if (isset($_POST['Nif']))
                $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
            if (isset($_POST['Series']))
                $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
            if (isset($_POST['Number']))
                $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
            if (isset($_POST['Amount']))
                $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";

            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function check_batch_bulletin_sydonia($ref) {
            $this->_table_name = '';

            $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Refop_25 = '" . $ref . "' ";

            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function  get_paiement_batchs_by_reference($references)
        {
                $account = $this->session->userdata['account_id'];

                $st = "Account_3='".$account."' AND Lot_14 IN ($references) ";

                $query = $this->db->table('logiref_integration_sydonia_batchs')
                        ->select('logiref_integration_sydonia_batchs.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return  $query->getResult();
        }

        public function check_bl_exist() 
        {
            $this->_table_name = '';

            $st = " Account_3='44'";

            if (isset($_POST['Office']))
                $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
            if (isset($_POST['Year']))
                $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
            if (isset($_POST['Nif']))
                $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
            if (isset($_POST['Series']))
                $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
            if (isset($_POST['Number']))
                $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
            if (isset($_POST['Amount']))
                $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";
            if (isset($_POST['Bank']))
                $st .= " AND Bank_11 ='" . $_POST['Bank'] . "'";
            if (isset($_POST['Agent']))
                $st .= " AND Agent_10 ='" . $_POST['Agent'] . "'";

            #Query
            $query = $this->db->table('logiref_integration_sydonia')
                    ->select('logiref_integration_sydonia.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_unvalidated_batch_bl() {
            $account = $this->session->userdata['account_id'];
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Account_3='" . $account . "' AND Status_2 = '2' AND Agence_24 ='" . $agence . "' ";
            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }


        public function get_unvalidated_batch_bl_with_instructions() {
            $account = $this->session->userdata['account_id'];
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Account_3='" . $account . "' AND (Status_2 = '1' OR Status_2 = '2') AND Agence_24 ='" . $agence . "'";
            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_unvalidated_batch_bl_rbo() {
            $account = $this->session->userdata['account_id'];
            $agence = $_SESSION['Logiref_guichet'];
            $role = $_SESSION['Logiref_role'];

            $st = " Account_3='" . $account . "' AND Agence_24 ='" . $agence . "' AND Customercode_27!='' AND  Status_31='2' ";

            if(!in_array((int) $role, [4, 7], true)){
                $st.=" AND Status_2='2'";
            }
            else{
                $st.=" AND Status_2='1'";
            }

            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_unvalidated_batch_bl_by_id($id) {
            $account = $this->session->userdata['account_id'];
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Account_3='" . $account . "' AND Agence_24 ='" . $agence . "' AND Id_0 = '" . $id . "' ";
            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_bulletins_batch_by_id($id) {
            $this->set_table('logiref_integration_sydonia_batchs', 'Id_0', 'Id_0 DESC');
            return $this->get_by(array('Id_0' => $id), TRUE);
        }

        public function get_bulletins_batch_by_lot($lot) {
            $this->set_table('logiref_integration_sydonia_batchs', 'Id_0', 'Id_0 DESC');
            return $this->get_by(array('Lot_14' => $lot), TRUE);
        }

        public function get_all_payments_rbo($status) {

            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $agence = $this->session->userdata['Logiref_guichet'];
            $this->_table_name = '';
            $this->db->select('logiref_integration_sydonia.*');
            $this->db->from('logiref_integration_sydonia');

            $st = "Account_3='" . $account . "' AND Customercode_35 != '' AND Agence_32 ='" . $agence . "'";

            if ($status == "new"):

                $st .= " AND Status_2 ='1' ";

            else:

                $st .= " AND Status_2 = 2  ";

            endif;

            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0 DESC');
            $payments = $this->get_all();

            $bureaux = array();
            $counts = array();
            $amounts = array();

            foreach ($payments as $line):

                $key = $line->Office_6 . $line->Customercode_35;

                if (key_exists($key, $counts)) {
                    $counts[$key] += 1;
                    $amounts[$key] += $line->Amount_25;
                } else {
                    $counts[$key] = 1;
                    $amounts[$key] = $line->Amount_25;
                }

                $line->total = $counts[$key];
                $line->amounts = $amounts[$key];
                $bureaux[$line->Office_6][$line->Customercode_35] = $line;

            endforeach;

            return $bureaux;
        }

        public function get_payments_rbo_by_reference($data) {
            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $agence = $this->session->userdata['Logiref_guichet'];
            $this->_table_name = '';
            $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 ASC');
            $this->db->from('logiref_integration_sydonia');
            $st = "Status_2 ='1' AND Account_3='" . $account . "' AND Customercode_35 = '" . $data['reference'] . "' AND Agence_32 ='" . $agence . "'";
            $this->db->where($st, NULL, FALSE);
            $this->db->order_by('Id_0 DESC');
            return $this->get_all();
        }

        public function get_validated_batch_bl() {
            $account = $this->session->userdata['account_id'];
            $agence = $_SESSION['Logiref_guichet'];
            $st = " Account_3='" . $account . "' AND Status_2 = '3' AND Agence_24 ='" . $agence . "' ";
            $query = $this->db->table('logiref_integration_sydonia_batchs')
                    ->select('logiref_integration_sydonia_batchs.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

            $result = $query->getResult();

            return $result;
        }

        public function get_data_cbs_journalisation($paiement_data, $instructions, $bulletin, $type)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $data = array();
                
                if(!empty($paiement_data) && !empty($instructions))
                {
                        $total_amount_debited = $this->sum_instructions_amount_debited($instructions);
                        $total_amount_credited = $this->sum_instructions_amount_credited($instructions);
                        
                        $data ['Date_1'] = gmdate('Y-m-d h:i:s');
                        $data ['Status_2'] = '1';
                        $data ['Account_3'] = $this->session->userdata['account_id'];
                        $data ['Creator_4'] = $this->session->userdata['user_id'];
                        $data ['Office_7'] = $paiement_data['Service_16'];
                        $data ['Amountdebited_8'] = $total_amount_debited;
                        $data ['Amountcredited_9'] = $total_amount_credited;
                        $data ['Instructions_11'] = json_encode($instructions);
                        $data ['Nbinstructions_12'] = count($instructions);
                        $data ['Bulletinamount_13'] = $bulletin->Amount_12;
                        $data ['Bulletinid_14'] = $bulletin->Id_0;
                        $data ['Branch_15'] = $bulletin-> Agence_32;
                        

                        if($bulletin->Account_24 != '')
                        {
                                $data ['Account_16'] = $bulletin->Account_24;
                        }
                        else  
                        {
                                $agence = $_SESSION['Logiref_guichet'];
                                $comptes = $this->comptabilisation->get_comptes_array_dgda("'CGU'", "'DGDA'", $agence, []);

                                $data ['Account_16'] = isset($comptes['CGU']) ? $comptes['CGU'] : "";
                        }  

                        $data ['Designation_17'] = $this->remove_all_special_characters($paiement_data['Designation_14']);
                        $data ['Nif_18'] = $paiement_data['Nif_13'];
                        $data ['Type_19'] = $type;
                        
                        $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                }
                else
                {
                        $return = ['code' => 404,'message'=>'valid', 'data' => $data];
                }
                
                return $return;
        }
        
        public function clean_array_special_characters(array $data)
        {
                foreach ($data as $key => $value) 
                {
                        if (is_array($value))
                        {
                                // Appel récursif pour sous-tableaux
                                $data[$key] = $this->clean_array_special_characters($value);
                        } 
                        else 
                        {
                                // Nettoyage de la valeur (si string uniquement)
                                if (is_string($value)) 
                                {
                                        if($key == 'Libelle_12')
                                        {
                                                $data[$key] = $this->remove_all_special_characters($value);
                                        }
                                }
                        }
                }

                return $data;
        }
        
        public function get_data_integration_sftp($office_data, $path, $id, $reference)
        {
                $data = [];
                
                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                $data['Status_2'] = 1;
                $data['Account_3'] = $this->session->userdata['account_id'];
                $data['Creator_4'] = $this->session->userdata['user_id'];
                $data['Office_7'] = $office_data['office'];
                $data['Amountdebited_8'] = $office_data['amount_debited'];
                $data['Amountcredited_9'] = $office_data['amount_credited'];
                $data['Bankaccount_10'] = $office_data['bankaccount'];
                $data['Nbinstructions_11'] = $office_data['nbinstructions'];
                $data['Nbulletins_12'] = $office_data['nbulletins'];
                $data['Journalisationid_13'] = json_encode($office_data['journalisationid']);
                $data['Bulletinids_14'] = json_encode($office_data['bulletinids']);
                $data['Branch_15'] = $_SESSION['Logiref_guichet'];
                $data['Path_16'] = $path;
                $data['Paymenttype_17'] = 'comptant';
                $data['Treatmentid_18'] = $id;
                $data['Logirefid_19'] = $reference;
                
                
                return $data;
        }
        
        public function get_instructions_by_office_from_journalisation($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $instructions_by_office = [];
                
                foreach($data as $row)
                {
                        $ids[] = json_decode($row['journalisationid'], true);
                }
                
                $tab = array_merge(...$ids);
                
                # implode le tableau pour avoir une chaine des ids
                $ids = implode(',',$tab);
                
                $raw_journalisation = $this->get_instructions_from_journalisation_by_id($ids);
                
                # aggregate instructions by office
                foreach($raw_journalisation as $row)
                {
                        $instructions_by_office[$row->Office_7][] = $row;
                }
                
                return $instructions_by_office;
        }
        
        public function sum_instructions_amount_debited($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_debited = 0;
                
                foreach($data as $row)
                {
                        $total_amount_debited = $row['Montant_10'] + $total_amount_debited;
                }
                
                return $total_amount_debited;
        }
        
        public function sum_instructions_amount_credited($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_credited = 0;
                
                foreach($data as $row)
                {
                        $total_amount_credited = $row['Montant_10'] + $total_amount_credited;
                }
                
                return $total_amount_credited;
        }   
        
        public function sum_instructions_amount_debited_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                
                $total_amount_debited_by_office = 0;
                
                foreach($data as $row)
                {
                        $total_amount_debited_by_office = $row->Amountdebited_8 + $total_amount_debited_by_office;
                }
                
                return $total_amount_debited_by_office;
        }
        
        public function sum_instructions_amount_credited_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_credited_by_office = 0;
                
                foreach($data as $row)
                {
                        $total_amount_credited_by_office = $row-> Amountcredited_9  + $total_amount_credited_by_office;
                }
                
                return $total_amount_credited_by_office;
        }
        
        public function sum_nb_bulletins_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $nb_bulletins_by_office = 0;
                
                foreach($data as $row)
                {
                        $nb_bulletins_by_office = $nb_bulletins_by_office  + 1;
                }
                
                return $nb_bulletins_by_office;
        }
        
        public function sum_nb_instructions_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $nb_instructions_by_office = 0;
                
                foreach($data as $row)
                {
                        $nb_instructions_by_office = $row->Nbinstructions_12  + $nb_instructions_by_office;
                }
                
                return $nb_instructions_by_office;
        }
        
        public function construct_instructions_id_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $instructions_id_by_office = [];
                
                foreach($data as $row)
                {
                        
                        $instructions_id_by_office[] = $row->Id_0;
                }
                
                return $instructions_id_by_office;
        }
        
        public function construct_bulletins_id_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $bulletins_id_by_office = [];
                
                foreach($data as $row)
                {
                        
                        $bulletins_id_by_office[] = $row->Bulletinid_14;
                }
                
                return $bulletins_id_by_office;
        }

        /*
        * Save Information: insert or update an array
        * Use: inserting or updating 
        * List
        *  *************************************************************************************************************************SECTION 5
        */

        public function delete_bl($id) {
            $this->db->where('Id_0', $id);
            return $this->db->delete('logiref_integration_sydonia');
        }

        public function save_integrations_isys($data, $id) {
            $this->set_table('logiref_integration_isys', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_bulletin($data, $id) {
            $this->set_table('logiref_integration_sydonia', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_cbs_return($data, $id) {
            $this->set_table('logiref_cbs_returns', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }
        
        public function save_cbs_journalisation($data, $id) 
        {
                $this->set_table('logiref_cbs_integration_journalisation_dgda_comptant', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_cbs_return($data, $id) {
            $this->set_table('logiref_cbs_returns', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function update_integrations($data, $ref) {
            $this->db->where("logiref_integrations.Reference_14 ='" . $ref . "'");
            return $this->db->update('logiref_integrations', $data);
        }

        public function update_log_info($data, $ids) {
    //        $this->db->where("logiref_log_branchless_retrieves.Id_0 IN (" . $ids . ")");
    //        return $this->db->update('logiref_log_branchless_retrieves', $data);
            
            if (!is_array($ids)):
                $ids = array($ids);
            endif;

            $return = $this->db->table('logiref_log_branchless_retrieves')
                    ->whereIn('Id_0', $ids)
                    ->update($data);

            return $return;
        }

        public function save_integrations($data, $id) {
            $this->set_table('logiref_integrations', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_declaration($data, $id) {
            $this->set_table('logiref_declarations', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_note($data, $id) {
            $this->set_table('logiref_notes', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_regularisations($data, $id) {
            $this->set_table('logiref_cbs_regularisations', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function update_note($data, $ids) {
            $this->db->where("logiref_notes.Id_0 IN ('" . $ids . "')");
            return $this->db->update('logiref_notes', $data);
        }

        public function save_token($data, $id) {
            $this->set_table('logiref_integration_tokens', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function update_declaration($data, $ids) {
            $this->db->where("logiref_declarations.Id_0 IN ('" . $ids . "')");
            return $this->db->update('logiref_declarations', $data);
        }

        public function update_prepayement($data, $ids) {
            $this->db->where("logiref_sydonia_prepayments.Id_0 IN (" . $ids . ")");
            return $this->db->update('logiref_sydonia_prepayments', $data);
        }

        public function update_bulletin($data, $ids) {
            if (!is_array($ids))
                $ids = array($ids);

            $return = $this->db->table('logiref_integration_sydonia')
                    ->whereIn('Id_0', $ids)
                    ->update($data);

            return $return;
        }
        

        public function update_bulletin_batch($data, $ids) {
            if (!is_array($ids)):
                $ids = array($ids);
            endif;

            $return = $this->db->table('logiref_integration_sydonia')
                    ->whereIn('Id_0', $ids)
                    ->update($data);

            return $return;
        }
        
        public function lock_batch_paiement($data, $ids) 
        {
                    if (!is_array($ids)):
                    $ids = array($ids);
                    endif;

                    $return = $this->db->table('logiref_integration_sydonia_batchs')
                    ->whereIn('Id_0', $ids)
                    ->update($data);

                    return $return;
        }

    // prepaiements ___________________________________________

        public function get_prepaiements_log($day) {
            $role = $_SESSION['Logiref_role'];

            $st = "  Date_1 LIKE '%" . $day . "%'";
            $query = $this->db->table('logiref_prepayments_logs')
                    ->select('logiref_prepayments_logs.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();
            return $result;
        }

    //______________________________________

        public function update_paiement($data, $ids) {
            $this->db->where("logiref_bulletins.Declaration_12 IN ('" . $ids . "')");
            return $this->db->update('logiref_bulletins', $data);
        }

        public function update_sydonia_declaration($data, $ids) {
            $this->db->where("logiref_sydonia_declarations.Id_0 IN (" . $ids . ")");
            return $this->db->update('logiref_sydonia_declarations', $data);
        }

        public function save_isys_account($data, $id) {
            $this->set_table('logiref_isys_accounts', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_logs_branchless($data, $id) {
            $this->set_table('logiref_log_branchless_retrieves', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_sydonia_account($data, $id) {
            $this->set_table('logiref_sydonia_accounts', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_batch_bulletin($data, $id) {
            $this->set_table('logiref_integration_sydonia_batchs', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function save_integration_sftp($data, $id) {
            $this->set_table('logiref_integration_sftp', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }

        public function update_batch_bulletin($data, $ids) {
            if (!is_array($ids)):
                $ids = array($ids);
            endif;

            $return = $this->db->table('logiref_integration_sydonia_batchs')
                    ->whereIn('Lot_14', $ids)
                    ->update($data);

            return $return;
        }

        public function update_batch_bulletin_with_reference($data, $ids) {
            if (!is_array($ids)):
                $ids = array($ids);
            endif;

            $return = $this->db->table('logiref_integration_sydonia_batchs')
                    ->whereIn('Refop_25', $ids)
                    ->update($data);

            return $return;
        }

        public function update_cbs_instructions_guichet_unique_dgda($data, $reference) {
            return $this->db->table('logiref_cbs_instructions_dgda')
                    ->where('Paiementid_4', $reference)
                    ->where('Status_2', 1)
                    ->update($data);
        }

        public function update_declaration_by_ref($data, $reference) {
            return $this->db->table('logiref_integration_declaration')
                    ->where('Noteid_9', $reference)
                    ->update($data);
        }
        public function update_note_by_ref($data, $reference) {
            return $this->db->table('logiref_integration_logirad')
                    ->where('PerceptionNumber_10', $reference)
                    ->update($data);
        }
        function generate_unique_reference() {
                $datetimePart = date('Hisdmy');
                $randomPart = substr(bin2hex(random_bytes(2)), 0, 4);
                $uniqueReference = $datetimePart . $randomPart;

                return $uniqueReference;
        }

        public function delete_bls($data, $ids, $concat = false)
        {
                if (!is_array($ids)) {
                    $ids = [$ids];
                }

                $builder = $this->db->table('logiref_integration_sydonia');

                if (isset($data['Status_2'])) {
                    $builder->set('Status_2', $data['Status_2']);
                }

                if (isset($data['Paiementkey_42'])) {
                    if ($concat === true) {
                        $builder->set(
                            'Paiementkey_42',
                            "CONCAT(Paiementkey_42, '," . "_" . $data['Paiementkey_42'] . "')",
                            false // ⚡ important pour ne pas échapper la fonction SQL
                        );
                    } else {
                        $builder->set('Paiementkey_42', $data['Paiementkey_42']);
                    }
                }

                // ✅ si tu veux aussi mettre Account_3 = 0 et Treated_45 = 5
                $builder->set('Account_3', 0);
                $builder->set('Treated_45', 5);
                $builder->set('Deletion_48', gmdate('Y-m-d H:i:s'));
                $builder->set('Deletedby_49', $_SESSION['userdata']['user_id'] ?? "");

                $builder->whereIn('Id_0', $ids);

                return $builder->update();
        }

    

    public function save_immatriculation($data)
    {
            $this->set_table("logiref_integration_immatriculation","Id_0","Id_0 DESC");
            return $this->saveData($data);
    }


    public function get_paiement_immatriculation_attempts($id = NULL,$priority = NULL)
    {
            $this->set_table('logiref_cbs_instructions_immatriculation I', 'I.Id_0', 'I.Id_0 DESC');
            $data= $this->get_by(array('Paiementid_4' => $id,'Priority_27'=>$priority), TRUE);
            if(!empty($data))
            {
                    return $data->Attempts_29;
            }
            else
            {
                    return 0;
            }
    }


    public function update_integration_immatriculation_attempts($paiement_id, $priority)
    {
            $attempts = $this->get_paiement_immatriculation_attempts($paiement_id, $priority);
            $data = array(
                    'Attempts_29' => $attempts + 1,
            );

            $return = $this->db->table('logiref_cbs_instructions_immatriculation')
                ->where('Paiementid_4', $paiement_id)
                ->where('Priority_27',$priority);

            return  $return->update($data);
            
    }

    public function update_immatriculation($data,$id)
    {
            $this->set_table("logiref_integration_immatriculation","Id_0","Id_0 DESC");
            return $this->saveData($data,$id);
    }


    public function get_integration_immatriculation($id)
    {
            $builder=$this->db->table("logiref_integration_immatriculation");
            $result=$builder->select('*')->where("Id_0",$id)->get()->getRow();
            return $result;
    }

    public function get_integration_immatriculation_by_reference($numero_note)
    {
            $builder=$this->db->table("logiref_integration_immatriculation");
            $result=$builder->select('*')->where("Reference_6",$numero_note)->get()->getRow();
            return $result;
    }

    
    public function get_instructions_from_journalisation_by_id($ids) {
        
        $branch = $_SESSION['Logiref_guichet'];

        $st = " Status_2 ='1' AND Id_0 IN (" . $ids . ") AND Branch_15 ='".$branch."' ";

        $query = $this->db->table('logiref_cbs_integration_journalisation_dgda_comptant')
                ->select('logiref_cbs_integration_journalisation_dgda_comptant.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    
    public function remove_all_special_characters($texte)
    {
        // 1. Décoder les entités HTML (&lt; &gt; &amp; etc.)
        $texte = html_entity_decode($texte, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // 2. Supprimer les accents
        $texte = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texte);

        // 3. Supprimer tous les caractères spéciaux
        $texte = preg_replace('/[^a-zA-Z0-9]/', ' ', $texte);

        // 4. Nettoyer les espaces multiples
        $texte = preg_replace('/\s+/', ' ', trim($texte));

        return $texte;
    }
}
