<?php

namespace Modules\Branch\Models;

use CodeIgniter\Model;
use App\Models\MY_Reporting;
use stdClass;

class ReportingModel extends MY_Reporting
{
        /* Presentation: 
        * Last update
        * By Papin  on the 25.12.2020
        *  *************************************************************************************************************************SECTION 1
        */

       /*
        * Protected and public variables 
        * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        * Get Information: return a single item
        * Use: for creation, for display, for updates
        * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
        * *************************************************************************************************************************SCETION 2
        */

       protected $_table_name = '';
       protected $_primary_key = '';
       protected $_order_by = '';
       protected $_timestamps = FALSE;
       protected $_date_created = '';
       protected $_date_modified = '';
       public $regies = array(
           '' => '',
           'DGI' => 'DGI',
           'DGRAD' => 'DGRAD'
       );

       public function __construct() 
       {
               parent::__construct();
       }

       protected function get_logiref_role(): int
       {
               return (int) ($_SESSION['Logiref_role'] ?? 0);
       }

       protected function restrict_to_current_guichet(): bool
       {
               return in_array($this->get_logiref_role(), [3, 4, 7], true);
       }

       protected function restrict_to_current_agence(): bool
       {
               $role = $this->get_logiref_role();
               return $role > 2 && $role !== 8;
       }

       protected function is_maker_role(): bool
       {
               return in_array($this->get_logiref_role(), [4, 7], true);
       }
       
       /*
     * Get Information: return a single item
     * Use: for creation, for display, for updates
     * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
     * *************************************************************************************************************************SCETION 2
     */

    public function get_OBJE_info($oid = NULL) 
    {
            if ($oid == NULL) 
            {
                    $obj = new stdClass();
                    $obj->Id_0 = '';
                    $obj->Date_1 = gmdate('Y-m-d H:i:s');
                    $obj->Status_2 = ''; //0: Deleted, 1: In Progress, 2: Completed
                    $obj->Account_3 = '';
                    $obj->Creator_4 = '';
                    $obj->Changes_5 = '';
                    $obj->Changer_6 = '';

                    #Add more here
                    return $obj;
            } 
            else 
            {
                    $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                    return $this->get_by(array('Id_0' => $oid), TRUE);
            }
    }

    /*
     * Get Information: returns an array
     * Use: for indexation, for dropdon etc
     * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
     *  *************************************************************************************************************************SECTION 3
     */

    public function get_dropdown($item) 
    {
            $account_id = $this->session->userdata['account_id'];

            if ($item == "OBJECT NAME") 
            {
                    $this->db->order_by('Id_0');
                    $query = $this->db->get('main_countries');
                    $ddmenu_country = array();
                    $ddmenu_country['0'] = ' ';
                    foreach ($query->result_array() as $row) 
                    {
                            $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                    }
                    return $ddmenu_country;
            } 
            elseif ($item == "OBJECT NAME") 
            {
                    $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                    $where = "Status_2 !='0'";
                    $this->db->where($where, NULL, FALSE);
                    $this->db->order_by('NAME');
                    $query = $this->db->get('TABLE_NAME');
                    $ddmenu = array();
                    foreach ($query->result_array() as $row) 
                    {
                            $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                    }
                    return $ddmenu;
                
            }
    }
    
    public function get_reports_bls(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition
        $st = "Status_2 != 0 AND Account_3 = '{$accountId}'";

        if (isset($_POST['Service']) && $_POST['Service'] != '')
            $st .= " AND Office_6 ='" . $_POST['Service'] . "'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Integration_16 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Integration_16 AS DATE) = CURRENT_DATE";

        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND User_15 ='" . $_POST['user'] . "'";
        
        // Restrictions selon rôle
        if ($restrictions) 
        {
            if ($this->restrict_to_current_agence())
                $st .= " AND Agence_32 = '{$_SESSION['Logiref_agence']}'";
            if ($this->restrict_to_current_guichet())
                $st .= " AND Agence_32 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_integration_sydonia')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }
    
    public function get_reports_filter_dgda($data) {
        $user = $this->session->userdata['user_id'];
        #Query
        $st = " Account_3='" . $this->session->userdata['account_id'] . "' ";

        #Filtre d'affichage
        if (isset($data['guichet']) && $data['guichet'] != '')
            $st .= " AND Agence_32='" . $data['guichet'] . "'";
        if (isset($data['start']) && $data['start'] != '')
            $st .= " AND Integration_16 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

        #Run
        $query = $this->db->table('logiref_integration_sydonia')
                ->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC')
                ->where($st)
                ->orderBy('Date_1 DESC')
                ->get();
        return $query->getResult();
    }

    
    public function get_report_paiements_dgi($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
            $date = gmdate('Y-m-d');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10 > '0' AND Status_2=3 AND Beneficaire_15='DGI' AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51=''";
            #Restriction
            if ($this->restrict_to_current_guichet())
                $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
            
            $query = $this->db->table('logiref_paiements_tresor')
                    ->select('logiref_paiements_tresor.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(500)
                    ->get();
            # var_dump($query->getResult());die;
            return $query->getResult();
    }
    public function get_report_paiements_dgrad($status = NULL, $param = NULL, $type = NULL, $arg = NULL) 
    {
            $date = gmdate('Y-m-d');
            $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10 > '0' AND Status_2=3 AND Beneficaire_15='DGRAD' AND Sydonia_44=0 AND Sydonia_49=0 AND Customercode_51='' ";
            #Restriction
            if ($this->restrict_to_current_guichet())
                $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
            
            $query = $this->db->table('logiref_paiements_tresor')
                    ->select('logiref_paiements_tresor.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->limit(500)
                    ->get();
            # var_dump($query->getResult());die;
            return $query->getResult();
    }
    
    public function get_report_paiements_dgrad_filter($type = NULL, $data = NULL) 
    {
        $st = "Status_2=3 AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGRAD') AND (Sydonia_44 =0 AND Sydonia_49 = 0)";

        #Filtre d'affichage
        if (isset($_POST['Recette']) && $_POST['Recette'] != '')
            $st .= " AND Typerecette_17='" . $_POST['Recette'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9='" . $_POST['user'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get();

        return $query->getResult();
    }

    
    public function get_report_paiements_dgda($type = NULL, $data = NULL) 
    {
            $date = gmdate('Y-m-d');
            $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Beneficaire_15='DGDA' AND (Sydonia_44 != 0 OR Sydonia_49 != 0) AND Status_2 = 4 AND Date_1 < '".$date."'";
            #Restriction
            if ($this->restrict_to_current_guichet())
                $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

            $query = $this->db->table('logiref_paiements_tresor')
                    ->select('logiref_paiements_tresor.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->limit(500)
                    ->get();

            return $query->getResult();
    }
    
    public function get_paiements_tresor($type = NULL, $data = NULL) {

        $account_id = $this->session->userdata['account_id'];
        $user_id = $this->session->userdata['user_id'];

        $st = " Account_3='" . $account_id . "' AND Beneficaire_15 = 'DGI' AND  Checkerid_10 != 0 AND Sydonia_44 = 0 AND Sydonia_49 = 0 AND Status_2=3";

        #Filtre d'affichage
        //if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17 ='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
        if (isset($_POST['user']) && $_POST['user'] != '')
            $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";

        #Restriction
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
        if ($_SESSION['Logiref_role'] == 3)
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->get();

        return $query->getResult();
    }

    public function get_paiements_dgi(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition : paiements DGI validés
        $st = "Status_2 != '0' AND Account_3 = '{$accountId}' AND Beneficaire_15 = 'DGI' AND Checkerid_10 != 0";

        // Différenciation selon Sydonia
        // - get_report_paiements_dgi : (Sydonia_44 = 0 OR Sydonia_49 != 0)
        // - get_paiements_tresor     : Sydonia_44 = 0 AND Sydonia_49 = 0
        if (!empty($_POST['mode']) && $_POST['mode'] === 'report')
            $st .= " AND (Sydonia_44 = 0 OR Sydonia_49 != 0)";
        else 
            $st .= " AND Sydonia_44 = 0 AND Sydonia_49 = 0";

        // Filtres dynamiques
        if (!empty($_POST['Typerecette_17']))
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";

        if (!empty($_POST['user']))
            $st .= " AND Makerid_9 = '{$_POST['user']}'";



        // Restrictions par rôle
        if ($restrictions) 
        {
            if (isset($_POST['guichet']) && $_POST['guichet'] != '')
                $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
            else
                if (in_array($this->get_logiref_role(), [3, 4, 7], true))
                    $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }

    public function get_paiements_dgrad(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // Base condition : paiements DGI validés
        $st = "Status_2 != '0' AND Account_3 = '{$accountId}' AND Beneficaire_15 = 'DGRAD' AND Checkerid_10 != 0";

        // Différenciation selon Sydonia
        // - get_report_paiements_dgi : (Sydonia_44 = 0 OR Sydonia_49 != 0)
        // - get_paiements_tresor     : Sydonia_44 = 0 AND Sydonia_49 = 0
        if (!empty($_POST['mode']) && $_POST['mode'] === 'report')
            $st .= " AND (Sydonia_44 = 0 OR Sydonia_49 != 0)";
        else 
            $st .= " AND Sydonia_44 = 0 AND Sydonia_49 = 0";

        // Filtres dynamiques
        if (!empty($_POST['Typerecette_17']))
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";

        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";

        if (!empty($_POST['user']))
            $st .= " AND Makerid_9 = '{$_POST['user']}'";

        // Restrictions par rôle
        if ($restrictions) 
        {
            if (isset($_POST['guichet']) && $_POST['guichet'] != '')
                $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
            else
                if (in_array($this->get_logiref_role(), [3, 4, 7], true))
                    $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        // Exécution
        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Date_1', 'DESC')
                ->limit(800)
                ->get()
                ->getResult();
    }
    
    public function get_paiements_tresor_dgrad($type = NULL, $data = NULL) {
       $account_id = $this->session->userdata['account_id'];
       $user_id = $this->session->userdata['user_id'];

       $st = " Account_3='" . $account_id . "' AND Beneficaire_15 = 'DGRAD' AND Sydonia_44 = 0 AND Sydonia_49 = 0 AND Status_2=3";

       #Filtre d'affichage
       if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
           $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
       if (isset($_POST['start']) && $_POST['start'] != '')
           $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
       if (isset($_POST['guichet']) && $_POST['guichet'] != '')
           $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";
       if (isset($_POST['user']) && $_POST['user'] != '')
           $st .= " AND Makerid_9 ='" . $_POST['user'] . "'";

       #Restriction
       if ($this->is_maker_role())
           $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
       if ($_SESSION['Logiref_role'] == 3)
           $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";

       $query = $this->db->table('logiref_paiements_tresor')
               ->select('logiref_paiements_tresor.*')
               ->where($st)
               ->orderBy('Date_1', 'DESC')
               ->get();

       return $query->getResult();
   }
   
   public function get_fond_tresor($type = NULL, $data = NULL) {
        $user = $this->session->userdata['user_id'];
        $this->_table_name = '';
        #Query
        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
        $this->db->from('logiref_paiements_tresor');
        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

        #Filtre d'affichage
        if (isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15'] != '')
            $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_15'] . "'";
        if (isset($_POST['Typerecette_17']) && $_POST['Typerecette_17'] != '')
            $st .= " AND Typerecette_17='" . $_POST['Typerecette_17'] . "'";
        if (isset($_POST['start']) && $_POST['start'] != '')
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";
        if (isset($_POST['guichet']) && $_POST['guichet'] != '')
            $st .= " AND Guichet_21='" . $_POST['guichet'] . "'";

        #Restriction
        if ($this->restrict_to_current_agence())
            $st .= " AND Agence_20='" . $_SESSION['Logiref_agence'] . "'";
        if ($this->is_maker_role())
            $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "' AND Makerid_9 ='" . $user . "'";

        #Run
        $this->db->where($st, NULL, FALSE);
        $this->db->order_by('Date_1 DESC');
        return $this->get_all();
    }
    
    public function get_paiements_tresor_gu(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        // BASE OBLIGATOIRE
        $st = "Account_3 = '{$accountId}'  AND Status_2 != 0 AND (Sydonia_44 != 0 OR Sydonia_49 != 0)";

        // FILTRES D'AFFICHAGE
        if (!empty($_POST['Regie'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Regie']}'";

        if (!empty($_POST['Office'])) 
            $st .= " AND Service_16 = '{$_POST['Office']}'";

        if (!empty($_POST['Recette']))
            $st .= " AND Typerecette_17 = '{$_POST['Recette']}'";

        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";


        // GESTION DES DATES (POINT CLÉ)
        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Date_1 AS DATE) = CURRENT_DATE";
    
        // RESTRICTION PAR RÔLE
        if ($restrictions && $this->restrict_to_current_guichet())
            $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";

        return $this->db->table('logiref_paiements_tresor')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }
    public function filter_paiements_gu_tresor($data) {

        $user = $this->session->userdata['user_id'];
        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

        #Filtre d'affichage
        if (isset($data['Regie']) && $data['Regie'] != '')
            $st .= " AND Beneficaire_15='" . $data['Regie'] . "'";
        if (isset($data['Office']) && $data['Office'] != '')
            $st .= " AND Service_16='" . $data['Office'] . "'";
        if (isset($data['Recette']) && $data['Recette'] != '')
            $st .= " AND Typerecette_17='" . $data['Recette'] . "'";
        if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
            $st .= " AND Datevaleur_31 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

        #Restriction
        //if($_SESSION['Logiref_role']>2) $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21='".$guichet."' AND (Sydonia_44 != 0  || Sydonia_49 != 0) AND Status_2 != 0";

        $query = $this->db->table('logiref_paiements_tresor')
                ->select('logiref_paiements_tresor.*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get();
        return $query->getResult();
    }
    public function get_paiements_propres_gu(bool $restrictions = true)
    {
        $accountId = $this->session->userdata['account_id'];

        $st = "Account_3 = '{$accountId}' AND Status_2 != 0 AND (Sydonia_44 != 0 OR Sydonia_49 != 0)";

        if (!empty($_POST['Regie'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Regie']}'";
        if (!empty($_POST['Office'])) 
            $st .= " AND Agence_20 = '{$_POST['Office']}'";
        if (!empty($_POST['Recette']))
            $st .= " AND Typerecette_17 = '{$_POST['Recette']}'";
        if (!empty($_POST['guichet']))
            $st .= " AND Guichet_21 = '{$_POST['guichet']}'";

        // GESTION DES DATES
        if (!empty($_POST['start']) && !empty($_POST['end']))
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Datevaleur_31 AS DATE) = CURRENT_DATE";

        if ($restrictions) 
        {
            if ($this->restrict_to_current_agence())
                $st .= " AND Agence_20 = '{$_SESSION['Logiref_agence']}'";
            if ($this->is_maker_role())
                $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}'";
        }

        return $this->db->table('logiref_paiements_propres')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }
    public function filter_paiements_gu_propres($data) {
        $user = $this->session->userdata['user_id'];

        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

        #Filtre d'affichage
        if (isset($data['Regie']) && $data['Regie'] != '')
            $st .= " AND Beneficaire_15='" . $data['Regie'] . "'";
        if (isset($data['Office']) && $data['Office'] != '')
            $st .= " AND Service_16='" . $data['Office'] . "'";
        if (isset($data['Recette']) && $data['Recette'] != '')
            $st .= " AND Typerecette_17='" . $data['Recette'] . "'";
        if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != ''))
            $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

        #Restriction
        //if($_SESSION['Logiref_role']>2) $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_21='".$guichet."' AND (Sydonia_44 != 0  || Sydonia_49 != 0) AND Status_2 != 0";


        $query = $this->db->table('logiref_paiements_propres')
                ->select('logiref_paiements_propres.*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get();

        return $query->getResult();
    }
    
    public function get_fond_propres($type = NULL, $data = NULL) 
    {
        $user = $this->session->userdata['user_id'];
        $accountId = $this->session->userdata['account_id'];

        $st = "Account_3='{$accountId}' AND Beneficaire_15 != 'DGDA' AND Sydonia_44 != 0 AND Status_2 != 0";

        if (!empty($_POST['start']) && !empty($_POST['end'])) 
            $st .= " AND Datevaleur_31 BETWEEN '{$_POST['start']}' AND '{$_POST['end']}'";
        else
            $st .= " AND CAST(Date_1 AS DATE) = CURRENT_DATE";
        
        if (!empty($_POST['Beneficaire_15'])) 
            $st .= " AND Beneficaire_15 = '{$_POST['Beneficaire_15']}'";
        if (!empty($_POST['Typerecette_17'])) 
            $st .= " AND Typerecette_17 = '{$_POST['Typerecette_17']}'";
        if ($this->restrict_to_current_agence()) 
            $st .= " AND Agence_20 = '{$_SESSION['Logiref_agence']}'";
        if ($this->is_maker_role()) 
            $st .= " AND Guichet_21 = '{$_SESSION['Logiref_guichet']}' AND Makerid_9 = '{$user}'";

        return $this->db->table('logiref_paiements_propres')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0', 'DESC')
                ->get()
                ->getResult();
    }

   
    
    public function get_prepayments_customers_validated()
    {
            $account = $this->session->userdata['account_id'];

            $st = "Account_3='".$account."' AND Status_2 = '3' ";

            $query = $this->db->table('logiref_sydonia_prepayments')
                            ->select('logiref_sydonia_prepayments.*')
                            ->where($st)
                            ->orderBy('Id_0', 'DESC')
                            ->get();

            $payments = $query->getResult();

            $customers= array();
            $counts = array();
            $amounts = array();

            foreach($payments as $line):

                    $key = $line->AccountRef_14.$line->Office_8;

                    if(key_exists($key, $counts))
                    {
                        $counts[$key] += 1;
                        $amounts[$key]+= $line->Amount_18;
                    }
                    else
                    {
                        $counts[$key] = 1;
                        $amounts[$key] = $line->Amount_18;
                    }

                    $line->total = $counts[$key];
                    $line->amounts = $amounts[$key];
                    $customers[$line->AccountRef_14][$line->Office_8] = $line;


            endforeach;

            return $customers;
    }
       
}
