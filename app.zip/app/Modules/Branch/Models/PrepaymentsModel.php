<?php

namespace Modules\Branch\Models;

use stdClass;
use App\Models\MY_Transaction;

class prepaymentsModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        public $ackmessages =  array(
            'OK'=>'Cl&ocirc;turer la transaction',
            'KO'=>'Reinitaliser le bulletin',
            ''=>''
        );
        public $declaration_ackmessages =  array(
            'OK'=>'Cl&ocirc;turer la transaction',
            'KO'=>'D&eacute;claration non valid&eacute;e',
            ''=>''
        );
        
        public $prepayments_status_color = array(
            '1'=>'label-upcoming',
            '2' => 'label-ongoing',
            '3' => 'label-completed',
            '4' => 'label-completed',
            '5' => 'label-muted'
        );
        
        public $prepayments_status = array(
            '1'=> 'Nouveau paiement',
            '2' => 'En attente de validation',
            '3' => 'Paiement valid&eacute;',
            '4' => 'Transaction cl&ocirc;r&eacute;e',
            '5' => 'Paiement rejet&eacute;'
        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('TABLE_NAME')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('TABLE_NAME')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
      
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function check_bulletin_prepayment_by_customer()
        {
                $date = gmdate('Y-m-d');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Date_1 LIKE '%".$date."%' ";
                
                $_POST['total_amount'] = str_replace(' ', '', $_POST['total_amount']);
                $_POST['total_amount'] = str_replace(',','.', $_POST['total_amount']);
                
                if(isset($_POST['total_amount'])) $st .= " AND Amout_12 ='".$_POST['total_amount']."'";
                if(isset($_POST['Declarant'])) $st .= " AND Declarant_8 ='".$_POST['Declarant']."'"; 
                if(isset($_POST['account_reference'])) $st .= " AND AccountRef_9 ='".$_POST['account_reference']."'";
                if(isset($_POST['Npaiements'])) $st .= " AND Declarations_10 ='".$_POST['Npaiements']."'"; 
               
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $return = $query->getResult();
                
                // if(isset($return[0]->Id_0)) 
                // {
                //         $result = current($return);
                        
                //         $office = json_decode($result->Office_7);
                        
                //         if(isset($office[0]) && $office[0] == $_POST['Office'][0])
                //         {
                //                 return $return;
                //         }
                //         else
                //         {
                //                 return [];
                //         }
                // }
                // else
                // {
                return $return;
                // }
        }
        
        public function check_bulletin_prepayment_by_office()
        {
                $date = gmdate('Y-m-d');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Date_1 LIKE '%".$date."%' ";
                
                $_POST['total_amount'] = str_replace(' ', '', $_POST['total_amount']);
                $_POST['total_amount'] = str_replace(',','.', $_POST['total_amount']);
                
                if(isset($_POST['total_amount'])) $st .= " AND Amout_12 ='".$_POST['total_amount']."'";
                if(isset($_POST['Declarant'])) $st .= " AND Declarant_8 ='".$_POST['Declarant']."'"; 
                if(isset($_POST['Npaiements'])) $st .= " AND Declarations_10 ='".$_POST['Npaiements']."'"; 
                
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $return = $query->getResult();
                
                if(isset($return[0]->Id_0)) 
                {
                        $result = current($return);
                        
                        $office = json_decode($result->Office_7);
                        
                        if(isset($office[0]) && $office[0] == $_POST['Office'][0])
                        {
                                return $return;
                        }
                        else
                        {
                                return [];
                        }
                }
                else
                {
                        return $return;
                }
        }
        
        public function get_unvalidated_bls()
        {
                $user = $this->session->userdata['user_id'];
                $account = $this->session->userdata['account_id'];
                
                $role = $_SESSION['Logiref_role'];
                
                $st = "Account_3='" . $account . "' AND Agence_30 = '".$_SESSION['Logiref_guichet']."'";

                if($role !=4)$st.= "AND Status_2 = '2'";
                if($role == 4)$st.= "AND Status_2 = '2' AND Creator_4 = '".$user."' ";

                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->limit(500)
                                ->get();

                return  $query->getResult();
        }
        
        public function get_unvalidated_integrate()
        {
            $st = "Account_3='" . $account . "' AND Agence_30 = '".$_SESSION['Logiref_guichet']."' AND Status_2 = '7' ";

            $query = $this->db->table('logiref_sydonia_prepayments')
                            ->select('logiref_sydonia_prepayments.*')
                            ->where($st)
                            ->orderBy('Date_1', 'DESC')
                            ->limit(500)
                            ->get();

            return  $query->getResult();
        }
        
        public function get_validated_bls($type=NULL)
        {
                $user = $this->session->userdata['user_id'];
                $account = $this->session->userdata['account_id'];
                
                $date = gmdate('Y-m-d');
                
                $role = $_SESSION['Logiref_role'];
                
                $st = "Account_3='" . $account . "' AND Agence_30 = '".$_SESSION['Logiref_guichet']."' AND (Status_2 = '6' OR Status_2 = '3') ";
                
                if($type == 'dailly') $st .= " AND Date_1 LIKE '%".$date."%' ";

                if($type=='penalities') $st.= " AND (Status_2 = '3' OR Status_2 = '2') AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1";
                if($role == 4) $st.= " AND Creator_4 = '".$user."' ";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->limit(500)
                                ->get();

                return  $query->getResult();
        }
        
        public function get_validated_prepaids ($type=NULL)
        {

                $account = $this->session->userdata['account_id'];

                $agence = $_SESSION['Logiref_guichet'];

                $st = "Account_3='" . $account . "' AND Status_2 = '3' AND Agence_30 = '".$agence."'  ";

                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->limit(500)
                                ->get();
               #var_dump($query->getResult());die;

                return  $query->getResult();
        }
        
        
        public function  get_prepayments_by_lot($ids)
        {   
                $account = $this->session->userdata['account_id'];
                
                $st = " Status_2 ='1' AND Account_3='".$account."' AND Id_0 IN (".$ids.")";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $payments = $query->getResult();
                
                $bureaux = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->Office_8.$line->AccountRef_14;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $bureaux[$line->Office_8][$line->AccountRef_14] = $line;
                    
                endforeach;
                
                
                return $bureaux;
        }
        
        public function get_integration_sftp_summary_by_id($id = NULL) 
        {
                $this->set_table('logiref_cbs_treatment_sftp_dgda i', 'i.Id_0', 'i.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }
        
        public function get_all_prepayments($status)
        {
                
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' ";
                
                if($status == "new"):
                    
                        $st.= " AND Status_2 ='1' ";
                
                elseif($status):
                    
                        $st.= " AND Status_2 > 1 ";
                
                endif;
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                $payments = $query->getResult();
                
                $bureaux = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->Office_8.$line->AccountRef_14;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $bureaux[$line->Office_8][$line->AccountRef_14] = $line;
                    
                endforeach;
                
                
                return $bureaux;
        }
        
        public function get_prepayments_office($status)
        {
                
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' ";
                
                if($status == "new"):
                    
                        $st.= " AND Status_2 ='1' ";
                
                elseif($status):
                    
                        $st.= " AND Status_2 > 1 ";
                
                endif;
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                $payments = $query->getResult();
                
                $bureaux = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->Office_8.$line->AccountRef_14;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $bureaux[$line->Office_8][$line->AccountRef_14] = $line;
                    
                endforeach;
                
                
                return $bureaux;
        }
        
        public function get_prepayments_customers($status)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."'";
                
                if($status == "new"):
                    
                        $st.= " AND Status_2 ='1' ";
                
                elseif($status):
                    
                        $st.= " AND Status_2 > 1 ";
                
                endif;
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                                
                $payments = $query->getResult();
                
                $customers = array();
                $counts    = array();
                $amounts   = array();
                $ids       = array();  # <-- nouveau tableau pour accumuler les Id_0

                foreach($payments as $line):
                        $key = $line->AccountRef_14.$line->Office_8;

                        if(key_exists($key, $counts)) 
                        {
                                $counts[$key]  += 1;
                                $amounts[$key] += $line->Amount_18;
                                # on ajoute l’Id au tableau existant
                                $ids[$key][]    = $line->Id_0;   
                        } 
                        else 
                        {
                                $counts[$key]  = 1;
                                $amounts[$key] = $line->Amount_18;
                                # première valeur dans le tableau des Ids
                                $ids[$key]     = array($line->Id_0); 
                        }

                        $line->total   = $counts[$key];
                        $line->amounts = $amounts[$key];
                        # <-- tableau complet des Ids
                        $line->ids     = $ids[$key];  

                        $customers[$line->AccountRef_14][$line->Office_8] = $line;
                endforeach;
                
                
                return $customers;
        }

        public function get_prepayments_customers_treated()
        {
                $account = $this->session->userdata['account_id'];
                $agence = $_SESSION['Logiref_guichet'];

                $st = "Status_2 != '0' AND Account_3='".$account."' AND Treated_31 !='0' ";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                                
                $payments = $query->getResult();
                
                $customers= array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->AccountRef_14.$line->Office_8;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $customers[$line->AccountRef_14][$line->Office_8] = $line;

                    
                endforeach;
                
                
                return $customers;
        }
        
        public function get_prepayments_customers_validated()
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Status_2 = '3' AND CAST(Date_1 as date)=CURRENT_DATE";

                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                                
                $payments = $query->getResult();
                
                $customers= array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->AccountRef_14.$line->Office_8;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $customers[$line->AccountRef_14][$line->Office_8] = $line;

                    
                endforeach;
                
                return $customers;
        }
        public function get_prepayments_validated_office($status)
        {
                
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Status_2 ='3' ";
                
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                $payments = $query->getResult();
                
                $bureaux = array();
                $counts = array();
                $amounts = array();
                
                foreach($payments as $line):
                    
                        $key = $line->Office_8.$line->AccountRef_14;

                        if(key_exists($key, $counts))
                        {
                            $counts[$key] += 1;
                            $amounts[$key]+= $line->Amount_18;
                        }
                        else
                        {
                            $counts[$key] = 1;
                            $amounts[$key] = $line->Amount_18;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $bureaux[$line->Office_8][$line->AccountRef_14] = $line;
                    
                endforeach;
                
                return $bureaux;
        }
        
        public function  check_prepayments_treated()
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Office_7 = '".$_POST['Office']."' AND AccountRef_9 = '".$_POST['account_reference']."' AND Declarant_8 = '".$_POST['Declarant']."' AND Account_15 = '".$_POST['Compte_33']."' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' ";

                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        
        public function  check_prepayments_treated_office($data)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Office_7 = '".$data['office']."' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' ";

                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        
        
        public function  get_prepayments_by_reference($data)
        {
                $account = $this->session->userdata['account_id'];
                
                //$st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$data['compte']."' AND Office_8 = '".$data['office']."'";
                $st = "Status_2 ='1' AND Account_3='".$account."'";
               
                if (isset($data['compte']) && $data['compte'] !="") $st.=  " AND AccountRef_14 = '".$data['compte']."'";
                if (isset($data['office']) && $data['office'] !="") $st.=  " AND Office_8 = '".$data['office']."'";
      
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        public function  get_prepayments_validated_by_reference($data)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 ='3' AND Account_3='".$account."'";
               
                if (isset($data['compte']) && $data['compte'] !="") $st.=  " AND AccountRef_14 = '".$data['compte']."'";
                if (isset($data['office']) && $data['office'] !="") $st.=  " AND Office_8 = '".$data['office']."'";
      
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        public function  get_prepayments_by_office($data)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$data['compte']."' AND Office_8 = '".$data['office']."'";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        
        public function  get_prepayments_group_offices($data)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Office_8 = '".$data['office']."'";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                return $query->getResult();
        }
        
        
        public function get_payment_to_save($data)
        {
                $account = $this->session->userdata['account_id'];
                //$st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$data['compte']."' AND Office_8 = '".$data['office']."' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' ";
                //$st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$data['account_reference']."' AND Office_8 = '".$data['Office']."' AND Date_1 LIKE '%".gmdate('Y-m-d')."%'  ";
                $st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$data['account_reference']."' AND Office_8 = '".$data['Office']."' ";
      
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();

        }
        
        public function get_prepayments($status=NULL)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Agence_30 = '".$agence."' AND Id_0, COUNT(Id_0) as total, SUM(Amount_18) as amounts";
                
                if($status == "new")
                $st .= " AND Status_2 = 1 AND Date_1 LIKE '%".gmdate('Y-m-d')."%' ";
                elseif($status == "nvalidated")
                $st .= " AND Status_2 = 2";
                elseif($status == "validated")
                $st .= " AND (Status_2 = 3 || Status_2 = 4)";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->groupBy('AccountRef_14')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_treated_by_id($id=NULL)
        {
                $this->set_table('logiref_prepayments_traitements', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }
        
        public function get_prepayments_integrated_by_id($ids) 
        {
                $account = $this->session->userdata['account_id'];

                $st = "Status_2 ='2' AND Account_3='" . $account . "' AND Id_0 IN (" . $ids . ")";

                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_prepayments_by_id($ids) 
        {
                $account = $this->session->userdata['account_id'];

                $st = "Status_2 ='2' AND Account_3='" . $account . "' AND Id_0 IN ($ids)";

                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_prepayments_treated($status=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = "Account_3='".$account."' AND Agence_16 = '".$agence."' AND Status_2 = 2 ";
                
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_treated_by_lot($lot)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3 = '".$account."' AND Lot_19 = '".$lot."' AND (Treated_31 = 0 OR Treated_31 IS NULL)";
       
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }

        public function get_prepayments_unvalidated_by_lot($lot)
        {
		$date = gmdate('Y-m-d');
                $account = $this->session->userdata['account_id'];
		$agence = $_SESSION['Logiref_guichet'];
				
                $st = "(Status_2 = 2 OR Status_2 = 5) AND Account_3='".$account."' AND Lot_19 = '".$lot."' AND Agence_30 = '".$agence."' AND (Treated_31 = 0 OR Treated_31 IS NULL)";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_treated_by_lots_selected($lot)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Lot_11 = '".$lot."' ";
                
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_treatment_by_lot_to_integrate($lot)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Lot_11 IN ($lot) ";
                
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_by_lot_to_integrate($lot)
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Account_3='".$account."' AND Lot_19 IN ($lot) ";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_declarations_by_ref($ref)
        {
                $account = $this->session->userdata['account_id'];
                $st = "Account_3='".$account."' AND  Lot_19 = '".$ref."'";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                $ids = $query->getResult();
                
                $bls = array();
                $amount = array();
                $response = array();
                
                foreach($ids as $bl)
                {
                        $bls[] = $bl->Id_0;
                        $amount[] = $bl->Amount_18;
                }
                
                $response['bulletins']= $bls;
                $response['amounts']= $amount;
                
                return $response;
        }
        
        
        public function get_traitements($status = NULL)
        { 
                $account = $this->session->userdata['account_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = "Account_3='".$account."' AND Agence_16 = '".$agence."'";
                if($status == 'new')
                $st .=  " AND Status_2 = 1";
                elseif($status == 'done')
                $st .=  " AND Status_2 = 2";
                
                $query = $this->db->table('logiref_prepayments_traitements')
                        ->select('logiref_prepayments_traitements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        
        public function get_unvalidated_bls_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                
                $st = "Status_2 = '5' AND Account_3='".$account."' AND Agence_30 = '".$_SESSION['Logiref_guichet']."'";
                
                $query = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        
        public function get_integrations_sftp_treatment_in_progress()
        {
                $agence = $_SESSION['Logiref_guichet'];

                $st = " Branch_11 ='" . $agence . "' AND (Status_2 = 1 OR Status_2 = 2) ";

                $query = $this->db->table('logiref_cbs_treatment_sftp_dgda')
                        ->select('logiref_cbs_treatment_sftp_dgda.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->limit(1)
                        ->get();

                $result = $query->getResult();

                return $result;
        }
        
        public function get_instructions_to_treat_for_sftp_dgda() 
        {
                $branch = $_SESSION['Logiref_guichet'];

                $st = "Status_2 = '1' AND Branch_15 = '".$branch."' ";

                $query = $this->db->table('logiref_cbs_integration_journalisation_dgda_prepayment')
                        ->select('logiref_cbs_integration_journalisation_dgda_prepayment.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                $rows = $query->getResult();

                $result = [];
                $sum = 0;
                $max = 5;

                foreach ($rows as $row) {
                    if ($sum + $row->Nbinstructions_12 > $max) {
                        break;
                    }

                    $result[] = $row;
                    $sum += $row->Nbinstructions_12;
                }

                return $result;
        }
        
        public function get_integrations_sftp_by_treatmentid_and_office($integrationid, $office)
    {
            $agence = $_SESSION['Logiref_guichet'];

            $st = " Id_0 ='" .$integrationid. "' AND Status_2 = '1' AND Office_7 ='" .$office. "' ";
            
            $query = $this->db->table('logiref_integration_sftp')
                    ->select('logiref_integration_sftp.*')
                    ->where($st)
                    ->orderBy('Id_0', 'DESC')
                    ->get();

            $result = $query->getResult();
            
            $return = current($result);

            return $return;
    }
        
        public function get_prepayments_instructions_by_ref($ids) 
        {
                $st = "Status_2 = '1' AND Reference_14 = '".$ids."' AND Priority_24 > 0 AND Montant_10 > 0";
                
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->select('logiref_cbs_prepayments_instructions.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_instructions_integrated_by_lot($lot) 
        {
                $st = "Status_2 = '2' AND Paiementid_4 = '".$lot."' ";
                
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->select('logiref_cbs_prepayments_instructions.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_prepayments_instructions_to_integrate_by_lot($ids) 
        {
                $st = "Status_2 = '1' AND Paiementid_4 IN ($ids) AND Priority_24 = '1'";
                
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->select('logiref_cbs_prepayments_instructions.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                return $query->getResult();
        }
        
        public function get_instructions_prepayments_by_paiement_id($paiement_id)
        {
                
                $agence = $_SESSION['Logiref_guichet'];

                $st = "Status_2!='0' AND Guichet_7='" . $agence . "' AND Paiementid_4 IN($paiement_id) AND Priority_24 = 1 ";
                
                $query = $this->db->table('logiref_cbs_prepayments_instructions')
                                ->select('logiref_cbs_prepayments_instructions.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();

                return  $query->getResult();
        }
        
        public function get_data_cbs_journalisation($paiement_data, $instructions, $bulletin)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */

                $data = array();

                if(!empty($paiement_data) && !empty($instructions))
                {
                        $total_amount_debited = $this->sum_instructions_amount_debited($instructions);
                        $total_amount_credited = $this->sum_instructions_amount_credited($instructions);

                        $data ['Date_1'] = gmdate('Y-m-d h:i:s');
                        $data ['Status_2'] = '1';
                        $data ['Account_3'] = $this->session->userdata['account_id'];
                        $data ['Creator_4'] = $this->session->userdata['user_id'];
                        $data ['Office_7'] = $paiement_data['Service_16'];
                        $data ['Amountdebited_8'] = $total_amount_debited;
                        $data ['Amountcredited_9'] = $total_amount_credited;
                        $data ['Instructions_11'] = json_encode($instructions);
                        $data ['Nbinstructions_12'] = count($instructions);
                        $data ['Bulletinamount_13'] = $bulletin->Amount_18;
                        $data ['Bulletinid_14'] = $bulletin->Id_0;
                        $data ['Branch_15'] = $_SESSION['Logiref_guichet'];
                        $data ['Account_16'] = $bulletin->Account_22;
                        
                        $data ['Designation_17'] = $this->remove_all_special_characters($paiement_data['Designation_14']);
                        $data ['Nif_18'] = $paiement_data['Nif_13'];

                        $return = ['code' => 200,'message'=>'valid', 'data' => $data];
                }
                else
                {
                        $return = ['code' => 404,'message'=>'valid', 'data' => $data];
                }

                return $return;
        }
        
        public function clean_array_special_characters(array $data)
        {
                foreach ($data as $key => $value) 
                {
                        if (is_array($value))
                        {
                                // Appel récursif pour sous-tableaux
                                $data[$key] = $this->clean_array_special_characters($value);
                        } 
                        else 
                        {
                                // Nettoyage de la valeur (si string uniquement)
                                if (is_string($value)) 
                                {
                                        if($key == 'Libelle_12')
                                        {
                                                $data[$key] = $this->remove_all_special_characters($value);
                                        }
                                }
                        }
                }

                return $data;
        }

        public function get_data_integration_sftp($office_data, $path, $id, $reference)
        {
                $data = [];

                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                $data['Status_2'] = 1;
                $data['Account_3'] = $this->session->userdata['account_id'];
                $data['Creator_4'] = $this->session->userdata['user_id'];
                $data['Office_7'] = $office_data['office'];
                $data['Amountdebited_8'] = $office_data['amount_debited'];
                $data['Amountcredited_9'] = $office_data['amount_credited'];
                $data['Bankaccount_10'] = $office_data['bankaccount'];
                $data['Nbinstructions_11'] = $office_data['nbinstructions'];
                $data['Nbulletins_12'] = $office_data['nbulletins'];
                $data['Journalisationid_13'] = json_encode($office_data['journalisationid']);
                $data['Bulletinids_14'] = json_encode($office_data['bulletinids']);
                $data['Branch_15'] = $_SESSION['Logiref_guichet'];
                $data['Path_16'] = $path;
                $data['Paymenttype_17'] = 'prepayment';
                $data['Treatmentid_18'] = $id;
                $data['Logirefid_19'] = $reference;

                return $data;
        }

        public function get_instructions_by_office_from_journalisation($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $instructions_by_office = [];

                foreach($data as $row)
                {
                        $ids[] = json_decode($row['journalisationid'], true);
                }

                $tab = array_merge(...$ids);

                # implode le tableau pour avoir une chaine des ids
                $ids = implode(',',$tab);

                $raw_journalisation = $this->get_instructions_from_journalisation_by_id($ids);

                # aggregate instructions by office
                foreach($raw_journalisation as $row)
                {
                        $instructions_by_office[$row->Office_7][] = $row;
                }

                return $instructions_by_office;
        }

        public function sum_instructions_amount_debited($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_debited = 0;

                foreach($data as $row)
                {
                        $total_amount_debited = $row['Montant_10'] + $total_amount_debited;
                }

                return $total_amount_debited;
        }

        public function sum_instructions_amount_credited($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_credited = 0;

                foreach($data as $row)
                {
                        $total_amount_credited = $row['Montant_10'] + $total_amount_credited;
                }

                return $total_amount_credited;
        }   

        public function sum_instructions_amount_debited_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */

                $total_amount_debited_by_office = 0;

                foreach($data as $row)
                {
                        $total_amount_debited_by_office = $row->Amountdebited_8 + $total_amount_debited_by_office;
                }

                return $total_amount_debited_by_office;
        }

        public function sum_instructions_amount_credited_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $total_amount_credited_by_office = 0;

                foreach($data as $row)
                {
                        $total_amount_credited_by_office = $row-> Amountcredited_9  + $total_amount_credited_by_office;
                }

                return $total_amount_credited_by_office;
        }

        public function sum_nb_bulletins_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $nb_bulletins_by_office = 0;

                foreach($data as $row)
                {
                        $nb_bulletins_by_office = $nb_bulletins_by_office  + 1;
                }

                return $nb_bulletins_by_office;
        }

        public function sum_nb_instructions_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $nb_instructions_by_office = 0;

                foreach($data as $row)
                {
                        $nb_instructions_by_office = $row->Nbinstructions_12  + $nb_instructions_by_office;
                }

                return $nb_instructions_by_office;
        }

        public function construct_instructions_id_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $instructions_id_by_office = [];

                foreach($data as $row)
                {

                        $instructions_id_by_office[] = $row->Id_0;
                }

                return $instructions_id_by_office;
        }

        public function construct_bulletins_id_by_office($data)
        {
                /*
                * --------------------------------------------
                * Variable initialization
                * --------------------------------------------
                */
                $bulletins_id_by_office = [];

                foreach($data as $row)
                {

                        $bulletins_id_by_office[] = $row->Bulletinid_14;
                }

                return $bulletins_id_by_office;
        }
        
       
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_cbs_journalisation($data, $id) 
        {
                $this->set_table('logiref_cbs_integration_journalisation_dgda_prepayment', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_integration_sftp($data, $id) 
        {
            $this->set_table('logiref_integration_sftp', 'Id_0', 'Id_0 DESC');
            return $this->saveData($data, $id);
        }
        
        public function save_traitement($data, $id)
	{
                $this->set_table('logiref_prepayments_traitements', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function update_traitement($data, $id)
	{
                if (!is_array($ids)):
                        $ids = array($ids);
                endif;
                
                $return = $this->db->table('logiref_prepayments_traitements')
                        ->whereIn('Id_0', $ids)
                        ->update($data);
                
                return $return;
	}
        
        public function update_prepayement_by_lot($data, $ids) 
        {
                if (!is_array($ids)):
                        $ids = array($ids);
                endif;
                
                $return = $this->db->table('logiref_sydonia_prepayments')
                        ->whereIn('Lot_19', $ids)
                        ->update($data);
                
                return $return;
        }
        
        public function update_prepayement_by_reference($data, $ids, $office = NULL) 
        {
                if($office != '')
                {
                        if (!is_array($ids)):
                                $ids = array($ids);
                        endif;

                        $return = $this->db->table('logiref_sydonia_prepayments')
                                ->whereIn('AccountRef_14 ', $ids)
                                ->where('Office_8', $office) 
                                ->update($data);
                }
                else
                {
                        if (!is_array($ids)):
                                $ids = array($ids);
                        endif;

                        $return = $this->db->table('logiref_sydonia_prepayments')
                                ->whereIn('AccountRef_14 ', $ids)
                                ->update($data);
                }
                
                return $return;
        }

        public function update_prepayement_by_ids($data, $ids) 
        {
                # S'assurer que $ids est bien un tableau
                if (!is_array($ids)) 
                {
                        $ids = array($ids);
                }

                # Mise à jour directe par Id_0
                return $this->db->table('logiref_sydonia_prepayments')
                                ->whereIn('Id_0', $ids)
                                ->update($data);
        }

        
        public function update_traitement_by_lot($data, $ids) 
        {
                
                if (!is_array($ids)):
                        $ids = array($ids);
                endif;
                
                $return = $this->db->table('logiref_prepayments_traitements')
                        ->whereIn('Lot_11', $ids)
                        ->update($data);
                
                return $return;
        }
        
        public function update_prepayement($data, $ids) 
        {
                if (!is_array($ids)):
                        $ids = array($ids);
                endif;
                
                $return = $this->db->table('logiref_sydonia_prepayments')
                        ->whereIn('Id_0', $ids)
                        ->update($data);

                return $return;
        }
        
        public function save_integration_summary($data, $id) 
        {
                $this->set_table('logiref_cbs_treatment_sftp_dgda', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function generate_unique_reference()
        {
                // Horodatage haute résolution (microsecondes)
                $timePart = microtime(true);

                // Génère un hash unique à partir du temps + random
                $hash = hash('sha256', $timePart . random_bytes(8));

                // On prend les 24 premiers caractères du hash
                $unique_ref = substr($hash, 0, 16).$this->session->userdata['user_id'];

                return $unique_ref;
        }
        
        public function remove_all_special_characters($texte) 
        {
                // Supprimer les accents en remplaçant les caractères spéciaux par leurs équivalents non accentués
                $texte = strtr($texte, 'À�?ÂÃÄÅàáâãäåÇçÈÉÊËèéêëÌ�?Î�?ìíîïÑñÒÓÔÕÖØòóôõöøÙÚÛÜùúûü�?ýÿ', 'AAAAAAaaaaaaCcEEEEeeeeIIIIiiiiNnOOOOOOooooooUUUUuuuuYyy');

                // Supprimer les caractères spéciaux (tout sauf lettres et chiffres)
                $texte = preg_replace('/[^a-zA-Z0-9]/', ' ', $texte);

                return $texte;
        }
}