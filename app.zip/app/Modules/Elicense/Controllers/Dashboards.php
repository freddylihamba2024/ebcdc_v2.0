<?php

namespace Modules\Elicense\Controllers;

use App\Controllers\BaseController;
use Modules\Elicense\Models\LicenceModel;
use Modules\logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Admin\Models\BranchModel;

class Dashboards extends BaseController
{
        /*
         * Presentation: Gestion des tableaux de bord
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('start', 'overview', '');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'elicense';
        public $folder = 'dashboards';
        public $core_banking;
        public $options;
        private $logirefModel = null;
        private $branchesModel;
        private $licenceModel;
        private $mainModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->logirefModel = new LogirefModel();
                $this->licenceModel = new LicenceModel();
                $this->mainModel = new MainModel();
                $this->branchesModel = new BranchModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->logiref_elicense();

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else {
                        return redirect()->to(base_url($this->module));
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Elicense\Views\container';
                if ($_SESSION['Logiref_role'] == 1) {
                        echo view('layouts/layout_admin', $this->data);
                }
                else {
                        echo view('layouts/layout_main', $this->data);
                }
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {

                        if($needle == "overview"){

                                if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') {

                                        if(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                                        {
                                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                        }
                                        else
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if(!isset($_SESSION['Exchange_rates']))
                                                {
                                                        $this->display("set_exchange_rates");
                                                }

                                                $this->data['sidebar'] = '';
                                                $this->data['subview'] = '\Modules\Elicense\Views\container';

                                                echo view('layouts/layout_main', $this->data);
                                        }
                                }

                        }
                        else{
                                $this->index();
                        }

                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                ############################ Menu Operateur ################
                if ($obj == "start")
                {
                        $this->data['paiement_cdf'] = array();
                        $this->data['paiement_usd'] = array();
                        $this->data['paiement_regie'] = array();
                        $this->data['paiement'] = array();
                        $this->data['pie_situation_cdf'] = array();
                        $this->data['pie_situation_usd'] = array();
                        $this->data['right_side'] = $id;
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = array();

                        $this->data['licence_expires'] = $this->licenceModel->get_licences_expires();
                        $this->data['licences_encours'] = $this->licenceModel->get_licences_encours();
                        $this->data['licences_enforce'] = $this->licenceModel->get_licences_enforce();
                        $this->data['licences_apures'] = $this->licenceModel->get_licences_apures();

                        $this->data['all_declarations'] = $this->licenceModel->get_all_declations();
                        $this->data['licence_es'] = $this->licenceModel->get_licence_es();
                        $this->data['licence_is'] = $this->licenceModel->get_licence_is();
                        $this->data['licence_rc'] = $this->licenceModel->get_licence_rc();
                        $this->data['licence_eb'] = $this->licenceModel->get_licence_eb();
                        $this->data['licence_ib'] = $this->licenceModel->get_licence_ib();

                        echo view('\Modules\Elicense\Views\\' . $this->folder . '\start', $this->data);
                }
                elseif($obj == "overview")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                        $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')])?$this->data['guichets'][$this->session->get('Logiref_guichet')]:"";
                        $this->data['agence']= isset($this->data['agences'][$this->session->get('Logiref_agence')])?$this->data['agences'][$this->session->get('Logiref_agence')]:"";
                        $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                        $this->data['region'] = (!is_null($region))?$region->Nom_7:'';
                        $this->data['role_user'] = (!empty($_SESSION['roles_banks']))?$_SESSION['roles_banks'][$this->session->get('Logiref_role')]:"";

                        $this->data['paiement_cdf'] = $paiement_cdf = array();
                        $this->data['paiement_usd'] = $paiement_usd = array();
                        $this->data['paiement_regie'] = array();
                        $this->data['paiement'] = array();
                        $this->data['pie_situation_cdf'] = array();
                        $this->data['pie_situation_usd'] = array();
                        $this->data['right_side']= $id;
                        $this->data['beneficiaires'] = array();
                        $this->data['encaissements'] = array();
                        $this->data['guichets'] = array();

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Main\Views\overview', $this->data);
                }
                #Default
                elseif ($obj == "deny") {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Eximtrade\Views\\' . $this->lang . '_denial', $this->data);
                }
        }


        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "pie-chart") {
                        if ($arg == 'commission') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00C6F3",highlight:"green"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                } elseif ($obj == "pie-chart_operator") {
                        if ($arg == 'paiement_situation_cdf') {
                                $stats = $data;
                                //var_dump($stats); die;
                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement_situation_usd') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" USD",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" USD",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" USD",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                }
                elseif ($obj == "OBJ ") {

                }
                elseif ($obj == "OBJ ") {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */