<?php

namespace Modules\Elicense\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Synergies\Controllers\Synergies;

class Accounts extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('comptes','prepayments','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'elicense';
        public $folder = 'accounts';
        public $role;
        public $mainModel;
        public $integrationModel;
        public $accountsModel;
        public $logirefModel;
        public $branchesModel;
        public $usersModel;
        public $stakeholdersModel;
        public $flexcube;
        public $amplitude;
        public $synergies;
        public $core_banking;
        public $bank;
        public $functionalities;
        public $options;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->integrationModel = new IntegrationModel();
                $this->accountsModel = new AccountsModel();
                $this->logirefModel = new LogirefModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->flexcube = new Flexcube();
                $this->amplitude = new Amplitude();
                $this->synergies = new Synergies();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'accounts';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_elicense();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {

                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to($this->module);
                }

	}


	public function index()
	{
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
		echo view("layouts/layout_main", $this->data);
	}


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}


        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['agences'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                                $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                                $this->data['comptes'] = $this->accountsModel->get_comptes("cptes");

                                $this->data['lastestComptes'] = $this->accountsModel->get_latest_validated_accounts();
                        }
                        else
                        {
                                $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                                $this->data['comptes'] = $this->accountsModel->get_comptes();
                        }
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\comptes', $this->data);
                }
                elseif($obj == "compte")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['service_types'] =$this->accountsModel->type_service;
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['banque'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['compte'] = $this->accountsModel->get_compte_info($id);

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_compte', $this->data);
                }
                elseif($obj == "filter")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountsModel->get_filtered_accounts($_POST);
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_comptes', $this->data);
                }

                elseif($obj == "prepayments")
                {
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['comptes'] = $this->accountsModel->get_prepaid_comptes();
                        $this->data['sidebar'] = '';
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\prepayments', $this->data);
                }
                elseif($obj == "prepayment")
                {
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['compte'] = $this->accountsModel->get_prepaid_compte_info($id);
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_prepayment', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Eximtrade\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "compte")
                {
                        #Save compte
                        # Validate compte form 
                    
                        if($_POST['Compte_6']=='0' || $_POST['Compte_6']==''  || $_POST['Devise_8']==''  || ($_POST['Beneficiaires1']=='' && $_POST['Beneficiaires2']=='' && $_POST['Beneficiaires3']=='')  || $_POST['Type_4']==''):
                                echo '<div class="alert alert-danger">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Makerid_9']= $this->session->userdata['user_id'];
                               
                        endif;
                        
                        if($_SESSION['Logiref_role']==1):
                                $data['Type_4']=$_POST['Type_4'];
                                if($data['Type_4'] ==="CAC" || $data['Type_4'] ==="CPI" || $data['Type_4'] ==="CPS"): 
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires1'];
                                elseif($data['Type_4'] ==="CPT" || $data['Type_4'] ==="CGU"):
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires3'];
                                else:
                                    $data['Beneficiaires_5']=$_POST['Beneficiaires2'];
                                endif;
                                //else $data['Beneficiaires_5']=$_POST['Beneficiaires2'];
                                if($data['Beneficiaires_5'] === "DGI"):
                                    $data['Serviceid_16'] = $_POST['service2'];
                                else:
                                    $data['Serviceid_16'] = $_POST['service1'];
                                endif;
                                
                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):
                                    
                                        $devise = $this->request->getPost("Devise_8");
                                        $type= $this->request->getPost("Type_4");
                                        $beneficiaire = $data['Beneficiaires_5'];
                                        $agence = $this->request->getPost("agence");
                                        $compte = $this->request->getPost("Compte_6");
                                        $recette = $service  = NULL;
                                        if($agence == "" || $agence == '0'):
                                            
                                                echo '<div class="alert alert-warning">Vous devez s&eacute;l&eacute;ctionner une agance !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                                
                                        endif;

                                        if(isset($_POST['service']))$service = $this->request->getPost("service");
                                        if(isset($_POST['recette']))$recette = $this->request->getPost("recette");
                                       
                                        $comptes = $this->accountsModel->get_comptes_by_parameters($compte, $devise, $type, $beneficiaire, $agence, $recette, $service);

                                        if(!empty($comptes))
                                        {
                                                echo '<div class="alert alert-danger">D&eacute;sol&eacute; il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                endif;
                                #var_dump($_POST['Beneficiaires2']);die;
                                
                                $aCmpt = explode("-", trim($_POST['Compte_6']));
                                #var_dump($aCmpt);die;
                                #Optional keys
                                if(count($aCmpt) == 2)
                                {
                                    if(isset($aCmpt[0])) $data['Agenceid_15'] = trim($aCmpt[0]);
                                    if(isset($aCmpt[1])) $data['Compte_6'] = trim($aCmpt[1]);
                                }
                                else
                                {
                                    if(isset($aCmpt[0])) $data['Agenceid_15'] = trim($aCmpt[0]);
                                    if(isset($aCmpt[1]) && isset($aCmpt[2])) $data['Compte_6'] = trim($aCmpt[1])."-".trim($aCmpt[2]);
                                    if(isset($aCmpt[3])) $data['Clef_7'] = trim($aCmpt[3]);
                                    if(isset($aCmpt[4])) $data['Numeric_code_19'] = trim($aCmpt[4]);
                                }
                                #Devise par defaut
                                if($data['Type_4']=='CPU') $data['Devise_8']= 'USD';
                                elseif($data['Type_4']=='TVA') $data['Devise_8']= 'CDF';
                                #elseif($data['Type_4']=='CFB') $data['Devise_8']= 'CDF';
                                elseif($data['Type_4']=='CCV') $data['Devise_8']= 'CDF';
                                else $data['Devise_8']=$_POST['Devise_8'];
                                #Validation section
                                
                                if(isset($_POST['agence']))
                                {
                                        $data['Agence_12'] = $_POST['agence'];
                                }
                                if(isset($_POST['recette']))
                                {
                                       $data['Recette_13'] = $_POST['recette']; 
                                }
                                if(isset($_POST['service']))
                                {
                                       $data['Serviceid_16'] = $_POST['service']; 
                                }
                                if(isset($_POST['nif']))
                                {
                                       $data['Nif_17'] = $_POST['nif']; 
                                }
                                if(isset($_POST['comptesydonia']))
                                {
                                       $data['Comptesydonia_18'] = $_POST['comptesydonia']; 
                                }
                                
                                $data['Validation_10']='0000-00-00';
                                $data['Checkerid_11']=0;
                        else:
                                $data['Validation_10']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11']=$this->session->userdata['user_id'];
                        endif;    
                            
                        #Database
                        $cid = $this->accountsModel->save_compte($data, $id);  
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == 'prepayment')
                {
                    # Save compte
                    # Validate compte form 
                    #var_dump($_POST); die;
                    if($_POST['Accountnumber']=='0' || $_POST['Accountnumber']==''  || $_POST['Devise']==''  || ($_POST['Refsydonia']=='0' && $_POST['Refsydonia']=='')):
                            echo '<div class="alert alert-danger">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                            die;
                    endif;
                    if($id=='0' || $id==''):
                            $data['Date_1']=gmdate('Y-m-d H:i:s');
                            $data['Status_2']=1;
                            $data['Creator_4']=$this->session->userdata['user_id'];
                            $data['Account_3']=$this->session->userdata['account_id'];
                            $data['Makerid_11']=$this->session->userdata['user_id'];
                    endif;
                    if($_SESSION['Logiref_role']==1):
                            
                            $data['Devise_10'] = $devise = $this->request->getPost("Devise");
                            $data['Nifimportateur_7'] = $this->request->getPost("Nifimportateur");
                            $data['Refsydonia_9'] = $accountSydonia = $this->request->getPost("Refsydonia");
                            $accountcbs = $data['Accountnumber_8'] = $this->request->getPost("Accountnumber");

                            $count_number = $this->accountsModel->tcheck_prepaid_account($accountcbs, $devise);

                            if(!empty($count_number))
                            {
                                    echo '<div class="alert alert-danger">D&eacute;sol&eacute; il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                    die;
                            }
                        
                            $data['Validation_13']='0000-00-00';
                            $data['Checkerid_12']=0;
                    else:
                           
                            $data['Changes_5']=gmdate('Y-m-d H:i:s');
                            $data['Changer_6']=$this->session->userdata['user_id'];
                            $data['Validation_13']=gmdate('Y-m-d H:i:s');
                            $data['Checkerid_12']=$this->session->userdata['user_id'];
                    endif;    
                    #Database
                    $cid = $this->accountsModel->save_prepaid_accounts($data, $id);
                    if($cid): 
                            echo '<div class="alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                    endif;
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        $members = $this->usersModel->get_members();
                        $type = $this->session->userdata['user_type'];
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata['user_id'];
                                $cid = $this->usersModel->save_users($data, NULL);
                                if($cid) $members = $this->usersModel->get_members();
                        }
                        return $members;
                }
                elseif($obj == "get_accountname")
                {
                        $data = array();
                        $core_banking = strtolower($this->core_banking);

                        if($core_banking == 'igor')
                        {
                                # Extraire les 11 digits dans la chaine
                                $compte = explode('-', $_POST['compte']);

                                $data['Compte_33'] = isset($compte[1]) ? $compte[1] : '';
                                $data['Devise_34'] = $_POST['devise'];
                        }
                        else
                        {
                                $data['Compte_33'] = $_POST['compte'];
                                $data['Devise_34'] = $_POST['devise'];
                                $data['agence'] = $_SESSION['Guichet_code'];
                        }

                        $return = $this->{$core_banking}->account_info($data);

                        if(isset($return['code']) && $return['code'] == 404 || $return['code'] == 406 || $return['code'] == 405)
                        {
                                echo json_encode($return);
                        }
                        else
                        {
                                if(isset($return['account_name']) && $return['account_name'] != "")
                                {
                                        $return = json_encode($return);

                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo 404;
                                }
                        }

                }
                elseif($obj == "get_account_balance")
                {
                        if (isset($_POST['montant']) && isset($_POST['commission']) && isset($_POST['compte']) && isset($_POST['devise'])) 
                        {
                                $amount = str_replace(' ', '', $_POST['montant']);
                                $amount = str_replace(',', '.', $amount);

                                $commission = str_replace(' ', '', $_POST['commission']);
                                $commission = str_replace(',', '.', $commission);

                                $tva = $commission * 0.16;

                                $amount_to_pay = $amount + $tva + $commission;

                                $data = array();

                                $data['bank_account'] = $_POST['compte'];
                                $data['devise_account'] = $_POST['devise'];
                                $data['amount'] = $amount_to_pay;

                                if ($this->bank == '@rawbank' || $this->bank == '@firstbank'):
                                        $response = $this->amplitude->check_balance($data);
                                else:
                                        $response['code'] = ($_POST['balance'] >= $data['amount']) ? '200': '';
                                endif;

                                if (isset($response['code']) && $response['code'] == 200 || $response['code'] == 300) 
                                {
                                        echo $response['code'];
                                }
                                else
                                {
                                        echo '411';
                                        die;
                                }
                        }
                        else
                        {
                                echo '405';
                                die;
                        }

                }
                elseif($obj == "get_reservation")
                {
                        $bulletin = $this->integrationModel->check_bulletin_sydonia();

                        $result= array();
                        $infos = array();

                        if(isset($bulletin[0]->Id_0) && $bulletin[0]->Id_0 !="") $infos = json_decode($bulletin[0]->Reservation_43, true);

                        if(isset($infos['lien_id']) && $infos['lien_id'] !="")
                        {
                                $id = $bulletin[0]->Id_0;
                                $logiref_id = $bulletin[0]->Logirefid_34;

                                $_SESSION['lien_id'] = isset($infos['lien_id']) ? $infos['lien_id'] : "";
                                $_SESSION['date_lien'] = isset($infos['date_lien']) ? $infos['date_lien'] : "";

                                $result['code'] = 'E500';
                                $result['id'] = $id;
                                $result['reference'] = $logiref_id;
                                echo json_encode($result);
                        }
                        else
                        {
                                $api_data['compte'] = $_POST['devise'].$_POST['compte'];
                                $api_data['devise'] = $_POST['devise'];
                                $api_data['montant'] = $_POST['montant'];

                                $api_data['montant'] = str_replace(' ','',$api_data['montant']);
                                $api_data['montant'] = str_replace(',','.',$api_data['montant']);

                                $this->options['DGDA']['funds-reservation-with-instructions'] = "OK";
                                if(isset($this->options['DGDA']['funds-reservation-with-instructions']))
                                {
                                        # Especially for this bank, there will not be an API invocation at this step
                                        # The script calls this bloc just to keep the same process with others banks
                                        # All the more so as we need to have one instance of logiref

                                        $result['lien_id'] = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                                        $result['date_lien'] = gmdate('Y-m-d');
                                        $result['code'] = '200';

                                        echo json_encode($result);
                                }
                                else
                                {
                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode reservation existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'reservation')) 
                                        {
                                                $result = $this->{$core_banking}->reservation($api_data);
                                        }
                                        else
                                        {
                                                $result['code'] = '407';
                                                echo json_encode($result); die;
                                        }

                                        $return = json_decode($result, true);

                                        if(isset($return['code']) && $return['code']=='200')
                                        {
                                                if(isset($_POST['bulletin_id']) && $_POST['bulletin_id'] !="")
                                                {
                                                        $infos['lien_id'] = isset($return['lien']) ? $return['lien'] : "";
                                                        $infos['date_lien'] = isset($return['date']) ? $return['date'] : "";

                                                        $bl_data['Reservation_34'] = json_encode($infos);
                                                        $bl = $this->integrationModel->update_bulletin($bl_data, $_POST['bulletin_id']);


                                                        $result['code'] = '200';

                                                        echo json_encode($result);
                                                }
                                                else
                                                {
                                                        $result['lien_id'] = $return['transactionCode'];
                                                        $result['date_lien'] = $return['valueDate'];
                                                        $result['code'] = '200';


                                                        echo json_encode($result);
                                                }
                                        }
                                        elseif(isset($return['code']) && $return['code'] != "")
                                        {
                                                $result['code'] = $return['code'];
                                                $result['error_message'] = '<div class="alert alert-warning text-white">'.$return['error_message'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                                echo json_encode($result);
                                        }
                                        else
                                        {
                                                $result['code'] = 'E411';

                                                echo json_encode($result);
                                        }
                                }
                        }

                }
                elseif($obj == "cancel_reservation")
                {

                        $bulletin = $this->integrationModel->get_paiement_sydonia($_POST['bulletin_id']);

                        $infos = json_decode($bulletin->Reservation_43, true);

                        $api_data['lien_id'] = $infos['lien_id'];
                        $api_data['date_lien'] = $infos['date_lien'];

                        $response = $this->synergies->cancel_reservation($api_data);
                        $return = json_decode($response, true);

                        if($return['code']=='200')
                        {
                                $info['lien_id'] = "";
                                $info['date_lien'] = "";
                                $bl_data['Reservation_43'] = json_encode($info);

                                $this->integrationModel->save_bulletin($bl_data, $_POST['bulletin_id']);

                                $result['code'] = '200';
                                echo json_encode($result);
                        }
                        elseif(isset($return['code']) && $return['code'] != "")
                        {
                                $result['code'] = $return['code'];
                                $result['error_message'] = '<div class="alert alert-warning text-white">'.$return['error_message'].'.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = 'E411';

                                echo json_encode($result);
                        }

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */