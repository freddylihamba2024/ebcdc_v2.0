<?php

namespace Modules\Elicense\Controllers;

use App\Libraries\Mail;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use Modules\Elicense\Models\LicenceModel;
use Modules\Services\Licenses\Controllers\License;

class Elicense extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Donald on the 06.08.2024
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('start', 'document');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'elicense';
        public $folder = 'elicense';
        public $role;
        public $mail;
        public $seguceModel;
        public $mainModel;
        public $logirefModel;
        public $licenceModel;
        public $license;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->seguceModel = new SeguceModel();
                $this->licenceModel = new LicenceModel();
                $this->mail = new Mail();
                $this->license = new License();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'elicense';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['sidebar'] = $this->sidebars->logiref_elicense();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }

                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                }
                else {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Elicense\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "start")
                {
                        $this->data['elicense'] = $this->licenceModel->get_licence_info($id);
                        $this->data['step'] = 1;
                        echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif ($obj == "elicense")
                {
                        if(!empty($_POST['Licence_35'])){

                                $declaration = $this->licenceModel->get_license_exists($_POST['Licence_35']);

                                if(!is_null($declaration)){
                                        echo "E405";
                                }
                                else{
                                        $licenses_isys =  $this->license->license_details_by_id($this->request->getPost("Licence_35"));
                                        $elicense = $this->licenceModel->get_licence_by_id($id);

                                        if(empty($licenses_isys[0])){
                                                echo "E404";
                                        }
                                        else{
                                                $arrayCodetypeIsys = explode("-",$licenses_isys[0]['license_id']);
                                                $codetype_isys = $this->licenceModel->get_codetype_isys($licenses_isys[0]['license_type'],end($arrayCodetypeIsys));
                                                $Category_20 = $codetype_isys->Codetype_1;
                                                if(!in_array($Category_20, array("IS","ES","RC")))
                                                {
                                                       $Category_20 .= $codetype_isys->Licensetype_2;
                                                }

                                                $amount_paid = floatval($licenses_isys[0]['paid_amount']);
                                                $amount_remaining = floatval($licenses_isys[0]['amount']) - floatval($licenses_isys[0]['paid_amount']);
                                                $amount = floatval($licenses_isys[0]['amount']);
                                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['expiry_date']);
                                                $initial_expiration = $date->format("Y-m-d");
                                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['validation_date']);
                                                $initial_date = $date->format("Y-m-d");
                                                $remise_force = 0;

                                                if($licenses_isys[0]["license_id"] == $_POST['Licence_35']){

                                                        $datas['Category_20'] = $Category_20;
                                                        $datas['amount_paid'] = $amount_paid;
                                                        $datas['amount_remaining'] = $amount_remaining;
                                                        $datas['amount'] = $amount;
                                                        $datas['initial_expiration'] = $initial_expiration;
                                                        $datas['initial_date'] = $initial_date;
                                                        $datas['remise_force'] = $remise_force;
                                                        $datas['licenses_isys'] = $licenses_isys;

                                                        $elicense = $this->data("treat_license_isys", $datas);

                                                        if(!is_null($elicense))
                                                        {
                                                                $this->data['categories'] = $this->licenceModel->get_dropdown("categories","all");
                                                                $this->data["elicense"] = $elicense;

                                                                echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);
                                                        }
                                                        else{
                                                                echo "E406";
                                                        }
                                                }
                                                else{
                                                        echo "E404";
                                                }
                                        }
                                }
                        }
                        else{

                                $this->data['categories'] = $this->licenceModel->get_dropdown("categories","all");
                                $this->data["elicense"] = $this->licenceModel->get_licence_info($id);

                                echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);
                        }
                }
                elseif ($obj == "document")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        if(!is_null($id))
                        {
                                $this->data["elicense"] = $elicense = $this->licenceModel->get_licence_by_id($id);
                                $this->data["NumLcc"] = $elicense->Licence_35;
                        }
                        echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif($obj == "notification")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data["status_licence"] = $this->licenceModel->status;
                        $this->data["license"] = $license = $this->licenceModel->get_licence_info($id);

                        if (isset($license->Results_36) && $license->Results_36 !=""):
                                $paiements = json_decode($license->Results_36);
                        else:
                                $paiements = array();
                        endif;

                        $this->data["paiements"] = $paiements;

                        echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif($obj == "additional_field_licence")
                {
                        $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($_GET['Object_7']);
                        $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                        $this->data['Validity_10'] = $categorie->Validity_10;
                        if(!empty($_GET["Date_initial_14"]))
                        {
                                $date1 = new \DateTime($_GET["Date_initial_14"]);
                                $this->data['Initial_expiration_25'] = $Initial_expiration_25 = $date1->modify("+$categorie->Validity_10 days")->format("Y-m-d");

                                if(!empty($_GET["Date_validation_bcc"])){
                                        $expiration = new \DateTime($Initial_expiration_25);
                                        if(in_array($categorie->Object_7,array("IS","IB20","IB21","IB22","IB23","IB24","IB25","IB27","IB36"))){
                                                $this->data['Initial_expiration_25'] = $expiration->modify("+180 days")->format("Y-m-d");
                                        }
                                        elseif(in_array($categorie->Object_7,array("RC","ES","EB01","EB06","EB08"))){
                                                $this->data['Initial_expiration_25'] = $expiration->modify("+90 days")->format("Y-m-d");
                                        }
                                }
                        }
                        elseif(!empty($_GET["Date_extension_32"]))
                        {
                                $date1 = new \DateTime($_GET["Date_extension_32"]);
                                if(in_array($categorie->Object_7,array("IS","IB20","IB21","IB22","IB23","IB24","IB25","IB27","IB36"))){
                                        $date2 = new \DateTime($date1->modify("+180 days")->format("Y-m-d"));
                                }
                                elseif(in_array($categorie->Object_7,array("RC","ES","EB01","EB06","EB08"))){
                                        $date2 = new \DateTime($date1->modify("+90 days")->format("Y-m-d"));
                                }
                                $this->data['Initial_expiration_25'] = $date2->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                        }

                        echo view("\Modules\Elicense\Views\\".$this->folder."\_".$obj, $this->data);

                }
                elseif($obj == "information_documents")
                {
                        $NumLcc = $_GET["Numero_licence"];
                        $declaration = $this->licenceModel->get_license_exists($NumLcc);

                        if (empty($declaration))
                        {
                                $licenses_isys =  $this->license->license_details_by_id($NumLcc);
                                $arrayCodetypeIsys = explode("-",$licenses_isys[0]['license_id']);
                                $codetype_isys = $this->licenceModel->get_codetype_isys($licenses_isys[0]['license_type'],end($arrayCodetypeIsys));
                                $Category_20 = $codetype_isys->Codetype_1;
                                if(!in_array($Category_20, array("IS","ES","RC")))
                                {
                                        $Category_20 .= $codetype_isys->Licensetype_2;
                                }
                                $amount_paid = floatval($licenses_isys[0]['paid_amount']);
                                $amount_remaining = floatval($licenses_isys[0]['amount']) - floatval($licenses_isys[0]['paid_amount']);
                                $amount = floatval($licenses_isys[0]['amount']);
                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['expiry_date']);
                                $initial_expiration = $date->format("Y-m-d");
                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['validation_date']);
                                $initial_date = $date->format("Y-m-d");
                                $remise_force = 0;

                                if($licenses_isys[0]["license_id"] == $NumLcc){

                                        $datas['Category_20'] = $Category_20;
                                        $datas['amount_paid'] = $amount_paid;
                                        $datas['amount_remaining'] = $amount_remaining;
                                        $datas['amount'] = $amount;
                                        $datas['initial_expiration'] = $initial_expiration;
                                        $datas['initial_date'] = $initial_date;
                                        $datas['remise_force'] = $remise_force;
                                        $datas['licenses_isys'] = $licenses_isys;

                                        $declaration = $this->data("treat_license_isys", $datas);
                                }
                                else{
                                        $declaration = NULL;
                                }
                        }

                        if(!is_null($declaration)){
                                $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                                $this->data['typepay'] = $this->licenceModel->get_typepayment_by_type($categorie->Payment_type_13);
                                $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                                $this->data['documents'] = $documents =  explode(",",$categorie->Document_list_12);
                                $this->data['description_document'] = array();
                                $this->data['status_document'] = array();
                                $this->data["notifications"] = $this->licenceModel->get_elicense_notification($declaration->Id_0,1);
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                $this->data["status_licence"] = $this->licenceModel->status;

                                if (isset($declaration->Results_36) && $declaration->Results_36 != ""):
                                        $paiements = json_decode($declaration->Results_36);
                                else:
                                        $paiements = array();
                                endif;

                                if (isset($declaration->Documents_37) && $declaration->Documents_37 != ""):
                                        $docs = json_decode($declaration->Documents_37);
                                else:
                                        $docs = array();
                                endif;

                                $this->data["paiements"] = $paiements;
                                $this->data["docs"] = $docs;

                                $this->data['licence_documents'] = $this->licenceModel->get_documents_saving_by_declaration($declaration->Id_0);
                                foreach($documents as $document){
                                        $this->data['status_document'][$document] = $this->licenceModel->get_status_document_licence($declaration->Id_0,$document);
                                        $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                                }
                        }

                        $this->data["declaration"] = $declaration;
                        echo json_encode(array("status" => (!is_null($declaration))?true:false,"check" => (!is_null($declaration) && $declaration->Id_0 != "")?true:false,"checkmail" => (!is_null($declaration) && $declaration->Email_11 != "")?true:false, "page" => view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data)));
                }
                elseif($obj == "apurement")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($id);
                        $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        $this->data['description'] = array();
                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                $synthese_paiements[$file] = 0;
                        }

                        $NumLcc = $declaration->Licence_35;
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $folder = ".drive/licence/notifications/".$account_id;
                        $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                        if (!is_dir($folder))
                        {
                                mkdir($folder, 0755, true);
                        }

                        $status_docs_expiration = false;
                        if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                $paiements = json_decode($declaration->Results_36);
                                foreach($paiements->Accounts as $key => $account){
                                        if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                $status_docs_expiration = true;
                                        }
                                }
                        else:
                                $paiements = array();
                        endif;

                        $Amountpaidoc = 0;

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $Documents_37 = json_decode($declaration->Documents_37);
                                foreach($Documents_37 as $item){
                                        foreach($item->Documents as $key => $document){

                                                if($document == "FF"){
                                                        $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                }

                                                $synthese_paiements[$document] += (float) $item->Amountpaid->$key;

                                                if(!in_array($document,$synthese_documents)){

                                                        array_push($synthese_documents,$document);

                                                }

                                        }
                                }
                        endif;

                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                        $this->data["creatime"] = date("Y-m-d H:i:s");
                        $this->data["date"] = date("Y-m-d H:i:s");
                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                        $this->data["Designation_9"] = $declaration->Designation_9;
                        $this->data["Address_29"] = $declaration->Address_29;
                        $this->data["Num_lcc"] = $NumLcc;
                        $this->data["Title_8"] = $Categorie->Title_8;
                        $this->data["Devise"] = $declaration->Devise_24;
                        $this->data["Categorie"] = $declaration->Category_20;
                        $this->data["elicense"] = $declaration;
                        $this->data["synthese_documents"] = $synthese_documents;
                        $this->data["synthese_paiements"] = $synthese_paiements;
                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                        $html = view('\Modules\Elicense\Views\impression\_elicense_apurement', $this->data);
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'I');
                        exit;
                }
                elseif($obj == "send_mail_apurement")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($_POST["Id_0"]);
                        $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        $this->data['description'] = array();
                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                $synthese_paiements[$file] = 0;
                        }
                        $NumLcc = $declaration->Licence_35;
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $folder = ".drive/licence/notifications/".$account_id;
                        $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                        if (!is_dir($folder))
                        {
                                mkdir($folder, 0755, true);
                        }

                        $status_docs_expiration = false;
                        if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                $paiements = json_decode($declaration->Results_36);
                                foreach($paiements->Accounts as $key => $account){
                                        if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                $status_docs_expiration = true;
                                        }
                                }
                        else:
                                $paiements = array();
                        endif;

                        $Amountpaidoc = 0;

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $Documents_37 = json_decode($declaration->Documents_37);
                                foreach($Documents_37 as $item){
                                        foreach($item->Documents as $key => $document){

                                                if($document == "FF"){
                                                        $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                }

                                                $synthese_paiements[$document] += (float) $item->Amountpaid->$key;

                                                if(!in_array($document,$synthese_documents)){

                                                        array_push($synthese_documents,$document);

                                                }

                                        }
                                }
                        endif;

                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                        $this->data["creatime"] = date("Y-m-d H:i:s");
                        $this->data["date"] = date("Y-m-d H:i:s");
                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                        $this->data["Designation_9"] = $declaration->Designation_9;
                        $this->data["Address_29"] = $declaration->Address_29;
                        $this->data["Num_lcc"] = $NumLcc;
                        $this->data["Title_8"] = $Categorie->Title_8;
                        $this->data["Devise"] = $declaration->Devise_24;
                        $this->data["Categorie"] = $declaration->Category_20;
                        $this->data["elicense"] = $declaration;
                        $this->data["synthese_documents"] = $synthese_documents;
                        $this->data["synthese_paiements"] = $synthese_paiements;
                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                        $html = view('\Modules\Elicense\Views\impression\_elicense_apurement', $this->data);
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'F');

                        $customer = $declaration->Designation_9;
                        $email = $declaration->Email_11;
                        if($email != ""){
                                $return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);

                                unlink(ROOTPATH . $folder."/".$Linkdocument_9);

                                if($return)
                                {
                                        echo 200;
                                }
                                else
                                {
                                        echo 500;
                                }
                        }
                }
                elseif($obj == "viewpdf")
                {
                        $notification = $this->licenceModel->get_elicense_notification_by_id($id);
                        $filePath = ROOTPATH . $notification->Linkdocument_9;

                        if (file_exists($filePath)) {
                                return $this->response->setHeader('Content-Type', 'application/pdf')
                                        ->setHeader('Content-Disposition', 'inline; filename="' . basename($notification->Linkdocument_9) . '"')
                                        ->setBody(file_get_contents($filePath));
                        }
                        else {
                                return redirect()->to(base_url("404"));
                        }
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "elicense_document")
                {

                        $Id_0 = $this->request->getPost("Id_0");

                        if($Id_0 == "")
                        {
                                $NumLcc = $this->request->getPost("Licence_35");
                                $data = array();
                                $Prefinance_38 = "";
                                $AmountPrefinance_39 = 0;
                                $Devise_40 = "";
                                $Merchandise_41 = "";

                                $licenses_isys =  $this->license->license_details_by_id($NumLcc);
                                $arrayCodetypeIsys = explode("-",$licenses_isys[0]['license_id']);
                                $codetype_isys = $this->licenceModel->get_codetype_isys($licenses_isys[0]['license_type'],end($arrayCodetypeIsys));
                                $Category_20 = $codetype_isys->Codetype_1;
                                if(!in_array($Category_20, array("IS","ES","RC")))
                                {
                                        $Category_20 .= $codetype_isys->Licensetype_2;
                                }
                                $amount_paid = floatval($licenses_isys[0]['paid_amount']);
                                $amount_remaining = floatval($licenses_isys[0]['amount']) - floatval($licenses_isys[0]['paid_amount']);
                                $amount = floatval($licenses_isys[0]['amount']);
                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['expiry_date']);
                                $initial_expiration = $date->format("Y-m-d");
                                $date = \DateTime::createFromFormat('d/m/Y', $licenses_isys[0]['validation_date']);
                                $initial_date = $date->format("Y-m-d");
                                $remise_force = 0;

                                $datas['Category_20'] = $Category_20;
                                $datas['amount_paid'] = $amount_paid;
                                $datas['amount_remaining'] = $amount_remaining;
                                $datas['amount'] = $amount;
                                $datas['initial_expiration'] = $initial_expiration;
                                $datas['initial_date'] = $initial_date;
                                $datas['remise_force'] = $remise_force;
                                $datas['licenses_isys'] = $licenses_isys;

                                $elicense = $this->data("treat_license_isys", $datas);
                                if(!is_null($elicense))
                                {
                                        $categorie = $this->licenceModel->get_categorie_by_object($elicense->Category_20);
                                        $data["Date_1"] = $days = $elicense->Date_1;
                                        $data["Status_2"] = $elicense->Status_2;
                                        $data["Account_3"] = $this->session->userdata["account_id"];
                                        $data["Creator_4"] = $this->session->userdata["user_id"];
                                        $data["Compte_7"] = $elicense->Compte_7;
                                        $data["Devise_8"] = $elicense->Devise_8;
                                        $data["Designation_9"] = $elicense->Designation_9;
                                        $data["Nif_12"] = $elicense->Nif_12;
                                        $data["Code_importers_13"] = $elicense->Code_importers_13;
                                        $data["Date_initial_14"] = $elicense->Date_initial_14;
                                        $data["Ref_paiement_16"] = $elicense->Ref_paiement_16;
                                        $data["Numero_importexport_18"] = $elicense->Numero_importexport_18;
                                        $data["Category_20"] = $Category_20 = $elicense->Category_20;
                                        $data["Amountdue_23"] = $Amountdue_23 = $elicense->Amountdue_23;
                                        $data["Devise_24"] = $elicense->Devise_24;
                                        $data["Initial_expiration_25"] = $Initial_expiration_25 = $elicense->Initial_expiration_25;
                                        $data["Amountremaining_33"] = $Amountremaining_33 = $elicense->Amountremaining_33;
                                        $data["Devise_34"] = $elicense->Devise_34;
                                        $data["Licence_35"] = $elicense->Licence_35;
                                        $data["Prefinance_38"] = $Prefinance_38 = $elicense->Prefinance_43;
                                        $data["AmountPrefinance_39"] = $AmountPrefinance_39 = $elicense->AmountPrefinance_39;
                                        $data["Devise_40"] = $elicense->Devise_40;
                                        $data["Merchandise_41"] = $elicense->Merchandise_41;

                                        $Documents_37 = array();
                                        $expedition = $this->request->getPost("Expedition");
                                        $Expedition = array();
                                        $Amount_paid_document = 0;
                                        $files = explode(",",$categorie->Document_list_12);
                                        $synthese_documents = array();
                                        $synthese_paiements = array();
                                        foreach($files as $file){
                                                $synthese_paiements[$file] = 0;
                                        }

                                        $i = 1;
                                        foreach($expedition as $key => $value){
                                                $documents = $this->request->getPost("Documents[$key]");
                                                for($j = 1;$j <= count($documents);$j++){
                                                        $Creator[$j]= $this->session->userdata["user_id"];
                                                        $Changes[$j] = "0000-00-00 00:00:00";
                                                        $Changer[$j] = "0";
                                                }
                                                $Documents = array();
                                                $j = 1;
                                                foreach($documents as $document){
                                                        $Documents[$j] = $document;
                                                        if(!in_array($document,$synthese_documents)){
                                                                array_push($synthese_documents,$document);
                                                        }
                                                        $j++;
                                                }
                                                $reference = $this->request->getPost("Reference[$key]");
                                                $Reference = array();
                                                $j = 1;
                                                foreach($reference as $val){
                                                        $Reference[$j] = $val;
                                                        $j++;
                                                }
                                                $amounts = $this->request->getPost("Amountpaid[$key]");
                                                $Amountpaid = array();
                                                $j = 1;
                                                foreach($amounts as $amount){
                                                        if($Documents[$j] == "FF"){
                                                                $Amount_paid_document += str_replace(",",".",$amount);
                                                        }
                                                        $Amountpaid[$j] = str_replace(",",".",$amount);
                                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        $j++;
                                                }
                                                $currency = $this->request->getPost("Currency[$key]");
                                                $Currency = array();
                                                $j = 1;
                                                foreach($currency as $val){
                                                        $Currency[$j] = $val;
                                                        $j++;
                                                }

                                                if(count($synthese_documents) == 4){

                                                        if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                                if($synthese_paiements["FF"] >= $Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $Amountdue_23))){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }
                                                        }
                                                        elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($Prefinance_38 == "" && $Amountdue_23 <= $synthese_paiements["FF"]) || ($Prefinance_38 == "P" && ($Amountdue_23 - $AmountPrefinance_39) <= $synthese_paiements["FF"]) || $Prefinance_38 == "T")){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }

                                                        }
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }

                                                $Datexport = "";
                                                if(!empty($this->request->getPost("Datexport[$key]"))){
                                                        $datexport = $this->request->getPost("Datexport[$key]");
                                                        foreach($datexport as $val){
                                                                $Datexport = $val;
                                                        }
                                                }

                                                $Expedition["Exped"] = $value;
                                                $Expedition["Documents"] = $Documents;
                                                $Expedition["Reference"] = $Reference;
                                                $Expedition["Amountpaid"] = $Amountpaid;
                                                $Expedition["Currency"] = $Currency;
                                                $Expedition["Status"] = $status_2;
                                                $Expedition["Datexport"] = $Datexport;
                                                $Expedition["Date"] = $days;
                                                $Expedition["Creator"] = $Creator;
                                                $Expedition["Changes"] = $Changes;
                                                $Expedition["Changer"] = $Changer;

                                                array_push($Documents_37,$Expedition);
                                                $i++;
                                        }

                                        $is_complete_27 = 0;

                                        if(count($synthese_documents) == 4){

                                                if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                        if($synthese_paiements["FF"] >= $Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $Amountdue_23))){

                                                                $is_complete_27 = 1;
                                                                $Intitule_8 = "Apuré";
                                                                $data["Status_2"] = 7;

                                                        }
                                                        else{
                                                                if(strtotime(date("Y-m-d")) >= strtotime($Initial_expiration_25)){

                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;

                                                                }
                                                        }

                                                }
                                                elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($Prefinance_38 == "" && $Amountdue_23 <= $synthese_paiements["FF"]) || ($Prefinance_38 == "P" && ($Amountdue_23 - $AmountPrefinance_39) <= $synthese_paiements["FF"]) || $Prefinance_38 == "T")){

                                                                $is_complete_27 = 1;
                                                                $Intitule_8 = "Apuré";
                                                                $data["Status_2"] = 7;

                                                        }
                                                        else{

                                                                if(strtotime(date("Y-m-d")) >= strtotime($Initial_expiration_25)){
                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;
                                                                }

                                                        }

                                                }

                                        }

                                        $data["is_complete_27"] = $is_complete_27;
                                        $data['Force_26'] = 0;
                                        $data['Documents_37'] = json_encode($Documents_37);

                                        $licence = $this->licenceModel->save_elicense_declarations($data);

                                        if($licence){

                                                foreach($files as $file)
                                                {
                                                        $rdata = array();
                                                        $rdata['Date_1'] = $days;
                                                        $rdata['Status_2'] = 2;
                                                        $rdata['Account_3'] = $this->session->userdata["account_id"];
                                                        $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                                                        $rdata['Changer_6'] = 0;
                                                        $rdata['Declarationid_7'] = $licence;
                                                        $rdata['Code_8'] =  $file;

                                                        $this->licenceModel->save_elicense_documents($rdata);
                                                }

                                                echo json_encode(array("status" => 200));

                                        }
                                        else{
                                                echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                                        }
                                }
                                else{
                                        echo json_encode(array("status" => 501,"message" => "Le suivi de licence pour la catégorie de ce numéro de déclaration n\'est pas encore disponible"));
                                }
                        }
                        else{
                                $elicense = $this->licenceModel->get_licence_by_id($Id_0);
                                $categorie = $this->licenceModel->get_categorie_by_object($elicense->Category_20);
                                $files = explode(",",$categorie->Document_list_12);
                                $synthese_documents = array();
                                $synthese_paiements = array();
                                $days = date("Y-m-d H:i:s");
                                $is_complete_27 = $elicense->is_complete_27;
                                $expedition = $this->request->getPost("Expedition");
                                $Amount_paid_document = 0;
                                $Documents_37 = array();
                                foreach($files as $file){
                                        $synthese_paiements[$file] = 0;
                                }

                                $Expedition = array();
                                $i = 1;
                                foreach($expedition as $key => $value){
                                        $documents = $this->request->getPost("Documents[$key]");
                                        for($j = 1;$j <= count($documents);$j++){
                                                $Creator[$j]= $this->session->userdata["user_id"];
                                                $Changes[$j] = "0000-00-00 00:00:00";
                                                $Changer[$j] = "0";
                                        }
                                        $Documents = array();
                                        $j = 1;
                                        foreach($documents as $document){
                                                $Documents[$j] = $document;
                                                if(!in_array($document,$synthese_documents)){
                                                        array_push($synthese_documents,$document);
                                                }
                                                $j++;
                                        }
                                        $reference = $this->request->getPost("Reference[$key]");
                                        $Reference = array();
                                        $j = 1;
                                        foreach($reference as $val){
                                                $Reference[$j] = $val;
                                                $j++;
                                        }
                                        $amounts = $this->request->getPost("Amountpaid[$key]");
                                        $Amountpaid = array();
                                        $j = 1;
                                        foreach($amounts as $amount){
                                                if($Documents[$j] == "FF"){
                                                        $Amount_paid_document += str_replace(",",".",$amount);
                                                }
                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                $j++;
                                        }
                                        $currency = $this->request->getPost("Currency[$key]");
                                        $Currency = array();
                                        $j = 1;
                                        foreach($currency as $val){
                                                $Currency[$j] = $val;
                                                $j++;
                                        }

                                        if(count($synthese_documents) == 4){

                                                if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                        if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                                $Intitule_8 = "Total";
                                                                $status_2 = 9;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }
                                                }
                                                elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                                $Intitule_8 = "Total";
                                                                $status_2 = 9;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }

                                                }
                                        }
                                        else{
                                                $Intitule_8 = "Incomplète";
                                                $status_2 = 3;
                                        }

                                        $Datexport = "";
                                        if(!empty($this->request->getPost("Datexport[$key]"))){
                                                $datexport = $this->request->getPost("Datexport[$key]");
                                                foreach($datexport as $val){
                                                        $Datexport = $val;
                                                }
                                        }

                                        $Expedition["Exped"] = $value;
                                        $Expedition["Documents"] = $Documents;
                                        $Expedition["Reference"] = $Reference;
                                        $Expedition["Amountpaid"] = $Amountpaid;
                                        $Expedition["Currency"] = $Currency;
                                        $Expedition["Status"] = $status_2;
                                        $Expedition["Datexport"] = $Datexport;
                                        $Expedition["Date"] = $days;
                                        $Expedition["Creator"] = $Creator;
                                        $Expedition["Changes"] = $Changes;
                                        $Expedition["Changer"] = $Changer;

                                        array_push($Documents_37,$Expedition);
                                        $i++;
                                }

                                if(count($synthese_documents) == 4){

                                        if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                        $is_complete_27 = 1;
                                                        $Intitule_8 = "Apuré";
                                                        $data["Status_2"] = 7;

                                                }
                                                else{
                                                        $is_complete_27 = 0;
                                                        if($elicense->Status_2 == 7){
                                                                $Intitule_8 = "Incomplète";
                                                                $data["Status_2"] = 3;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Partielle";
                                                                $data["Status_2"] = 4;
                                                        }

                                                        if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){

                                                                $Intitule_8 = "Licence expiré";
                                                                $data["Status_2"] = 8;

                                                        }
                                                }

                                        }
                                        elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                        $is_complete_27 = 1;
                                                        $Intitule_8 = "Apuré";
                                                        $data["Status_2"] = 7;

                                                }
                                                else{
                                                        $is_complete_27 = 0;
                                                        if($elicense->Status_2 == 7){
                                                                $Intitule_8 = "Incomplète";
                                                                $data["Status_2"] = 3;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Partielle";
                                                                $data["Status_2"] = 4;
                                                        }

                                                        if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){
                                                                $Intitule_8 = "Licence expiré";
                                                                $data["Status_2"] = 8;
                                                        }

                                                }

                                        }

                                }

                                $data["is_complete_27"] = $is_complete_27;
                                $data['Documents_37'] = json_encode($Documents_37);

                                $licence = $this->licenceModel->save_elicense_declarations($data, $Id_0);

                                if($licence){
                                        echo json_encode(array("status" => 200));
                                }
                                else{
                                        echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                                }

                        }

                }
                elseif ($obj == "elicense_document_update")
                {
                        $Id_0 = $this->request->getPost("Id_0");
                        $elicense = $this->licenceModel->get_licence_by_id($Id_0);
                        $categorie = $this->licenceModel->get_categorie_by_object($elicense->Category_20);
                        $files = explode(",",$categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        foreach($files as $file){
                                $synthese_paiements[$file] = 0;
                        }
                        $days = date("Y-m-d H:i:s");
                        $is_complete_27 = $elicense->is_complete_27;
                        $expedition = $this->request->getPost("Expedition");
                        $Amount_paid_document = 0;
                        $Documents_37 = array();
                        $Expedition = array();
                        $i = count($Documents_37) + 1;
                        foreach($expedition as $key => $value){
                                $documents = $this->request->getPost("Documents[$key]");
                                for($j = 1;$j <= count($documents);$j++){
                                        $Changes[$j] = $days;
                                        $Changer[$j] = $this->session->userdata["user_id"];
                                }
                                $Creator = array();
                                $creator = $this->request->getPost("Creator[$key]");
                                $j = 1;
                                foreach($creator as $user){
                                        $Creator[$j] = $user;
                                        $j++;
                                }
                                $Documents = array();
                                $j = 1;
                                foreach($documents as $document){
                                        $Documents[$j] = $document;
                                        if(!in_array($document,$synthese_documents)){
                                                array_push($synthese_documents,$document);
                                        }
                                        $j++;
                                }
                                $reference = $this->request->getPost("Reference[$key]");
                                $Reference = array();
                                $j = 1;
                                foreach($reference as $val){
                                        $Reference[$j] = $val;
                                        $j++;
                                }
                                $amounts = $this->request->getPost("Amountpaid[$key]");
                                $Amountpaid = array();
                                $j = 1;
                                foreach($amounts as $amount){
                                        if($Documents[$j] == "FF"){
                                                $Amount_paid_document += str_replace(",",".",$amount);
                                        }
                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                        $Amountpaid[$j] = str_replace(",",".",$amount);
                                        $j++;
                                }
                                $currency = $this->request->getPost("Currency[$key]");
                                $Currency = array();
                                $j = 1;
                                foreach($currency as $val){
                                        $Currency[$j] = $val;
                                        $j++;
                                }

                                if(count($synthese_documents) == 4){

                                        if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                        $Intitule_8 = "Total";
                                                        $status_2 = 9;
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }
                                        }
                                        elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                        $Intitule_8 = "Total";
                                                        $status_2 = 9;
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }

                                        }
                                }
                                else{
                                        $Intitule_8 = "Incomplète";
                                        $status_2 = 3;
                                }

                                $Datexport = "";
                                if(!empty($this->request->getPost("Datexport[$key]"))){
                                        $datexport = $this->request->getPost("Datexport[$key]");
                                        foreach($datexport as $val){
                                                $Datexport = $val;
                                        }
                                }

                                $Expedition["Exped"] = $value;
                                $Expedition["Documents"] = $Documents;
                                $Expedition["Reference"] = $Reference;
                                $Expedition["Amountpaid"] = $Amountpaid;
                                $Expedition["Currency"] = $Currency;
                                $Expedition["Status"] = $status_2;
                                $Expedition["Datexport"] = $Datexport;
                                $Expedition["Date"] = $days;
                                $Expedition["Creator"] = $Creator;
                                $Expedition["Changes"] = $Changes;
                                $Expedition["Changer"] = $Changer;

                                array_push($Documents_37,$Expedition);
                                $i++;
                        }

                        if(count($synthese_documents) == 4){

                                if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                        if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                $is_complete_27 = 1;
                                                $Intitule_8 = "Apuré";
                                                $data["Status_2"] = 7;

                                        }
                                        else{
                                                if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){

                                                        $Intitule_8 = "Licence expiré";
                                                        $data["Status_2"] = 8;

                                                }
                                        }

                                }
                                elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                $is_complete_27 = 1;
                                                $Intitule_8 = "Apuré";
                                                $data["Status_2"] = 7;

                                        }
                                        else{

                                                if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){
                                                        $Intitule_8 = "Licence expiré";
                                                        $data["Status_2"] = 8;
                                                }

                                        }

                                }

                        }

                        $data["is_complete_27"] = $is_complete_27;
                        $data['Documents_37'] = json_encode($Documents_37);

                        $licence = $this->licenceModel->save_elicense_declarations($data, $Id_0);

                        if($licence){
                                echo json_encode(array("status" => 200));
                        }
                        else{
                                echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                        }

                }
                elseif ($obj == "elicense")
                {
                        $AmountPrefinance_39 = ($_POST["AmountPrefinance_39"] != "")?$this->request->getPost("AmountPrefinance_39"):0;
                        $Prefinance_38 = ($_POST['Prefinance_38'] != "")?$this->request->getPost("Prefinance_38"):Null;
                        $total_amountpaid = 0;
                        $amount_remaining = 0;

                        $amount_licence = $Amountdue_23 = str_replace(",",".",$_POST['Amountdue_23']);
                        $amount_licence = str_replace(' ','',$amount_licence);
                        $amount_licence -= $AmountPrefinance_39;

                        if($Prefinance_38 != "T"){
                                $status = array();
                                foreach ((array) $_POST["Amountpaids"] as $key => $amount)
                                {
                                        $total_amountpaid += str_replace(' ','',$amount);
                                        $amount_remaining = $amount_licence - $total_amountpaid;

                                        if ($amount_remaining > 0) $status[$key] = 4;
                                        if ($amount_remaining == 0) $status[$key] = 9;
                                }
                        }

                        $prorogation = json_decode($this->request->getPost("prorogation"));
                        $Id_0 = $this->request->getPost("DeclarationId");
                        $Categorie = $this->licenceModel->get_categorie_by_object($this->request->getPost("Category_20"));
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);

                        $Force_26 = (!empty($this->request->getPost("Force_26")))?json_decode($this->request->getPost("Force_26")):0;
                        $is_complete_27 = $this->request->getPost("is_complete_27");
                        $this->data["error"] = 200;
                        $this->data['description'] = array();

                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                        }

                        if(in_array($this->request->getPost("Category_20"),array("IS","ES","RC"))){

                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($this->request->getPost("Initial_expiration_25")))
                                {
                                        if($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                        elseif($amount_remaining > 0){
                                                $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                $status_2 = 4;

                                                if($this->request->getPost("Date_extension_32") != "" && $this->request->getPost("Date_extension_32") != "0000-00-00"){
                                                        $Intitule_8 = "Licence renouvellé avec succès";
                                                        $Status_2 = 5;
                                                }
                                        }
                                        else{
                                                $Intitule_8 = "Licence en cours de validité";
                                                $status_2 = 2;
                                        }
                                }
                                else{
                                        if($amount_remaining > 0){
                                                $Intitule_8 = "Licence est expiré";
                                                $status_2 = 8;
                                        }
                                        elseif($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                }

                                $is_complete_27 = 1;

                        }
                        else{
                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($this->request->getPost("Initial_expiration_25")))
                                {
                                        if($Force_26 == 1){
                                                $Intitule_8 = "Licence remise en force";
                                                $status_2 = 6;
                                        }
                                        else{
                                                if($amount_remaining == 0){
                                                        if($is_complete_27 == 1){
                                                                $Intitule_8 = "Licence est apuré";
                                                                $status_2 = 7;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Licence est total";
                                                                $status_2 = 9;
                                                        }
                                                }
                                                elseif($amount_remaining > 0 && $Amountdue_23 > $amount_remaining){
                                                        $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                        $status_2 = 4;
                                                }
                                                elseif($this->request->getPost("Date_extension_32") != "" && $this->request->getPost("Date_extension_32") != "0000-00-00" && ($amount_remaining > 0 || $is_complete_27 == 0)){
                                                        $Intitule_8 = "Licence renouvellé avec succès";
                                                        $status_2 = 5;
                                                }
                                                else{
                                                        $Intitule_8 = "Licence en cours de validité";
                                                        $status_2 = 2;
                                                }
                                        }
                                }
                                else{
                                        if($is_complete_27 == 1 && $amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                        elseif($is_complete_27 == 0 && $amount_remaining == 0){
                                                $Intitule_8 = "Licence incomplète, document(s) non présenté";
                                                $status_2 = 3;
                                        }
                                        elseif($amount_remaining > 0 && $is_complete_27 == 0){
                                                $Intitule_8 = "Licence expiré, paiement(s) non soldé";
                                                $status_2 = 8;
                                        }
                                }

                        }

                        $rdata = array();
                        $rdata['Date_1'] = $days = date("Y-m-d H:i:s");
                        $rdata['Status_2'] = $status_2;
                        $rdata['Account_3'] = $this->session->userdata["account_id"];
                        $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                        $rdata['Changer_6'] = 0;
                        $rdata['Compte_7 ']= $this->request->getPost("Compte_7");
                        $rdata['Devise_8'] = $this->request->getPost("Devise_8");
                        $rdata['Designation_9'] = $Designation_9 = $this->request->getPost("Designation_9");
                        $rdata['Cellphone_10'] = $this->request->getPost("Cellphone_10");
                        $rdata['Email_11'] = $this->request->getPost("Email_11");
                        $rdata['Nif_12'] = $this->request->getPost("Nif_12");
                        $rdata['Code_importers_13'] = $this->request->getPost("Code_importers_13");
                        $rdata['Date_initial_14'] = $this->request->getPost("Date_initial_14");
                        $rdata['Ref_declaration_15'] = $this->request->getPost("Ref_declaration_15");
                        $rdata['Ref_paiement_16'] = $this->request->getPost("Ref_paiement_16");
                        $rdata['Numero_importexport_18'] = $this->request->getPost("Numero_importexport_18");
                        $rdata['Category_20'] = $Category_20 = $this->request->getPost("Category_20");
                        $rdata['Prefinance_38'] = $Prefinance_38;
                        $rdata['AmountPrefinance_39'] = $AmountPrefinance_39;
                        $rdata['Devise_40'] = ($_POST['Devise_40'] != "")?$this->request->getPost("Devise_40"):Null;
                        $rdata['Merchandise_41'] = ($_POST['Merchandise_41'] != "")?$this->request->getPost("Merchandise_41"):Null;

                        /* ---- Amountpayed ----- */

                        if($Prefinance_38 != "T")
                        {
                                $rdata['Amountpaid_21']= str_replace(",",".",$this->request->getPost("Amountpayed"));
                                $rdata['Amountpaid_21'] = str_replace(' ','',$rdata['Amountpaid_21']);
                                $rdata['Amountpaid_21']  = $Amountpaid_21  = str_replace(',','.',$rdata['Amountpaid_21']);

                                $rdata['Devise_22'] = $this->request->getPost("Devise_22");

                                $rdata['Amountdue_23']  = $this->request->getPost("Amountdue_23");
                                $rdata['Amountdue_23'] = str_replace(' ','',$rdata['Amountdue_23']);
                                $rdata['Amountdue_23'] = $Amountdue_23 = str_replace(',','.',$rdata['Amountdue_23']);

                                $rdata['Devise_24'] = $Devise = $this->request->getPost("Devise_24");
                                $rdata['Initial_expiration_25'] = $this->request->getPost("Initial_expiration_25");
                                $rdata['Force_26'] = $Force_26;
                                $rdata['is_complete_27'] = $is_complete_27;

                                $rdata['Address_29'] = $Address_29 = $this->request->getPost("Address_29");
                                $rdata['Date_extension_32'] = $this->request->getPost("Date_extension_32");

                                $rdata['Amountremaining_33'] = $this->request->getPost("Amountremaining_33");
                                $rdata['Amountremaining_33'] = str_replace(' ','',$rdata['Amountremaining_33']);
                                $rdata['Amountremaining_33'] = $Amountremaining_33 = str_replace(',','.',$rdata['Amountremaining_33']);

                                $rdata['Devise_34'] = $this->request->getPost("Devise_34");
                                $rdata['Devise_34'] = $this->request->getPost("Devise_34");
                                $rdata['Licence_35'] = $this->request->getPost("Licence_35");

                                $input = array();

                                $input['Accounts'] = $_POST["Customer_accounts"];
                                $input['Accountnames'] = $_POST["Account_name"];
                                $input['Currency'] = $_POST["Currency_customer_accounts"];
                                $input['Date_paids'] = $_POST["Date_payments"];
                                $input['Amounts'] = $_POST["Amountpaids"];
                                $input['Camounts'] = $_POST["Currency_total_amounts"];
                                $input['Comments'] = $_POST["Comments"];
                                $input['Delays'] = $_POST["Document_delay"];
                                $input['Expirations'] = $_POST["Doc_expirations"];
                                $input['Status'] = $status;

                                $rdata['Results_36'] = json_encode($input);

                                $_array_amount_paid = $this->request->getPost("Amountpaids");
                                $totalpayed = 0;
                                foreach($_array_amount_paid as $value){
                                        $totalpayed += $value;
                                }

                                if($totalpayed > $Amountdue_23){
                                        $this->data["error"] = "Le montant payé ne doit pas être supérieur au montant total de la licence";
                                }
                        }

                        if($this->data["error"] == 200)
                        {
                                if($Id_0 == "")
                                {

                                        $Declarationid_7 = $this->licenceModel->save_elicense_declarations($rdata, $id);
                                        $Proofpayment_12 = array();

                                        foreach($files as $file)
                                        {
                                                $rdata = array();
                                                $rdata['Date_1'] = $days;
                                                $rdata['Status_2'] = 2;
                                                $rdata['Account_3'] = $this->session->userdata["account_id"];
                                                $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                                                $rdata['Changer_6'] = 0;
                                                $rdata['Declarationid_7'] = $Declarationid_7;
                                                $rdata['Code_8'] =  $file;

                                                $this->licenceModel->save_elicense_documents($rdata, $id);
                                        }
                                }
                                else
                                {
                                        $licence = $this->licenceModel->get_licence_by_id($Id_0);
                                        unset($rdata["Date_1"]);
                                        $rdata['Changes_5'] = $days;
                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                        if($licence->Amountpaid_21 != $licence->Amountdue_23){
                                                if(!empty($this->request->getPost("Amountpaid_21"))){
                                                        $rdata['Amountpaid_21'] = ($licence->Amountpaid_21) + (str_replace(",",".",$this->request->getPost("Amountpaid_21")));
                                                }
                                        }
                                        else{
                                                if($Amountremaining_33 > 0){
                                                        $rdata['Amountpaid_21'] = $licence->Amountdue_23 - $Amountremaining_33;
                                                }
                                                else{
                                                        $rdata['Amountpaid_21'] = $licence->Amountdue_23;
                                                }
                                        }
                                        $Declarationid_7 = $this->licenceModel->save_elicense_declarations($rdata,$Id_0);

                                }

                                $declaration = $this->licenceModel->get_licence_by_id($Declarationid_7);
                                $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                                $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);

                                $this->data['description'] = array();
                                foreach($files as $file)
                                {
                                        $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                }

                                $NumLcc = $declaration->Licence_35;
                                $account_id = $this->session->userdata['account_id'];
                                $user_id = $this->session->userdata['user_id'];
                                $folder = ".drive/licence/notifications/".$account_id;
                                $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                                if (!is_dir($folder))
                                {
                                        mkdir($folder, 0755, true);
                                }

                                $status_docs_expiration = false;
                                if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                        $paiements = json_decode($declaration->Results_36);
                                        foreach($paiements->Accounts as $key => $account){
                                                if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                        $status_docs_expiration = true;
                                                }
                                        }
                                else:
                                        $paiements = array();
                                endif;

                                $Amountpaidoc = 0;

                                if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                        $Documents_37 = json_decode($declaration->Documents_37);
                                        foreach($Documents_37 as $item){
                                                foreach($item->Documents as $key => $document){

                                                        if($document == "FF"){
                                                                $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                        }

                                                }
                                        }
                                endif;

                                if($Prefinance_38 != "T"){
                                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                                        $this->data["creatime"] = date("Y-m-d H:i:s");
                                        $this->data["date"] = date("Y-m-d H:i:s");
                                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                                        $this->data["Designation_9"] = $declaration->Designation_9;
                                        $this->data["Address_29"] = $declaration->Address_29;
                                        $this->data["Num_lcc"] = $NumLcc;
                                        $this->data["Title_8"] = $Categorie->Title_8;
                                        $this->data["Devise"] = $declaration->Devise_24;
                                        $this->data["Categorie"] = $declaration->Category_20;
                                        $this->data["elicense"] = $declaration;
                                        $this->data["data"] = $_POST;
                                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                                        $html = view('\Modules\Eximtrade\Views\impression\_elicense_paiement', $this->data);
                                        $this->mpdf->AddPageByArray([
                                                'margin-left' => 10,
                                                'margin-right' => 10,
                                        ]);

                                        $this->mpdf->WriteHTML('', 1);
                                        $this->mpdf->WriteHTML($html, 2);
                                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'F');

                                        $customer = $declaration->Designation_9;
                                        $email = $declaration->Email_11;
                                        if($email != ""){
                                                $return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);

                                                unlink(ROOTPATH . $folder."/".$Linkdocument_9);

                                                if($return)
                                                {
                                                        echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                                }
                                                else
                                                {
                                                        echo json_encode(array("status" => 500,"message" => "Mail non envoyé"));
                                                }
                                        }
                                        else{
                                                echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                        }
                                }
                                else{
                                        echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                }
                        }
                        else{
                                echo json_encode(array("status" => 500,"message" => $this->data["error"]));
                        }
                }
                elseif ($obj == "sendmail")
                {
                        $Linkdocument_9 = $this->request->getPost("Linkdocument_9");
                        $Id_0 = $this->request->getPost("Id_0");
                        $Comment_17 = $this->request->getPost("Comment_17");

                        $declaration = $this->licenceModel->get_licence_info($Id_0);

                        $customer = $declaration->Designation_9;
                        $email = $declaration->Email_11;

                        $return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);

                        if($return)
                        {
                                echo 200;
                        }
                        else
                        {
                                echo 500;
                        }
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "elicense")
                {
                        if (isset($_POST['license']) && $_POST['license'] != "")
                        {
                                $declaration = $this->licenceModel->get_license_exists($_POST['license']);
                                if (!empty($declaration))
                                {
                                        if($declaration->Results_36 == "" && $declaration->Status_2 != 7){
                                                $response['code'] = '203';
                                                $response['Id_0'] = $declaration->Id_0;
                                                $response['Designation_9'] = $declaration->Designation_9;
                                                $response['Category_20'] = $declaration->Category_20;
                                                $response['Amountdue_23'] = $declaration->Amountdue_23;
                                                $response['Devise_24'] = $declaration->Devise_24;
                                                $response['Compte_7'] = $declaration->Compte_7;
                                                $response['Devise_8'] = $declaration->Devise_8;
                                                $response['Code_importers_13'] = $declaration->Code_importers_13;
                                                $response['Date_initial_14'] = $declaration->Date_initial_14;
                                                $response['Ref_paiement_16'] = $declaration->Ref_paiement_16;
                                                $response['Numero_importexport_18'] = $declaration->Numero_importexport_18;
                                                $response['Nif_12'] = $declaration->Nif_12;
                                                $response["Prefinance_38"] = $declaration->Prefinance_38;
                                                $response["AmountPrefinance_39"] = $declaration->AmountPrefinance_39;
                                                $response["Devise_40"] = $declaration->Devise_40;
                                                $response["Merchandise_41"] = $declaration->Merchandise_41;

                                                echo json_encode($response);
                                        }
                                        elseif($declaration->Status_2 == 7){

                                                $response['code'] = '402';
                                                echo json_encode($response);
                                                die;

                                        }
                                        else{
                                                $response['code'] = '401';
                                                echo json_encode($response);
                                                die;
                                        }
                                }
                                else
                                {
                                        //$provision = $this->seguceModel->get_provisions_validated_by_licence($_POST['license']);

                                        if (!empty($provision))
                                        {
                                                $datime = new \DateTime($provision[0]->Changes_5);
                                                $response['code'] = '200';
                                                $response['Id_0'] = "";
                                                $response['Designation_9'] = $provision[0]->Designation_23;
                                                $response['Category_20'] = $provision[0]->CodeType_38;
                                                $response['Amountdue_23'] = $provision[0]->MontantCIF_8;
                                                $response['Devise_24'] = $provision[0]->Devise_9;
                                                $response['Compte_7'] = $provision[0]->Compte_21;
                                                $response['Devise_8'] = $provision[0]->Devise_22;
                                                $response['Code_importers_13'] = $provision[0]->Codeimport_19;
                                                $response['Date_initial_14'] = $datime->format("Y-m-d");
                                                $response['Ref_paiement_16'] = $provision[0]->Reference_20;
                                                $response['Numero_importexport_18'] = $provision[0]->Numero_importexport_39;
                                                $response['Nif_12'] = $provision[0]->Nif_24;
                                                $response["Prefinance_38"] = $provision[0]->Prefinance_43;
                                                $response["AmountPrefinance_39"] = $provision[0]->AmountPrefinance_41;
                                                $response["Devise_40"] = $provision[0]->Devise_42;
                                                $response["Merchandise_41"] = $provision[0]->Merchandise_40;
                                        }
                                        else
                                        {
                                                //$licence = $this->seguceModel->get_licence_validated_by_id($_POST['license']);
                                                $licence = array();

                                                if (!empty($licence))
                                                {
                                                        $datime = new \DateTime($licence->Changes_5);
                                                        $response['code'] = '202';
                                                        $response['Id_0'] = "";
                                                        $response['Designation_9'] = $licence->Designation_22;
                                                        $response['Category_20'] = $licence->CodeType_26;
                                                        $response['Amountdue_23'] = $licence->MontantCIF_8;
                                                        $response['Devise_24'] = $licence->Devise_9;
                                                        $response['Compte_7'] = $licence->Compte_20;
                                                        $response['Devise_8'] = $licence->Devise_21;
                                                        $response['Code_importers_13'] = $licence->Codeimport_18;
                                                        $response['Date_initial_14'] = $datime->format("Y-m-d");
                                                        $response['Ref_paiement_16'] = $licence->Reference_19;
                                                        $response['Numero_importexport_18'] = $licence->Numero_importexport_27;
                                                        $response['Nif_12'] = $licence->Nif_23;
                                                        $response["Prefinance_38"] = "";
                                                        $response["AmountPrefinance_39"] = 0;
                                                        $response["Devise_40"] = "";
                                                        $response["Merchandise_41"] = "";

                                                }
                                                else
                                                {
                                                        $response['code'] = '204';
                                                        $response['Id_0'] = "";
                                                        $response['Designation_9'] = "";
                                                        $response['Category_20'] = "";
                                                        $response['Amountdue_23'] = "";
                                                        $response['Devise_24'] = "";
                                                        $response['Compte_7'] = "";
                                                        $response['Devise_8'] = "";
                                                        $response['Code_importers_13'] = "";
                                                        $response['Date_initial_14'] = "";
                                                        $response['Ref_paiement_16'] = "";
                                                        $response['Numero_importexport_18'] = "";
                                                        $response['Nif_12'] = "";
                                                        $response["Prefinance_38"] = "";
                                                        $response["AmountPrefinance_39"] = 0;
                                                        $response["Devise_40"] = "";
                                                        $response["Merchandise_41"] = "";
                                                }
                                        }

                                        echo json_encode($response);
                                }
                        }

                }
                elseif($obj == "get_dateend_document")
                {
                        if (isset($_GET['Category']) && $_GET["Date_payment"] != "")
                        {
                                if(isset($_GET["Date_payment"]) && $_GET["Date_payment"] != ""):
                                        $date2 = new \DateTime($_GET["Date_payment"]);
                                endif;

                                $categorie = $this->licenceModel->get_categorie_by_object($_GET['Category']);
                                $delay = $categorie->Document_delay_11;

                                $response = array();

                                if ($_GET["Date_payment"] == "" || $_GET["Date_payment"] == "0000-00-00"):

                                        $response['delay'] = '';
                                        $response['dateend'] = '';
                                else:
                                        $dateend = $date2->modify("+$categorie->Document_delay_11 days")->format("Y-m-d");

                                        $response['delay'] = $delay;
                                        $response['dateend'] = $dateend;
                                endif;
                        }
                        else
                        {
                                $response['delay'] = '';
                                $response['dateend'] = '';
                        }

                        return json_encode($response);
                }
                elseif($obj == "Num_DEC_Licence_ISYS")
                {
                        $licenses =  $this->license->license_details_by_id($_POST["DEC"]."%");
                        if(count($licenses) > 0){
                                foreach($licenses as $license){
                                        echo "<div id='".$license['license_id']."' class='col-md-12 select-dec' style='padding:13px;font-size:14px;font-weight:400;font-family:roboto;'>".$license['license_id']."</div>";
                                }
                        }
                        else{
                                echo "<div class='col-md-12' id='select-dec-none' style='padding:13px;font-size:14px;font-weight:400;font-family:roboto;text-align:center;'>Aucun numéro de déclaration trouvé</div>";
                        }
                }
                elseif($obj == "treat_license_isys")
                {
                        $Category_20 = $data['Category_20'];
                        $amount_paid = $data['amount_paid'];
                        $amount_remaining = $data['amount_remaining'];
                        $amount = $data['amount'];
                        $initial_expiration = $data['initial_expiration'];
                        $initial_date = $data['initial_date'];
                        $remise_force = $data['remise_force'];
                        $licenses_isys = $data['licenses_isys'];

                        if(in_array($Category_20,array("IS","ES","RC")))
                        {

                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                {
                                        if($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                        elseif($amount_remaining > 0){
                                                $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                $status_2 = 4;

                                                /*if($this->request->getPost("Date_extension_32") != "" && $this->request->getPost("Date_extension_32") != "0000-00-00"){
                                                        $Intitule_8 = "Licence renouvellé avec succès";
                                                        $Status_2 = 5;
                                                }*/
                                        }
                                        else{
                                                $Intitule_8 = "Licence en cours de validité";
                                                $status_2 = 2;
                                        }
                                }
                                else{
                                        if($amount_remaining > 0){
                                                $Intitule_8 = "Licence est expiré";
                                                $status_2 = 8;
                                        }
                                        elseif($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                }

                                $is_complete_27 = 1;

                        }
                        else
                        {
                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                {
                                        if($remise_force == 1){
                                                $Intitule_8 = "Licence remise en force";
                                                $status_2 = 6;
                                        }
                                        else{
                                                if($amount_remaining == 0){
                                                        $Intitule_8 = "Licence est total";
                                                        $status_2 = 9;
                                                }
                                                elseif($amount_remaining > 0 && $amount > $amount_remaining){
                                                        $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                        $status_2 = 4;
                                                }
                                                else{
                                                        $Intitule_8 = "Licence en cours de validité";
                                                        $status_2 = 2;
                                                }
                                        }
                                }
                                else{
                                        if($amount_remaining == 0){
                                                $Intitule_8 = "Licence incomplète, document(s) non présenté";
                                                $status_2 = 3;
                                        }
                                        elseif($amount_remaining > 0){
                                                $Intitule_8 = "Licence expiré, paiement(s) non soldé";
                                                $status_2 = 8;
                                        }
                                }

                                $is_complete_27 = 0;

                        }

                        $Categorie = $this->licenceModel->get_categorie_by_object($Category_20);
                        $history_licence_isys = $this->license->licenses_history($licenses_isys[0]["license_id"]);
                        $currency_mapping = $this->licenceModel->get_currency_mapping($licenses_isys[0]["currency"]);
                        $currency_isys = $currency_mapping->Currency_2;
                        $Results_36 = '';

                        if(!is_null($Categorie))
                        {
                                if(count($history_licence_isys) > 0)
                                {
                                        $input = array();
                                        $history_licence_isys = array_reverse($history_licence_isys);
                                        $Customer_accounts = array();
                                        $Account_name = array();
                                        $Currency_customer_accounts = array();
                                        $Date_payments = array();
                                        $Amountpaids = array();
                                        $Currency_total_amounts = array();
                                        $Comments = array();
                                        $Document_delay = array();
                                        $Doc_expirations = array();
                                        $status = array();
                                        $increment = 1;
                                        $remaining = $amount;

                                        foreach($history_licence_isys as $history)
                                        {
                                                $date = $date1 = new \DateTime($history['updated_date']);

                                                $Customer_accounts[$increment] = "";
                                                $Account_name[$increment] = "";
                                                $Currency_customer_accounts[$increment] = $currency_isys;
                                                $Date_payments[$increment] = $date->format('Y-m-d');
                                                $Amountpaids[$increment] = $amountpaids = floatval($history['paid_amount']);
                                                $Currency_total_amounts[$increment] = $currency_isys;
                                                $Comments[$increment] = "";
                                                $Document_delay[$increment] = $Categorie->Document_delay_11;
                                                $Doc_expirations[$increment] = $date1->modify("+$Categorie->Document_delay_11 days")->format("Y-m-d");
                                                $remaining -= $amountpaids;

                                                if ($remaining > 0) $status[$increment] = 4;
                                                if ($remaining == 0) $status[$increment] = 9;
                                                $increment++;
                                        }

                                        $input['Accounts'] = $Customer_accounts;
                                        $input['Accountnames'] = $Account_name;
                                        $input['Currency'] = $Currency_customer_accounts;
                                        $input['Date_paids'] = $Date_payments;
                                        $input['Amounts'] = $Amountpaids;
                                        $input['Camounts'] = $Currency_total_amounts;
                                        $input['Comments'] = $Comments;
                                        $input['Delays'] = $Document_delay;
                                        $input['Expirations'] = $Doc_expirations;
                                        $input['Status'] = $status;

                                        $Results_36 = json_encode($input);
                                }

                                $elicense = new \stdClass();
                                $elicense->Id_0 = NULL;
                                $elicense->Date_1 = gmdate('Y-m-d H:i:s');
                                $elicense->Status_2 = $status_2;
                                $elicense->Account_3 = $this->session->userdata["account_id"];
                                $elicense->Creator_4 = $this->session->userdata['user_id'];
                                $elicense->Changes_5 = 0;
                                $elicense->Changer_6 = '';
                                $elicense->Compte_7 = '';
                                $elicense->Devise_8 = '';
                                $elicense->Designation_9 = $licenses_isys[0]["customer_name"];
                                $elicense->Cellphone_10 = '';
                                $elicense->Email_11 = '';
                                $elicense->Nif_12 = '';
                                $elicense->Code_importers_13 = $licenses_isys[0]["client_code"];
                                $elicense->Date_initial_14 = $initial_date;
                                $elicense->Ref_declaration_15 = '';
                                $elicense->Ref_paiement_16 = '';
                                $elicense->Numero_nrc_17 = '';
                                $elicense->Numero_importexport_18 = '';
                                $elicense->Numero_validation_19 = '';
                                $elicense->Category_20 = $Category_20;
                                $elicense->Amountpaid_21 = $amount_paid;
                                $elicense->Devise_22 = $currency_isys;
                                $elicense->Amountdue_23 = $amount;
                                $elicense->Devise_24 = $currency_isys;
                                $elicense->Initial_expiration_25 = $initial_expiration;
                                $elicense->Force_26 = $remise_force;
                                $elicense->is_complete_27 = $is_complete_27;
                                $elicense->Doc_expiration_28 = '';
                                $elicense->Address_29 = '';
                                $elicense->Date_paiement_30 = '';
                                $elicense->Comment_31 = '';
                                $elicense->Date_extension_32 = '';
                                $elicense->Amountremaining_33 = $amount_remaining;
                                $elicense->Devise_34 = $currency_isys;
                                $elicense->Licence_35 = $licenses_isys[0]["license_id"];
                                $elicense->Results_36 = $Results_36;
                                $elicense->Documents_37 = '';
                                $elicense->Prefinance_38 = '';
                                $elicense->AmountPrefinance_39 = 0;
                                $elicense->Devise_40 = '';
                                $elicense->Merchandise_41 = '';

                                return $elicense;
                        }
                        else{
                                return NULL;
                        }
                }

        }
}