<?php

namespace Modules\Elicense\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Elicense\Models\LicenceModel;

class Reports extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array("licences_current", "licences_expire","licence_documents");
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'elicense';
        public $folder = 'reports';
        public $reportsModel;
        public $feesModel;
        public $logirefModel;
        public $integrationModel;
        public $comptabilisationModel;
        public $prepaymentsModel;
        public $dataModel;
        public $accountsModel;
        public $branchesModel;
        public $usersModel;
        public $encaissementModel;
        public $ratesModel;
        public $seguceModel;
        public $stakeholdersModel;
        public $mainModel;
        public $licenceModel;
        public $functionalities;
        public $bank;
        public $core_banking;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->logirefModel = new LogirefModel();
                $this->licenceModel = new LicenceModel();

                $this->mainModel = new MainModel();
                $this->folder = 'reports';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_elicense();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->roles = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }

	}


	public function index()
	{
                $this->data['subview'] = '\Modules\Elicense\Views\container';
		echo view("layouts/layout_main", $this->data);
	}


        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "licence_documents")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($id);
                        $categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $documents =  explode(",",$categorie->Document_list_12);
                        $this->data['description_document'] = array();

                        foreach($documents as $document){
                                $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                        }

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $docs = json_decode($declaration->Documents_37);
                        else:
                                $docs = array();
                        endif;

                        $this->data["documents"] = $documents;
                        $this->data["Expeditions"] = $docs;
                        $this->data["declaration"] = $declaration;

                        echo view('\Modules\Elicense\Views\\'.$this->folder.'\\'.$obj,$this->data);
                }
                elseif ($obj == "licences_current")
                {
                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['licences'] = $licences = $this->licenceModel->get_current_licenses();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","all");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Elicense\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif ($obj == "filter_licencecurent")
                {
                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['licences'] = $this->licenceModel->get_filter_currentlicenses();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","all");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Elicense\Views\\'.$this->folder.'\_filter_licencecurent', $this->data);
                }
                elseif ($obj == "licences_expire")
                {
                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['licences'] = $licences = $this->licenceModel->get_licenses_expire();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Elicense\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif ($obj == "filter_licencesexpire")
                {
                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['licences'] = $this->licenceModel->get_filter_licensesexpire();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Elicense\Views\\'.$this->folder.'\_filter_licencesexpire', $this->data);
                }
                elseif($obj == "viewpdf")
                {
                        $document = $this->licenceModel->get_documents_saving_by_id($id);
                        $filePath = ROOTPATH . $document->Link_9;

                        if (file_exists($filePath)) {
                                return $this->response->setHeader('Content-Type', 'application/pdf')
                                        ->setHeader('Content-Disposition', 'inline; filename="' . basename($document->Link_9) . '"')
                                        ->setBody(file_get_contents($filePath));
                        }
                        else {
                                return redirect()->to(base_url("404"));
                        }
                }

                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Elicense\Views\\'.$this->folder . '_denial', $this->data);
                }
	}


        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        if($data !="" && $data != NULL)
                        {
                                $members = $this->usersModel->get_members($data);
                        }
                        else
                        {
                                $members = $this->usersModel->get_members();
                        }

                        $members = $this->usersModel->get_members();

                        return $members;
                }
                else if ($obj == "calculate_total")
                {
                        if (!is_array($data))
                        {
                                return 0;
                        }

                        return array_reduce($data, function ($carry, $row) {
                                return $carry + $row->MontantCIF_8;
                        }, 0);
                }

        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */