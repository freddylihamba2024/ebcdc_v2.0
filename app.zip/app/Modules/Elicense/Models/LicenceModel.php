<?php

namespace Modules\Elicense\Models;

use App\Models\MY_Elicence;

class LicenceModel extends MY_Elicence {

        /* Presentation:
         * Last update
         * By Papin on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';

        /**
         * 1 : Nouvelle
         * 2 : En cours
         * 3 : Incomplète
         * 4 : Partielle
         * 5 : Renouvelle
         * 6 : En force
         * 7 : Apuré
         * 8 : Expiré
         */

        public $colors = array(
                '1'=>'badge badge-primary',
                '2'=>'badge badge-success',
                '3'=>'badge badge-warning',
                '4'=>'badge badge-info',
                '5'=>'badge badge-primary',
                '6'=>'badge badge-danger',
                '7'=>'badge badge-primary',
                '8'=>'badge badge-danger',
                '9'=>'badge badge-success',
                '10'=>'badge badge-info',
        );

        public $status = array(
                '' => '',
                '1'=> "Nouvelle",
                '2'=> "En cours",
                '3'=> "Incomplète",
                '4'=> "Partielle",
                '5'=> "Renouvelle",
                '6'=> "En force",
                '7'=> "Apuré",
                '8'=> "Expir&eacute;",
                '9'=> "Total",
                '10'=> "Non transmis",
        );

        public $categories = array(
                '' => '',
                'IB' => 'Importation de biens',
                'EB' => 'Exportation de biens'
        );

        public $merchandises = array(
                '' => '',
                'OR' => 'OR ou DIAMANT',
                'AUTRE' => 'AUTRES'
        );

	public function __construct()
	{
		parent::__construct();
	}

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_licence_info($oid = NULL)
        {
                if ($oid == NULL)
                {
                        $obj = new \stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Compte_7 = '';
                        $obj->Devise_8 = '';
                        $obj->Designation_9 = '';
                        $obj->Cellphone_10 = '';
                        $obj->Email_11 = '';
                        $obj->Nif_12 = '';
                        $obj->Code_importers_13 = '';
                        $obj->Date_initial_14 = '';
                        $obj->Ref_declaration_15 = '';
                        $obj->Ref_paiement_16 = '';
                        $obj->Numero_nrc_17 = '';
                        $obj->Numero_importexport_18 = '';
                        $obj->Numero_validation_19 = '';
                        $obj->Category_20 = '';
                        $obj->Amountpaid_21 = '';
                        $obj->Devise_22 = '';
                        $obj->Amountdue_23 = '';
                        $obj->Devise_24= '';
                        $obj->Initial_expiration_25= '';
                        $obj->Force_26 = '';
                        $obj->is_complete_27 = '';
                        $obj->Doc_expiration_28 = '';
                        $obj->Address_29 = '';
                        $obj->Date_paiement_30 = '';
                        $obj->Comment_31 = '';
                        $obj->Date_extension_32 = '';
                        $obj->Amountremaining_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Licence_35 = '';
                        $obj->Results_36 = '';
                        $obj->Documents_37 = '';
                        $obj->Prefinance_38 = '';
                        $obj->AmountPrefinance_39 = '';
                        $obj->Devise_40 = '';
                        $obj->Merchandise_41 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('elicense_declarations  p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }



        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item,$menu=NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME')
                                ->get();

                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
                elseif($item=="type_payments")
                {
                        $builder = $this->db->table('elicense_type_payments')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[""] = "";
                        foreach ($builder->getResultArray() as $row)
                        {
                                $ddmenu[$row['Code_7']] = $row['Description_8']." (".$row['Code_7'].")";
                        }
                        return $ddmenu;
                }
                elseif($item=="devises")
                {
                        $builder = $this->db->table('elicense_currency_mapping')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[""] = "";
                        foreach ($builder->getResultArray() as $row)
                        {
                                $ddmenu[$row['Currency_2']] = $row['Currency_2'];
                        }
                        return $ddmenu;
                }
                elseif($item == "licence_ib")
                {
                        $st = "Status_2 > 0 AND Type_14 = 'IB'";
                        $builder = $this->db->table('elicence_categories')
                                ->where($st)
                                ->orderBy('Title_8')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Object_7']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
                elseif($item == "licence_eb")
                {
                        $st = "Status_2 > 0 AND Type_14 = 'EB'";
                        $builder = $this->db->table('elicence_categories')
                                ->where($st)
                                ->orderBy('Title_8')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($builder->getResultArray() as $row)
                        {
                                $ddmenu[$row['Object_7']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
                elseif($item=="categories")
                {
                        $account_id = $this->session->userdata['account_id'];

                        if(is_null($menu))
                        {
                                $st = "Status_2 > '0' ";
                                $builder = $this->db->table('elicence_categories')
                                        ->where($st)
                                        ->orderBy('Title_8')
                                        ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                $ddmenu['IB'] = "Importation des biens (IB)";
                                $ddmenu['EB'] = "Exportation des biens (EB)";
                                foreach ($builder->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Object_7']] = $row['Title_8'];
                                }
                                return $ddmenu;
                        }
                        elseif($menu=="all")
                        {
                                $st = "Status_2 > '0' ";
                                $builder = $this->db->table('elicence_categories')
                                        ->where($st)
                                        ->orderBy('Title_8')
                                        ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($builder->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Object_7']] = $row['Title_8'];
                                }
                                return $ddmenu;
                        }
                        elseif($menu=="provision")
                        {
                                $st = "Status_2 > 0 AND Object_7 <> 'RC' AND Object_7 <> 'ES' AND Object_7 <> 'IS'  OR Object_7 LIKE '%EB%'";
                                $builder = $this->db->table('elicence_categories')
                                        ->where($st)
                                        ->orderBy('Title_8',"ASC")
                                        ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($builder->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Object_7']] = $row['Title_8'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                                $st = "Status_2 > 0 AND (Object_7 = 'RC' OR Object_7 = 'ES' OR Object_7 = 'IS')";
                                $builder = $this->db->table('elicence_categories')
                                        ->where($st)
                                        ->orderBy('Title_8')
                                        ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($builder->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Object_7']] = $row['Title_8'];
                                }
                                return $ddmenu;
                        }
                }
        }

        public function get_categorie_by_object($object)
        {
                $builder = $this->db->table("elicence_categories")
                        ->where("Object_7='".$object."'")
                        ->get();
                return $builder->getRow();
        }

        public function get_tarif_by_object($object)
        {
                $builder = $this->db->table("elicence_tarifs")
                        ->where("Object_7='".$object."'")
                        ->get();
                return $builder->getRow();
        }

        public function get_typepayment_by_type($type)
        {
                $builder = $this->db->table("elicense_type_payments")
                        ->where("Code_7='".$type."'")
                        ->get();
                return $builder->getRow();
        }

        public function get_documents_proof_payed($id)
        {
                $builder = $this->db->table("elicense_notifications")
                        ->where("Declarationid_7='".$id."' AND Type_20='2'")
                        ->get();
                $proof_payed = $builder->getResult();

                $data = array();
                foreach($proof_payed as $value)
                {
                        $data[$value->Id_0] = json_decode($value->Proofpayment_12);
                }

                return array("documents" => $data, "proof_payed" => $proof_payed);
        }

        public function get_licences()
        {
                $st = "Status_2 > '0' AND  Account_3='" . $this->session->userdata['account_id'] . "'";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }

        public function get_licence_by_id($Id_0)
        {
                $builder = $this->db->table("elicense_declarations")
                        ->select("elicense_declarations.*")
                        ->where("Id_0 ",$Id_0)
                        ->get();
                return $builder->getRow();
        }

        public function get_licence_by_ref($Ref_paiement_16)
        {
                $builder = $this->db->table("elicense_declarations")
                        ->select("elicense_declarations.*")
                        ->where("Ref_paiement_16",$Ref_paiement_16)
                        ->get();
                return $builder->getRow();
        }

        public function get_amount_document_payed($Declarationid_7)
        {
                $builder = $this->db->table("elicense_notifications")
                        ->select("elicense_notifications.*")
                        ->where("Declarationid_7 = '".$Declarationid_7."' AND Type_20 ='2'")
                        ->get();
                $return = $builder->getResult();

                $total = 0;
                foreach($return as $value){
                        $Proofpayment_12 = json_decode($value->Proofpayment_12);
                        foreach($Proofpayment_12 as $ligne){
                                foreach($ligne as $payement){
                                        $total += $payement->Amount_paid_licence;
                                }
                        }
                }
                return $total;
        }

        public function get_licences_encours()
        {
                $st = "Status_2 = 2 ";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                        $result = $query->getResult();

                        $total = count($result);

                        return $total;
        }

        public function get_licences_expires()
        {
                $st = "Status_2 = 8 ";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();
                $result = $query->getResult();

                $total = count($result);

                return $total;

        }

        public function get_licences_enforce()
        {
                $st = "Status_2 = 6 ";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                        $result = $query->getResult();

                        $total = count($result);

                return $total;
        }

        public function get_licences_apures()
        {
                $st = "Status_2 = 7 ";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                        $result = $query->getResult();

                        $total = count($result);

                return $total;
        }

        public function get_all_declations()
        {

                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->orderBy('Id_0', 'DESC')
                        ->countAllResults();

                return $query;
        }


        public function get_licence_es()
        {
                $query = $this->db->table('elicense_declarations')
                        ->where('Category_20', 'ES')
                        ->orderBy('Id_0', 'DESC')
                        ->countAllResults();

                return $query;
        }

        public function get_licence_is()
        {
                $query = $this->db->table('elicense_declarations')
                        ->where('Category_20', 'IS')
                        ->orderBy('Id_0', 'DESC')
                        ->countAllResults();

                return $query;
        }


        public function get_licence_rc()
        {
                $query = $this->db->table('elicense_declarations')
                ->where('Category_20', 'RC')
                ->orderBy('Id_0', 'DESC')
                ->countAllResults();

                return $query;
        }

        public function get_licence_eb()
        {
                $query = $this->db->table('elicense_declarations')
                ->where('Category_20', 'EB')
                ->orderBy('Id_0', 'DESC')
                ->countAllResults();

                return $query;
        }

        public function get_licence_ib()
        {
                $query = $this->db->table('elicense_declarations')
                        ->where('Category_20', 'IB')
                        ->orderBy('Id_0', 'DESC')
                        ->countAllResults();

                return $query;
        }

        public function get_current_licenses()
        {
                $day = gmdate('Y-m-d');
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "') AND Initial_expiration_25 >='" .$day. "' ";
                $query = $this->db->table('elicense_declarations')
                        ->select('elicense_declarations.*')
                        ->where($st)
                        ->get();

                return $query->getResult();
        }

        public function get_elicense_notification($Declarationid_7,$Type_20)
        {
                $builder = $this->db->table("elicense_notifications")
                        ->where("Declarationid_7 = '".$Declarationid_7."' AND Type_20 = '".$Type_20."' ")
                        ->orderBy("Date_1","DESC")
                        ->get();
                return $builder->getResult();
        }

        public function get_notification_by_declarationid($dec_id)
        {
                $builder = $this->db->table("elicense_notifications")
                        ->where("Declarationid_7 = '".$dec_id."'")
                        ->orderBy("Date_1","DESC")
                        ->get();
                return $builder->getResult();
        }

        public function get_elicense_notification_by_id($id)
        {
                $builder = $this->db->table("elicense_notifications")
                        ->where("Id_0 = ".$id)
                        ->get();
                return $builder->getRow();
        }

        public function get_documents_saving_by_declaration($Declarationid_7)
        {
                $builder = $this->db->table("elicense_documents")
                        ->where("Declarationid_7 = ".$Declarationid_7)
                        ->get();
                return $builder->getResult();
        }

        public function get_documents_saving_by_id($Id_0)
        {
                $builder = $this->db->table("elicense_documents")
                        ->where("Id_0 = ".$Id_0)
                        ->get();
                return $builder->getRow();
        }

        public function get_licenses_expire()
        {
                $day = gmdate('Y-m-d');
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "') AND Initial_expiration_25 <'" .$day. "' ";

                $query = $this->db->table('elicense_declarations')
                                ->select('elicense_declarations.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }

        public function get_description_document($document)
        {
                $builder = $this->db->table("elicense_type_documents")
                        ->select("elicense_type_documents.*")
                        ->where("Code_7='".$document."'")
                        ->get()
                        ->getRow();
                if(!is_null($builder)){
                        $Description_8 = $builder->Description_8;
                }
                else{
                        $Description_8 = "";
                }

                return $Description_8;
        }

        public function get_status_document_licence($Id_0,$document)
        {
                $builder = $this->db->table("elicense_documents")
                        ->select("elicense_documents.*")
                        ->where("Code_8='".$document."' AND Declarationid_7=".$Id_0)
                        ->get();

                if(!is_null($builder->getRow())){
                        if($builder->getRow()->Status_2 == 1){
                                $value = 1;
                        }
                        else{
                                $value = 0;
                        }
                }
                else{
                        $value = 0;
                }

                return $value;
        }

        public function get_filter_currentlicenses()
        {
                $data = $_POST;
                $day = gmdate('Y-m-d');
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "') AND Initial_expiration_25 >='" .$day. "' ";

                # Filtre d'affichage
                if(isset($data['Status_2']) && $data['Status_2']!='') $st .= " AND Status_2  ='".$data['Status_2']."'";
                if(isset($data['Category_20']) && $data['Category_20']!='')
                {
                        if($data['Category_20'] == "IB" || $data['Category_20'] == "EB"){
                                $st .= " AND Category_20 LIKE '%".$data['Category_20']."%'";
                        }
                        else{
                                $st .= " AND Category_20 ='".$data['Category_20']."'";
                        }
                }

                if(isset($data['start']) && $data['start']!='')
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('elicense_declarations')
                                ->select('elicense_declarations.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }

        public function get_filter_licensesexpire()
        {
                $data = $_POST;
                $day = gmdate('Y-m-d');
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "') AND Initial_expiration_25 <'" .$day. "' ";

                # Filtre d'affichage
                if(isset($data['Status_2']) && $data['Status_2']!='') $st .= " AND Status_2  ='".$data['Status_2']."'";
                if(isset($data['Category_20']) && $data['Category_20']!='')
                {
                        if($data['Category_20'] == "IB" || $data['Category_20'] == "EB"){
                                $st .= " AND Category_20 LIKE '%".$data['Category_20']."%'";
                        }
                        else{
                                $st .= " AND Category_20 ='".$data['Category_20']."'";
                        }
                }

                if(isset($data['start']) && $data['start']!='')
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('elicense_declarations')
                                ->select('elicense_declarations.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }

        public function get_license_exists($license)
        {
                $this->set_table('elicense_declarations  I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Licence_35' => $license), TRUE);
        }

        public function get_currency_mapping($code)
        {
                $this->set_table('elicense_currency_mapping c', 'c.Id_0', 'c.Id_0 DESC');
                return $this->get_by(array('Code_1' => $code), TRUE);
        }

        public function get_codetype_isys($licensetype,$type)
        {
                $this->set_table('elicense_codetype_isys cdt', 'cdt.Id_0', 'cdt.Id_0 DESC');
                return $this->get_by(array('Codetype_1' => $type,'Licensetype_2' => $licensetype), TRUE);
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        public function delete_single_document_declaration($id)
        {
                $builder = $this->db->table("elicense_documents");
                return $builder->delete(["Id_0" => $id]);
        }

	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}

        public function save_elicense_declarations($data, $id=NULL)
	{
		$this->set_table('elicense_declarations', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}

        public function save_elicense_documents($data, $id=NULL)
	{
		$this->set_table('elicense_documents', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}

        public function save_elicense_notifications($data, $id=NULL)
	{
		$this->set_table('elicense_notifications', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
}