<?php

namespace Modules\Eximtrade\Controllers;

use DateTime;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Eximtrade\Models\CurlModel;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\FeesModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Modules\Admin\Models\StakeholderModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Seguce\Controllers\SeguceSFTP;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Comptabilisation\Controllers\ComptabilisationSeguce;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Temenos\Controllers\Temenos;

class Seguce extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('invoice', 'report_invoices', 'validated_invoices', 'nvalidated','nvalidated_invoices', 'validated', 'exemptcustomers', 'feesinvoice','provision','invoice_occ_batch','regularize_invoices_occ','provision_batch');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'seguce';
        public $role;
        public $seguceModel;
        public $feesModel;
        public $dataModel;
        public $comptabilisationModel;
        public $encaissementModel;
        public $curlModel;
        public $usersModel;
        public $mainModel;
        public $logirefModel;
        public $stakeholderModel;
        public $accountsModel;
        public $branchesModel;
        public $licenceModel;
        public $integrationModel;
        public $flexcube;
        public $amplitude;
        public $functionalities;
        public $bank;
        public $core_banking;
        public $temenos;
        public $ratesModel;
        public $seguceSFTP;
        public $fibridge;
        public $seguceAPI;
        public $spreadsheet=null;
        public $comptabilisation;
        public $options;
        public $finacle_standardbank;
        public $bsqr;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->seguceModel = new SeguceModel();
                $this->feesModel = new FeesModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->curlModel = new CurlModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->accountsModel = new AccountsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->branchesModel = new BranchesModel();
                $this->licenceModel = new LicenceModel();
                $this->ratesModel = new RatesModel();
                $this->integrationModel = new IntegrationModel();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->amplitude = new Amplitude();
                $this->seguceSFTP = new SeguceSFTP();
                $this->fibridge = new FIBridge();
                $this->spreadsheet=new Spreadsheet();
                $this->comptabilisation = new ComptabilisationSeguce();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->bsqr = new Bsqr();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'seguce';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                $this->data['modes'] = $this->seguceModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);
                
                $this->bank = ucfirst(strtolower($this->session->userdata["account_restrict"]));

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                } else {
                        return redirect()->to(base_url($this->module));
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "invoice")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "invoices")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "exempted_customer")
                {
                        $this->data['exempt'] = $this->feesModel->get_exempt_customer_info($id);
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['from'] = $id;
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "verify_clt_exist")
                {
                        $clt = $_POST['clt'];

                        $result = $this->feesModel->customer_exempt_provision_by_clt($clt);

                        $response['code_import'] = ($result != NULL) ? $result->Codeimport_11 : "";

                        $return = json_encode($response);

                        echo $return;
                        die;
                }
                elseif ($obj == "report_invoices")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoice_single();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "invoice_occ_batch")
                {
                        $this->data['step'] = 0;
                        $this->data['invoices'] = $this->seguceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_batch_start', $this->data);
                }
                elseif ($obj == "invoice_occ_batch_step_2")
                {
                        $file = $_FILES['file']['tmp_name'];
                        $file_extension = strtolower(substr(strrchr($_FILES['file']['name'], '.'), 1));
                        $valid_extensions = array('xlsx', 'xls');

                        $path = '/ikwook_files/invoices_occ/';
                        $config['upload_path'] = $path;
                        $config['allowed_types'] = 'xlsx|xls';
                        $config['remove_spaces'] = TRUE;

                        $licenses = array();
                        $tables = array();
                        $common_infos = new \stdClass();

                        if (empty($file)) {
                                echo 'E201';
                                die;
                        }

                        if (!in_array($file_extension, $valid_extensions)) {
                                echo 'E202';
                                die;
                        }

                        $handle = fopen($file, "r");
                        if ($handle == false) {
                                echo 'E201';
                        }
                        else {
                                $sheet = IOFactory::createReaderForFile($file);
                                $sheet->setReadDataOnly(true);
                                $objPHPExcel = $sheet->load($file);
                                $objWorksheet = $objPHPExcel->getActiveSheet();
                                $lines = $objWorksheet->toArray(null, true, true, true);

                                $account_id = $this->session->userdata['account_id'];
                                $ref = date('H') . date('i') . date('s') . date('m') . date('j') . date('Y');
                                $target_dir = "./drive/logiref/" . $account_id . "/" . date('Y-m') . '/invoices/OCC/' . $ref;
                                if (is_dir($target_dir) == false) {
                                        mkdir($target_dir, 0777, true);
                                }

                                $target_file = $target_dir . basename($_FILES["license"]["name"]);
                                $target_file = str_replace(" ", "", $target_file);
                                if (move_uploaded_file($file, $target_file)) {
                                        $this->data['path_file'] = $target_file;
                                }

                                if (!empty($lines)) {
                                        $t = 1;
                                        foreach ($lines as $worksheet) {
                                                if ($t > 1) {
                                                        $licenses[] = $worksheet;
                                                }

                                                $t++;
                                        }

                                        foreach ($licenses as $sheet) {
                                                $license_exists = false;

                                                foreach ($tables as $license) {
                                                        if ($sheet['C'] == $license->license_number && $sheet['E'] == $license->date && $sheet['F'] == $license->code_importation && $sheet['G'] == $license->designation_cli && $sheet['J'] == $license->valeur_cif && $sheet['K'] == $license->frais_ctrl && $sheet['L'] == $license->part_occ && $sheet['M'] == $license->part_bivac && $sheet['N'] == $license->tva_ctrl) {
                                                                $license_exists = true;
                                                        }
                                                }

                                                if ($license_exists == false) {
                                                        if ($sheet['A'] != "" && $sheet['B'] != "" && $sheet['C'] != "" && $sheet['D'] != "" && $sheet['E'] != "" && $sheet['F'] != "" && $sheet['G'] != "" && $sheet['H'] != "" && $sheet['I'] != "" && $sheet['J'] != "" && $sheet['K'] != "" && $sheet['L'] != "" && $sheet['M'] != "" && $sheet['N'] != "" && $sheet['O'] != "" && $sheet['P'] != "" && $sheet['Q'] != "" && $sheet['R'] != "") {
                                                                $license = new \stdClass();
                                                                $license->license_number = $sheet['C'];
                                                                $date_av_converted = ($sheet['P'] - 25569) * 86400;
                                                                $license->date =  gmdate("Y-m-d", $date_av_converted);
                                                                $license->code_importation = $sheet['F'];
                                                                $license->nom_importateur = $sheet['G'];
                                                                $license->devise = $sheet['I'];

                                                                $license->valeur_cif = $sheet['J'];
                                                                $license->frais_ctrl = $sheet['K'];
                                                                $license->part_occ = $sheet['L'];
                                                                $license->part_bivac = $sheet['M'];
                                                                $license->tva_ctrl = $sheet['N'];

                                                                $license->valeur_cif = str_replace(' ', '', $license->valeur_cif);
                                                                $license->valeur_cif = str_replace(',', '.', $license->valeur_cif);

                                                                $license->frais_ctrl = str_replace(' ', '', $license->frais_ctrl);
                                                                $license->frais_ctrl = str_replace(',', '.', $license->frais_ctrl);

                                                                $license->part_bivac = str_replace(' ', '', $license->part_bivac);
                                                                $license->part_bivac = str_replace(',', '.', $license->part_bivac);

                                                                $license->part_occ = str_replace(' ', '', $license->part_occ);
                                                                $license->part_occ = str_replace(',', '.', $license->part_occ);

                                                                $license->tva_ctrl = str_replace(' ', '', $license->tva_ctrl);
                                                                $license->tva_ctrl = str_replace(',', '.', $license->tva_ctrl);

                                                                $license->frais_ctrl = round($license->frais_ctrl, 2);
                                                                $license->part_bivac = round($license->part_bivac, 2);
                                                                $license->part_occ = round($license->part_occ, 2);
                                                                $license->tva_ctrl = round($license->tva_ctrl, 2);

                                                                $license->designation_cli = $sheet['G'];
                                                                $license->livraison = $sheet['Q'];

                                                                $tables[] = $license;

                                                                $common_infos->code_bque = $sheet['A'];
                                                                $common_infos->sigle_bque = $sheet['B'];
                                                                $common_infos->nom_import = $sheet['G'];
                                                                $common_infos->code_import = $sheet['F'];
                                                                $common_infos->num_bordereau = $sheet['O'];

                                                                $date_bord_converted = ($sheet['P'] - 25569) * 86400;
                                                                $common_infos->date_bordereau_fr = gmdate("d-m-Y", $date_bord_converted);
                                                                $common_infos->date_bordereau_en = gmdate("Y-m-d", $date_bord_converted);
                                                                $date_edit_converted = ($sheet['R'] - 25569) * 86400;
                                                                $common_infos->date_edition_fr = gmdate("d-m-Y", $date_edit_converted);
                                                                $common_infos->date_edition_en = gmdate("Y-m-d", $date_edit_converted);
                                                        }
                                                }
                                        }

                                        if(!empty($_POST['Date_receipt'])){
                                                $code_licenses = [];

                                                foreach ($tables as $key => $value) :
                                                        $code_licenses[$value->code_importation][$key] = $value;
                                                endforeach;

                                                $this->data['licenses'] = $code_licenses;
                                                $this->data['date_receipt'] = $_POST['Date_receipt'];
                                                $this->data['number_licenses'] = count($tables);
                                                $this->data['common_infos'] = $common_infos;
                                                $this->data['step'] = 1;
                                        }
                                        else{
                                                $date_bordereau = str_replace('-','',$common_infos->date_bordereau_fr);
                                                $ref_bordereau = $common_infos->num_bordereau .''. $date_bordereau;

                                                $results = $this->seguceModel->get_invoice_batch_by_numbordereau($ref_bordereau);

                                                if (!empty($results))
                                                {
                                                        echo 'E203';
                                                        die;
                                                }

                                                $code_licenses = [];

                                                foreach($tables as $key => $value):
                                                $code_licenses[$value->code_importation][$key] = $value;
                                                endforeach;

                                                $this->data['licenses'] = $code_licenses;
                                                $this->data['number_licenses'] = count($tables);
                                                $this->data['common_infos'] = $common_infos;
                                                $this->data['step'] = 1;
                                        }

                                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_batch_step_2', $this->data);
                                }
                        }
                }
                elseif ($obj == "invoice_occ_step_1")
                {
                        $data_prov = array();
                        $licenses = array();
                        $code_licenses = array();
                        $tables = array();
                        $data = array();
                        $check_key = array();
                        $required = array();
                        $data_key = array();
                        $licenses_livraison = array();

                        $invoice = $this->seguceModel->get_invoices_occ_batchs_info($id);
                        $license = json_decode($invoice->Licenses_11, true);

                        $licence_number = $this->seguceModel->get_dropdown('licence_number');
                        $licence_provision = $this->seguceModel->get_dropdown('licence_provision');

                        $customer_account = $this->seguceModel->get_dropdown("provision_current_account");
                        $customer_account_currency = $this->seguceModel->get_dropdown("provision_current_account_currency");
                        $customer_account_exempt_provision = $this->feesModel->get_dropdown("customer_account_exempt_provision");
                        $customer_account_currency_exempt_provision = $this->feesModel->get_dropdown("customer_account_currency_exempt_provision");

                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        if(isset($comptes['TMB']['CSP']['USD']))
                        {
                                $compte_suspens_provision = $comptes['TMB']['CSP']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CSP']['USD']))
                        {
                                $compte_suspens_provision = $comptes['Rawbank']['CSP']['USD'];
                        }
                        else{
                                $compte_suspens_provision = '00000000000000000000000';
                        }

                        $common_infos = new \stdClass();

                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "")
                        {
                                $taux = $result;
                        }
                        else
                        {
                                $taux = 1;
                        }

                        if(array_key_exists('eximtrade_licences_groop_by_clt',$this->functionalities['ALL']))
                        {
                                $somme_frais_ctrl = [];
                                $som_fraisctrl_livraison = [];
                                $licenses_by_clt = [];

                                foreach ($license as $sheet) {
                                        $code_import = $sheet["code_import"];
                                        $frais_ctrl = str_replace(" ", "", $sheet["frais_ctrl"]);
                                        $frais_ctrl = str_replace(",", ".", $frais_ctrl);
                                        $frais_ctrl = (float) $frais_ctrl;

                                        if (isset($somme_frais_ctrl[$code_import])) {
                                                $somme_frais_ctrl[$code_import] += $frais_ctrl;
                                        }
                                        else {
                                                $somme_frais_ctrl[$code_import] = $frais_ctrl;
                                        }

                                        if ($sheet['livraison'] == "T") {
                                                if (isset($som_fraisctrl_livraison[$code_import])) {
                                                        $som_fraisctrl_livraison[$code_import] += $frais_ctrl;
                                                } else {
                                                        $som_fraisctrl_livraison[$code_import] = $frais_ctrl;
                                                }

                                                $licenses_livraison[$code_import][] = $sheet['numero_licenses'];
                                        } else {
                                                $licenses_livraison = array();
                                        }
                                }
                        }

                        foreach ($license as $sheet) {

                                $license_number = explode('-', $sheet['numero_licenses']);
                                $segment_license_number = $license_number[0];

                                $licenses = new \stdClass();
                                $licenses->license_number = $sheet['numero_licenses'];
                                $licenses->segment_license_number = $segment_license_number;

                                $licenses->date =  $sheet['date_bordereau'];
                                $licenses->code_importation = $sheet['code_import'];
                                $licenses->nom_importateur = $sheet['nom_importateur'];

                                $licenses->valeur_cif = $sheet['frais_cif'];

                                $licenses->frais_ctrl = $sheet['frais_ctrl'];
                                $licenses->part_occ = $sheet['frais_occ'];
                                $licenses->part_bivac = $sheet['frais_bivac'];
                                $licenses->tva_ctrl = $sheet['frais_tva_ctrl'];
                                $licenses->livraison = $sheet['livraison'];

                                $licenses->frais_ctrl = str_replace(' ', '', $licenses->frais_ctrl);
                                $licenses->frais_ctrl = str_replace(',', '.', $licenses->frais_ctrl);

                                $licenses->valeur_cif = str_replace(' ', '', $licenses->valeur_cif);
                                $licenses->valeur_cif = str_replace(',', '.', $licenses->valeur_cif);
                                $licenses->devise = $sheet['devises'];

                                $licenses->part_bivac = str_replace(' ', '', $licenses->part_bivac);
                                $licenses->part_bivac = str_replace(',', '.', $licenses->part_bivac);

                                $licenses->part_occ = str_replace(' ', '', $licenses->part_occ);
                                $licenses->part_occ = str_replace(',', '.', $licenses->part_occ);

                                $licenses->tva_ctrl = str_replace(' ', '', $licenses->tva_ctrl);
                                $licenses->tva_ctrl = str_replace(',', '.', $licenses->tva_ctrl);

                                $licenses->part_bivac = round($licenses->part_bivac, 2);
                                $licenses->part_occ = round($licenses->part_occ, 2);
                                $licenses->tva_ctrl = round($licenses->tva_ctrl, 2);
                                //$licenses->montant_prov = round($frais_ctrl, 2);

                                if(array_key_exists('eximtrade_amount_prov_get_fees_ctrl',$this->functionalities['ALL']))
                                {
                                        $licenses->montant_prov = round($licenses->frais_ctrl, 2);
                                }
                                else{
                                        $data_prov['MontantCIF_8'] = $licenses->valeur_cif;
                                        $data_prov['Devise_9'] = $licenses->devise;
                                        $data_prov['type'] = "CIF";

                                        $amount_treated = $this->data("get_provision_start", $data_prov);

                                        $data_prov['amount_treated'] = $amount_treated;

                                        $amount = $this->data("get_provision_final", $data_prov);

                                        if($amount >= 232)
                                        {
                                                $licenses->montant_prov = round($amount, 2);
                                        }
                                        else
                                        {
                                                $licenses->montant_prov = 232;
                                        }
                                }

                                $tables[] = $licenses;

                                $common_infos->code_bque = $invoice->Codebank_7;
                                $common_infos->sigle_bque = $invoice->Siglebank_8;
                                $common_infos->num_bordereau = $invoice->Numbordereau_9;
                                $common_infos->date_bordereau = $invoice->Date_10;
                                $common_infos->date_edit = $invoice->Date_13;
                        }

                        #Les licences

                        if(array_key_exists('eximtrade_licences_groop_by_clt',$this->functionalities['ALL']))
                        {
                                foreach ($tables as $key => $value) {
                                        $code_licenses[$value->code_importation][$key] = $value;
                                        $licenses_by_clt[$value->code_importation][$key] = $value->license_number;
                                }

                                foreach ($licenses_by_clt as $clt => $value) {
                                        $licenses_clt[$clt] = (array_unique($value));
                                }

                                $somme_provison_clt = [];
                                foreach ($licenses_clt as $clt => $values) {
                                        foreach ($values as $row) {
                                                $license_number = explode('-', $row);
                                                $segment_license_number = $license_number[0];

                                                if (isset($licence_provision[$segment_license_number])) {
                                                        if (isset($somme_provison_clt[$clt])) {
                                                                $somme_provison_clt[$clt] += $licence_provision[$segment_license_number];
                                                        } else {
                                                                $somme_provison_clt[$clt] = $licence_provision[$segment_license_number];
                                                        }
                                                }

                                                if (isset($licence_provision[$row])) {
                                                        if (isset($somme_provison_clt[$clt])) {
                                                                $somme_provison_clt[$clt] += $licence_provision[$row];
                                                        } else {
                                                                $somme_provison_clt[$clt] = $licence_provision[$row];
                                                        }
                                                }
                                        }
                                }

                                $som_provison_livraison = [];
                                foreach ($licenses_livraison as $clt => $values) {
                                        foreach ($values as $row) {

                                                $license_number = explode('-', $row);
                                                $segment_license_number = $license_number[0];

                                                if (isset($licence_provision[$segment_license_number])) {
                                                        if (isset($som_provison_livraison[$clt])) {
                                                                $som_provison_livraison[$clt] += $licence_provision[$segment_license_number];
                                                        } else {
                                                                $som_provison_livraison[$clt] = $licence_provision[$segment_license_number];
                                                        }
                                                }

                                                if (isset($licence_provision[$row])) {
                                                        if (isset($som_provison_livraison[$clt])) {
                                                                $som_provison_livraison[$clt] += $licence_provision[$row];
                                                        } else {
                                                                $som_provison_livraison[$clt] = $licence_provision[$row];
                                                        }
                                                }
                                        }
                                }

                                $this->data['provison_clt'] = $somme_provison_clt;
                                $this->data['frais_ctrl'] = $somme_frais_ctrl;
                                $this->data['fctrl_livraison'] = $som_fraisctrl_livraison;
                                $this->data['provison_livraison'] = $som_provison_livraison;

                        }
                        else{
                                foreach ($tables as $key => $value) {
                                        $code_licenses[$value->code_importation][$key] = $value;
                                }
                        }

                        foreach ($code_licenses as $key => $license) {
                                foreach ($license as $row) {
                                        $data[$row->license_number] = 0;
                                }
                        }

                        #Somme des quotes-parts par licence
                        foreach ($code_licenses as $key => $license){
                                foreach($license as $row){

                                        $result = $this->feesModel->customer_exempt_provision_by_clt($row->code_importation);

                                        if (isset($result->Infos_10))
                                        {
                                                $infos = json_decode($result->Infos_10, true);
                                                $response['provision'] = (isset($infos['provision']) && $infos['provision'] !="") ? '1' : '0';
                                                $response['tva'] = (isset($infos['tva']) && $infos['tva'] != "") ? '1' : '0';
                                        }
                                        else
                                        {
                                                $response['provision'] = '0';
                                                $response['tva'] = '0';
                                        }

                                        $tva_exempt = $response['tva'];
                                        if (isset($tva_exempt) && $tva_exempt == '1'){
                                                $row->tva_ctrl = 0;
                                                $data[$row->license_number] = $row->part_bivac + $row->tva_ctrl + $row->part_occ;
                                        }
                                        else {
                                                $data[$row->license_number] = $row->part_bivac + $row->tva_ctrl + $row->part_occ;
                                        }
                                }
                        }

                        foreach ($code_licenses as $key => $license) {
                                $data_key[] =  $key;
                                foreach ($license as $value) {
                                        if (in_array($value->license_number, $licence_number)) {
                                                if ($licence_provision[$value->license_number] < $value->montant_prov) {
                                                        $check_key[$key] = $key;
                                                        $required[] = "";
                                                }
                                                else {
                                                        $check_key[$key] = $key;
                                                        $required[] = "required";
                                                }
                                        }
                                }
                        }

                        $this->data['data_key'] = json_encode($data_key);
                        $this->data['required'] = $required;
                        $this->data['check_key'] = $check_key;

                        $this->data['licence_som'] = $licence_som = $data;
                        $this->data['bank_fees'] = 10 + (10 * 0.16);

                        $this->data['compte_suspens_provision'] = $compte_suspens_provision;
                        $this->data['licenses'] = $code_licenses;

                        $this->data['customer_account'] = $customer_account;
                        $this->data['customer_account_currency'] = $customer_account_currency;

                        $this->data['common_infos'] = $common_infos;
                        $this->data['step'] = 1;
                        $this->data['invoice_batchId'] = $id;
                        $this->data['licence_number'] = $licence_number;
                        $this->data['provision_exempt'] = $this->feesModel->get_dropdown('provision_exempt');
                        $this->data['licence_provision'] = $this->seguceModel->get_dropdown('licence_provision');
                        $this->data['customer_account_exempt_provision'] = $customer_account_exempt_provision;
                        $this->data['customer_account_currency_exempt_provision'] = $customer_account_currency_exempt_provision;

                        # Get the list of accounts associated to the CLT
                        $this->data['account_codeimport'] = $this->accountsModel->get_dropdown("account_code_import");
                        $this->data['account_codeimport_currency'] = $this->accountsModel->get_dropdown("account_code_import_currency");

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_step_2', $this->data);
                }
                elseif ($obj == "invoice_occ_step_2")
                {
                        $licenses_treat = [];
                        $licenses_no_treat = [];
                        $licence_issues_treat = [];
                        $licence_issues_no_treat = [];

                        $instructions2 = array();
                        $instructions_issues2 = array();

                        $instructions = array();
                        $instructions_issues = array();

                        $licenses = array();
                        $licenses_issues = array();

                        $amounts = array();
                        $amounts_issues = array();

                        $total_amount_paid_customer = array();

                        # Retrieve the exchange rate
                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                $taux = $result['Dollar_4'];
                        } else {
                                $taux = 1;
                        }

                        # Generation of transactions based on each licence number
                        $agence_src = $this->session->get('Logiref_guichet');

                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        if(isset($comptes['TMB']['CSP']['USD']))
                        {
                                $provision_account = $comptes['TMB']['CSP']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CSP']['USD']))
                        {
                                $provision_account = $comptes['Rawbank']['CSP']['USD'];
                        }
                        else{
                                $provision_account = '00000000000000000000000';
                        }

                        $customer_account = $this->seguceModel->get_dropdown("provision_current_account");
                        $customer_account_currency = $this->seguceModel->get_dropdown("provision_current_account_currency");

                        $customer_account_provision = $this->seguceModel->get_dropdown("provision_customer_account");
                        $customer_account_currency_provision = $this->seguceModel->get_dropdown("provision_customer_account_currency");
                        $provision_account_clt = $this->seguceModel->get_dropdown("provision_account_by_clt");

                        $customer_account_exempted = $this->feesModel->get_dropdown("customer_account_exempt_provision");
                        $customer_currency_exempted = $this->feesModel->get_dropdown("customer_account_currency_exempt_provision");

                        $licence_provision = $this->seguceModel->get_dropdown('licence_provision');

                        $data = array();

                        $data['designation'] = isset($_POST['nom_import']) ? $_POST['nom_import'] : "";
                        $data['code_import'] = isset($_POST['code_import']) ? $_POST['code_import'] : "";
                        $data['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                        $data['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                        $data['code_bank'] = isset($_POST['code_bque']) ? $_POST['code_bque'] : "";
                        $data['compte_provision'] = $provision_account;
                        $data['compte_suspens_provision'] = $provision_account;
                        $data['devise'] = "USD";
                        $data['sigle'] = isset($_POST['sigle_bque']) ? $_POST['sigle_bque'] : "";
                        $data['code_import'] = isset($_POST['code_import']) ? $_POST['code_import'] : "";
                        $data['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                        $data['date_edit'] = isset($_POST['date_edit']) ? $_POST['date_edit'] : "";

                        if(array_key_exists('eximtrade_provision_account',$this->functionalities['ALL']))
                        {
                                $instructions = array();
                                $instructions_fb = array();
                                $instructions_issues = array();
                                $instructions_issues_fb = array();
                                $licenses = array();
                                $licenses_issues = array();
                                $return = array();
                                $amounts = array();
                                $amounts_issues = array();

                                $part_occ = false;

                                if(isset($_POST['licence']) && $_POST['licence'] != "")
                                {
                                        $licenses = $_POST['licence'];

                                        $total_amount_licence = 0;
                                        $amount = array();

                                        # Calcul du montant total de chaque licence avec provision suffisante
                                        foreach ($_POST['licence'] as $clt=>$line)
                                        {
                                                foreach ($line as $key=>$row)
                                                {
                                                        $total_amount_licence = 0;

                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                $amount_recipe = $amount_recipe + $value;
                                                                        }
                                                                        $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                }
                                                        }
                                                        $amount[$key] = $total_amount_licence;

                                                }
                                        }

                                        foreach ($_POST['licence'] as $clt=>$line)
                                        {
                                                foreach($line as $key=>$row)
                                                {
                                                        $provision_amount = $this->seguceModel->get_dropdown("licence_provision");

                                                        if(isset($row['livraison'][0]) && $row['livraison'][0] == 'T')
                                                        {
                                                                $data['amount_provision'] = isset($provision_amount[$key]) ? $provision_amount[$key] : $amount[$key];
                                                                $data['montant'] = $amount[$key];
                                                        }
                                                        else
                                                        {
                                                                $provision_amount_value = isset($provision_amount[$key]) ? $provision_amount[$key] : $amount[$key];

                                                                //$data['amount_provision'] = $amount[$key];
                                                                //$data['montant'] = $amount[$key];

                                                                if($provision_amount_value >= $row['montantprov'][0])
                                                                {
                                                                        $data['amount_provision'] = $data['montant'] = $amount[$key];
                                                                }
                                                                elseif($provision_amount_value < $row['montantprov'][0])
                                                                {
                                                                        $data['amount_provision'] = $provision_amount[$key];
                                                                        $data['montant'] = $amount[$key];
                                                                }

                                                        }

                                                        $data['licence'] = $key;
                                                        $data['designation'] = isset($_POST['customers'][$key]) ? $_POST['customers'][$key] : "";
                                                        $data['customer_account'] = isset($_POST['compte'][$_POST['licence_clt'][$key]]) ? $_POST['compte'][$_POST['licence_clt'][$key]] : "";
                                                        $data['account_currency'] = isset($_POST['devise'][$_POST['licence_clt'][$key]]) ? $_POST['devise'][$_POST['licence_clt'][$key]] : "";
                                                        $data['account_provision_currency'] = isset($account_provision_currency[$key]) ? $account_provision_currency[$key] : "";
                                                        $data['customer_account_currency'] = isset($customer_account_currency[$key]) ? $customer_account_currency[$key] : "";

                                                        $compte_provision = isset($account_provision[$key]) ? $account_provision[$key] : "000000000000000000000000";
                                                        $compte_client = isset($customer_account[$key]) ? $customer_account[$key] : "000000000000000000000000";
                                                        $devise_compte_client = ($customer_account_currency[$key]) ? $customer_account_currency[$key] : '';

                                                        $return = $this->seguceModel->get_instructions_seguce_debit_by_licence_number1($data, $comptes, $compte_provision, $compte_client);

                                                        foreach ($return as $instruction)
                                                        {
                                                                $instructions[$key][] = $instruction;
                                                        }

                                                        $comm_occ = 0;
                                                        $comm_bivac = 0;
                                                        $amount_occ = 0;
                                                        $amount_bivac = 0;

                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                if ($cle == 'CPO')
                                                                                {
                                                                                        $amount_occ = $value;
                                                                                        $comm_occ = ($amount_occ * 0.232)/100;
                                                                                        $tva_occ = $comm_occ * 0.16;

                                                                                        $amount_recipe = $amount_occ - ($comm_occ + $tva_occ);
                                                                                }
                                                                                elseif ($cle == 'CPB')
                                                                                {
                                                                                        $amount_bivac = $value;
                                                                                        $comm_bivac = ($amount_bivac * 0.116)/100;
                                                                                        $tva_bivac = $comm_bivac * 0.16;

                                                                                        $amount_recipe = $amount_bivac - ($comm_bivac+$tva_bivac);
                                                                                }
                                                                                else
                                                                                {
                                                                                        $amount_recipe = $value;
                                                                                }
                                                                        }

                                                                        $amounts[$key]['CPO'] = $amount_occ;
                                                                        $amounts[$key]['CPB'] = $amount_bivac;

                                                                        //$data['montant'] = $amount_recipe;
                                                                        $data['montant'] = $this->data('get_reduce_decimal', $amount_recipe , 2);

                                                                        $data['licence'] = $key;
                                                                        $type = $cle;
                                                                        $data['designation'] = isset($_POST['customers'][$key]) ? $_POST['customers'][$key] : "";
                                                                        $instructions[$key][] = $this->seguceModel->get_instructions_seguce_by_licence_number1($data, $comptes, $provision_account, $type);
                                                                }
                                                        }

                                                        unset($data['amount_provision']);
                                                }
                                        }
                                }

                                if(isset($_POST['licence_issues']) && $_POST['licence_issues'] != "")
                                {
                                        $amount_issues = array();
                                        $total_amount_licence = 0;
                                        $amount_paid_occ = array();

                                        # Calcul du montant total de chaque licence avec provision insuffisante
                                        foreach ($_POST['licence_issues'] as $lines)
                                        {
                                                foreach ($lines as $key=>$row)
                                                {
                                                        $total_amount_licence = 0;
                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                $amount_recipe = $amount_recipe + $value;
                                                                        }
                                                                        $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                }
                                                        }
                                                        $amount_issues[$key] = $total_amount_licence;
                                                }
                                        }

                                        foreach ($_POST['licence_issues'] as $clt=>$lines)
                                        {
                                                $amount_occ = 0;
                                                $amount_bivac = 0;
                                                $comm_occ = 0;
                                                $comm_bivac = 0;

                                                foreach ($lines as $key=>$row)
                                                {
                                                        $provision_amount = $this->seguceModel->get_dropdown("licence_provision");
                                                        $data['amount_provision'] = isset($provision_amount[$key]) ? $provision_amount[$key] : 0;

                                                        if($data['amount_provision'] !="")
                                                        {
                                                                # The provision exists, we get the provision amount
                                                                $data['amount_provision'] = $data['amount_provision'];
                                                                $data['montant'] = $amount_issues[$key];
                                                        }
                                                        else
                                                        {
                                                                # If the provision doesn't exist, we get the missing amount
                                                                $data['montant'] = $amount_issues[$key];
                                                        }

                                                        $data['missing_amount'] = isset($_POST['missing_amount_issues'][$_POST['licence_clt'][$key]]) ? $_POST['missing_amount_issues'][$_POST['licence_clt'][$key]] : "";
                                                        $data['licence'] = $key;
                                                        $data['designation'] = isset($_POST['customers'][$key]) ? $_POST['customers'][$key] : "";
                                                        $data['customer_account'] = isset($_POST['compte'][$_POST['licence_clt'][$key]]) ? $_POST['compte'][$_POST['licence_clt'][$key]] : "00000000000000000000000";
                                                        $data['account_currency'] = $data['devise'] = isset($_POST['devise'][$_POST['licence_clt'][$key]]) ? $_POST['devise'][$_POST['licence_clt'][$key]] : "";
                                                        $data['account_provision_currency'] = $data['compte_provision'] = isset($account_provision_currency[$key]) ? $account_provision_currency[$key] : "";
                                                        $data['customer_account_currency'] = $data['currency'] =  isset($customer_account_currency[$key]) ? $customer_account_currency[$key] : "";
                                                        $data['compte_provision'] = $compte_provision  = isset($account_provision[$key]) ? $account_provision[$key] : "00000000000000000000000";
                                                        $compte_client = isset($customer_account[$key]) ? $customer_account[$key] : $data['customer_account'];

                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {

                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                if ($cle == 'CPO')
                                                                                {
                                                                                        $amount_occ = $value;
                                                                                        $comm_occ = ($amount_occ * 0.232)/100;
                                                                                        $tva_occ = $comm_occ * 0.16;

                                                                                        $amount_recipe = $amount_occ - ($comm_occ + $tva_occ);
                                                                                }
                                                                                elseif ($cle == 'CPB')
                                                                                {
                                                                                        $amount_bivac = $value;
                                                                                        $comm_bivac = ($amount_bivac * 0.116)/100;
                                                                                        $tva_bivac = $comm_bivac * 0.16;

                                                                                        $amount_recipe = $amount_bivac - ($comm_bivac + $tva_bivac);
                                                                                }
                                                                                else
                                                                                {
                                                                                        $amount_recipe = $value;
                                                                                }
                                                                        }

                                                                        $amounts_issues[$key]['CPO'] = $amount_occ;
                                                                        $amounts_issues[$key]['CPB'] = $amount_bivac;

                                                                        $data['montant'] = $this->data('get_reduce_decimal', $amount_recipe , 2);

                                                                        $data['licence'] = $key;
                                                                        $data['designation'] = isset($_POST['customers'][$key]) ? $_POST['customers'][$key] : "";
                                                                        $type = $cle;

                                                                        $instructions_issues[$key][] = $this->seguceModel->get_instructions_seguce_by_licence_number1($data, $comptes, $provision_account, $type);
                                                                }

                                                        }

                                                        $licenses_issues[$clt] = $lines;

                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;

                                                        foreach($amounts_issues as $aKey => $aVal)
                                                        {
                                                                foreach ($aVal as $cle => $value)
                                                                {
                                                                        if ($cle == 'CPO') $total_amount_occ += $value;
                                                                        if ($cle == 'CPB') $total_amount_bivac += $value;
                                                                }
                                                        }

                                                        #Calcul de commission OCC & BIVAC
                                                        $com_occ = $this->data("get_occ_bivac_commission", "OCC",  $total_amount_occ);
                                                        $com_bivac = $this->data("get_occ_bivac_commission", "BIVAC", $total_amount_bivac);

                                                        $data['amount_comm'] = $com_occ + $com_bivac;
                                                        $data['amount_tva'] = $data['amount_comm'] * 0.16;

                                                        $data['amount_comm'] = $this->data('get_reduce_decimal', $data['amount_comm'] , 2);
                                                        $data['amount_tva'] = $this->data('get_reduce_decimal', $data['amount_tva'] , 2);

                                                        if (isset($data['customer_account']) && $data['account_currency'])
                                                        {
                                                                $instructions_fb = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_fb1($data, $comptes, $compte_client);
                                                        }
                                                        else
                                                        {
                                                                $instructions_issues_fb = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_fb1($data, $comptes, $compte_client);
                                                        }
                                                }
                                        }
                                }

                                $total_amount_occ = 0;
                                $total_amount_bivac = 0;

                                if(isset($_POST['licence']) && $_POST['licence'] != "")
                                {
                                        foreach($amounts as $aKey => $aVal)
                                        {
                                                foreach ($aVal as $cle => $value)
                                                {
                                                        if ($cle == 'CPO') $total_amount_occ += $value;
                                                        if ($cle == 'CPB') $total_amount_bivac += $value;
                                                }
                                        }
                                }

                                if(isset($_POST['licence_issues']) && $_POST['licence_issues'] != "")
                                {
                                        foreach($amounts as $aKey => $aVal)
                                        {
                                                foreach ($aVal as $cle => $value)
                                                {
                                                        if ($cle == 'CPO') $total_amount_occ += $value;
                                                        if ($cle == 'CPB') $total_amount_bivac += $value;
                                                }
                                        }
                                }

                                #Calcul de commission OCC & BIVAC
                                $com_occ = $this->data("get_occ_bivac_commission", "OCC",  $total_amount_occ);
                                $com_bivac = $this->data("get_occ_bivac_commission", "BIVAC", $total_amount_bivac);

                                $data['amount_comm'] = $com_occ + $com_bivac;
                                $data['amount_tva'] = $data['amount_comm'] * 0.16;

                                $data['amount_comm'] = $this->data('get_reduce_decimal', $data['amount_comm'] , 2);
                                $data['amount_tva'] = $this->data('get_reduce_decimal', $data['amount_tva'] , 2);

                                $instructions_fb = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_fb1($data, $comptes);

                                $this->data['datas'] = isset($licenses) ? $licenses : "";
                                $this->data['customers'] = isset($_POST['customers']) ? $_POST['customers'] : "";
                                $this->data['customer_codes'] = isset($_POST['customer_codes']) ? $_POST['customer_codes'] : "";
                                $this->data['licence_issues'] = isset($licenses_issues) ? $licenses_issues : "";
                                $this->data['customer_issues'] = isset($_POST['customer_issues']) ? $_POST['customer_issues'] : "";
                                $this->data['compte_suspens_provision'] = $provision_account;
                                $this->data['invoice_batchId'] = $_POST['invoice_batchId'];
                                $this->data['common_infos'] = $data;
                                $this->data['instructions'] = $instructions;
                                $this->data['instructions_fb'] = $instructions_fb;
                                $this->data['instructions_issues'] = $instructions_issues;
                                $this->data['instructions_issues_fb'] = $instructions_issues_fb;
                                $this->data['compte_clients'] = $_POST['compte'];
                                $this->data['devise_comptes'] = $_POST['devise'];
                                $this->data['licence_clt'] = $_POST['licence_clt'];
                        }
                        else{
                                if(array_key_exists('eximtrade_select_license_for_processing_and_validation_of_slip',$this->functionalities['ALL']))
                                {

                                        # TRAITEMENT DES FACTURES AVEC PROVISION SUFFISSANTE & SUPERIEURES
                                        if (isset($_POST["licence"]) && $_POST["licence"] != "")
                                        {
                                                foreach ($_POST["licence"] as $client => $licences)
                                                {
                                                        foreach ($licences as $key => $val)
                                                        {
                                                                if (in_array($key, $_POST["licences"]))
                                                                {
                                                                        $licenses_treat[$client][$key] = $val;
                                                                }
                                                                else
                                                                {
                                                                        //$licenses_no_treat[$client][$key] = $val;
                                                                }
                                                        }
                                                }
                                        }

                                        if(isset($licenses_treat) && $licenses_treat != "")
                                        {
                                                $licence_number = $this->seguceModel->get_dropdown("licence_number");

                                                $licenses = $_POST['licence'];

                                                $total_amount_licence = 0;
                                                $amount = array();

                                                # Calcul du montant total de chaque licence avec provision suffisante
                                                foreach ($_POST['licence'] as $clt=>$line)
                                                {
                                                        foreach ($line as $key => $row)
                                                        {
                                                                $total_amount_licence = 0;

                                                                foreach($row as $cle => $ligne)
                                                                {
                                                                        if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                        {
                                                                                $amount_recipe = 0;

                                                                                foreach ($ligne as $value)
                                                                                {
                                                                                        $amount_recipe = $amount_recipe + $value;
                                                                                }
                                                                                $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                        }
                                                                }

                                                                $amount[$key] = $total_amount_licence;
                                                        }
                                                }

                                                # Extourne de la provision
                                                foreach ($_POST['licence'] as $clt => $line)
                                                {
                                                        foreach($line as $key => $row)
                                                        {
                                                                # Recuperation de la première partie du numéro de licence
                                                                $license_number = explode('-', $key);
                                                                $segment_license_number = $license_number[0];

                                                                if (!empty($customer_account[$key]))
                                                                {
                                                                        $data['customer_account'] = $customer_account[$key];
                                                                }
                                                                elseif (in_array($segment_license_number, $licence_number))
                                                                {
                                                                        $data['customer_account'] = !empty($_POST['compte'][$clt]) ?  $_POST['compte'][$clt] : "000000000000000000000000";
                                                                }
                                                                else
                                                                {
                                                                        $data['customer_account'] = "000000000000000000000000";
                                                                }

                                                                $data['compte_provision'] = !empty($provision_account) ? $provision_account : "000000000000000000000000";
                                                                $data['account_currency'] = !empty($customer_account_currency[$key]) ? $customer_account_currency[$key] : "";

                                                                if(isset($row['livraison'][0]) && $row['livraison'][0] == 'T')
                                                                {
                                                                        if (in_array($segment_license_number, $licence_number))
                                                                        {
                                                                                $surplus_amount = isset($_POST['tsurplus_amount'][$segment_license_number]) ? $_POST['tsurplus_amount'][$segment_license_number] : "";

                                                                                if ($surplus_amount != "")
                                                                                {
                                                                                        $data['licence'] = $segment_license_number;
                                                                                        $data['montant'] = $surplus_amount;

                                                                                        $instructions[$segment_license_number][] = $this->seguceModel->get_instructions_provision_reverse_by_customer($data);
                                                                                }
                                                                        }

                                                                        if (in_array($key, $licence_number))
                                                                        {
                                                                                $surplus_amount = isset($_POST['tsurplus_amount'][$key]) ? $_POST['tsurplus_amount'][$key] : "";

                                                                                if ($surplus_amount != "")
                                                                                {
                                                                                        $data['licence'] = $key;
                                                                                        $data['montant'] = $surplus_amount;

                                                                                        $instructions[$key][]  = $this->seguceModel->get_instructions_provision_reverse_by_customer($data);
                                                                                }

                                                                        }
                                                                }
                                                        }
                                                }

                                                foreach ($_POST['licence'] as $clt => $line)
                                                {
                                                        foreach($line as $key=>$row)
                                                        {
                                                                $licenses[$clt][$key] = $row;
                                                        }
                                                }
                                        }

                                        # TRAITEMENT DES FACTURES AVEC PROVISION INSUFFISSANTE & INEXISTANTE
                                        if (isset($_POST['licence_issues']) && $_POST['licence_issues']!="")
                                        {
                                                foreach ($_POST['licence_issues'] as $client => $licences)
                                                {
                                                        foreach ($licences as $key => $val)
                                                        {
                                                                if (in_array($key, $_POST["licences"]))
                                                                {
                                                                        $licence_issues_treat[$client][$key] = $val;
                                                                }
                                                                else
                                                                {
                                                                        $licence_issues_no_treat[$client][$key] = $val;
                                                                }
                                                        }
                                                }
                                        }

                                        if(isset($licence_issues_treat) && !empty($licence_issues_treat))
                                        {
                                                $amount_issues = array();
                                                $total_amount_licence = 0;

                                                # Calcul du montant total de chaque licence avec provision insuffisante
                                                foreach ($licence_issues_treat as $lines)
                                                {
                                                        foreach ($lines as $key => $row)
                                                        {
                                                                $total_amount_licence = 0;

                                                                foreach($row as $cle=>$ligne)
                                                                {
                                                                        if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                        {
                                                                                $amount_recipe = 0;

                                                                                foreach ($ligne as $value)
                                                                                {
                                                                                        $amount_recipe = $amount_recipe + $value;
                                                                                }
                                                                                $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                        }
                                                                }

                                                                $amount_issues[$key] = $total_amount_licence;
                                                        }
                                                }

                                                # Complement des frais à partir du compte courant pour crediter la partie manquante dans le compte provision
                                                $clt_licenses = [];
                                                $clt_licenses_no_trouve = [];

                                                foreach ($_POST['clts'] as $clt => $licences)
                                                {
                                                        foreach ($licences as $licence)
                                                        {
                                                                if (in_array($licence, $_POST["licences"]))
                                                                {
                                                                        $clt_licenses[$clt][] = $licence;
                                                                }
                                                                else
                                                                {
                                                                        $clt_licenses_no_trouve[$clt][] = $licence;
                                                                }
                                                        }
                                                }

                                                foreach ($clt_licenses as $cKey => $lisences)
                                                {
                                                        if (isset($_POST['balance'][$cKey]))
                                                        {
                                                                $customer_balance = str_replace(' ','',$_POST['balance'][$cKey]);
                                                                $customer_balance = str_replace(',','.',$customer_balance);

                                                                if ($data['account_currency']== "CDF")
                                                                {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                }
                                                                else if ($data['account_currency'] == 'EUR')
                                                                {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $customer_balance = 0;
                                                        }

                                                        $data['customer_account'] = isset($_POST['compte'][$cKey]) ? $_POST['compte'][$cKey] : "";
                                                        $data['account_currency'] = isset($_POST['devise'][$cKey]) ? $_POST['devise'][$cKey] : "";

                                                        foreach ($lisences as $line)
                                                        {
                                                                if (isset($_POST['missing_amount_issues'][$line]))
                                                                {
                                                                        $data['montant'] = $data['missing_amount'] = $_POST['missing_amount_issues'][$line];
                                                                        $data['licence'] = $line;

                                                                        if ($customer_balance >= $data['montant'])
                                                                        {
                                                                                $instructions[$line][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data, $provision_account);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions_issues[$line][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data, $provision_account);
                                                                        }

                                                                        $customer_balance = $customer_balance - $data['montant'];

                                                                        $_POST['balance'][$cKey] = $customer_balance;
                                                                }
                                                        }
                                                }

                                                foreach ($licence_issues_treat as $clt=>$lines)
                                                {
                                                        $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "00000000000000000000000";
                                                        $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";

                                                        if (isset($_POST['balance'][$clt]))
                                                        {
                                                                $customer_balance = str_replace(' ','',$_POST['balance'][$clt]);
                                                                $customer_balance = str_replace(',','.',$customer_balance);

                                                                if ($data['account_currency']== "CDF")
                                                                {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                }
                                                                else if ($data['account_currency'] == 'EUR')
                                                                {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $customer_balance = 0;
                                                        }

                                                        foreach ($lines as $key => $row)
                                                        {
                                                                $license_number = explode('-', $key);
                                                                $segment_license_number = $license_number[0];

                                                                if (isset($licence_provision[$key]))
                                                                {
                                                                        $data['amount_provision'] = $licence_provision[$key];
                                                                }
                                                                elseif(isset($licence_provision[$segment_license_number]))
                                                                {
                                                                        $data['amount_provision'] = $licence_provision[$segment_license_number];
                                                                }
                                                                else
                                                                {
                                                                        $data['amount_provision'] = 0;
                                                                }

                                                                # Paiement de la facture à partir du compte du client
                                                                if (isset($data['customer_account']) && $data['customer_account'] != "" )
                                                                {
                                                                        # Provision manquante
                                                                        if(isset($data['amount_provision']) && $data['amount_provision'] > 0)
                                                                        {
                                                                                if (isset($_POST['missing_amount_issues'][$key]) && $customer_balance >= $_POST['missing_amount_issues'][$key])
                                                                                {
                                                                                        $licenses[$clt][$key] = $row;

                                                                                        # Update of baalnce
                                                                                        $customer_balance = $customer_balance - $_POST['missing_amount_issues'][$key];
                                                                                        $_POST['balance'][$clt] = $customer_balance;
                                                                                }
                                                                                else
                                                                                {
                                                                                        $licenses_issues[$clt][$key]  =  $row;

                                                                                        foreach($row as $cle=>$ligne)
                                                                                        {
                                                                                                if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                                {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value)
                                                                                                        {
                                                                                                                if ($cle == 'CPO') $amount_occ = $value;
                                                                                                                elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                                elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                                        }

                                                                                                        if (!isset($amounts_issues[$key]))
                                                                                                        {
                                                                                                                $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                                        }

                                                                                                        $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                                        $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                                        $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                $missing_amount_exempt = isset($_POST['missing_amount_exempt'])? $_POST['missing_amount_exempt'] : [];
                                                                                $amounts_noprovision = isset($_POST['amounts_noprovision'])? $_POST['amounts_noprovision'] : [];

                                                                                if (isset($_POST['missing_amount_exempt'][$key]))
                                                                                {
                                                                                        $data['missing_amounts_exempt'] = $_POST['missing_amount_exempt'][$key];
                                                                                        $data['missing_amount_exempt'] = $_POST['missing_amount_exempt'][$key];
                                                                                }

                                                                                if (isset($_POST['amounts_noprovision'][$key]))
                                                                                {
                                                                                        $data['amounts_noprovision'] = $_POST['amounts_noprovision'][$key];
                                                                                }

                                                                                # La balance du client peut couvrir le montant total de la facture
                                                                                if ((array_key_exists($key, $missing_amount_exempt) && $_POST['balance'][$clt] >= $data['missing_amount_exempt']) || array_key_exists($key, $amounts_noprovision) && $_POST['balance'][$clt] >= $data['amounts_noprovision'])
                                                                                {
                                                                                        $licenses[$clt][$key] =  $row;

                                                                                        if (isset($_POST['missing_amount_issues'][$key])):
                                                                                                $customer_balance = $customer_balance - $_POST['missing_amount_issues'][$key];

                                                                                                $_POST['balance'][$clt] = $customer_balance;
                                                                                        endif;

                                                                                }
                                                                                else
                                                                                {
                                                                                        $licenses_issues[$clt][$key] = $row;

                                                                                        foreach($row as $cle=>$ligne)
                                                                                        {
                                                                                                if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                                {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value)
                                                                                                        {
                                                                                                                if ($cle == 'CPO') $amount_occ = $value;
                                                                                                                elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                                elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                                        }

                                                                                                        if (!isset($amounts_issues[$key]))
                                                                                                        {
                                                                                                                $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                                        }

                                                                                                        $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                                        $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                                        $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                }
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $licenses_issues[$clt][$key]  = $row;

                                                                        foreach($row as $cle=>$ligne)
                                                                        {
                                                                                if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                {
                                                                                        $amount_occ = 0;
                                                                                        $amount_bivac = 0;
                                                                                        $amount_occ_tva = 0;

                                                                                        foreach ($ligne as $value)
                                                                                        {
                                                                                                if ($cle == 'CPO') $amount_occ = $value;
                                                                                                elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                        }

                                                                                        if (!isset($amounts_issues[$key]))
                                                                                        {
                                                                                                $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                        }

                                                                                        $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                        $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                        $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }

                                        if(isset($licence_issues_no_treat) && !empty($licence_issues_no_treat))
                                        {
                                                foreach ($licence_issues_no_treat as $clt=>$lines)
                                                {
                                                        $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "00000000000000000000000";
                                                        $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";

                                                        if (isset($_POST['balance'][$clt]))
                                                        {
                                                                $customer_balance = str_replace(' ','',$_POST['balance'][$clt]);
                                                                $customer_balance = str_replace(',','.',$customer_balance);

                                                                if ($data['account_currency']== "CDF")
                                                                {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                }
                                                                else if ($data['account_currency'] == 'EUR')
                                                                {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $customer_balance = 0;
                                                        }

                                                        foreach ($lines as $key => $row)
                                                        {
                                                                $license_number = explode('-', $key);
                                                                $segment_license_number = $license_number[0];

                                                                if (isset($licence_provision[$key]))
                                                                {
                                                                        $data['amount_provision'] = $licence_provision[$key];
                                                                }
                                                                elseif(isset($licence_provision[$segment_license_number]))
                                                                {
                                                                        $data['amount_provision'] = $licence_provision[$segment_license_number];
                                                                }
                                                                else
                                                                {
                                                                        $data['amount_provision'] = 0;
                                                                }

                                                                # Paiement de la facture à partir du compte du client
                                                                if (isset($data['customer_account']) && $data['customer_account'] != "" )
                                                                {
                                                                        # Provision manquante
                                                                        if(isset($data['amount_provision']) && $data['amount_provision'] > 0)
                                                                        {
                                                                                $licenses_issues[$clt][$key]  =  $row;

                                                                                foreach($row as $cle=>$ligne)
                                                                                {
                                                                                        if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                        {
                                                                                                $amount_occ = 0;
                                                                                                $amount_bivac = 0;
                                                                                                $amount_occ_tva = 0;

                                                                                                foreach ($ligne as $value)
                                                                                                {
                                                                                                        if ($cle == 'CPO') $amount_occ = $value;
                                                                                                        elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                        elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                                }

                                                                                                if (!isset($amounts_issues[$key]))
                                                                                                {
                                                                                                        $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                                }

                                                                                                $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                                $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                                $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                        }
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                $missing_amount_exempt = isset($_POST['missing_amount_exempt'])? $_POST['missing_amount_exempt'] : [];
                                                                                $amounts_noprovision = isset($_POST['amounts_noprovision'])? $_POST['amounts_noprovision'] : [];

                                                                                if (isset($_POST['missing_amount_exempt'][$key]))
                                                                                {
                                                                                        $data['missing_amounts_exempt'] = $_POST['missing_amount_exempt'][$key];
                                                                                        $data['missing_amount_exempt'] = $_POST['missing_amount_exempt'][$key];
                                                                                }

                                                                                if (isset($_POST['amounts_noprovision'][$key]))
                                                                                {
                                                                                        $data['amounts_noprovision'] = $_POST['amounts_noprovision'][$key];
                                                                                }

                                                                                $licenses_issues[$clt][$key] = $row;

                                                                                foreach($row as $cle=>$ligne)
                                                                                {
                                                                                        if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                        {
                                                                                                $amount_occ = 0;
                                                                                                $amount_bivac = 0;
                                                                                                $amount_occ_tva = 0;

                                                                                                foreach ($ligne as $value)
                                                                                                {
                                                                                                        if ($cle == 'CPO') $amount_occ = $value;
                                                                                                        elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                        elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                                }

                                                                                                if (!isset($amounts_issues[$key]))
                                                                                                {
                                                                                                        $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                                }

                                                                                                $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                                $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                                $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                        }
                                                                                }

                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $licenses_issues[$clt][$key]  = $row;

                                                                        foreach($row as $cle=>$ligne)
                                                                        {
                                                                                if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                                {
                                                                                        $amount_occ = 0;
                                                                                        $amount_bivac = 0;
                                                                                        $amount_occ_tva = 0;

                                                                                        foreach ($ligne as $value)
                                                                                        {
                                                                                                if ($cle == 'CPO') $amount_occ = $value;
                                                                                                elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                                elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                        }

                                                                                        if (!isset($amounts_issues[$key]))
                                                                                        {
                                                                                                $amounts_issues[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                        }

                                                                                        $amounts_issues[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                        $amounts_issues[$key]['CPB'] += $amount_bivac;
                                                                                        $amounts_issues[$key]['CTC'] += $amount_occ_tva;
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }

                                        # TRAITEMENT DES FACTURES AVEC PROVISION SUFFISSANTE, SUPERIEURE & MANQUANTE OU INEXISTANTE (COUVRE PAR LE COMPTE DU CLIENT)
                                        if(isset($licenses) && $licenses != "")
                                        {
                                                foreach ($licenses as $clt=>$line)
                                                {
                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;
                                                        $total_occ_tva = 0;

                                                        foreach($line as $key=>$row)
                                                        {
                                                                foreach($row as $cle=>$ligne)
                                                                {
                                                                        if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                        {
                                                                                $amount_occ = 0;
                                                                                $amount_bivac = 0;
                                                                                $amount_occ_tva = 0;

                                                                                foreach ($ligne as $value)
                                                                                {
                                                                                        if ($cle == 'CPO') $amount_occ = $value;
                                                                                        elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                        elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                }

                                                                                if (!isset($amounts[$key]))
                                                                                {
                                                                                        $amounts[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                }

                                                                                $amounts[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                $amounts[$key]['CPB'] += $amount_bivac;
                                                                                $amounts[$key]['CTC'] += $amount_occ_tva;
                                                                        }
                                                                }
                                                        }
                                                }

                                                # Calcul des monatants totaux des frais de la part OCC, BIVAC & TVA de de la part de l'OCC
                                                foreach ($amounts as $aKey => $amount)
                                                {
                                                        $missing_amount_exempt = isset($_POST['missing_amount_exempt'])? $_POST['missing_amount_exempt'] : "";
                                                        $amounts_noprovision = isset($_POST['amounts_noprovision'])? $_POST['amounts_noprovision'] : [];

                                                        if((isset($missing_amount_exempt[$aKey]) && $missing_amount_exempt[$aKey] != "") || isset($amounts_noprovision[$aKey]) && $amounts_noprovision[$aKey] != "")
                                                        {


                                                                $clt =  (isset($_POST['licence_clt'][$aKey])) ? $_POST['licence_clt'][$aKey] : "";
                                                                $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "";
                                                                $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";

                                                                foreach($amount as $keys => $val)
                                                                {
                                                                        $type = $keys;
                                                                        $data['montant'] = $val;
                                                                        $data['designation'] = isset($_POST['customers'][$aKey]) ? $_POST['customers'][$aKey] : "";
                                                                        $data['licence'] = $keys;

                                                                        if ($type != 'CTC')
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                foreach($amount as $keys => $val)
                                                                {

                                                                        $type = $keys;
                                                                        $data['montant'] = $val;
                                                                        $data['designation'] = isset($_POST['customers'][$aKey]) ? $_POST['customers'][$aKey] : "";
                                                                        $data['licence'] = $aKey;

                                                                        if ($type != 'CTC')
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $provision_account, $type);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                        }
                                                                }
                                                        }
                                                }

                                                # Prelevement de la commission et TVA
                                                $instructions_fees = array();

                                                foreach ($licenses as $clt=>$line)
                                                {
                                                        $data['montant'] = 10;
                                                        $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "";
                                                        $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";
                                                        $data['designation'] = isset($_POST['customer_clt'][$clt]) ? $_POST['customer_clt'][$clt] : "";

                                                        $data['montant_tva'] = $data['montant'] * 0.16;

                                                        $fees_amount = $data['montant'] + $data['montant_tva'];

                                                        if (isset($_POST['balance'][$clt]))
                                                        {
                                                                $customer_balance = str_replace(' ','',$_POST['balance'][$clt]);
                                                                $customer_balance = str_replace(',','.',$customer_balance);

                                                                if ($data['account_currency'] == "CDF")
                                                                {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                }
                                                                else if ($data['account_currency'] == 'EUR')
                                                                {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $customer_balance = 0;
                                                        }

                                                        $data['Priority']= 1;
                                                        $instructions_fees  = $this->seguceModel->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                                        foreach ($instructions_fees as $instruction)
                                                        {
                                                                $instructions2[$clt][] = $instruction;
                                                        }
                                                }
                                        }

                                        if (isset($licenses_issues) && $licenses_issues !="")
                                        {
                                                # CALCUL DES MONTANTS TOTAUX DES FRAIS OCC-BIVAC PAR CODE IMPORTATEUR
                                                foreach ($amounts_issues as $aKey => $amount)
                                                {
                                                        foreach($amount as $keys => $val)
                                                        {
                                                                $type = $keys;
                                                                $data['montant'] = $val;
                                                                $data['designation'] = isset($_POST['customers'][$aKey]) ? $_POST['customers'][$aKey] : "";

                                                                $customers_account = isset($_POST['compte'][$aKey]) ? $_POST['compte'][$aKey] : "";
                                                                $account_currency = isset($_POST['devise'][$aKey]) ? $_POST['devise'][$aKey] : "";

                                                                if ($type != 'CTC')
                                                                {
                                                                        $customers_account = $data['customer_account'] = isset($_POST['compte'][$aKey]) ? $_POST['compte'][$aKey] : "";
                                                                        $account_currency = $data['account_currency'] = isset($_POST['devise'][$aKey]) ? $_POST['devise'][$aKey] : "";

                                                                        if (isset($customers_account) && $customers_account !="" && isset($account_currency))
                                                                        {
                                                                                $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $provision_account, $type);
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                }
                                                        }
                                                }

                                                # CALCUL DE PRELEVEMENT DE LA COMMISSION  & TVA SUR LA COMMISSION
                                                $instructions_fees_issues = array();

                                                foreach ($licenses_issues as $clt=>$line)
                                                {
                                                        $data['montant'] = 10;

                                                        $data['designation'] = isset($_POST['customer_clt'][$clt]) ? $_POST['customer_clt'][$clt] : "";
                                                        $data['Priority']= 1;

                                                        if (isset($customer_account_provision[$clt]) && $customer_account_provision[$clt] !="")
                                                        {
                                                                $data['customer_account'] = $customer_account_provision[$clt];
                                                                $data['account_currency'] = isset($customer_account_currency_provision[$clt]) ? $customer_account_currency_provision[$clt] : '';
                                                        }
                                                        else if (isset($customer_account_exempted[$clt]) && $customer_account_exempted[$clt] !="")
                                                        {
                                                                $data['customer_account'] = $customer_account_exempted[$clt];
                                                                $data['account_currency'] = isset($customer_currency_exempted[$clt]) ? $customer_currency_exempted[$clt] : '';
                                                        }
                                                        else
                                                        {
                                                                $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "";
                                                                $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";
                                                        }

                                                        $instructions_fees_issues  = $this->seguceModel->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                                        foreach ($instructions_fees_issues as $instruction)
                                                        {
                                                                $instructions_issues2[$clt][] = $instruction;
                                                        }
                                                }
                                        }

                                        $this->data['surplus_amount'] = isset($_POST['tsurplus_amount'])? $_POST['tsurplus_amount'] : [];
                                }
                                else
                                {
                                        # TRAITEMENT DES FACTURES AVEC PROVISION SUFFISSANTE & SUPERIEURES
                                        if (isset($_POST['licence']) && $_POST['licence'] != "") {
                                                $licence_number = $this->seguceModel->get_dropdown("licence_number");

                                                $licenses = $_POST['licence'];

                                                $total_amount_licence = 0;
                                                $amount = array();

                                                # Calcul du montant total de chaque licence avec une provision suffissante ou supérieure
                                                foreach ($_POST['licence'] as $clt => $line) {
                                                        foreach ($line as $key => $row) {
                                                                $total_amount_clt = 0;

                                                                foreach ($row as $cle => $ligne) {
                                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                $amount_recipe = 0;

                                                                                foreach ($ligne as $value) {
                                                                                        $amount_recipe = $amount_recipe + $value;
                                                                                }
                                                                                $total_amount_clt +=  $amount_recipe;
                                                                        }
                                                                }
                                                        }
                                                }

                                                foreach ($amount as $aKey => $aVal) {
                                                        $total_amount_paid_customer[$aKey] = array_sum($aVal);
                                                }

                                                # Extourne de la provision
                                                foreach ($_POST['licence'] as $clt => $line) {
                                                        foreach ($line as $key => $row) {
                                                                $license_number = explode('-', $key);
                                                                $segment_license_number = $license_number[0];

                                                                if (!empty($customer_account[$key])) {
                                                                        $data['customer_account'] = $customer_account[$key];
                                                                } elseif (in_array($segment_license_number, $licence_number)) {
                                                                        $data['customer_account'] = !empty($_POST['compte'][$clt]) ?  $_POST['compte'][$clt] : "000000000000000000000000";
                                                                } else {
                                                                        $data['customer_account'] = "000000000000000000000000";
                                                                }

                                                                $data['compte_provision'] = !empty($provision_account) ? $provision_account : "000000000000000000000000";
                                                                $data['account_currency'] = !empty($customer_account_currency[$key]) ? $customer_account_currency[$key] : "";
                                                        }

                                                        if (isset($row['livraison'][0]) && $row['livraison'][0] == 'T') {
                                                                $surplus_amount = isset($_POST['surplus_amount'][$clt]) ? $_POST['surplus_amount'][$clt] : "";
                                                                $surplus_amount2 = isset($_POST['surplus_amount2'][$clt][$key]) ? $_POST['surplus_amount2'][$clt][$key] : "";

                                                                if ($surplus_amount != "") {
                                                                        //$data['montant'] = $surplus_amount;
                                                                        $data['montant'] = $surplus_amount2;
                                                                        $data['licence'] = $key;

                                                                        $instructions[$clt][$key]  = $this->seguceModel->get_instructions_provision_reverse_by_customer($data);
                                                                }
                                                        }
                                                }

                                                foreach ($_POST['licence'] as $clt => $line) {
                                                        foreach ($line as $key => $row) {
                                                                $licenses[$clt][$key] = $row;
                                                        }
                                                }
                                        }

                                        # TRAITEMENT DES FACTURES AVEC PROVISION INSUFFISSANTE & INEXISTANTE
                                        if (isset($_POST['licence_issues']) && $_POST['licence_issues'] != "") {
                                                $amount_issues = array();
                                                $total_amount_licence = 0;

                                                # Calcul du montant total de chaque licence avec provision insuffisante
                                                foreach ($_POST['licence_issues'] as $lines) {
                                                        foreach ($lines as $key => $row) {
                                                                $total_amount_licence = 0;

                                                                foreach ($row as $cle => $ligne) {
                                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                $amount_recipe = 0;

                                                                                foreach ($ligne as $value) {
                                                                                        $amount_recipe = $amount_recipe + $value;
                                                                                }
                                                                                $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                        }
                                                                }

                                                                $amount_issues[$key] = $total_amount_licence;
                                                        }
                                                }

                                                # Complement des frais à partir du compte courant pour crediter la partie manquante dans le compte provision
                                                foreach ($_POST['licence_issues'] as $clt => $line) {
                                                        $data['customer_account'] = !empty($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "000000000000000000000000";
                                                        $data['account_currency'] = !empty($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";

                                                        if (isset($_POST['balance'][$clt])) {
                                                                $customer_balance = str_replace(' ', '', $_POST['balance'][$clt]);
                                                                $customer_balance = str_replace(',', '.', $customer_balance);

                                                                if ($data['account_currency'] == "CDF") {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                } else if ($data['account_currency'] == 'EUR') {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        } else {
                                                                $customer_balance = 0;
                                                        }

                                                        $missing_amounts = isset($_POST['missing_amount_issues']) ? $_POST['missing_amount_issues'] : [];

                                                        if (array_key_exists($clt, $missing_amounts)) {

                                                                $data['montant'] = $data['missing_amount'] = $missing_amounts[$clt];

                                                                if ($customer_balance >= $data['montant']) {
                                                                        $instructions[$clt][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data, $provision_account);
                                                                } else {
                                                                        $instructions_issues[$clt][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data, $provision_account);
                                                                }
                                                        }
                                                }

                                                foreach ($_POST['licence_issues'] as $clt => $lines) {
                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;
                                                        $total_amount_occ_tva = 0;

                                                        $total_amount_occ_2 = 0;
                                                        $total_amount_bivac_2 = 0;

                                                        if (isset($_POST['provison_clt'][$clt])) {
                                                                $data['amount_provision'] = $_POST['provison_clt'][$clt];
                                                        } else {
                                                                $data['amount_provision'] =  0;
                                                        }

                                                        $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "00000000000000000000000";
                                                        $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";

                                                        if (isset($_POST['balance'][$clt])) {
                                                                $customer_balance = str_replace(' ', '', $_POST['balance'][$clt]);
                                                                $customer_balance = str_replace(',', '.', $customer_balance);

                                                                if ($data['account_currency'] == "CDF") {
                                                                        $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                                } else if ($data['account_currency'] == 'EUR') {
                                                                        $customer_balance = $customer_balance * $result['Dollar_4'];
                                                                        $customer_balance = $customer_balance / $result['Euro_5'];
                                                                }
                                                        } else {
                                                                $customer_balance = 0;
                                                        }

                                                        foreach ($lines as $key => $row) {
                                                                $license_number = explode('-', $key);
                                                                $segment_license_number = $license_number[0];


                                                                if (isset($data['customer_account']) && $data['customer_account'] != "") {
                                                                        if (isset($data['amount_provision']) && $data['amount_provision'] > 0) {
                                                                                if ($customer_balance >= $data['missing_amount']) {
                                                                                        $licenses[$clt][$key] = $clt_issue_with_bal[$clt][$key] = $row;

                                                                                        foreach ($row as $cle => $ligne) {
                                                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value) {
                                                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                                        }

                                                                                                        $total_amount_occ += $amount_occ;
                                                                                                        $total_amount_bivac += $amount_bivac;
                                                                                                        $total_amount_occ_tva += $amount_occ_tva;

                                                                                                        $amounts[$clt]['CPO'] = $total_amount_occ;
                                                                                                        $amounts[$clt]['CPB'] = $total_amount_bivac;
                                                                                                        $amounts[$clt]['CTC']  = $total_amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                } else {
                                                                                        $licenses_issues[$clt][$key]  =  $row;

                                                                                        foreach ($row as $cle => $ligne) {
                                                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value) {
                                                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                                        }

                                                                                                        $total_amount_occ += $amount_occ;
                                                                                                        $total_amount_bivac += $amount_bivac;
                                                                                                        $total_amount_occ_tva += $amount_occ_tva;

                                                                                                        $amounts_issues[$clt]['CPO'] = $total_amount_occ;
                                                                                                        $amounts_issues[$clt]['CPB'] = $total_amount_bivac;
                                                                                                        $amounts_issues[$clt]['CTC']  = $total_amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                }
                                                                        } else {
                                                                                $missing_amount_exempt = isset($_POST['missing_amount_exempt']) ? $_POST['missing_amount_exempt'] : [];
                                                                                $amounts_noprovision = isset($_POST['amounts_noprovision']) ? $_POST['amounts_noprovision'] : [];

                                                                                if (isset($_POST['missing_amount_exempt'][$clt])) {
                                                                                        $data['missing_amounts_exempt'] = $_POST['missing_amount_exempt'][$clt];
                                                                                        $data['missing_amount_exempt'] = $_POST['missing_amount_exempt'][$clt];
                                                                                }

                                                                                if (isset($_POST['amounts_noprovision'][$clt])) {
                                                                                        $data['amounts_noprovision'] = $_POST['amounts_noprovision'][$clt];
                                                                                }

                                                                                if ((array_key_exists($clt, $missing_amount_exempt) && $customer_balance >= $data['missing_amount_exempt']) || array_key_exists($clt, $amounts_noprovision) && $customer_balance >= $data['amounts_noprovision']) {
                                                                                        $licenses[$clt][$key] =  $row;

                                                                                        foreach ($row as $cle => $ligne) {
                                                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value) {
                                                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                                        }

                                                                                                        $total_amount_occ += $amount_occ;
                                                                                                        $total_amount_bivac += $amount_bivac;
                                                                                                        $total_amount_occ_tva += $amount_occ_tva;

                                                                                                        $amounts[$clt]['CPO'] = $total_amount_occ;
                                                                                                        $amounts[$clt]['CPB'] = $total_amount_bivac;
                                                                                                        $amounts[$clt]['CTC']  = $total_amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                } else {
                                                                                        $licenses_issues[$clt][$key] = $row;

                                                                                        foreach ($row as $cle => $ligne) {
                                                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                                        $amount_occ = 0;
                                                                                                        $amount_bivac = 0;
                                                                                                        $amount_occ_tva = 0;

                                                                                                        foreach ($ligne as $value) {
                                                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                                        }

                                                                                                        $total_amount_occ += $amount_occ;
                                                                                                        $total_amount_bivac += $amount_bivac;
                                                                                                        $total_amount_occ_tva += $amount_occ_tva;

                                                                                                        $amounts_issues[$clt]['CPO'] = $total_amount_occ;
                                                                                                        $amounts_issues[$clt]['CPB'] = $total_amount_bivac;
                                                                                                        $amounts_issues[$clt]['CTC']  = $total_amount_occ_tva;
                                                                                                }
                                                                                        }
                                                                                }
                                                                        }
                                                                } else {
                                                                        $licenses_issues[$clt][$key]  = $row;

                                                                        foreach ($row as $cle => $ligne) {
                                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                        $amount_occ = 0;
                                                                                        $amount_bivac = 0;
                                                                                        $amount_occ_tva = 0;

                                                                                        foreach ($ligne as $value) {
                                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                        }

                                                                                        $total_amount_occ += $amount_occ;
                                                                                        $total_amount_bivac += $amount_bivac;
                                                                                        $total_amount_occ_tva += $amount_occ_tva;

                                                                                        $amounts_issues[$clt]['CPO'] = $total_amount_occ;
                                                                                        $amounts_issues[$clt]['CPB'] = $total_amount_bivac;
                                                                                        $amounts_issues[$clt]['CTC']  = $total_amount_occ_tva;
                                                                                }
                                                                        }
                                                                }
                                                        }
                                                }
                                        }

                                        if (isset($licenses) && $licenses != "") {
                                                foreach ($licenses as $clt => $line) {
                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;
                                                        $total_occ_tva = 0;

                                                        foreach ($line as $key => $row) {
                                                                foreach ($row as $cle => $ligne) {
                                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                $amount_occ = 0;
                                                                                $amount_bivac = 0;
                                                                                $amount_occ_tva = 0;

                                                                                foreach ($ligne as $value) {
                                                                                        if ($cle == 'CPO') $amount_occ += $value;
                                                                                        if ($cle == 'CPB') $amount_bivac += $value;
                                                                                        if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                }

                                                                                $total_amount_occ += $amount_occ;
                                                                                $total_amount_bivac += $amount_bivac;
                                                                                $total_occ_tva += $amount_occ_tva;

                                                                                $amounts[$clt]['CPO'] = $total_amount_occ;
                                                                                $amounts[$clt]['CPB'] = $total_amount_bivac;
                                                                                $amounts[$clt]['CTC'] = $total_occ_tva;
                                                                        }
                                                                }
                                                        }
                                                }

                                                # Calcul des monatants totaux des frais de la part OCC, BIVAC & TVA de de la part de l'OCC
                                                foreach ($amounts as $aKey => $amount) {
                                                        $missing_amount_exempt = isset($_POST['missing_amount_exempt']) ? $_POST['missing_amount_exempt'] : "";
                                                        $amounts_noprovision = isset($_POST['amounts_noprovision']) ? $_POST['amounts_noprovision'] : [];

                                                        if ((isset($missing_amount_exempt[$aKey]) && $missing_amount_exempt[$aKey] != "") || isset($amounts_noprovision[$aKey]) && $amounts_noprovision[$aKey] != "") {
                                                                $data['customer_account'] = isset($_POST['compte'][$aKey]) ? $_POST['compte'][$aKey] : "";
                                                                $data['account_currency'] = isset($_POST['devise'][$aKey]) ? $_POST['devise'][$aKey] : "";

                                                                foreach ($amount as $keys => $val) {
                                                                        $type = $keys;
                                                                        $data['montant'] = $val;
                                                                        $data['designation'] = isset($_POST['customer_clt'][$aKey]) ? $_POST['customer_clt'][$aKey] : "";

                                                                        if ($type != 'CTC') {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type);
                                                                        } else {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                        }
                                                                }
                                                        } else {
                                                                foreach ($amount as $keys => $val) {
                                                                        $type = $keys;
                                                                        $data['montant'] = $val;
                                                                        $data['designation'] = isset($_POST['customer_clt'][$aKey]) ? $_POST['customer_clt'][$aKey] : "";

                                                                        if ($type != 'CTC') {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $provision_account, $type);
                                                                        } else {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                        }
                                                                }
                                                        }
                                                }

                                                /**
                                                 * A n'est pas supprimé
                                                 */

                                                # Prelevement de la commission et TVA sur la commission
                                                // $instructions_fees = array();

                                                // foreach ($licenses as $clt=>$line)
                                                // {
                                                //         //$data['montant'] = count($line) * 10;
                                                //         $data['montant'] = 10;
                                                //         $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "";
                                                //         $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";
                                                //         $data['designation'] = isset($_POST['customer_clt'][$clt]) ? $_POST['customer_clt'][$clt] : "";

                                                //         $data['montant_tva'] = $data['montant'] * 0.16;

                                                //         $fees_amount = $data['montant'] + $data['montant_tva'];

                                                //         if (isset($_POST['balance'][$clt]))
                                                //         {
                                                //                 $customer_balance = str_replace(' ','',$_POST['balance'][$clt]);
                                                //                 $customer_balance = str_replace(',','.',$customer_balance);

                                                //                 if ($data['account_currency'] == "CDF")
                                                //                 {
                                                //                         $customer_balance = $customer_balance  * $result['Dollar_4'];
                                                //                 }
                                                //                 else if ($data['account_currency'] == 'EUR')
                                                //                 {
                                                //                         $customer_balance = $customer_balance * $result['Dollar_4'];
                                                //                         $customer_balance = $customer_balance / $result['Euro_5'];
                                                //                 }
                                                //         }
                                                //         else
                                                //         {
                                                //                 $customer_balance = 0;
                                                //         }

                                                //         if ($customer_balance > $fees_amount)
                                                //         {
                                                //                 $data['Priority']= 1;
                                                //                 $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                                //                 foreach ($instructions_fees as $instruction)
                                                //                 {
                                                //                         $instructions[$clt][] = $instruction;
                                                //                 }
                                                //         }
                                                //         else
                                                //         {
                                                //                 $data['Priority']= 0;
                                                //                 $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                                //                 foreach ($instructions_fees as $instruction)
                                                //                 {
                                                //                         //$instructions_fees_issues_2[$clt][] = $instruction;
                                                //                         $instructions[$clt][] = $instruction;

                                                //                 }
                                                //         }
                                                // }


                                        }

                                        if (isset($licenses_issues) && $licenses_issues != "") {
                                                # CALCUL DES MONTANTS TOTAUX DES FRAIS OCC-BIVAC PAR CODE IMPORTATEUR
                                                foreach ($amounts_issues as $aKey => $amount) {

                                                        foreach ($amount as $keys => $val) {
                                                                $type = $keys;
                                                                $data['montant'] = $val;
                                                                $data['designation'] = isset($_POST['customer_clt'][$aKey]) ? $_POST['customer_clt'][$aKey] : "";

                                                                $customers_account = isset($_POST['compte'][$aKey]) ? $_POST['compte'][$aKey] : "";
                                                                $account_currency = isset($_POST['devise'][$aKey]) ? $_POST['devise'][$aKey] : "";

                                                                if ($type != 'CTC') {
                                                                        $customers_account = $data['customer_account'] = isset($_POST['compte'][$aKey]) ? $_POST['compte'][$aKey] : "";
                                                                        $account_currency = $data['account_currency'] = isset($_POST['devise'][$aKey]) ? $_POST['devise'][$aKey] : "";

                                                                        if (isset($customers_account) && $customers_account != "" && isset($account_currency)) {
                                                                                $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type);
                                                                        } else {
                                                                                $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $provision_account, $type);
                                                                        }
                                                                } else {
                                                                        $instructions_issues[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                                }
                                                        }
                                                }


                                                /**
                                                 * A n'est pas supprimé
                                                 */
                                                # CALCUL DE PRELEVEMENT DE LA COMMISSION  & TVA SUR LA COMMISSION
                                                // $instructions_fees_issues = array();

                                                // foreach ($licenses_issues as $clt=>$line)
                                                // {
                                                //         $data['montant'] = 10;

                                                //         $data['designation'] = isset($_POST['customer_clt'][$clt]) ? $_POST['customer_clt'][$clt] : "";
                                                //         $data['Priority']= 1;

                                                //         if (isset($customer_account_provision[$clt]) && $customer_account_provision[$clt] !="")
                                                //         {
                                                //                 $data['customer_account'] = $customer_account_provision[$clt];
                                                //                 $data['account_currency'] = isset($customer_account_currency_provision[$clt]) ? $customer_account_currency_provision[$clt] : '';
                                                //         }
                                                //         else if (isset($customer_account_exempted[$clt]) && $customer_account_exempted[$clt] !="")
                                                //         {
                                                //                 $data['customer_account'] = $customer_account_exempted[$clt];
                                                //                 $data['account_currency'] = isset($customer_currency_exempted[$clt]) ? $customer_currency_exempted[$clt] : '';
                                                //         }
                                                //         else
                                                //         {
                                                //                 $data['customer_account'] = isset($_POST['compte'][$clt]) ? $_POST['compte'][$clt] : "";
                                                //                 $data['account_currency'] = isset($_POST['devise'][$clt]) ? $_POST['devise'][$clt] : "";
                                                //         }

                                                //         $instructions_fees_issues  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                                //         foreach ($instructions_fees_issues as $instruction)
                                                //         {
                                                //                 $instructions_issues[$clt][] = $instruction;
                                                //         }
                                                // }
                                        }

                                        $this->data['surplus_amount'] = isset($_POST['surplus_amount']) ? $_POST['surplus_amount'] : [];
                                        $this->data['surplus_amount2'] = isset($_POST['surplus_amount2']) ? $_POST['surplus_amount2'] : [];
                                }

                                $this->data['datas'] = isset($licenses) ? $licenses : "";
                                $this->data['balances'] = isset($_POST['balance']) ? $_POST['balance'] : "";
                                $this->data['customers'] = isset($_POST['customers']) ? $_POST['customers'] : "";
                                $this->data['customer_clt'] = isset($_POST['customer_clt']) ? $_POST['customer_clt'] : "";
                                $this->data['customer_codes'] = isset($_POST['customer_codes']) ? $_POST['customer_codes'] : "";
                                $this->data['licence_issues'] = isset($licenses_issues) ? $licenses_issues : "";
                                $this->data['customer_issues'] = isset($_POST['customer_issues']) ? $_POST['customer_issues'] : "";
                                $this->data['compte_suspens_provision'] = $provision_account;
                                $this->data['invoice_batchId'] = $_POST['invoice_batchId'];
                                $this->data['common_infos'] = $data;
                                $this->data['instructions'] = $instructions;
                                $this->data['instructions2'] = $instructions2;
                                $this->data['instructions_issues'] = $instructions_issues;
                                $this->data['instructions_issues2'] = $instructions_issues2;
                                $this->data['compte_clients'] = $_POST['compte'];
                                $this->data['devise_comptes'] = $_POST['devise'];
                                $this->data['licence_clt'] = $_POST['licence_clt'];
                                $this->data['missing_amount'] = isset($_POST['missing_amount_issues']) ? $_POST['missing_amount_issues'] : "";
                                $this->data['missing_amounts_exempt'] = isset($_POST['missing_amount_exempt']) ? $_POST['missing_amount_exempt'] : [];
                                $this->data['amounts_noprovision'] = isset($_POST['amounts_noprovision'])? $_POST['amounts_noprovision'] : [];
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_step_3', $this->data);
                }
                elseif ($obj == "regularize_invoices_occ")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoice_occ_issues();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "regularize_invoices_start")
                {
                        $this->data['step'] = 0;
                        $this->data['regularizeId'] = $id;
                        $this->data['invoice'] = $this->seguceModel->get_invoices_occ_issues_info($id);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "regularize_invoices_step_2")
                {
                        # Les variables pour les provisions insuffisantes
                        # --------------------------------------------------

                        # Somme totale des montants manquant de chaque licence
                        $total_amount_gap_1 = 0;
                        # Nombre des factures
                        $plicence = 0;
                        # Frais de la banque
                        $fees_1 = 0;

                        # Les quotes-parts a payer pour chaque licence
                        $total_amount_occ = 0;
                        $total_amount_bivac = 0;
                        $total_occ_tva = 0;

                        $amounts = array();
                        $instructions = array();

                        # Les variables pour les provisions non existante
                        # --------------------------------------------------

                        # Somme totale des montants manquant de chaque licence
                        $total_amount_gap_2 = 0;
                        # Nombre des factures avec provision inexistante
                        $noplicence = 0;
                        # Frais de la banque
                        $fees_2 = 0;

                        # Les quotes-parts a payer pour chaque licence
                        $total_amount_occ_2 = 0;
                        $total_amount_bivac_2 = 0;
                        $total_occ_tva_2 = 0;

                        $amounts_2 = array();
                        $instructions_2 = array();

                        # Somme totale des factures a payer
                        $total_invoice_to_pay = 0;
                        $amount_to_paid = 0;

                        # La sommation des quotes-parts a payer pour chaque licence
                        $amount_som = array();
                        # Le tableau des parts qui manquent dans la provision de chaque licence 
                        $amount_gap = array();

                        $data = array();

                        $id = $_POST['regularizeId'];
                        $invoice = $this->seguceModel->get_invoices_occ_issues_info($id);

                        if ($invoice != "") {
                                $licenses = json_decode($invoice->Result_10, true);
                        } else {
                                $licenses = array();
                        }

                        # Generation of transactions based on each licence number
                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        if(isset($comptes['TMB']['CSP']['USD'])){
                             $compte_suspens_provision = $comptes['TMB']['CSP']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CSP']['USD'])){
                             $compte_suspens_provision = $comptes['Rawbank']['CSP']['USD'];
                        }
                        else{
                             $compte_suspens_provision = '000000000000000000000000';
                        }

                        if(isset($comptes['TMB']['CPF']['USD'])){
                             $compte_provision = $comptes['TMB']['CPF']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CPF']['USD'])){
                             $compte_provision = $comptes['Rawbank']['CPF']['USD'];
                        }
                        else{
                             $compte_provision = '000000000000000000000000';
                        }

                        $account_provision = $this->seguceModel->get_dropdown("provision_account");

                        $compte_client = $_POST['Compte'];
                        $devise_compte_client = $_POST['Devise'];

                        $data['designation'] = $invoice->Designation_7;
                        $data['code_import'] = $clt = $invoice->CodeImport_8;
                        $data['num_bordereau'] = $invoice->Numbordereau_9;
                        $data['date_bordereau'] = $invoice->Datebordereau_11;
                        $data['customer_account'] = $_POST['Compte'];
                        $data['currency'] = $data['account_currency'] = $_POST['Devise'];

                        $licence_provision = $this->seguceModel->get_dropdown('licence_provision');

                        if(!empty($_POST['account_balance']))
                        {
                                foreach ($licenses as $key => $license) {
                                        $amount_som[$key] = 0;
                                }

                                foreach ($licenses as $key => $row) {
                                        foreach ($row as $cle => $ligne) {
                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                        foreach ($ligne as $value) {
                                                                $amount_som[$key] += $value;
                                                        }
                                                }
                                        }
                                }

                                foreach ($licenses as $key => $license) {
                                        $license_number = explode('-', $key);
                                        $segment_license = $license_number[0];

                                        if (isset($licence_provision[$key]) && $licence_provision[$key] != "") {
                                                $amount_gap[$key] = 0;
                                        }

                                        if (isset($licence_provision[$segment_license]) && $licence_provision[$segment_license] != "") {
                                                $amount_gap[$segment_license] = 0;
                                        }
                                }

                                $data['compte_provision'] = $compte_provision;
                                $data['devise'] = "USD";

                                foreach ($licenses as $key => $license) {
                                        $license_number = explode('-', $key);
                                        $segment_license = $license_number[0];


                                        if (isset($licence_provision[$key]) && $licence_provision[$key] > 0) {
                                                # Calcul du montant manquant de la provision manquante
                                                if ($licence_provision[$key] > $amount_som[$key]) :
                                                        $amount_gap[$key] = $licence_provision[$key] - $amount_som[$key];
                                                else :
                                                        $amount_gap[$key] = $amount_som[$key] - $licence_provision[$key];
                                                endif;
                                                $total_amount_gap_1 += $amount_gap[$key];

                                                $plicence++;
                                        } elseif (isset($licence_provision[$segment_license]) && $licence_provision[$segment_license] > 0) {
                                                # Calcul du montant manquant de la provision manquante
                                                if ($licence_provision[$segment_license] >  $amount_som[$key]) :
                                                        $amount_gap[$segment_license] = $licence_provision[$segment_license] - $amount_som[$key];
                                                else :
                                                        $amount_gap[$segment_license] = $amount_som[$key] - $licence_provision[$segment_license];
                                                endif;
                                                $total_amount_gap_1 += $amount_gap[$segment_license];

                                                $plicence++;
                                        } else {
                                                # Calcul du montant manquant de la provision inexistante
                                                $amount_gap_2[$key] = $amount_som[$key];
                                                $total_amount_gap_2 += $amount_gap_2[$key];

                                                $noplicence++;
                                        }

                                        $total_invoice_to_pay = $amount_som[$key];
                                }

                                foreach ($licenses as $key => $row) {
                                        $license_number = explode('-', $key);
                                        $segment_license = $license_number[0];

                                        if ((isset($licence_provision[$key]) && $licence_provision[$key] > 0) || (isset($licence_provision[$segment_license]) && $licence_provision[$segment_license] > 0)) {
                                                foreach ($row as $cle => $ligne) {
                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                $amount_occ = 0;
                                                                $amount_bivac = 0;
                                                                $amount_occ_tva = 0;

                                                                foreach ($ligne as $value) {
                                                                        if ($cle == 'CPO') $amount_occ += $value;
                                                                        if ($cle == 'CPB') $amount_bivac += $value;
                                                                        if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                }

                                                                $total_amount_occ += $amount_occ;
                                                                $total_amount_bivac += $amount_bivac;
                                                                $total_occ_tva += $amount_occ_tva;

                                                                $amounts['CPO'] = $total_amount_occ;
                                                                $amounts['CPB'] = $total_amount_bivac;
                                                                $amounts['CTC'] = $total_occ_tva;
                                                        }
                                                }
                                        } else {
                                                foreach ($row as $cle => $ligne) {
                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                $amount_occ = 0;
                                                                $amount_bivac = 0;
                                                                $amount_occ_tva = 0;

                                                                foreach ($ligne as $value) {
                                                                        if ($cle == 'CPO') $amount_occ += $value;
                                                                        if ($cle == 'CPB') $amount_bivac += $value;
                                                                        if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                }

                                                                $total_amount_occ_2 += $amount_occ;
                                                                $total_amount_bivac_2 += $amount_bivac;
                                                                $total_occ_tva_2 += $amount_occ_tva;

                                                                $amounts_2['CPO'] = $total_amount_occ_2;
                                                                $amounts_2['CPB'] = $total_amount_bivac_2;
                                                                $amounts_2['CTC'] = $total_occ_tva_2;
                                                        }
                                                }
                                        }
                                }

                                # Calcul des montants totaux des quotes-parts OCC, BIVAC et TVA de l'OCC pour les provisions insuffisantes
                                $i = 1;
                                foreach ($amounts as $cle => $amount) {
                                        if ($i == 1) {
                                                if (isset($total_amount_gap_1) && $total_amount_gap_1 > 0) {
                                                        $data['montant'] = $total_amount_gap_1;

                                                        $instructions[]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data, $compte_provision);
                                                }
                                        }

                                        $type = $cle;
                                        $data['montant'] = $amount;

                                        if ($type != 'CTC') {
                                                $instructions[] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $compte_provision, $type);
                                        } else {
                                                $instructions[] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                        }

                                        $i++;
                                }

                                # Calcul des montants totaux des quotes-parts OCC, BIVAC et TVA de l'OCC pour les provisions inexistante
                                foreach ($amounts_2 as $cle => $amount) {
                                        $type = $cle;
                                        $data['montant'] = $amount;

                                        if ($type != 'CTC') {
                                                $instructions_2[] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type);
                                        } else {
                                                $instructions_2[] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                        }
                                }

                                /**
                                 * ATTENTION: A N'EST PAS SUPPRIME 
                                 */

                                // #Frais de la banque pour les provisions insuffisantes
                                // if (isset($plicence) && $plicence > 0)
                                // {
                                //         $data['montant'] =  10;
                                //         $data['montant_tva'] = $data['montant'] * 0.16;
                                //         $data['Priority']= 1; 

                                //         $fees_1 = $data['montant'] + $data['montant_tva'];

                                //         $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                //         foreach ($instructions_fees as $instruction)
                                //         {
                                //                 $instructions[] = $instruction;
                                //         }
                                // }

                                // #Frais de la banque pour les provisions inexistantes
                                // if (isset($noplicence) && $noplicence > 0)
                                // {
                                //         $data['montant'] =  10;
                                //         $data['montant_tva'] = $data['montant'] * 0.16;
                                //         $data['Priority']= 1; 

                                //         $fees_2 = $data['montant'] + $data['montant_tva'];

                                //         $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                //         foreach ($instructions_fees as $instruction)
                                //         {
                                //                 $instructions_2[] = $instruction;
                                //         }
                                // }

                                $total_fees = $fees_1 + $fees_2;
                                $total_amount_gap = $total_amount_gap_1 + $total_amount_gap_2;
                                $amount_to_paid = $total_amount_gap + $total_fees;

                                $this->data['invoice_batchId'] = $invoice->BatchId_12;
                                $this->data['num_bordereau'] = $invoice->Numbordereau_9;
                                $this->data['date_bordereau'] = $invoice->Datebordereau_11;
                                $this->data['designation'] = $invoice->Designation_7;
                                $this->data['code_import'] = $invoice->CodeImport_8;
                                $this->data['compte_provision'] = $compte_provision;
                                $this->data['total_amount_gap'] = $total_amount_gap;
                                $this->data['total_amount_gap_1'] = $total_amount_gap_1;
                                $this->data['total_amount_gap_2'] = $total_amount_gap_2;
                                $this->data['common_infos'] = $data;
                                $this->data['amount_to_paid'] = $amount_to_paid;
                                $this->data['amount_gap'] = $amount_gap;
                                $this->data['total_invoice_to_pay'] = $total_invoice_to_pay;
                                $this->data['instructions'] = $instructions;
                                $this->data['instructions_2'] = $instructions_2;
                                $this->data['customer_account'] = $_POST['Compte'];
                                $this->data['account_currency'] = $_POST['Devise'];
                                $this->data['invoice_regulId'] = $_POST['regularizeId'];
                                $this->data['datas'] = $licenses;
                                $this->data['account_balance'] = $_POST['account_balance'];
                        }
                        else{
                                # La sommation des quotes-parts a payer pour chaque licence
                                $amount_som = array();
                                # Le tableau des parts qui manquent dans la provision de chaque licence 
                                $amount_gap = array();

                                foreach ($licenses as $key => $license)
                                {
                                        $amount_som[$key] = 0;
                                }
                                foreach ($licenses as $key => $row)
                                {
                                        foreach($row as $cle=>$ligne)
                                        {
                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                {
                                                        foreach($ligne as $value)
                                                        {
                                                                $amount_som[$key] += $value;
                                                        }
                                                }
                                        }
                                }

                                foreach ($licenses as $key => $license)
                                {
                                        $amount_gap[$key] = 0;
                                }

                                foreach ($licenses as $key => $license)
                                {
                                        $compte_provision = isset($account_provision[$key]) ? $account_provision[$key] : '00000000000000000000000';
                                }

                                $data['compte_provision'] = $compte_provision;
                                $data['devise'] = "USD";

                                # Somme totale des montants manquant dans la provision de chaque licence
                                $total_amount_gap = 0;

                                # Somme totale de la provision a extourner dans le compte du client
                                $amount_to_extourne = 0;

                                # Somme totale des factures a payer
                                $total_invoice_to_pay = 0;
                                $amount_to_paid = 0;

                                foreach ($licenses as $key => $license)
                                {
                                        if(isset($licence_provision[$key]))
                                        {
                                                $amount_gap[$key] = $amount_som[$key] - $licence_provision[$key];
                                                $total_amount_gap = $total_amount_gap + $amount_gap[$key];
                                                $amount_to_extourne = $amount_to_extourne + $licence_provision[$key];

                                                //$amount_to_paid = $licence_provision[$key] + $customer_balance;
                                        }
                                        else
                                        {
                                                $amount_gap[$key] = $amount_som[$key];
                                                $total_amount_gap = $total_amount_gap + $amount_gap[$key];
                                        }

                                        $total_invoice_to_pay = $amount_som[$key];
                                }

                                $instructions = array();
                                #$instructions_regul = array();
                                $data['montant'] = $amount_to_extourne;

                                if(!empty($licenses))
                                {
                                        $total_amount_licence = 0;
                                        $amount = array();

                                        # Calcul du montant total de chaque licence avec provision suffisante
                                        foreach ($licenses as $key=>$row)
                                        {
                                                $total_amount_licence = 0;

                                                foreach($row as $cle=>$ligne)
                                                {
                                                        if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                        {
                                                                $amount_recipe = 0;

                                                                foreach ($ligne as $value)
                                                                {
                                                                        $amount_recipe = $amount_recipe + $value;
                                                                }
                                                                $total_amount_licence = $total_amount_licence + $amount_recipe;

                                                        }
                                                }
                                                $amount[$key] = $total_amount_licence;
                                        }
                                }

                                $comm_occ = 0;
                                $comm_bivac = 0;
                                $amount_occ = 0;
                                $amount_bivac = 0;

                                foreach ($licenses as $key=>$lines)
                                {
                                        $data['montant'] = $amount[$key];
                                        $data['licence'] = $key;
                                        $data['designation'] = $invoice->Designation_7;

                                        $instructions[$key][] = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_regul1($data, $comptes, $compte_provision, $compte_client);

                                        $data['customer_account'] = $_POST['Compte'];
                                        $data['account_currency'] = $_POST['Devise'];

                                        foreach ($lines as $cle=>$row)
                                        {
                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                {
                                                        $amount_recipe = 0;

                                                        foreach ($row as $ligne)
                                                        {
                                                                if ($cle == 'CPO')
                                                                {
                                                                        $amount_occ = $ligne;
                                                                        $comm_occ = ($amount_occ * 0.232)/100;
                                                                        $tva_occ = $comm_occ * 0.16;

                                                                        $amount_recipe = $amount_occ - ($comm_occ + $tva_occ);
                                                                }
                                                                elseif ($cle == 'CPB')
                                                                {
                                                                        $amount_bivac = $ligne;
                                                                        $comm_bivac = ($amount_bivac * 0.116)/100;
                                                                        $tva_bivac = $comm_bivac * 0.16;

                                                                        $amount_recipe = $amount_bivac - ($comm_bivac + $tva_bivac);
                                                                }
                                                                else
                                                                {
                                                                        $amount_recipe = $ligne;
                                                                }

                                                        }

                                                        $amounts[$key]['CPO'] = $amount_occ;
                                                        $amounts[$key]['CPB'] = $amount_bivac;

                                                        $data['montant'] = $this->data('get_reduce_decimal', $amount_recipe , 2);

                                                        $data['licence'] = $key;
                                                        $type = $cle;
                                                        $data['designation'] = $invoice->Designation_7;
                                                        $instructions[$key][] = $this->seguceModel->get_instructions_seguce_by_licence_number1($data, $comptes, $compte_suspens_provision, $type);
                                                }
                                        }
                                }

                                $total_amount_occ = 0;
                                $total_amount_bivac = 0;

                                foreach($amounts as $aKey => $aVal)
                                {
                                        foreach ($aVal as $cle => $value)
                                        {
                                                if ($cle == 'CPO') $total_amount_occ += $value;
                                                if ($cle == 'CPB') $total_amount_bivac += $value;
                                        }
                                }

                                #Calcul de commission OCC & BIVAC
                                $com_occ = $this->data("get_occ_bivac_commission", "OCC",  $total_amount_occ);
                                $com_bivac = $this->data("get_occ_bivac_commission", "BIVAC", $total_amount_bivac);

                                $data['amount_comm'] = $com_occ + $com_bivac;
                                $data['amount_tva'] = $data['amount_comm'] * 0.16;

                                $data['amount_comm'] = $this->data('get_reduce_decimal', $data['amount_comm'] , 2);
                                $data['amount_tva'] = $this->data('get_reduce_decimal', $data['amount_tva'] , 2);

                                $instructions2 = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_fb1($data, $comptes);

                                $this->data['invoice_batchId'] = $invoice->BatchId_12;
                                $this->data['num_bordereau'] = $invoice->Numbordereau_9;
                                $this->data['date_bordereau'] = $invoice->Datebordereau_11;
                                $this->data['designation'] = $invoice->Designation_7;
                                $this->data['code_import'] = $invoice->CodeImport_8;
                                $this->data['compte_provision'] = $compte_provision;
                                $this->data['total_amount_gap'] = $total_amount_gap;
                                $this->data['common_infos'] = $data;
                                $this->data['amount_gap'] = $amount_gap;
                                $this->data['amount_to_extourne'] = $amount_to_extourne;
                                $this->data['total_invoice_to_pay'] = $total_invoice_to_pay;
                                $this->data['instructions'] = $instructions;
                                $this->data['instructions2'] = $instructions2;
                                #$this->data['instructions_regul'] = $instructions_regul;
                                $this->data['customer_account'] = $_POST['Compte'];
                                $this->data['account_currency'] = $_POST['Devise'];
                                $this->data['invoice_regulId'] = $_POST['regularizeId'];
                                $this->data['datas'] = $licenses;
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "preview_regularized_invoice")
                {
                        $this->data['invoice'] = $invoices = $this->seguceModel->get_invoices_occ_regularized($id);

                        $instructions = array();
                        $instructions_regul = array();
                        $amount_gap_tab = array();
                        $total_amount_gap = 0;

                        foreach ($invoices as $row) {
                                $return = $this->seguceModel->get_instructions_invoices_occ_regul($row->Regulid_18);

                                $instructions_regul = json_decode(json_encode($return), true);

                                $return = $this->seguceModel->get_instructions_invoices_occ($row->Id_0);
                                $return = json_decode(json_encode($return), true);

                                $instructions[$row->Licence_8] = $return;

                                $total_amount_gap = $total_amount_gap + $row->Amountgap_21;

                                $amount_gap_tab[$row->Licence_8] = $row->Amountgap_21;
                        }

                        $invoice = current($invoices);

                        $this->data['instructions'] = $instructions;
                        $this->data['instructions_regul'] = $instructions_regul;

                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                        $compte_provision = isset($comptes['TMB']['CSP']['USD']) ? $comptes['TMB']['CSP']['USD'] : '00000000000000000000000';

                        $this->data['num_bordereau'] = $invoice->Numbordereau_14;
                        $this->data['designation'] = $invoice->Designation_13;
                        $this->data['code_import'] = $invoice->Codeimport_12;
                        $this->data['compte_provision'] = $compte_provision;
                        $this->data['total_amount_gap'] = $total_amount_gap;
                        $this->data['amount_gap_tab'] = $amount_gap_tab;
                        $this->data['instructions'] = $instructions;
                        $this->data['instructions_regul'] = $instructions_regul;
                        $this->data['customer_account'] = $invoice->Compte_19;
                        $this->data['account_currency'] = $invoice->Devise_20;
                        $this->data['invoice_regulId'] = $invoice->Regulid_18;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "treat_invoices_regul")
                {
                        $id = $_POST['invoice_regulId'];

                        # Retrieve the exchange rate
                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                $taux = $result['Dollar_4'];
                        }
                        else {
                                $taux = 1;
                        }

                        $result = array();
                        $datas  = array();

                        if(isset($_POST['account_balance']) && $_POST['account_balance'] != "")
                        {
                                if (isset($_POST['account_currency']) && $_POST['account_currency'] == 'CDF')
                                {
                                        $account_balance = $_POST['account_balance'] / $taux;
                                }
                                else
                                {
                                        $account_balance = $_POST['account_balance'];
                                }

                                $partial_validation = false;

                                if ($account_balance >= $_POST['amount_to_paid'])
                                {
                                        $balance_code = "200";
                                        $balance = $account_balance;
                                }
                                else
                                {
                                        $datas = json_decode($_POST['datas'], true);

                                        foreach ($datas as $row)
                                        {
                                                $amount_occ = current($row['CPO']);
                                        }

                                        $balance_code = "300";
                                        $balance = $account_balance;

                                        //$retour = $this->save("partial_regularisation");
                                }

                                $result['partial_validation'] = $partial_validation;
                        }
                        else{
                                $data['bank_account'] = $_POST['customer_account'];
                                $data['devise_account'] = $_POST['account_currency'];
                                $data['amount'] = $_POST['total_invoice_to_pay'];

                                $core_banking = strtolower($this->core_banking);
                                $response = $this->{$core_banking}->check_balance($data);

                                if($response['code'] == 200)
                                {
                                        if ($data['devise_account'] == 'CDF')
                                        {
                                                $customer_balance = $response['balance'] / $taux;
                                        }
                                        else
                                        {
                                                $customer_balance = $response['balance'];
                                        }

                                        if($customer_balance >= $_POST['total_invoice_to_pay'])
                                        {
                                                $balance_code = "200";
                                        }
                                        else
                                        {
                                                $balance_code = "300";
                                        }

                                        $balance = $customer_balance;
                                }
                                else
                                {
                                        $balance_code = $response['code'];
                                        $balance = 0;
                                }
                        }

                        $result['code'] = "E200";
                        $result['balance_code'] = $balance_code;
                        $result['balance'] = $balance;

                        echo json_encode($result);
                }
                elseif ($obj == "partial_validation") 
                {
                        $id = $_POST['invoice_regulId'];

                        $invoiceid = $this->seguceModel->get_invoice_occ_by_regul_id($id);

                        $ids = array();

                        foreach ($invoiceid as $row) {
                                $ids[] = $row->Id_0;
                        }

                        $ids = implode(",", $ids);

                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['invoiceids'] = $ids;
                        $data['Designation'] = $_POST['designation'];
                        $data['invoice_regulId'] = $_POST['invoice_regulId'];

                        //$response = $this->amplitude->call_bank_invoice_partial_integration($data);

                        $response = json_encode([]);
                        $return = json_decode($response, true);

                        if (isset($return['response']) && $return['response'] == '200') {
                                $this->data['invoice'] = $invoices = $this->seguceModel->get_invoices_occ_regularized($id);

                                foreach ($invoices as $row) {
                                        $return = $this->seguceModel->get_instructions_invoices_occ($row->Id_0);
                                        $return = json_decode(json_encode($return), true);

                                        $instructions[$row->Licence_8] = $return;


                                        $amount_gap_tab[$row->Licence_8] = $row->Amountgap_21;
                                }

                                $this->data['instructions'] = $instructions;
                                $this->data['amount_gap_tab'] = $amount_gap_tab;

                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\__regularize_invoices', $this->data);
                        } else {
                                echo '411';
                        }
                }
                elseif ($obj == "treat_partial_regul")
                {
                        $regul_id = $_POST['invoice_regulId'];
                        $invoices = $this->seguceModel->get_invoices_occ_regularized($regul_id);
                        $total_amount_to_pay = 0;

                        foreach ($invoices as $row) {
                                $return = $this->seguceModel->get_instructions_invoices_occ_not_integrated($row->Id_0);

                                foreach ($return as $line) {
                                        if ($line->Type_26 != "") {
                                                $total_amount_to_pay = $total_amount_to_pay + $line->Montant_10;
                                        }
                                }
                        }

                        # Verify balance
                        $data['bank_account'] = $_POST['customer_account'];
                        $data['devise_account'] = $_POST['account_currency'];
                        $data['amount'] = $total_amount_to_pay;

                        $core_banking = strtolower($this->core_banking);
                        $response = $this->{$core_banking}->check_balance($data);

                        if ($response['code'] == 200) {
                                echo "E200";
                        }
                        elseif ($response['code'] == 300) {
                                echo "E300";
                        }
                }
                elseif ($obj == "approvisionnement_regul_verify")
                {
                        $id = $_POST['invoice_regulId'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['invoice_id'] = $id;

                        //$response = $this->curl_model->call_bank_regularize_invoice($data);
                        //$return = json_decode($response, true);

                        $return['response'] = "200";

                        if (isset($return['response']) && $return['response'] == '200') {
                                $result['code'] = 'E200';
                                $result['id'] = $id;
                                echo json_encode($result);
                        } elseif (isset($return['code'])) {
                                $result['code'] = $return['code'];
                                echo json_encode($result);
                        } else {
                                $result['code'] = 'E300';
                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "approvisionne")
                {
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_step_3', $this->data);
                }
                elseif ($obj == "provision")
                {
                        //$this->data['categories'] = $this->licenceModel->get_dropdown("categories","provision");
                        $this->data['categories'] = $this->licenceModel->categories;
                        $this->data['merchandises'] = $this->licenceModel->merchandises;

                        if ($id != "")
                        {
                                $this->data['provision'] = $provision = $this->seguceModel->get_provision_info($id);

                                if (preg_match('/^EB/', $provision->CodeType_38))
                                {
                                        $this->data['sub_categories'] = $this->licenceModel->get_dropdown('licence_eb');
                                }
                                elseif (preg_match('/^IB/', $provision->CodeType_38))
                                {
                                        $this->data['sub_categories'] = $this->licenceModel->get_dropdown('licence_ib');
                                }
                                else
                                {
                                        $this->data['sub_categories'] = array();
                                }

                                if (isset($provision->Compte_21) && $provision->Compte_21 != "") {
                                        $account_customer = trim($provision->Compte_21);
                                        $account_without_branch = preg_replace('/^\d{3}-/', '', $account_customer);
                                        $provision->Compte_21 = $account_without_branch;
                                }

                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        }
                        else
                        {
                                $this->data['provision'] = $this->seguceModel->get_provision_info($id);
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        }
                }
                elseif ($obj == "provision_batch")
                {
                        $this->data['step'] = 0;
                        $this->data['invoices'] = $this->seguceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_provision_batch_start', $this->data);
                } 
                elseif ($obj == "provision_batch_step_2") 
                {
                        ini_set('memory_limit', '8192M');
                        #$this->load->library('Excel');
                        #$objPHPExcel = new Excel();
                        $file = $_FILES['file']['tmp_name'];
                        $file_extension = strtolower(substr(strrchr($_FILES['file']['name'], '.'), 1));
                        $valid_extensions = array('xlsx', 'xls');

                        /*$path = '/ikwook_files/invoices_occ/';
                        require_once APPPATH . "/third_party/PHPExcel.php";
                        $config['upload_path'] = $path;
                        $config['allowed_types'] = 'xlsx|xls';
                        $config['remove_spaces'] = TRUE;
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);

                        if (!$this->upload->do_upload('license')):
                                $error = array('error' => $this->upload->display_errors());
                        else:
                                $datas = array('upload_data' => $this->upload->data());
                        endif;

                        $inputFileName = $path . $this->upload->data('file_name');*/

                        $provisions = array();
                        $tables = array();
                        $common_infos = new \stdClass();

                        if (empty($file)) {
                                echo 'E201';
                                die;
                        }

                        if (!in_array($file_extension, $valid_extensions)) {
                                echo 'E202';
                                die;
                        }

                        $handle = fopen($file, "r");
                        if ($handle == false) {
                                echo 'E201';
                        } else {
                                $sheet = IOFactory::createReaderForFile($file);
                                $sheet->setReadDataOnly(true);
                                $objPHPExcel = $sheet->load($file);
                                $objWorksheet = $objPHPExcel->getActiveSheet();
                                $lines = $objWorksheet->toArray(null, true, true, true);

                                $account_id = $this->session->userdata['account_id'];
                                $ref = date('H') . date('i') . date('s') . date('m') . date('j') . date('Y');
                                $target_dir = "./drive/logiref/" . $account_id . "/" . date('Y-m') . '/invoices/provision/' . $ref;
                                if (is_dir($target_dir) == false) {
                                        mkdir($target_dir, 0777, true);
                                }

                                $target_file = $target_dir . basename($_FILES["license"]["name"]);
                                $target_file = str_replace(" ", "", $target_file);
                                if (move_uploaded_file($file, $target_file)) {
                                        $this->data['path_file'] = $target_file;
                                }

                                if (!empty($lines)) {
                                        $t = 1;
                                        foreach ($lines as $worksheet) {
                                                if ($t > 1) {
                                                        $provisions[] = $worksheet;
                                                }

                                                $t++;
                                        }

                                        foreach ($provisions as $sheet) {
                                                if ($sheet['B'] != "" && $sheet['D'] != "" && $sheet['E'] != "") {

                                                        $provisions = new \stdClass();

                                                        if (is_numeric($sheet['B'])) {
                                                                $date_av_converted = ($sheet['B'] - 25569) * 86400;
                                                                $provisions->dates_operation =  gmdate("Y-m-d", $date_av_converted);
                                                        }

                                                        $provisions->reference = $sheet['C'];
                                                        $provisions->montant_prov = $sheet['D'];
                                                        $provisions->montant_prov = str_replace(' ', '', $provisions->montant_prov);
                                                        $provisions->montant_prov = str_replace(',', '.', $provisions->montant_prov);

                                                        $provisions->licence = $sheet['E'];
                                                        $provisions->nom_importateur = $sheet['F'];

                                                        $tables[] = $provisions;
                                                }
                                        }

                                        unset($tables[0]);

                                        $this->data['provisions'] = $tables;

                                        $this->data['step'] = 1;

                                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_provision_batch_step_2', $this->data);
                                }
                        }
                }
                elseif ($obj == "invoices_occ_preview")
                {
                        $item = $arg;

                        $this->data['invoice'] = $invoices = $this->seguceModel->get_invoice_occ_by_id($id);

                        if ($item == "nvalidated")
                        {
                                $this->data['instructions'] = $this->seguceModel->get_instructions_invoices_occ($id);
                        }
                        elseif ($item == "validated")
                        {
                                $this->data['instructions'] = $this->seguceModel->get_instructions_invoices_occ_integrated($id);
                        }
                        elseif ($item == "regularized")
                        {
                                $this->data['instructions'] = $this->seguceModel->get_instructions_invoices_occ_regularized($id);
                        }
                        elseif ($item == "regul_manual")
                        {
                                $this->data['instructions'] = $this->seguceModel->get_instructions_invoices_occ_regul_manual($id);
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_preview', $this->data);
                }
                elseif ($obj == "invoices_batchs_preview")
                {
                        $this->data['invoice'] = $invoices = $this->seguceModel->get_invoice_batch_by_id($id);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_batch_preview', $this->data);
                }
                elseif ($obj == "traitement")
                {
                        $refbfu = isset($_GET['reference']) ? $_GET['reference'] : "";
                        $this->data['refbfu'] =  $refbfu;
                        $invoices = $this->data['invoices'] = $this->seguceModel->get_invoices_by_reference_bfu($refbfu);

                        $internal_ref = ($this->data['invoices'][0]->Reference_7);
                        $number_declaration = explode('/', $internal_ref);

                        if (isset($number_declaration[3]) && $number_declaration[3] != "") {
                                $number_dec = $number_declaration[3];
                        }
                        else {
                                $number_dec = strstr($this->data['invoices'][0]->Reference_7, 'DEC');
                        }

                        $type_invoice = [];

                        foreach ($invoices as $invoice) {
                                $type_invoice[] = $invoice->Typefacture_23;
                        }

                        $this->data['type_invoices'] = $type_invoice;

                        if (in_array("INVDIB", $type_invoice))
                        {
                                $this->data['invoice_bank'] = true;

                                $this->data['provision'] = $this->seguceModel->get_provision_by_licence($number_dec);
                        }
                        else
                        {
                                $this->data['invoice_bank'] = false;
                        }

                        //$this->data['provision'] = $this->seguce_model->get_provision_info($id);

                        $this->data['number_dec'] = isset($number_dec) ? $number_dec : "";

                        $this->data['object_info'] = isset($this->data['invoices'][0]) ? $this->data['invoices'][0] : "";

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_1', $this->data);
                }
                elseif ($obj == "traitement-via-api")
                {
                        $this->seguceAPI=new Seguce();

                        $invoice=null;
                        $ref = isset($_POST['numero_facture']) ? $_POST['numero_facture'] : "";
                       
                        $invoice = $this->seguceModel->get_invoice_by_reference($ref);

                        if($invoice!=NULL)
                        {
                                if($invoice->Status_2==3)
                                {
                                        return "2";
                                }
                                elseif($invoice->Status_2==2)
                                {
                                        return "3";
                                }
                                else
                                {
                                        $this->data['invoice']= $invoice;
                                }   
                        }
                        else
                        {       
                                $postdata['ID']      = $ref;
                                $postdata['Account'] = $this->session->userdata['account_id'] ?? "";
                                
                                $seguceAPI = $this->curl(base_url('services/seguce/invoiceQuery'),'POST',$postdata);
                   	 

                                //$seguceAPI = $this->curl(base_url('services/seguce/invoiceQuerySimulation'),'POST',$postdata);
                    

                                $response = json_decode($seguceAPI,true);
                            
                                if(isset($response['code']) && $response['code']==200)
                                {
                                        $invoice_data = $response['data'];
                                        $account=isset($this->session->userdata['account_id'])?$this->session->userdata['account_id']:"";
                                        
                                        $invoice=$this->seguceModel->transform_invoice_data($invoice_data,$account);
                                     
                                        $this->data['invoice'] =  $invoice;
                                }
                                else
                                {
                                        if(isset($response['code']) && $response['code']==201)
                                        {
                                                return "2";
                                        }
                                        else
                                        {
                                                return "0";
                                        }
                                }

                        }
 
                        $number_dec=isset($invoice->Reference_7)?$invoice->Reference_7:"";
                       
                        $this->data['number_dec'] = $number_dec;

                        $this->data['object_info'] = $invoice;

                        $this->data['invoice_bank'] = false;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_step_1', $this->data);
                }
                elseif ($obj == "filter_invoice")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoices_filter($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "filter_batch_invoice") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_unvalidated_invoices_batch($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif ($obj == "edit") 
                {
                        $bl = $id;

                        $facture = $this->seguceModel->get_invoice_by_id($id);
                        $encaissement = $this->dataModel->get_seguce_migrate_invoice($id);

                        $type = $facture->Typefacture_23;

                        $object = json_encode($encaissement);
                        $data = json_decode($object, true);

                        $taux = json_decode($this->session->get('Bank_rates'), true);

                        $_POST['taux'] = isset($taux['Dollar_4']) ? $taux['Dollar_4'] : "";

                        switch ($type) {
                                case "GUICE":

                                        $fraisb = 0;
                                        $data['Montant_11'] = ($_POST['taux'] * $data['Notemontant_28']);
                                        $amount_acb = $data['frais_acb'] = 0;
                                        $data['Commission_23'] = $data['total_frais'] =  ($fraisb * $_POST['taux']);
                                        $data['frais_tva'] = (($fraisb * 16) / 100) * $_POST['taux'];
                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                        break;
                                case "GUICELOG":

                                        $fraisb = 12.93;
                                        $data['Montant_11'] = ($_POST['taux'] * $data['Notemontant_28']);
                                        $amount_acb = $data['frais_acb'] = (5  * $_POST['taux']);
                                        $data['Commission_23'] = $data['total_frais'] = ($fraisb * $_POST['taux']);
                                        $data['frais_tva'] = (($fraisb * 16) / 100) * $_POST['taux'];
                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                        break;
                                case "INVDIB":

                                        $fraisb = ($_POST['taux'] * $data['Notemontant_28']);
                                        $data['Montant_11'] = 0;
                                        $amount_acb = $data['frais_acb'] = 0;
                                        $data['Commission_23'] = $data['total_frais'] = $fraisb;
                                        $data['frais_tva'] = (($fraisb * 16) / 100);
                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                        break;
                                case "NP":

                                        // Selon les paliers des taux
                                        $fraisb = (10 * $_POST['taux']);
                                        $data['Montant_11'] = ($_POST['taux'] * $data['Notemontant_28']);
                                        $amount_acb = $data['frais_acb'] = 0;
                                        $data['Commission_23'] = $data['total_frais'] = $fraisb;
                                        $data['frais_tva'] = ($fraisb * 16) / 100;
                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                        break;
                                default:
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }


                        if ($data['Compte_33'] == "") {
                                $data['Compte_33'] = "05101-70599999504-49";
                        }

                        if ($data['Commission_23'] == "0") {
                                $data['Commission_23'] = "80000";
                        }


                        $agence_src = $this->session->get('Logiref_guichet');

                        $case = $this->comptabilisationModel->get_use_case($data);
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        switch ($case) {
                                case "case_1":
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_1($data, $comptes, "DGDA");
                                        break;
                                case "case_2":
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_2($data, $comptes, "SEGUCE");
                                        break;
                                case "case_3":
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_3($data, $comptes, "DGDA");
                                        break;
                                case "case_4":
                                        $instructions1 = $this->comptabilisationModel->get_instructions_case_4($data, $comptes, "DGDA");
                                        break;
                                default:
                                        //$instructions = $this->comptabilisation_model->get_instructions_case_1($data, $comptes,"DGDA");
                                        break;
                        }

                        $info = $encaissement->Notereference_30;

                        $guichet = $this->session->userdata['Logiref_guichet'];
                        $compte_cpt = isset($comptes['TMB']['CSO'][$data['Devise_12']]) ? $comptes['TMB']['CSO'][$data['Devise_12']] : '00000000000000000000000';
                        $compte_csg = isset($comptes['SEGUICE']['CSG'][$data['Devise_12']]) ? $comptes['SEGUICE']['CSG'][$data['Devise_12']] : '00000000000000000000000';

                        #Taxes comptes
                        $comptes = array();
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $instructions2 = array();

                        $comptes = $this->accountsModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);

                        $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                        $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                        $taxes = array();
                        $taxes = $info['taxesPaid'];

                        foreach ($taxes as $taxe) {
                                $data['Typerecette_17'] = $taxe->Code;
                                $data['Montant_11'] = $taxe->NetAmount;
                                $instruction = $this->comptabilisationModel->get_instructions_seguce($data, $comptes, $compte_cpt, $compte_csg, "TRESOR");
                                $instructions2[] = $instruction;
                        }

                        $this->data['instructions'] = array_merge($instructions1, $instructions2);
                        $this->data['encaissement'] = $encaissement;
                        $this->data['facture'] = $facture;

                        $this->data['comptes'] = $comptes;
                        $this->data['compte_csg'] = $compte_csg;
                        $this->data['compte_cso'] = $compte_cpt;
                        $this->data['mode'] = $this->request->getGet('mode');
                        $this->data['cCompte'] = $this->request->getGet('compte');
                        $this->data['cDevise'] = $this->request->getGet('devise');
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['typeRecette'] = $this->logirefModel->get_dropdown("type_recette");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\invoice', $this->data);
                } 
                elseif ($obj == "reservation") 
                {
                        //$_POST['designation'] = $_POST['$_POST['designation']'];

                        $agence = $this->session->get('Logiref_guichet');
                        $ref = $agence . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        //Enrgistrement d'ecriture : dÃ©bit compte PS et crÃ©dit compte guichet unique.
                        $id = $this->save('reservation', $ref);

                        // Debit compte prepaiement et crÃ©dit guichet unique

                        $data['Seguce_53'] = $id;
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] =  $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Priority'] = 0;

                        //$response = $this->amplitude->call_seguce_invoice_reservation($data);

                        $response = json_encode([]);
                        $return = json_decode($response, true);

                        //$return['response']='200';

                        if ($return['response'] == '200') {
                                $result['code'] = 'E200';

                                $result['id'] = $id;

                                $result['reference'] = $ref;

                                $traitement_data = array();
                                $traitement_data['Status_2'] = 1;
                                $tid = $this->seguceModel->update_traitement_by_lot($traitement_data, $id);
                                if ($tid > 0) {
                                        echo json_encode($result);
                                }
                        } elseif ($return['response'] == '301') {
                                $result['code'] = 'E301';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];

                                echo json_encode($result);
                        } elseif ($return['response'] == '302') {
                                $result['code'] = 'E302';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];

                                echo json_encode($result);
                        } elseif ($return['response'] == '303') {
                                $result['code'] = 'E303';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];

                                echo json_encode($result);
                        } elseif ($return['response'] == '304') {
                                $result['code'] = 'E304';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];


                                echo json_encode($result);
                        } elseif ($return['response'] == '305') {
                                $result['code'] = 'E305';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];

                                echo json_encode($result);
                        } elseif ($return['response'] == '306') {
                                $result['code'] = 'E306';

                                $result['reference'] = $ref;

                                $result['id'] = $id;

                                $result['transaction_id'] = $return['transaction_id'];

                                echo json_encode($result);
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_1_details', $this->data);
                } 
                elseif ($obj == "preview") 
                {
                        $facture = $this->seguceModel->get_invoice_by_id($id);
                        $encaissement = $this->dataModel->get_seguce_migrate_invoice($id);

                        $this->ratesModel->get_exchange_rates();
                        $this->data['facture'] = $facture;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] != "") ? $_GET['controller'] : '';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] != "") ? $_GET['view'] : '';
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_seguice($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        $this->data['encaissement'] = $encaissement;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_3', $this->data);
                }
                elseif ($obj=="preview_invoice")
                {
                        $facture = $this->seguceModel->get_invoice_by_id($id);

                        $this->ratesModel->get_exchange_rates();
                        $this->data['facture'] = $facture;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] != "") ? $_GET['controller'] : '';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] != "") ? $_GET['view'] : '';
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_seguice($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_step_3', $this->data);
                }
                elseif ($obj == "preview_occ")
                {
                        $data_codeimport = array();
                        $fees_instructions = [];

                        $batch_id = $id;
                        $instructions = $this->seguceModel->get_instructions_invoices_occ_by_batchid($batch_id);

                        if (!empty($instructions))
                        {
                                foreach($instructions as $row)
                                {
                                        if (isset($row->Codeimport_28) && strpos($row->Codeimport_28, 'CLT') === 0)
                                        {
                                                $fees_instructions[$row->Codeimport_28][] = $row;
                                        }

                                        if (!in_array($row->Codeimport_28, $data_codeimport))
                                        {
                                                $data_codeimport[] = $row->Codeimport_28;
                                        }
                                }
                        }

                        $invoices = $this->seguceModel->get_invoices_occ_by_batch_id($batch_id, "ALL");

                        $this->data['batch_id'] = $batch_id;
                        $this->data['code_imports'] = $data_codeimport;
                        $this->data['instructions'] = $instructions;
                        $this->data['fees_instructions'] = $fees_instructions;
                        $this->data['invoices'] = $this->seguceModel->get_invoices_occ_by_batch_id($batch_id);

                        $this->data['count_invoices'] = count($invoices);
                        $this->data['batch'] = $this->seguceModel->get_invoices_occ_batchs_info($batch_id);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_occ_step_4', $this->data);
                }
                elseif ($obj == "preview_license")
                {
                        $data = array();
                        $instructions = array();

                        $invoice = $this->seguceModel->get_invoices_occ_info($id);
                        $result = $invoice->Result_11;

                        $licence = json_decode($result, true);

                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                        $compte_provision = isset($invoice->Compte_16) ? $invoice->Compte_16 : '000000000000000000000000';
                        $compte_provision_devise = isset($invoice->Devise_17) ? $invoice->Devise_17 : '';
                        $compte_client = isset($invoice->Compte_19) ? $invoice->Compte_19 : '000000000000000000000000';
                        $compte_client_devise = isset($invoice->Devise_20) ? $invoice->Devise_20 : '';
                        $designation = isset($invoice->Designation_13) ? $invoice->Designation_13 : "";
                        $num_bordereau = isset($invoice->Numbordereau_14) ? $invoice->Numbordereau_14 : "";

                        foreach ($licence as $key => $row) {

                                if ($key == $invoice->Licence_8) {
                                        foreach ($row as $cle => $ligne) {
                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                        $amount_recipe = 0;

                                                        foreach ($ligne as $value) {
                                                                if ($cle == 'CPO') $amount_recipe += $value;
                                                                if ($cle == 'CPB') $amount_recipe += $value;
                                                                if ($cle == 'CTC') $amount_recipe += $value;
                                                        }

                                                        $type = $cle;
                                                        $data['montant'] = $amount_recipe;
                                                        $data['designation'] = $designation;
                                                        $data['num_bordereau'] = $num_bordereau;
                                                        $data['devise'] = "USD";

                                                        if ($type != "CTC") {
                                                                $instructions[] = $this->seguceModel->get_instructions_seguce_by_licence_number($data, $comptes, $compte_provision, $type);
                                                        } else {
                                                                $instructions[] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data, $comptes);
                                                        }
                                                }
                                        }

                                        $data['montant'] = 10;
                                        $data['customer_account'] = $compte_client;
                                        $data['account_currency'] = $compte_client_devise;
                                        $data['Priority'] = '1';

                                        $instructions_fees  = $this->seguceModel->get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes);

                                        foreach ($instructions_fees as $instruction) {
                                                $instructions[] = $instruction;
                                        }
                                }
                        }

                        $this->data['invoice'] = $invoice;
                        $this->data['num_bordereau'] = $invoice->Numbordereau_14;
                        $this->data['designation'] = $invoice->Designation_13;
                        $this->data['code_import'] = $invoice->Codeimport_12;
                        $this->data['compte_provision'] = $compte_provision;
                        $this->data['instructions'] = $instructions;
                        $this->data['customer_account'] = $invoice->Compte_19;
                        $this->data['account_currency'] = $invoice->Devise_20;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif ($obj == "unvalidated_invoices") 
                {
                        $refbfu = isset($_GET['reference']) ? $_GET['reference'] : "";
                        $this->data['refbfu'] =  $refbfu;
                        $invoices = $this->data['invoices'] = $this->seguceModel->get_unvalidated_invoices_by_reference_bfu($refbfu);

                        $this->data['Npaiements'] = count($invoices);
                        $this->data['facture'] = isset($this->data['invoices'][0]) ? $this->data['invoices'][0] : "";

                        $integrations = array();

                        $i = 0;
                        $montant_total = 0;
                        $amount_total = 0;
                        $reference = array();

                        foreach ($invoices as $row) {
                                $invoice_transactions = $this->comptabilisationModel->get_instructions_seguice($row->Id_0);

                                $montant_total = $montant_total + $row->Montant_11;
                                $amount_total += $row->Amount_21;

                                $reference[$row->Id_0] = $row->Reference_7;

                                foreach ($invoice_transactions as $line) {
                                        $integrations[$row->Id_0][] = $line;
                                }
                        }

                        $this->data['montant_total'] = $montant_total;
                        $this->data['amount_total'] = $amount_total;

                        $this->data['reference'] = $reference;

                        $this->data['integrations'] = $integrations;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_bacth_step_3', $this->data);
                }
                elseif($obj=="_invoice_step_2")
                {
                        $id_facture=isset($_GET['id'])?$_GET['id']:"";
                        
                        $invoice = $this->seguceModel->get_unvalidated_invoice_by_id($id_facture);
                 
                        $invoice_instructions=$this->comptabilisationModel->get_instructions_seguice($invoice->Id_0);

                        foreach ($invoice_instructions as $row) {
                                $integrations[$row->Id_0] = $row;
                        }

                        $this->data['facture']=$invoice;
                        $this->data['references']=$integrations;

                        $this->data['integrations']=$invoice_instructions;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoice_step_2', $this->data);

                }
                elseif ($obj == "integration")
                {
                        $data = array();
                        $data = $_POST;

                        if (isset($_POST['invoices_id']) && $_POST['invoices_id'] != "") {
                                if ($data['total_to_paid'] == 0) {
                                        if ($data['taux'] != 0) {
                                                $result = $this->data('validate_encaissement', $data);

                                                if (isset($data['guice_rate']) && $data['guice_rate'] != "") {
                                                        if ($data['Devise_account'] == 'USD') {
                                                                $total_amount = $result['total_topaid'] / $data['guice_rate'];
                                                        } else {
                                                                $total_amount = $result['total_topaid'];
                                                        }
                                                } else {
                                                        if ($data['Devise_account'] == 'USD') {
                                                                $total_amount = $result['total_topaid'] / $data['taux'];
                                                        } else {
                                                                $total_amount = $result['total_topaid'];
                                                        }
                                                }

                                                $data['bank_account'] = $data['Compte_33'];
                                                $data['devise_account'] = $data['Devise_account'];
                                                $data['amount'] = $total_amount;

                                                $core_banking = strtolower($this->core_banking);
                                                $response = $this->{$core_banking}->check_balance($data);

                                                if ($response['code'] == 200) {
                                                        $result['code'] = 'E200';
                                                        $result['balance'] = true;

                                                        echo json_encode($result);
                                                } elseif ($response['code'] == 300) {
                                                        $result['code'] = 'E300';
                                                        $result['balance'] = false;

                                                        echo json_encode($result);
                                                } else {
                                                        echo  'E411';
                                                }
                                        } else {
                                                echo  'E412';
                                        }
                                } 
                                elseif ($data['total_to_paid'] > 0) 
                                {
                                        // generer les premieres ecritures
                                        $agence = $this->session->get('Logiref_guichet');
                                        $ref = $agence . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');
                                        $type_array = array();

                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Beneficaire_15'] = 'SEGUCE';
                                        $data['Agence_20'] = $this->session->get('Logiref_agence');
                                        $data['Guichet_21'] = $this->session->get('Logiref_guichet');
                                        $data['Mode_19'] =  $_POST['Mode'];
                                        $data['Typerecette_17'] = 'OP' . $_POST['Refbfu'];
                                        $data['Devise_12'] = 'CDF';
                                        $data['Compte_33'] = $_POST['Compte_33'];
                                        $data['Devise_34'] = $_POST['Devise_account'];

                                        $logirefid = $data['Noteid_26'] = $ref;

                                        $data['Devise_24'] = 'CDF';
                                        $data['Nif_13'] = $_POST['Nif'];
                                        $data['total_topaid'] = $_POST['total_to_paid'];
                                        $data['total_invoices'] = $_POST['total_invoices'];
                                        $data['total_acb'] = $_POST['total_acb'];
                                        $data['total_frais'] = $_POST['total_frais'];
                                        $data['total_tva'] = $_POST['total_tva'];
                                        $data['to_paid'] = isset($_POST['to_paid']) ? $_POST['to_paid'] : "";
                                        $data['licence_fees'] = isset($_POST['total_licence_fees']) ? $_POST['total_licence_fees'] : 0;

                                        $reference_provision = "";

                                        foreach ($_POST['invoices_id'] as $invId) {
                                                $invoice = $this->seguceModel->get_invoice_by_id($invId);
                                                $type_array[] = $invoice->Typefacture_23;
                                        }

                                        $invoice = $this->seguceModel->check_invoices();

                                        if (isset($invoice[0]->Id_0) && $invoice[0]->Id_0 != "") {
                                                $transaction = $this->seguceModel->get_instructions_invoice($invoice[0]->Id_0);

                                                if (!empty($transaction)) {
                                                        $lines = array();
                                                        $i = 1;
                                                        $invoice_ref = "";

                                                        foreach ($transaction as $row) {
                                                                $lines[$i]['status'] = $row->Status_2;
                                                                $lines[$i]['id'] = $row->Id_0;
                                                                $lines[$i]['reference'] = $invoice_ref = $row->Reference_14;

                                                                $i++;
                                                        }


                                                        if (isset($lines[3]['status']) && $lines[1]['status'] == "1" && $lines[2]['status'] == "1" && $lines[3]['status'] == "1") {

                                                                # reference of the payment.
                                                                $id = $invoice[0]->Id_0;

                                                                $data['Seguce_53'] = $id;
                                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                                $data['Designation_14'] =  $_POST['designation'];
                                                                $data['Account_3'] = $this->session->userdata['account_id'];
                                                                $data['Priority'] = 0;

                                                                //$response = $this->amplitude->call_seguce_invoice_reservation($data);

                                                                $response = json_encode([]);
                                                                $return = json_decode($response, true);

                                                                if ($return['response'] == '200') {
                                                                        $result['code'] = 'E200';

                                                                        $result['id'] = $id;

                                                                        $result['reference'] = $invoice_ref;

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '301') {
                                                                        $result['code'] = 'E301';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '302') {
                                                                        $result['code'] = 'E302';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '303') {
                                                                        $result['code'] = 'E303';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '304') {
                                                                        $result['code'] = 'E304';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];


                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '305') {
                                                                        $result['code'] = 'E305';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '306') {
                                                                        $result['code'] = 'E306';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                }
                                                        } elseif (isset($lines[1]['status']) && ($lines[1]['status'] == "4" || $lines[1]['status'] == "5")) {
                                                                $result['code'] = 'E501';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[1]['id'];

                                                                $result['reference'] = $lines[1]['reference'];


                                                                echo json_encode($result);
                                                        } elseif (isset($lines[2]['status']) && ($lines[2]['status'] == "4" || $lines[2]['status'] == "5")) {
                                                                $result['code'] = 'E502';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[2]['id'];

                                                                $result['reference'] = $lines[2]['reference'];

                                                                echo json_encode($result);
                                                        } elseif (isset($lines[3]['status']) && ($lines[3]['status'] == "4" || $lines[3]['status'] == "5")) {
                                                                $result['code'] = 'E503';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[3]['id'];

                                                                $result['reference'] = $lines[3]['reference'];

                                                                echo json_encode($result);
                                                        } elseif (isset($lines[3]['status']) && $lines[1]['status'] == "2" || $lines[2]['status'] == "2" && $lines[3]['status'] == "2") {
                                                                # the reservation was succesfull.
                                                                $result['code'] = 'E500';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['reference'] = $lines[3]['reference'];

                                                                echo json_encode($result);
                                                        }
                                                } else {
                                                        $agence_src = $this->session->get('Logiref_guichet');
                                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                                        $instructions = $this->seguceModel->get_first_instructions($data, $comptes, $reference_provision = NULL, $type_array);

                                                        if (!empty($instructions)) {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 0;
                                                                $pid =  $this->seguceModel->save_seguce_instructions($ref, $data, $instructions, $logirefid, $priority);
                                                        }
                                                        if ($pid) {
                                                                $data['Seguce_53'] = $ref;
                                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                                $data['Designation_14'] =  $_POST['designation'];
                                                                $data['Account_3'] = $this->session->userdata['account_id'];
                                                                $data['Priority'] = 0;

                                                                //$response = $this->amplitude->call_seguce_invoice_reservation($data);
                                                                //$return = json_decode($response, true);
                                                                $return['response']='200';

                                                                if ($return['response'] == '200') {
                                                                        $in = $this->save('comptant');

                                                                        if ($in > 0) {
                                                                                $result['code'] = 'E200';
                                                                                $result['reference'] = $ref;
                                                                        } else {
                                                                                $result['code'] = 'E202';
                                                                                $result['reference'] = $ref;
                                                                        }

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '301') {
                                                                        $result['code'] = 'E301';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '302') {
                                                                        $result['code'] = 'E302';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '303') {
                                                                        $result['code'] = 'E303';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '304') {
                                                                        $result['code'] = 'E304';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '305') {
                                                                        $result['code'] = 'E305';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '306') {
                                                                        $result['code'] = 'E306';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];

                                                                        echo json_encode($result);
                                                                } else {
                                                                        $result['code'] = 'E411';
                                                                        $result['reference'] = $ref;
                                                                        $result['id'] = $ref;
                                                                        $result['transaction_id'] = $return['transaction_id'];
                                                                }
                                                        } else {
                                                                $result['code'] = 'E515';
                                                                echo json_encode($result);
                                                        }
                                                }
                                        } else {
                                                $result['code'] = 'E515';
                                                echo json_encode($result);
                                        }
                                }
                        } else {
                                $result['code'] = 'E000';
                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "integration-invoice")
                {
                        $data = array();
                        $data = $_POST;


                        $core_banking = strtolower($this->core_banking);

                        $_POST['invoices_id']=$data['invoice_id'];
                         
                        if (isset($_POST['invoice_id']) && $_POST['invoice_id'] != "") {

                                $result = $this->data('validate_encaissement_facture', $data);
                                $data['total_invoice'] = $result['total_invoices'];

                                if ($data['total_to_paid'] == 0) 
                                {
                                        if ($data['taux'] != 0) 
                                        {
                                                if (isset($data['guice_rate']) && $data['guice_rate'] != "") 
                                                {
                                                        if ($data['Devise_account'] == 'USD')
                                                                $total_amount = $result['total_topaid'] / $data['guice_rate'];
                                                        else
                                                                $total_amount = $result['total_topaid'];
                                                } 
                                                else 
                                                {
                                                        if ($data['Devise_account'] == 'USD')
                                                                $total_amount = $result['total_topaid'] / $data['taux'];
                                                        else
                                                                $total_amount = $result['total_topaid'];
                                                }
                                                
                                                $data['bank_account'] = $data['Compte_33'];
                                                $data['devise_account'] = $data['Devise_account'];
                                                $data['amount'] = $total_amount;

                                                if (!empty($this->options['ALL']['retrieve-balance-with-account-info'])) 
                                                {
                                                        # Balance du compte
                                                        $balance = ($_POST['account_balance'] ?? 0);
                                                        $devise  = $_POST['Devise_account'] ?? '';

                                                        if ($devise === 'CDF') 
                                                        {
                                                                # Vérification directe en CDF
                                                                $response['code'] = ($balance >= $total_amount) ? '200' : '300';
                                                        } 
                                                        elseif ($devise === 'USD') 
                                                        {
                                                                # Conversion USD → CDF
                                                                $converted_balance = $balance / $data['taux'];
                                                                $response['code'] = ($converted_balance >= $total_amount) ? '200' : '300';
                                                        }
                                                }
                                                else
                                                {
                                                        $response = $this->{$core_banking}->check_balance($data);
                                                }

                                                if ($response['code'] == 200) 
                                                {
                                                        $result['code'] = 'E200';
                                                        $result['balance'] = true;

                                                        echo json_encode($result);
                                                } 
                                                elseif ($response['code'] == 300) 
                                                {
                                                        $result['code'] = 'E300';
                                                        $result['balance'] = false;

                                                        echo json_encode($result);
                                                } 
                                                else 
                                                {
                                                        echo  'E411';
                                                }

                                        } 
                                        else 
                                        {
                                                echo  'E412';
                                        }
                                        
                                } 
                                elseif ($data['total_to_paid'] > 0) 
                                {
                                        $compte_suspens=null;
                                        // generer les premieres ecritures
                                        $agence = $this->session->get('Logiref_guichet');
                                        $ref = $agence . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');
                                        $type_array = array();

                                        $data['Designation_14'] = $_POST['designation'];
                                        $data['Beneficaire_15'] = 'SEGUCE';
                                        $data['Agence_20'] = $this->session->get('Logiref_agence');
                                        $data['Guichet_21'] = $this->session->get('Logiref_guichet');
                                        $data['Mode_19'] =  $_POST['Mode'];
                                        $data['Typerecette_17'] = 'OP' . $_POST['reference'];
                                        $data['Montant_11']=$data['total_invoice'];
                                        $data['Devise_12'] = 'CDF';
                                        $data['Compte_33'] = $_POST['Compte_33'];
                                        $data['Devise_34'] = $_POST['Devise_account'];

                                        $logirefid = $data['Noteid_26'] = $this->seguceModel->generate_unique_reference();

                                        $data['Devise_24'] = 'CDF';
                                        $data['Nif_13'] = $_POST['Nif'];

                                        $data['Noteid_26'] = $data['Ref'];
                                        $data['Notemontant_28']=$data['total_invoice'];
                                        $data['Taux_41']=$_POST['taux'];

                                        $data['total_topaid'] = $_POST['total_to_paid'];
                                        // $data['total_invoices'] = $_POST['total_invoices'];
                                        $data['total_acb'] = $_POST['total_acb'];
                                        $data['total_frais'] = $data['Commission_23'] = $_POST['total_frais'];
                                        $data['total_tva'] = $_POST['total_tva'];
                                        $data['to_paid'] = isset($_POST['to_paid']) ? $_POST['to_paid'] : "";
                                        $data['licence_fees'] = isset($_POST['total_licence_fees']) ? $_POST['total_licence_fees'] : 0;
                                        
                                        $reference_provision = "";

                                        $invoice = $this->seguceModel->check_invoice();
                                        
                                        $invoice_id=isset($invoice[0]->Id_0)?$invoice[0]->Id_0:0;
                                        if (isset($invoice[0]->Id_0) && $invoice[0]->Id_0 != "") 
                                        {
                                                # reference of the payment.
                                                $id = $invoice[0]->Id_0;

                                                $type_array[] = $invoice[0]->Typefacture_23;

                                                $transaction = $this->seguceModel->get_instructions_invoice($invoice[0]->Id_0);
                                                $transaction = [];

                                                if (!empty($transaction)) 
                                                {
                                                        $lines = array();
                                                        $i = 1;
                                                        $invoice_ref = "";

                                                        foreach ($transaction as $row) {
                                                                $lines[$i]['status'] = $row->Status_2;
                                                                $lines[$i]['id'] = $row->Id_0;
                                                                $lines[$i]['reference'] = $invoice_ref = $row->Reference_14;

                                                                $i++;
                                                        }

                                                        if (isset($lines[3]['status']) && $lines[1]['status'] == "1" && $lines[2]['status'] == "1" && $lines[3]['status'] == "1") 
                                                        {

                                                                # reference of the payment.
                                                                $id = $invoice[0]->Id_0;

                                                                $data['Seguce_53'] = $id;
                                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                                $data['Designation_14'] =  $_POST['designation'];
                                                                $data['Account_3'] = $this->session->userdata['account_id'];
                                                                $data['Priority'] = 0;
                                                                

                                                                $agence_src = $this->session->get('Logiref_guichet');
                                                                $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                                                $compte_suspens=isset($comptes[$this->bank]['CSG'][$data['Devise_12']]) ? $comptes[$this->bank]['CSG'][$data['Devise_12']]:"";

                                                                //$response = $this->{$core_banking}->reservation_seguce_invoice($data);

                                                                $data_to_update['Account_15']=$data['Compte_33'];
                                                                $data_to_update['Devise_16']=$data['Devise_account'];
                                                                $data_to_update['Commission_17']=$data['total_frais'];
                                                                $data_to_update['Devise_18']='CDF';
                                                                $data_to_update['Account_19']=$compte_suspens;
                                                                $data_to_update['Devise_20']=$data['Devise_12'];
                                                                $data_to_update['Rate_28']=$data['taux'];
                                                                $data_to_update['Accountholder_30'] = $_POST['account_name'];
                                                                $data_to_update['Logirefid_31']=$ref;
                                                                $data_to_update['Contrevaleur_33']=$data['Notemontant_28'];
                                                               
                                                                $return = [];
                                                                 $return['response']='200';
                                                                if ($return['response'] == '200') {
                                                                        $result['code'] = 'E200';
                                                                        $result['id'] = $id;
                                                                        $result['reference'] = $invoice_ref;
                                                                        
                                                                        $data_to_update['Status_2']='2';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '301') {
                                                                        $result['code'] = 'E301';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '302') {
                                                                        $result['code'] = 'E302';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '303') {
                                                                        $result['code'] = 'E303';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                         $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '304') {
                                                                        $result['code'] = 'E304';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '305') {
                                                                        $result['code'] = 'E305';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                        echo json_encode($result);
                                                                } elseif ($return['response'] == '306') {
                                                                        $result['code'] = 'E306';

                                                                        $result['reference'] = $invoice_ref;

                                                                        $result['id'] = $id;

                                                                        $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                        $data_to_update['Status_2']='5';
                                                                        $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                        echo json_encode($result);
                                                                }
                                                        } elseif (isset($lines[1]['status']) && ($lines[1]['status'] == "4" || $lines[1]['status'] == "5")) {
                                                                $result['code'] = 'E501';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[1]['id'];

                                                                $result['reference'] = $lines[1]['reference'];

                                                                $data_to_update['Status_2']='5';
                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                echo json_encode($result);
                                                        } elseif (isset($lines[2]['status']) && ($lines[2]['status'] == "4" || $lines[2]['status'] == "5")) {
                                                                $result['code'] = 'E502';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[2]['id'];

                                                                $result['reference'] = $lines[2]['reference'];

                                                                $data_to_update['Status_2']='5';
                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                echo json_encode($result);
                                                        } elseif (isset($lines[3]['status']) && ($lines[3]['status'] == "4" || $lines[3]['status'] == "5")) {
                                                                $result['code'] = 'E503';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['transaction_id'] = $lines[3]['id'];

                                                                $result['reference'] = $lines[3]['reference'];

                                                                $data_to_update['Status_2']='5';
                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                echo json_encode($result);
                                                        } elseif (isset($lines[3]['status']) && $lines[1]['status'] == "2" || $lines[2]['status'] == "2" && $lines[3]['status'] == "2") {
                                                                # the reservation was succesfull.
                                                                $result['code'] = 'E500';

                                                                $result['id'] = $invoice[0]->Id_0;

                                                                $result['reference'] = $lines[3]['reference'];

                                                                $data_to_update['Status_2']='5';
                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id); 

                                                                echo json_encode($result);
                                                        }
                                                } 
                                                else 
                                                {
                                                        $agence_src = $this->session->get('Logiref_guichet');
                                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                                        $compte_suspens=isset($comptes[$this->bank]['CSG'][$data['Devise_12']]) ? $comptes[$this->bank]['CSG'][$data['Devise_12']]:"";

                                                        //$instructions = $this->seguceModel->get_first_instructions($data, $comptes, $reference_provision = NULL, $type_array);
                                                        $instructions = $this->comptabilisation->get_instructions_seguce($data);
                                                        
                                                        if (!empty($instructions)) 
                                                                $pid =  $this->seguceModel->save_seguce_instructions($invoice_id, $data, $instructions, $logirefid);
                                                
                                                        if ($pid) 
                                                        {
                                                                $data['Seguce_53']      = $invoice_id;
                                                                $data['Id_0']           = $invoice_id;
                                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                                $data['Designation_14'] =  $_POST['designation'];
                                                                $data['Account_3']      = $this->session->userdata['account_id'];
                                                                $data['Logirefid_4']    = $logirefid;
                                                                $data['Priority']       = 0;

                                                                # Nom du core banking
                                                                $core_banking = strtolower($this->core_banking);

                                                                # Vérifier si la méthode existe dans la classe
                                                                if (method_exists($this->{$core_banking}, 'reservation_seguce_invoice'))
                                                                {
                                                                        $response = $this->{$core_banking}->reservation_seguce_invoice($data);

                                                                        // var_dump($return);die;
                                                                        $return = json_decode($response, true);
                                                                        // $return['response']='200';

                                                                        $data_to_update['Account_15']=$data['Compte_33'];
                                                                        $data_to_update['Devise_16']=$data['Devise_account'];
                                                                        $data_to_update['Commission_17']=$data['total_frais'];
                                                                        $data_to_update['Devise_18']='CDF';
                                                                        $data_to_update['Account_19']=$compte_suspens;
                                                                        $data_to_update['Devise_20']=$data['Devise_12'];
                                                                        $data_to_update['Rate_28']=$data['taux'];
                                                                        $data_to_update['Refop_29']=$data['reference'];
                                                                        $data_to_update['Accountholder_30'] = $_POST['account_name'];
                                                                        //$data_to_update['Logirefid_31']=$ref;
                                                                        $data_to_update['Logirefid_31']=$logirefid;
                                                                        $data_to_update['Contrevaleur_33']=$data['Notemontant_28'];

                                                                        if ($return['response'] == '200') {

                                                                                $result['code'] = 'E200';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                
                                                                                $data_to_update['Status_2']='2';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  
                                                                        
                                                                                echo json_encode($result);

                                                                        } elseif ($return['response'] == '301') {
                                                                                $result['code'] = 'E301';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $ref;
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } elseif ($return['response'] == '302') {
                                                                                $result['code'] = 'E302';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'] ;
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } elseif ($return['response'] == '303') {
                                                                                $result['code'] = 'E303';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'];
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } elseif ($return['response'] == '304') {
                                                                                $result['code'] = 'E304';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'];
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } elseif ($return['response'] == '305') {
                                                                                $result['code'] = 'E305';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'];
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } elseif ($return['response'] == '306') {
                                                                                $result['code'] = 'E306';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'];
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                                echo json_encode($result);
                                                                        } else {
                                                                                $result['code'] = 'E411';
                                                                                //$result['reference'] = $ref;
                                                                                $result['reference'] = $logirefid;
                                                                                $result['id'] = $data['Id_0'];
                                                                                $result['transaction_id'] = isset($return['transaction_id'])?$return['transaction_id']:"";

                                                                                $data_to_update['Status_2']='5';
                                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $result['code'] = 'E407';
                                                                        echo json_encode($result); die;
                                                                }
                                                                
                                                        } else {
                                                                $result['code'] = 'E515';

                                                                $data_to_update['Status_2']='5';
                                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                                echo json_encode($result);
                                                        }
                                                }
                                        } else {
                                                $result['code'] = 'E515';

                                                $data_to_update['Status_2']='5';
                                                $this->seguceModel->update_invoice($data_to_update,$invoice_id);  

                                                echo json_encode($result);
                                        }
                                }
                        } else {
                                $result['code'] = 'E000'; 
                                echo json_encode($result);
                        }
                } 
                elseif ($obj == "verify") 
                {
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Seguce_53'] = $_POST['invoice_id'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];
                        $data['MontantCIF_8'] = isset($_POST['MontantCIF_8'])  ? $_POST['MontantCIF_8'] : "";

                        $data['Priority'] = 0;

                        //$response = $this->amplitude->call_seguce_invoice_verify_reservation($data);
                        $response = json_encode([]);

                        $return = json_decode($response, true);

                        if ($return['response'] == '200') {
                                $in = $this->save('comptant');

                                if ($in > 0) {
                                        echo 'E200';
                                } else {
                                        echo  'E202';
                                }
                        } elseif ($return['response'] == '304') {
                                echo 'E304';
                        } elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) {
                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "cancel_reservation") 
                {
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Logirefid_4'] = $_POST['logirefid'];
                        $data['Seguce_53'] = $_POST['invoice_id'];

                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = $_POST['transaction_id'];

                        $data['Priority'] = 0;

                        //$response = $this->amplitude->call_seguce_invoice_cancel_reservation($data);
                        $response = json_encode([]);

                        $return = json_decode($response, true);

                        if ($return['response'] == '200') {
                                echo 'E200';
                        } elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) {
                                echo 'E' . $return['response'];
                                die;
                        }
                } 
                elseif ($obj == "first_comptabilisation") 
                {
                        $type_array = array();

                        $data = array();
                        
                        $data = $_POST;

                        if (isset($data['invoices_id']) && $data['invoices_id'] != "") 
                        {

                                foreach ($_POST['invoices_id'] as $invId) {
                                        $invoice = $this->seguceModel->get_invoice_by_id($invId);
                                        $type_array[] = $invoice->Typefacture_23;
                                }
                        }
                        else
                        {

                                $_POST['invoices_id'] = $data['Ref'];

                                $type_array[]='GUICE';

                        }
                        // generer les premieres ecritures
                        $agence = $this->session->get('Logiref_guichet');
                        $ref = $agence . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        $data['Designation_14'] = $data['designation'];
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Agence_20'] = $this->session->get('Logiref_agence');
                        $data['Guichet_21'] = $this->session->get('Logiref_guichet');
                        $data['Mode_19'] =  $data['Mode'];
                        $data['Typerecette_17'] = 'OP' . $data['Refbfu'];
                        $data['Devise_34'] = $data['Devise_account'];

                        if(isset($_POST['treatment_type']) && $_POST['treatment_type']!="single-via-api")
                        {
                                $result = $this->data('validate_encaissement', $data);
                        }
                        else
                        {
                                $result = $this->data('validate_encaissement_facture', $data);
                        }
                        
                        
                        $data['Devise_12'] = 'CDF';
                        $data['Compte_33'] = $data['Compte_33'];
                        $logirefid = $data['Noteid_26'] = $ref;

                        $data['Devise_24'] = 'CDF';
                        $data['Nif_13'] = $data['Nif'];
                        $data['total_to_paid'] = $result['total_invoices'];
                        $data['total_invoices'] = $result['total_invoices'];
                        $data['total_acb'] = $result['total_acb'];
                        $data['total_frais'] = $result['total_frais'];
                        $data['total_tva'] = $result['total_tva'];
                        $data['licence_fees'] = $result['total_licence_fees'];

                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                       
                        $instructions = $this->seguceModel->get_first_instructions($data, $comptes, $ref, $type_array);
                     
                        $this->data['lines'] = $instructions;

                        echo view('\Modules\Eximtrade\Views\seguce\_first_comptabilisation', $this->data);
                        // } 
                        // else 
                        // {
                        //         echo 'E000';
                        // }
                } 
                elseif ($obj == "first_comptabilisation_invoice") 
                {
                        $type_array = array();

                        $data = array();
                        $data = $_POST;
                        $instructions=array();

                        $_POST['invoices_id'] = $data['invoice_id'];

                        $type_array[]='GUICE';
                  
                        // generer les premieres ecritures
                        $agence = $this->session->get('Logiref_guichet');
                        $ref = $agence . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        $data['Designation_14'] = $data['designation'];
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Agence_20'] = $this->session->get('Logiref_agence');
                        $data['Guichet_21'] = $this->session->get('Logiref_guichet');
                        $data['Mode_19'] =  $data['Mode'];
                        $data['Typerecette_17'] = $data['reference'];
                        $data['Devise_34'] = $data['Devise_account'];

                        $result = $this->data('validate_encaissement_facture', $data);
                        $data['Montant_11']=$result['total_invoices'];
                        $data['Devise_12'] = 'CDF';
                        $data['Compte_33'] = $data['Compte_33'];
                        $logirefid = $data['Noteid_26'] = $ref;

                        $data['Devise_24'] = 'CDF';
                        $data['Noteid_26'] = $data['Ref'];
                        $data['Notemontant_28']=$result['total_invoices'];
                        $data['Taux_41']=$_POST['taux'];

                        $data['Nif_13'] = $data['Nif'];
                        $data['total_to_paid'] = $result['total_invoices'];
                        $data['total_invoice'] = $result['total_invoices'];
                        $data['total_acb'] = $result['total_acb'];
                        $data['total_frais'] = $data['Commission_23'] = $result['total_frais'];
                        $data['total_tva'] = $result['total_tva'];
                        $data['licence_fees'] = $result['total_licence_fees'];
                        $data['bank']=$this->bank;

                        #Comptabilisation
                        $instructions = $this->comptabilisation->get_instructions_seguce($data);

                        // $first_instructions = $this->seguceModel->get_first_instructions($data, $comptes, $ref, $type_array);
                        // $seguce_instructions=$this->seguceModel->get_instructions_seguce_invoice($data,$comptes,null,null,[]);
                        // $instructions=array_merge($first_instructions,$seguce_instructions);
                        
                        $this->data['lines'] = $instructions;

                        echo view('\Modules\Eximtrade\Views\seguce\_first_comptabilisation', $this->data);
                        // } 
                        // else 
                        // {
                        //         echo 'E000';
                        // }
                }
                elseif ($obj == "validated_invoices") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\pending', $this->data);
                } 
                elseif ($obj == "report_payseguce") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices();
                        echo view('\Modules\Eximtrade\\' . $this->folder . '\report_payseguce', $this->data);
                }
                elseif ($obj == "nvalidated")
                {
                        $this->data['invoices'] = $this->seguceModel->get_unvalidated_factures();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "validated")
                {
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif($obj=="nvalidated_invoices")
                {
                        $this->data['invoices'] = $this->seguceModel->get_unvalidated_invoices();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "filterresult")
                {
                        $status = $id;

                        if ($status == 'invoices') {
                                $this->data['invoices'] = $_SESSION["report_invoices"] = $this->seguceModel->get_invoices_filter($_POST);
                        } elseif ($status == 'pending') {
                                $this->data['invoices'] = $_SESSION["validated_invoices"] = $this->seguceModel->get_validated_invoices($_POST);
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "filter_nvalidated") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_unvalidated_factures($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "filter_payseguce") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "filter_batch_invoice")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoices($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "extractList")
                {
                        $data = array();

                        $user = $this->session->userdata['user_id'];
                        $users = $this->usersModel->get_member_by_user_id($user);

                        $data['agence'] = isset($_SESSION['Logiref_guichet']) ? $_SESSION['Logiref_guichet'] : "";
                        $data['ville'] = isset($_SESSION['Logiref_province']) ? $_SESSION['Logiref_province'] : "";
                        $data['ref_bfu'] = isset($_POST['ref_bfu']) && $_POST['ref_bfu'] !="" ? $_POST['ref_bfu'] : "";
                        $data['bank_account'] = isset($this->session->userdata['account_id']) ? $this->session->userdata['account_id'] : "";

                        $response = $this->seguceSFTP->get_invoice($data);

                        if (strpos($response, "`") !== false)
                        {
                                $return = str_replace("`", "", $response);
                        }
                        else{
                                $return = $response;
                        }

                        if($return ==  '0'):
                                echo $return;
                                die;
                        elseif (is_numeric($return) && $return > 0 ) :

                                $this->data['invoices'] = $this->seguceModel->get_invoices();
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoices', $this->data);
                        else :
                                echo '0';
                                die;
                        endif;
                }
                elseif ($obj == "extractPayments")
                {
                        //$response = $this->amplitude>call_seguce_invoices_paid();
                        $response = 'E100';

                        if ($response ==  'E100' || $response == 'E101') :

                                echo $response;

                        elseif ($response == 'E200') :


                                $this->data['invoices'] = $this->seguceModel->get_invoices_paid();
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_invoices_paid', $this->data);
                        else :

                                echo '0';

                        endif;
                }
                elseif ($obj == "invoicefees")
                {
                        if ($id != "") {
                                $this->data['invoicefee'] = $this->seguceModel->get_invoice_fees_info($id);

                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        } else {

                                $this->data['invoicefee'] = $this->seguceModel->get_invoice_fees_info();
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        }
                }
                elseif ($obj == "feesinvoice")
                {
                        $this->data['feesinvoice'] = $this->seguceModel->get_invoice_fees();
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif($obj == 'dropdowns')
                {
                        if($arg == "licence")
                        {
                                if ($id == 'IB'): 
                                        $categories = $this->licenceModel->get_dropdown('licence_ib');
                                elseif ($id == 'EB'):
                                        $categories = $this->licenceModel->get_dropdown('licence_eb');
                                else:
                                        $categories = array();
                                endif;

                                echo form_dropdown('CodeType_38', $categories, '', ' id="code_licence" class="form-control"  required="required"');
                        }
                }
                elseif($obj=="export_seguce_invoices")
                {

                        $sheet = $this->spreadsheet->getActiveSheet();
                        $sheet->setTitle("Factures validées et acquittées");

                        // En-têtes
                        $sheet->setCellValue('A1', 'Date');
                        $sheet->setCellValue('B1', 'Identifiant');
                        $sheet->setCellValue('C1', 'Référence');
                        $sheet->setCellValue('D1', 'Type');
                        $sheet->setCellValue('E1', 'Débiteur');
                        $sheet->setCellValue('F1', 'Créditeur');
                        $sheet->setCellValue('G1', 'Montant');

                        $invoices=$this->seguceModel->get_validated_invoices($_GET);

                        $row = 2;
                        foreach($invoices as $invoice)
                        {
                                $sheet->setCellValue('A'.$row, $invoice->Datevaleur_13);
                                $sheet->setCellValue('B'.$row, $invoice->Factureid_5);
                                $sheet->setCellValue('C'.$row, $invoice->Reference_7);
                                $sheet->setCellValue('D'.$row, $invoice->Typefacture_23);
                                $sheet->setCellValue('E'.$row, $invoice->Debiteur_25);
                                $sheet->setCellValue('F'.$row, $invoice->Creditaire_26);
                                $sheet->setCellValue('G'.$row, $invoice->Devise_12."  ".$invoice->Montant_11);

                                $row++;
                        }

                        // Télécharger le fichier
                        $writer = new Xlsx($this->spreadsheet);

                        $file_name="Factures_validees_".date("Ymdhis");

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$file_name.'"');
                        header('Cache-Control: max-age=0');

                        $writer->save('php://output');
                        exit;
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "comptant") 
                {
                        # Save payment
                        # Validate payment form 
                        $error = $this->data("validate_paiments");

                        #If form could not be validate
                        if ($error != '') {
                                echo $error;
                                die;
                        }
                        # If form is validated successfullly
                        else {
                                $data = array();
                                $data_id_paiement = array();
                                $prefix = 1;

                                $end_execution = NULL;

                                $Missmatch['Missmatch_32'] = 0;

                                $taux = str_replace(' ', '', $_POST['taux']);
                                $_POST['taux'] = str_replace(',', '.', $taux);


                                $type_recettes = $this->logirefModel->get_dropdown("type_recette");
                                $beneficiaires = $this->stakeholderModel->get_dropdown("beneficiaires");

                                $invoice_id = isset($_POST['invoices_id']) ? $_POST['invoices_id'] : "";
                                $invoice_id = implode(',', $invoice_id);
                                $invoices = $this->seguceModel->get_treated_invoices_by_id($invoice_id);

                                foreach ($invoices as $row) {
                                        $encaissement = $this->dataModel->get_seguce_migrate_invoice($row->Id_0);
                                        $agence_src = $this->session->get('Logiref_guichet');

                                        $object = json_encode($encaissement);
                                        $data = json_decode($object, true);
                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, "DGDA");
                                        $data['Compte_33'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "00000000000000000000000";
                                        $data['Devise_34'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                                        $data['Devise_12'] = "CDF";
                                        //$data['to_paid'] = isset($_POST['to_paid'])?$_POST['to_paid']:"";

                                        $type = $row->Typefacture_23;


                                        switch ($type) {
                                                case "GUICE":

                                                        $fraisb = 0;
                                                        $data['Montant_11'] = $data['Notemontant_28'];
                                                        $amount_acb = $data['frais_acb'] = 0;
                                                        $data['Commission_23'] = $data['total_frais'] =  ($fraisb * $_POST['taux']);
                                                        $data['frais_tva'] = (($fraisb * 16) / 100) * $_POST['taux'];
                                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                                        break;
                                                case "GUICELOG":

                                                        $fraisb = 12.93;
                                                        $data['Montant_11'] = $data['Notemontant_28'];
                                                        $amount_acb = $data['frais_acb'] = (5  * $_POST['taux']);
                                                        $data['Commission_23'] = $data['total_frais'] = ($fraisb * $_POST['taux']);
                                                        $data['frais_tva'] = (($fraisb * 16) / 100) * $_POST['taux'];
                                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                                        break;
                                                case "INVDIB":
                                                        $invoice = 40.6;
                                                        $fraisb = ($_POST['taux'] * $invoice);
                                                        $bank_fees = $fraisb - 34800;
                                                        $tva = ($bank_fees * 16) / 100;
                                                        $data['Montant_11'] = 0;
                                                        $amount_acb = $data['frais_acb'] = 0;
                                                        $data['Commission_23'] = $data['total_frais'] = $bank_fees;
                                                        $data['frais_tva'] = $tva;
                                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                                        break;
                                                case "NP":

                                                        // Selon les paliers des taux
                                                        $fraisb = (10 * $_POST['taux']);
                                                        $data['Montant_11'] = $data['Notemontant_28'];
                                                        $amount_acb = $data['frais_acb'] = 0;
                                                        $data['Commission_23'] = $data['total_frais'] = $fraisb;
                                                        $data['frais_tva'] = ($fraisb * 16) / 100;
                                                        $amount = $data['total_topaid'] =  ($data['Montant_11'] + $data['frais_acb'] + $data['Commission_23'] + $data['frais_tva']);

                                                        break;
                                                default:
                                                        break;
                                        }

                                        $data['Notereference_30'] = json_encode($data['Notereference_30']);

                                        $data['Devise_24'] = "CDF";
                                        $commission = $data['Commission_23'];
                                        $commission_devise = "CDF";
                                        $data['Taux_41'] =  $_POST['taux'];
                                        if (isset($_POST['guice_rate'])) $data['guice_rate'] =  $_POST['guice_rate'];

                                        $instructions = $this->seguceModel->get_first_instructions_single($data, $comptes, $type);

                                        if (!empty($instructions)) {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                $end_execution = $this->seguceModel->save_seguce_instructions($row->Id_0, $data, $instructions, $data['Logirefid_4'], $priority);
                                                unset($instructions);
                                        }
                                        #SAVE PAYMENT DE CHAQUE TAXE
                                        #Comptes CGU & CSG
                                        $guichet = $this->session->get('Logiref_guichet');
                                        $compte_cpt = isset($comptes['TMB']['CSO'][$data['Devise_12']]) ? $comptes['TMB']['CSO'][$data['Devise_12']] : '00000000000000000000000';
                                        $compte_sgc = isset($comptes['TMB']['CSG'][$data['Devise_12']]) ? $comptes['TMB']['CSG'][$data['Devise_12']] : '00000000000000000000000';

                                        #Taxes comptes
                                        unset($comptes);

                                        $comptes = array();
                                        $agence_src = $this->session->get('Logiref_guichet');
                                        $instructions = array();

                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                                        $info = $encaissement->Notereference_30;
                                        $taxes = $info['taxesPaid'];

                                        unset($data['CSG']);
                                        unset($data['CGU']);
                                        unset($data['Total']);
                                        unset($data['total_invoice']);
                                        unset($data['total_topaid']);
                                        unset($data['total_acb']);
                                        unset($data['frais_acb']);
                                        unset($data['total_frais']);
                                        unset($data['total_tva']);
                                        unset($data['frais_tva']);
                                        unset($data['Phase']);
                                        if (isset($data['guice_rate'])) unset($data['guice_rate']);

                                        foreach ($taxes as $taxe) {
                                                $data['Logirefid_4'] = $data['Logirefid_4'] . '-' . $prefix;
                                                $data['Contrevaleur_22'] = $data['Montant_11'];
                                                $data['Montant_11'] = $data['Montant_11'];
                                                $data['Devise_12'] = 'CDF';
                                                $data['Typerecette_17'] = $taxe->Code;
                                                $data['Commission_23'] = $commission;
                                                $data['Devise_24'] = $commission_devise;
                                                $data['Status_2'] = '1';

                                                $prefix++;

                                                if (isset($type_recettes[$taxe->Code]) && ($type_recettes[$taxe->Code] == "TRESOR" || $type_recettes[$taxe->Code] == "RFTRESD") && isset($beneficiaires[$taxe->Code])) {
                                                        $data['Tresor_45'] = '1';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->Code];

                                                        $type_rectte = $type_recettes[$taxe->Code];

                                                        if ($type == "NP") $pid = $this->encaissementModel->save_payment_tresor($data, NULL);


                                                        $instruction = $this->seguceModel->get_instructions_seguce($data, $comptes, $compte_cpt, $compte_sgc, $type_rectte);
                                                        $instructions[] = $instruction;
                                                } else if (isset($beneficiaires[$taxe->Code])) {
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $beneficiaires[$taxe->Code];


                                                        if ($type == "NP") $pid = $this->encaissementModel->save_payment_propres($data, NULL);
                                                        $instruction = $this->seguceModel->get_instructions_seguce($data, $comptes, $compte_cpt, $compte_sgc, "PROPRES");
                                                        $instructions[] = $instruction;
                                                } else {
                                                        $data['Missmatch_46'] = 1;
                                                        $data['Tresor_45'] = '0';
                                                        $data['Beneficaire_15'] = $taxe->Code;

                                                        if ($type == "NP") $pid = $this->encaissementModel->save_payment_propres($data, NULL);

                                                        $instruction = $this->seguceModel->get_instructions_seguce($data, $comptes, $compte_cpt, $compte_sgc, "PROPRES");
                                                        $instructions[] = $instruction;
                                                }
                                        }

                                        if (!empty($instructions)) {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;
                                                if ($type != "INVDIB") $end_execution = $this->seguceModel->save_seguce_instructions($row->Id_0, $data, $instructions, $_POST['logirefid'], $priority);
                                                unset($instructions);
                                        }

                                        if ($end_execution) {
                                                $invoice_data['Status_2'] = '2';
                                                $invoice_data['Logirefid_31'] =  $_POST['logirefid'];
                                                $invoice_data['Account_19'] = $compte_sgc;
                                                $invoice_data['Devise_20'] = 'CDF';
                                                $invoice_data['Commission_17'] = $data['Commission_23'];
                                                $invoice_data['Devise_18'] = $data['Devise_24'];
                                                $invoice_data['Amount_21'] = $amount;
                                                $invoice_data['Account_15'] = $data['Compte_33'];
                                                $invoice_data['Devise_16'] = $data['Devise_34'];
                                                $invoice_data['Accountholder_30'] = $_POST['account_name'];
                                                $invoice_data['Datevaleur_13'] = gmdate('Y-m-d H:i:s');
                                                $invoice_data['Amountacb_37'] = $amount_acb;
                                                $invoice_data['Mode_38'] = $_POST['Mode'];
                                                $invoice_data['Refop_29'] = $_POST['reference'];
                                                //$invoice_data['Topaid_43'] = isset($_POST['to_paid'])?$_POST['to_paid']:"";

                                                $update_invoice = $this->seguceModel->update_invoice($invoice_data, $row->Id_0);
                                        }
                                }
                                return $update_invoice;
                        }
                }
                elseif ($obj == "provision")
                {
                        if(array_key_exists('eximtrade_seguce_fee_deduction',$this->functionalities['ALL']))
                        {
                                $response = array();

                                # Check if the provision with the licence number exist already
                                $return = $this->seguceModel->get_provision_by_licence_id($_POST['Licence_7']);
                                $return1 = $this->seguceModel->get_licence_by_id($_POST['Licence_7']);

                                if ((!empty($return) || !empty($return1)) && $id == NULL)
                                {
                                        $response['code'] = 'E500';
                                        echo json_encode($response);
                                        die;
                                }
                                else
                                {

                                        $reference_provision = mt_rand(1, 999) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                                        if (isset($_POST['Codeimport_19']) && $_POST['Codeimport_19'] != "") {
                                                $customer_exempt = $this->data('get_customer_exempt', NULL, $_POST['Codeimport_19']);

                                                $results = json_decode($customer_exempt, true);

                                                $data['invoice_provision'] = $results['provision'];
                                        }

                                        if (isset($data['invoice_provision']) && $data['invoice_provision'] == 'TRUE') {
                                                $data['MontantCIF_8'] = 0;
                                                $data['Devise_9'] = "";
                                                $data['Montantprov_10'] = 0;
                                                $data['type'] = '';

                                                $data['Compte_12'] = '';
                                                $data['Devise_13'] = "";
                                        }
                                        else
                                        {
                                                #Data for the provision
                                                $data['MontantCIF_8'] = str_replace(' ', '', $_POST['MontantCIF_8']);
                                                $data['MontantCIF_8'] = str_replace(',', '.', $data['MontantCIF_8']);
                                                $data['Devise_9'] = $_POST['Devise_9'];

                                                $result = json_decode($this->session->get('Bank_rates'), true);

                                                if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") 
                                                {
                                                        $taux = $result;
                                                }
                                                else
                                                {
                                                        $taux = 1;
                                                }

                                                if ($data['Devise_9'] == 'EUR')
                                                {
                                                        $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Euro_5'];
                                                        $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                                }
                                                elseif ($data['Devise_9'] == 'ZAR')
                                                {
                                                        $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Zar_7'];
                                                        $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                                }
                                                elseif($data['Devise_9'] == 'GBP')
                                                {
                                                        $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Pound_7'];
                                                        $data['MontantCIF_8'] = round($data['MontantCIF_8'] / $taux['Dollar_4'], 2); 
                                                }

                                                if (isset($_POST['Categories']) && $_POST['Categories'] == 'EB')
                                                {
                                                        $data['Montantprov_10'] = 0;
                                                }
                                                else
                                                {
                                                        if ($data['MontantCIF_8'] > 10000)
                                                        {
                                                                $data['Montantprov_10'] = ($data['MontantCIF_8'] * 2.32) / 100;
                                                        }
                                                        else
                                                        {
                                                                $data['Montantprov_10'] = 232;
                                                        }
                                                }
                                        }

                                        # Get the provision account
                                        $agence_src = $this->session->get('Logiref_guichet');
                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                        $data_prov['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_prov['Status_2'] = 1;
                                        $data_prov['Account_3'] = $this->session->userdata['account_id'];
                                        $data_prov['Creator_4'] = $this->session->userdata['user_id'];

                                        $data_prov['Licence_7'] = isset($_POST['Licence_7'])?$_POST['Licence_7']:'';

                                        $data_prov['MontantCIF_8'] = $data['MontantCIF_8'];
                                        $data_prov['Devise_9'] = $data['Devise_9'];
                                        $data_prov['Montantprov_10'] = round($data['Montantprov_10'], 2);

                                        $data_prov['Date_11'] = $_POST['Date_11'];
                                        $data_prov['Taux_14'] = $_POST['Taux_14'];
                                        $data_prov['Codeimport_19'] = $_POST['Codeimport_19'];
                                        $data_prov['Compte_21'] = $_POST['Compte_21'];
                                        $data_prov['Devise_22'] = $_POST['Devise_account'];
                                        $data_prov['Designation_23'] = $_POST['Designation'];
                                        $data_prov['Nif_24'] = isset($_POST['NIF']) ? $_POST['NIF'] : "";
                                        $data_prov['LicenceFees_15'] = $_POST['LicenceFees_15'];
                                        $data_prov['Devise_16'] = $_POST['Devise_16'];
                                        $data_prov['ValidationFees_17'] = $_POST['ValidationFees_17'];
                                        $data_prov['Devise_18'] = $_POST['Devise_18'];
                                        $data_prov['Agence_27'] = $_SESSION['Logiref_agence'];
                                        $data_prov['Guichet_28'] = $_SESSION['Logiref_guichet'];
                                        $data_prov['SeguceFees_32'] = $_POST['SeguceFees_32'];
                                        $data_prov['Devise_33'] = $_POST['Devise_33'];
                                        $data_prov['RoyaltyFees_30'] = isset($_POST['RoyaltyFees_30']) && $_POST['RoyaltyFees_30'] != "" ? $_POST['RoyaltyFees_30'] : 0;
                                        $data_prov['Devise_31'] = isset($_POST['Devise_31']) ? $_POST['Devise_31'] : "";
                                        $data_prov['Reference_34'] = isset($_POST['Reference_34']) ? $_POST['Reference_34'] : "";
                                        $data_prov['CodeAur_25'] = isset($_POST['CodeAur_25']) ? $_POST['CodeAur_25'] : "";
                                        $data_prov['Commission_35'] = isset($_POST['Commission_35']) ? $_POST['Commission_35'] : "";
                                        $data_prov['Devise_36'] = isset($_POST['Devise_36']) ? $_POST['Devise_36'] : "";
                                        $data_prov['RateSeguce_37'] = isset($_POST['Taux_seguce']) && $_POST['Taux_seguce'] != "" ? $_POST['Taux_seguce'] : 0;
                                        $data_prov['CodeType_38'] = (isset($_POST['CodeType_38']) && $_POST['CodeType_38'] != "")?$_POST['CodeType_38']: NULL;
                                        $data_prov['Numero_importexport_39'] = $_POST['Numero_importexport_39'];

                                        $data_prov['Merchandise_40'] = isset($_POST['Merchandise_40']) && $_POST['Merchandise_40'] != "" ? $_POST['Merchandise_40']: '';

                                        if (isset($_POST['AmountPrefinance_41']) && $_POST['AmountPrefinance_41'] != '')
                                        {
                                                $data_prov['AmountPrefinance_41'] = str_replace(' ','',$_POST['AmountPrefinance_41']);
                                                $data_prov['AmountPrefinance_41'] = str_replace(',','.',$data_prov['AmountPrefinance_41']);
                                        }

                                        $data_prov['Devise_42'] = isset($_POST['Devise_42']) && $_POST['Devise_42'] != '' ? $_POST['Devise_42'] : '';
                                        $data_prov['Prefinance_43'] = isset($_POST['Prefinance_43']) && $_POST['Prefinance_43'] != "" ? $_POST['Prefinance_43']: '';

                                        if(is_null($id))
                                        {
                                                $data_prov['Reference_20'] = $reference_provision;
                                        }

                                        # Get the list of accounts from the db
                                        $agence_src = $this->session->get('Logiref_guichet');
                                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                        # Get the provision account
                                        $provision_account = isset($comptes['TMB']['CPF']['USD']) ? $comptes['TMB']['CPF']['USD'] : '000000000000000000000000';

                                        $data_prov['Compte_12'] = $provision_account;
                                        $data_prov['Devise_13'] = 'USD';

                                        $license_number = explode('-', $_POST['Licence_7']);

                                        if (!empty($license_number))
                                        {
                                                $data_prov['Licence'] = $license_number[0];
                                        }
                                        else
                                        {
                                                $data_prov['Licence'] = $_POST['Licence_7'];
                                        }

                                        $instructions = $this->seguceModel->get_instructions_provision($data_prov, $comptes);

                                        unset($data_prov['Licence']);
                                        unset($data_prov['Categories']);
                                        $pid = $this->seguceModel->save_provision($data_prov, $id);

                                        if ($pid)
                                        {
                                                if (isset($id) && $id > 0 && $id != NULL)
                                                {
                                                        $return = $this->seguceModel->delete_instructions_provision($id);
                                                }

                                                if (!empty($instructions))
                                                {
                                                        # priority for integrating the counting in cbs
                                                        $priority = 0;
                                                        $this->seguceModel->save_instructions_provision($pid, $data_prov, $instructions);
                                                }

                                                //echo $reference_provision;
                                                $response['code'] = 'E200';
                                                $response['reference'] = $reference_provision;
                                                $response['id'] = $pid;
                                                echo json_encode($response);
                                        }
                                        else
                                        {
                                                $response['code'] = 'E000';
                                                echo json_encode($response);
                                        }
                                }
                        }
                        else{

                                $response = array();

                                # Check if the provision with the licence number exist already
                                $return = $this->seguceModel->get_provision_by_licence_id($_POST['Licence_7']);
                                $return1 = $this->seguceModel->get_licence_by_id($_POST['Licence_7']);

                                if ((!empty($return) || !empty($return1)) && $id == NULL) {
                                        $response['code'] = 'E500';
                                        echo json_encode($response);
                                        die;
                                }
                                else {

                                        $reference_provision = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                        if (isset($_POST['Codeimport_19']))
                                        {
                                                $result = $this->feesModel->customer_exempt_provision_by_clt($_POST['Codeimport_19']);

                                                if (isset($result->Infos_10))
                                                {
                                                        $infos = json_decode($result->Infos_10, true);
                                                        $response['provision'] = (isset($infos['provision']) && $infos['provision'] !="") ? '1' : '0';
                                                        $response['tva'] = (isset($infos['tva']) && $infos['tva'] != "") ? '1' : '0';
                                                }
                                                else
                                                {
                                                        $response['provision'] = '0';
                                                        $response['tva'] = '0';
                                                }

                                                $data['invoice_provision'] = $_POST['invoice_provision'] = $response['provision'];
                                                $data['invoice_tva'] = $_POST['invoice_tva'] = $response['tva'];
                                        }

                                        if (isset($data['invoice_provision']) && $data['invoice_provision'] == '1')
                                        {
                                                $data['MontantCIF_8'] = 0;
                                                $data['Devise_9'] = "";
                                                $data['Montantprov_10'] = 0;
                                                $data['type'] = '';

                                                $data['Compte_12'] = '';
                                                $data['Devise_13'] = "";
                                        }
                                        else
                                        {
                                                #Data for the provision
                                                $data['MontantCIF_8'] = str_replace(' ','',$_POST['MontantCIF_8']);
                                                $data['MontantCIF_8'] = str_replace(',','.',$data['MontantCIF_8']);
                                                $data['Devise_9'] = $_POST['Devise_9'];

                                                $data['Compte_12'] = $_POST['Compte_12'];
                                                $data['Devise_13'] = $_POST['Devise_13'];

                                                if(isset($_POST['cif']))
                                                {
                                                        $data['type'] = "CIF";
                                                }
                                                elseif(isset($_POST['fob']))
                                                {
                                                        $data['type'] = "FOB";
                                                }
                                                elseif(isset($_POST['cfr']))
                                                {
                                                        $data['type'] = "CFR";
                                                }

                                                $amount_treated = $this->data("get_provision_start", $data);

                                                $data['amount_treated'] = $amount_treated;

                                                $amount = $this->data("get_provision_final", $data);

                                                if($amount >= 232)
                                                {
                                                        $data['Montantprov_10'] = $amount;
                                                }
                                                else
                                                {
                                                        $data['Montantprov_10'] = 232;
                                                }
                                        }

                                        if($data['type']=='')
                                        {
                                                $response['code'] = 'E201';

                                                echo json_encode($response);
                                        }
                                        else
                                        {
                                                $data_prov['Date_1']=gmdate('Y-m-d H:i:s');
                                                $data_prov['Status_2']= 1;
                                                $data_prov['Account_3'] = $this->session->userdata['account_id'];
                                                $data_prov['Creator_4'] = $this->session->userdata['user_id'];
                                                $data_prov['MontantCIF_8'] = $data['MontantCIF_8'];
                                                $data_prov['Devise_9'] = $data['Devise_9'];
                                                $data_prov['Montantprov_10'] = round($data['Montantprov_10'], 2);
                                                $data_prov['Compte_12'] = $data['Compte_12'];
                                                $data_prov['Devise_13'] = $data['Devise_13'];
                                                $data_prov['Licence_7'] = $_POST['Licence_7'];
                                                $data_prov['Date_11'] = $_POST['Date_11'];
                                                $data_prov['Taux_14'] = $_POST['Taux_14'];
                                                $data_prov['Codeimport_19'] = $_POST['Codeimport_19'];
                                                $data_prov['Reference_20'] = $reference_provision;
                                                $data_prov['Compte_21'] = $_POST['Compte_21'];
                                                $data_prov['Devise_22'] = $_POST['Devise_account'];
                                                $data_prov['Designation_23'] = $_POST['Designation'];
                                                $data_prov['Nif_24'] = isset($_POST['NIF'])? $_POST['NIF']:"";
                                                $data_prov['CodeAur_25'] = $_POST['CodeAur_25'];
                                                $data_prov['Typefacture_26'] = $data['type'];
                                                $data_prov['Agence_27'] = $_SESSION['Logiref_agence'];
                                                $data_prov['Guichet_28'] = $_SESSION['Logiref_guichet'];
                                                $data_prov['Numero_importexport_39'] = $_POST['Numero_importexport_39'];
                                                $data_prov['Environment_45'] = 'L';

                                                # Comptabilisation
                                                $agence_src = $_SESSION['Logiref_guichet'];
                                                $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                                $data_prov['Licence'] = $_POST['Licence_7'];
                                                $instructions = $this->seguceModel->get_instruction_provision($data_prov, $comptes, $reference_provision);
                                                unset($data_prov['Licence']);
                                                $pid = $this->seguceModel->save_provision($data_prov, $id);

                                                if($pid)
                                                {
                                                        if(isset($id) && $id > 0 && $id != NULL)
                                                        {
                                                                $this->seguceModel->delete_instructions_provision($id);
                                                        }

                                                        if(!empty($instructions))
                                                        {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 0;
                                                                $this->seguceModel->save_instructions_provision($pid, $data_prov, $instructions);
                                                        }

                                                        $response['code'] = 'E200';
                                                        $response['reference'] = $reference_provision;
                                                        $response['id'] = $pid;
                                                        echo json_encode($response);
                                                }
                                                else
                                                {
                                                        $reponse['code'] = 'E000';
                                                        echo json_encode($response);
                                                }
                                        }
                                }
                        }
                }
                elseif ($obj == "licence")
                {
                        $response = array();
                        # Check if the provision with the licence number exist already
                        //$return1 = $this->seguceModel->get_provision_by_licence_id($_POST['Licence_7']);
                        $return = $this->seguceModel->get_licence_by_id($_POST['Licence_7']);

                        if ((!empty($return) /*|| !empty($return1)*/) && $id == NULL) {
                                $response['code'] = 'E500';
                                echo json_encode($response);
                                die;
                        }
                        else {

                                $reference_licence = mt_rand(1, 999) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                                #Data for the provision
                                $data['MontantCIF_8'] = str_replace(' ', '', $_POST['MontantCIF_8']);
                                $data['MontantCIF_8'] = str_replace(',', '.', $data['MontantCIF_8']);

                                $data['Devise_9'] = $_POST['Devise_9'];

                                $result = json_decode($this->session->get('Bank_rates'), true);

                                if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                        $taux = $result;
                                }
                                else {
                                        $taux = 1;
                                }

                                # Get the provision account
                                $agence_src = $this->session->get('Logiref_guichet');
                                $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                $data_lcc['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data_lcc['Status_2'] = 1;
                                $data_lcc['Account_3'] = $this->session->userdata['account_id'];
                                $data_lcc['Creator_4'] = $this->session->userdata['user_id'];
                                $data_lcc['MontantCIF_8'] = $data['MontantCIF_8'];
                                $data_lcc['Devise_9'] = $data['Devise_9'];
                                $data_lcc['Licence_7'] = $_POST['Licence_7'];
                                $data_lcc['Date_10'] = $_POST['Date_10'];
                                $data_lcc['Taux_13'] = $_POST['Taux_13'];
                                $data_lcc['Codeimport_18'] = $_POST['Codeimport_18'];
                                $data_lcc['Compte_20'] = $_POST['Compte_20'];
                                $data_lcc['Devise_21'] = $_POST['Devise_21'];
                                $data_lcc['Designation_22'] = $_POST['Designation_22'];
                                $data_lcc['Nif_23'] = isset($_POST['Nif_23']) ? $_POST['Nif_23'] : "";
                                $data_lcc['LicenceFees_14'] = $_POST['LicenceFees_14'];
                                $data_lcc['Devise_15'] = $_POST['Devise_15'];
                                $data_lcc['ValidationFees_16'] = $_POST['ValidationFees_16'];
                                $data_lcc['Devise_17'] = $_POST['Devise_17'];
                                $data_lcc['Agence_24'] = $_SESSION['Logiref_agence'];
                                $data_lcc['Guichet_25'] = $_SESSION['Logiref_guichet'];
                                $data_lcc['CodeType_26'] = $_POST['CodeType_26'];
                                $data_lcc['Numero_importexport_27'] = $_POST['Numero_importexport_27'];

                                $data_lcc['Title_8'] = $this->licenceModel->get_categorie_by_object($data_lcc['CodeType_26'])->Title_8;

                                if(is_null($id)){
                                        $data_lcc['Reference_19'] = $reference_licence;
                                }

                                # Get the list of accounts from the db
                                $agence_src = $this->session->get('Logiref_guichet');
                                $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                                $instructions = $this->seguceModel->get_instructions_licence($data_lcc, $comptes);
                                unset($data_lcc['Title_8']);
                                $lid = $this->seguceModel->save_licence($data_lcc, $id);

                                if ($lid) {
                                        if (isset($id) && $id > 0 && $id != NULL) {
                                                $return = $this->seguceModel->delete_instructions_licence($id);
                                        }

                                        if (!empty($instructions)) {
                                                # priority for integrating the counting in cbs
                                                $priority = 0;
                                                $this->seguceModel->save_instructions_licence($lid, $data_lcc, $instructions);
                                        }

                                        $response['code'] = 'E200';
                                        $response['reference'] = $reference_licence;
                                        $response['id'] = $lid;
                                        echo json_encode($response);
                                }
                                else {
                                        $response['code'] = 'E000';
                                        echo json_encode($response);
                                }
                        }
                }
                elseif ($obj == 'provision_batchs')
                {
                        ini_set('memory_limit', '8192M');
                        $data = array();

                        $date = new DateTime();
                        $date = $date->format('Y-m-d');

                        $reference_provision = rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        $taux = json_decode($this->session->get('Bank_rates'), true);

                        # Get the list of accounts from the db
                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        # Get the provision account
                        $provision_account = isset($comptes['TMB']['CPF']['USD']) ? $comptes['TMB']['CPF']['USD'] : '000000000000000000000000';


                        if ($this->session->get('Logiref_role') == 4) {
                                $inserdata = array();
                                $allData = $_POST['allDatas'];
                                $i = 1;

                                $data = array();
                                $date = new DateTime();
                                $date = $date->format('Y-m-d');

                                foreach ($allData as $key => $value) {
                                        $_POST['montant_prov'][$value] = str_replace(' ', '', $_POST['montant_prov'][$value]);
                                        $_POST['montant_prov'][$value] = str_replace(',', '.', $_POST['montant_prov'][$value]);

                                        $inserdata[$i]['Date_1'] = $date;
                                        $inserdata[$i]['Status_2'] = '2';
                                        $inserdata[$i]['Account_3'] = $this->session->get('account_id');
                                        $inserdata[$i]['Creator_4'] = $this->session->get('user_id');
                                        $inserdata[$i]['Licence_7'] = $_POST['licences'][$value];
                                        $inserdata[$i]['MontantCIF_8'] = $_POST['montant_prov'][$value];
                                        $inserdata[$i]['Devise_9'] = "USD";
                                        $inserdata[$i]['Montantprov_10'] =  $_POST['montant_prov'][$value];
                                        $inserdata[$i]['Date_11'] = $_POST['dates'][$value];
                                        $inserdata[$i]['Compte_12'] = $provision_account;
                                        $inserdata[$i]['Devise_13'] = "USD";
                                        $inserdata[$i]['Taux_14'] = $taux["Dollar_4"];
                                        $inserdata[$i]['Reference_20'] = $reference_provision;
                                        $inserdata[$i]['Designation_23'] = $_POST['noms'][$value];
                                        $inserdata[$i]['Agence_27'] = $this->session->get('Logiref_agence');
                                        $inserdata[$i]['Guichet_28'] = $this->session->get('Logiref_guichet');

                                        $i++;
                                }

                                if (!empty($inserdata)) {
                                        $pid = $this->seguceModel->save_provision_batchs($inserdata);
                                }

                                if ($pid) {
                                        echo '<div class="alert alert-success">Donn&eacute;e enr&eacute;gistrer avec succ&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } else {
                                        echo '<div class="alert alert-danger">Donn&eacute;es non enregistr&eacute;, un probl&egrave;me est survenu !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                }
                elseif ($obj == 'invoice_occ_regul')
                {
                        # Les variables pour les provisions insuffisantes
                        # --------------------------------------------------

                        # Somme totale des montants manquant de chaque licence
                        $total_amount_gap_1 = 0;
                        # Nombre des factures
                        $plicence = 0;
                        # Frais de la banque
                        $fees_1 = 0;

                        # Les quotes-parts a payer pour chaque licence
                        $total_amount_occ = 0;
                        $total_amount_bivac = 0;
                        $total_occ_tva = 0;

                        $amounts = array();
                        $instructions = array();

                        # Les variables pour les provisions non existante
                        # ------------------------------------------------

                        # Somme totale des montants manquant de chaque licence
                        $total_amount_gap_2 = 0;
                        # Nombre des factures avec provision inexistante
                        $noplicence = 0;
                        # Frais de la banque
                        $fees_2 = 0;

                        # Les quotes-parts a payer pour chaque licence
                        $total_amount_occ_2 = 0;
                        $total_amount_bivac_2 = 0;
                        $total_occ_tva_2 = 0;

                        $amounts_2 = array();
                        $instructions_2 = array();

                        $data_to_treat = array();
                        $data_propre = array();

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Creator_4'] = $this->session->userdata['user_id'];

                        # Retrieve the exchange rate
                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                $taux = $result['Dollar_4'];
                        }
                        else {
                                $taux = 1;
                        }

                        # Generation of transactions based on each licence number
                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        if(isset($comptes['TMB']['CSP']['USD'])){
                                $compte_suspens_provision = $comptes['TMB']['CSP']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CSP']['USD'])){
                                $compte_suspens_provision = $comptes['Rawbank']['CSP']['USD'];
                        }
                        else{
                                $compte_suspens_provision = '00000000000000000000000';
                        }

                        if(isset($comptes['TMB']['CPF']['USD'])){
                                $compte_provision = $comptes['TMB']['CPF']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CPF']['USD'])){
                                $compte_provision = $comptes['Rawbank']['CPF']['USD'];
                        }
                        else{
                                $compte_provision = '00000000000000000000000';
                        }

                        $licence_provision = $this->seguceModel->get_dropdown('licence_provision');

                        $invoice = $this->seguceModel->get_invoices_occ_issues_info($_POST['invoice_regulId']);

                        if(isset($_POST['account_balance']) && $_POST['account_balance'] != "")
                        {
                                $compte_client = $data_to_treat['customer_account'] = $_POST['customer_account'];
                                $devise_compte_client = $data_to_treat['account_currency'] = $_POST['account_currency'];
                                $data_to_treat['devise'] = 'USD';

                                $date_bordereau = explode('-', $_POST['date_bordereau']);
                                $annee_bordereau = $date_bordereau[0];
                                $batch_id = $_POST['invoice_batchId'];
                                $reference_bordereau = $_POST['invoice_batchId'] . "" . $_POST['num_bordereau'] . "" . $annee_bordereau;

                                if (isset($_POST['datas']) && $_POST['datas'] != "") {
                                        $invoices = json_decode($_POST['datas'], true);

                                        foreach ($invoices as $key => $license) {
                                                $amount_som[$key] = 0;
                                        }

                                        foreach ($invoices as $key => $row) {
                                                foreach ($row as $cle => $ligne) {
                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                foreach ($ligne as $value) {
                                                                        $amount_som[$key] += $value;
                                                                }
                                                        }
                                                }
                                        }

                                        foreach ($invoices as $key => $license) {
                                                $license_number = explode('-', $key);
                                                $segment_license = $license_number[0];

                                                if (isset($licence_provision[$key])) {
                                                        if ($licence_provision[$key] > $amount_som[$key]) :
                                                                $amount_gap[$key] = $licence_provision[$key] - $amount_som[$key];
                                                        else :
                                                                $amount_gap[$key] = $amount_som[$key] - $licence_provision[$key];
                                                        endif;

                                                        $total_amount_gap_1 += $amount_gap[$key];
                                                        $plicence++;
                                                } elseif (isset($licence_provision[$segment_license]) && $licence_provision[$segment_license] != "") {
                                                        if ($licence_provision[$segment_license] > $amount_som[$key]) :
                                                                $amount_gap[$segment_license] = $licence_provision[$segment_license] - $amount_som[$key];
                                                        else :
                                                                $amount_gap[$segment_license] = $amount_som[$key] - $licence_provision[$segment_license];
                                                        endif;
                                                        $total_amount_gap_1 += $amount_gap[$segment_license];

                                                        $plicence++;
                                                } else {
                                                        $amount_gap_2[$key] = $amount_som[$key];
                                                        $total_amount_gap_2 += $amount_gap_2[$key];

                                                        $noplicence++;
                                                }
                                        }

                                        foreach ($invoices as $key => $row) {
                                                $license_number = explode('-', $key);
                                                $segment_license = $license_number[0];

                                                $data['Bank_7'] = isset($_POST['code_bank']) ? $_POST['code_bank'] : "";
                                                $data['Licence_8'] = $key;
                                                $data['Designation_13'] = $data_to_treat['designation'] = isset($_POST['designation']) ? $_POST['designation'] : "";
                                                $data['Codeimport_12'] = $data_to_treat['code_import'] = isset($_POST['code_import']) ? $_POST['code_import'] : "";
                                                $data['Numbordereau_14'] = $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                                $data['Datebordereau_15'] = $data_to_treat['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                                $data['MontantCIF_9'] = $data_to_treat['MontantCIF_9'] = isset($row['valeur_cif'][0]) ? $row['valeur_cif'][0] : "";
                                                $data['Devise_10'] = $data_to_treat['devise'] = "USD";
                                                $data['Result_11'] = $_POST['datas'];
                                                $data['Compte_16'] = $compte_provision;
                                                $data['Devise_17'] = "USD";
                                                $data['BatchId_23'] = $_POST['invoice_batchId'];

                                                $licence_id = $this->seguceModel->save_invoice_occ($data, NULL);

                                                $regulId = $_POST['invoice_regulId'];
                                                $data_regul['Status_2'] = '2';

                                                $this->seguceModel->update_invoice_occ_issues($data_regul, $regulId);

                                                $date_bordereau = explode('-', $data_to_treat['date_bordereau']);
                                                $ref_bordereau = $data_to_treat['num_bordereau'] . '/' . $date_bordereau[0];

                                                foreach ($row as $cle => $ligne) {
                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                $amount_recipe = 0;
                                                                foreach ($ligne as $value) {
                                                                        $data_propre['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                        $data_propre['Status_2'] = '1';
                                                                        $data_propre['Account_3'] = $this->session->userdata['account_id'];
                                                                        $data_propre['Makerid_9'] = $this->session->userdata['user_id'];
                                                                        $data_propre['Logirefid_4'] = $logirefid = rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');
                                                                        $data_propre['Contrevaleur_22'] = $value * $taux;
                                                                        $data_propre['Montant_11'] = $value;
                                                                        $data_propre['Devise_12'] = $data_to_treat['devise'];
                                                                        $data_propre['Typerecette_17'] = $cle;
                                                                        $data_propre['Tresor_45'] = '0';
                                                                        $data_propre['Beneficaire_15'] = 'OCC';
                                                                        $data_propre['Designation_14'] = $data_to_treat['designation'];
                                                                        $data_propre['Mode_19 '] = '7';
                                                                        $data_propre['Agence_20'] = $this->session->get('Logiref_agence');
                                                                        $data_propre['Guichet_21'] = $this->session->get('Logiref_guichet');
                                                                        $data_propre['Noteid_26'] = $key;
                                                                        $data_propre['Notedate_27'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                        $data_propre['Notemontant_28'] = $data_to_treat['MontantCIF_9'];
                                                                        $data_propre['Notedevise_29 '] = $data_to_treat['devise'];
                                                                        $data_propre['Notereference_30 '] = $reference_bordereau;
                                                                        $data_propre['Datevaleur_31'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                        $data_propre['Invoice_54'] = $licence_id;

                                                                        //$this->encaissementModel->save_payment_propres($data_propre, NULL);
                                                                }
                                                        }
                                                }

                                                if ((isset($licence_provision[$key]) && $licence_provision[$key] > 0)  || (isset($licence_provision[$segment_license]) && $licence_provision[$segment_license] > 0)) {
                                                        foreach ($row as $cle => $ligne) {
                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                        $amount_occ = 0;
                                                                        $amount_bivac = 0;
                                                                        $amount_occ_tva = 0;

                                                                        foreach ($ligne as $value) {
                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                        }

                                                                        $total_amount_occ += $amount_occ;
                                                                        $total_amount_bivac += $amount_bivac;
                                                                        $total_occ_tva += $amount_occ_tva;

                                                                        $amounts['CPO'] = $total_amount_occ;
                                                                        $amounts['CPB'] = $total_amount_bivac;
                                                                        $amounts['CTC'] = $total_occ_tva;
                                                                }
                                                        }
                                                } else {
                                                        foreach ($row as $cle => $ligne) {
                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                        $amount_occ = 0;
                                                                        $amount_bivac = 0;
                                                                        $amount_occ_tva = 0;

                                                                        foreach ($ligne as $value) {
                                                                                if ($cle == 'CPO') $amount_occ += $value;
                                                                                if ($cle == 'CPB') $amount_bivac += $value;
                                                                                if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                        }

                                                                        $total_amount_occ_2 += $amount_occ;
                                                                        $total_amount_bivac_2 += $amount_bivac;
                                                                        $total_occ_tva_2 += $amount_occ_tva;

                                                                        $amounts_2['CPO'] = $total_amount_occ_2;
                                                                        $amounts_2['CPB'] = $total_amount_bivac_2;
                                                                        $amounts_2['CTC'] = $total_occ_tva_2;
                                                                }
                                                        }
                                                }
                                        }

                                        # Calcul des montants totaux des quotes-parts OCC, BIVAC et TVA de l'OCC pour les provisions insuffisantes
                                        $i = 1;
                                        foreach ($amounts as $cle => $amount) {
                                                if ($i == 1) {
                                                        if (isset($total_amount_gap_1) && $total_amount_gap_1 > 0) {
                                                                $data_to_treat['montant'] = $total_amount_gap_1;

                                                                $instructions[]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data_to_treat, $compte_provision);
                                                        }
                                                }

                                                $type = $cle;
                                                $data_to_treat['montant'] = $amount;

                                                if ($type != 'CTC') {
                                                        $instructions[] = $this->seguceModel->get_instructions_seguce_by_licence_number($data_to_treat, $comptes, $compte_provision, $type);
                                                } else {
                                                        $instructions[] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                }

                                                $i++;
                                        }

                                        # Calcul des montants totaux des quotes-parts OCC, BIVAC et TVA de l'OCC pour les provisions inexistante
                                        foreach ($amounts_2 as $cle => $amount) {
                                                $type = $cle;
                                                $data_to_treat['montant'] = $amount;

                                                if ($type != 'CTC') {
                                                        $instructions_2[] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data_to_treat, $comptes, $type);
                                                } else {
                                                        $instructions_2[] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                }
                                        }

                                        /**
                                         * ATTENTION: A N'EST PAS SUPPRIME
                                         */

                                        // #Frais de la banque pour les provisions insuffisante
                                        // if (isset($plicence) && $plicence > 0)
                                        // {
                                        //         $data_to_treat['montant'] =  10;
                                        //         $data_to_treat['montant_tva'] = $data_to_treat['montant'] * 0.16;
                                        //         $data_to_treat['Priority']= 1;

                                        //         $fees_1 = $data_to_treat['montant'] + $data_to_treat['montant_tva'];

                                        //         $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data_to_treat, $comptes);

                                        //         foreach ($instructions_fees as $instruction)
                                        //         {
                                        //                 $instructions[] = $instruction;
                                        //         }
                                        // }

                                        // #Frais de la banque pour les provisions inexistante
                                        // if (isset($noplicence) && $noplicence > 0)
                                        // {
                                        //         $data_to_treat['montant'] = 10;
                                        //         $data_to_treat['montant_tva'] = $data_to_treat['montant'] * 0.16;
                                        //         $data_to_treat['Priority']= 1;

                                        //         $fees_2 = $data_to_treat['montant'] + $data_to_treat['montant_tva'];

                                        //         $instructions_fees  = $this->seguce_model->get_instructions_occ_bivac_debit_bank_fees_by_customer($data_to_treat, $comptes);

                                        //         foreach ($instructions_fees as $instruction)
                                        //         {
                                        //                 $instructions_2[] = $instruction;
                                        //         }
                                        // }

                                }

                                if (!empty($instructions)) {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;

                                        $end_execution = $this->seguceModel->save_instructions_invoice_occ($batch_id, $instructions, $logirefid, $priority, $data_to_treat['code_import']);
                                        unset($instructions);
                                }

                                if (!empty($instructions_2)) {
                                        # priority for integrating the counting in cbs
                                        $priority = 1;

                                        $end_save = $this->seguceModel->save_instructions_invoice_occ($batch_id, $instructions_2, $logirefid, $priority, $data_to_treat['code_import']);
                                        unset($instructions_2);
                                }

                                if (isset($end_execution) && $end_execution != "") {
                                        $data_batch['Status_2'] = '3';
                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data_batch['Creator_4'] = $this->session->userdata['user_id'];

                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);

                                        echo "E200";
                                }
                                elseif (isset($end_save) && $end_save != "") {
                                        $data_batch['Status_2'] = '3';
                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data_batch['Creator_4'] = $this->session->userdata['user_id'];

                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);

                                        echo "E200";
                                }
                                else {
                                        echo 0;
                                }
                        }
                        else{
                                $account_provision_clt = $this->accountsModel->get_dropdown("account_provision_with_clt");
                                $account_provision_clt_currency = $this->accountsModel->get_dropdown("account_provision_with_clt_currency");

                                $account_codeimport = $this->accountsModel->get_dropdown("account_code_import");
                                $account_codeimport_currency = $this->accountsModel->get_dropdown("account_code_import_currency");

                                $compte_provision = isset($account_provision_clt[$invoice->CodeImport_8]) ? $account_provision_clt [$invoice->CodeImport_8] : "000000000000000000000000";
                                $compte_client = $_POST['customer_account'];

                                $date_bordereau = explode('-', $_POST['date_bordereau']);
                                $annee_bordereau = $date_bordereau[0];
                                $reference_bordereau = $_POST['invoice_batchId']. "" .$_POST['num_bordereau']. "" .$annee_bordereau;

                                if(isset($_POST['datas']) && $_POST['datas'] !="")
                                {
                                        $invoices = json_decode($_POST['datas'], true);

                                        $amount = array();

                                        # Calcul du montant total de chaque licence pour faire un seul debit dans le compte du client
                                        foreach ($invoices as $key=>$row)
                                        {
                                                $total_amount_licence = 0;

                                                foreach($row as $cle=>$ligne)
                                                {
                                                        if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                        {
                                                                $amount_recipe = 0;

                                                                foreach ($ligne as $value)
                                                                {
                                                                        $amount_recipe = $amount_recipe + $value;
                                                                }
                                                                $total_amount_licence = $total_amount_licence + $amount_recipe;

                                                        }
                                                }

                                                $amount[$key] = $total_amount_licence;
                                        }

                                        $comm_occ = 0;
                                        $comm_bivac = 0;
                                        $tva_occ = 0;
                                        $tva_bivac = 0;
                                        $amount_bivac = 0;
                                        $amount_occ = 0;

                                        foreach($invoices as $key=>$row)
                                        {
                                                $data['Bank_7'] = isset($_POST['code_bank']) ? $_POST['code_bank'] : "";
                                                $data['Licence_8'] = $key;
                                                $data['Designation_13'] = $data_to_treat['designation'] = isset($_POST['designation']) ? $_POST['designation'] : "";
                                                $data['Codeimport_12'] = $data_to_treat['code_import'] = isset($_POST['code_import']) ? $_POST['code_import'] : "";
                                                $data['Numbordereau_14'] = $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                                $data['Datebordereau_15'] = $data_to_treat['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                                $data['MontantCIF_9'] = $data_to_treat['MontantCIF_9'] = isset($row['valeur_cif'][0]) ? $row['valeur_cif'][0] : "";
                                                $data['Devise_10'] = $data_to_treat['devise'] = "USD";
                                                $data['Result_11'] = $_POST['datas'];
                                                $data['Compte_16'] = $compte_provision;
                                                $data['Devise_17'] = "USD";
                                                $data['Regulid_18'] = $_POST['invoice_regulId'];
                                                $data['Compte_19'] = $_POST['customer_account'];
                                                $data['Devise_20'] = $_POST['account_currency'];
                                                $data['Siglebank_22'] = isset($_POST['sigle']) ? $_POST['sigle']: "";
                                                $data['BatchId_23'] = $_POST['invoice_batchId'];
                                                $data['Environment_24'] = "L";
                                                $data['Agence_25'] = $_SESSION['Logiref_agence'];
                                                $data['Guichet_26'] = $_SESSION['Logiref_guichet'];

                                                $licence_id = $this->seguceModel->save_invoice_occ($data, NULL);

                                                $regulId = $_POST['invoice_regulId'];
                                                $data_regul['Status_2'] = '2';

                                                $this->seguceModel->update_invoice_occ_issues($data_regul, $regulId);

                                                $data_to_treat['montant'] = $amount[$key];
                                                $data_to_treat['licence'] = $key;
                                                $data_to_treat['customer_account'] =  $_POST['customer_account'];
                                                $data_to_treat['account_currency'] = $_POST['account_currency'];

                                                $instructions[] = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_regul($data_to_treat, $comptes, $compte_provision, $compte_client);

                                                $date_bordereau = explode('-', $data_to_treat['date_bordereau']);
                                                $ref_bordereau = $data_to_treat['num_bordereau'].'/'.$date_bordereau[0];

                                                foreach($row as $cle=>$ligne)
                                                {
                                                        if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                        {
                                                                $amount_recipe = 0;
                                                                foreach ($ligne as $value)
                                                                {
                                                                        $data_propre['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                        $data_propre['Status_2'] = '1';
                                                                        $data_propre['Account_3'] = $this->session->userdata['account_id'];
                                                                        $data_propre['Makerid_9'] = $this->session->userdata['user_id'];
                                                                        $data_propre['Logirefid_4'] = $logirefid = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                                                        $data_propre['Contrevaleur_22'] = $value * $taux;
                                                                        $data_propre['Montant_11'] = $value;
                                                                        $data_propre['Devise_12'] = $data_to_treat['devise'];
                                                                        $data_propre['Typerecette_17'] = $cle;
                                                                        $data_propre['Tresor_45'] = '0';
                                                                        $data_propre['Beneficaire_15'] = 'OCC';
                                                                        $data_propre['Designation_14'] = $data_to_treat['designation'];
                                                                        $data_propre['Mode_19 '] = '7';
                                                                        $data_propre['Agence_20'] = $_SESSION['Logiref_agence'];
                                                                        $data_propre['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                                                        $data_propre['Noteid_26'] = $key;
                                                                        $data_propre['Notedate_27'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                        $data_propre['Notemontant_28'] = $data_to_treat['MontantCIF_9'];
                                                                        $data_propre['Notedevise_29 '] = $data_to_treat['devise'];
                                                                        $data_propre['Notereference_30 '] = $ref_bordereau;
                                                                        $data_propre['Datevaleur_31'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                        $data_propre['Invoice_54'] = $licence_id;
                                                                        $data_propre['Environment_55'] = "L";

                                                                        $this->encaissementModel->save_seguce_payment_propres($data_propre, NULL);

                                                                        if ($cle == 'CPO')
                                                                        {
                                                                                $amount_occ = $value;
                                                                                $comm_occ = ($amount_occ * 0.232)/100;
                                                                                $tva_occ = $comm_occ * 0.16;

                                                                                $amount_recipe = $amount_occ - ($comm_occ + $tva_occ);
                                                                        }
                                                                        elseif ($cle == 'CPB')
                                                                        {
                                                                                $amount_bivac = $value;
                                                                                $comm_bivac = ($amount_bivac * 0.116)/100;
                                                                                $tva_bivac = $comm_bivac * 0.16;

                                                                                $amount_recipe = $amount_bivac - ($comm_bivac+$tva_bivac);
                                                                        }
                                                                        else
                                                                        {
                                                                                $amount_recipe = $value;
                                                                        }

                                                                }

                                                                $frais_bancaire_partial = $comm_occ + $comm_bivac;
                                                                $frais_tva_partial = $tva_occ + $tva_bivac;

                                                                $data_to_treat['licence'] = $key;
                                                                $type = $cle;
                                                                //$data_to_treat['montant'] = round($amount_recipe,2);

                                                                $amounts[$key]['CPO'] = $amount_occ;
                                                                $amounts[$key]['CPB'] = $amount_bivac;

                                                                $data_to_treat['montant'] = $this->data('get_reduce_decimal', $amount_recipe , 2);
                                                                $data_to_treat['montant_fb'] = $this->data('get_reduce_decimal', $frais_bancaire_partial , 3);
                                                                $data_to_treat['montant_tva'] = $this->data('get_reduce_decimal', $frais_tva_partial , 3);

                                                                $instructions[] = $this->seguceModel->get_instructions_seguce_by_licence_number1($data_to_treat, $comptes, $compte_suspens_provision, $type);

                                                                if(!empty($instructions))
                                                                {
                                                                        # priority for integrating the counting in cbs
                                                                        $priority = 1;

                                                                        $end_execution = $this->seguceModel->save_instructions_invoice_occ($licence_id, $instructions, NULL, $priority, $data_to_treat['code_import']);
                                                                        unset($instructions);
                                                                }
                                                        }
                                                }


                                                $instruction_partial = $this->seguceModel->get_frais_bancaire_instructions_seguce_debit_by_licence_number1($data_to_treat, $comptes);

                                                if(!empty($instruction_partial))
                                                {
                                                        # priority for integrating the counting in cbs
                                                        $priority = 0;

                                                        $this->seguceModel->save_instructions_invoice_occ($licence_id, $instruction_partial, NULL, $priority, $data_to_treat['code_import']);

                                                        unset($instruction_partial);
                                                }

                                        }

                                        $total_amount_occ = 0;
                                        $total_amount_bivac = 0;

                                        foreach($amounts as $aKey => $aVal)
                                        {
                                                foreach ($aVal as $cle => $value)
                                                {
                                                        if ($cle == 'CPO') $total_amount_occ += $value;
                                                        if ($cle == 'CPB') $total_amount_bivac += $value;
                                                }
                                        }

                                        #Calcul de commission OCC & BIVAC
                                        $com_occ = $this->data("get_occ_bivac_commission", "OCC",  $total_amount_occ);
                                        $com_bivac = $this->data("get_occ_bivac_commission", "BIVAC", $total_amount_bivac);

                                        $data_to_treat['amount_comm'] = $com_occ + $com_bivac;
                                        $data_to_treat['amount_tva'] = $data_to_treat['amount_comm'] * 0.16;

                                        $data_to_treat['amount_comm'] = $this->data('get_reduce_decimal', $data_to_treat['amount_comm'] , 2);
                                        $data_to_treat['amount_tva'] = $this->data('get_reduce_decimal', $data_to_treat['amount_tva'] , 2);

                                        $instructions2 = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_fb1($data_to_treat, $comptes);

                                        $instruction_frais = $this->seguceModel->get_instructions_invoices_occ($licence_id);

                                        if (!$instruction_frais && !empty($instructions2))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;

                                                $this->seguceModel->save_instructions_invoice_occ($licence_id, $instructions2, NULL, $priority, $data_to_treat['code_import']);
                                                unset($instructions2);
                                        }
                                        else
                                        {
                                                foreach ($instruction_frais as $row)
                                                {
                                                        if ($row->Type_26 == 'COM')
                                                        {
                                                                $frais_com_cdf = round($data_to_treat['amount_comm'] * $taux, 2);
                                                                $frais_com_usd =  $data_to_treat['amount_comm'];

                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $frais_data_updated['Montant_10'] = $frais_com_cdf + $row->Montant_10;
                                                                $frais_data_updated['Montant_24'] = $frais_com_usd + $row->Montant_24;

                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $reference_bordereau, 'COM');
                                                        }

                                                        if ($row->Type_26 == 'TVA')
                                                        {
                                                                $frais_tva_cdf = $data_to_treat['amount_tva'] * $taux;
                                                                $frais_tva_usd =  $data_to_treat['amount_tva'];

                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $frais_data_updated['Montant_10'] = $frais_tva_cdf  + $row->Montant_10;
                                                                $frais_data_updated['Montant_24'] = $frais_tva_usd + $row->Montant_24;

                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $reference_bordereau, 'TVA');
                                                        }
                                                }
                                        }

                                }

                                if(isset($end_execution) && $end_execution !="")
                                {
                                        echo "E200";
                                }
                                elseif(isset($end_save) && $end_save !="")
                                {
                                        echo "E200";
                                }
                                else
                                {
                                        echo 0;
                                }
                        }
                }
                elseif ($obj == 'partial_regularisation')
                {
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = '0';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Creator_4'] = $this->session->userdata['user_id'];

                        $data_to_treat = array();
                        $data_propre = array();


                        # Retrieve the exchange rate
                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                $taux = $result['Dollar_4'];
                        } else {
                                $taux = 1;
                        }

                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        $compte_suspens_provision = isset($comptes['TMB']['CSP']['USD']) ? $comptes['TMB']['CSP']['USD'] : '00000000000000000000000';

                        $invoice = $this->seguceModel->get_invoices_occ_issues_info($_POST['invoice_regulId']);

                        $account_provision_clt = $this->accountsModel->get_dropdown("account_provision_with_clt");
                        $account_provision_clt_currency = $this->accountsModel->get_dropdown("account_provision_with_clt_currency");

                        $account_codeimport = $this->accountsModel->get_dropdown("account_code_import");
                        $account_codeimport_currency = $this->accountsModel->get_dropdown("account_code_import_currency");

                        $compte_provision = isset($account_provision_clt[$invoice->CodeImport_8]) ? $account_provision_clt[$invoice->CodeImport_8] : "000000000000000000000000";
                        $compte_client = $_POST['customer_account'];

                        if (isset($_POST['datas']) && $_POST['datas'] != "") {
                                $invoices = json_decode($_POST['datas'], true);
                                $amount = array();
                                $amount_paid_occ = array();
                                $amount_paid_bivac = array();
                                $types_regul = array();

                                # Calcul du montant total de chaque licence pour faire un seul debit dans le compte du client
                                foreach ($invoices as $key => $row) {
                                        $total_amount_licence = 0;

                                        foreach ($row as $cle => $ligne) {
                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                        $amount_recipe = 0;

                                                        foreach ($ligne as $value) {
                                                                if ($cle == 'CPO') {
                                                                        $amount_paid_occ[$key] = $value;
                                                                        $types_regul[] = $cle;
                                                                } else {
                                                                        $amount_recipe = $amount_recipe + $value;
                                                                        $types_regul[] = $cle;
                                                                }
                                                        }

                                                        $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                }
                                        }

                                        $amount[$key] = $total_amount_licence;
                                }

                                $licence_amount_gap = json_decode($_POST['licence_amount_gap'], true);

                                foreach ($invoices as $key => $row) {
                                        $data['Bank_7'] = isset($_POST['code_bank']) ? $_POST['code_bank'] : "";
                                        $data['Licence_8'] = $key;
                                        $data['Designation_13'] = $data_to_treat['designation'] = isset($_POST['designation']) ? $_POST['designation'] : "";
                                        $data['Codeimport_12'] = $data_to_treat['code_import'] = isset($_POST['code_import']) ? $_POST['code_import'] : "";
                                        $data['Numbordereau_14'] = $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                        $data['Datebordereau_15'] = $data_to_treat['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                        $data['MontantCIF_9'] = $data_to_treat['MontantCIF_9'] = isset($row['valeur_cif'][0]) ? $row['valeur_cif'][0] : "";
                                        $data['Devise_10'] = $data_to_treat['devise'] = "USD";
                                        $data['Result_11'] = $_POST['datas'];
                                        $data['Compte_16'] = $compte_provision;
                                        $data['Devise_17'] = "USD";
                                        $data['Regulid_18'] = $_POST['invoice_regulId'];
                                        $data['Compte_19'] = $_POST['customer_account'];
                                        $data['Devise_20'] = $_POST['account_currency'];
                                        $data['Amountgap_21'] = isset($licence_amount_gap[$key]) ? $licence_amount_gap[$key] : "0";
                                        $data['BatchId_23'] = $_POST['invoice_batchId'];

                                        $licence_id = $this->seguceModel->save_invoice_occ($data, NULL);

                                        $regulId = $_POST['invoice_regulId'];
                                        $data_regul['Status_2'] = '5';

                                        $this->seguceModel->update_invoice_occ_issues($data_regul, $regulId);

                                        $data_to_treat['licence'] = $key;
                                        $data_to_treat['customer_account'] =  $_POST['customer_account'];
                                        $data_to_treat['account_currency'] = $_POST['account_currency'];

                                        $date_bordereau = explode('-', $data_to_treat['date_bordereau']);
                                        $ref_bordereau = $data_to_treat['num_bordereau'] . '/' . $date_bordereau[0];

                                        foreach ($types_regul as $type) {
                                                if ($type == 'CPO') {
                                                        $data_to_treat['montant'] = $amount_paid_occ[$key];
                                                        $data_to_treat['type'] = $type;

                                                        $instructions[] = $this->seguceModel->get_instructions_partial_seguce_debit_by_licence_number_regul($data_to_treat, $comptes, $compte_suspens_provision, $compte_client);
                                                }

                                                if ($type == 'CTC') {
                                                        $data_to_treat['montant'] = $amount[$key];
                                                        $data_to_treat['type'] = "";

                                                        $instructions[] = $this->seguceModel->get_instructions_partial_seguce_debit_by_licence_number_regul($data_to_treat, $comptes, $compte_suspens_provision, $compte_client);
                                                }
                                        }

                                        foreach ($row as $cle => $ligne) {

                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                        $amount_recipe = 0;
                                                        foreach ($ligne as $value) {
                                                                $data_propre['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $data_propre['Status_2'] = '0';
                                                                $data_propre['Account_3'] = $this->session->userdata['account_id'];
                                                                $data_propre['Makerid_9'] = $this->session->userdata['user_id'];
                                                                $data_propre['Logirefid_4'] = $logirefid = rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');
                                                                $data_propre['Contrevaleur_22'] = $value * $taux;
                                                                $data_propre['Montant_11'] = $value;
                                                                $data_propre['Devise_12'] = $data_to_treat['devise'];
                                                                $data_propre['Typerecette_17'] = $cle;
                                                                $data_propre['Tresor_45'] = '0';
                                                                $data_propre['Beneficaire_15'] = 'OCC';
                                                                $data_propre['Designation_14'] = $data_to_treat['designation'];
                                                                $data_propre['Mode_19 '] = '7';
                                                                $data_propre['Agence_20'] = $this->session->get('Logiref_agence');
                                                                $data_propre['Guichet_21'] = $this->session->get('Logiref_guichet');
                                                                $data_propre['Noteid_26'] = $key;
                                                                $data_propre['Notedate_27'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                $data_propre['Notemontant_28'] = $data_to_treat['MontantCIF_9'];
                                                                $data_propre['Notedevise_29 '] = $data_to_treat['devise'];
                                                                $data_propre['Notereference_30 '] = $ref_bordereau;
                                                                $data_propre['Datevaleur_31'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                $data_propre['Invoice_54'] = $licence_id;

                                                                $this->encaissementModel->save_payment_propres($data_propre, NULL);

                                                                if ($cle == 'CPO') {
                                                                        $comm_occ = ($value * 0.232) / 100;
                                                                        $tva_occ = $comm_occ * 0.16;
                                                                        $amount_recipe = $value - ($comm_occ + $tva_occ);
                                                                } elseif ($cle == 'CPB') {
                                                                        $comm_bivac = ($value * 0.116) / 100;
                                                                        $tva_bivac = $comm_bivac * 0.16;
                                                                        $amount_recipe = $value - ($comm_bivac + $tva_bivac);
                                                                } else {
                                                                        $amount_recipe = $value;
                                                                }
                                                        }

                                                        $data_to_treat['licence'] = $key;
                                                        $type = $cle;

                                                        $data_to_treat['montant'] = $this->data('get_reduce_decimal', $amount_recipe, 2);

                                                        //$instructions[] = $this->seguce_model->get_partial_instructions_seguce_by_licence_number($data_to_treat, $comptes, $data_to_treat['customer_account'], $type);
                                                        $instructions[] = $this->seguceModel->get_partial_instructions_seguce_by_licence_number($data_to_treat, $comptes, $compte_suspens_provision, $type);

                                                        if (!empty($instructions)) {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 1;

                                                                $end_execution = $this->seguceModel->save_instructions_invoice_occ($licence_id, $instructions, $logirefid, $priority);
                                                                unset($instructions);
                                                        }
                                                }
                                        }
                                }

                                $types = array();

                                foreach ($invoices as $key => $row) {
                                        $frais_bancaire_occ = 0;
                                        $frais_tva_occ = 0;
                                        $frais_bancaire_bivac = 0;
                                        $frais_tva_bivac = 0;

                                        foreach ($row as $cle => $ligne) {
                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                        foreach ($ligne as $value) {
                                                                if ($cle == 'CPO') {
                                                                        $frais_bancaire_occ = ($value * 0.232) / 100;
                                                                        $frais_tva_occ = $frais_bancaire_occ * 0.16;
                                                                        $types[] = $cle;
                                                                }

                                                                if ($cle == 'CPB') {
                                                                        $frais_bancaire_bivac = ($value * 0.116) / 100;
                                                                        $frais_tva_bivac = $frais_bancaire_bivac * 0.16;
                                                                        $types[] = $cle;
                                                                }
                                                        }
                                                }
                                        }

                                        $data_to_frais['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                        $data_to_frais['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";

                                        foreach ($types as $type) {
                                                if ($type == 'CPO') {
                                                        $data_to_frais['montant_fb'] = $this->data('get_reduce_decimal', $frais_bancaire_occ, 2);
                                                        $data_to_frais['montant_tva'] = $this->data('get_reduce_decimal', $frais_tva_occ, 2);
                                                        $data_to_frais['type'] = $type;
                                                }

                                                if ($type == 'CPB') {
                                                        $data_to_frais['montant_fb'] = $this->data('get_reduce_decimal', $frais_bancaire_bivac, 2);
                                                        $data_to_frais['montant_tva'] = $this->data('get_reduce_decimal', $frais_tva_bivac, 2);
                                                        $data_to_frais['type'] = $type;
                                                }


                                                $instruction_partial = $this->seguceModel->get_frais_bancaire_instructions_seguce_debit_by_licence_number($data_to_frais, $comptes);

                                                if (!empty($instruction_partial)) {
                                                        # priority for integrating the counting in cbs
                                                        $priority = 1;

                                                        $this->seguceModel->save_instructions_invoice_occ($licence_id, $instruction_partial, $logirefid, $priority);

                                                        unset($instruction_partial);
                                                }
                                        }
                                }
                        }

                        if (isset($end_execution) && $end_execution != "") {
                                return "E200";
                        }
                        elseif (isset($end_save) && $end_save != "") {
                                return "E200";
                        }
                        else {
                                return 0;
                        }
                }
                elseif ($obj == "regul_invoice")
                {
                        $data['designation'] = $_POST['designation'];
                        $data['code_import'] = $_POST['code_import'];
                        $data['num_bordereau'] = $_POST['num_bordereau'];
                        $data['date_bordereau'] = $_POST['date_bordereau'];
                        $data['customer_account'] = $_POST['customer_account'];
                        $data['currency'] = $_POST['account_currency'];
                        $data['montant'] = $_POST['amount_to_extourne'];

                        $data['compte_provision'] = $_POST['compte_provision'];
                        $data['devise'] = 'USD';
                        $data['invoice_regulId'] = $_POST['invoice_regulId'];

                        $instructions[] = $this->seguceModel->get_instructions_invoice_regularization($data);

                        $ref = rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        $priority = 0;

                        if (!empty($instructions)) {
                                $this->seguceModel->save_instructions_invoice_occ_regul($data['invoice_regulId'], $instructions, $ref, $priority);
                        }

                        return $data['invoice_regulId'];
                } 
                elseif ($obj == 'invoice_occ_batchs') 
                {
                        $data = array();

                        $date = new DateTime();
                        $date = $date->format('Y-m-d');

                        $reference = mt_rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');

                        if ($_SESSION['Logiref_role'] == 4) {
                                $inserdata = array();
                                $allData = $_POST['allDatas'];
                                $i = 1;

                                foreach ($allData as $key => $value) {
                                        $inserdata[$i]['code_import'] = $_POST['codes'][$value];
                                        $inserdata[$i]['nom_importateur'] = $_POST['noms'][$value];
                                        $inserdata[$i]['date_bordereau'] = $_POST['dates'][$value];
                                        $inserdata[$i]['numero_licenses'] = $_POST['licenses'][$value];
                                        $inserdata[$i]['devises'] = $_POST['devises'][$value];

                                        $inserdata[$i]['frais_cif'] = $_POST['cif'][$value];
                                        $inserdata[$i]['frais_ctrl'] = $_POST['ctrl'][$value];
                                        $inserdata[$i]['frais_occ'] = $_POST['occ'][$value];
                                        $inserdata[$i]['frais_bivac'] = $_POST['bivac'][$value];
                                        $inserdata[$i]['frais_tva_ctrl'] = $_POST['tva_ctrl'][$value];
                                        $inserdata[$i]['livraison'] = $_POST['livraison'][$value];

                                        $i++;
                                }

                                $data['Date_1'] = date('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4 '] = $this->session->userdata['user_id'];

                                $data['Codebank_7'] = $_POST['code_banque'];
                                $data['Siglebank_8'] = $_POST['sigle_banque'];
                                $data['Numbordereau_9'] = $_POST['num_bordereau'];
                                $data['Date_10'] = $_POST['date_bordereau'];
                                $data['Licenses_11'] = json_encode($inserdata);
                                $data['Files_12'] = $_POST['path_file'];
                                $data['Date_13'] = $_POST['date_edit'];
                                $data['Agence_14'] = $_SESSION['Logiref_agence'];
                                $data['Guichet_15'] = $_SESSION['Logiref_guichet'];
                                $data['Reference_16'] = $reference;
                                $data['DateReceipt_17'] = (!empty($_POST['DateReceipt_17']))?$_POST['DateReceipt_17']:"";
                                $data['Environment_18'] = 'L';

                                #Validation section
                                //$data['Changes_5'] = '0000-00-00';
                                $data['Changer_6'] = 0;
                        }
                        else {
                                $data['Status_2'] = 2;
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                $data['Changes_5'] = date('Y-m-d H:i:s');
                        }

                        $result = $this->seguceModel->save_invoice_occ_batchs($data, $id);

                        if ($result) {
                                if ($id != "") :
                                        echo '<div class="alert alert-success">Donn&eacute;e valider avec succ&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                else :
                                        echo '<div class="alert alert-success">Donn&eacute;e enr&eacute;gistrer avec succ&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                endif;
                        } else {
                                echo '<div class="alert alert-danger">Ce type fichier n\'est pas autoris&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                elseif ($obj == 'invoice_occ')
                {

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Creator_4'] = $this->session->userdata['user_id'];

                        $customer_account = $this->seguceModel->get_dropdown("provision_current_account");

                        $instructions = array();

                        $data_to_treat = array();
                        $data_propre = array();
                        $amounts = array();
                        $data_clt = array();

                        # Retrieve the batch ID
                        $invoice_batchId = $_POST['invoice_batchId'];

                        $date_bordereau = explode('-', $_POST['date_bordereau']);
                        $annee_bordereau = $date_bordereau[0];
                        $reference_bordereau = $invoice_batchId . "" . $_POST['num_bordereau'] . "" . $annee_bordereau;

                        # Retrieve the exchange rate
                        $result = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                $taux = $result['Dollar_4'];
                        } else {
                                $taux = 1;
                        }

                        # Generation of transactions based on each licence number
                        $agence_src = $this->session->get('Logiref_guichet');
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        if(isset($comptes['TMB']['CPF']['USD'])){
                              $compte_provision = $comptes['TMB']['CPF']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CPF']['USD']))
                        {
                              $compte_provision = $comptes['Rawbank']['CPF']['USD'];
                        }
                        else{
                              $compte_provision = '00000000000000000000000';
                        }

                        if(isset($comptes['TMB']['CSP']['USD'])){
                             $compte_suspens_provision = $comptes['TMB']['CSP']['USD'];
                        }
                        elseif(isset($comptes['Rawbank']['CSP']['USD']))
                        {
                             $compte_suspens_provision = $comptes['Rawbank']['CSP']['USD'];
                        }
                        else{
                             $compte_suspens_provision = '00000000000000000000000';
                        }


                        if(!empty($_POST['balances']))
                        {
                                if (isset($_POST['datas']) && $_POST['datas'] != "")
                                {
                                        $customers = json_decode($_POST['customers'], true);
                                        $customer_clt = json_decode($_POST['customer_clt'], true);
                                        $compte_clients = json_decode($_POST['compte_clients'], true);
                                        $devise_comptes = json_decode($_POST['devise_comptes'], true);
                                        $missing_amount = json_decode($_POST['missing_amount'], true);
                                        $missing_amounts_exempt = json_decode($_POST['missing_amounts_exempt'], true);
                                        $balances = json_decode($_POST['balances'], true);

                                        $data_to_treat['compte_provision'] = $compte_provision;
                                        $data_to_treat['devise'] = "USD";
                                        $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";

                                        $invoices = json_decode($_POST['datas'], true);

                                        $amounts = array();

                                        if(array_key_exists('eximtrade_select_license_for_processing_and_validation_of_slip',$this->functionalities['ALL']))
                                        {
                                                $surplus_amounts = json_decode($_POST['surplus_amount'], true);

                                                foreach ($invoices as $clt => $line)
                                                {
                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;
                                                        $total_occ_tva = 0;

                                                        $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";

                                                        if ($data_to_treat['account_currency']  == "CDF")
                                                        {
                                                                $customer_balance = $balances[$clt]  * $result['Dollar_4'];
                                                        }
                                                        else if ($data_to_treat['account_currency'] == 'EUR')
                                                        {
                                                                $customer_balance = $balances[$clt] * $result['Dollar_4'];
                                                                $customer_balance = $customer_balance / $result['Euro_5'];
                                                        }
                                                        else
                                                        {
                                                                $customer_balance = $balances[$clt];
                                                        }

                                                        $data_licenses = array_keys($line);
                                                        foreach($data_licenses as $license)
                                                        {
                                                                //$surplus_amount = isset($surplus_amounts[$clt][$license]) ? $surplus_amounts[$clt][$license] : "";
                                                                $surplus_amount = isset($surplus_amounts[$license]) ? $surplus_amounts[$license] : "";

                                                                # EXTOURNE DE LA PROVISION
                                                                if (isset($surplus_amount) && $surplus_amount > 0)
                                                                {
                                                                        $data_to_treat['montant'] = $surplus_amount;
                                                                        $data_to_treat['licence'] = $license;

                                                                        $instructions[$license][] = $this->seguceModel->get_instructions_provision_reverse_by_customer($data_to_treat);
                                                                }

                                                                # COMPLEMENT DU MONTANT MANQUANT DANS LE COMPTE PROVISION
                                                                if (isset($missing_amount[$license]) && $customer_balance >= $missing_amount[$license])
                                                                {
                                                                        $data_to_treat['montant'] = $missing_amount[$license];
                                                                        $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                                        $data_to_treat['licence'] = $license;

                                                                        $instructions[$license][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data_to_treat, $compte_provision);
                                                                }
                                                        }

                                                        foreach($line as $key => $row)
                                                        {
                                                                foreach($row as $cle=>$ligne)
                                                                {
                                                                        if (!in_array($cle, ['valeur_cif', 'livraison', 'CFC', 'montantprov', 'devise']))
                                                                        {
                                                                                $amount_occ = 0;
                                                                                $amount_bivac = 0;
                                                                                $amount_occ_tva = 0;

                                                                                foreach ($ligne as $value)
                                                                                {
                                                                                        if ($cle == 'CPO') $amount_occ = $value;
                                                                                        elseif ($cle == 'CPB') $amount_bivac = $value;
                                                                                        elseif ($cle == 'CTC') $amount_occ_tva = $value;
                                                                                }

                                                                                if (!isset($amounts[$key]))
                                                                                {
                                                                                        $amounts[$key] = ['CPO' => 0, 'CPB' => 0, 'CTC' => 0];
                                                                                }

                                                                                $amounts[$key]['CPO'] += $amount_occ + $amount_occ_tva;
                                                                                $amounts[$key]['CPB'] += $amount_bivac;
                                                                                $amounts[$key]['CTC'] += $amount_occ_tva;
                                                                        }
                                                                }
                                                        }
                                                }

                                                # CALCUL DES MONTANTS TOTAUX DES FRAIS OCC-BIVAC ET TVA L'OCC
                                                foreach ($amounts as $aKey => $amount)
                                                {
                                                        foreach($amount as $keys => $val)
                                                        {
                                                                $clt =  (isset($licence_clt[$aKey])) ? $licence_clt[$aKey] : "";
                                                                $data_to_treat['designation'] = isset($customer_clt[$clt]) ? $customer_clt[$clt] : "";
                                                                $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                                $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                        }

                                                        $data_to_treat['licence'] = $aKey;

                                                        if ((isset($missing_amounts_exempt[$aKey]) && $missing_amounts_exempt[$aKey] != "") || (isset($amounts_noprovision[$aKey]) && $amounts_noprovision[$aKey] != ""))
                                                        {
                                                                foreach($amount as $keys => $val)
                                                                {
                                                                        $type = $keys;

                                                                        $data_to_treat['montant'] = $val;

                                                                        $clt =  (isset($licence_clt[$aKey])) ? $licence_clt[$aKey] : "";

                                                                        // $data_to_treat['designation'] = isset($customer_clt[$aKey]) ? $customer_clt[$aKey] : "";
                                                                        // $data_to_treat['customer_account'] = isset($compte_clients[$aKey]) ? $compte_clients[$aKey] : "";
                                                                        // $data_to_treat['account_currency'] = isset($devise_comptes[$aKey]) ? $devise_comptes[$aKey] : "";

                                                                        $data_to_treat['designation'] = isset($customer_clt[$clt]) ? $customer_clt[$clt] : "";
                                                                        $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";

                                                                        if ($type != 'CTC')
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data_to_treat, $comptes, $type);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                foreach($amount as $keys => $val)
                                                                {
                                                                        $type = $keys;

                                                                        $data_to_treat['montant'] = $val;
                                                                        $data_to_treat['designation'] = isset($customer_clt[$aKey]) ? $customer_clt[$aKey] : "";

                                                                        if ($type != 'CTC')
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data_to_treat, $comptes, $compte_provision, $type);
                                                                        }
                                                                        else
                                                                        {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                                        }
                                                                }
                                                        }
                                                }

                                        }
                                        else
                                        {
                                                //$surplus_amounts = json_decode($_POST['surplus_amount'], true);
                                                $surplus_amounts = json_decode($_POST['surplus_amount2'], true);

                                                foreach ($invoices as $clt => $line) {
                                                        $data_clt['clt_to_paid'][$clt] = "TRUE";

                                                        $total_amount_occ = 0;
                                                        $total_amount_bivac = 0;
                                                        $total_occ_tva = 0;

                                                        $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";

                                                        if ($data_to_treat['account_currency']  == "CDF") {
                                                                $customer_balance = $balances[$clt]  * $result['Dollar_4'];
                                                        } else if ($data_to_treat['account_currency'] == 'EUR') {
                                                                $customer_balance = $balances[$clt] * $result['Dollar_4'];
                                                                $customer_balance = $customer_balance / $result['Euro_5'];
                                                        } else {
                                                                $customer_balance = $balances[$clt];
                                                        }

                                                        $data_licenses = array_keys($line);
                                                        foreach ($data_licenses as $license) {
                                                                $surplus_amount = isset($surplus_amounts[$clt][$license]) ? $surplus_amounts[$clt][$license] : "";

                                                                # EXTOURNE DE LA PROVISION
                                                                if (isset($surplus_amount) && $surplus_amount > 0) {
                                                                        $data_to_treat['montant'] = $surplus_amount;
                                                                        $data_to_treat['licence'] = $license;

                                                                        $instructions[$clt][$license] = $this->seguceModel->get_instructions_provision_reverse_by_customer($data_to_treat);
                                                                }
                                                        }

                                                        # COMPLEMENT DU MONTANT MANQUANT DANS LE COMPTE PROVISION
                                                        if (isset($missing_amount[$clt]) && $customer_balance >= $missing_amount[$clt]) {
                                                                $data_to_treat['montant'] = $missing_amount[$clt];
                                                                $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                                $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";

                                                                $instructions[$clt][]  = $this->seguceModel->get_instructions_provision_complement_by_customer($data_to_treat, $compte_provision);
                                                        }

                                                        foreach ($line as $key => $row) {
                                                                foreach ($row as $cle => $ligne) {
                                                                        if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                                $amount_occ = 0;
                                                                                $amount_bivac = 0;
                                                                                $amount_occ_tva = 0;

                                                                                foreach ($ligne as $value) {
                                                                                        if ($cle == 'CPO') $amount_occ += $value;
                                                                                        if ($cle == 'CPB') $amount_bivac += $value;
                                                                                        if ($cle == 'CTC') $amount_occ_tva += $value;
                                                                                }

                                                                                $total_amount_occ += $amount_occ;
                                                                                $total_amount_bivac += $amount_bivac;
                                                                                $total_occ_tva += $amount_occ_tva;

                                                                                $amounts[$clt]['CPO'] = $total_amount_occ;
                                                                                $amounts[$clt]['CPB'] = $total_amount_bivac;
                                                                                $amounts[$clt]['CTC'] = $total_occ_tva;
                                                                        }
                                                                }
                                                        }
                                                }

                                                # CALCUL DES MONTANTS TOTAUX DES FRAIS OCC-BIVAC ET TVA L'OCC
                                                foreach ($amounts as $aKey => $amount) {
                                                        if (isset($missing_amounts_exempt[$aKey]) && $missing_amounts_exempt[$aKey] != "") {
                                                                foreach ($amount as $keys => $val) {
                                                                        $type = $keys;

                                                                        $data_to_treat['montant'] = $val;
                                                                        $data_to_treat['designation'] = isset($customer_clt[$aKey]) ? $customer_clt[$aKey] : "";
                                                                        $data_to_treat['customer_account'] = isset($compte_clients[$aKey]) ? $compte_clients[$aKey] : "";
                                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$aKey]) ? $devise_comptes[$aKey] : "";

                                                                        if ($type != 'CTC') {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number_without_provision($data_to_treat, $comptes, $type);
                                                                        } else {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                                        }
                                                                }
                                                        } else {
                                                                foreach ($amount as $keys => $val) {
                                                                        $type = $keys;

                                                                        $data_to_treat['montant'] = $val;
                                                                        $data_to_treat['designation'] = isset($customer_clt[$aKey]) ? $customer_clt[$aKey] : "";

                                                                        if ($type != 'CTC') {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_seguce_by_licence_number($data_to_treat, $comptes, $compte_provision, $type);
                                                                        } else {
                                                                                $instructions[$aKey][] = $this->seguceModel->get_instructions_occ_tva_debit_by_customer($data_to_treat, $comptes);
                                                                        }
                                                                }
                                                        }
                                                }
                                        }

                                        /**
                                         * ATTENTION: A N'EST PAS SUPPRIME
                                         */

                                        /*foreach ($invoices as $clt => $line)
                                        {
                                                $data_to_treat['montant'] = 10;

                                                $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                $data_to_treat['designation'] = isset($customer_clt[$clt]) ? $customer_clt[$clt] : "";
                                                $data_to_treat['montant_tva'] = $data_to_treat['montant'] * 0.16;

                                                $fees_amount = $data_to_treat['montant'] + $data_to_treat['montant_tva'];

                                                if ($data_to_treat['account_currency']  == "CDF")
                                                {
                                                        $customer_balance = $balances[$clt]  * $result['Dollar_4'];

                                                        $data_to_treat['Priority'] = ($customer_balance > $fees_amount) ? 1 : 0;
                                                }
                                                else if ($data_to_treat['account_currency'] == 'EUR')
                                                {
                                                        $customer_balance = $balances[$clt] * $result['Dollar_4'];
                                                        $customer_balance = $customer_balance / $result['Euro_5'];

                                                        $data_to_treat['Priority'] = ($customer_balance > $fees_amount) ? 1 : 0;
                                                }
                                                else
                                                {
                                                        $data_to_treat['Priority'] = ($balances[$clt] > $fees_amount) ? 1 : 0;
                                                }

                                                $instructions_fees  = $this->seguceModel->get_instructions_occ_bivac_debit_bank_fees_by_customer($data_to_treat, $comptes);

                                                foreach ($instructions_fees as $instruction)
                                                {
                                                         $instructions[$clt][] = $instruction;
                                                }

                                        }*/

                                        foreach ($invoices as $clt => $line)
                                        {

                                                foreach ($line as $key => $row)
                                                {
                                                        $customers = json_decode($_POST['customers'], true);
                                                        $compte_clients = json_decode($_POST['compte_clients'], true);
                                                        $devise_comptes = json_decode($_POST['devise_comptes'], true);
                                                        $missing_amount = json_decode($_POST['missing_amount'], true);

                                                        $compte_client = isset($customer_account[$key]) ? $customer_account[$key] : "000000000000000000000000";

                                                        $data['Bank_7'] = isset($_POST['code_bank']) ? $_POST['code_bank'] : "";
                                                        $data['Licence_8'] = $key;
                                                        $data['Designation_13'] = $data_to_treat['designation'] = isset($customers[$key]) ? $customers[$key] : "";
                                                        $data['Codeimport_12'] = $data_to_treat['code_import'] = $clt;
                                                        $data['Numbordereau_14'] = $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                                        $data['Datebordereau_15'] = $data_to_treat['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                                        $data['MontantCIF_9'] = $data_to_treat['MontantCIF_9'] = isset($row['valeur_cif'][0]) ? $row['valeur_cif'][0] : "";
                                                        $data['Devise_10'] = "USD";
                                                        $data['Result_11'] = json_encode($line);
                                                        $data['Compte_16'] = $compte_provision;
                                                        $data['Devise_17'] = "USD";
                                                        $data['Compte_19'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "000000000000000000000000";
                                                        $data['Devise_20'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                        $data['Siglebank_22'] = $_POST['sigle'];
                                                        $data['BatchId_23'] = $invoice_batchId;

                                                        $licence_id = $this->seguceModel->save_invoice_occ($data, NULL);

                                                        $date_bordereau = explode('-', $data_to_treat['date_bordereau']);
                                                        $ref_bordereau = $data_to_treat['num_bordereau'] . '/' . $date_bordereau[0];

                                                        foreach ($row as $cle => $ligne) {
                                                                if ($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise') {
                                                                        foreach ($ligne as $value) {
                                                                                $data_propre['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                $data_propre['Status_2'] = '1';
                                                                                $data_propre['Account_3'] = $this->session->userdata['account_id'];
                                                                                $data_propre['Makerid_9'] = $this->session->userdata['user_id'];
                                                                                $data_propre['Logirefid_4'] = $logirefid = rand(1, 99) . date('H') . date('i') . date('s') . date('j') . date('m') . date('y');
                                                                                $data_propre['Contrevaleur_22'] = $value * $taux;
                                                                                $data_propre['Montant_11'] = $value;
                                                                                $data_propre['Devise_12'] = $data_to_treat['devise'];
                                                                                $data_propre['Typerecette_17'] = $cle;
                                                                                $data_propre['Tresor_45'] = '0';
                                                                                $data_propre['Beneficaire_15'] = 'OCC';
                                                                                $data_propre['Designation_14'] = $data_to_treat['designation'];
                                                                                $data_propre['Mode_19 '] = '7';
                                                                                $data_propre['Agence_20'] = $this->session->get('Logiref_agence');
                                                                                $data_propre['Guichet_21'] = $this->session->get('Logiref_guichet');
                                                                                $data_propre['Noteid_26'] = $key;
                                                                                $data_propre['Notedate_27'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                                $data_propre['Notemontant_28'] = $data_to_treat['MontantCIF_9'];
                                                                                $data_propre['Notedevise_29 '] = $data_to_treat['devise'];
                                                                                $data_propre['Notereference_30 '] = $ref_bordereau;
                                                                                $data_propre['Datevaleur_31'] = $data_to_treat['date_bordereau'];
                                                                                $data_propre['Invoice_54'] = $licence_id;

                                                                                $this->encaissementModel->save_seguce_payment_propres($data_propre, NULL);
                                                                        }
                                                                }
                                                        }
                                                }

                                                if (!empty($instructions)) {
                                                        foreach ($instructions as $iKey => $instruction) {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 1;

                                                                $end_execution = $this->seguceModel->save_instructions_invoice_occ($invoice_batchId, $instruction, $logirefid, $priority, $iKey);

                                                                unset($instructions);
                                                        }
                                                }
                                        }
                                }

                                if (isset($_POST['licence_issues']) && $_POST['licence_issues'] != "") {
                                        $data_issues = array();

                                        $data_issues['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_issues['Status_2'] = '1';
                                        $data_issues['Account_3'] = $this->session->userdata['account_id'];
                                        $data_issues['Creator_4'] = $this->session->userdata['user_id'];
                                        $data_issues['Numbordereau_9'] =  isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                        $data_issues['Datebordereau_11'] =  isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                        $data_issues['BatchId_12'] =  $invoice_batchId;

                                        $licence_issues = isset($_POST['licence_issues']) ? json_decode($_POST['licence_issues'], true) : array();

                                        foreach ($licence_issues as $key => $row) {
                                                if (isset($_POST['customer_issues']) && $_POST['customer_issues'] != "") {
                                                        $customers_issues = json_decode($_POST['customer_issues'], true);
                                                        $data_issues['Designation_7'] = isset($customers_issues[$key]) ? $customers_issues[$key] : "";
                                                }

                                                $data_issues['CodeImport_8'] = $key;
                                                $data_issues['Result_10'] = json_encode($row);

                                                $end_save = $this->seguceModel->save_invoice_occ_issues($data_issues, NULL);
                                        }
                                }
                        }
                        else{
                                if(isset($_POST['datas']) && $_POST['datas'] !="")
                                {
                                        $invoices = json_decode($_POST['datas'], true);

                                        $amounts = array();

                                        # Calcul du montant total de chaque licence avec provision suffisante
                                        foreach ($invoices as $clt=>$line)
                                        {
                                                foreach($line as $key=>$row)
                                                {
                                                        $total_amount_licence = 0;

                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                $amount_recipe = $amount_recipe + $value;
                                                                        }
                                                                        $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                }
                                                        }

                                                        $amount[$key] = $total_amount_licence;
                                                }
                                        }

                                        $comm_occ = 0;
                                        $comm_bivac = 0;
                                        $tva_occ = 0;
                                        $tva_bivac = 0;
                                        $amount_bivac = 0;
                                        $amount_occ = 0;

                                        foreach($invoices as $clt=>$line)
                                        {
                                                foreach($line as $key=>$row)
                                                {
                                                        $customers = json_decode($_POST['customers'], true);
                                                        $compte_clients = json_decode($_POST['compte_clients'], true);
                                                        $devise_comptes = json_decode($_POST['devise_comptes'], true);

                                                        $compte_provision = isset($account_provision[$key]) ? $account_provision[$key] : "000000000000000000000000";
                                                        $compte_client = isset($customer_account[$key]) ? $customer_account[$key] : "000000000000000000000000";

                                                        $data['Bank_7'] = isset($_POST['code_bank']) ? $_POST['code_bank'] : "";
                                                        $data['Licence_8'] = $key;
                                                        $data['Designation_13'] = $data_to_treat['designation'] = isset($customers[$key]) ? $customers[$key] : "";
                                                        $data['Codeimport_12'] = $data_to_treat['code_import'] = $clt;
                                                        $data['Numbordereau_14'] = $data_to_treat['num_bordereau'] = isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                                        $data['Datebordereau_15'] = $data_to_treat['date_bordereau'] = isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                                        $data['MontantCIF_9'] = $data_to_treat['MontantCIF_9'] = isset($row['valeur_cif'][0]) ? $row['valeur_cif'][0] : "";
                                                        $data['Devise_10'] = $data_to_treat['devise'] = "USD";
                                                        $data['Result_11'] = json_encode($line);
                                                        $data['Compte_16'] = $compte_provision;
                                                        $data['Devise_17'] = "USD";
                                                        $data['Compte_19'] = $compte_client;
                                                        $data['Devise_20'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                        $data['Siglebank_22'] = $_POST['sigle'];
                                                        $data['BatchId_23'] = $invoice_batchId ;
                                                        $data['Environment_24'] = 'L' ;
                                                        $data['Agence_25'] = $_SESSION['Logiref_agence'];
                                                        $data['Guichet_26'] = $_SESSION['Logiref_guichet'];

                                                        $licence_id = $this->seguceModel->save_invoice_occ($data, NULL);

                                                        $provision_amount = $this->seguceModel->get_dropdown("licence_provision");

                                                        if(isset($row['livraison'][0]) && $row['livraison'][0] == 'T')
                                                        {
                                                                if(($provision_amount[$key] > $row['montantprov'][0]) || $provision_amount[$key] == $row['montantprov'][0])
                                                                {
                                                                        $data_to_treat['amount_provision'] = isset($provision_amount[$key]) ? $provision_amount[$key] : $amount[$key];
                                                                        $data_to_treat['montant'] = $amount[$key];
                                                                }
                                                                else
                                                                {
                                                                        $amount_missing = $amount[$key] - $provision_amount[$key];

                                                                        $data_to_treat['amount_provision'] = isset($provision_amount[$key]) ? $provision_amount[$key] : $amount[$key];
                                                                        $data_to_treat['montant'] = $amount[$key];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $provision_amount_value = isset($provision_amount[$key]) ? $provision_amount[$key] : "0";

                                                                if($provision_amount_value >= $amount[$key])
                                                                {
                                                                        $data_to_treat['amount_provision'] = $amount[$key];
                                                                        $data_to_treat['montant'] = $amount[$key];
                                                                }
                                                                else
                                                                {
                                                                        $data_to_treat['amount_provision'] = $provision_amount_value;
                                                                        $data_to_treat['montant'] = $amount[$key];
                                                                }

                                                        }

                                                        $data_to_treat['licence'] = $key;
                                                        $data_to_treat['code_import'] = $clt;
                                                        $data_to_treat['customer_account'] = isset($compte_clients[$clt]) ? $compte_clients[$clt] : "";
                                                        $data_to_treat['account_currency'] = isset($devise_comptes[$clt]) ? $devise_comptes[$clt] : "";
                                                        $data_to_treat['account_provision_currency'] = isset($account_provision_currency[$key]) ? $account_provision_currency[$key] : "";
                                                        $data_to_treat['customer_account_currency'] = isset($customer_account_currency[$key]) ? $customer_account_currency[$key] : "";

                                                        if(isset($provision_amount[$key]) && $provision_amount[$key] > 0)
                                                        {
                                                                $return = $this->seguceModel->get_instructions_seguce_debit_by_licence_number1($data_to_treat, $comptes, $compte_provision, $compte_client);
                                                        }
                                                        else
                                                        {
                                                                $compte_client = $data_to_treat['customer_account'];
                                                                $return = $this->seguceModel->get_instructions_seguce_debit_by_licence_number_without_provision1($data_to_treat, $comptes, $compte_provision, $compte_client);

                                                        }

                                                        foreach ($return as $instruction)
                                                        {
                                                                $instructions[] = $instruction;
                                                        }

                                                        $date_bordereau = explode('-', $data_to_treat['date_bordereau']);
                                                        $ref_bordereau = $data_to_treat['num_bordereau'].'/'.$date_bordereau[0];

                                                        foreach($row as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                $data_propre['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                $data_propre['Status_2'] = '1';
                                                                                $data_propre['Account_3'] = $this->session->userdata['account_id'];
                                                                                $data_propre['Makerid_9'] = $this->session->userdata['user_id'];
                                                                                $data_propre['Logirefid_4'] = $logirefid = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                                                                $data_propre['Contrevaleur_22'] = $value * $taux;
                                                                                $data_propre['Montant_11'] = $value;
                                                                                $data_propre['Devise_12'] = $data_to_treat['devise'];
                                                                                $data_propre['Typerecette_17'] = $cle;
                                                                                $data_propre['Tresor_45'] = '0';
                                                                                $data_propre['Beneficaire_15'] = 'OCC';
                                                                                $data_propre['Designation_14'] = $data_to_treat['designation'];
                                                                                $data_propre['Mode_19 '] = '7';
                                                                                $data_propre['Agence_20'] = $_SESSION['Logiref_agence'];
                                                                                $data_propre['Guichet_21'] = $_SESSION['Logiref_guichet'];
                                                                                $data_propre['Noteid_26'] = $key;
                                                                                $data_propre['Notedate_27'] = isset($data_to_treat['date_bordereau']) ? $data_to_treat['date_bordereau'] : "";
                                                                                $data_propre['Notemontant_28'] = $data_to_treat['MontantCIF_9'];
                                                                                $data_propre['Notedevise_29 '] = $data_to_treat['devise'];
                                                                                $data_propre['Notereference_30 '] = $ref_bordereau;
                                                                                $data_propre['Datevaleur_31'] = $data_to_treat['date_bordereau'];
                                                                                $data_propre['Invoice_54'] = $licence_id;
                                                                                $data_propre['Environment_55'] = 'L';

                                                                                $this->encaissementModel->save_seguce_payment_propres($data_propre, NULL);

                                                                                if ($cle == 'CPO')
                                                                                {
                                                                                        $amount_occ = $value;
                                                                                        $comm_occ = ($amount_occ * 0.232)/100;
                                                                                        $tva_occ = $comm_occ * 0.16;

                                                                                        $amount_recipe = $amount_occ - ($comm_occ + $tva_occ);
                                                                                }
                                                                                elseif ($cle == 'CPB')
                                                                                {
                                                                                        $amount_bivac = $value;
                                                                                        $comm_bivac = ($amount_bivac * 0.116)/100;
                                                                                        $tva_bivac = $comm_bivac * 0.16;

                                                                                        $amount_recipe = $amount_bivac - ($comm_bivac + $tva_bivac);
                                                                                }
                                                                                else
                                                                                {
                                                                                        $amount_recipe = $value;
                                                                                }

                                                                                $amounts[$key]['CPO'] = $amount_occ;
                                                                                $amounts[$key]['CPB'] = $amount_bivac;
                                                                        }

                                                                        $frais_bancaire_partial = $comm_occ + $comm_bivac;
                                                                        $frais_tva_partial = $tva_occ + $tva_bivac;

                                                                        $data_to_treat['licence'] = $key;
                                                                        $type = $cle;

                                                                        $data_to_treat['montant'] = $this->data('get_reduce_decimal', $amount_recipe , 2);

                                                                        $data_to_treat['montant_fb'] = $this->data('get_reduce_decimal', $frais_bancaire_partial , 3);
                                                                        $data_to_treat['montant_tva'] = $this->data('get_reduce_decimal', $frais_tva_partial , 3);

                                                                        $instructions[] = $this->seguceModel->get_instructions_seguce_by_licence_number1($data_to_treat, $comptes, $compte_suspens_provision, $type);

                                                                        if(!empty($instructions))
                                                                        {
                                                                                # priority for integrating the counting in cbs
                                                                                $priority = 1;

                                                                                $end_execution = $this->seguceModel->save_instructions_invoice_occ($invoice_batchId, $instructions, NULL, $priority, $clt);

                                                                                unset($instructions);
                                                                        }
                                                                }
                                                        }

                                                        $instruction_partial = $this->seguceModel->get_frais_bancaire_instructions_seguce_debit_by_licence_number1($data_to_treat, $comptes);

                                                        if(!empty($instruction_partial))
                                                        {
                                                                # priority for integrating the counting in cbs
                                                                $priority = 0;

                                                                $this->seguceModel->save_instructions_invoice_occ($invoice_batchId, $instruction_partial, NULL, $priority, $clt);

                                                                unset($instruction_partial);
                                                        }
                                                }
                                        }

                                        $total_amount_occ = 0;
                                        $total_amount_bivac = 0;

                                        foreach($amounts as $aKey => $aVal)
                                        {
                                                foreach ($aVal as $cle => $value)
                                                {
                                                        if ($cle == 'CPO') $total_amount_occ += $value;
                                                        if ($cle == 'CPB') $total_amount_bivac += $value;
                                                }
                                        }

                                        #Calcul de commission OCC & BIVAC
                                        $com_occ = $this->data("get_occ_bivac_commission", "OCC",  $total_amount_occ);
                                        $com_bivac = $this->data("get_occ_bivac_commission", "BIVAC", $total_amount_bivac);

                                        $data_to_treat['amount_comm'] = $com_occ + $com_bivac;
                                        $data_to_treat['amount_tva'] = $data_to_treat['amount_comm'] * 0.16;

                                        $frais_bancaire = $com_occ + $com_bivac;
                                        $frais_tva = $frais_bancaire * 0.16;

                                        $data_to_treat['montant_fb'] = $this->data('get_reduce_decimal', $frais_bancaire , 2);
                                        $data_to_treat['montant_tva'] = $this->data('get_reduce_decimal', $frais_tva , 2);


                                        $instruction2 = $this->seguceModel->get_frais_bancaire_instructions_seguce_debit_by_licence_number1($data_to_treat, $comptes);

                                        $instruction_frais = $this->seguceModel->get_instructions_invoices_occ($invoice_batchId);

                                        if (!$instruction_frais && !empty($instruction2))
                                        {
                                                # priority for integrating the counting in cbs
                                                $priority = 1;

                                                $this->seguceModel->save_instructions_invoice_occ($invoice_batchId, $instruction2, NULL, $priority, $clt);
                                                unset($instructions2);
                                        }
                                        else
                                        {
                                                foreach ($instruction_frais as $row)
                                                {
                                                        if ($row->Type_26 == 'COM')
                                                        {
                                                                $frais_com_cdf = round($data_to_treat['amount_comm'] * $taux, 2);
                                                                $frais_com_usd =  $data_to_treat['amount_comm'];

                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $frais_data_updated['Montant_10'] = $frais_com_cdf + $row->Montant_10;
                                                                $frais_data_updated['Montant_24'] = $frais_com_usd + $row->Montant_24;

                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $row->Paiementid_4, 'COM');
                                                        }

                                                        if ($row->Type_26 == 'TVA')
                                                        {
                                                                $frais_tva_cdf = $data_to_treat['amount_tva'] * $taux;
                                                                $frais_tva_usd =  $data_to_treat['amount_tva'];

                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $frais_data_updated['Montant_10'] = $frais_tva_cdf  + $row->Montant_10;
                                                                $frais_data_updated['Montant_24'] = $frais_tva_usd + $row->Montant_24;

                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $row->Paiementid_4, 'TVA');
                                                        }
                                                }
                                        }
                                }

                                if((isset($_POST['licence_issues']) && $_POST['licence_issues'] != "") || isset($_POST['licence_issues_manual']) && $_POST['licence_issues_manual'] != "")
                                {
                                        $data = array();

                                        $provision_amount = $this->seguceModel->get_dropdown("licence_provision");

                                        //$compte_clients = json_decode($_POST['compte_clients'], true);
                                        //$devise_comptes = json_decode($_POST['devise_comptes'], true);

                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        $data['Numbordereau_9'] =  isset($_POST['num_bordereau']) ? $_POST['num_bordereau'] : "";
                                        $data['Datebordereau_11'] =  isset($_POST['date_bordereau']) ? $_POST['date_bordereau'] : "";
                                        $data['BatchId_12'] =  $invoice_batchId ;
                                        $data['Environment_13'] = "L" ;
                                        $data['Agence_14'] = $_SESSION['Logiref_agence'];
                                        $data['Guichet_15'] = $_SESSION['Logiref_guichet'];

                                        if((isset($_POST['licence_issues']) && $_POST['licence_issues'] != ""))
                                        {
                                                $data['Status_2'] = '1';

                                                $licence_issues = isset($_POST['licence_issues']) ? json_decode($_POST['licence_issues'], true) : array();

                                                foreach($licence_issues as $key=>$row)
                                                {
                                                        if(isset($_POST['customer_issues']) && $_POST['customer_issues'] != "")
                                                        {
                                                                $customers_issues = json_decode($_POST['customer_issues'], true);
                                                                $data['Designation_7'] = isset($customers_issues[$key]) ? $customers_issues[$key] : "";
                                                        }

                                                        $data['CodeImport_8'] = $key;
                                                        $data['Result_10'] = json_encode($row);

                                                        $end_save = $this->seguceModel->save_invoice_occ_issues($data, NULL);
                                                }
                                        }
                                }
                        }

                        if (isset($end_execution) && $end_execution != "")
                        {
                                $invoice_batchId = $_POST['invoice_batchId'];
                                $data_batch['Status_2'] = '3';
                                $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_batch['Creator_4'] = $this->session->userdata['user_id'];

                                $this->seguceModel->update_invoice_occ_batchs($data_batch, $invoice_batchId);

                                echo "E200";
                        }
                        elseif (!isset($end_execution) && (isset($end_save) && $end_save != ""))
                        {
                                $invoice_batchId = $_POST['invoice_batchId'];
                                $data_batch['Status_2'] = '5';
                                $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_batch['Creator_4'] = $this->session->userdata['user_id'];

                                $this->seguceModel->update_invoice_occ_batchs($data_batch, $invoice_batchId);
                                echo "E201";
                        }
                        else
                        {
                                echo 0;
                        }
                }
                elseif ($obj == "validate")
                {
                        $data = $_POST;
                        $code = '';


                        if (isset($_POST['Seguice_53']) && $_POST['Seguice_53'] != "") {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if ($this->session->get('Logiref_role') == 3 || $this->session->get('Logiref_role') == 2) {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;

                                        #Invocation of the api transfer
                                        @set_time_limit(300);

                                        $core_banking = strtolower($this->core_banking);
                                        $response = $this->{$core_banking}->virement($data);

                                        $return = json_decode($response, true);

                                        if (isset($return['response']) && $return['response'] == "200") {
                                                #Confirmation facture
                                                $data_to_send = array();

                                                $users = $this->mainModel->get_dropdown('users_array');
                                                $user = $this->session->userdata['user_id'];

                                                $cbs_return = $this->integrationModel->get_cbs_returns_seguice($_POST['Seguice_53']);

                                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                                        $transaction_reference = $cbs_return;
                                                }

                                                $return = json_decode($response, true);

                                                $data_to_send['accountNumber'] = isset($_POST['Compte_33']) ? $_POST['Compte_33'] : "";
                                                $data_to_send['bankUserName'] = isset($users[$user]) ? $users[$user] : "";
                                                $data_to_send['PaymentMethod'] = isset($_POST['Mode_19']) ? $_POST['Mode_19'] : "";
                                                $data_to_send['PaymentMethodNumber'] = isset($_POST['refOp']) ? $_POST['refOp'] : "";
                                                $data_to_send['TransactionReference'] = isset($transaction_reference[$_POST['Seguice_53']]['Num_evenement']) ? $transaction_reference[$_POST['Seguice_53']]['Num_evenement'] : "467399";

                                                //$response = $this->amplitude->call_seguce_confirm_invoices($data_to_send);
                                                //$response = $this->amplitude->call_seguce_confirm_invoices($data_to_send);

                                                $code = 200;
                                                $id = $_POST['Seguice_53'];

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                if ($tid) {
                                                        $bl_data['Status_2'] = '3';
                                                        $bl = $this->seguceModel->update_invoice($bl_data, $id);
                                                }
                                        } elseif (isset($return['response']) && $return['response'] == "300") {
                                                $code = 300;
                                                $id = $_POST['Seguice_53'];

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);


                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->seguceModel->update_invoice($bl_data, $id);
                                        } elseif (isset($return['response']) && $return['response'] == "404") {
                                                $code = 404;
                                                $id = $_POST['Seguice_53'];

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);


                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->seguceModel->update_invoice($bl_data, $id);
                                        } elseif (isset($return['response']) && $return['response'] == "411") {
                                                $code = 411;
                                                $id = $_POST['Seguice_53'];

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);


                                                $bl_data['Status_2'] = '5';
                                                $bl = $this->seguceModel->update_invoice($bl_data, $id);
                                        } elseif (isset($return['response']) && $return['response'] == "405") {
                                                # Aucune ecriture trouvE 
                                                $code = 405;
                                                $id = $bl = $_POST['Seguice_53'];
                                        } elseif ($return == false || $return == NULL) {
                                                $code = 202;
                                                $id = $_POST['Seguice_53'];

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                if ($tid) {
                                                        $bl_data['Status_2'] = '5';
                                                        $bl = $this->seguceModel->update_invoice($bl_data, $id);
                                                }
                                        }
                                }
                                if (isset($bl) && $bl > 0) {
                                        $retour = array('code' => $code, 'id' => $id);
                                        echo json_encode($retour);
                                }
                                else {
                                        echo 0;
                                }
                        }
                }
                elseif ($obj == "validate_provision")
                {
                        $data = $_POST;
                        $code = '';
                        $result = array();
                        $provision = $this->seguceModel->get_provision_info($id);

                        if ($_SESSION['Logiref_role'] == 3 || $provision->Creator_4  != $this->session->userdata['user_id']) 
                        {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['pid'] = $data['Id_0'];
                                $data['Beneficaire_15'] = 'SEGUCE';
                                $data["Designation_13"] = $data['Designation'];
                                $data['Reference_14'] = $data['Reference'];
                                $data['Paiementid_4'] = $data['Id_0'];
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                #Invocation of the api transfer
                                @set_time_limit(300);

                                $core_banking = strtolower($this->core_banking);
                                $response = $this->{$core_banking}->virement_provision($data);

                                $return = json_decode($response, true);

                                if (isset($return['response']) && $return['response'] == "200")
                                {
                                        $code = 200;

                                        $license = $data['Licence_7'];
                                        $data_to_updated['Status_2'] = 2;
                                        $data_to_updated['Changes_5'] = date("Y-m-d H:i:s");
                                        $data_to_updated['Changes_6'] = $this->session->userdata['user_id'];
                                        $data_to_updated['Validation_44'] = date("Y-m-d H:i:s");

                                        $this->seguceModel->update_provisions($data_to_updated, $license);

                                        $result['code'] = $code;
                                }
                                else
                                {
                                        $code = $return['response'];

                                        $result['code'] = $return['response'];
                                        $result['reference'] = $data['Reference'];

                                        $license = $data['Licence_7'];
                                        $data_to_updated['Status_2'] = 5;
                                        $data_to_updated['Changes_5'] = date("Y-m-d H:i:s");
                                        $data_to_updated['Changes_6'] = $this->session->userdata['user_id'];

                                        $this->seguceModel->update_provisions($data_to_updated, $license);
                                }
                        }
                        else
                        {
                                # Not habilitated to validate the payment
                                $result['code'] = 501;
                        }

                        echo json_encode($result);
                }
                elseif ($obj == "validate_licence")
                {
                        $data = $_POST;
                        $code = '';
                        $result = array();
                        $licence = $this->seguceModel->get_licence_info($id);

                        if ($_SESSION['Logiref_role'] == 3 || $licence->Creator_4  != $this->session->userdata['user_id']) {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['lid'] = $data['Id_0'];
                                $data['Beneficaire_15'] = 'SEGUCE';
                                $data["Designation_13"] = $data['Designation_22'];
                                $data['Reference_14'] = $data['Reference'];
                                $data['Paiementid_4'] = $data['Id_0'];
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                #Invocation of the api transfer
                                @set_time_limit(300);

                                $core_banking = strtolower($this->core_banking);
                                $response = $this->{$core_banking}->virement_prelevement_frais_licence($data);

                                $return = json_decode($response, true);

                                if (isset($return['response']) && $return['response'] == 200) {
                                        $code = 200;

                                        $license = $data['Licence_7'];
                                        $data_to_updated['Status_2'] = 2;
                                        $data_to_updated['Changes_5'] = date("Y-m-d H:i:s");
                                        $data_to_updated['Changes_6'] = $this->session->userdata['user_id'];
                                        $data_to_updated['Validation_28'] = date("Y-m-d H:i:s");

                                        $this->seguceModel->update_licence($data_to_updated, $license);

                                        $result['code'] = $code;
                                } else {
                                        $code = $return['response'];

                                        $result['code'] = $return['response'];
                                        $result['reference'] = $data['Reference'];

                                        $license = $data['Licence_7'];
                                        $data_to_updated['Status_2'] = 5;
                                        $data_to_updated['Changes_5'] = date("Y-m-d H:i:s");
                                        $data_to_updated['Changes_6'] = $this->session->userdata['user_id'];

                                        $this->seguceModel->update_licence($data_to_updated, $license);
                                }
                        } 
                        else {
                                # Not habilitated to validate the payment
                                $result['code'] = 501;
                        }

                        echo json_encode($result);
                }
                elseif ($obj == "provision_verify")
                {
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = $_POST['Designation'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Reference'] = $_POST['Reference'];

                        $provision = $this->seguceModel->get_instruction_provision_by_ref($data['Reference']);

                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = !empty($_POST['transaction_id']) ? $_POST['transaction_id'] : $provision->Id_0;

                        $core_banking = strtolower($this->core_banking);
                        //$response = $this->{$core_banking}->virement_provision_verify($data);
                        $response = json_encode([]);

                        $return = json_decode($response, true);

                        if ($return['response'] == '200') {
                                $code = 200;

                                $license = $_POST['Licence_7'];
                                $data_to_updated['Status_2'] = 2;

                                $this->seguceModel->update_provisions($data_to_updated, $license);

                                echo 'E' . $code;
                        }
                        elseif (isset($return['response']) && ($return['response'] == '300' || $return['response'] == '404' || $return['response'] == '405' || $return['response'] == '411')) {
                                echo 'E' . $return['response'];
                                die;
                        }
                }
                elseif ($obj == "validate_batch")
                {

                        $data = $_POST;
                        $code = '';
                        $validation = array();
                        $errors = array();

                        $factureids = isset($_POST['factureid']) ? $_POST['factureid'] : "";

                        $factureids = implode(',', $factureids);

                        $factures = $this->seguceModel->get_unvalidated_invoices_by_id($factureids);

                        foreach ($factures as $row) {
                                if (isset($row->Id_0) && $row->Id_0 != "") {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        if ($this->session->get('Logiref_role') == 3 || $this->session->get('Logiref_role') == 2) {
                                                # Priority of transactions to send to the API set to 1.
                                                $data['Priority'] = 1;
                                                $data['Seguice_53'] = $row->Id_0;
                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                $data["Designation_14"] = $row->Debiteur_25;
                                                $data['Account_3'] = $this->session->userdata['account_id'];

                                                #Invocation of the api transfer
                                                @set_time_limit(300);

                                                $instructions = $this->comptabilisationModel->get_instructions_seguice($row->Id_0);

                                                $instruction = current($instructions);
                                                $core_banking = strtolower($this->core_banking);
                                                //$response = $this->{$core_banking}->virement($data);
                                                //$return = json_decode($response, true);
                                                $return['response'] = "200";
                                                $validation[$row->Id_0]['response'] = $return['response'];

                                                if (isset($return['response']) && $return['response'] == "200" || $instruction->Priority_24 == 0) {
                                                        if ($instruction->Priority_24 == 0) {
                                                                $users = $this->mainModel->get_dropdown('users_array');
                                                                $user = $this->session->userdata['user_id'];

                                                                $data_to_send['accountNumber'] = isset($row->Account_15) ? $row->Account_15 : "";
                                                                $data_to_send['bankUserName'] = isset($users[$user]) ? $users[$user] : "";
                                                                $data_to_send['PaymentMethod'] = isset($row->Mode_38) ? $row->Mode_38 : "";
                                                                $data_to_send['PaymentMethodNumber'] = isset($row->Refop_29) ? $row->Refop_29 : "";
                                                                $data_to_send['TransactionReference'] = isset($return['Num_evenement']) ? $return['Num_evenement'] : "467394";
                                                                $data_to_send['path'] = isset($row->Path_34) ? $row->Path_34 : "";
                                                                $data_to_send['Filename'] = isset($row->Filename_39) ? $row->Filename_39 : "";
                                                                $data_to_send['bank_account'] = isset($this->session->userdata['account_id']) ? $this->session->userdata['account_id'] : "";

                                                                //$response = $this->amplitude->call_seguce_confirm_invoices($data_to_send);
                                                                //$response = $this->seguceSFTP->confirm_invoice($data_to_send);

                                                                $code = 200;
                                                                $id = $row->Id_0;

                                                                $data_to_validate['Status_2'] = 1;
                                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                                # Update the paiement related to the bulletin
                                                                /*$tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                                if ($tid) {*/
                                                                        $facture_data['Status_2'] = '3';
                                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                                //}
                                                        } else {
                                                                #Confirmation facture
                                                                $data_to_send = array();

                                                                $users = $this->mainModel->get_dropdown('users_array');
                                                                $user = $this->session->userdata['user_id'];

                                                                $cbs_return = $this->integrationModel->get_cbs_returns_seguice($row->Id_0);

                                                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                                                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                                                        $transaction_reference = $cbs_return;
                                                                }

                                                                $data_to_send['accountNumber'] = isset($row->Account_15) ? $row->Account_15 : "";
                                                                $data_to_send['bankUserName'] = isset($users[$user]) ? $users[$user] : "";
                                                                $data_to_send['PaymentMethod'] = isset($row->Mode_38) ? $row->Mode_38 : "";
                                                                $data_to_send['PaymentMethodNumber'] = isset($row->Refop_29) ? $row->Refop_29 : "";
                                                                $data_to_send['TransactionReference'] = isset($transaction_reference[$row->Id_0]['Num_evenement']) ? $transaction_reference[$row->Id_0]['Num_evenement'] : "";
                                                                $data_to_send['path'] = isset($row->Path_34) ? $row->Path_34 : "";
                                                                $data_to_send['Filename'] = isset($row->Filename_39) ? $row->Filename_39 : "";

                                                                //$response = $this->amplitude->call_seguce_confirm_invoices($data_to_send);

                                                                $code = 200;
                                                                $id = $row->Id_0;

                                                                $data_to_validate['Status_2'] = 1;
                                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                                # Update the paiement related to the bulletin
                                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                                if ($tid) {
                                                                        $facture_data['Status_2'] = '3';
                                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                                }
                                                        }
                                                } elseif (isset($return['response']) && $return['response'] == "300") {
                                                        $code = 300;
                                                        $id = $row->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);


                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$row->Id_0] = $code;
                                                } elseif (isset($return['response']) && $return['response'] == "404") {
                                                        $code = 404;
                                                        $id = $row->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);


                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$row->Id_0] = $code;
                                                } elseif (isset($return['response']) && $return['response'] == "411") {
                                                        $code = 411;
                                                        $id = $row->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_dgda($data_to_validate, $id);


                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$row->Id_0] = $code;
                                                } elseif (isset($return['response']) && $return['response'] == "405") {
                                                        # Aucune ecriture trouvE
                                                        $code = 405;
                                                        $id = $facture_update = $row->Id_0;

                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$row->Id_0] = $code;
                                                } elseif ($return == false || $return == NULL) {
                                                        $code = 202;
                                                        $id = $row->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                        $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                        if ($tid) {
                                                                $facture_data['Status_2'] = '5';
                                                                $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                        }

                                                        $errors[$row->Id_0] = $code;
                                                }
                                        }
                                }
                        }

                        if (!empty($errors)) {
                                $validation['errors'] = true;
                        } else {
                                $validation['errors'] = false;
                        }

                        $result = json_encode($validation);

                        echo $result;
                }
                elseif($obj=="validate_invoice")
                {
                        $data = $_POST;
                        $code = '';
                        $validation = array();
                        $errors = array();

                        $factureid =  $_POST['factureid'] ?? "";

                        $facture = $this->seguceModel->get_unvalidated_invoice_by_id($factureid);

                        if(!empty($facture))
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                if ($this->session->get('Logiref_role') == 3 || $this->session->get('Logiref_role') == 2) 
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority']       = 1;
                                        $data['Id_0']           = $facture->Id_0;
                                        $data['Seguice_53']     = $facture->Id_0;
                                        $data['Beneficaire_15'] = 'SEGUCE';
                                        $data["Designation_14"] = $facture->Debiteur_25;
                                        $data['Logirefid_4']    = $facture->Logirefid_31;
                                        $data['Account_3']      = $this->session->userdata['account_id'];

                                        #Invocation of the api transfer
                                        @set_time_limit(300);
                                        $priority=1;
                                        $instructions = $this->comptabilisationModel->get_instructions_seguice_by_priority($facture->Id_0,$priority);
                                        
                                        $instruction = current($instructions);

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'virement'))
                                        {        
                                                $response = $this->{$core_banking}->virement($data);
                                                $return   = json_decode($response, true);

                                                $validation[$instruction->Id_0]['response'] = $return['response'];
                                                
                                                if (isset($return['response']) && $return['response'] == "200") 
                                                {
                                                        $users = $this->mainModel->get_dropdown('users_array');
                                                        $user  = $this->session->userdata['user_id'];

                                                        $data_to_send["ID"]                     = $facture->Factureid_5;
                                                        $data_to_send["BankActorCode"]          = $facture->Bank_4;
                                                        $data_to_send["Date"]                   = $facture->Date_1;
                                                        $data_to_send["InternalReference"]      = $facture->Reference_7;
                                                        $data_to_send["DebtorActorName"]        = $facture->Debiteur_25;
                                                        $data_to_send["CreditorActorName"]      = $facture->Creditaire_26;
                                                        $data_to_send["NetAmount"]              = $facture->Montant_11;
                                                        $data_to_send["Currency"]               = $facture->Devise_12;
                                                        $data_to_send["AccountNumber"]          = $facture->Account_15;
                                                        $data_to_send["AccountOwner"]           = $facture->Debiteur_25;
                                                        $data_to_send["PaymentMethod"]          = '7';
                                                        $data_to_send["TransactionReference"]   = $facture->Reference_7;
                                                        $data_to_send["TransactionDate"]        = $facture->Date_1;
                                                        $data_to_send["ContractType"]           = $facture->Contracttype_46;
                                                        $data_to_send["Status"]                 = "Issued";

                                                        $data_to_validate['Status_2'] = 6;
                                                        $this->seguceModel->update_invoice($data_to_validate, $factureid);

                                                        $response = $this->curl(base_url('services/seguce/settleInvoice'),'POST',json_encode($data_to_send));
                                                        $return   = json_decode($response,true);

                                                        if(isset($return['code']) && $return['code']=='200')
                                                        {
                                                                $code = 200;
                                                                $id = $facture->Id_0;
                                                                
                                                                $facture_data['Status_2'] = '3';
                                                                $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                        }
                                                        else
                                                        {
                                                                $code = 302;
                                                                $errors[$facture->Id_0] = $code;
                                                        }    
                                                } 
                                                elseif (isset($return['response']) && $return['response'] == "300") 
                                                {
                                                        $code = 300;
                                                        $id = $facture->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                        # Update the paiement related to the bulletin
                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$facture->Id_0] = $code;
                                                } 
                                                elseif (isset($return['response']) && $return['response'] == "404") 
                                                {
                                                        $code = 404;
                                                        $id = $facture->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        


                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$facture->Id_0] = $code;
                                                } 
                                                elseif (isset($return['response']) && $return['response'] == "411") 
                                                {
                                                        $code = 411;
                                                        $id = $facture->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin

                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$facture->Id_0] = $code;
                                                } 
                                                elseif (isset($return['response']) && $return['response'] == "405") 
                                                {
                                                        # Aucune ecriture trouvE
                                                        $code = 405;
                                                        $id = $facture_update = $facture->Id_0;

                                                        $facture_data['Status_2'] = '5';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);

                                                        $errors[$facture->Id_0] = $code;
                                                } 
                                                elseif ($return == false || $return == NULL) 
                                                {
                                                        $code = 202;
                                                        $id = $facture->Id_0;

                                                        $data_to_validate['Status_2'] = 1;
                                                        $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                        $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                        # Update the paiement related to the bulletin
                                                        // $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                        // $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                        // if ($tid) {
                                                                $facture_data['Status_2'] = '5';
                                                                $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                        // }

                                                        $errors[$facture->Id_0] = $code;
                                                }
                                        }
                                        else 
                                        {
                                                $result['code'] = 'E407';
                                                echo json_encode($result); die;
                                        }
                                }
                        }
                        
                        if (!empty($errors)) 
                        {
                                $validation['errors']     = true;
                                $validation['error_code'] = $code;
                        } 
                        else 
                        {
                                $validation['errors']     = false;
                                $validation['error_code'] = $code;
                        }

                        $result = json_encode($validation);

                        echo $result;
                        
                }
                elseif ($obj == "validate_acquit")
                {
                        $data = $_POST;
                        $code = '';
                        $validation = array();
                        $errors = array();

                        $factureids = isset($_POST['factureid']) ? $_POST['factureid'] : "";

                        $factureids = implode(',', $factureids);

                        $factures = $this->seguceModel->get_unvalidated_invoices_by_id($factureids);

                        foreach ($factures as $row) {
                                if (isset($row->Id_0) && $row->Id_0 != "") {
                                        #Is this a validation? Yes if it's a validator or the supervisor
                                        //if($row->Topaid_43 ==1 && ($_SESSION['Logiref_role'] ==3 || $_SESSION['Logiref_role']==2))
                                        if (($this->session->get('Logiref_role') == 3 || $this->session->get('Logiref_role') == 2)) {
                                                //$validation[$row->Id_0]['response'] = $return['response'];

                                                #Confirmation facture
                                                $data_to_send = array();

                                                $users = $this->mainModel->get_dropdown('users_array');
                                                $user = $this->session->userdata['user_id'];

                                                $cbs_return = $this->integrationModel->get_cbs_returns_seguice($row->Id_0);

                                                if (isset($cbs_return->Result_6) && $cbs_return->Result_6 != "") {
                                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                                        $transaction_reference = $cbs_return;
                                                }

                                                $data_to_send['accountNumber'] = isset($row->Account_15) ? $row->Account_15 : "";
                                                $data_to_send['bankUserName'] = isset($users[$user]) ? $users[$user] : "";
                                                $data_to_send['PaymentMethod'] = isset($row->Mode_38) ? $row->Mode_38 : "";
                                                $data_to_send['PaymentMethodNumber'] = isset($row->Refop_29) ? $row->Refop_29 : "";
                                                $data_to_send['TransactionReference'] = isset($transaction_reference[$row->Id_0]['Num_evenement']) ? $transaction_reference[$row->Id_0]['Num_evenement'] : "";
                                                $data_to_send['path'] = isset($row->Path_34) ? $row->Path_34 : "";
                                                $data_to_send['Filename'] = isset($row->Filename_39) ? $row->Filename_39 : "";

                                                //$response = $this->curl_model->call_seguce_confirm_invoices($data_to_send);

                                                $code = 200;
                                                $id = $row->Id_0;

                                                $data_to_validate['Status_2'] = 1;
                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                # Update the paiement related to the bulletin
                                                $tid = $this->encaissementModel->update_payment_tresor_seguice($data_to_validate, $id);
                                                $pid = $this->encaissementModel->update_payment_propres_seguice($data_to_validate, $id);

                                                if ($tid) {
                                                        $facture_data['Status_2'] = '3';
                                                        $facture_update = $this->seguceModel->update_invoice($facture_data, $id);
                                                }

                                                if ($facture_update) {
                                                        $validation['errors'] = true;
                                                }
                                        } else {
                                                $validation['errors'] = false;
                                        }
                                }
                        }

                        $result = json_encode($validation);

                        echo $result;
                }
                elseif($obj == "validate_fees_occ")
                {
                        $data = $_POST;
                        $code = '';

                        $invoice_batchid = $data['invoice_batchid'];
                        //$invoice_batchid = $data['ref_bordereau'];

                        if(isset($invoice_batchid) && $invoice_batchid != "")
                        {
                                if($_SESSION['Logiref_role'] ==3)
                                {
                                        # Priority of transactions to send to the API set to 1.
                                        $data['Priority'] = 1;
                                        $data['invoice_id'] = $invoice_batchid;
                                        $data['Beneficaire_15'] = 'SEGUCE';
                                        $data["Designation_13"] = "Bordereau " .$invoice_batchid;
                                        $data['Account_3'] = $this->session->userdata['user_id'];

                                        #Invocation of the api transfer
                                        @set_time_limit(300);

                                        //$response = $this->curl_model->call_bank_virement_occ($data);
                                        //$return = json_decode($response, true);

                                        $return['response'] = "200";

                                        $validation['response'] = $return['response'];

                                        if(isset($return['response']) && $return['response'] == "200")
                                        {
                                                $code = 200;
                                                $result['code'] = $code;
                                        }
                                        else
                                        {
                                                $code = $return['response'];

                                                $result['code'] = $return['response'];
                                                $result['transaction_id'] = json_encode($return['transaction_id']);
                                                $result['reference'] = $invoice_batchid;
                                        }
                                }

                                echo json_encode($result);

                        }
                        else
                        {
                                $validation = array('code'=>0);

                                $result = json_encode($validation);
                                echo $result;
                        }
                }
                elseif($obj == "verify_fees_occ")
                {
                        $data['Priority'] = 1;
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = "Bordereau ".$_POST['logirefid'];
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Reference'] = $_POST['logirefid'];
                        $data['Error_code'] = $_POST['error_code'];
                        $data['transaction_id'] = json_decode($_POST['transaction_id'], true);

                        //$response = $this->curl_model->call_bank_virement_occ_bivac_verify($data);

                        //$return = json_decode($response, true);

                        $return['response'] = "200";

                        if($return['response']=='200')
                        {
                                $code = 200;

                                echo 'E'.$code;
                        }
                        elseif(isset($return['response']) && ($return['response'] =='300' || $return['response']=='404' || $return['response']=='405' || $return['response']=='411'))
                        {
                                echo 'E'.$return['response'];
                                die;
                        }
                }
                elseif ($obj == "validate_invoice_occ")
                {
                        $data = $_POST;
                        $code = '';

                        if(array_key_exists('eximtrade_validate_in_batch_by_customer',$this->functionalities['ALL']))
                        {
                                $batch_id = $data['batch_id'];
                                $code_import = $data['code_imports'];
                                $batch_ref = $data['batch_ref'];

                                if (isset($batch_id) && $batch_id != "") {
                                        $invoices = $this->seguceModel->get_invoices_occ_by_code_import($batch_id, $code_import);
                                        $licences_provision = $this->seguceModel->get_dropdown("licence_provision");
                                        $licences_number = $this->seguceModel->get_dropdown("licence_number");

                                        $instructions = $this->seguceModel->get_instructions_invoices_occ_by_clt($batch_id, $code_import);

                                        foreach ($instructions as $row) {
                                                $invoice_ids[] = $row->Id_0;
                                        }

                                        $validation = array();

                                        if ($_SESSION['Logiref_role'] == 3) {
                                                # Priority of transactions to send to the API set to 1.
                                                $data['Priority'] = 1;
                                                $data['batch_id'] = $batch_id;
                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                $data["Codeimport_28"] = $code_import;
                                                $data['Account_3'] = $this->session->userdata['user_id'];
                                                $data['Reference'] = $batch_ref;

                                                #Invocation of the api transfer
                                                @set_time_limit(300);
                                                $core_banking = strtolower($this->core_banking);
                                                $response = $this->{$core_banking}->virement_occ($data);
                                                $return = json_decode($response, true);

                                                $return['reponse'] = $return['response'];

                                                unset($return['ids']);
                                                unset($return['response']);

                                                $invoice_updated  = 0;
                                                $total_amount = 0;

                                                foreach ($invoice_ids as $row) {
                                                        if (isset($return[$row]['code'])) {
                                                                $validation[$row]['response'] = $return[$row]['code'];
                                                        } else {
                                                                $validation[$row]['response'] = '405';
                                                        }
                                                }

                                                if (isset($return['reponse']) && $return['reponse'] == "200") {
                                                        $code = 200;

                                                        $data_inst['Status_2'] = '3';
                                                        $data_inst['Priority_27'] = '1';
                                                        $inst_updated = $this->seguceModel->update_instructions_fees($data_inst, $batch_id, $code_import);

                                                        foreach ($invoices as $invoice) {
                                                                $licence = explode('-', $invoice->Licence_8);
                                                                $segment_license_number = $licence[0];

                                                                if (in_array($invoice->Licence_8, $licences_number) || in_array($segment_license_number, $licences_number)) {
                                                                        $result = json_decode($invoice->Result_11, true);
                                                                        $livraison = $result[$invoice->Licence_8]['livraison']['0'];

                                                                        $data_provision['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                                        #Updated provisions
                                                                        if ($livraison == 'T') {
                                                                                if (isset($licences_provision[$invoice->Licence_8])) $provision = $licences_provision[$invoice->Licence_8];
                                                                                if (isset($licences_provision[$segment_license_number])) $provision = $licences_provision[$segment_license_number];

                                                                                $montant_prov = $result[$invoice->Licence_8]['montantprov']['0'];

                                                                                $frais_occ = $result[$invoice->Licence_8]['CPO']['0'];
                                                                                $frais_bivac = $result[$invoice->Licence_8]['CPB']['0'];
                                                                                $frais_tva_occ = $result[$invoice->Licence_8]['CTC']['0'];

                                                                                $amount_paid = $frais_occ + $frais_bivac + $frais_tva_occ;

                                                                                if ($provision >= $montant_prov) {
                                                                                        $provision_amount_gap = $provision - $amount_paid;

                                                                                        if ($provision_amount_gap < 1)  $provision_amount_gap = 0;

                                                                                        $data_provision['Montantprov_10'] = $provision_amount_gap;
                                                                                        $data_provision['AmountPartial_29'] = round($amount_paid, 2);
                                                                                } else {
                                                                                        $data_provision['Montantprov_10'] = 0;
                                                                                        $data_provision['AmountPartial_29'] = $provision;
                                                                                }

                                                                                $data_provision['Status_2'] = '3';
                                                                                if (isset($licences_provision[$invoice->Licence_8])) {
                                                                                        $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                }

                                                                                if (isset($licences_provision[$segment_license_number])) {
                                                                                        $this->seguceModel->update_provisions($data_provision, $segment_license_number);
                                                                                }
                                                                        }

                                                                        if ($livraison == 'P') {

                                                                                if (isset($licences_provision[$invoice->Licence_8]))  $provision = $licences_provision[$invoice->Licence_8];
                                                                                if (isset($licences_provision[$segment_license_number])) $provision = $licences_provision[$segment_license_number];

                                                                                $montant_prov = $result[$invoice->Licence_8]['montantprov']['0'];

                                                                                $frais_occ = $result[$invoice->Licence_8]['CPO']['0'];
                                                                                $frais_bivac = $result[$invoice->Licence_8]['CPB']['0'];
                                                                                $frais_tva_occ = $result[$invoice->Licence_8]['CTC']['0'];

                                                                                $amount_paid = $frais_occ + $frais_bivac + $frais_tva_occ;

                                                                                if ($provision >= $montant_prov) {
                                                                                        $provision_amount_gap = $provision - $amount_paid;

                                                                                        if ($provision_amount_gap < 1) $provision_amount_gap = 0;

                                                                                        $data_provision['Status_2'] = $provision == $montant_prov ? '3' : '4';
                                                                                        $data_provision['Montantprov_10'] = $provision_amount_gap;
                                                                                        $data_provision['AmountPartial_29'] = round($amount_paid);
                                                                                } else {
                                                                                        $data_provision['Status_2'] = '3';
                                                                                        $data_provision['Montantprov_10'] = 0;
                                                                                        $data_provision['AmountPartial_29'] = $provision;
                                                                                }

                                                                                if (isset($licences_provision[$invoice->Licence_8])) {
                                                                                        $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                }

                                                                                if (isset($licences_provision[$segment_license_number])) {
                                                                                        $this->seguceModel->update_provisions($data_provision, $segment_license_number);
                                                                                }
                                                                        }
                                                                }
                                                        }

                                                        $instruction = $this->seguceModel->get_instructions_invoices_occ_by_batchid($batch_id);

                                                        $data_batch['Status_2'] = (empty($instruction)) ? '4' : '3';
                                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);
                                                } else {
                                                        $code = $return['reponse'];

                                                        $instruction = $this->seguceModel->get_instructions_invoices_occ_not_integrated($batch_id);

                                                        $data_batch['Status_2'] = (empty($instruction)) ? '4' : '3';
                                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);
                                                }
                                        }

                                        $result = json_encode($validation);

                                        echo $result;
                                }
                                else {
                                        $validation = array('code' => 0);

                                        $result = json_encode($validation);
                                        echo $result;
                                }
                        }
                        elseif(array_key_exists('eximtrade_select_license_for_processing_and_validation_of_slip',$this->functionalities['ALL']))
                        {
                                $batch_id = $data['batch_id'];
                                $licences = $data['licences'];
                                $batch_ref = $data['batch_ref'];

                                if(isset($batch_id) && $batch_id!= "")
                                {
                                        foreach ($licences as $key => $line)
                                        {
                                                $invoices = $this->seguceModel->get_invoices_occ_by_licence($batch_id, $line);

                                                $licences_provision = $this->seguceModel->get_dropdown("licence_provision");
                                                $licences_number = $this->seguceModel->get_dropdown("licence_number");

                                                $instructions = $this->seguceModel->get_instructions_invoices_occ_by_clt($batch_id, $line);

                                                foreach ($instructions as $row)
                                                {
                                                        $ids_instruction[$row->Codeimport_28][] = $row->Id_0;
                                                }

                                                $validation = array();

                                                if($_SESSION['Logiref_role'] == 3)
                                                {
                                                        # Priority of transactions to send to the API set to 1.
                                                        $data['Priority'] = 1;
                                                        $data['batch_id'] = $batch_id;
                                                        $data['Beneficaire_15'] = 'SEGUCE';
                                                        $data["Codeimport_28"] = $line;
                                                        $data['Account_3'] = $this->session->userdata['user_id'];
                                                        $data['Reference'] = $batch_ref;

                                                        #Invocation of the api transfer
                                                        @set_time_limit(300);
                                                        $core_banking = strtolower($this->core_banking);
                                                        $response = $this->{$core_banking}->virement_occ($data);
                                                        $return = json_decode($response, true);

                                                        foreach ($ids_instruction as $lKey => $ids)
                                                        {
                                                                foreach ($ids as $iKey)
                                                                {
                                                                        if (isset($return[$iKey]['code'])):
                                                                                $validation[$lKey]['response'] = $return[$iKey]['code'];
                                                                        else:
                                                                                $validation[$lKey]['response'] = '405';
                                                                        endif;
                                                                }
                                                        }

                                                        if(isset($return['response']) && $return['response'] == "200")
                                                        {
                                                                $code = 200;

                                                                $data_inst['Status_2'] = '3';
                                                                $data_inst['Priority_27'] = '1';
                                                                $inst_updated = $this->seguceModel->update_instructions_fees($data_inst, $batch_id, $line);

                                                                foreach($invoices as $invoice)
                                                                {
                                                                        $licence = explode('-', $invoice->Licence_8);
                                                                        $segment_license_number = $licence[0];

                                                                        if (in_array($invoice->Licence_8, $licences_number) || in_array($segment_license_number, $licences_number))
                                                                        {
                                                                                $result = json_decode($invoice->Result_11, true);
                                                                                $livraison = $result[$invoice->Licence_8]['livraison']['0'];

                                                                                $data_provision['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                                                #Updated provisions
                                                                                if ($livraison == 'T')
                                                                                {
                                                                                        if (isset($licences_provision[$invoice->Licence_8])) $provision = $licences_provision[$invoice->Licence_8];
                                                                                        if (isset($licences_provision[$segment_license_number])) $provision = $licences_provision[$segment_license_number];

                                                                                        $montant_prov = $result[$invoice->Licence_8]['montantprov']['0'];

                                                                                        $frais_occ = $result[$invoice->Licence_8]['CPO']['0'];
                                                                                        $frais_bivac = $result[$invoice->Licence_8]['CPB']['0'];
                                                                                        $frais_tva_occ = $result[$invoice->Licence_8]['CTC']['0'];

                                                                                        $amount_paid = $frais_occ + $frais_bivac + $frais_tva_occ;

                                                                                        if($provision >= $montant_prov)
                                                                                        {
                                                                                                $provision_amount_gap = $provision - $amount_paid;

                                                                                                if ($provision_amount_gap < 1)  $provision_amount_gap = 0;

                                                                                                $data_provision['Montantprov_10'] = $provision_amount_gap;
                                                                                                $data_provision['AmountPartial_29'] = round($amount_paid, 2);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                                $data_provision['Montantprov_10'] = 0;
                                                                                                $data_provision['AmountPartial_29'] = $provision;
                                                                                        }

                                                                                        $data_provision['Status_2'] = '3';

                                                                                        if (isset($licences_provision[$invoice->Licence_8]))
                                                                                        {
                                                                                                $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                        }

                                                                                        if (isset($licences_provision[$segment_license_number]))
                                                                                        {
                                                                                                $this->seguceModel->update_provisions($data_provision, $segment_license_number);
                                                                                        }
                                                                                }

                                                                                if ($livraison == 'P')
                                                                                {
                                                                                        if (isset($licences_provision[$invoice->Licence_8]))  $provision = $licences_provision[$invoice->Licence_8];
                                                                                        if (isset($licences_provision[$segment_license_number])) $provision = $licences_provision[$segment_license_number];

                                                                                        $montant_prov = $result[$invoice->Licence_8]['montantprov']['0'];

                                                                                        $frais_occ = $result[$invoice->Licence_8]['CPO']['0'];
                                                                                        $frais_bivac = $result[$invoice->Licence_8]['CPB']['0'];
                                                                                        $frais_tva_occ = $result[$invoice->Licence_8]['CTC']['0'];

                                                                                        $amount_paid = $frais_occ + $frais_bivac + $frais_tva_occ;

                                                                                        if($provision >= $montant_prov)
                                                                                        {
                                                                                                $provision_amount_gap = $provision - $amount_paid;

                                                                                                if ($provision_amount_gap < 1) $provision_amount_gap = 0;

                                                                                                $data_provision['Status_2'] = $provision == $montant_prov ? '3' : '4';
                                                                                                $data_provision['Montantprov_10'] = $provision_amount_gap;
                                                                                                $data_provision['AmountPartial_29'] = round($amount_paid);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                                $data_provision['Status_2'] = '3';
                                                                                                $data_provision['Montantprov_10'] = 0;
                                                                                                $data_provision['AmountPartial_29'] = $provision;

                                                                                        }

                                                                                        if (isset($licences_provision[$invoice->Licence_8]))
                                                                                        {
                                                                                                $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                        }

                                                                                        if (isset($licences_provision[$segment_license_number]))
                                                                                        {
                                                                                                $this->seguceModel->update_provisions($data_provision, $segment_license_number);
                                                                                        }
                                                                                }
                                                                        }
                                                                }

                                                                $instruction = $this->seguceModel->get_instructions_invoices_occ_by_batchid($batch_id);

                                                                $data_batch['Status_2'] = (empty($instruction)) ? '4': '3';
                                                                $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                                $bid = $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);

                                                                $invoice_data['Status_2'] = '3';
                                                                $this->seguceModel->update_invoice_occ($invoice_data, $key);

                                                        }
                                                        else
                                                        {
                                                                $code = $return['response'];

                                                                $instruction = $this->seguceModel->get_instructions_invoices_occ_not_integrated($batch_id);

                                                                $data_batch['Status_2'] = (empty($instruction)) ? '4': '3';
                                                                $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                                $bid = $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);

                                                                $invoice_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice_occ($invoice_data, $key);
                                                        }
                                                }
                                        }

                                        $result = json_encode($validation);

                                        echo $result;
                                }
                                else
                                {
                                        $validation = array('code'=>0);

                                        $result = json_encode($validation);
                                        echo $result;
                                }
                        }
                        else{

                                $bal_data = array();

                                $provisions = $this->seguceModel->get_dropdown("licence_provision");

                                # Retrieve the exchange rate
                                $rate = json_decode($_SESSION['Bank_rates'], true);

                                if(isset($rate['Dollar_4']) && $rate['Dollar_4'] != "" )
                                {
                                        $taux = $rate['Dollar_4'];
                                }
                                else
                                {
                                        $taux = 1;
                                }

                                $invoice_ids = $data['invoices_id'];

                                if(isset($invoice_ids) && $invoice_ids != "")
                                {
                                        $validation = array();
                                        $amounts = array();

                                        foreach ($invoice_ids as $iKey => $row)
                                        {
                                                $invoice = $this->seguceModel->get_invoices_occ_info($row);

                                                $result = json_decode($invoice->Result_11, true);
                                                $livraison = $result[$invoice->Licence_8]['livraison']['0'];

                                                $date_bordereau = explode('-', $invoice->Datebordereau_15);
                                                $annee_bordereau = $date_bordereau[0];
                                                $num_bordereau = $invoice->Numbordereau_14;

                                                $paiementid_bordereau = $invoice->BatchId_23. "" .$num_bordereau. "" .$annee_bordereau;

                                                foreach($result as $licence => $values)
                                                {
                                                        $total_amount_licence = 0;

                                                        foreach($values as $cle=>$ligne)
                                                        {
                                                                if($cle != 'valeur_cif' && $cle != 'livraison' && $cle != 'CFC' && $cle != 'montantprov' && $cle != 'devise')
                                                                {
                                                                        $amount_recipe = 0;

                                                                        foreach ($ligne as $value)
                                                                        {
                                                                                $amount_recipe = $amount_recipe + $value;

                                                                        }
                                                                        $total_amount_licence = $total_amount_licence + $amount_recipe;
                                                                }
                                                        }
                                                        $amounts[$licence] = $total_amount_licence;
                                                }

                                                if($_SESSION['Logiref_role'] == 3)
                                                {
                                                        $id = $row;

                                                        $invoice_updated  = 0;
                                                        $total_amount = 0;

                                                        # Priority of transactions to send to the API set to 1.
                                                        $data['Priority'] = 1;
                                                        $data['invoice_id'] = $row;
                                                        $data['Beneficaire_15'] = 'SEGUCE';
                                                        $data["Designation_13"] = $invoice->Designation_13;
                                                        $data['Account_3'] = $this->session->userdata['user_id'];

                                                        #Invocation of the api transfer
                                                        @set_time_limit(300);

                                                        if (isset($provisions[$invoice->Licence_8]) && $provisions[$invoice->Licence_8] > 0)
                                                        {
                                                                $instruction_extourne = $this->seguceModel->get_instructions_info_extourne_invoice_occ($row);

                                                                if (!empty($instruction_extourne))
                                                                {
                                                                        #Check balance
                                                                        $bal_data['bank_account'] = $invoice->Compte_19;
                                                                        $bal_data['devise_account'] = $invoice->Devise_20;
                                                                        $bal_data['amount'] = $invoice->Devise_20;

                                                                        $bal_result = $this->data('get_balance_by_customer_account', $bal_data);

                                                                        if ($bal_data['devise_account'] == 'CDF')
                                                                        {
                                                                                $customer_balance = $bal_result / $taux;
                                                                        }
                                                                        else
                                                                        {
                                                                                $customer_balance = $bal_result;
                                                                        }

                                                                        $total_topaid_licence = $amounts[$invoice->Licence_8];

                                                                        if ((isset($customer_balance) && $customer_balance >= 0) && (int) $customer_balance >= (int) $amounts[$invoice->Licence_8])
                                                                        {
                                                                                $data['Type'] = '';
                                                                                //$response = $this->curl_model->call_bank_virement_occ($data);

                                                                                //$return = json_decode($response, true);
                                                                                $return['response'] = "200";
                                                                                $validation[$row]['response'] = $return['response'];

                                                                                if(isset($return['response']) && $return['response'] == "200")
                                                                                {
                                                                                        $code = 200;

                                                                                        $invoice_data['Status_2'] = '3';
                                                                                        $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);

                                                                                        $data_partial['Status_2'] = '2';
                                                                                        $this->seguceModel->update_instructions_partail_occ($data_partial, $invoice->Id_0);

                                                                                }
                                                                                else
                                                                                {
                                                                                        $code = $return['response'];

                                                                                        $invoice_data['Status_2'] = '5';

                                                                                        $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                $code = 'E501';

                                                                                $validation[$row]['response'] = $code;

                                                                                $instruction_partial = $this->seguceModel->get_instructions_partial_invoices_occ($invoice->Id_0);

                                                                                $instruction_frais = $this->seguceModel->get_instructions_invoices_occ($paiementid_bordereau);

                                                                                foreach ($instruction_frais as $row)
                                                                                {
                                                                                        if ($row->Type_26 == 'COM')
                                                                                        {
                                                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                                $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[0]->Montant_10;
                                                                                                $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[0]->Montant_24;

                                                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'COM');
                                                                                        }

                                                                                        if ($row->Type_26 == 'TVA')
                                                                                        {
                                                                                                $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                                $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[1]->Montant_10;
                                                                                                $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[1]->Montant_24;

                                                                                                $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'TVA');
                                                                                        }
                                                                                }

                                                                                #Updated invoices instructions
                                                                                $instruction_data['Status_2'] = '5';
                                                                                $this->seguceModel->update_instructions_occ($instruction_data, $invoice->Id_0);

                                                                                #Updating invoices
                                                                                $invoice_data['Status_2'] = '6';
                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $data['Type'] = 'EXT';

                                                                        //$response_prov = $this->curl_model->call_bank_virement_occ($data);
                                                                       // $return_prov = json_decode($response_prov, true);
                                                                        $return_prov['response'] = "200";
                                                                        if(isset($return_prov['response']) && $return_prov['response'] =='200')
                                                                        {
                                                                                #Updated provisions
                                                                                if ($livraison == 'T')
                                                                                {
                                                                                        $data_provision['Status_2'] = '3';
                                                                                        $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                }

                                                                                if ($livraison == 'P')
                                                                                {
                                                                                        if($provisions[$invoice->Licence_8] >= $amounts[$invoice->Licence_8])
                                                                                        {
                                                                                                $provision_amount_gap = $provisions[$invoice->Licence_8] - $amounts[$invoice->Licence_8];

                                                                                                $data_provision['Status_2'] = ($provisions[$invoice->Licence_8] == $amounts[$invoice->Licence_8]) ? '3' : '4';
                                                                                                $data_provision['Montantprov_7'] = $provision_amount_gap;
                                                                                                $data_provision['AmountPartial_26'] = $amounts[$invoice->Licence_8];

                                                                                                $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                                $data_provision['Status_2'] = '3';
                                                                                                $data_provision['Montantprov_7'] = 0;
                                                                                                $data_provision['AmountPartial_26'] = $provisions[$invoice->Licence_8];

                                                                                                $this->seguceModel->update_provisions($data_provision, $invoice->Licence_8);
                                                                                        }
                                                                                }

                                                                                #Check balance
                                                                                $bal_data['bank_account'] = $invoice->Compte_19;
                                                                                $bal_data['devise_account'] = $invoice->Devise_20;
                                                                                $bal_data['amount'] = $invoice->Devise_20;

                                                                                $bal_result = $this->data('get_balance_by_customer_account', $bal_data);

                                                                                if ($bal_data['devise_account'] == 'CDF')
                                                                                {
                                                                                        $customer_balance = $bal_result / $taux;
                                                                                }
                                                                                else
                                                                                {
                                                                                        $customer_balance = $bal_result;
                                                                                }

                                                                                $total_topaid_licence = $amounts[$invoice->Licence_8];

                                                                                if ((isset($customer_balance) && $customer_balance >= 0) && (int) $customer_balance >= (int) $amounts[$invoice->Licence_8])
                                                                                {
                                                                                        $data['Type'] = '';
                                                                                        //$response = $this->curl_model->call_bank_virement_occ($data);

                                                                                        //$return = json_decode($response, true);
                                                                                        $return['response'] = "200";
                                                                                        $validation[$row]['response'] = $return['response'];

                                                                                        if(isset($return['response']) && $return['response'] == "200")
                                                                                        {
                                                                                                $code = 200;

                                                                                                $invoice_data['Status_2'] = '3';
                                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);

                                                                                                $data_partial['Status_2'] = '2';
                                                                                                $this->seguceModel->update_instructions_partail_occ($data_partial, $invoice->Id_0);

                                                                                        }
                                                                                        else
                                                                                        {
                                                                                                $code = $return['response'];

                                                                                                $invoice_data['Status_2'] = '5';
                                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                                        }
                                                                                }
                                                                                else
                                                                                {
                                                                                        $code = 'E501';

                                                                                        $validation[$row]['response'] = $code;

                                                                                        $instruction_partial = $this->seguceModel->get_instructions_partial_invoices_occ($invoice->Id_0);

                                                                                        $instruction_frais = $this->seguceModel->get_instructions_invoices_occ($paiementid_bordereau);

                                                                                        foreach ($instruction_frais as $row)
                                                                                        {
                                                                                                if ($row->Type_26 == 'COM')
                                                                                                {
                                                                                                        $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                                        $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[0]->Montant_10;
                                                                                                        $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[0]->Montant_24;

                                                                                                        $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'COM');
                                                                                                }

                                                                                                if ($row->Type_26 == 'TVA')
                                                                                                {
                                                                                                        $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                                        $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[1]->Montant_10;
                                                                                                        $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[1]->Montant_24;

                                                                                                        $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'TVA');
                                                                                                }
                                                                                        }

                                                                                        #Updated invoices instructions
                                                                                        //$instruction_data['Status_2'] = '5';
                                                                                        //$this->seguceModel->update_instructions_occ($instruction_data, $invoice->Id_0);

                                                                                        #Updating invoices
                                                                                        $invoice_data['Status_2'] = '6';
                                                                                        $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                $code = 'E502';

                                                                                $validation[$row]['response'] = $code;

                                                                                #Updated invoices instructions
                                                                                $instruction_data['Status_2'] = '1';
                                                                                $this->seguceModel->update_instructions_occ($instruction_data, $invoice->Id_0);

                                                                                #Updating invoices
                                                                                $invoice_data['Status_2'] = '5';
                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $bal_data['bank_account'] = $invoice->Compte_19;
                                                                $bal_data['devise_account'] = $invoice->Devise_20;
                                                                $bal_data['amount'] = $invoice->Devise_20;

                                                                $bal_result = $this->data('get_balance_by_customer_account', $bal_data);

                                                                if ($bal_data['devise_account'] == 'CDF')
                                                                {
                                                                        $customer_balance = $bal_result / $taux;
                                                                }
                                                                else
                                                                {
                                                                        $customer_balance = $bal_result;
                                                                }

                                                                if ((isset($customer_balance) && $customer_balance >= 0) && $customer_balance >= $amounts[$invoice->Licence_8])
                                                                {
                                                                        $data['Type'] = '';

                                                                        //$response = $this->curl_model->call_bank_virement_occ($data);
                                                                        //$return = json_decode($response, true);
                                                                        $return['response'] = "200";
                                                                        $validation[$row]['response'] = $return['response'];

                                                                        if(isset($return['response']) && $return['response'] == "200")
                                                                        {
                                                                                $code = 200;

                                                                                $invoice_data['Status_2'] = '3';
                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);

                                                                                $data_partial['Status_2'] = '2';
                                                                                $this->seguceModel->update_instructions_partail_occ($data_partial, $invoice->Id_0);
                                                                        }
                                                                        else
                                                                        {
                                                                                $code = $return['response'];

                                                                                $invoice_data['Status_2'] = '5';
                                                                                $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $code = 'E501';

                                                                        $validation[$row]['response'] = $code;

                                                                        $instruction_partial = $this->seguceModel->get_instructions_partial_invoices_occ($invoice->Id_0);

                                                                        $instruction_frais = $this->seguceModel->get_instructions_invoices_occ($paiementid_bordereau);

                                                                        foreach ($instruction_frais as $row)
                                                                        {

                                                                                if ($row->Type_26 == 'COM')
                                                                                {
                                                                                        $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                        $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[0]->Montant_10;
                                                                                        $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[0]->Montant_24;

                                                                                        $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'COM');
                                                                                }

                                                                                if ($row->Type_26 == 'TVA')
                                                                                {
                                                                                        $frais_data_updated['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                        $frais_data_updated['Montant_10'] = $row->Montant_10 - $instruction_partial[1]->Montant_10;
                                                                                        $frais_data_updated['Montant_24'] = $row->Montant_24 - $instruction_partial[1]->Montant_24;

                                                                                        $this->seguceModel->update_instructions_frais_boredereau_occ($frais_data_updated, $paiementid_bordereau, 'TVA');
                                                                                }
                                                                        }

                                                                        #Updating invoices
                                                                        $invoice_data['Status_2'] = '6';
                                                                        $invoice_updated = $this->seguceModel->update_invoice_occ($invoice_data, $id);
                                                                }
                                                        }
                                                }
                                        }

                                        $result = json_encode($validation);

                                        echo $result;

                                }
                                else
                                {
                                        $validation = array('code'=>0);

                                        $result = json_encode($validation);
                                        echo $result;
                                }

                        }
                }
                elseif($obj == "validate_fees_invoices")
                {
                        $instruction_ids = array();
                        $return_merged = array();
                        $validation = array();

                        $data = $_POST;
                        $code = '';

                        $batch_id = $data['batch_id'];
                        $clts = $data['clts'];

                        $fees_ids = $data['fees_ids'];

                        $batch_ref = $data['batch_ref'];

                        if(isset($batch_id) && $batch_id!= "")
                        {
                                foreach ($clts as $key => $line)
                                {
                                        $instructions = $this->seguceModel->get_instructions_invoices_occ_by_clt($batch_id, $line);

                                        foreach ($instructions as $row)
                                        {
                                                $instruction_ids[] = $row->Id_0;
                                        }

                                        $validation = array();

                                        if($_SESSION['Logiref_role'] == 3)
                                        {
                                                # Priority of transactions to send to the API set to 1.
                                                $data['Priority'] = 1;
                                                $data['batch_id'] = $batch_id;
                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                $data["Codeimport_28"] = $line;
                                                $data['Account_3'] = $this->session->userdata['user_id'];
                                                $data['Reference'] = $batch_ref;

                                                #Invocation of the api transfer
                                                @set_time_limit(300);
                                                $core_banking = strtolower($this->core_banking);
                                                $response = $this->{$core_banking}->virement_occ($data);
                                                $return = json_decode($response, true);

                                                foreach ($return as $key => $values)
                                                {
                                                        if (is_int($key) && is_array($values))
                                                        {
                                                                if (is_array($values) && isset($values['code']))
                                                                {
                                                                        $return_merged[$key]['code'] = $values['code'];
                                                                }
                                                        }
                                                }

                                                foreach ($fees_ids as $row)
                                                {
                                                        if (isset($return_merged[$row]['code']))
                                                        {
                                                                $validation[$row]['response'] = $return_merged[$row]['code'];
                                                        }
                                                        // else
                                                        // {
                                                        //         $validation[$row]['response'] = 405;
                                                        // }
                                                }

                                                if(isset($return['response']) && $return['response'] == "200")
                                                {
                                                        $code = 200;

                                                        $data_inst['Status_2'] = '3';
                                                        $data_inst['Priority_27'] = '1';
                                                        $inst_updated = $this->seguceModel->update_instructions_fees($data_inst, $batch_id, $line);

                                                        $instruction = $this->seguceModel->get_instructions_invoices_occ_by_batchid($batch_id);

                                                        $data_batch['Status_2'] = (empty($instruction)) ? '4': '3';
                                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);
                                                }
                                                else
                                                {
                                                        $code = $return['response'];

                                                        $instruction = $this->seguceModel->get_instructions_invoices_occ_not_integrated($batch_id);

                                                        $data_batch['Status_2'] = (empty($instruction)) ? '4': '3';
                                                        $data_batch['Changes_5'] = gmdate('Y-m-d H:i:s');

                                                        $this->seguceModel->update_invoice_occ_batchs($data_batch, $batch_id);
                                                }
                                        }
                                }

                                $result = json_encode($validation);

                                echo $result;
                        }
                        else
                        {
                                $validation = array('code'=>0);

                                $result = json_encode($validation);
                                echo $result;
                        }
                }
                elseif ($obj == "validate_invoice_preview")
                {
                        $data = $_POST;
                        $code = '';

                        $id = $_POST['Id_0'];

                        # Priority of transactions to send to the API set to 1.
                        $data['Priority'] = 1;

                        #Invocation of the api transfer
                        @set_time_limit(300);
                        //$core_banking = strtolower($this->core_banking);
                        //$response = $this->{$core_banking}->virement($data);

                        //$return = json_decode($response, true);

                        $return['response'] = '200';

                        if (isset($return['response']) && $return['response'] == "200") {

                                $data_to_validate['Status_2'] = 2;
                                $data_to_validate['Changer_6'] = $this->session->userdata['user_id'];

                                $fid = $this->seguceModel->update_invoice_occ($data_to_validate, $id);

                                $code = 200;
                        } elseif (isset($return['response']) && $return['response'] == "300") {
                                $code = 300;
                        }

                        if ($code == 200) {
                                echo 'E200';
                        } else {
                                echo 0;
                        }
                }
                elseif ($obj == "validate_invoice_partial")
                {
                        $data = $_POST;
                        $code = '';

                        $invoices = $this->seguceModel->get_invoices_occ_regularized($_POST['invoice_regulId']);

                        foreach ($invoices as $row) {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['invoice_id'] = $row->Id_0;
                                $data['Designation'] = $row->Designation_13;
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                #Invocation of the api transfer
                                @set_time_limit(300);

                                //$response = $this->amplitude->call_bank_batch_invoice_partial_integration($data);
                                $response = json_encode([]);

                                $return = json_decode($response, true);

                                if (isset($return['response']) && $return['response'] == "200") {
                                        $code = 200;
                                        $invoice_data['Status_2'] = '3';
                                        $invoice = $this->seguceModel->update_invoice_occ($invoice_data, $row->Id_0);
                                } elseif (isset($return['response']) && $return['response'] == "300") {
                                        $code = 300;
                                        $invoice_data['Status_2'] = '5';
                                        $invoice = $this->seguceModel->update_invoice_occ($invoice_data, $row->Id_0);
                                } elseif (isset($return['response']) && $return['response'] == "404") {
                                        $code = 404;
                                        $invoice_data['Status_2'] = '5';
                                        $invoice = $this->seguceModel->update_invoice_occ($invoice_data, $row->Id_0);
                                } elseif (isset($return['response']) && $return['response'] == "411") {
                                        $code = 411;
                                        $invoice_data['Status_2'] = '5';
                                        $invoice = $this->seguceModel->update_invoice_occ($invoice_data, $row->Id_0);
                                } elseif (isset($return['response']) && $return['response'] == "405") {
                                        # Aucune ecriture trouvE 
                                        $code = 405;
                                        $id = $invoice = $row->Id_0;
                                } elseif ($return == false || $return == NULL) {
                                        $code = 411;
                                        $invoice_data['Status_2'] = '5';
                                        $invoice = $this->seguceModel->update_invoice_occ($invoice_data, $row->Id_0);
                                }

                                if (isset($invoice) && $invoice > 0) {
                                        $data_regul['Status_2'] = '2';

                                        $this->seguceModel->update_invoice_occ_issues($data_regul, $row->Regulid_18);

                                        $retour = array('code' => $code, 'id' => $row->Id_0);
                                        echo json_encode($retour);
                                } else {
                                        $retour = array('code' => 0, 'id' => $row->Id_0);
                                        echo json_encode($retour);
                                }
                        }
                }
                elseif ($obj == "exempted_customer")
                {
                        $fields = array(

                                'Codeimport_11' => 'code',
                                'Designation_7' => 'designation',
                                'Account_13' => 'account',
                                'Currency_14' => 'currency'
                        );
                        foreach ($fields as $field => $value) {
                                $data[$field] = $this->request->getPost($value); //On assigne les valeurs de input aux champs de la DB
                        }

                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        if (isset($_POST['guichet'])) $data['Agence_9'] = $_POST['guichet'];

                        if ($_SESSION['Logiref_role'] == 1) :

                                $data['Validation_12'] = '0000-00-00';
                                $data['Changer_6'] = 0;
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                        else :
                                $data['Validation_12'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                        endif;

                        #Database
                        $cid = $this->feesModel->save_exempt_customers($data, $id);
                        if ($cid) :
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                } 
                elseif ($obj == "invoicefees") 
                {
                        $fields = array(
                                'Frais_intervention_13' => 'frais',
                                'Frais_achat_9' => 'achat',
                                'Frais_seguce_7' => 'seguce',
                                'Frais_validation_11' => 'validation',
                                'Tva_15' => 'tva',
                                'Devise_8' => 'deviseseguce',
                                'Devise_10' => 'devisefrais',
                                'Devise_12' => 'devisevalidation',
                                'Devise_14' => 'deviseintervention',
                                'Devise_16' => 'devisetva',
                        );
                        foreach ($fields as $field => $value) {
                                $data[$field] = $this->request->getPost($value); //On assigne les valeurs de input aux champs de la DB
                        }



                        $data['Frais_intervention_13'] = str_replace(',', '.', $data['Frais_intervention_13']);
                        $data['Frais_achat_9'] = str_replace(',', '.', $data['Frais_achat_9']);
                        $data['Frais_seguce_7'] = str_replace(',', '.', $data['Frais_seguce_7']);
                        $data['Frais_validation_11'] = str_replace(',', '.', $data['Frais_validation_11']);
                        $data['Tva_15'] = str_replace(',', '.', $data['Tva_15']);

                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        $data['Creator_4'] = $this->session->userdata['user_id'];
                        if ($_SESSION['Logiref_role'] == 1) :
                                $data['Changes_5'] = '0000-00-00';
                                $data['Changer_6'] = 0;
                        else :
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                        endif;

                        $rid = $this->seguceModel->save_invoicefees($data, $id); // Enregistre les donnees dans la bd
                        if ($rid) :
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert alert-danger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "validate_paiments")
                {
                        $error = '';
                        if ($_POST['Refbfu'] == '' || $_POST['Refbfu'] == NULL) $error = '<div class="alert alert-danger text-white">Le compte de pr&eacute;paiement ne peut pas &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        return $error;
                }
                elseif($obj=="validate_encaissement_facture")
                {
                        $array = array();
                        #$invoices = unserialize($data['invoices']);

                        $invoice_id = isset($_POST['invoices_id']) ? $_POST['invoices_id'] : "";

                        $invoice = $this->seguceModel->get_treated_invoice_by_factureid($invoice_id);
                     
                        $taux = $data['taux'];
                        $total_invoices = 0;
                        $array['total_invoices'] = 0;
                        $array['total_topaid'] = 0;
                        $array['total_acb'] = 0;
                        $array['total_frais'] = 0;
                        $array['total_tva'] = 0;
                        $array['total_licence_fees'] = 0;
                        $array['total_licence_fees'] = 0;
                        $array['total_amount'] = 0;
                        $array['total_folder_bank'] = 0;
                        $array['total_folder'] = 0;
                        $array['balance'] = false;
                        $invoices_bank = 0;
                        
                        if ($invoice->Typefacture_23 == "GUICE") 
                        {
                                $agence = $_SESSION['Logiref_guichet'];
                                $recette = "FUGLI";
                                //$recette = "FUGPI";
                                $regie = "SEGUCE";
                                $devise = "USD";

                                $rules = $this->feesModel->get_bank_charges($regie, NULL, $recette, $devise, NULL, $agence);

                                if ($rules['Valeur'] != '' && $rules['Unite'] != '') {
                                        $commission = $rules['Valeur'];
                                        $devise_com = $rules['Unite'];
                                }

                                $total = $invoice->Montant_11 * $data['taux'];

                                $total_invoices +=   $total;

                                if($this->bank == 'Rawbank'):
                                        $tva = ($commission * 16) / 100;
                                        $frais_cfb = $commission - $tva; // en USD
                                else:
                                        $tva = ($commission * 16) / 100;
                                        $frais_cfb = $commission; // en USD
                                endif;

                                $array['total_frais'] += ($taux * $frais_cfb);
                                $array['total_tva'] += ($taux * $tva);

                        } 
                        elseif ($invoice->Typefacture_23 == "GUICELOG") 
                        {
                                $total_invoices +=   $invoice->Contrevaleur_33;
                                $invoice_frais = 12.93; // en USD
                                $frais_acb = 5; // en USD

                                $tva = ($invoice_frais * 16) / 100;

                                $array['total_acb'] += ($taux * $frais_acb);
                                $array['total_frais'] += ($taux * $invoice_frais);
                                $array['total_tva'] += ($taux * $tva);
                        } 
                        elseif ($invoice->Typefacture_23 == "INVDIB") 
                        {
                                $bank_invoice = 40.6;
                                $array['total_folder_bank'] += $bank_invoice = $bank_invoice * $taux;

                                $bank_fees = $bank_invoice - 34800;
                                $tva = ($bank_fees * 16) / 100;
                                $array['total_frais'] += $bank_fees;
                                $array['total_tva'] += $tva;
                        } 
                        elseif ($invoice->Typefacture_23 == "NP") 
                        {
                                $total_invoices +=   $invoice->Contrevaleur_33;
                                $invoice_amount = $invoice->Contrevaleur_33;
                                $invoice_frais = 10; // en USD
                                $tva = ($invoice_frais * 16) / 100;

                                $array['total_frais'] += ($taux * $invoice_frais);
                                $array['total_tva'] += ($tva * $taux);
                        }

                        
                        // Calcul du montant total Ã  payer en CDF
                        $array['total_invoices'] = $total_invoices;
                        $array['total_topaid'] = $array['total_invoices'] + $array['total_acb'] + $array['total_frais'] + $array['total_tva'];
                        $array['total_folder'] = $array['total_invoices'] + $array['total_folder_bank'];
                   
                        return $array;
                }
                elseif ($obj == "validate_encaissement")
                {
                        $array = array();
                        #$invoices = unserialize($data['invoices']);

                        $invoice_id = isset($_POST['invoices_id']) ? $_POST['invoices_id'] : "";
                        
                        $invoice_id = implode(',', $invoice_id);
                        
                        $invoices = $this->seguceModel->get_treated_invoices_by_id($invoice_id);

                        $taux = $data['taux'];
                        $total_invoices = 0;
                        $array['total_invoices'] = 0;
                        $array['total_topaid'] = 0;
                        $array['total_acb'] = 0;
                        $array['total_frais'] = 0;
                        $array['total_tva'] = 0;
                        $array['total_licence_fees'] = 0;
                        $array['total_licence_fees'] = 0;
                        $array['total_amount'] = 0;
                        $array['total_folder_bank'] = 0;
                        $array['total_folder'] = 0;
                        $array['balance'] = false;
                        $invoices_bank = 0;

                        foreach ($invoices as $invoice) :

                                if ($invoice->Typefacture_23 == "GUICE") {

                                        $agence = $_SESSION['Logiref_guichet'];
                                        $recette = "FUGLI";
                                        //$recette = "FUGPI";
                                        $regie = "SEGUCE";
                                        $devise = "USD";

                                        $rules = $this->feesModel->get_bank_charges($regie, NULL, $recette, $devise, NULL, $agence);

                                        if ($rules['Valeur'] != '' && $rules['Unite'] != '') {
                                                $commission = $rules['Valeur'];
                                                $devise_com = $rules['Unite'];
                                        }

                                        $total_invoices +=   $invoice->Contrevaleur_33;

                                        $tva = ($commission * 16) / 100;
                                        $frais_cfb = $commission - $tva; // en USD

                                        $array['total_frais'] += ($taux * $frais_cfb);
                                        $array['total_tva'] += ($taux * $tva);
                                } elseif ($invoice->Typefacture_23 == "GUICELOG") {
                                        $total_invoices +=   $invoice->Contrevaleur_33;
                                        $invoice_frais = 12.93; // en USD
                                        $frais_acb = 5; // en USD

                                        $tva = ($invoice_frais * 16) / 100;

                                        $array['total_acb'] += ($taux * $frais_acb);
                                        $array['total_frais'] += ($taux * $invoice_frais);
                                        $array['total_tva'] += ($taux * $tva);
                                } elseif ($invoice->Typefacture_23 == "INVDIB") {
                                        $bank_invoice = 40.6;
                                        $array['total_folder_bank'] += $bank_invoice = $bank_invoice * $taux;

                                        $bank_fees = $bank_invoice - 34800;
                                        $tva = ($bank_fees * 16) / 100;
                                        $array['total_frais'] += $bank_fees;
                                        $array['total_tva'] += $tva;
                                } elseif ($invoice->Typefacture_23 == "NP") {
                                        $total_invoices +=   $invoice->Contrevaleur_33;
                                        $invoice_amount = $invoice->Contrevaleur_33;
                                        $invoice_frais = 10; // en USD
                                        $tva = ($invoice_frais * 16) / 100;

                                        $array['total_frais'] += ($taux * $invoice_frais);
                                        $array['total_tva'] += ($tva * $taux);
                                }


                                // Calcul du montant total Ã  payer en CDF
                                $array['total_invoices'] = $total_invoices;
                                $array['total_topaid'] = $array['total_invoices'] + $array['total_acb'] + $array['total_frais'] + $array['total_tva'];
                                $array['total_folder'] = $array['total_invoices'] + $array['total_folder_bank'];

                        endforeach;

                        return $array;
                }
                /*elseif ($obj == "get_account_codeimport") {
                        $compte = $this->accountsModel->get_compte_by_codeimport($_POST['code']);
                        $response['compte'] = $compte->Agenceid_15 . "-" . $compte->Compte_6 . "-" . $compte->Clef_7;
                        $response['devise'] = $compte->Devise_8;

                        $return = json_encode($response);

                        echo $return;
                }*/
                elseif ($obj == "get_provision_start") 
                {
                        $amount = $data['MontantCIF_8'];
                        $currency = $data['Devise_9'];

                        $amount_treated = 0;
                        $parity = 0;

                        $taux = json_decode($this->session->get('Bank_rates'), true);

                        if (isset($data['taux'])) $taux['Dollar_4'] = $data['taux'];
                        if (isset($data['eur'])) $taux['Euro_5'] = $data['eur'];

                        if (isset($data['zar'])) {
                                $data['zar'] = str_replace(' ', '', $data['zar']);
                                $data['zar'] = str_replace(',', '.', $data['zar']);
                        } elseif (isset($data['gbp'])) {
                                $data['gbp'] = str_replace(' ', '', $data['gbp']);
                                $data['gbp'] = str_replace(',', '.', $data['gbp']);
                        } elseif (isset($data['zar'])) {
                                $data['chf'] = str_replace(' ', '', $data['chf']);
                                $data['chf'] = str_replace(',', '.', $data['chf']);
                        } elseif (isset($data['cad'])) {
                                $data['cad'] = str_replace(' ', '', $data['cad']);
                                $data['cad'] = str_replace(',', '.', $data['cad']);
                        }

                        $taux['Zar'] = isset($data['zar']) ? $data['zar'] : "";
                        $taux['Gbp'] = isset($data['gbp']) ? $data['gbp'] : "";
                        $taux['Chf'] = isset($data['chf']) ? $data['chf'] : "";
                        $taux['Cad'] = isset($data['cad']) ? $data['cad'] : "";

                        switch ($currency) {
                                case "USD":

                                        $amount_treated = $amount * 0.0232;

                                        break;

                                case "EUR":

                                        $amount = $amount * 0.0232;
                                        $parity = $taux['Dollar_4'] / $taux['Euro_5'];

                                        $amount_treated = $amount / $parity;

                                        break;

                                case "ZAR":

                                        $amount = $amount * 0.0232;
                                        $parity = $taux['Dollar_4'] / $taux['Rand_6'];

                                        $amount_treated = $amount / $parity;

                                        break;

                                case "CAD":

                                        $amount = $amount * 0.0232;
                                        $parity = $taux['Dollar_4'] / $taux['Cad_12'];

                                        $amount_treated = $amount / $parity;

                                        break;

                                case "GBP":

                                        $amount = $amount * 0.0232;
                                        $parity = $taux['Dollar_4'] / $taux['Pound_7'];

                                        $amount_treated = $amount / $parity;

                                        break;

                                case "CHF":

                                        $amount = $amount * 0.0232;
                                        $parity = $taux['Dollar_4'] / $taux['Chf_13'];

                                        $amount_treated = $amount / $parity;

                                        break;
                        }
                        return $amount_treated;
                }
                elseif ($obj == "get_provision_final")
                {
                        $amount = $data['amount_treated'];

                        $type = $data['type'];

                        switch ($type) {
                                case "CIF":
                                        $amount = $amount * 1;
                                        break;

                                case "FOB":

                                        $amount = $amount * 1.1546;

                                        break;

                                case "CFR":

                                        $amount = $amount * 1.004;

                                        break;
                        }

                        return $amount;
                } 
                elseif ($obj == "get_provision_by_licence") 
                {
                        $response = array();

                        $license = $_POST['license'];

                        $result = $this->seguceModel->get_provision_by_licence_id($license);

                        if (!empty($result)) {
                                $response['Licence_7'] = $result->Licence_7;
                                $response['MontantCIF_8'] = $result->MontantCIF_8;
                                $response['Devise_9'] = $result->Devise_9;
                                $response['Montantprov_10'] = $result->Montantprov_10;
                                $response['Compte_12'] = $result->Compte_12;
                                $response['Devise_13'] = $result->Devise_13;
                                $response['Codeimport_19'] = $result->Codeimport_19;
                        } else {
                                $response = array();
                        }

                        $return = json_encode($response);

                        echo $return;
                } 
                elseif ($obj == "get_customer_exempt") 
                {
                        $response = array();

                        $code_import = $arg;

                        $result = $this->feesModel->customer_exempt_provision_by_clt($code_import);

                        $response['provision'] = (!empty($result)) ? 'TRUE' : 'FALSE';

                        $return = json_encode($response);

                        return $return;
                } 
                elseif ($obj == "get_provision_by_license") 
                {
                        $response = array();

                        if (isset($_POST['license']) && $_POST['license']!='')
                        {
                                $result = $this->seguceModel->get_provision_by_license_aur($_POST['license']);

                                if (!empty($result)) 
                                {
                                        $response['check'] = true;
                                        $response['codeimport'] = $result->Codeimport_19;
                                        $response['montantCIF'] = $result->MontantCIF_8;
                                } 
                                else 
                                {
                                        $response['check'] = false;
                                }
                        }
                        else
                        {
                                $response['check'] = false;
                        }

                        echo json_encode($response);
                }
                elseif ($obj == "get_account_balance_by_provision")
                {
                        if(array_key_exists('eximtrade_seguce_fee_deduction',$this->functionalities['ALL']))
                        {
                                if (isset($_POST['MontantCIF_8']) && isset($_POST['Compte_21'])) {
                                        $data['MontantCIF_8'] = str_replace(' ', '', $_POST['MontantCIF_8']);
                                        $data['MontantCIF_8'] = str_replace(',', '.', $data['MontantCIF_8']);
                                        $data['Devise_9'] = isset($_POST['Devise_9']) ? $_POST['Devise_9'] : "";

                                        if (isset($_POST['SeguceFees_32']) && $_POST['SeguceFees_32'] != "") {
                                                $data['SeguceFees_32'] = str_replace(' ', '', $_POST['SeguceFees_32']);
                                                $data['SeguceFees_32'] = str_replace(',', '.', $data['SeguceFees_32']);
                                        } else {
                                                $data['SeguceFees_32'] = 0;
                                        }

                                        if (isset($_POST['LicenceFees_15']) && $_POST['LicenceFees_15'] != "") {
                                                $data['LicenceFees_15'] = str_replace(' ', '', $_POST['LicenceFees_15']);
                                                $data['LicenceFees_15'] = str_replace(',', '.', $data['LicenceFees_15']);
                                        } else {
                                                $data['LicenceFees_15'] = 0;
                                        }

                                        if (isset($_POST['ValidationFees_17']) && $_POST['ValidationFees_17'] != "") {
                                                $data['ValidationFees_17'] = str_replace(' ', '', $_POST['ValidationFees_17']);
                                                $data['ValidationFees_17'] = str_replace(',', '.', $data['ValidationFees_17']);
                                        } else {
                                                $data['ValidationFees_17'] = 0;
                                        }

                                        if (isset($_POST['RoyaltyFees_30']) && $_POST['RoyaltyFees_30'] != "") {
                                                $data['RoyaltyFees_30'] = str_replace(' ', '', $_POST['RoyaltyFees_30']);
                                                $data['RoyaltyFees_30'] = str_replace(',', '.', $data['RoyaltyFees_30']);
                                        } else {
                                                $data['RoyaltyFees_30'] = 0;
                                        }

                                        $result = json_decode($_SESSION['Bank_rates'], true);

                                        if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                                $taux = $result;
                                        } else {
                                                $taux = 1;
                                        }

                                        if (isset($data['Devise_9']) && $data['Devise_9'] == 'EUR') {
                                                $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Euro_5'];
                                                $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                        } elseif (isset($data['Devise_9']) && $data['Devise_9'] == 'ZAR') {
                                                $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Zar_7'];
                                                $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                        }

                                        if ($data['MontantCIF_8'] >= 10000) {
                                                $data['Montantprov_10'] = ($data['MontantCIF_8'] * 2.32) / 100;
                                        } else if ($data['MontantCIF_8'] > 0 && $data['MontantCIF_8'] < 10000) {
                                                $data['Montantprov_10'] = 232;
                                        } else if ($data['MontantCIF_8'] == 0) {
                                                $data['Montantprov_10'] = 0;
                                        }

                                        #Frais des licences
                                        if (isset($_POST['Devise_16']) && $_POST['Devise_16'] == 'EUR') {
                                                $data['LicenceFees_15'] =  $data['LicenceFees_15'] * $taux['Euro_5'];
                                                $data['LicenceFees_15'] = $data['LicenceFees_15'] / $taux['Dollar_4'];
                                        } elseif (isset($_POST['Devise_16']) && $_POST['Devise_16'] == 'ZAR') {
                                                $data['LicenceFees_15'] =  $data['LicenceFees_15'] * $taux['Zar_7'];
                                                $data['LicenceFees_15'] = $data['LicenceFees_15'] / $taux['Dollar_4'];
                                        }

                                        #Frais de validation de la licence
                                        if (isset($_POST['Devise_18']) && $_POST['Devise_18'] == 'EUR') {
                                                $data['ValidationFees_17'] =  $data['ValidationFees_17'] * $taux['Euro_5'];
                                                $data['ValidationFees_17'] = $data['ValidationFees_17'] / $taux['Dollar_4'];
                                        } elseif (isset($_POST['Devise_18']) && $_POST['Devise_18'] == 'ZAR') {
                                                $data['ValidationFees_17'] =  $data['ValidationFees_17'] * $taux['Zar_7'];
                                                $data['ValidationFees_17'] = $data['ValidationFees_17'] / $taux['Dollar_4'];
                                        }

                                        #Frais SEGUCE
                                        if (isset($_POST['Taux_seguce']) && $_POST['Taux_seguce'] != "") {
                                                if (isset($_POST['Devise_33']) && $_POST['Devise_33'] == 'EUR') {
                                                        $data['SeguceFees_32'] =  $data['SeguceFees_32'] * $taux['Euro_5'];
                                                        $data['SeguceFees_32'] = $data['SeguceFees_32'] / $_POST['Taux_seguce'];
                                                } elseif (isset($_POST['Devise_33']) && $_POST['Devise_33'] == 'ZAR') {
                                                        $data['SeguceFees_32'] =  $data['SeguceFees_32'] * $taux['Zar_7'];
                                                        $data['SeguceFees_32'] = $data['SeguceFees_32'] / $_POST['Taux_seguce'];
                                                }
                                        }

                                        #Frais Redevance
                                        if (isset($_POST['Devise_31']) && $_POST['Devise_31'] == 'EUR') {
                                                $data['RoyaltyFees_30'] =  $data['RoyaltyFees_30'] * $taux['Euro_5'];
                                                $data['RoyaltyFees_30'] = $data['RoyaltyFees_30'] / $taux['Dollar_4'];
                                        } elseif (isset($_POST['Devise_31']) && $_POST['Devise_31'] == 'ZAR') {
                                                $data['RoyaltyFees_30'] =  $data['RoyaltyFees_30'] * $taux['Zar_7'];
                                                $data['RoyaltyFees_30'] = $data['RoyaltyFees_30'] / $taux['Dollar_4'];
                                        }


                                        $total_topaid = $data['Montantprov_10'] + $data['LicenceFees_15'] + $data['ValidationFees_17'] + $data['SeguceFees_32'] + $data['RoyaltyFees_30'];

                                        if (isset($_POST['account_balance']) && isset($_POST['account_currency'])) {
                                                # this condition takes into account only two currencies for customer account
                                                if ($_POST['account_currency'] == 'USD') {
                                                        $provision_amount = $total_topaid;
                                                } else {
                                                        $provision_amount = $total_topaid / $taux['Dollar_4'];
                                                }

                                                if ($_POST['account_balance'] >= $total_topaid) {
                                                        # Compte approvissionné
                                                        echo '200';
                                                } else {
                                                        # Solde insuffisant
                                                        echo '300';
                                                }
                                        }
                                        else {
                                                echo '411';
                                                die;
                                        }
                                } else {
                                        echo '405';
                                        die;
                                }
                        }
                        elseif(array_key_exists('eximtrade_transaction_on_cif_amount',$this->functionalities['ALL']))
                        {
                                if(isset($_POST['MontantCIF_8']) && isset($_POST['Compte_21']) && isset($_POST['Devise_account']))
                                {
                                        $data['MontantCIF_8'] = str_replace(' ','',$_POST['MontantCIF_8']);
                                        $data['MontantCIF_8'] = str_replace(',','.',$data['MontantCIF_8']);
                                        $data['Devise_account'] = $_POST['Devise_account'];
                                        $data['Devise_9'] = $_POST['Devise_9'];

                                        if(isset($_POST['cif']))
                                        {
                                                $data['type'] = "CIF";
                                        }
                                        elseif(isset($_POST['fob']))
                                        {
                                                $data['type'] = "FOB";
                                        }
                                        elseif(isset($_POST['cfr']))
                                        {
                                                $data['type'] = "CFR";
                                        }

                                        if (!isset($data['type']))
                                        {
                                                echo 'E201';
                                                die;
                                        }
                                        else
                                        {
                                                $amount_treated = $this->data("get_provision_start", $data);

                                                $data['amount_treated'] = $amount_treated;

                                                $amount = $this->data("get_provision_final", $data);

                                                $data_to_check['bank_account'] = $_POST['Compte_21'];
                                                $data_to_check['devise_account'] = $_POST['Devise_account'];
                                                $data_to_check['amount'] = $amount;

                                                $return = $this->amplitude->check_balance($data_to_check);

                                                if(isset($_POST['Compte_21']) && isset($_POST['Devise_account']))
                                                {
                                                        if($return['code'] == 200)
                                                        {
                                                                # Compte approvissionné
                                                                echo '200';
                                                        }
                                                        else
                                                        {
                                                                # Solde insuffisant
                                                                echo '300';
                                                        }
                                                }
                                                else
                                                {
                                                        echo '411'; die;
                                                }
                                        }
                                }
                                else
                                {
                                        echo '405'; die;
                                }
                        }

                }
                elseif ($obj == "get_account_balance_by_licence")
                {
                        if (isset($_POST['MontantCIF_8']) && isset($_POST['Compte_20'])) {
                                $data['MontantCIF_8'] = str_replace(' ', '', $_POST['MontantCIF_8']);
                                $data['MontantCIF_8'] = str_replace(',', '.', $data['MontantCIF_8']);
                                $data['Devise_9'] = isset($_POST['Devise_9']) ? $_POST['Devise_9'] : "";

                                if (isset($_POST['LicenceFees_14']) && $_POST['LicenceFees_14'] != "") {
                                        $data['LicenceFees_14'] = str_replace(' ', '', $_POST['LicenceFees_14']);
                                        $data['LicenceFees_14'] = str_replace(',', '.', $data['LicenceFees_14']);
                                }
                                else {
                                        $data['LicenceFees_14'] = 0;
                                }

                                if (isset($_POST['ValidationFees_16']) && $_POST['ValidationFees_16'] != "") {
                                        $data['ValidationFees_16'] = str_replace(' ', '', $_POST['ValidationFees_16']);
                                        $data['ValidationFees_16'] = str_replace(',', '.', $data['ValidationFees_16']);
                                }
                                else {
                                        $data['ValidationFees_16'] = 0;
                                }

                                $result = json_decode($_SESSION['Bank_rates'], true);

                                if (isset($result['Dollar_4']) && $result['Dollar_4'] != "") {
                                        $taux = $result;
                                }
                                else {
                                        $taux = 1;
                                }

                                if (isset($data['Devise_9']) && $data['Devise_9'] == 'EUR') {
                                        $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Euro_5'];
                                        $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                }
                                elseif (isset($data['Devise_9']) && $data['Devise_9'] == 'ZAR') {
                                        $data['MontantCIF_8'] =  $data['MontantCIF_8'] * $taux['Zar_7'];
                                        $data['MontantCIF_8'] = $data['MontantCIF_8'] / $taux['Dollar_4'];
                                }

                                #Frais des licences
                                if (isset($_POST['Devise_15']) && $_POST['Devise_15'] == 'EUR') {
                                        $data['LicenceFees_14'] = $data['LicenceFees_14'] * $taux['Euro_5'];
                                        $data['LicenceFees_14'] = $data['LicenceFees_14'] / $taux['Dollar_4'];
                                } elseif (isset($_POST['Devise_15']) && $_POST['Devise_15'] == 'ZAR') {
                                        $data['LicenceFees_14'] = $data['LicenceFees_14'] * $taux['Zar_7'];
                                        $data['LicenceFees_14'] = $data['LicenceFees_14'] / $taux['Dollar_4'];
                                }

                                #Frais de validation de la licence
                                if (isset($_POST['Devise_17']) && $_POST['Devise_17'] == 'EUR') {
                                        $data['ValidationFees_16'] =  $data['ValidationFees_16'] * $taux['Euro_5'];
                                        $data['ValidationFees_16'] = $data['ValidationFees_16'] / $taux['Dollar_4'];
                                } elseif (isset($_POST['Devise_17']) && $_POST['Devise_17'] == 'ZAR') {
                                        $data['ValidationFees_16'] =  $data['ValidationFees_16'] * $taux['Zar_7'];
                                        $data['ValidationFees_16'] = $data['ValidationFees_16'] / $taux['Dollar_4'];
                                }

                                $total_topaid = $data['LicenceFees_14'] + $data['ValidationFees_16'];

                                if (isset($_POST['account_balance']) && isset($_POST['account_currency'])) {
                                        # this condition takes into account only two currencies for customer account
                                        if ($_POST['account_currency'] == 'USD') {
                                                $provision_amount = $total_topaid;
                                        }
                                        else {
                                                $provision_amount = $total_topaid / $taux['Dollar_4'];
                                        }

                                        if ($_POST['account_balance'] >= $total_topaid) {
                                                # Compte approvissionné
                                                echo '200';
                                        }
                                        else {
                                                # Solde insuffisant
                                                echo '300';
                                        }
                                }
                                else {
                                        echo '411';
                                        die;
                                }
                        }
                        else {
                                echo '405';
                                die;
                        }
                }
                elseif ($obj == "get_balance_by_customer_account") 
                {
                        //$return = $this->amplitude->call_bank_check_balance_invoice($data);
                        $return = json_encode([]);

                        $response = json_decode($return, true);

                        if ($response['code'] == '200') {
                                return $response['balance'];
                        } else {
                                return $response['balance'] = '';
                        }
                } 
                elseif ($obj == "get_occ_bivac_commission") 
                {
                        $type = $data;
                        $amount_to_treat = $arg;
                        $amount = 0;

                        switch ($type) {
                                case "OCC":

                                        $amount = ($amount_to_treat * 0.232) / 100;

                                        break;

                                case "BIVAC":

                                        $amount = ($amount_to_treat * 0.116) / 100;

                                        break;
                        }

                        return $amount;
                } 
                elseif ($obj == "get_reduce_decimal") 
                {
                        $numbers =  $data;
                        $decimal_point = $arg;

                        $decimal = explode('.', $numbers);

                        if (isset($decimal[1])) {
                                $decimal_point = ((int) $decimal_point > 0) ? $decimal_point : "0";

                                $reduce = substr($decimal[1], 0, $decimal_point);

                                if ($decimal_point == 0) {
                                        $numbers = $decimal[0];
                                } else {
                                        $numbers = $decimal[0] . '.' . $reduce;
                                }
                        }

                        return (float) $numbers;
                }
                elseif ($obj == "get_accountname")
                {
                        $data_bal = array();
                        $core_banking = strtolower($this->core_banking);

                        $account_customer = explode('-', $data);

                        $branch_code = $account_customer[0] . "-";

                        $branch_code = '/' . preg_quote($branch_code, '/') . '/';

                        $data_bal['Compte_33'] = preg_replace($branch_code, '',  $data, 1);

                        $return = $this->{$core_banking}->account_info($data_bal);

                        if(isset($return['code']) && $return['code'] == 404 || $return['code'] == 406 || $return['code'] == 405)
                        {
                                echo json_encode($return);
                        }
                        else
                        {
                                if(isset($return['account_name']) && $return['account_name'] != "")
                                {
                                        $return = json_encode($return);

                                        # return data in json format : account, devise, balance.
                                        echo $return;
                                }
                                else
                                {
                                        echo '406';
                                }
                        }

                        /*if ($return == '404' || $return == '406' || $return == '405') {
                                $response['balance'] = 0;

                                $return = json_encode($response);

                                return $return;
                        } else {
                                if (isset($return) && $return != "") {
                                        # return data in json format : account, devise, balance.
                                        $result = json_decode($return, true);

                                        $response['account'] = $result['account'];
                                        $response['devise'] = $result['devise'];
                                        $response['balance'] = $result['balance'];
                                        $response['branch_code'] = $result['branch_code'];

                                        $return = json_encode($response);
                                        return $return;
                                } else {
                                        return '406';
                                }
                        }*/
                }
                elseif ($obj == "get_characters_part") 
                {
                        $position = mb_stripos($data, $arg);

                        // Vérifier si la partie des caractères est présente dans la chaîne
                        if ($position !== false) {
                                return $arg;
                        } else {
                                return $data;
                        }
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
