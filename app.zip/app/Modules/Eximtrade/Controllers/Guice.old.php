<?php

namespace Modules\Eximtrade\Controllers;

use DateTime;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Eximtrade\Models\CurlModel;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\FeesModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Eximtrade\Models\GuiceModel;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Modules\Admin\Models\StakeholderModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Seguce\Controllers\SeguceSFTP;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Comptabilisation\Controllers\ComptabilisationSeguce;
use Modules\Services\Comptabilisation\Models\ComptabilisationSeguceModel;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Temenos\Controllers\Temenos;

class Guice extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Alain on the 8.03.2026
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('invoice', 'report_invoices', 'validated_invoices', 'nvalidated','nvalidated_invoices', 'validated', 'exemptcustomers', 'feesinvoice','provision','invoice_occ_batch','regularize_invoices_occ','provision_batch');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'guice';
        public $role;
        public $seguceModel;
        public $feesModel;
        public $dataModel;
        public $comptabilisationModel;
        public $comptabilisationSeguceModel;
        public $encaissementModel;
        public $curlModel;
        public $usersModel;
        public $mainModel;
        public $logirefModel;
        public $stakeholderModel;
        public $accountsModel;
        public $branchesModel;
        public $licenceModel;
        public $integrationModel;
        public $flexcube;
        public $amplitude;
        public $functionalities;
        public $bank;
        public $core_banking;
        public $temenos;
        public $ratesModel;
        public $seguceSFTP;
        public $fibridge;
        public $seguceAPI;
        public $spreadsheet=null;
        public $comptabilisation;
        public $options;
        public $finacle_standardbank;
        public $bsqr;
        public $guiceModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->seguceModel = new SeguceModel();
                $this->guiceModel  = new GuiceModel();
                $this->feesModel = new FeesModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->comptabilisationSeguceModel = new ComptabilisationSeguceModel();
                $this->curlModel = new CurlModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->accountsModel = new AccountsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->branchesModel = new BranchesModel();
                $this->licenceModel = new LicenceModel();
                $this->ratesModel = new RatesModel();
                $this->integrationModel = new IntegrationModel();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->amplitude = new Amplitude();
                $this->seguceSFTP = new SeguceSFTP();
                $this->fibridge = new FIBridge();
                $this->spreadsheet=new Spreadsheet();
                $this->comptabilisation = new ComptabilisationSeguce();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->bsqr = new Bsqr();
                $this->seguceAPI = new Seguce();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'guice';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                $this->data['modes'] = $this->seguceModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);
                
                $this->bank = ucfirst(strtolower($this->session->userdata["account_restrict"]));

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                } else {
                        return redirect()->to(base_url($this->module));
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "start")
                {
                        $this->data['invoices'] = $this->guiceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\guice\_start', $this->data);
                }
                elseif ($obj === "verification") 
                {
                        $ref_invoice = $_POST['numero_facture'] ?? "";
                        $invoices    = $this->guiceModel->get_invoice_by_reference($ref_invoice);

                        if (!empty($invoices)) 
                        {
                                switch ($invoices->Status_2) 
                                {
                                        case 1:
                                                break;
                                        case 2:
                                                echo  "E201"; die;
                                        case 3:
                                             echo  "E203"; die;
                                        case 5: case 6:
                                                echo  "E205"; die;
                                        default:
                                                echo  "E405"; die;
                                }
                        } 
                        else 
                        {
                                $response = $this->data('get_invoices', $_POST);

                                if (($response['code'] ?? "") == 'E200'):
                                        $invoices = $response['data'] ?? [];
                                else:
                                        echo $response['code']; die;
				endif;
                        }

                        $this->data['object_info']  = $invoices ?? null;
                        $this->data['invoice_bank'] = false;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_1', $this->data);
                }
                elseif ($obj === "treat_invoice") 
                {
                        $result = $this->data('calculate_invoice_totals', $_POST);

                        $taux         = $_POST['taux'] ?? 1;
                        $guice_rate   = $_POST['guice_rate'] ?? null;
                        $devise       = $_POST['Devise_account'] ?? '';
                        $total_topaid = $result['total_topaid'] ?? 0;

                        # Calcul du montant total
                        if ($devise === 'USD') 
                        {
                                $rate = $guice_rate ?: $taux;
                                $total_amount = $total_topaid / $rate;
                        } 
                        else 
                        {
                                $total_amount = $total_topaid;
                        }

                        $data = [
                                'bank_account'   => $_POST['Compte_33'] ?? "",
                                'devise_account' => $devise,
                                'amount'         => $total_amount,
                                'taux'           => $taux,
                        ];

                        # Vérification du solde
                        if (!empty($this->options['ALL']['retrieve-balance-with-account-info'])) 
                        {
                                $balance = $_POST['account_balance'] ?? 0;

                                if ($devise === 'CDF') 
                                {
                                        $response['code'] = ($balance >= $total_amount) ? '200' : '300';
                                } 
                                elseif ($devise === 'USD') 
                                {
                                        $converted_balance = $balance / $taux;
                                        $response['code'] = ($converted_balance >= $total_amount) ? '200' : '300';
                                }
                        } 
                        else 
                        {
                                $core_banking = strtolower($this->core_banking);
                                $response = $this->{$core_banking}->check_balance($data);
                        }

                        // --- Gestion des réponses ---
                        if ($response['code'] == 200) 
                        {
                                $result['code']    = 'E200';
                                $result['balance'] = true;
                        } 
                        elseif ($response['code'] == 300) 
                        {
                                $result['code']    = 'E300';
                                $result['balance'] = false;
                        } 
                        else 
                        {
                                $result['code']    = 'E411';
                        }

                        # Préparation comptabilisation 
                        $instructions_data = $this->data('prepare_instructions_data', $_POST);
                        $instructions      = $this->comptabilisation->get_instructions_seguce($instructions_data);

                        $this->data['lines'] = $instructions;

                        # On génère le HTML et on l’ajoute au JSON
                        $result['html'] = view('\Modules\Eximtrade\Views\guice\_comptabilisation', $this->data);

                        echo json_encode($result);
                }
                elseif ($obj == "verify_transaction") 
                {
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3']      = $this->session->userdata['account_id'];
                        $data['Logirefid_4']    = $_POST['logirefid'] ?? "";
                        $data['Seguce_53']      = $_POST['invoice_id'] ?? "";
                        $data['Id_0']           = $_POST['invoice_id'] ?? "";
                        $data['Type']           = "GUICE";
                        $data['Error_code']     = $_POST['error_code'] ?? "";
                        $data['transaction_id'] = $_POST['transaction_id'] ?? "";
                        $data['Priority']       = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'invoice_guice_verification_treatment'))
                        {
                                $return = $this->{$core_banking}->invoice_guice_verification_treatment($data);
                                $result = json_decode($return, true);
                                
                                if (($result['code'] ?? "") == "E200")
                                {  
                                        $result['id'] = $_POST['invoice_id'] ?? "";
                                        
                                        $data_to_update = [];    
                                        $data_to_update['Status_2'] = 2;
                                        $data_to_update['Validation_49'] = date('Y-m-d H:i:s');
                                        $this->guiceModel->update_invoice($data_to_update, $data['Id_0'] );
                                }

                                //echo $return;
                                echo json_encode($result);
                                die;
                        }
                        else
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                elseif ($obj == "edit")
                {
                        $invoice      = $this->guiceModel->get_paiement_invoice($id);
                        $integrations = $this->guiceModel->get_instructions_invoice($id);
                
                        $integration_status = [];
                        foreach($integrations as $row)
                        {
                                $integration_status[$row->Id_0] = $row->Status_2;
                        }

                        $this->data['integration_status']  = $integration_status ?? null;
                        $this->data['invoice']  = $invoice ?? null;
                        $this->data['invoice_bank'] = false;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_1_process', $this->data);
                }
                elseif($obj=="preview")
                {
                        $instructions = $this->comptabilisationModel->get_instructions_seguice($id);
                        $invoice      = $this->guiceModel->get_paiement_invoice($id);
                        
                        foreach ($instructions as $row) 
                        {
                                $integrations[$row->Id_0] = $row;
                        }

                        $this->data['invoice']      = $invoice;
                        $this->data['references']   = $integrations;
                        $this->data['integrations'] = $instructions;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_2', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj === "reservation") 
                {
                        $data = $_POST;
                        $_POST['invoices_id'] = $data['invoice_id'] ?? "";

                        if (empty($_POST['invoice_id'])) 
                        {
                                echo json_encode(['code' => 'E000']);
                                return;
                        }

                        $agence     = $this->session->get('Logiref_guichet');
                        $ref        = $agence.date('Hisjmy');
                        $logirefid  = $data['Noteid_26'] = $this->seguceModel->generate_unique_reference();
                        $invoice    = $this->guiceModel->check_invoice();

                        if (empty($invoice[0]->Id_0)) 
                        {
                                $this->data('update_and_respond', 'E515', $invoice[0]->Id_0 ?? null);
                                return;
                        }

                        $invoice_id  = $invoice[0]->Id_0;
                        $transaction = $this->guiceModel->get_instructions_invoice($invoice_id);

                        if (!empty($transaction)) 
                        {
                                $lines = $this->data('map_transaction_lines', $transaction);

                                if ($this->data('all_lines_status', $lines, "1")) 
                                {
                                        $result_data = [
                                                'invoice_id' => $invoice_id,
                                                'logirefid'  => $invoice[0]->Logirefid_31,
                                        ];

                                        $response = $this->data('call_corebanking_reservation', $invoice_id, $invoice[0]->Logirefid_31);

                                        $data['total_frais']    = $invoice[0]->Commission_17;
                                        $data['Notemontant_28'] = $invoice[0]->Contrevaleur_33;
                                        $data['Devise_12']      = 'CDF';
                                        $data['compte_suspens'] = $invoice[0]->Account_19;

                                        $return = $this->data('handle_corebanking_response', $response, $result_data, $data);
                                } 
                                elseif ($this->data('any_line_status', $lines, ["4","5"])) 
                                {
                                        $return =  $this->data('process_reservation_error', $lines, $invoice_id);
                                } 
                                elseif ($this->data('all_lines_status', $lines, "2")) 
                                {
                                        $return = $this->data('update_and_respond', 'E500', $invoice_id, $lines[3]['reference']);
                                }
                        } 
                        else 
                        {
                                // Pas de transaction → préparation comptabilisation
                                $instructions_data = $this->data('prepare_instructions_data', $_POST);
                                $instructions      = $this->comptabilisation->get_instructions_seguce($instructions_data);
                                
                                if (!empty($instructions)) 
                                {
                                        $pid = $this->comptabilisationSeguceModel->save_seguce_instructions($invoice_id, $instructions_data, $instructions, $logirefid);

                                        if ($pid) 
                                        {
                                                $result_data = [
                                                        'invoice_id' => $invoice_id,
                                                        'logirefid'  => $logirefid,
                                                ];

                                                $response = $this->data('call_corebanking_reservation', $invoice_id, $logirefid);

                                                $data['total_frais']    = $instructions_data['Commission_23'];
                                                $data['Notemontant_28'] = $instructions_data['Notemontant_28'];
                                                $data['Devise_12']      = $instructions_data['Devise_12'];
                                                $data['compte_suspens'] = $instructions[0]['Compte_13'];

                                                $return = $this->data('handle_corebanking_response', $response, $result_data, $data);
                                        } 
                                        else
                                        {
                                                $return = $this->data('update_and_respond', 'E515', $invoice_id);
                                        }
                                }
                        }

                        echo $return;
                }
                elseif ($obj === "validate") 
                {
                        $errors     = [];
                        $validation = [
                                'errors' => false, 
                                'code'   => ''
                        ];

                        $invoiceid = $_POST['factureid'] ?? "";
                        $invoice   = $this->guiceModel->get_unvalidated_invoice_by_id($invoiceid);

                        if (!empty($invoice) && in_array($_SESSION['Logiref_role'], [2,3])) 
                        {
                                $data = [
                                        'Priority'       => 1,
                                        'Id_0'           => $invoice->Id_0,
                                        'Seguice_53'     => $invoice->Id_0,
                                        'Beneficaire_15' => 'SEGUCE',
                                        'Designation_14' => $invoice->Debiteur_25,
                                        'Logirefid_4'    => $invoice->Logirefid_31,
                                        'Account_3'      => $_SESSION['userdata']['account_id'] ?? '',
                                ];

                                @set_time_limit(300);
                                $instruction = current($this->comptabilisationModel->get_instructions_seguice_by_priority($invoice->Id_0, 1));

                                $core_banking = strtolower($this->core_banking);

                                if (method_exists($this->{$core_banking}, 'virement')) 
                                {
                                        $response = $this->{$core_banking}->virement($data);
                                        $return   = json_decode($response, true);

                                        # On conserve la traçabilité par instruction
                                        $validation[$instruction->Id_0]['response'] = $return['response'] ?? null;

                                        $code = $this->data('handle_validation_response', $return, $invoice);

                                        if ($code !== 200) 
                                        {
                                                $errors[$invoice->Id_0] = $code;
                                                $validation['errors']   = true;
                                        }

                                        $validation['code'] = $code;
                                } 
                                else 
                                {
                                        echo json_encode(['code' => 'E407']);
                                        die;
                                }
                        }

                        echo json_encode($validation);
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "get_invoices") 
                {
                        $invoices   = [];
                        $account_id = $_SESSION['userdata']['account_id'] ?? "";

                        $postdata['ID']        = $data['numero_facture'];
                        $postdata['Account']   = $account_id;
                        $postdata['Branchid']  = $_SESSION['Logiref_guichet'] ?? "";
                        $postdata['Agence']    = $_SESSION['Logiref_agence'] ?? "";
                        $postdata['Makerid']   = $_SESSION['userdata']['user_id'] ?? '';

                        # Appel au service SEGUCE
                        $response = $this->curl(base_url('services/seguce/invoiceQuery'),'POST',$postdata);
                        $result   = json_decode($response,true);

                        # Récupération du code renvoyé par l'API
                        $code = $result['code'] ?? 0; // 0 si vide ou absent

                        switch ($code) {
                                # Facture récupérée avec succès
                                case 200:
                                        return [
                                                'code'    => 'E200',
                                                'message' => $result['message'] ?? "Facture récupérée avec succès.",
                                                'data'    => $this->data('prepare_invoice_data', $result['data'])
                                        ];

                                # Facture déjà traitée et en attente de validation
                                case 201:
                                        return [
                                                'code'    => 'E300',
                                                'message' => $result['message'] ?? "Cette facture est déjà traitée et en attente de validation par le validateur."
                                        ];

                                # Erreur serveur SEGUCE
                                case 500:
                                        return [
                                                'code'    => 'E500',
                                                'message' => 'Le système SEGUCE ne répond pas actuellement. Veuillez réessayer plus tard.'
                                        ];

                                # Facture non trouvée (HTTP 404)
                                case 404:
                                        return [
                                                'code'    => 'E404',
                                                'message' => $result['message'] ?? 'La référence transmise est incorrecte ou inexistante. Vérifiez la référence ou si elle appartient à une autre banque.'
                                        ];

                                #  Cas où aucune facture n’a été trouvée ou référence invalide
                                case 0:
                                default:
                                        return [
                                                'code'    => 'E000',
                                                'message' => 'Aucune facture trouvée pour la référence transmise.'
                                        ];
                        }
                }
                elseif ($obj == "prepare_invoice_data")
                {
                        if(!empty($data))
                        {
                                $invoice_data = new \stdClass();

                                $invoice_data->Date_1          = date('Y-m-d H:i:s');
                                $invoice_data->Status_2        = 1;
                                $invoice_data->Account_3       = $_SESSION['userdata']['account_id'] ?? "";
                                $invoice_data->Bank_4          = $data['BankActorCode'] ?? '';
                                $invoice_data->Factureid_5     = $data['ID'] ?? '';
                                $invoice_data->Result_6        = json_encode($data);
                                $invoice_data->Reference_7     = $data['InternalReference'] ?? '';
                                $invoice_data->Description_8   = 'Guichet Unique Intégral - GUICE';
                                $invoice_data->Refbfu_9        = '';
                                $invoice_data->Nif_10          = '';
                                $invoice_data->Montant_11      = $data['NetAmount'] ?? '';
                                $invoice_data->Devise_12       = $data['Currency'] ?? '';
                                $invoice_data->Datevaleur_13   = date("Y-m-d");
                                $invoice_data->Agence_14       ='' ;
                                $invoice_data->Debiteur_25     = $data['DebtorActorName'] ?? '';
                                $invoice_data->Creditaire_26   = $data['CreditorActorName'] ?? '';
                                $invoice_data->Clientcode_45   = $data['ClientCode'] ?? '';
                                $invoice_data->Contracttype_46 = $data['ContractType'] ?? '';
                        }

                        return !empty($invoice_data) ? $invoice_data : [];
                }
                elseif ($obj === "prepare_instructions_data") 
                {
                        # Validation des factures 
                        $result = $this->data('calculate_invoice_totals', $data);

                        # Construction des données
                        $instruction_data = [
                                'Designation_14' => $this->data('sanitize_string', $data['designation'] ?? ""),
                                'Beneficaire_15' => 'SEGUCE',
                                'Agence_20'      => $_SESSION['Logiref_agence'] ?? "",
                                'Guichet_21'     => $_SESSION['Logiref_guichet'] ?? "",
                                'Mode_19'        => $this->data('sanitize_string', $data['Mode'] ?? ""),
                                'Typerecette_17' => $this->data('sanitize_string', $data['reference'] ?? ""),
                                'Devise_34'      => $this->data('sanitize_string', $data['Devise_account'] ?? ""),
                                'Montant_11'     => $this->data('sanitize_amount', $result['total_invoices']),
                                'Devise_12'      => 'CDF',
                                'Compte_33'      => $this->data('sanitize_string', $data['Compte_33'] ?? ""),
                                'Devise_24'      => 'CDF',
                                'Noteid_26'      => $this->data('sanitize_string', $data['Ref'] ?? ""),
                                'Notemontant_28' => $this->data('sanitize_amount', $result['total_invoices']),
                                'Taux_41'        => $this->data('sanitize_amount', $data['taux'] ?? "1"),
                                'Nif_13'         => $this->data('sanitize_string', $data['Nif'] ?? ""),
                                'total_to_paid'  => $this->data('sanitize_amount', $result['total_invoices']),
                                'total_invoice'  => $this->data('sanitize_amount', $result['total_invoices']),
                                'total_acb'      => $this->data('sanitize_amount', $result['total_acb']),
                                'total_frais'    => $this->data('sanitize_amount', $result['total_frais']),
                                'Commission_23'  => $this->data('sanitize_amount', $result['total_frais']),
                                'total_tva'      => $this->data('sanitize_amount', $result['total_tva']),
                                'licence_fees'   => $this->data('sanitize_amount', $result['total_licence_fees']),
                                'bank'           => $this->bank
                        ];

                        return $instruction_data;
                }
                elseif ($obj === "calculate_invoice_totals") 
                {
                        $array = [
                                'total_invoices'       => 0,
                                'total_topaid'         => 0,
                                'total_acb'            => 0,
                                'total_frais'          => 0,
                                'total_tva'            => 0,
                                'total_licence_fees'   => 0,
                                'total_folder_bank'    => 0,
                                'total_folder'         => 0,
                        ];

                        $ref_invoice = $_POST['Ref'] ?? "";
                        $invoice     = $this->guiceModel->get_invoice_by_id($ref_invoice);

                        $taux            = $data['taux'] ?? 1;
                        $total_invoices  = 0;

                        # On ne traite que les factures GUICE
                        $agence  = $_SESSION['Logiref_guichet'] ?? "";
                        $recette = "FUGLI";
                        $regie   = "SEGUCE";
                        $devise  = "USD";

                        $rules = $this->feesModel->get_bank_charges($regie, null, $recette, $devise, null, $agence);

                        $commission = 0;
                        if (!empty($rules['Valeur']) && !empty($rules['Unite'])) 
                        {
                                $commission = (float) $rules['Valeur'];
                        }

                        # Montant total en fonction du taux
                        if (($invoice->Devise_12 ?? "") == "USD")
                                $total_invoices += ($invoice->Montant_11 ?? 0) * $taux;
                        else
                                $total_invoices += ($invoice->Montant_11 ?? 0);

                        # Calcul TVA et frais selon la banque
                        $tva       = ($commission * 16) / 100;
                        $frais_cfb = ($this->bank === 'Rawbank') ? ($commission - $tva) : $commission;

                        $array['total_invoices'] = $total_invoices;
                        $array['total_frais']    = $taux * $frais_cfb;
                        $array['total_tva']      = $taux * $tva;

                        # Montant total à payer en CDF
                        $array['total_topaid']   = $array['total_invoices'] + $array['total_acb'] + $array['total_frais'] + $array['total_tva'];
                        $array['total_folder']   = $array['total_invoices'] + $array['total_folder_bank'];

                        return $array;
                }
                elseif ($obj == "sanitize_amount")
                {
                        # Supprime espaces, remplace virgule par point
                        $clean = str_replace([' ', ','], ['', '.'], $data ?? "");

                        #Force en float puis format standard (2 décimales)
                        return is_numeric($clean) ? number_format((float)$clean, 2, '.', '') : "0.00";
                }
                elseif ($obj == "sanitize_string")
                {
                        return trim(preg_replace('/\s+/', ' ', $data ?? ""));
                }
                elseif ($obj == "update_and_respond")
                {
                        $code       = $data;
                        $invoice_id = $arg;
                        $reference  = $param;
                        //$status     = ($code == "E500" || $code == "E200") ? '2': '5'; 
                        $status     = ($code == "E500" || $code == "E200") ? '2': '1'; 
                        
                        $result = [
                                'code'      => $code, 
                                'id'        => $invoice_id, 
                                'reference' => $reference
                        ];
                        
                        $this->guiceModel->update_invoice(['Status_2' => $status], $invoice_id);

                        echo json_encode($result);
                }
                elseif ($obj == "map_transaction_lines")
                {
                        $lines = [];

                        $transaction = $data;
                        foreach ($transaction as $i => $row) 
                        {
                                $lines[$i+1] = [
                                        'status'    => $row->Status_2,
                                        'id'        => $row->Id_0,
                                        'reference' => $row->Reference_14,
                                ];
                        }

                        return $lines;
                }
                elseif ($obj == "call_corebanking_reservation")
                {
                        $invoice_id = $data;
                        $logirefid  = $arg;

                        $api_data = [
                                'Seguce_53'      => $invoice_id,
                                'Id_0'           => $invoice_id,
                                'Beneficaire_15' => 'SEGUCE',
                                'Designation_14' => $_POST['designation'] ?? '',
                                'Account_3'      => $this->session->userdata['account_id'] ?? '',
                                'Logirefid_4'    => $logirefid,
                                'Priority'       => 0,
                        ];

                        $core_banking = strtolower($this->core_banking);

                        if (method_exists($this->{$core_banking}, 'reservation_seguce_invoice')) 
                        {
                                $response = $this->{$core_banking}->reservation_seguce_invoice($api_data);
                                return json_decode($response, true);
                        }

                        # méthode inexistante
                        return ['response' => '407']; 
                }
                elseif ($obj == "handle_corebanking_response")
                {
                        $return = $data;
                        $result = [
                                'id'        => $arg['invoice_id'],
                                'reference' => $arg['logirefid'],
                                'transaction_id' => $return['transaction_id'] ?? "",
                        ];

                       $infos = [];
                       $infos['total_acb']       = $this->data('sanitize_amount', $_POST['Infos']['total_acb'] ?? 0);
                       $infos['total_frais']     = $this->data('sanitize_amount', $_POST['Infos']['total_frais'] ?? 0);
                       $infos['total_tva']       = $this->data('sanitize_amount', $_POST['Infos']['total_tva'] ?? 0);
                       $infos['total_to_paid']   = $this->data('sanitize_amount', $_POST['Infos']['total_to_paid'] ?? 0);
                       $infos['balance']         = $_POST['Infos']['balance'] ?? 0;
                       $infos['customer_number'] = $_POST['Infos']['customer_number'] ?? 0;

                        $data_to_update = [
                                'Nif_10'           => $param['Nif'] ?? "",
                                'Account_15'       => $param['Compte_33'] ?? "",
                                'Devise_16'        => $param['Devise_account'] ?? "",
                                'Commission_17'    => $param['total_frais'] ?? 0,
                                'Devise_18'        => 'CDF',
                                'Account_19'       => $param['compte_suspens'] ?? "",
                                'Devise_20'        => $param['Devise_12'] ?? "",
                                'Rate_28'          => $param['taux'] ?? 1,
                                'Refop_29'         => $param['reference'] ?? "",
                                'Accountholder_30' => $_POST['account_name'] ?? "",
                                'Logirefid_31'     => $arg['logirefid'],
                                'Contrevaleur_33'  => $param['Notemontant_28'] ?? 0,
                                'Mode_38'          => $_POST['Mode'] ?? "",
                                //'Topaid_43'        => $this->data('sanitize_amount', $_POST['total_to_paid'] ?? 0),
                                'Invoiceinfos_52'  => json_encode($infos ?? []),
                                'Treated_53'       => 1,
                        ];

                        switch ($return['response']) 
                        {
                                case '200':
                                        $result['code'] = 'E200';
                                        $data_to_update['Status_2'] = '2';
                                        $data_to_update['Validation_49'] = date('Y-m-d H:i:s');
                                        break;
                                case '301': case '302': case '303':
                                case '304': case '305': case '306':
                                case '300':
                                        $result['code'] = 'E' . $return['response'];
                                        $data_to_update['Status_2'] = '1';
                                        break;
                                default:
                                        $result['code'] = 'E411';
                                        $data_to_update['Status_2'] = '1';
                                        break;
                        }

                        $this->guiceModel->update_invoice($data_to_update, $arg['invoice_id']);
                        echo json_encode($result);
                }
                elseif ($obj == "all_lines_status")
                {
                        $lines  = $data;
                        $status = $arg;

                        return isset($lines[1], $lines[2], $lines[3]) &&
                                $lines[1]['status'] === $status &&
                                $lines[2]['status'] === $status &&
                                $lines[3]['status'] === $status;
                }
                elseif ($obj == "any_line_status")
                {
                        $lines    = $data;
                        $statuses = $arg;

                        foreach ($lines as $index => $line) 
                        {
                                if (in_array($line['status'], $statuses)) 
                                {
                                        # retourne l’index de la ligne fautive
                                        return $index; 
                                }
                        }
                        
                        return false;
                }
                elseif ($obj == "process_reservation_error")
                {
                        $lines      = $data;
                        $invoice_id = $arg;
                        
                        $line_index = $this->data('any_line_status',$lines, ["4","5"]);

                        if ($line_index !== false) 
                        {
                                $result = [
                                        'code'          => 'E50'.$line_index,
                                        'id'            => $invoice_id,
                                        'transaction_id'=> $lines[$line_index]['id'],
                                        'reference'     => $lines[$line_index]['reference'],
                                ];

                                $this->guiceModel->update_invoice(['Status_2' => '5'], $invoice_id);
                                
                                echo json_encode($result);
                        }
                }
                elseif ($obj == "handle_validation_response")
                {
                        $return  = $data;
                        $invoice = $arg;

                        $id = $invoice->Id_0;
                        $code = $return['response'] ?? null;

                        switch ($code) 
                        {
                                case 200:
                                        # Mise à jour statut en cours
                                        $data_to_update = [];
                                        $data_to_update['Status_2']   = '6';
                                        $data_to_update['Treated_53'] = '2';

                                        $pid = $this->guiceModel->update_invoice($data_to_update, $invoice->Id_0);

                                        # Préparer les données pour l’API externe
                                        $data_to_send = [
                                                "ID"                   => $invoice->Factureid_5,
                                                "BankActorCode"        => $invoice->Bank_4,
                                                "Date"                 => $invoice->Date_1,
                                                "InternalReference"    => $invoice->Reference_7,
                                                "DebtorActorName"      => $invoice->Debiteur_25,
                                                "CreditorActorName"    => $invoice->Creditaire_26,
                                                "NetAmount"            => $invoice->Montant_11,
                                                "Currency"             => $invoice->Devise_12,
                                                "AccountNumber"        => $invoice->Account_15,
                                                "AccountOwner"         => $invoice->Debiteur_25,
                                                "PaymentMethod"        => '7',
                                                "TransactionReference" => $invoice->Reference_7,
                                                "TransactionDate"      => $invoice->Date_1,
                                                "ContractType"         => $invoice->Contracttype_46,
                                                "Status"               => "Issued",
                                        ];

                                        $response = $this->curl(base_url('services/seguce/settleInvoice'), 'POST', json_encode($data_to_send));
                                        $settle   = json_decode($response, true);

                                        if (($settle['code'] ?? "") == '200') 
                                        {
                                                $data_to_update = [];
                                                $data_to_update['Status_2']   = '3';
                                                $data_to_update['Treated_53'] = '3';

                                                $this->guiceModel->update_invoice($data_to_update, $id);
                                                return 200;
                                        }

                                        return 302;

                                case 300: case 404: 
                                case 411: case 405:
                                        
                                        $this->guiceModel->update_invoice(['Status_2' => '5'], $id);
                                        return (int) $code;

                                default:
                                        $this->guiceModel->update_invoice(['Status_2' => '5'], $id);
                                        return 202; // erreur générique
                        }
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
