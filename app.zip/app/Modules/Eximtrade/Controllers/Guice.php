<?php

namespace Modules\Eximtrade\Controllers;

use DateTime;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Eximtrade\Models\CurlModel;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\FeesModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Eximtrade\Models\GuiceModel;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Modules\Admin\Models\StakeholderModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Services\Bsqr\Controllers\Bsqr;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Seguce\Controllers\SeguceSFTP;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\Comptabilisation\Controllers\ComptabilisationSeguce;
use Modules\Services\Comptabilisation\Models\ComptabilisationSeguceModel;
use Modules\Services\Finacle\Standardbank\Controllers\FinacleStandardBank;
use Modules\Services\Temenos\Controllers\Temenos;

class Guice extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Alain on the 16.03.2026
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('invoice', 'report_invoices', 'validated_invoices', 'nvalidated','nvalidated_invoices', 'validated', 'exemptcustomers', 'feesinvoice','provision','invoice_occ_batch','regularize_invoices_occ','provision_batch');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'guice';
        public $role;
        public $seguceModel;
        public $feesModel;
        public $dataModel;
        public $comptabilisationModel;
        public $comptabilisationSeguceModel;
        public $encaissementModel;
        public $curlModel;
        public $usersModel;
        public $mainModel;
        public $logirefModel;
        public $stakeholderModel;
        public $accountsModel;
        public $branchesModel;
        public $licenceModel;
        public $integrationModel;
        public $flexcube;
        public $amplitude;
        public $functionalities;
        public $bank;
        public $core_banking;
        public $temenos;
        public $ratesModel;
        public $seguceSFTP;
        public $fibridge;
        public $seguceAPI;
        public $spreadsheet=null;
        public $comptabilisation;
        public $options;
        public $finacle_standardbank;
        public $bsqr;
        public $guiceModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->seguceModel = new SeguceModel();
                $this->guiceModel  = new GuiceModel();
                $this->feesModel = new FeesModel();
                $this->dataModel = new DataModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->comptabilisationSeguceModel = new ComptabilisationSeguceModel();
                $this->curlModel = new CurlModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->accountsModel = new AccountsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->branchesModel = new BranchesModel();
                $this->licenceModel = new LicenceModel();
                $this->ratesModel = new RatesModel();
                $this->integrationModel = new IntegrationModel();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();
                $this->amplitude = new Amplitude();
                $this->seguceSFTP = new SeguceSFTP();
                $this->fibridge = new FIBridge();
                $this->spreadsheet=new Spreadsheet();
                $this->comptabilisation = new ComptabilisationSeguce();
                $this->finacle_standardbank = new FinacleStandardBank();
                $this->bsqr = new Bsqr();
                $this->seguceAPI = new Seguce();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'guice';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                $this->data['modes'] = $this->seguceModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);
                
                $this->bank = ucfirst(strtolower($this->session->userdata["account_restrict"]));

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                } else {
                        return redirect()->to(base_url($this->module));
                }

                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "start")
                {
                        $this->data['invoices'] = $this->guiceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\guice\_start', $this->data);
                }
                elseif ($obj === "verification") 
                {
                        $post_data = $this->data("prepare_invoice_verify_data");
                        $response  = $this->curl(base_url('services/InvoiceCheck/invoice'), 'POST', $post_data);
                        $result    = json_decode($response, true);

                        if (($result['code'] ?? "") !== 'E200') 
                        {
                                echo $response; die;
                        }

                        $this->data['object_info']  = $result['data'] ?? null;
                        $this->data['invoice_bank'] = false;

                        # On génère le HTML et on l’ajoute au JSON
                        $result['html'] = view('\Modules\Eximtrade\Views\guice\_step_1', $this->data);

                        echo json_encode($result);
                }
                elseif ($obj === "treat_invoice") 
                {
                        $post_data = $this->data("prepare_invoice_data");
                        $response  = $this->curl(base_url('services/InvoiceTreatment/invoice'), 'POST', $post_data);
                        $result    = json_decode($response, true);

                        if (($result['code'] ?? "") !== 'E200') 
                        {
                                echo $response; die;
                        }

                        $this->data['lines'] = $result["instructions"];
                        
                        # On génère le HTML et on l’ajoute au JSON
                        $result['html'] = view('\Modules\Eximtrade\Views\guice\_comptabilisation', $this->data);

                        echo json_encode($result);
                }
                elseif ($obj == "verify_transaction") 
                {
                        $data['Beneficaire_15'] = 'SEGUCE';
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Account_3']      = $this->session->userdata['account_id'];
                        $data['Logirefid_4']    = $_POST['logirefid'] ?? "";
                        $data['Seguce_53']      = $_POST['invoice_id'] ?? "";
                        $data['Id_0']           = $_POST['invoice_id'] ?? "";
                        $data['Type']           = "GUICE";
                        $data['Error_code']     = $_POST['error_code'] ?? "";
                        $data['transaction_id'] = $_POST['transaction_id'] ?? "";
                        $data['Priority']       = 0;

                        # Nom du core banking
                        $core_banking = strtolower($this->core_banking);

                        # Vérifier si la méthode existe dans la classe
                        if (method_exists($this->{$core_banking}, 'invoice_guice_verification_treatment'))
                        {
                                $return = $this->{$core_banking}->invoice_guice_verification_treatment($data);
                                $result = json_decode($return, true);
                                
                                if (($result['code'] ?? "") == "E200")
                                {  
                                        $result['id'] = $_POST['invoice_id'] ?? "";
                                        
                                        $data_to_update = [];    
                                        $data_to_update['Status_2'] = 2;
                                        $data_to_update['Validation_49'] = date('Y-m-d H:i:s');
                                        $this->guiceModel->update_invoice($data_to_update, $data['Id_0'] );
                                }

                                //echo $return;
                                echo json_encode($result);
                                die;
                        }
                        else
                        {
                                $result['code'] = 'E407';
                                echo json_encode($result);
                                die;
                        }
                }
                elseif ($obj == "edit")
                {
                        $invoice      = $this->guiceModel->get_paiement_invoice($id);
                        $integrations = $this->guiceModel->get_instructions_invoice($id);
                
                        $integration_status = [];
                        foreach($integrations as $row)
                        {
                                $integration_status[$row->Id_0] = $row->Status_2;
                        }

                        $this->data['integration_status']  = $integration_status ?? null;
                        $this->data['invoice']  = $invoice ?? null;
                        $this->data['invoice_bank'] = false;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_1_process', $this->data);
                }
                elseif($obj=="preview")
                {
                        $instructions = $this->comptabilisationModel->get_instructions_seguice($id);
                        $invoice      = $this->guiceModel->get_paiement_invoice($id);
                        
                        foreach ($instructions as $row) 
                        {
                                $integrations[$row->Id_0] = $row;
                        }

                        $this->data['invoice']      = $invoice;
                        $this->data['references']   = $integrations;
                        $this->data['integrations'] = $instructions;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_step_2', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj === "reservation") 
                {
                        $post_data = $this->data("prepare_invoice_data");
                        $response  = $this->curl(base_url('services/InvoiceReservation/invoice'), 'POST', $post_data);
                        $result    = json_decode($response, true);

                        echo $response;
                }
                elseif ($obj === "validate") 
                {
                        # Appel vers le service Seguce
                        $post_data = $this->data("prepare_invoice_data");
                        $response  = $this->curl(base_url('services/InvoiceValidation/invoice'), 'POST', $post_data);

                        echo $response;
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "prepare_invoice_verify_data")
                {
                        $post_data = [];

                        $post_data['ID']        = trim($_POST['numero_facture']  ?? "");
                        $post_data['Account']   = $_SESSION['userdata']['account_id'] ?? "";
                        $post_data['Branchid']  = $_SESSION['Logiref_guichet'] ?? "";
                        $post_data['Agence']    = $_SESSION['Logiref_agence'] ?? "";
                        $post_data['Makerid']   = $_SESSION['userdata']['user_id'] ?? '';

                        return $post_data;
                }
                elseif ($obj == "prepare_invoice_data")
                {
                        $post_data = $_POST ?? [];

                        # Injecter les infos de session dans $_POST
                        $post_data['Logiref_guichet'] = $_SESSION['Logiref_guichet'] ?? "";
                        $post_data['Logiref_agence']  = $_SESSION['Logiref_agence'] ?? "";
                        $post_data['Logiref_role']    = $_SESSION['Logiref_role'] ?? "";
                        $post_data['Account']         = $_SESSION['userdata']['account_id'] ?? "";
                        $post_data['Userid']          = $_SESSION['userdata']['user_id'] ?? "";

                        # Déterminer le core banking
                        $core_banking = strtolower($_SESSION['userdata']['account_cbs'] ?? '');
                        $post_data['core_banking'] = $core_banking;

                        # Passer aussi les options (car via curl la session n’est plus active)
                        $post_data['options'] = $this->options['ALL'];

                        # Passer aussi le nom de la banque
                        $post_data['bank'] = ucfirst(strtolower($_SESSION['userdata']['account_restrict'] ?? ''));

                        return $post_data;
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
