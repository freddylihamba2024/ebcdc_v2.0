<?php 

namespace Modules\Eximtrade\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Eximtrade\Models\ReportsModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Eximtrade\Models\SeguceModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Main\Models\MainModel;
use PhpOffice\PhpSpreadsheet\IOFactory;

class Impression extends BaseController {
        /*
         * Presentation: gestion des impression(production des documents PDF)
         * Last update:
         * By Glodi on the 20.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'Eximtrade';
        public $folder = 'impression';
        public $bank;
        public $licenceModel;
        public $encaissementModel;
        public $logirefModel;
        public $stakeholdersModel;
        public $integrationModel;
        public $branchesModel;
        public $usersModel;
        public $mainModel;
        public $seguceModel;
        public $comptabilisationModel;
        public $accountModel;
        public $branchModel;
        public $reportsModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->licenceModel = new LicenceModel();
                $this->logirefModel = new LogirefModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->integrationModel = new IntegrationModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new mainModel();
                $this->seguceModel = new SeguceModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->accountModel = new AccountsModel();
                $this->branchModel = new BranchModel();
                $this->reportsModel = new ReportsModel();

                
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['accountid'] = $account = $this->session->userdata["account_id"];
                $this->data['account_business'] = $this->session->userdata['account_business'];
                $this->data['account_logo'] = $this->session->userdata['account_logo'];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->session->userdata["account_cbs"];
                $this->data['deny'] = false;
                
                /*
                 * Control user access to this module
                 * If role is not set to access this module, then access denied
                */
                if($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
	} 
	
        
	public function index()
	{
               
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "export_gu") 
                {  
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'",$agence);
                        $encaissements  = $this->integrationModel->get_sucess_instructions_dgda($day);
                        $events = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $users = $this->mainModel->get_dropdown('users_array');
                        $cgu = isset($comptes['DGDA']['CGU']['CDF'])? $comptes['DGDA']['CGU']['CDF']: "";
                          
                        $regie = 'DGDA';
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_gu');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date comptant","Date validation","Operateur","Validateur","Numéro événement","Code opération", "Libellé","Débit","Crédit");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        foreach($encaissements as $row)
                        {
                                # Montant paye
                                
                                if($row->Compte_13 == $cgu || $row->Compte_9 == $cgu)
                                {
                                        if($row->Compte_13 == $cgu)
                                        {
                                                $credit= $row->Montant_10;
                                                $debit= "";
                                        }
                                        else
                                        {
                                                $debit= $row->Montant_10;
                                                $credit="";
                                        }
                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                
                                        if(isset($events[$row->Paiementid_4][$row->Id_0]['Num_evenement'])? $references[$row->Id_0] = $events[$row->Paiementid_4][$row->Id_0]['Num_evenement'] : $references[$row->Id_0] = '');
                                        if(isset($users[$row->Makerid_16])? $users[$row->Makerid_16] : $users[$row->Makerid_16]="" );
                                        if(isset($users[$row->Checkerid_17])? $users[$row->Checkerid_17] : $users[$row->Checkerid_17]="" );

                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Validation_18);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $users[$row->Makerid_16]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $users[$row->Checkerid_17]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $references[$row->Id_0]);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, "147");
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Libelle_12);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $debit);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $credit);

                                        if($i != $array_length)
                                        {   
                                            $erow++;
                                        }
                                        $i++;

                                }
                                
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_report_gu_'.time().'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/reportings';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                                //save the file on the server's HD
                                $objWriter->save($path);
                        }
                        
                        //download the file in the browser
                        $objWriter->save('php://output');

                }
                elseif($obj == "export_commission")
                {
                        $paiements = $this->encaissementModel->get_paiements();
                        $equivalence = 0;
                        $calcul = 0;
                        $tva = 0.16;
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $this->load->library('Excel');
                        $objPHPExcel = new Excel();
                        //activate worksheet number 1
                        $objPHPExcel->setActiveSheetIndex(0);
                        //name the worksheet
                        $objPHPExcel->getActiveSheet()->setTitle('report_commissions');
                        //set cell A1 content with some tex
                        
                        $style4Array = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));         
                        $table_columns = array("Date","Client","Commission","TVA","Agence");
                        $column = 0;
                        
                        foreach($table_columns as $field)
                        {
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                $column++;
                        }
                        $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($style4Array);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiements);
                        foreach($paiements as $row)
                        {
                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $calcul = $row->Commission_23*$tva;

                                if($row->Devise_24 == "USD")
                                {
                                        $equivalence = $row->Commission_23*$usd;
                                }
                                else
                                {
                                        $equivalence = $row->Commission_23;
                                }
                                #var_dump($equivalence);die;

                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $date_paiement);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, $row->Designation_14);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $equivalence);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $calcul);
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        for ($i = 'A'; $i <=  $objPHPExcel->getActiveSheet()->getHighestColumn(); $i++) {
                            $objPHPExcel->getActiveSheet()->getColumnDimension($i)->setAutoSize(TRUE);
                        }

                        $styleArray = array(
                              'borders' => array(
                                    'allborders' => array(
                                        'style' => PHPExcel_Style_Border::BORDER_THIN
                                    )
                              )
                        );
                        $objPHPExcel->getActiveSheet()->getStyle('A1:'.$atoz.$erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_commissions_'.time().'.xlsx';
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-commission';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                }
                elseif($obj == "report_dgidgrad")
                {
                        $beneficiaires= $this->reportsModel->regies;
                        $encaissements = $this->reportsModel->get_report_paiements_dgi();
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        $recettes = $this->logirefModel->get_dropdown("recettes");

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_dgi_dgrad');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Date","Regie","Service","Client","Montant", "Commissions", "Agences");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($encaissements);

                        foreach($encaissements as $row)
                        {
                                #$date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, $row->Contrevaleur_22);
                                $worksheet->setCellValue('F'.$erow, $row->Commission_23);
                                
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'_DGIDGRAD_'.time().'.xlsx';
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                      
                }
                elseif($obj == "report_dgrad")
                {
                        $beneficiaires= $this->reportsModel->regies;
                        $encaissements = $this->reportsModel->get_report_paiements_dgi();
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        $recettes = $this->logirefModel->get_dropdown("recettes");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 

                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        
                        //name the worksheet
                        $worksheet->setTitle('report_dgrad');

                        //set cell A1 content with some text
                             
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Date","Regie","Service","Client","Montant", "Commissions", "Agences");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($encaissements);

                        foreach($encaissements as $row)
                        {
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, $row->Contrevaleur_22);
                                $worksheet->setCellValue('F'.$erow, $row->Commission_23);
                                
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'_DGRAD_'.time().'.xlsx';
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report_dgrad';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                      
                }
                elseif($obj == "export_paydgda")
                {

                        $services = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $bulletins = $this->integrationModel->get_reports_bls();

                        $guichets = $this->branchModel->get_dropdown("guichets");

                        $deadline = date('Y-m-d');
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report-paydgda');

                        //set cell A1 content with some text
                        $styleArray = [
                                'font' => [
                                    'bold' => true,
                                    'color' => ['rgb' => '000000'],
                                    'size' => 12,
                                    'name' => 'Book Antiqua',
                                ],
                        ];  

                        $table_columns = array("Date", "Service","Client","Montant", "Commissions", "Agence");
                        $column = 0;
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($bulletins);

                        foreach($bulletins as $row)
                        {

                                //$date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));

                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $services['DGDA'][$row->Office_6]);
                                $worksheet->setCellValue('C'.$erow, $row->Designation_23);
                                $worksheet->setCellValue('D'.$erow, $row->Amount_12);
                                $worksheet->setCellValue('E'.$erow, $row->Commission_26);
                                $worksheet->setCellValue('F'.$erow, $guichets[$row->Agence_32]);

                                    
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'reportdgda'.time().'.xlsx';

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-paydgda';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                        
                }
                elseif($obj == "export_gu_paiements_tresor")
                {
                        $services = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        $encaissements = $this->reportsModel->get_paiements_tresor_gu();

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[9]; 
                        //load our new PHPExcel library
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('report_paiement_tresor');

                        //set cell A1 content with some text
                             
                        $styleArray = [
                                'font' => [
                                    'bold' => true,
                                    'color' => ['rgb' => '000000'],
                                    'size' => 12,
                                    'name' => 'Book Antiqua',
                                ],
                        ]; 

   
                        $table_columns = array("Date", "Numero BL", "Régie","Service","Recette", "Importateur","Quittance","Bordereau", "Montant BL", "Montant Taxe");
                        
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {
                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);

                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);

                        foreach($encaissements as $row)
                        {
                                $Infos = json_decode($row->Notereference_30, true); 

                                $quittance = $Infos['quittanceid'];

                                if($row->Sydonia_44 != 0)
                                {

                                        $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);

                                        $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);

                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);

                                        $worksheet->setCellValue('D'.$erow, $services[$row->Service_16]);
                                        $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('F'.$erow, $row->Designation_14);
                                        $worksheet->setCellValue('G'.$erow, $quittance);
                                                                                 #var_dump($quittance);die;

                                        $worksheet->setCellValue('H'.$erow, $row->Reference_32);
                                        $worksheet->setCellValue('I'.$erow, number_format($sydonia->Amount_12,2,","," "));
                                        $worksheet->setCellValue('J'.$erow, number_format($row->Montant_11,2,","," "));
                                }
                                elseif ($row->Sydonia_49 !=0)
                                {
                                        $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                        $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                        $worksheet->setCellValue('D'.$erow, $services[$row->Service_16]);
                                        $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('F'.$erow, $row->Designation_14);
                                        $worksheet->setCellValue('G'.$erow, '');
                                        $worksheet->setCellValue('H'.$erow, $prepaiements ->Accountholder_29);
                                        $worksheet->setCellValue('I'.$erow, number_format($prepaiements ->Amount_18,2,","," "));
                                        $worksheet->setCellValue('J'.$erow, number_format($row->Montant_11,2,","," "));
                                }
                                if($i != $array_length)
                                {  
                                        $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'reportdgdatresor'.time().'.xlsx';
                        #var_dump($filename);die;

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-paiement_tresor';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
           
                }
                elseif($obj == "export_gu_paiements_propres")
                {
                        $services = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        $encaissements = $this->reportsModel->get_paiements_propres_gu();

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[9]; 
                        //load our new PHPExcel library
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('report_paiement_tresor');

                        //set cell A1 content with some text
                             
                        $styleArray = [
                                'font' => [
                                    'bold' => true,
                                    'color' => ['rgb' => '000000'],
                                    'size' => 12,
                                    'name' => 'Book Antiqua',
                                ],
                        ]; 

   
                        $table_columns = array("Date", "Numero BL", "Régie","Service","Recette", "Importateur","Quittance","Bordereau", "Montant BL", "Montant Taxe");
                        
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {
                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);

                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);

                        foreach($encaissements as $row)
                        {
                                $Infos = json_decode($row->Notereference_30, true); 
                                $quittance = $Infos['quittanceid'];

                                if($row->Sydonia_44 != 0)
                                {

                                        $sydonia = $this->integrationModel->get_paiement_sydonia_by_ref($row->Sydonia_44);
                                        $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                        $worksheet->setCellValue('D'.$erow, $services[$row->Service_16]);
                                        $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('F'.$erow, $row->Designation_14);
                                        $worksheet->setCellValue('G'.$erow, $quittance);
                                        $worksheet->setCellValue('H'.$erow, $row->Reference_32);
                                        $worksheet->setCellValue('I'.$erow, number_format($sydonia->Amount_12,2,","," "));
                                        $worksheet->setCellValue('J'.$erow, number_format($row->Montant_11,2,","," "));
                                }
                                elseif ($row->Sydonia_49 !=0)
                                {
                                        $prepaiements = $this->integrationModel->get_prepaiement_sydonia($row->Sydonia_49);
                                        $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                        $worksheet->setCellValue('B'.$erow, $row->Noteid_26);
                                        $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                        $worksheet->setCellValue('D'.$erow, $services[$row->Service_16]);
                                        $worksheet->setCellValue('E'.$erow, $row->Typerecette_17);
                                        $worksheet->setCellValue('F'.$erow, $row->Designation_14);
                                        $worksheet->setCellValue('G'.$erow, '');
                                        $worksheet->setCellValue('H'.$erow, $prepaiements ->Accountholder_29);
                                        $worksheet->setCellValue('I'.$erow, number_format($prepaiements ->Amount_18,2,","," "));
                                        $worksheet->setCellValue('J'.$erow, number_format($row->Montant_11,2,","," "));
                                }
                                if($i != $array_length)
                                {  
                                        $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'reportdgdahorstresor'.time().'.xlsx';
                        #var_dump($filename);die;

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-paiement_tresor';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                }
                elseif($obj == "penalitie_dgda")
                {
                        $penalite=0;
                        $beneficiaires = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $encaissements = $this->encaissementModel->get_paiements('penalities');
                        $guichets = $this->branchModel->get_dropdown("guichets");
                        
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);

                        //name the worksheet
                        $worksheet->setTitle('retard_reversement');

                        //set cell A1 content with some text
                             
                        $styleArray = [
                                'font' => [
                                    'bold' => true,
                                    'color' => ['rgb' => '000000'],
                                    'size' => 12,
                                    'name' => 'Book Antiqua',
                                ],
                        ]; 

                        
                        $table_columns = array("Date","Client","Beneficiaire","Service", "Recette", "Montant", "Retard", "Penalité", "Agences");
                        $column = 0;
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        
                        $array_length = count($encaissements);
                        
                        
                        foreach($encaissements as $row)
                        {

                               #Trouver le nombre de jour/mois/annee entre les dates
                                $date1 = $row->Datevaleur_31;
                                $date2 = gmdate('Y-m-d');
                                $diff = abs(strtotime($date2) - strtotime($date1));
                                $years = floor($diff / (365*60*60*24));
                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                
                                $penalite =$row->Montant_11*0.03*$days; 

                                //$dateTime = new DateTime($row->Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+60 day",$date));
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $row->Service_16);
                                if($row->Beneficaire_15 =="DGRAD")$worksheet->setCellValue('E'.$erow, $row->Typerecette_17." ".$row->Noteid_26);  
                                else $worksheet->setCellValue('E'.$erow, $row->Typerecette_17); 
                                $worksheet->setCellValue('F'.$erow, $row->Montant_11);
                                $worksheet->setCellValue('G'.$erow, $days." "."jours");
                                $worksheet->setCellValue('H'.$erow, $penalite);
                                $worksheet->setCellValue('I'.$erow, $guichets[$row->Guichet_21]);

                                    
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;

                        }
                         //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'noreverse'.time().'.xlsx';
                         #var_dump($filename);die;

                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/noreverse';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                        
                        
                }
                elseif($obj == "schema_prov")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');

                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $this->data['provision'] = $provision = $this->seguceModel->get_provision_info($id);

                        $guichet = $this->branchesModel->get_guichet_info($this->data['provision']->Guichet_28);

                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';

                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instruction_provision($provision->Id_0);
                        

                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->seguceModel->get_cbs_returns_provision($provision->Reference_20);
                        
                        if(isset($cbs_return->Result_5) && $cbs_return->Result_5 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_5, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        else
                        {
                                $this->data['cbs_return'] = array();
                        }
                        
                        $this->data['lines'] = $instrcutions;

                        $html = view('\Modules\Eximtrade\Views\\'.$this->folder.'\_schema_prov', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
                }
                elseif($obj == "schema_licence")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');

                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $this->data['licence'] = $licence = $this->seguceModel->get_licence_info($id);

                        $guichet = $this->branchesModel->get_guichet_info($this->data['licence']->Guichet_25);

                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';

                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instruction_licence($licence->Id_0);
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->seguceModel->get_cbs_returns_licence($licence->Reference_19);
                        
                        if(isset($cbs_return->Result_5) && $cbs_return->Result_5 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_5, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        else
                        {
                                $this->data['cbs_return'] = array();
                        }
                        
                        $this->data['lines'] = $instrcutions;

                        $html = view('\Modules\Eximtrade\Views\\'.$this->folder.'\_schema_licence', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
                }
                elseif($obj == "schema_invoices")
                {
                        $data_clt = array();
                        $batchid = $id;

                        if (isset($_GET['invoices']))
                        {
                                $invoices = $_GET['invoices'];
                                $invoices = json_decode(urldecode($invoices), true);

                                foreach ($invoices as $key => $row):
                                        $data_clt[$key] = $key;
                                endforeach;

                                $clt = sprintf("'%s'", implode("','", $data_clt));
                        }

                        if (isset($_GET['codeimport']))
                        {
                                $data_clt = $_GET['codeimport'];
                                $data_clt = json_decode(urldecode($data_clt), true);

                                $clt = sprintf("'%s'", implode("','", $data_clt));
                        }

                        $invoice_slip = $this->seguceModel->get_invoices_occ_batchs_info($batchid);
                        $guichet = $this->branchesModel->get_guichet_info($invoice_slip->Guichet_15);

                        $batch_ref = $this->seguceModel->get_dropdown("batch_reference");
                        $batch_ref = isset($batch_ref[$batchid]) ? $batch_ref[$batchid] : "";
                        # Treatment of information returned by the CBS
                        $this->data['cbs_return']  = $this->seguceModel->get_cbs_returns_invoices($batch_ref);

                        $this->data['clts'] = $data_clt;
                        $this->data['invoice_slip'] = $invoice_slip;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['lines'] = $this->comptabilisationModel->get_instruction_invoices($batchid, $clt);

                        $html = view('\Modules\Eximtrade\Views\\'.$this->folder.'\_schema_invoices', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
                }
                elseif($obj == "export_comptes")
                {
                        $comptes = $this->accountModel->get_export_comptes();
                        $types = $this->logirefModel->get_dropdown("types","Compte");
                        $users = $this->mainModel->get_dropdown('users_array');
                        $agences = $this->branchModel->get_dropdown("guichets");
                        $services =$this->logirefModel->get_dropdown("services");
                        $recettes = $this->logirefModel->get_dropdown("recettes");
                        $villes = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $guichets = $this->branchModel->get_dropdown("guichets");

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_comptes');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Agence","Type","Taxe","Comptes","Devise","Bénéficiaire");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($comptes);
                      
                        foreach($comptes as $row)
                        {
                                $compte = isset($guichets[$row->Agence_12])? $guichets[$row->Agence_12] : "";
                                
                                $worksheet->setCellValue('A'.$erow, $compte);
                                $worksheet->setCellValue('A'.$erow, $row->Type_4);
                                $worksheet->setCellValue('B'.$erow, $row->Recette_13);
                                $worksheet->setCellValue('C'.$erow, $row->Agenceid_15.'-'.$row->Compte_6.'-'.$row->Clef_7.' ');
                                $worksheet->setCellValue('D'.$erow, $row->Devise_8);
                                $worksheet->setCellValue('E'.$erow, $row->Beneficiaires_5);
                                 
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_comptes'.time().'.xlsx';
                         #var_dump($filename);die;

                                                
                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                }
                elseif($obj == "export_agences")
                {
                        $beneficiaires = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $guichets = $this->branchModel->get_dropdown("guichets");
			$users = $this->mainModel->get_dropdown('users_array');
                        
                        if (isset($_SESSION['payment_agence']) && $_SESSION['payment_agence'] != '')
                        {
                            $encaissements = $_SESSION['payment_agence'];
                        }
                        else
                        {
                            $encaissements = [];
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_payment_agence');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("Date","Désignation","Bénéficiaire","Recette","Montant", "Commissions", "Opérateur", "Agence");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($encaissements);
                      
                        foreach($encaissements as $row)
                        {
                                $worksheet->setCellValue('A'.$erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                $worksheet->setCellValue('A'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('B'.$erow, $row->Recette_13);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('D'.$erow, $row->Devise_12.' '.number_format($row->Montant_11,2,","," "));
                                $worksheet->setCellValue('E'.$erow, $row->Devise_24.' '.number_format($row->Commission_23,2,","," "));
                                $worksheet->setCellValue('F'.$erow, (isset($users[$row->Makerid_9]))? $users[$row->Makerid_9] :' - ');
                                $worksheet->setCellValue('G'.$erow, (isset($guichets[$row->Guichet_21]))? $guichets[$row->Guichet_21] :' - ');
                                 
                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }
                        

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_payment'.time().'.xlsx';
                         #var_dump($filename);die;


                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                               
                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;
                              
                        }
                        
                        
                        unset($_SESSION['payment_agence']);
                        
                }
                elseif($obj == "schema")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)?$agence->Nom_4:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        //get instuctions
                        if($encaissement->Beneficaire_15 == "DGI"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGRAD"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGDA"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgda($encaissement->Sydonia_44);
                        
                        endif;
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);
                        
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        $this->data['lines'] = $instrcutions;
                        # Supprimer le caractère '@' au début de la chaîne
                        
                        $bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        $imagePath = base_url('ikwook_files/images/solidairebanque/bordereau.jpg');
                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "schemabl")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_paiement_tresor_bl($id);
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_paiement_propres_bl($id);  
                        }
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');
                        
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema_dgda', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "export_invoice_occ"){
                        $recettes = $this->seguceModel->recettes;
                        $licenses = $this->seguceModel->get_dropdown("invoices_occ");
                        $invoices = $this->reportsModel->get_invoicess_occ($_POST);

                        if(!empty($_SESSION['invoices_occ'])){ 
                                $invoices = $_SESSION['invoices_occ'];
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7];
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_invoice_occ');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("#","Date","Réf. Bordereau","Licence","Bénéficiaire","Recette", "Désignation", "Montant");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName)
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($invoices);

                        foreach($invoices as $row)
                        {
                                $worksheet->setCellValue('A'.$erow,($i + 1));
                                $worksheet->setCellValue('B'.$erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                $worksheet->setCellValue('C'.$erow, $row->Notereference_30);
                                $worksheet->setCellValue('D'.$erow, isset($licenses[$row->Invoice_54]) ? $licenses[$row->Invoice_54] : "-");
                                $worksheet->setCellValue('E'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('F'.$erow, isset($recettes[$row->Typerecette_17]) ? $recettes[$row->Typerecette_17] : "-");
                                $worksheet->setCellValue('G'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('H'.$erow, $row->Devise_12.' '.number_format($row->Montant_11,2,","," "));

                                if($i != $array_length)
                                {
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_invoice_occ'.time().'.xlsx';


                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;

                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;

                        }

                }
                elseif($obj == "print_invoice_occ"){
                        $this->data['recettes'] = $this->seguceModel->recettes;
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['invoices'] = $this->reportsModel->get_invoicess_occ($_POST);

                        if(!empty($_SESSION['invoices_occ'])){
                                $this->data['invoices'] = $_SESSION['invoices_occ'];
                        }

                        $html = view('\Modules\Eximtrade\Views\impression\_print_invoice_occ', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;

                }
                elseif($obj == "export_invoice_license"){
                        $num_bordereau = $this->seguceModel->get_dropdown("bordereau_number");
                        $code_imports = $this->seguceModel->get_dropdown("code_imports");
                        $invoices = $this->seguceModel->get_invoices_occ($_POST);
                        $users = $this->mainModel->get_dropdown('users_array');

                        if(!empty($_SESSION['invoices_license'])){ 
                                $invoices = $_SESSION['invoices_license'];
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8];
                        //activate worksheet number 1
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_invoice_license');
                        //set cell A1 content with some text
                        $styleArray = [
                            'font' => [
                                'bold' => true,
                                'color' => ['rgb' => '000000'],
                                'size' => 12,
                                'name' => 'Book Antiqua',
                            ],
                        ];

                        $table_columns = array("","Date","Désignation","N°bordereau","Numéro licence","Montant (CIF)", "Code importation", "Sigle Banque", "Opérateur");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName)
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($invoices);

                        foreach($invoices as $row)
                        {
                                $worksheet->setCellValue('A'.$erow,($i + 1));
                                $worksheet->setCellValue('B'.$erow, strftime('%d-%m-%Y',strtotime($row->Date_1)));
                                $worksheet->setCellValue('C'.$erow, $row->Designation_13);
                                $worksheet->setCellValue('D'.$erow, $row->Numbordereau_14);
                                $worksheet->setCellValue('E'.$erow, $row->Licence_8);
                                $worksheet->setCellValue('F'.$erow,$row->Devise_10.' '.number_format($row->MontantCIF_9,2,","," "));
                                $worksheet->setCellValue('G'.$erow, $row->Codeimport_12);
                                $worksheet->setCellValue('H'.$erow,$row->Siglebank_22);
                                $worksheet->setCellValue('I'.$erow, (isset($users[$row->Creator_4]))? $users[$row->Creator_4] :' - ');

                                if($i != $array_length)
                                {
                                    $erow++;
                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();
                        for ($col = 'A'; $col <= $highestColumn; $col++)
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= $user_id.'report_invoice_license'.time().'.xlsx';


                        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="' . $filename . '"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;

                                $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                                $objWriter->save($path);

                                return $path;

                        }

                }
                elseif($obj == "print_invoice_license"){
                        $this->data['num_bordereau'] = $this->seguceModel->get_dropdown("bordereau_number");
                        $this->data['code_imports'] = $this->seguceModel->get_dropdown("code_imports");
                        $this->data['invoices'] = $this->seguceModel->get_invoices_occ();
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        if(!empty($_SESSION['invoices_license'])){
                                $this->data['invoices'] = $_SESSION['invoices_license'];
                        }

                        $html = view('\Modules\Eximtrade\Views\impression\_print_invoice_license', $this->data);

                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);

                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;

                }
                elseif($obj == "schema_prepayment")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');

                        $encaissement = $this->encaissementModel->get_prepaiement_tresor_bl($id);

                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_prepaiement_propres_bl($id);  
                        }

                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;

                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_prepayments_cbs_returns($id);
                        //var_dump($cbs_return); die;
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['lines'] = $instrcutions;
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');
                        
                        $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_schema_prepayment', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "attestation")
                {
                        //now pass the data//
                        
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $this->comptabilisationModel->months;
                        //var_dump($this->data['months']);die;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);

                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        //$agence = $this->branchModel->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                        
                        $agences = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($agences->Ville_7) &&  $agences->Ville_7 != NULL)? $agences->Ville_7:'...................';
                        $this->data['agences'] = (isset($agences->Nom_4) && $agences->Nom_4 != NULL)? $agences->Nom_4:'...................';
                        #var_dump($this->data['agences']);die;
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $service_type= $this->data['service_type'] =$this->logirefModel->get_dropdown("type_services");
                        $commune_services =$this->logirefModel->get_dropdown("commune_services");
                       
                        # Treatment of information returned by the CBS
                        //$comptes_dgi = $this->integrationModel->get_instructions_dgis();
                        //$comptes_dgrad = $this->comptabilisationModel->get_instructions_dgrad();
                      
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        //creation de qrcode
                        //$dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        //if(is_dir($dir)==false)
                        //{
                        //        mkdir($dir,0777,true);
                        //}
                        
                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        //$this->data['qrcode'] = $params['savename'] = $dir."/".$this->data['encaissement']->Logirefid_4.'.png';
                        //$this->ciqrcode->generate($params);
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        $bank_name = ltrim($this->bank, '@');
                        if($encaissement->Beneficaire_15 == "DGRAD")
                        {
                                                        //var_dump($bank_name);die;

                                #$html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgrad', $this->data);
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_appurement_eb', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'AMRA')
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgi_amra', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] =="DGE" || $service_type[$encaissement->Service_16] =="CDI" )&& $encaissement->Typerecette_17 =="IPRIER")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_cdi_iprier', $this->data);

                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] =="CIS")&& $encaissement->Typerecette_17 =="IPRIER")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgi_iprier', $this->data);

                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != 'IPRIER')
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgi', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGDA")
                        {
                                $html = view('\Modules\Branch\Views\impression\\' . $bank_name . '\_attestation_dgda', $this->data);
                        }

                        #$html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        //actually, you can pass mPDF parameter on this load() function
                        // Chemin vers votre image à utiliser comme arrière-plan
                        $imagePath = base_url('ikwook_files/images/solidairebanque/attestation.jpg');

                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119); 
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, 'F');
                                return $pdfFilePath;
                        }
                        
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "apurement")
                {

                        $this->data['categories']= $categories = $this->licenceModel->get_licence_info($id);
                       
                        # Supprimer le caractère '@' au début de la chaîne
                        if($categories->Category_20 == "EB01")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_eb01', $this->data);
                        }
                        elseif($categories->Category_20 == "EB08")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_eb08', $this->data);
                        }
                        elseif($categories->Category_20 == "RC")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_rc', $this->data);
                        }
                        elseif($categories->Category_20 == "IB20")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_ib20', $this->data);
                        }
                        elseif($categories->Category_20 == "IB21")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_ib21', $this->data);
                        }
                        elseif($categories->Category_20 == "IB22")
                        {
                                $html = view('\Modules\Eximtrade\Views\impression\_appurement_ib22', $this->data);
                        }


                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";


                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119); 
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, 'F');
                                return $pdfFilePath;
                        }
                        
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "avertissement")
                {
                        //now pass the data//
                        
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        
                        #var_dump($this->data['license']);die;
                        
                        # Supprimer le caractère '@' au début de la chaîne
                        #$bank_name = ltrim($this->bank, '@');
                        $html = view('\Modules\Eximtrade\Views\impression\_appurement_rappel_ib_pay_total_doc', $this->data);


                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                       

                        // Configuration de l'image en arrière-plan
                        //$this->mpdf->SetWatermarkImage($imagePath);
                        //$this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        //$this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)

                        //Set margins (left,rigth,top, bottom)
                        //$this->mpdf->setMargins(-12,-9, 10, 119); 
                        $this->mpdf->AddPageByArray([
                            'margin-left' => 10,
                            'margin-right' => 10,
                        ]);
                        
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, 'F');
                                return $pdfFilePath;
                        }
                        
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj=="attestationbl")
                {       
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['villes'] = $this->logirefModel->get_dropdown('parameter', 'VILLE');
                        $this->data['users'] = $this->logirefModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_paiement_tresor_bl($id);
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_paiement_propres_bl($id);  
                        }
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = ($guichet->Ville_7!="")? $guichet->Ville_7 :'.................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        
                        $link = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        
                        // Créer un QR Code
                        $qrCode = $this->qrCodeBuilder
                            ->data($link)
                            ->encoding($this->qrCodeEncoding)
                            ->size(256)
                            ->margin(10)
                            ->build();
                        $qrCodeImageString = '';

                        $image = $qrCode->getImage();
                        if ($image instanceof \GdImage) {
                            ob_start();
                            imagepng($image);
                            $qrCodeImageString = ob_get_clean();
                        }

                        // Encodage en base64 si la chaîne de caractères de l'image est disponible
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;

                        $html = view('\Modules\Branch\Views\impression\_quittance', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	

                        //actually, you can pass mPDF parameter on this load() function

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj=="print_users")
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();

                        if(isset($_POST['members']) && $_POST['members'] !="")
                        {
                                $this->data['members'] = json_decode($_POST['members']);
                        }
                        else
                        {
                                $this->data['members'] = array();
                        }

                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);

                        $this->data['roles'] = $this->usersModel->role;

                        $this->load->model('MY_Main');
                        $this->load->model('main/mainModel');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_users', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }

                elseif($obj=="print_client")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        
                        if(isset($_POST['encaissements']) && $_POST['encaissements'] !="")
                        {
                                $this->data['encaissements'] = json_decode($_POST['encaissements']);
                                
                        }
                        else 
                        {
                                $this->data['encaissements'] = array();
                        }
                        
                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->load->model('MY_Main');
                        $this->load->model('main/mainModel');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_client', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
                elseif($obj=="print_gu_paiements_tresor")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_gu_paiements_tresor', $this->data, true);
                        
                        
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                } 
                elseif($obj=="print_others_taxes")
                {       
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountModel->get_comptes_recettes_agence_array("'CPI','CPT'", $agence_src);
                        
                        $beneficiaries = $this->accountModel->get_dropdown("beneficiary_tax_others_banks");
                        
                        $instructions = $_SESSION['taxes_others_banks'];

                        $taxes = [];
                        
                        foreach($instructions as $row)
                        {
                                $taxes[$row->Codetaxe_28][] = $row;
                        }
                        
                        $this->data['taxes'] = $taxes;
                        $this->data['beneficiaries'] = $beneficiaries;
                        $this->data['comptes'] = $comptes;

                        
                        $html = view('\Modules\Branch\Views\impression\_print_others_taxes', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                      
                }
                elseif($obj=="print_gu_paiements_propres")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_gu_paiements_propres', $this->data, true);
                        
                        
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_paiements_gu")
                {
                        $this->data['office'] = $_POST['Office'];
                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                        {
                                
                                $bls = implode(',', $_POST['paiements']);
                                $this->data['bulletins'] = $this->integrationModel->get_bulletins_by_lot($bls);
                               
                                
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_paiements_gu', $this->data, true);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj=="print_bl")
                {
                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                        {
                                $this->data['bulletins'] = json_decode($_POST['bulletins']);
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        $this->data['agences'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        $html = $this->load->view($this->module.'/'.$this->group. '/taximpression/_print_bl', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        $pdf->WriteHTML($html);
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }

                elseif($obj=="print_commissions")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        if(isset($_POST['commissions']) && $_POST['commissions'] !="")
                        {
                                $p = $this->data['paiements'] = json_decode($_POST['commissions']);
                        }
                        else
                        {
                                $this->data['paiements'] = array();
                        }

                        $html = $this->load->view($this->module.'/banks/taximpression/_print_commissions', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);

                        $pdf->WriteHTML($html);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                    
                        echo $pdfFilePath;
                }
              
                elseif($obj == "print_regles")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        if(isset($_POST['regles']) && $_POST['regles'] !="")
                        {
                                $this->data['regles'] = json_decode($_POST['regles']);
                        }
                        else
                        {
                                $this->data['regles'] = array();
                        }
                        
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_regles', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                       
                      
                        if(isset($_POST['comptes']) && $_POST['comptes'] !="")
                        {
                            
                                $this->data['comptes'] = json_decode($_POST['comptes']);
                                
                        }
                        else
                        {
                                $this->data['comptes'] = array();
                        }
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_comptes', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_penalites")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                       
                        $this->data['encaissements'] = (isset($_POST['encaissements']) && $_POST['encaissements'] !="")? json_decode($_POST['encaissements']) : array();
                        $this->data['bulletins'] = (isset($_POST['bulletins']) && $_POST['bulletins'] !="")?json_decode($_POST['bulletins']) : array();
                        
                        $html = $this->load->view($this->module.'/banks/taximpression/_print_penalites', $this->data, true);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                elseif($obj == "print_recettes")
                {
                        $this->data['agence'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchModel->get_branches();
                        if(isset($_POST['data']) && $_POST['data'] !="")
                        {
                               $this->data['data'] = json_decode($_POST['data'], true);
                        }
                        else
                        {
                                $this->data['data'] = array();
                        }
                        
                        $html = view('\Modules\Branch\Views\reports\report_agence\_print_recettes', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";
                        //actually, you can pass mPDF parameter on this load() function
                        $pdf = $this->m_pdf->load();
                        $pdf->AddPage('L','','','','',7,7,8,8,10,10);
                        
                        $pdf->WriteHTML($html);
                        
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $pdf->Output($pdfFilePath, "F");
                        echo $pdfFilePath;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
               if($obj == "number_letter")
               {
                   $value = $this->number_letter->converter($data, $arg);
                   
                   return $value;
               }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */