<?php

namespace Modules\Eximtrade\Controllers;

use App\Libraries\Mail;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Libraries\ChunkReadFilter;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Quitus\Models\QuitusModel;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\FIBridge\Controllers\FIBridge;
use Modules\Services\Temenos\Controllers\Temenos;

class Elicense extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Donald on the 06.08.2024
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('elicense','prelevement','document','customer','batchs','batch_details');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'elicense';
        public $role;
        public $mail;
        public $seguceModel;
        public $mainModel;
        public $logirefModel;
        public $licenceModel;
        public $quitusModel;
        public $bank;
        public $functionalities;
        public $core_banking;
        public $temenos;
        public $flexcube;
        public $fibridge;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->seguceModel = new SeguceModel();
                $this->licenceModel = new LicenceModel();
                $this->mail = new Mail();
                $this->quitusModel = new QuitusModel();
                $this->fibridge = new FIBridge();
                $this->flexcube = new Flexcube();
                $this->temenos = new Temenos();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'elicense';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);

                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }

                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                }
                else {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "elicense")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","all");
                        $this->data['merchandises'] = $this->licenceModel->merchandises;
                        $this->data["elicense"] = $this->licenceModel->get_licence_info($id);

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif ($obj == "batchs")
                {
                        $this->data['step'] = 0;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_dec_batch', $this->data);
                }
                elseif ($obj == "batch_details")
                {
                        $this->data['step'] = 0;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_batch', $this->data);
                }
                elseif ($obj == "document")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");

                        if(!is_null($id))
                        {
                                $this->data["elicense"] = $elicense = $this->licenceModel->get_licence_by_id($id);
                                $this->data["NumLcc"] = $elicense->Licence_35;
                        }

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif ($obj == "customer")
                {
                        $this->data["legalstatus"] = $this->quitusModel->legalstatus;
                        $this->data["clientfiscal"] = $this->quitusModel->get_client_fiscal_info($id);

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif ($obj == "elicense_first")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        if(!is_null($id))
                        {
                                $this->data["elicense"] =  $this->licenceModel->get_licence_by_id($id);
                        }
                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif ($obj == "elicense_last")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");
                        if(!is_null($id)){
                                $this->data["elicense"] =  $this->licenceModel->get_licence_by_id($id);
                        }
                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif($obj == "prelevement")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","licence");
                        if ($id != "") {
                                $this->data['licence'] = $licence = $this->seguceModel->get_licence_info($id);

                                if (isset($licence->Compte_20) && $licence->Compte_20 != "") {

                                        $account_customer = trim($licence->Compte_20);
                                        $account_without_branch = preg_replace('/^\d{3}-/', '', $account_customer);
                                        $licence->Compte_20 = $account_without_branch;

                                }

                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        }
                        else {
                                $this->data['licence'] = $this->seguceModel->get_licence_info($id);
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                        }
                }
                elseif($obj == "notification")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data["status_licence"] = $this->licenceModel->status;
                        //$this->data["notifications"] = $this->licenceModel->get_elicense_notification($id,1);
                        $this->data["license"] = $license = $this->licenceModel->get_licence_info($id);

                        if (isset($license->Results_36) && $license->Results_36 !=""):
                                $paiements = json_decode($license->Results_36);
                        else:
                                $paiements = array();
                        endif;

                        $this->data["paiements"] = $paiements;

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif($obj == "additional_field_licence_first")
                {

                        $date1 = new \DateTime($_GET["Date_initial_14"]);
                        $date2 = new \DateTime($_GET["Date_initial_14"]);
                        $this->data['tarif'] = $this->licenceModel->get_tarif_by_object($_GET['Object_7']);
                        $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($_GET['Object_7']);
                        $this->data['typepay'] = $this->licenceModel->get_typepayment_by_type($categorie->Payment_type_13);
                        $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                        $this->data['Validity_10'] = $categorie->Validity_10;
                        $this->data['Document_delay_11'] = $categorie->Document_delay_11;
                        $this->data['Initial_expiration_25'] = $date1->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                        $this->data['Doc_expiration_28'] = $date2->modify("+$categorie->Document_delay_11 days")->format("Y-m-d");
                        $this->data['documents'] = $documents =  explode(",",$categorie->Document_list_12);
                        $this->data['description_document'] = array();
                        foreach($documents as $document){
                                $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                        }
                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);

                }
                elseif($obj == "additional_field_licence_last")
                {

                        $date1 = new \DateTime($_GET["Date_initial_14"]);
                        if($_GET["Date_paiement_30"] != "")
                        {
                             $date2 = new \DateTime($_GET["Date_paiement_30"]);
                        }
                        $this->data['tarif'] = $this->licenceModel->get_tarif_by_object($_GET['Object_7']);
                        $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($_GET['Object_7']);
                        $this->data['typepay'] = $this->licenceModel->get_typepayment_by_type($categorie->Payment_type_13);
                        $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                        $this->data['Validity_10'] = $categorie->Validity_10;
                        $this->data['Document_delay_11'] = $categorie->Document_delay_11;
                        $this->data['Initial_expiration_25'] = $date1->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                        $this->data['Doc_expiration_28'] = ($_GET["Date_paiement_30"] == "")?"":$date2->modify("+$categorie->Document_delay_11 days")->format("Y-m-d");
                        $this->data['documents'] = $documents =  explode(",",$categorie->Document_list_12);
                        $this->data['description_document'] = array();
                        foreach($documents as $document){
                                $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                        }
                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);

                }
                elseif($obj == "additional_field_licence")
                {
                        $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($_GET['Object_7']);
                        $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                        $this->data['Validity_10'] = $categorie->Validity_10;
                        if(!empty($_GET["Date_initial_14"])){
                                $date1 = new \DateTime($_GET["Date_initial_14"]);
                                $this->data['Initial_expiration_25'] = $Initial_expiration_25 = $date1->modify("+$categorie->Validity_10 days")->format("Y-m-d");

                                if(!empty($_GET["Date_validation_bcc"])){
                                        $expiration = new \DateTime($Initial_expiration_25);
                                        if(in_array($categorie->Object_7,array("IS","IB20","IB21","IB22","IB23","IB24","IB25","IB27","IB36"))){
                                                $this->data['Initial_expiration_25'] = $expiration->modify("+180 days")->format("Y-m-d");
                                        }
                                        elseif(in_array($categorie->Object_7,array("RC","ES","EB01","EB06","EB08"))){
                                                $this->data['Initial_expiration_25'] = $expiration->modify("+90 days")->format("Y-m-d");
                                        }
                                }
                        }
                        elseif(!empty($_GET["Date_extension_32"])){
                                $date1 = new \DateTime($_GET["Date_extension_32"]);
                                if(in_array($categorie->Object_7,array("IS","IB20","IB21","IB22","IB23","IB24","IB25","IB27","IB36"))){
                                        $date2 = new \DateTime($date1->modify("+180 days")->format("Y-m-d"));
                                }
                                elseif(in_array($categorie->Object_7,array("RC","ES","EB01","EB06","EB08"))){
                                        $date2 = new \DateTime($date1->modify("+90 days")->format("Y-m-d"));
                                }
                                $this->data['Initial_expiration_25'] = $date2->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                        }

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);

                }
                elseif($obj == "information_documents")
                {
                        $NumLcc = $_GET["Numero_licence"];
                        $declaration = $this->licenceModel->get_license_exists($NumLcc);

                        if (empty($declaration))
                        {
                                $provision = $this->seguceModel->get_provisions_validated_by_licence($NumLcc);
                                $declaration = new \stdClass();

                                if (!empty($provision) && !empty($provision[0]->CodeType_38))
                                {
                                        $categorie = $this->licenceModel->get_categorie_by_object($provision[0]->CodeType_38);
                                        $datime = new \DateTime($provision[0]->Validation_44);
                                        $declaration->Id_0 = "";
                                        $declaration->Date_1 = gmdate('Y-m-d H:i:s');
                                        $declaration->Status_2 = '';
                                        $declaration->Account_3 = '';
                                        $declaration->Creator_4 = '';
                                        $declaration->Changes_5 = '';
                                        $declaration->Changer_6 = '';
                                        $declaration->Compte_7 = $provision[0]->Compte_21;
                                        $declaration->Devise_8 = $provision[0]->Devise_22;
                                        $declaration->Designation_9 = $provision[0]->Designation_23;
                                        $declaration->Cellphone_10 = '';
                                        $declaration->Email_11 = '';
                                        $declaration->Nif_12 = $provision[0]->Nif_24;
                                        $declaration->Code_importers_13 = $provision[0]->Codeimport_19;
                                        $declaration->Date_initial_14 = $datime->format("Y-m-d");
                                        $declaration->Ref_declaration_15 = '';
                                        $declaration->Ref_paiement_16 = $provision[0]->Reference_20;
                                        $declaration->Numero_nrc_17 = '';
                                        $declaration->Numero_importexport_18 = $provision[0]->Numero_importexport_39;
                                        $declaration->Numero_validation_19 = '';
                                        $declaration->Category_20 = $provision[0]->CodeType_38;
                                        $declaration->Amountpaid_21 = '';
                                        $declaration->Devise_22 = '';
                                        $declaration->Amountdue_23 = $provision[0]->MontantCIF_8;
                                        $declaration->Devise_24 = $provision[0]->Devise_9;
                                        $declaration->Initial_expiration_25 = $datime->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                                        $declaration->Force_26 = '';
                                        $declaration->is_complete_27 = '';
                                        $declaration->Doc_expiration_28 = '';
                                        $declaration->Address_29 = '';
                                        $declaration->Date_paiement_30 = '';
                                        $declaration->Comment_31 = '';
                                        $declaration->Date_extension_32 = '';
                                        $declaration->Amountremaining_33 = '';
                                        $declaration->Devise_34 = '';
                                        $declaration->Licence_35 = $NumLcc;
                                        $declaration->Results_36 = '';
                                        $declaration->Documents_37 = '';
                                        $declaration->Prefinance_38 = (!is_null($provision[0]->Prefinance_43))?$provision[0]->Prefinance_43:Null;
                                        $declaration->AmountPrefinance_39 = (!is_null($provision[0]->AmountPrefinance_41))?$provision[0]->AmountPrefinance_41:Null;
                                        $declaration->Devise_40 = (!is_null($provision[0]->Devise_42))?$provision[0]->Devise_42:Null;
                                        $declaration->Merchandise_41 = (!is_null($provision[0]->Merchandise_40))?$provision[0]->Merchandise_40:Null;
                                }
                                else
                                {
                                        $licence = $this->seguceModel->get_licence_validated_by_id($NumLcc);

                                        if (!empty($licence))
                                        {
                                                $categorie = $this->licenceModel->get_categorie_by_object($licence->CodeType_26);
                                                $datime = new \DateTime($licence->Validation_28);
                                                $declaration->Id_0 = "";
                                                $declaration->Date_1 = gmdate('Y-m-d H:i:s');
                                                $declaration->Status_2 = '';
                                                $declaration->Account_3 = '';
                                                $declaration->Creator_4 = '';
                                                $declaration->Changes_5 = '';
                                                $declaration->Changer_6 = '';
                                                $declaration->Compte_7 = $licence->Compte_20;
                                                $declaration->Devise_8 = $licence->Devise_21;
                                                $declaration->Designation_9 = $licence->Designation_22;
                                                $declaration->Cellphone_10 = '';
                                                $declaration->Email_11 = '';
                                                $declaration->Nif_12 = $licence->Nif_23;
                                                $declaration->Code_importers_13 = $licence->Codeimport_18;
                                                $declaration->Date_initial_14 = $datime->format("Y-m-d");
                                                $declaration->Ref_declaration_15 = '';
                                                $declaration->Ref_paiement_16 = $licence->Reference_19;
                                                $declaration->Numero_nrc_17 = '';
                                                $declaration->Numero_importexport_18 = $licence->Numero_importexport_27;
                                                $declaration->Numero_validation_19 = '';
                                                $declaration->Category_20 = $licence->CodeType_26;
                                                $declaration->Amountpaid_21 = '';
                                                $declaration->Devise_22 = '';
                                                $declaration->Amountdue_23 = $licence->MontantCIF_8;
                                                $declaration->Devise_24 = $licence->Devise_9;
                                                $declaration->Initial_expiration_25 = $datime->modify("+$categorie->Validity_10 days")->format("Y-m-d");;
                                                $declaration->Force_26 = '';
                                                $declaration->is_complete_27 = '';
                                                $declaration->Doc_expiration_28 = '';
                                                $declaration->Address_29 = '';
                                                $declaration->Date_paiement_30 = '';
                                                $declaration->Comment_31 = '';
                                                $declaration->Date_extension_32 = '';
                                                $declaration->Amountremaining_33 = '';
                                                $declaration->Devise_34 = '';
                                                $declaration->Licence_35 = $NumLcc;
                                                $declaration->Results_36 = '';
                                                $declaration->Documents_37 = '';
                                        }
                                        else
                                        {
                                                $declaration = Null;
                                        }
                                }

                        }

                        if(!is_null($declaration)){
                                $this->data['categorie'] = $categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                                $this->data['typepay'] = $this->licenceModel->get_typepayment_by_type($categorie->Payment_type_13);
                                $this->data['type_payments'] = $this->licenceModel->get_dropdown("type_payments");
                                $this->data['documents'] = $documents =  explode(",",$categorie->Document_list_12);
                                $this->data['description_document'] = array();
                                $this->data['status_document'] = array();
                                $this->data["notifications"] = $this->licenceModel->get_elicense_notification($declaration->Id_0,1);
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                $this->data["status_licence"] = $this->licenceModel->status;

                                if (isset($declaration->Results_36) && $declaration->Results_36 != ""):
                                        $paiements = json_decode($declaration->Results_36);
                                else:
                                        $paiements = array();
                                endif;

                                if (isset($declaration->Documents_37) && $declaration->Documents_37 != ""):
                                        $docs = json_decode($declaration->Documents_37);
                                else:
                                        $docs = array();
                                endif;

                                $this->data["paiements"] = $paiements;
                                $this->data["docs"] = $docs;

                                $this->data['licence_documents'] = $this->licenceModel->get_documents_saving_by_declaration($declaration->Id_0);
                                foreach($documents as $document){
                                        $this->data['status_document'][$document] = $this->licenceModel->get_status_document_licence($declaration->Id_0,$document);
                                        $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                                }
                        }

                        $this->data['merchandises'] = $this->licenceModel->merchandises;
                        $this->data["declaration"] = $declaration;
                        echo json_encode(array("status" => (!is_null($declaration))?true:false,"check" => (!is_null($declaration) && $declaration->Id_0 != "")?true:false,"checkmail" => (!is_null($declaration) && $declaration->Email_11 != "")?true:false, "page" => view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data)));
                }
                elseif($obj == "apurement")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($id);
                        $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        $this->data['description'] = array();
                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                $synthese_paiements[$file] = 0;
                        }

                        $prelevement = $this->seguceModel->get_licence_by_ref($declaration->Ref_paiement_16);
                        $NumLcc = $declaration->Licence_35;
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $folder = ".drive/licence/notifications/".$account_id;
                        $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                        if (!is_dir($folder))
                        {
                                mkdir($folder, 0755, true);
                        }

                        $status_docs_expiration = false;
                        if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                $paiements = json_decode($declaration->Results_36);
                                foreach($paiements->Accounts as $key => $account){
                                        if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                $status_docs_expiration = true;
                                        }
                                }
                        else:
                                $paiements = array();
                        endif;

                        $Amountpaidoc = 0;

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $Documents_37 = json_decode($declaration->Documents_37);
                                foreach($Documents_37 as $item){
                                        foreach($item->Documents as $key => $document){

                                                if($document == "FF"){
                                                        $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                }

                                                $synthese_paiements[$document] += (float) $item->Amountpaid->$key;

                                                if(!in_array($document,$synthese_documents)){

                                                        array_push($synthese_documents,$document);

                                                }

                                        }
                                }
                        endif;

                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                        $this->data["creatime"] = date("Y-m-d H:i:s");
                        $this->data["date"] = date("Y-m-d H:i:s");
                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                        $this->data["Designation_9"] = $declaration->Designation_9;
                        $this->data["Address_29"] = $declaration->Address_29;
                        $this->data["Num_lcc"] = $NumLcc;
                        $this->data["Title_8"] = $Categorie->Title_8;
                        $this->data["Devise"] = $declaration->Devise_24;
                        $this->data["Categorie"] = $declaration->Category_20;
                        $this->data["elicense"] = $declaration;
                        $this->data["synthese_documents"] = $synthese_documents;
                        $this->data["synthese_paiements"] = $synthese_paiements;
                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                        $html = view('\Modules\Eximtrade\Views\impression\_elicense_apurement', $this->data);
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'I');
                        exit;
                }
                elseif($obj == "send_mail_apurement")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($_POST["Id_0"]);
                        $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        $this->data['description'] = array();
                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                $synthese_paiements[$file] = 0;
                        }
                        $prelevement = $this->seguceModel->get_licence_by_ref($declaration->Ref_paiement_16);
                        $NumLcc = $declaration->Licence_35;
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $folder = ".drive/licence/notifications/".$account_id;
                        $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                        if (!is_dir($folder))
                        {
                                mkdir($folder, 0755, true);
                        }

                        $status_docs_expiration = false;
                        if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                $paiements = json_decode($declaration->Results_36);
                                foreach($paiements->Accounts as $key => $account){
                                        if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                $status_docs_expiration = true;
                                        }
                                }
                        else:
                                $paiements = array();
                        endif;

                        $Amountpaidoc = 0;

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $Documents_37 = json_decode($declaration->Documents_37);
                                foreach($Documents_37 as $item){
                                        foreach($item->Documents as $key => $document){

                                                if($document == "FF"){
                                                        $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                }

                                                $synthese_paiements[$document] += (float) $item->Amountpaid->$key;

                                                if(!in_array($document,$synthese_documents)){

                                                        array_push($synthese_documents,$document);

                                                }

                                        }
                                }
                        endif;

                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                        $this->data["creatime"] = date("Y-m-d H:i:s");
                        $this->data["date"] = date("Y-m-d H:i:s");
                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                        $this->data["Designation_9"] = $declaration->Designation_9;
                        $this->data["Address_29"] = $declaration->Address_29;
                        $this->data["Num_lcc"] = $NumLcc;
                        $this->data["Title_8"] = $Categorie->Title_8;
                        $this->data["Devise"] = $declaration->Devise_24;
                        $this->data["Categorie"] = $declaration->Category_20;
                        $this->data["elicense"] = $declaration;
                        $this->data["synthese_documents"] = $synthese_documents;
                        $this->data["synthese_paiements"] = $synthese_paiements;
                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                        $html = view('\Modules\Eximtrade\Views\impression\_elicense_apurement', $this->data);
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);

                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'F');

                        $customer = $declaration->Designation_9;
                        $email = $declaration->Email_11;
                        if($email != ""){
                                //$return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);

                                unlink(ROOTPATH . $folder."/".$Linkdocument_9);

                                if(true)//$return
                                {
                                        echo 200;
                                }
                                else
                                {
                                        echo 500;
                                }
                        }
                }
                elseif ($obj == "dec_batch_file")
                {
                        $fileTmp = $_FILES['file']['tmp_name'] ?? '';
                        $fileName = $_FILES['file']['name'] ?? '';
                        $file_extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                        $valid_extensions = ['xlsx', 'xls'];

                        if (empty($fileTmp) || !is_uploaded_file($fileTmp))
                        {
                                echo 'E201'; die;
                        }
                        if (!in_array($file_extension, $valid_extensions))
                        {
                                echo 'E202'; die;
                        }

                        $account_id = $this->session->userdata['account_id'] ?? 'default';
                        $ref = date('HisdmY');
                        $target_dir = "./drive/logiref/{$account_id}/" . date('Y-m') . "/DEC/{$ref}/";
                        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

                        $filename = basename($fileName);
                        $target_file = $target_dir . str_replace(" ", "", $filename);

                        if (move_uploaded_file($fileTmp, $target_file)) {
                                $file = $target_file;
                        } else {
                                $file = $fileTmp;
                        }

                        if (!file_exists($file)) {
                                echo 'E203'; die;
                        }

                        ini_set('memory_limit', '512M');
                        ini_set('max_execution_time', 300);

                        $columnsToPropagate = ['C','D','E','G','H','U','V'];
                        $lastValues = array_fill_keys($columnsToPropagate, null);

                        $processRow = function($row) use (&$lastValues, $columnsToPropagate)
                        {
                                foreach ($columnsToPropagate as $col)
                                {
                                        if (isset($row[$col]) && trim((string)$row[$col]) !== '')
                                        {
                                                $lastValues[$col] = trim((string)$row[$col]);
                                        }
                                        $row[$col] = $lastValues[$col];
                                }

                                $numdec = trim(($row['G'] ?? '') . ' ' . ($row['H'] ?? ''));
                                if ($numdec === '') {
                                        return;
                                }

                                $region = trim(($row['C'] ?? '') . ' ' . ($row['D'] ?? ''));
                                $type = $row['E'] ?? null;

                                $licenseVal = (object)[
                                        'region'            => $region,
                                        'type'              => $type,
                                        'client_code'       => $row['F'] ?? null,
                                        'license_id'        => $numdec,
                                        'license_type'      => $row['I'] ?? null,
                                        'customer_name'     => $row['J'] ?? null,
                                        'beneficiary'       => $row['K'] ?? null,
                                        'from_country'      => $row['L'] ?? null,
                                        'to_country'        => $row['M'] ?? null,
                                        'currency'          => $row['N'] ?? null,
                                        'amount'            => $row['O'] ?? null,
                                        'freight_fees'      => $row['P'] ?? null,
                                        'insurance_fees'    => $row['Q'] ?? null,
                                        'other_fees'        => $row['R'] ?? null,
                                        'total_fees'        => $row['S'] ?? null,
                                        'difference_amount' => $row['T'] ?? null,
                                        'is_validated'      => $row['U'] ?? null,
                                        'validation_date'   => $row['W'] ?? null,
                                        'expiry_date'       => $row['X'] ?? null,
                                        'validity_period'   => $row['Y'] ?? null,
                                        'status'            => $row['Z'] ?? null,
                                        'marked_by'         => $row['AA'] ?? null,
                                        'validated_by'      => $row['AB'] ?? null
                                ];

                                $arrayCodetypeIsys = explode("-", $licenseVal->license_id);
                                $codetype_isys = $this->licenceModel->get_codetype_isys($licenseVal->license_type, end($arrayCodetypeIsys));
                                if (!$codetype_isys) {
                                        if(end($arrayCodetypeIsys) == "EB" || end($arrayCodetypeIsys) == "IB"):
                                                $Category_20 = end($arrayCodetypeIsys).substr($licenseVal->license_type,0,2);
                                        else :
                                                $Category_20 = end($arrayCodetypeIsys).$licenseVal->license_type;
                                        endif;

                                        $this->licenceModel->save_codetype_isys(['Codetype_1' => end($arrayCodetypeIsys), 'Licensetype_2' => $licenseVal->license_type]);
                                }
                                else {
                                        $Category_20 = $codetype_isys->Codetype_1;
                                        if (!in_array($Category_20, ["IS","ES","RC"])) {
                                                $Category_20 .= $codetype_isys->Licensetype_2;
                                        }
                                        else{
                                                if(end($arrayCodetypeIsys) == "EB" || end($arrayCodetypeIsys) == "IB") :
                                                        $Category_20 .= substr($codetype_isys->Licensetype_2,0,2);
                                                endif;
                                        }
                                }

                                $amount = floatval($licenseVal->difference_amount) + floatval($licenseVal->total_fees);
                                $amount_paid = floatval($licenseVal->total_fees);
                                $amount_remaining = $amount - $amount_paid;

                                $initDate = $this->data("parseExcelDate", $licenseVal->validation_date);
                                $expDate = $this->data("parseExcelDate", $licenseVal->expiry_date);
                                $initial_date = $initDate ? date('Y-m-d', strtotime($initDate)) : null;
                                $initial_expiration = $expDate ? date('Y-m-d', strtotime($expDate)) : null;

                                if (!$initial_expiration) {
                                        return;
                                }

                                $Categorie = $this->licenceModel->get_categorie_by_object($Category_20);

                                if (!$Categorie)
                                {
                                        if(end($arrayCodetypeIsys) == "EB") :

                                                $Category_20 = "EB01";

                                        elseif(end($arrayCodetypeIsys) == "IB") :

                                                $Category_20 = "IB27";

                                        endif;
                                }

                                if ($licenseVal->status == "Apurée") {
                                        $status_2 = 7;
                                        $is_complete_27 = 1;
                                }
                                else {
                                        if (strtotime("now") < strtotime($initial_expiration)) {
                                                $status_2 = $amount_remaining == 0 ? 7 : 4;
                                        }
                                        else {
                                                $status_2 = $amount_remaining > 0 ? 8 : 7;
                                        }

                                        if (in_array($Category_20, ["IS","ES","RC"])) {
                                                $status_2 = strtotime("now") < strtotime($initial_expiration)
                                                        ? ($amount_remaining == 0 ? 7 : 4)
                                                        : ($amount_remaining > 0 ? 8 : 7);
                                        }
                                        $is_complete_27 = 0;
                                }

                                $declaration = $this->licenceModel->get_license_exists($licenseVal->license_id);
                                $currency_mapping = $this->licenceModel->get_currency_mapping($licenseVal->currency);
                                $currency_isys = $currency_mapping?->Currency_2 ?? 'USD';

                                $data = [
                                        'Status_2'              => $status_2,
                                        'Amountpaid_21'         => $amount_paid,
                                        'Devise_22'             => $currency_isys,
                                        'Amountdue_23'          => $amount,
                                        'Devise_24'             => $currency_isys,
                                        'Initial_expiration_25' => $initial_expiration,
                                        'is_complete_27'        => $is_complete_27,
                                        'Amountremaining_33'    => $amount_remaining,
                                        'Devise_34'             => $currency_isys
                                ];

                                if ($declaration) {
                                        $this->licenceModel->save_elicense_declarations($data, $declaration->Id_0);
                                }
                                else {

                                        $data = [
                                                'Id_0'                  => null,
                                                'Date_1'                => gmdate('Y-m-d H:i:s'),
                                                'Status_2'              => $status_2,
                                                'Account_3'             => $this->session->userdata["account_id"],
                                                'Creator_4'             => $this->session->userdata["user_id"],
                                                'Designation_9'         => $licenseVal->customer_name,
                                                'Code_importers_13'     => $licenseVal->client_code,
                                                'Date_initial_14'       => $initial_date,
                                                'Category_20'           => $Category_20,
                                                'Amountpaid_21'         => $amount_paid,
                                                'Devise_22'             => $currency_isys,
                                                'Amountdue_23'          => $amount,
                                                'Devise_24'             => $currency_isys,
                                                'Initial_expiration_25' => $initial_expiration,
                                                'Force_26'              => 0,
                                                'is_complete_27'        => $is_complete_27,
                                                'Amountremaining_33'    => $amount_remaining,
                                                'Devise_34'             => $currency_isys,
                                                'Licence_35'            => $licenseVal->license_id,
                                                'AmountPrefinance_39'   => 0,
                                                'Region_42'             => $licenseVal->region,
                                                'Type_43'               => $licenseVal->type,
                                                'Maker_44'              => $licenseVal->marked_by,
                                                'Checker_45'            => $licenseVal->validated_by
                                        ];

                                        $this->licenceModel->save_elicense_declarations($data);
                                }
                        };

                        try {
                                $reader = IOFactory::createReaderForFile($file);
                                $reader->setReadDataOnly(true);
                                $spreadsheet = $reader->load($file);
                        }
                        catch (\Throwable $e) {
                                echo 'E204 '.$e->getMessage(); die;
                        }

                        $sheet = $spreadsheet->getActiveSheet();
                        $highestRow = $sheet->getHighestDataRow();
                        $rows = $sheet->rangeToArray('A12:AB'.$highestRow, null, true, true, true);

                        foreach ($rows as $row)
                        {
                                $processRow($row);
                        }

                        $spreadsheet->disconnectWorksheets();
                        unset($spreadsheet);

                        $this->data['step'] = 2;

                        $logDir = ROOTPATH . 'drive/logs/spark/';

                        if (!is_dir($logDir)) {
                                mkdir($logDir, 0775, true);
                        }

                        $logFile = $logDir . 'log-' . date('Y-m-d') . '.log';

                        $output = [];
                        $status = 0;

                        chdir(ROOTPATH);

                        $php = '/Applications/MAMP/bin/php/php8.2.0/bin/php';
                        $spark = ROOTPATH . 'spark';

                        $cmd = $php . ' ' . $spark . ' elicense:actualisation 2>&1';

                        exec($cmd, $output, $status);

                        file_put_contents(
                                $logFile,
                                "[" . date('H:i:s') . "] " . implode(PHP_EOL, $output) . PHP_EOL . PHP_EOL,
                                FILE_APPEND
                        );

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_result', $this->data);
                }
                elseif ($obj == "details_batch_file")
                {
                        $file = $_FILES['file']['tmp_name'];
                        $file_extension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
                        $valid_extensions = ['xlsx', 'xls'];

                        if (empty($file) || !is_uploaded_file($file))
                        {
                                echo 'E201'; die;
                        }
                        if (!in_array($file_extension, $valid_extensions))
                        {
                                echo 'E202'; die;
                        }

                        $account_id = $this->session->userdata['account_id'] ?? 'default';
                        $ref = date('HisdmY');
                        $target_dir = "./drive/logiref/{$account_id}/" . date('Y-m') . "/DEC/Details/{$ref}/";
                        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

                        $filename = basename($_FILES["file"]["name"]);
                        $target_file = $target_dir . str_replace(" ", "", $filename);

                        if (move_uploaded_file($file, $target_file)) $file = $target_file;

                        ini_set('memory_limit', '512M');
                        ini_set('max_execution_time', 300);

                        $processRow = function($row)
                        {
                                if (isset($row[1])) unset($row[1]);
                                if (isset($row[2])) unset($row[2]);

                                $rowValues = array_values($row);
                                $isEmpty = true;

                                foreach ($rowValues as $cell)
                                {
                                        if (!is_null($cell) && trim($cell) !== '')
                                        {
                                                $isEmpty = false;
                                                break;
                                        }
                                }

                                if ($isEmpty) return;

                                $licenseVal = (object) [
                                        'number'                => $row['A'],
                                        'date'                  => $row['B'],
                                        'transaction'           => $row['C'],
                                        'account'               => $row['D'],
                                        'customer'              => $row['E'],
                                        'code_importers'        => $row['F'],
                                        'amount_op'             => $row['G'],
                                        'currency'              => $row['H'],
                                        'license_number'        => $row['I'],
                                        'amount_paid'           => $row['J'],
                                        'country'               => $row['K']
                                ];

                                // ---- Mise à jour ou insertion ---- //
                                $declaration = $this->licenceModel->get_license_exists($licenseVal->license_number);

                                if (!is_null($declaration))
                                {
                                        $results = !empty($declaration->Results_36) ? json_decode($declaration->Results_36,true) : [];
                                        $currency_mapping = $this->licenceModel->get_currency_mapping($licenseVal->currency);
                                        $currency_isys = $currency_mapping?->Currency_2 ?? 'USD';

                                        $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                                        if (!$Categorie) return;

                                        $amount_prefinance = (!is_null($declaration->AmountPrefinance_39))?$declaration->AmountPrefinance_39:0;
                                        $remaining = $declaration->Amountdue_23 - $amount_prefinance;

                                        if (!is_array($results) || !isset($results['Amounts']))
                                        {
                                                $results = [
                                                        'Accounts'      => [],
                                                        'Accountnames'  => [],
                                                        'Currency'      => [],
                                                        'Date_paids'    => [],
                                                        'Amounts'       => [],
                                                        'Camounts'      => [],
                                                        'Comments'      => [],
                                                        'Delays'        => [],
                                                        'Expirations'   => [],
                                                        'Status'        => []
                                                ];
                                        }
                                        else{
                                                $paiements = json_decode($declaration->Results_36);
                                                $paid = 0;
                                                foreach($paiements->Amounts as $key => $amount){
                                                        $paid += (float) $amount;
                                                }
                                                $remaining -= $paid + str_replace(",",".", $licenseVal->amount_paid);
                                        }

                                        $increment = count($results['Amounts']) + 1;

                                        $dateObj = $this->data("parseExcelDate", $licenseVal->date);

                                        $core_banking = strtolower($this->core_banking);

                                        $accountInfo['Compte_33'] = $licenseVal->account;
                                        $accountInfo['Devise_34'] = $licenseVal->currency;
                                        $accountInfo['agence'] = $_SESSION['Guichet_code'];

                                        $return = $this->{$core_banking}->account_info($accountInfo);

                                        if(isset($return['code']) && $return['code'] == 404 || $return['code'] == 406 || $return['code'] == 405)
                                        {
                                                $return['account_name'] = $licenseVal->customer;
                                        }

                                        $results['Accounts'][$increment]        = $licenseVal->account;
                                        $results['Accountnames'][$increment]    = $return['account_name'];
                                        $results['Currency'][$increment]        = $declaration->Devise_22 ?? 'USD';
                                        $results['Date_paids'][$increment]      = $dateObj->format("Y-m-d");
                                        $results['Amounts'][$increment]         = str_replace(",",".", $licenseVal->amount_paid);
                                        $results['Camounts'][$increment]        = $declaration->Devise_22 ?? 'USD';
                                        $results['Comments'][$increment]        = 'Paiement complémentaire ajouté le '.date('Y-m-d H:i:s');
                                        $results['Delays'][$increment]          = $Categorie->Document_delay_11;
                                        $results['Expirations'][$increment]     = $dateObj->modify("+{$Categorie->Document_delay_11} days")->format("Y-m-d");
                                        $results['Status'][$increment]          = ($remaining > 0)?4:9;

                                        $status_2 = $declaration->Status_2;

                                        // Déterminer statut et Intitulé
                                        if (in_array($declaration->Category_20, ["IS", "ES", "RC"]))
                                        {
                                                if (strtotime("now") < strtotime($declaration->Initial_expiration_25))
                                                {
                                                        $status_2 = $remaining == 0 ? 7 : ($remaining > 0 ? 4 : 2);
                                                        $labels = [
                                                                7 => "Licence est apuré",
                                                                4 => "Licence partielle, paiement(s) en attente",
                                                                2 => "Licence en cours de validité"
                                                        ];

                                                        $Intitule_8 = $labels[$status_2];
                                                }
                                                else {
                                                        $status_2 = $remaining > 0 ? 8 : 7;
                                                        $Intitule_8 = $status_2 == 8 ? "Licence expiré" : "Licence est apuré";
                                                }
                                        }
                                        else {
                                                if (strtotime("now") < strtotime($declaration->Initial_expiration_25))
                                                {
                                                        if ($remaining == 0)
                                                        {
                                                                $Intitule_8n = "Licence est total";
                                                                $status_2 = 9;
                                                        }
                                                        elseif ($remaining > 0 && $declaration->Amountdue_23 > $remaining)
                                                        {
                                                                $Intitule_8 = "Licence partielle";
                                                                $status_2 = 4;
                                                        }
                                                        else {
                                                                $Intitule_8 = "Licence en cours";
                                                                $status_2 = 2;
                                                        }
                                                }
                                                else {
                                                        if ($remaining == 0)
                                                        {
                                                                $Intitule_8 = "Licence incomplète";
                                                                $status_2 = 3;
                                                        }
                                                        else {
                                                                $Intitule_8 = "Licence expiré";
                                                                $status_2 = 8;
                                                        }
                                                }
                                        }

                                        $data = [
                                                'Status_2'              => $status_2,
                                                'Amountpaid_21'         => $declaration->Amountdue_23 - $remaining,
                                                'Amountremaining_33'    => $remaining,
                                                'Results_36' => json_encode($results)
                                        ];

                                        $this->licenceModel->save_elicense_declarations($data, $declaration->Id_0);
                                }
                        };

                        // --- Chunked Reading ---
                        $filter = new ChunkReadFilter();
                        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
                        $reader->setReadDataOnly(true);
                        $reader->setReadFilter($filter);

                        $chunkSize = 500;
                        $startRow = 3;

                        while (true)
                        {
                                $filter->setRows($startRow, $chunkSize);

                                try {
                                        $spreadsheet = $reader->load($file);
                                        $rows = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

                                        if (count($rows) <= 2) break;
                                        foreach ($rows as $row) $processRow($row);

                                        $spreadsheet->disconnectWorksheets();
                                        unset($spreadsheet);

                                        if (count($rows) < $chunkSize) break;
                                                $startRow += $chunkSize;
                                }
                                catch (\Throwable $e) {
                                        echo 'Erreur de lecture : '.$e->getMessage(); die;
                                }
                        }

                        $this->data['step'] = 2;

                        $logDir = ROOTPATH . 'drive/logs/spark/';

                        if (!is_dir($logDir)) {
                                mkdir($logDir, 0775, true);
                        }

                        $logFile = $logDir . 'log-' . date('Y-m-d') . '.log';

                        $output = [];
                        $status = 0;

                        chdir(ROOTPATH);

                        $php = '/Applications/MAMP/bin/php/php8.2.0/bin/php';
                        $spark = ROOTPATH . 'spark';

                        $cmd = $php . ' ' . $spark . ' elicense:actualisation 2>&1';

                        exec($cmd, $output, $status);

                        file_put_contents(
                                $logFile,
                                "[" . date('H:i:s') . "] " . implode(PHP_EOL, $output) . PHP_EOL . PHP_EOL,
                                FILE_APPEND
                        );

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_result', $this->data);
                }
                elseif($obj == "viewpdf")
                {
                        $notification = $this->licenceModel->get_elicense_notification_by_id($id);
                        $filePath = $notification->Linkdocument_9;

                        if (file_exists($filePath)) {
                                return $this->response->setHeader('Content-Type', 'application/pdf')
                                        ->setHeader('Content-Disposition', 'inline; filename="' . basename($notification->Linkdocument_9) . '"')
                                        ->setBody(file_get_contents($filePath));
                        }
                        else {
                                return redirect()->to(base_url("404"));
                        }
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "elicense_document")
                {

                        $Id_0 = $this->request->getPost("Id_0");

                        if($Id_0 == ""){

                                $NumLcc = $this->request->getPost("Licence_35");
                                $provision = $this->seguceModel->get_provisions_validated_by_licence($NumLcc);
                                $data = array();
                                $Prefinance_38 = "";
                                $AmountPrefinance_39 = 0;
                                $Devise_40 = "";
                                $Merchandise_41 = "";

                                if (!empty($provision))
                                {
                                        $categorie = $this->licenceModel->get_categorie_by_object($provision[0]->CodeType_38);
                                        $datime = new \DateTime($provision[0]->Validation_44);
                                        $data["Date_1"] = $days = gmdate('Y-m-d H:i:s');
                                        $data["Status_2"] = 1;
                                        $data["Account_3"] = $this->session->userdata["account_id"];
                                        $data["Creator_4"] = $this->session->userdata["user_id"];
                                        $data["Compte_7"] = $provision[0]->Compte_21;
                                        $data["Devise_8"] = $provision[0]->Devise_22;
                                        $data["Designation_9"] = $provision[0]->Designation_23;
                                        $data["Nif_12"] = $provision[0]->Nif_24;
                                        $data["Code_importers_13"] = $provision[0]->Codeimport_19;
                                        $data["Date_initial_14"] = $datime->format("Y-m-d");
                                        $data["Ref_paiement_16"] = $provision[0]->Reference_20;
                                        $data["Numero_importexport_18"] = $provision[0]->Numero_importexport_39;
                                        $data["Category_20"] = $Category_20 = $provision[0]->CodeType_38;
                                        $data["Amountdue_23"] = $Amountdue_23 = $provision[0]->MontantCIF_8;
                                        $data["Devise_24"] = $provision[0]->Devise_9;
                                        $data["Initial_expiration_25"] = $Initial_expiration_25 = $datime->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                                        $data["Amountremaining_33"] = $Amountremaining_33 = (!is_null($provision[0]->AmountPrefinance_41))?$Amountdue_23 - $provision[0]->AmountPrefinance_41:$Amountdue_23;
                                        $data["Devise_34"] = $provision[0]->Devise_9;
                                        $data["Licence_35"] = $NumLcc;
                                        $data["Prefinance_38"] = $Prefinance_38 = $provision[0]->Prefinance_43;
                                        $data["AmountPrefinance_39"] = $AmountPrefinance_39 = (!is_null($provision[0]->AmountPrefinance_41))?$provision[0]->AmountPrefinance_41:$AmountPrefinance_39;
                                        $data["Devise_40"] = $Devise_40 = $provision[0]->Devise_42;
                                        $data["Merchandise_41"] = $Merchandise_41 = $provision[0]->Merchandise_40;
                                }
                                else
                                {
                                        $licence = $this->seguceModel->get_licence_validated_by_id($NumLcc);

                                        if (!empty($licence))
                                        {
                                                $categorie = $this->licenceModel->get_categorie_by_object($licence->CodeType_26);
                                                $datime = new \DateTime($licence->Validation_28);
                                                $data["Date_1"] = $days = gmdate('Y-m-d H:i:s');
                                                $data["Status_2"] = 1;
                                                $data["Account_3"] = $this->session->userdata["account_id"];
                                                $data["Creator_4"] = $this->session->userdata["user_id"];
                                                $data["Compte_7"] = $licence->Compte_20;
                                                $data["Devise_8"] = $licence->Devise_21;
                                                $data["Designation_9"] = $licence->Designation_22;
                                                $data["Nif_12"] = $licence->Nif_23;
                                                $data["Code_importers_13"] = $licence->Codeimport_18;
                                                $data["Date_initial_14"] = $datime->format("Y-m-d");
                                                $data["Ref_paiement_16"] = $licence->Reference_19;
                                                $data["Numero_importexport_18"] = $licence->Numero_importexport_27;
                                                $data["Category_20"] = $Category_20 = $licence->CodeType_26;
                                                $data["Amountdue_23"] = $Amountdue_23 = $licence->MontantCIF_8;
                                                $data["Devise_24"] = $licence->Devise_9;
                                                $data["Initial_expiration_25"] = $Initial_expiration_25 = $datime->modify("+$categorie->Validity_10 days")->format("Y-m-d");
                                                $data["Amountremaining_33"] = $Amountremaining_33 = $Amountdue_23;
                                                $data["Devise_34"] = $licence->Devise_9;
                                                $data["Licence_35"] = $NumLcc;
                                                $data["Prefinance_38"] = $Prefinance_38;
                                                $data["AmountPrefinance_39"] = $AmountPrefinance_39;
                                                $data["Devise_40"] = $Devise_40;
                                                $data["Merchandise_41"] = $Merchandise_41;
                                        }
                                }

                                if(!empty($_POST["Expedition"]))
                                {
                                        $Documents_37 = array();
                                        $expedition = $this->request->getPost("Expedition");
                                        $Expedition = array();
                                        $Amount_paid_document = 0;
                                        $files = explode(",",$categorie->Document_list_12);
                                        $synthese_documents = array();
                                        $synthese_paiements = array();
                                        foreach($files as $file){
                                                $synthese_paiements[$file] = 0;
                                        }

                                        $i = 1;
                                        foreach($expedition as $key => $value){
                                                $documents = $this->request->getPost("Documents[$key]");
                                                for($j = 1;$j <= count($documents);$j++){
                                                        $Creator[$j]= $this->session->userdata["user_id"];
                                                        $Changes[$j] = "0000-00-00 00:00:00";
                                                        $Changer[$j] = "0";
                                                }
                                                $Documents = array();
                                                $j = 1;
                                                foreach($documents as $document){
                                                        $Documents[$j] = $document;
                                                        if(!in_array($document,$synthese_documents)){
                                                                array_push($synthese_documents,$document);
                                                        }
                                                        $j++;
                                                }
                                                $reference = $this->request->getPost("Reference[$key]");
                                                $Reference = array();
                                                $j = 1;
                                                foreach($reference as $val){
                                                        $Reference[$j] = $val;
                                                        $j++;
                                                }

                                                $Amountcertified = "";
                                                if(!empty($this->request->getPost("Amountcertified[$key]"))){
                                                        $amountcertified = $this->request->getPost("Amountcertified[$key]");
                                                        foreach($amountcertified as $val){
                                                                $Amountcertified = str_replace(",",".",$val);
                                                        }
                                                }

                                                $Confirmed = "";
                                                if(!empty($this->request->getPost("Confirmed[$key]"))){
                                                        $confirmed = $this->request->getPost("Confirmed[$key]");
                                                        foreach($confirmed as $val){
                                                                $Confirmed = $val;
                                                        }
                                                }

                                                $amounts = $this->request->getPost("Amountpaid[$key]");
                                                $Amountpaid = array();
                                                $j = 1;
                                                foreach($amounts as $amount){
                                                        if($Documents[$j] == "FF"){
                                                                $Amount_paid_document += str_replace(",",".",$amount);
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        }
                                                        elseif($Documents[$j] == "CVI" || $Documents[$j] == "AVB")
                                                        {
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                if($Confirmed != "" && $Confirmed == 2){
                                                                        $synthese_paiements[$Documents[$j]] += $Amountcertified;
                                                                }
                                                                else{
                                                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                                }
                                                        }
                                                        else{
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        }
                                                        $j++;
                                                }

                                                $currency = $this->request->getPost("Currency[$key]");
                                                $Currency = array();
                                                $j = 1;
                                                foreach($currency as $val){
                                                        $Currency[$j] = $val;
                                                        $j++;
                                                }

                                                if(count($synthese_documents) == 4){

                                                        if($categorie->Object_7 == "IB20" || $categorie->Object_7 == "IB21" || $categorie->Object_7 == "IB22"){

                                                                if($synthese_paiements["FF"] >= $Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $Amountdue_23))){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }
                                                        }
                                                        elseif($categorie->Object_7 == "EB01" || $categorie->Object_7 == "EB08" || $categorie->Object_7 == "EB06"){

                                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($Prefinance_38 == "" && $Amountdue_23 <= $synthese_paiements["FF"]) || ($Prefinance_38 == "P" && ($Amountdue_23 - $AmountPrefinance_39) <= $synthese_paiements["FF"]) || $Prefinance_38 == "T")){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }

                                                        }
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }

                                                $Datexport = "";
                                                if(!empty($this->request->getPost("Datexport[$key]"))){
                                                        $datexport = $this->request->getPost("Datexport[$key]");
                                                        foreach($datexport as $val){
                                                                $Datexport = $val;
                                                        }
                                                }

                                                $amountcertified = $this->request->getPost("Amountcertified[$key]");
                                                $Amountcertified = array();
                                                $j = 1;
                                                foreach($amountcertified as $amount){
                                                        $Amountcertified[$j] = str_replace(",",".",$amount);
                                                        $j++;
                                                }

                                                $Expedition["Exped"] = $value;
                                                $Expedition["Documents"] = $Documents;
                                                $Expedition["Reference"] = $Reference;
                                                $Expedition["Amountpaid"] = $Amountpaid;
                                                $Expedition["Currency"] = $Currency;
                                                $Expedition["Status"] = $status_2;
                                                $Expedition["Datexport"] = $Datexport;
                                                $Expedition["Date"] = $days;
                                                $Expedition["Creator"] = $Creator;
                                                $Expedition["Changes"] = $Changes;
                                                $Expedition["Changer"] = $Changer;
                                                $Expedition["Amountcertified"] = $Amountcertified;
                                                $Expedition["Confirmed"] = $Confirmed;

                                                array_push($Documents_37,$Expedition);
                                                $i++;
                                        }

                                        $is_complete_27 = 0;

                                        if(count($synthese_documents) == 4){

                                                if(preg_match('/^IB/', $categorie->Object_7)){

                                                        if($synthese_paiements["FF"] >= $Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $Amountdue_23))){

                                                                $is_complete_27 = 1;
                                                                $Intitule_8 = "En cours";
                                                                $data["Status_2"] = 2;

                                                        }
                                                        else{
                                                                if(strtotime(date("Y-m-d")) >= strtotime($Initial_expiration_25)){

                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;

                                                                }
                                                        }

                                                }
                                                elseif(preg_match('/^EB/', $categorie->Object_7)){

                                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($Prefinance_38 == "" && $Amountdue_23 <= $synthese_paiements["FF"]) || ($Prefinance_38 == "P" && ($Amountdue_23 - $AmountPrefinance_39) <= $synthese_paiements["FF"]) || $Prefinance_38 == "T")){

                                                                $is_complete_27 = 1;

                                                                if($Prefinance_38 == "T")
                                                                {
                                                                        $Intitule_8 = "Apuré";
                                                                        $data["Status_2"] = 7;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "En cours";
                                                                        $data["Status_2"] = 2;
                                                                }

                                                        }
                                                        else{

                                                                if(strtotime(date("Y-m-d")) >= strtotime($Initial_expiration_25)){
                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;
                                                                }

                                                        }

                                                }

                                        }

                                        $data["is_complete_27"] = $is_complete_27;
                                        $data['Force_26'] = 0;
                                        $data['Documents_37'] = json_encode($Documents_37);
                                }

                                if(!empty($_POST['Merchandise_41'])) {
                                        $data['Merchandise_41'] = $_POST['Merchandise_41'];
                                }

                                $licence = $this->licenceModel->save_elicense_declarations($data);

                                if($licence){

                                        foreach($files as $file)
                                        {
                                                $rdata = array();
                                                $rdata['Date_1'] = $days;
                                                $rdata['Status_2'] = 2;
                                                $rdata['Account_3'] = $this->session->userdata["account_id"];
                                                $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                                                $rdata['Changer_6'] = 0;
                                                $rdata['Declarationid_7'] = $licence;
                                                $rdata['Code_8'] =  $file;

                                                $this->licenceModel->save_elicense_documents($rdata);
                                        }

                                        echo json_encode(array("status" => 200));

                                }
                                else{
                                        echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                                }

                        }
                        else{
                                $elicense = $this->licenceModel->get_licence_by_id($Id_0);
                                $categorie = $this->licenceModel->get_categorie_by_object($elicense->Category_20);
                                $files = explode(",",$categorie->Document_list_12);
                                $synthese_documents = array();
                                $synthese_paiements = array();
                                $days = date("Y-m-d H:i:s");
                                $is_complete_27 = $elicense->is_complete_27;

                                if(!empty($_POST["Expedition"]))
                                {
                                        $expedition = $this->request->getPost("Expedition");
                                        $Amount_paid_document = 0;
                                        $Documents_37 = array();
                                        foreach($files as $file){
                                                $synthese_paiements[$file] = 0;
                                        }

                                        $Expedition = array();
                                        $i = 1;
                                        foreach($expedition as $key => $value){
                                                $documents = $this->request->getPost("Documents[$key]");
                                                for($j = 1;$j <= count($documents);$j++){
                                                        $Creator[$j]= $this->session->userdata["user_id"];
                                                        $Changes[$j] = "0000-00-00 00:00:00";
                                                        $Changer[$j] = "0";
                                                }
                                                $Documents = array();
                                                $j = 1;
                                                foreach($documents as $document){
                                                        $Documents[$j] = $document;
                                                        if(!in_array($document,$synthese_documents)){
                                                                array_push($synthese_documents,$document);
                                                        }
                                                        $j++;
                                                }
                                                $reference = $this->request->getPost("Reference[$key]");
                                                $Reference = array();
                                                $j = 1;
                                                foreach($reference as $val){
                                                        $Reference[$j] = $val;
                                                        $j++;
                                                }

                                                $Amountcertified = "";
                                                if(!empty($this->request->getPost("Amountcertified[$key]"))){
                                                        $amountcertified = $this->request->getPost("Amountcertified[$key]");
                                                        foreach($amountcertified as $val){
                                                                $Amountcertified = str_replace(",",".",$val);
                                                        }
                                                }

                                                $Confirmed = "";
                                                if(!empty($this->request->getPost("Confirmed[$key]"))){
                                                        $confirmed = $this->request->getPost("Confirmed[$key]");
                                                        foreach($confirmed as $val){
                                                                $Confirmed = $val;
                                                        }
                                                }

                                                $amounts = $this->request->getPost("Amountpaid[$key]");
                                                $Amountpaid = array();
                                                $j = 1;
                                                foreach($amounts as $amount){
                                                        if($Documents[$j] == "FF"){
                                                                $Amount_paid_document += str_replace(",",".",$amount);
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        }
                                                        elseif($Documents[$j] == "CVI" || $Documents[$j] == "AVB")
                                                        {
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                if($Confirmed != "" && $Confirmed == 2){
                                                                        $synthese_paiements[$Documents[$j]] += $Amountcertified;
                                                                }
                                                                else{
                                                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                                }
                                                        }
                                                        else{
                                                                $Amountpaid[$j] = str_replace(",",".",$amount);
                                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        }
                                                        $j++;
                                                }

                                                $currency = $this->request->getPost("Currency[$key]");
                                                $Currency = array();
                                                $j = 1;
                                                foreach($currency as $val){
                                                        $Currency[$j] = $val;
                                                        $j++;
                                                }

                                                if(preg_match('/^IB/', $categorie->Object_7))
                                                {
                                                        if(count($synthese_documents) == 5)
                                                        {
                                                                if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }
                                                }
                                                elseif(preg_match('/^EB/', $categorie->Object_7))
                                                {
                                                        if(count($synthese_documents) == 4)
                                                        {
                                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                                        $Intitule_8 = "Total";
                                                                        $status_2 = 9;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Incomplète";
                                                                        $status_2 = 3;
                                                                }
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }
                                                }

                                                $Datexport = "";
                                                if(!empty($this->request->getPost("Datexport[$key]"))){
                                                        $datexport = $this->request->getPost("Datexport[$key]");
                                                        foreach($datexport as $val){
                                                                $Datexport = $val;
                                                        }
                                                }

                                                $Expedition["Exped"] = $value;
                                                $Expedition["Documents"] = $Documents;
                                                $Expedition["Reference"] = $Reference;
                                                $Expedition["Amountpaid"] = $Amountpaid;
                                                $Expedition["Currency"] = $Currency;
                                                $Expedition["Status"] = $status_2;
                                                $Expedition["Datexport"] = $Datexport;
                                                $Expedition["Date"] = $days;
                                                $Expedition["Creator"] = $Creator;
                                                $Expedition["Changes"] = $Changes;
                                                $Expedition["Changer"] = $Changer;
                                                $Expedition["Amountcertified"] = $Amountcertified;
                                                $Expedition["Confirmed"] = $Confirmed;

                                                array_push($Documents_37,$Expedition);
                                                $i++;
                                        }

                                        if(preg_match('/^IB/', $categorie->Object_7))
                                        {
                                                if(count($synthese_documents) == 5)
                                                {
                                                        if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                                $is_complete_27 = 1;
                                                                if($elicense->Amountremaining_33 == 0){
                                                                        $Intitule_8 = "Apuré";
                                                                        $data["Status_2"] = 7;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "En cours";
                                                                        $data["Status_2"] = 2;
                                                                }

                                                        }
                                                        else{
                                                                $is_complete_27 = 0;
                                                                if($elicense->Status_2 == 7){
                                                                        $Intitule_8 = "Incomplète";
                                                                        $data["Status_2"] = 3;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Partielle";
                                                                        $data["Status_2"] = 4;
                                                                }

                                                                if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){

                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;

                                                                }
                                                        }
                                                }

                                        }
                                        elseif(preg_match('/^EB/', $categorie->Object_7))
                                        {

                                                if(count($synthese_documents) == 4)
                                                {
                                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                                $is_complete_27 = 1;
                                                                if($elicense->Amountremaining_33 == 0){
                                                                        $Intitule_8 = "Apuré";
                                                                        $data["Status_2"] = 7;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "En cours";
                                                                        $data["Status_2"] = 2;
                                                                }

                                                        }
                                                        else{
                                                                $is_complete_27 = 0;
                                                                if($elicense->Status_2 == 7){
                                                                        $Intitule_8 = "Incomplète";
                                                                        $data["Status_2"] = 3;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Partielle";
                                                                        $data["Status_2"] = 4;
                                                                }

                                                                if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){
                                                                        $Intitule_8 = "Licence expiré";
                                                                        $data["Status_2"] = 8;
                                                                }

                                                        }
                                                }
                                        }

                                        $data["is_complete_27"] = $is_complete_27;
                                        $data['Documents_37'] = json_encode($Documents_37);

                                }

                                if(!empty($_POST['Merchandise_41'])) {
                                        $data['Merchandise_41'] = $_POST['Merchandise_41'];
                                }

                                $licence = $this->licenceModel->save_elicense_declarations($data, $Id_0);

                                if($licence){
                                        echo json_encode(array("status" => 200));
                                }
                                else{
                                        echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                                }

                        }

                }
                elseif ($obj == "elicense_document_update")
                {
                        $Id_0 = $this->request->getPost("Id_0");
                        $elicense = $this->licenceModel->get_licence_by_id($Id_0);
                        $categorie = $this->licenceModel->get_categorie_by_object($elicense->Category_20);
                        $files = explode(",",$categorie->Document_list_12);
                        $synthese_documents = array();
                        $synthese_paiements = array();
                        foreach($files as $file){
                                $synthese_paiements[$file] = 0;
                        }
                        $days = date("Y-m-d H:i:s");
                        $is_complete_27 = $elicense->is_complete_27;

                        if(!empty($_POST["Expedition"]))
                        {
                                $expedition = $this->request->getPost("Expedition");
                                $Amount_paid_document = 0;
                                $Documents_37 = array();
                                $Expedition = array();
                                $i = count($Documents_37) + 1;
                                foreach($expedition as $key => $value){
                                        $documents = $this->request->getPost("Documents[$key]");
                                        for($j = 1;$j <= count($documents);$j++){
                                                $Changes[$j] = $days;
                                                $Changer[$j] = $this->session->userdata["user_id"];
                                        }
                                        $Creator = array();
                                        $creator = $this->request->getPost("Creator[$key]");
                                        $j = 1;
                                        foreach($creator as $user){
                                                $Creator[$j] = $user;
                                                $j++;
                                        }
                                        $Documents = array();
                                        $j = 1;
                                        foreach($documents as $document){
                                                $Documents[$j] = $document;
                                                if(!in_array($document,$synthese_documents)){
                                                        array_push($synthese_documents,$document);
                                                }
                                                $j++;
                                        }
                                        $reference = $this->request->getPost("Reference[$key]");
                                        $Reference = array();
                                        $j = 1;
                                        foreach($reference as $val){
                                                $Reference[$j] = $val;
                                                $j++;
                                        }

                                        $Amountcertified = "";
                                        if(!empty($this->request->getPost("Amountcertified[$key]"))){
                                                $amountcertified = $this->request->getPost("Amountcertified[$key]");
                                                foreach($amountcertified as $val){
                                                        $Amountcertified = str_replace(",",".",$val);
                                                }
                                        }

                                        $Confirmed = "";
                                        if(!empty($this->request->getPost("Confirmed[$key]"))){
                                                $confirmed = $this->request->getPost("Confirmed[$key]");
                                                foreach($confirmed as $val){
                                                        $Confirmed = $val;
                                                }
                                        }

                                        $amounts = $this->request->getPost("Amountpaid[$key]");
                                        $Amountpaid = array();
                                        $j = 1;
                                        foreach($amounts as $amount){
                                                if($Documents[$j] == "FF"){
                                                        $Amount_paid_document += str_replace(",",".",$amount);
                                                        $Amountpaid[$j] = str_replace(",",".",$amount);
                                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                }
                                                elseif($Documents[$j] == "CVI" || $Documents[$j] == "AVB")
                                                {
                                                        $Amountpaid[$j] = str_replace(",",".",$amount);
                                                        if($Confirmed != "" && $Confirmed == 2){
                                                                $synthese_paiements[$Documents[$j]] += $Amountcertified;
                                                        }
                                                        else{
                                                                $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                        }
                                                }
                                                else{
                                                        $Amountpaid[$j] = str_replace(",",".",$amount);
                                                        $synthese_paiements[$Documents[$j]] += str_replace(",",".",$amount);
                                                }
                                                $j++;
                                        }

                                        $currency = $this->request->getPost("Currency[$key]");
                                        $Currency = array();
                                        $j = 1;
                                        foreach($currency as $val){
                                                $Currency[$j] = $val;
                                                $j++;
                                        }

                                        if(preg_match('/^IB/', $categorie->Object_7))
                                        {
                                                if(count($synthese_documents) == 5)
                                                {
                                                        if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                                $Intitule_8 = "Total";
                                                                $status_2 = 9;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }
                                        }
                                        elseif(preg_match('/^EB/', $categorie->Object_7))
                                        {
                                                if(count($synthese_documents) == 4)
                                                {
                                                        if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                                $Intitule_8 = "Total";
                                                                $status_2 = 9;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Incomplète";
                                                                $status_2 = 3;
                                                        }
                                                }
                                                else{
                                                        $Intitule_8 = "Incomplète";
                                                        $status_2 = 3;
                                                }
                                        }

                                        $Datexport = "";
                                        if(!empty($this->request->getPost("Datexport[$key]"))){
                                                $datexport = $this->request->getPost("Datexport[$key]");
                                                foreach($datexport as $val){
                                                        $Datexport = $val;
                                                }
                                        }

                                        $Expedition["Exped"] = $value;
                                        $Expedition["Documents"] = $Documents;
                                        $Expedition["Reference"] = $Reference;
                                        $Expedition["Amountpaid"] = $Amountpaid;
                                        $Expedition["Currency"] = $Currency;
                                        $Expedition["Status"] = $status_2;
                                        $Expedition["Datexport"] = $Datexport;
                                        $Expedition["Date"] = $days;
                                        $Expedition["Creator"] = $Creator;
                                        $Expedition["Changes"] = $Changes;
                                        $Expedition["Changer"] = $Changer;
                                        $Expedition["Amountcertified"] = $Amountcertified;
                                        $Expedition["Confirmed"] = $Confirmed;

                                        array_push($Documents_37,$Expedition);
                                        $i++;
                                }

                                if(preg_match('/^IB/', $categorie->Object_7))
                                {
                                        if(count($synthese_documents) == 5)
                                        {
                                                if($synthese_paiements["FF"] >= $elicense->Amountdue_23 && (($synthese_paiements["FF"] == $synthese_paiements["AVB"] && $synthese_paiements["AVB"] >= $elicense->Amountdue_23) || ($synthese_paiements["FF"] == $synthese_paiements["CVI"] && $synthese_paiements["CVI"] >= $elicense->Amountdue_23))){

                                                        $is_complete_27 = 1;

                                                        if($elicense->Amountremaining_33 == 0){
                                                                $Intitule_8 = "Apuré";
                                                                $data["Status_2"] = 7;
                                                        }
                                                        else{
                                                                $Intitule_8 = "En cours";
                                                                $data["Status_2"] = 2;
                                                        }

                                                }
                                                else{
                                                        if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){

                                                                $Intitule_8 = "Licence expiré";
                                                                $data["Status_2"] = 8;

                                                        }
                                                }
                                        }
                                }
                                elseif(preg_match('/^EB/', $categorie->Object_7))
                                {
                                        if(count($synthese_documents) == 4)
                                        {
                                                if(($synthese_paiements["FF"] == $synthese_paiements["CVEE"]) && (($elicense->Prefinance_38 == "" && $elicense->Amountdue_23 <= $synthese_paiements["FF"]) || ($elicense->Prefinance_38 == "P" && ($elicense->Amountdue_23 - $elicense->AmountPrefinance_39) <= $synthese_paiements["FF"]) || $elicense->Prefinance_38 == "T")){

                                                        $is_complete_27 = 1;
                                                        if($elicense->Amountremaining_33 == 0){
                                                                $Intitule_8 = "Apuré";
                                                                $data["Status_2"] = 7;
                                                        }
                                                        else{
                                                                $Intitule_8 = "En cours";
                                                                $data["Status_2"] = 2;
                                                        }

                                                }
                                                else{

                                                        if(strtotime(date("Y-m-d")) >= strtotime($elicense->Initial_expiration_25)){
                                                                $Intitule_8 = "Licence expiré";
                                                                $data["Status_2"] = 8;
                                                        }

                                                }
                                        }
                                }

                                $data["is_complete_27"] = $is_complete_27;
                                $data['Documents_37'] = json_encode($Documents_37);
                        }

                        if(!empty($_POST['Merchandise_41'])) {
                                $data['Merchandise_41'] = $_POST['Merchandise_41'];
                        }

                        $licence = $this->licenceModel->save_elicense_declarations($data, $Id_0);

                        if($licence){
                                echo json_encode(array("status" => 200));
                        }
                        else{
                                echo json_encode(array("status" => 500,"message" => "Erreur d'enregistrement"));
                        }

                }
                elseif ($obj == "elicense")
                {
                        $AmountPrefinance_39 = ($_POST["AmountPrefinance_39"] != "")?$this->request->getPost("AmountPrefinance_39"):0;
                        $Prefinance_38 = ($_POST['Prefinance_38'] != "")?$this->request->getPost("Prefinance_38"):Null;
                        $total_amountpaid = 0;
                        $amount_remaining = 0;

                        $amount_licence = $Amountdue_23 = str_replace(",",".",$_POST['Amountdue_23']);
                        $amount_licence = str_replace(' ','',$amount_licence);
                        $amount_licence -= $AmountPrefinance_39;

                        if($Prefinance_38 != "T"){
                                $status = array();
                                foreach ((array) $_POST["Amountpaids"] as $key => $amount)
                                {
                                        $total_amountpaid += str_replace(' ','',$amount);
                                        $amount_remaining = $amount_licence - $total_amountpaid;

                                        if ($amount_remaining > 0) $status[$key] = 4;
                                        if ($amount_remaining == 0) $status[$key] = 9;
                                }
                        }

                        $prorogation = json_decode($this->request->getPost("prorogation"));
                        $Id_0 = $this->request->getPost("DeclarationId");
                        $Categorie = $this->licenceModel->get_categorie_by_object($this->request->getPost("Category_20"));
                        $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);

                        $Force_26 = (!empty($this->request->getPost("Force_26")))?json_decode($this->request->getPost("Force_26")):0;
                        $is_complete_27 = $this->request->getPost("is_complete_27");
                        $this->data["error"] = 200;
                        $this->data['description'] = array();

                        foreach($files as $file)
                        {
                                $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                        }

                        if(in_array($this->request->getPost("Category_20"),array("IS","ES","RC"))){

                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($this->request->getPost("Initial_expiration_25")))
                                {
                                        if($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                        elseif($amount_remaining > 0){
                                                $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                $status_2 = 4;

                                                if($this->request->getPost("Date_extension_32") != "" && $this->request->getPost("Date_extension_32") != "0000-00-00"){
                                                        $Intitule_8 = "Licence renouvellé avec succès";
                                                        $Status_2 = 5;
                                                }
                                        }
                                        else{
                                                $Intitule_8 = "Licence en cours de validité";
                                                $status_2 = 2;
                                        }
                                }
                                else{
                                        if($amount_remaining > 0){
                                                $Intitule_8 = "Licence est expiré";
                                                $status_2 = 8;
                                        }
                                        elseif($amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                }

                                $is_complete_27 = 1;

                        }
                        else{
                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($this->request->getPost("Initial_expiration_25")))
                                {
                                        if($Force_26 == 1){
                                                $Intitule_8 = "Licence remise en force";
                                                $status_2 = 6;
                                        }
                                        else{
                                                if($amount_remaining == 0){
                                                        if($is_complete_27 == 1){
                                                                $Intitule_8 = "Licence est apuré";
                                                                $status_2 = 7;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Licence est total";
                                                                $status_2 = 9;
                                                        }
                                                }
                                                elseif($amount_remaining > 0 && $Amountdue_23 > $amount_remaining){
                                                        $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                        $status_2 = 4;
                                                }
                                                elseif($this->request->getPost("Date_extension_32") != "" && $this->request->getPost("Date_extension_32") != "0000-00-00" && ($amount_remaining > 0 || $is_complete_27 == 0)){
                                                        $Intitule_8 = "Licence renouvellé avec succès";
                                                        $status_2 = 5;
                                                }
                                                else{
                                                        $Intitule_8 = "Licence en cours de validité";
                                                        $status_2 = 2;
                                                }
                                        }
                                }
                                else{
                                        if($is_complete_27 == 1 && $amount_remaining == 0){
                                                $Intitule_8 = "Licence est apuré";
                                                $status_2 = 7;
                                        }
                                        elseif($is_complete_27 == 0 && $amount_remaining == 0){
                                                $Intitule_8 = "Licence incomplète, document(s) non présenté";
                                                $status_2 = 3;
                                        }
                                        elseif($amount_remaining > 0 && $is_complete_27 == 0){
                                                $Intitule_8 = "Licence expiré, paiement(s) non soldé";
                                                $status_2 = 8;
                                        }
                                }

                        }

                        $rdata = array();
                        $rdata['Date_1'] = $days = date("Y-m-d H:i:s");
                        $rdata['Status_2'] = $status_2;
                        $rdata['Account_3'] = $this->session->userdata["account_id"];
                        $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                        $rdata['Changer_6'] = 0;
                        $rdata['Compte_7 ']= $this->request->getPost("Compte_7");
                        $rdata['Devise_8'] = $this->request->getPost("Devise_8");
                        $rdata['Designation_9'] = $Designation_9 = $this->request->getPost("Designation_9");
                        $rdata['Cellphone_10'] = $this->request->getPost("Cellphone_10");
                        $rdata['Email_11'] = $this->request->getPost("Email_11");
                        $rdata['Nif_12'] = $this->request->getPost("Nif_12");
                        $rdata['Code_importers_13'] = $this->request->getPost("Code_importers_13");
                        $rdata['Date_initial_14'] = $this->request->getPost("Date_initial_14");
                        $rdata['Ref_declaration_15'] = $this->request->getPost("Ref_declaration_15");
                        $rdata['Ref_paiement_16'] = $this->request->getPost("Ref_paiement_16");
                        $rdata['Numero_importexport_18'] = $this->request->getPost("Numero_importexport_18");
                        $rdata['Category_20'] = $Category_20 = $this->request->getPost("Category_20");
                        $rdata['Prefinance_38'] = $Prefinance_38;
                        $rdata['AmountPrefinance_39'] = $AmountPrefinance_39;
                        $rdata['Devise_40'] = ($_POST['Devise_40'] != "")?$this->request->getPost("Devise_40"):Null;
                        $rdata['Merchandise_41'] = ($_POST['Merchandise_41'] != "")?$this->request->getPost("Merchandise_41"):Null;

                        /* ---- Amountpayed ----- */

                        if($Prefinance_38 != "T")
                        {
                                $rdata['Amountpaid_21']= str_replace(",",".",$this->request->getPost("Amountpayed"));
                                $rdata['Amountpaid_21'] = str_replace(' ','',$rdata['Amountpaid_21']);
                                $rdata['Amountpaid_21']  = $Amountpaid_21  = str_replace(',','.',$rdata['Amountpaid_21']);

                                $rdata['Devise_22'] = $this->request->getPost("Devise_22");

                                $rdata['Amountdue_23']  = $this->request->getPost("Amountdue_23");
                                $rdata['Amountdue_23'] = str_replace(' ','',$rdata['Amountdue_23']);
                                $rdata['Amountdue_23'] = $Amountdue_23 = str_replace(',','.',$rdata['Amountdue_23']);

                                $rdata['Devise_24'] = $Devise = $this->request->getPost("Devise_24");
                                $rdata['Initial_expiration_25'] = $this->request->getPost("Initial_expiration_25");
                                $rdata['Force_26'] = $Force_26;
                                $rdata['is_complete_27'] = $is_complete_27;

                                $rdata['Address_29'] = $Address_29 = $this->request->getPost("Address_29");
                                $rdata['Date_extension_32'] = $this->request->getPost("Date_extension_32");

                                $rdata['Amountremaining_33'] = $this->request->getPost("Amountremaining_33");
                                $rdata['Amountremaining_33'] = str_replace(' ','',$rdata['Amountremaining_33']);
                                $rdata['Amountremaining_33'] = $Amountremaining_33 = str_replace(',','.',$rdata['Amountremaining_33']);

                                $rdata['Devise_34'] = $this->request->getPost("Devise_34");
                                $rdata['Devise_34'] = $this->request->getPost("Devise_34");
                                $rdata['Licence_35'] = $this->request->getPost("Licence_35");

                                $input = array();

                                $input['Accounts'] = $_POST["Customer_accounts"];
                                $input['Accountnames'] = $_POST["Account_name"];
                                $input['Currency'] = $_POST["Currency_customer_accounts"];
                                $input['Date_paids'] = $_POST["Date_payments"];
                                $input['Amounts'] = $_POST["Amountpaids"];
                                $input['Camounts'] = $_POST["Currency_total_amounts"];
                                $input['Comments'] = $_POST["Comments"];
                                $input['Delays'] = $_POST["Document_delay"];
                                $input['Expirations'] = $_POST["Doc_expirations"];
                                $input['Status'] = $status;

                                $rdata['Results_36'] = json_encode($input);

                                $_array_amount_paid = $this->request->getPost("Amountpaids");
                                $totalpayed = 0;
                                foreach($_array_amount_paid as $value){
                                        $totalpayed += $value;
                                }

                                if($totalpayed > $Amountdue_23){
                                        $this->data["error"] = "Le montant payé ne doit pas être supérieur au montant total de la licence";
                                }
                        }

                        if($this->data["error"] == 200)
                        {
                                if($Id_0 == "")
                                {

                                        $Declarationid_7 = $this->licenceModel->save_elicense_declarations($rdata, $id);
                                        $Proofpayment_12 = array();

                                        foreach($files as $file)
                                        {
                                                $rdata = array();
                                                $rdata['Date_1'] = $days;
                                                $rdata['Status_2'] = 2;
                                                $rdata['Account_3'] = $this->session->userdata["account_id"];
                                                $rdata['Creator_4'] =  $this->session->userdata['user_id'];
                                                $rdata['Changer_6'] = 0;
                                                $rdata['Declarationid_7'] = $Declarationid_7;
                                                $rdata['Code_8'] =  $file;

                                                $this->licenceModel->save_elicense_documents($rdata, $id);
                                        }
                                }
                                else
                                {
                                        $licence = $this->licenceModel->get_licence_by_id($Id_0);
                                        unset($rdata["Date_1"]);
                                        $rdata['Changes_5'] = $days;
                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                        if($licence->Amountpaid_21 != $licence->Amountdue_23){
                                                if(!empty($this->request->getPost("Amountpaid_21"))){
                                                        $rdata['Amountpaid_21'] = ($licence->Amountpaid_21) + (str_replace(",",".",$this->request->getPost("Amountpaid_21")));
                                                }
                                        }
                                        else{
                                                if($Amountremaining_33 > 0){
                                                        $rdata['Amountpaid_21'] = $licence->Amountdue_23 - $Amountremaining_33;
                                                }
                                                else{
                                                        $rdata['Amountpaid_21'] = $licence->Amountdue_23;
                                                }
                                        }
                                        $Declarationid_7 = $this->licenceModel->save_elicense_declarations($rdata,$Id_0);

                                }

                                $declaration = $this->licenceModel->get_licence_by_id($Declarationid_7);
                                $Categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                                $this->data["files"] = $files = explode(",",$Categorie->Document_list_12);

                                $this->data['description'] = array();
                                foreach($files as $file)
                                {
                                        $this->data['description'][$file] = $this->licenceModel->get_description_document($file);
                                }

                                $prelevement = $this->seguceModel->get_licence_by_ref($declaration->Ref_paiement_16);
                                $NumLcc = $declaration->Licence_35;
                                $account_id = $this->session->userdata['account_id'];
                                $user_id = $this->session->userdata['user_id'];
                                $folder = ".drive/licence/notifications/".$account_id;
                                $Linkdocument_9 = $declaration->Id_0."_".$user_id."_".time().".pdf";
                                if (!is_dir($folder))
                                {
                                        mkdir($folder, 0755, true);
                                }

                                $status_docs_expiration = false;
                                if (isset($declaration->Results_36) && $declaration->Results_36 !=""):
                                        $paiements = json_decode($declaration->Results_36);
                                        foreach($paiements->Accounts as $key => $account){
                                                if(strtotime(date("Y-m-d")) > strtotime($paiements->Expirations->$key)){
                                                        $status_docs_expiration = true;
                                                }
                                        }
                                else:
                                        $paiements = array();
                                endif;

                                $Amountpaidoc = 0;

                                if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                        $Documents_37 = json_decode($declaration->Documents_37);
                                        foreach($Documents_37 as $item){
                                                foreach($item->Documents as $key => $document){

                                                        if($document == "FF"){
                                                                $Amountpaidoc += (float) $item->Amountpaid->$key;
                                                        }

                                                }
                                        }
                                endif;

                                if($Prefinance_38 != "T"){
                                        $this->data["status_docs_expiration"] = $status_docs_expiration;
                                        $this->data["creatime"] = date("Y-m-d H:i:s");
                                        $this->data["date"] = date("Y-m-d H:i:s");
                                        $this->data["Amountpaidoc"] = $Amountpaidoc;
                                        $this->data["Amountdue_23"] = $declaration->Amountdue_23;
                                        $this->data["Amountremaining_33"] = $declaration->Amountremaining_33;
                                        $this->data["Designation_9"] = $declaration->Designation_9;
                                        $this->data["Address_29"] = $declaration->Address_29;
                                        $this->data["Num_lcc"] = $NumLcc;
                                        $this->data["Title_8"] = $Categorie->Title_8;
                                        $this->data["Devise"] = $declaration->Devise_24;
                                        $this->data["Categorie"] = $declaration->Category_20;
                                        $this->data["elicense"] = $declaration;
                                        $this->data["data"] = $_POST;
                                        $this->data["status_libelle"] = $this->licenceModel->status[$declaration->Status_2];

                                        $html = view('\Modules\Eximtrade\Views\impression\_elicense_paiement', $this->data);
                                        $this->mpdf->AddPageByArray([
                                                'margin-left' => 10,
                                                'margin-right' => 10,
                                        ]);

                                        $this->mpdf->WriteHTML('', 1);
                                        $this->mpdf->WriteHTML($html, 2);
                                        $this->mpdf->Output($folder."/".$Linkdocument_9, 'F');

                                        $customer = $declaration->Designation_9;
                                        $email = $declaration->Email_11;
                                        if($email != ""){
                                                //$return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                                                //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);

                                                unlink(ROOTPATH . $folder."/".$Linkdocument_9);

                                                if(true)//$return
                                                {
                                                        echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                                }
                                                else
                                                {
                                                        echo json_encode(array("status" => 500,"message" => "Mail non envoyé"));
                                                }
                                        }
                                        else{
                                                echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                        }
                                }
                                else{
                                        echo json_encode(array("status" => 200, "id" => $Declarationid_7));
                                }
                        }
                        else{
                                echo json_encode(array("status" => 500,"message" => $this->data["error"]));
                        }
                }
                elseif ($obj == "customer")
                {
                        $Id_0 = (!empty($this->request->getPost("Id_0")))?$this->request->getPost("Id_0"):NULL;
                        $data = array();
                        if(is_null($Id_0)){
                                $data['Date_1'] = $date =  date("Y-m-d H:i:s");
                                $data['Makerid_4'] = $this->session->userdata['user_id'];
                        }
                        else{
                                $data['Changer_5'] = $date =  date("Y-m-d H:i:s");
                                $data['Changes_6'] = $this->session->userdata['user_id'];
                        }
                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Nif_7'] = $this->request->getPost("Nif_7");
                        $data['Designation_8'] = $this->request->getPost("Designation_8");
                        $data['Email_9'] = $this->request->getPost("Email_9");
                        $data['Phone_10'] = $this->request->getPost("Phone_10");
                        $data['Address_11'] = $this->request->getPost("Address_11");
                        $data['Legalstatus_12'] = $this->request->getPost("Legalstatus_12");
                        $data['Cbs_id_13'] = $this->request->getPost("Cbs_id_13");
                        $data['Codeclt_14'] = $this->request->getPost("Codeclt_14");

                        $id = $this->quitusModel->save_client($data,$Id_0);

                        if($id){
                                echo json_encode(array("code" => "E200","id" => $id));
                        }
                        else{
                                echo json_encode(array("code" => "E500",));
                        }
                }
                elseif ($obj == "sendmail")
                {
                        $Linkdocument_9 = $this->request->getPost("Linkdocument_9");
                        $Id_0 = $this->request->getPost("Id_0");
                        $Comment_17 = $this->request->getPost("Comment_17");

                        $declaration = $this->licenceModel->get_licence_info($Id_0);

                        $customer = $declaration->Designation_9;
                        $email = $declaration->Email_11;

                        //$return = $this->mail->send_mail($email, "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("a.tshiteya@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("christian.mola@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("j.amoyen@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("opd.kin@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("j.mikombe@tmb.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("support@ikwook.cd", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);
                        //$return = $this->mail->send_mail("donald.kulombota@ikwook.com", "Suivi de licence ".$customer, 'En attache, votre document.','suivi.licence@logiref.cd','Suivi licence', $bcc = false, $folder."/".$Linkdocument_9, $cc = null);

                        if(true)//$return
                        {
                                echo 200;
                        }
                        else
                        {
                                echo 500;
                        }
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if($obj == "prelevement"){
                        $Licence_7 = $this->request->getPost("Licence_7");
                        $licence = $this->seguceModel->get_licence_by_id($Licence_7);
                        if(!is_null($licence)){
                                echo json_encode(array("check" => true,"codeimport" => "","montantCIF" => ""));
                        }
                        else{
                                $provision = $this->seguceModel->get_provision_by_licence_id($Licence_7);
                                if(!is_null($provision)){
                                        echo json_encode(array("check" => true,"codeimport" => $provision->Codeimport_19,"montantCIF" => $provision->MontantCIF_8));
                                }
                                else{
                                        echo json_encode(array("check" => false,"codeimport" => "","montantCIF" => ""));
                                }
                        }
                }
                elseif ($obj == "elicense")
                {
                        if (isset($_POST['license']) && $_POST['license'] != "")
                        {
                                $declaration = $this->licenceModel->get_license_exists($_POST['license']);
                                if (!empty($declaration))
                                {
                                        if($declaration->Results_36 == "" && $declaration->Status_2 != 7){
                                                $response['code'] = '203';
                                                $response['Id_0'] = $declaration->Id_0;
                                                $response['Designation_9'] = $declaration->Designation_9;
                                                $response['Category_20'] = $declaration->Category_20;
                                                $response['Amountdue_23'] = $declaration->Amountdue_23;
                                                $response['Devise_24'] = $declaration->Devise_24;
                                                $response['Compte_7'] = $declaration->Compte_7;
                                                $response['Devise_8'] = $declaration->Devise_8;
                                                $response['Code_importers_13'] = $declaration->Code_importers_13;
                                                $response['Date_initial_14'] = $declaration->Date_initial_14;
                                                $response['Ref_paiement_16'] = $declaration->Ref_paiement_16;
                                                $response['Numero_importexport_18'] = $declaration->Numero_importexport_18;
                                                $response['Nif_12'] = $declaration->Nif_12;
                                                $response["Prefinance_38"] = $declaration->Prefinance_38;
                                                $response["AmountPrefinance_39"] = $declaration->AmountPrefinance_39;
                                                $response["Devise_40"] = $declaration->Devise_40;
                                                $response["Merchandise_41"] = $declaration->Merchandise_41;

                                                echo json_encode($response);
                                        }
                                        elseif($declaration->Status_2 == 7){

                                                $response['code'] = '402';
                                                echo json_encode($response);
                                                die;

                                        }
                                        else{
                                                $response['code'] = '401';
                                                echo json_encode($response);
                                                die;
                                        }
                                }
                                else
                                {
                                        $provision = $this->seguceModel->get_provisions_validated_by_licence($_POST['license']);

                                        if (!empty($provision))
                                        {
                                                $datime = new \DateTime($provision[0]->Changes_5);
                                                $response['code'] = '200';
                                                $response['Id_0'] = "";
                                                $response['Designation_9'] = $provision[0]->Designation_23;
                                                $response['Category_20'] = $provision[0]->CodeType_38;
                                                $response['Amountdue_23'] = $provision[0]->MontantCIF_8;
                                                $response['Devise_24'] = $provision[0]->Devise_9;
                                                $response['Compte_7'] = $provision[0]->Compte_21;
                                                $response['Devise_8'] = $provision[0]->Devise_22;
                                                $response['Code_importers_13'] = $provision[0]->Codeimport_19;
                                                $response['Date_initial_14'] = $datime->format("Y-m-d");
                                                $response['Ref_paiement_16'] = $provision[0]->Reference_20;
                                                $response['Numero_importexport_18'] = $provision[0]->Numero_importexport_39;
                                                $response['Nif_12'] = $provision[0]->Nif_24;
                                                $response["Prefinance_38"] = $provision[0]->Prefinance_43;
                                                $response["AmountPrefinance_39"] = $provision[0]->AmountPrefinance_41;
                                                $response["Devise_40"] = $provision[0]->Devise_42;
                                                $response["Merchandise_41"] = $provision[0]->Merchandise_40;
                                        }
                                        else
                                        {
                                                $licence = $this->seguceModel->get_licence_validated_by_id($_POST['license']);

                                                if (!empty($licence))
                                                {
                                                        $datime = new \DateTime($licence->Changes_5);
                                                        $response['code'] = '202';
                                                        $response['Id_0'] = "";
                                                        $response['Designation_9'] = $licence->Designation_22;
                                                        $response['Category_20'] = $licence->CodeType_26;
                                                        $response['Amountdue_23'] = $licence->MontantCIF_8;
                                                        $response['Devise_24'] = $licence->Devise_9;
                                                        $response['Compte_7'] = $licence->Compte_20;
                                                        $response['Devise_8'] = $licence->Devise_21;
                                                        $response['Code_importers_13'] = $licence->Codeimport_18;
                                                        $response['Date_initial_14'] = $datime->format("Y-m-d");
                                                        $response['Ref_paiement_16'] = $licence->Reference_19;
                                                        $response['Numero_importexport_18'] = $licence->Numero_importexport_27;
                                                        $response['Nif_12'] = $licence->Nif_23;
                                                        $response["Prefinance_38"] = "";
                                                        $response["AmountPrefinance_39"] = 0;
                                                        $response["Devise_40"] = "";
                                                        $response["Merchandise_41"] = "";

                                                }
                                                else
                                                {
                                                        $response['code'] = '204';
                                                        $response['Id_0'] = "";
                                                        $response['Designation_9'] = "";
                                                        $response['Category_20'] = "";
                                                        $response['Amountdue_23'] = "";
                                                        $response['Devise_24'] = "";
                                                        $response['Compte_7'] = "";
                                                        $response['Devise_8'] = "";
                                                        $response['Code_importers_13'] = "";
                                                        $response['Date_initial_14'] = "";
                                                        $response['Ref_paiement_16'] = "";
                                                        $response['Numero_importexport_18'] = "";
                                                        $response['Nif_12'] = "";
                                                        $response["Prefinance_38"] = "";
                                                        $response["AmountPrefinance_39"] = 0;
                                                        $response["Devise_40"] = "";
                                                        $response["Merchandise_41"] = "";
                                                }
                                        }

                                        echo json_encode($response);
                                }
                        }
                        else{
                                $provision = $this->seguceModel->get_provision_by_licence_id($_POST['NumLcc']);
                                if(!is_null($provision)){
                                        $declaration = $this->licenceModel->get_licence_by_ref($provision->Reference_20);
                                        if(!is_null($declaration)){
                                                echo json_encode(array(
                                                        "existing" => true,
                                                        "Id_0" => $declaration->Id_0,
                                                        "Designation_9" => $provision->Designation_23,
                                                        "Category_20" => $declaration->Category_20,
                                                        "Amountdue_23" => $provision->MontantCIF_8,
                                                        "Devise_24" => $provision->Devise_9,
                                                        "Compte_7" => $provision->Compte_21,
                                                        "Devise_8" => $provision->Devise_22,
                                                        "Nif_12" => $provision->Nif_24,
                                                        "Code_importers_13" => $provision->Codeimport_19,
                                                        "Date_initial_14" => $provision->Date_11,
                                                        "Ref_paiement_16" => $provision->Reference_20,
                                                        "Numero_importexport_18" => $provision->Numero_importexport_39,
                                                        "Email_11" => $declaration->Email_11,
                                                        "Cellphone_10" => $declaration->Cellphone_10,
                                                        "Address_29" => $declaration->Address_29,
                                                        "Date_paiement_30" => ($declaration->Date_paiement_30 != "0000-00-00")?$declaration->Date_paiement_30:"",
                                                        "Status_2" => $declaration->Status_2,
                                                        "is_complete_27" => $declaration->is_complete_27,
                                                        "Date_extension_32" => ($declaration->Date_extension_32 != "0000-00-00")?$declaration->Date_extension_32:"",
                                                        "Amountpaid_21" => $declaration->Amountpaid_21,
                                                        "Devise_22" => $declaration->Devise_22,
                                                        "Amountdue_23" => $declaration->Amountdue_23,
                                                        "Devise_24" => $declaration->Devise_24,
                                                        "Amountremaining_33" => $declaration->Amountremaining_33,
                                                        "Devise_34" => $declaration->Devise_34,
                                                        "Comment_31" => $declaration->Comment_31
                                                ));
                                        }
                                        else{
                                                echo json_encode(array(
                                                        "existing" => false,
                                                        "Designation_9" => $provision->Designation_23,
                                                        "Category_20" => $provision->CodeType_38,
                                                        "Amountdue_23" => $provision->MontantCIF_8,
                                                        "Devise_24" => $provision->Devise_9,
                                                        "Compte_7" => $provision->Compte_21,
                                                        "Devise_8" => $provision->Devise_22,
                                                        "Nif_12" => $provision->Nif_24,
                                                        "Code_importers_13" => $provision->Codeimport_19,
                                                        "Date_initial_14" => $provision->Date_11,
                                                        "Ref_paiement_16" => $provision->Reference_20,
                                                        "Numero_importexport_18" => $provision->Numero_importexport_39
                                                ));
                                        }
                                }
                                else{
                                        $licence = $this->seguceModel->get_licence_by_id($_POST['NumLcc']);
                                        if(!is_null($licence)){
                                                $declaration = $this->licenceModel->get_licence_by_ref($licence->Reference_19);
                                                if(!is_null($declaration)){
                                                        echo json_encode(array(
                                                                "existing" => true,
                                                                "Id_0" => $declaration->Id_0,
                                                                "Designation_9" => $licence->Designation_22,
                                                                "Category_20" => $declaration->Category_20,
                                                                "Amountdue_23" => $licence->MontantCIF_8,
                                                                "Devise_24" => $licence->Devise_9,
                                                                "Compte_7" => $licence->Compte_20,
                                                                "Devise_8" => $licence->Devise_21,
                                                                "Nif_12" => $licence->Nif_23,
                                                                "Code_importers_13" => $licence->Codeimport_18,
                                                                "Date_initial_14" => $licence->Date_10,
                                                                "Ref_paiement_16" => $licence->Reference_19,
                                                                "Numero_importexport_18" => $licence->Numero_importexport_27,
                                                                "Email_11" => $declaration->Email_11,
                                                                "Cellphone_10" => $declaration->Cellphone_10,
                                                                "Address_29" => $declaration->Address_29,
                                                                "Date_paiement_30" => ($declaration->Date_paiement_30 != "0000-00-00")?$declaration->Date_paiement_30:"",
                                                                "Status_2" => $declaration->Status_2,
                                                                "is_complete_27" => $declaration->is_complete_27,
                                                                "Date_extension_32" => ($declaration->Date_extension_32 != "0000-00-00")?$declaration->Date_extension_32:"",
                                                                "Amountpaid_21" => $declaration->Amountpaid_21,
                                                                "Devise_22" => $declaration->Devise_22,
                                                                "Amountdue_23" => $declaration->Amountdue_23,
                                                                "Devise_24" => $declaration->Devise_24,
                                                                "Amountremaining_33" => $declaration->Amountremaining_33,
                                                                "Devise_34" => $declaration->Devise_34,
                                                                "Comment_31" => $declaration->Comment_31
                                                        ));
                                                }
                                                else{
                                                        echo json_encode(array(
                                                                "existing" => false,
                                                                "Designation_9" => $licence->Designation_22,
                                                                "Category_20" => $licence->CodeType_26,
                                                                "Amountdue_23" => $licence->MontantCIF_8,
                                                                "Devise_24" => $licence->Devise_9,
                                                                "Compte_7" => $licence->Compte_20,
                                                                "Devise_8" => $licence->Devise_21,
                                                                "Nif_12" => $licence->Nif_23,
                                                                "Code_importers_13" => $licence->Codeimport_18,
                                                                "Date_initial_14" => $licence->Date_10,
                                                                "Ref_paiement_16" => $licence->Reference_19,
                                                                "Numero_importexport_18" => $licence->Numero_importexport_27
                                                        ));
                                                }
                                        }
                                        else{
                                                echo json_encode(array(
                                                        "existing" => false
                                                ));
                                        }
                                }
                        }

                }
                elseif($obj == "get_dateend_document")
                {
                        if (isset($_GET['Category']) && $_GET["Date_payment"] != "")
                        {
                                if(isset($_GET["Date_payment"]) && $_GET["Date_payment"] != ""):
                                        $date2 = new \DateTime($_GET["Date_payment"]);
                                endif;

                                $categorie = $this->licenceModel->get_categorie_by_object($_GET['Category']);
                                $delay = $categorie->Document_delay_11;

                                $response = array();

                                if ($_GET["Date_payment"] == "" || $_GET["Date_payment"] == "0000-00-00"):

                                        $response['delay'] = '';
                                        $response['dateend'] = '';
                                else:
                                        $dateend = $date2->modify("+$categorie->Document_delay_11 days")->format("Y-m-d");

                                        $response['delay'] = $delay;
                                        $response['dateend'] = $dateend;
                                endif;
                        }
                        else
                        {
                                $response['delay'] = '';
                                $response['dateend'] = '';
                        }

                        return json_encode($response);
                }
                elseif($obj == "treat_license_isys")
                {
                        $licenseIsysDDR = $this->licenceModel->get_licenses_isys_DDR();

                        foreach($licenseIsysDDR as $licenseVal)
                        {
                                $declaration = $this->licenceModel->get_license_exists($licenseVal->licence);

                                if(is_null($declaration))
                                {
                                        $arrayCodetypeIsys = explode("-",$licenseVal->license_id);
                                        $codetype_isys = $this->licenceModel->get_codetype_isys($licenseVal->license_type,end($arrayCodetypeIsys));
                                        $Category_20 = $codetype_isys->Codetype_1;
                                        if(!in_array($Category_20, array("IS","ES","RC")))
                                        {
                                                $Category_20 .= $codetype_isys->Licensetype_2;
                                        }

                                        $amount_paid = floatval($licenseVal->amount) - floatval($licenseVal->difference_amount);
                                        $amount_remaining = floatval($licenseVal->amount) - floatval($amount_paid);
                                        $amount = floatval($licenseVal->amount);
                                        $date = \DateTime::createFromFormat('d/m/Y', $licenseVal->expiry_date);
                                        $initial_expiration = $date->format("Y-m-d");
                                        $date = \DateTime::createFromFormat('d/m/Y', $licenseVal->validation_date);
                                        $initial_date = $date->format("Y-m-d");
                                        $remise_force = 0;

                                        if(in_array($Category_20,array("IS","ES","RC")))
                                        {

                                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                                {
                                                        if($amount_remaining == 0){
                                                                $Intitule_8 = "Licence est apuré";
                                                                $status_2 = 7;
                                                        }
                                                        elseif($amount_remaining > 0){
                                                                $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                                $status_2 = 4;
                                                        }
                                                        else{
                                                                $Intitule_8 = "Licence en cours de validité";
                                                                $status_2 = 2;
                                                        }
                                                }
                                                else{
                                                        if($amount_remaining > 0){
                                                                $Intitule_8 = "Licence est expiré";
                                                                $status_2 = 8;
                                                        }
                                                        elseif($amount_remaining == 0){
                                                                $Intitule_8 = "Licence est apuré";
                                                                $status_2 = 7;
                                                        }
                                                }

                                                $is_complete_27 = 1;

                                        }
                                        else
                                        {
                                                if(strtotime(date("Y-m-d H:i:s")) < strtotime($initial_expiration))
                                                {
                                                        if($remise_force == 1){
                                                                $Intitule_8 = "Licence remise en force";
                                                                $status_2 = 6;
                                                        }
                                                        else{
                                                                if($amount_remaining == 0){
                                                                        $Intitule_8 = "Licence est total";
                                                                        $status_2 = 9;
                                                                }
                                                                elseif($amount_remaining > 0 && $amount > $amount_remaining){
                                                                        $Intitule_8 = "Licence partielle, paiement(s) en attente";
                                                                        $status_2 = 4;
                                                                }
                                                                else{
                                                                        $Intitule_8 = "Licence en cours de validité";
                                                                        $status_2 = 2;
                                                                }
                                                        }
                                                }
                                                else{
                                                        if($amount_remaining == 0){
                                                                $Intitule_8 = "Licence incomplète, document(s) non présenté";
                                                                $status_2 = 3;
                                                        }
                                                        elseif($amount_remaining > 0){
                                                                $Intitule_8 = "Licence expiré, paiement(s) non soldé";
                                                                $status_2 = 8;
                                                        }
                                                }

                                                $is_complete_27 = 0;

                                        }

                                        $Categorie = $this->licenceModel->get_categorie_by_object($Category_20);
                                        $history_licence_isys = $this->licenceModel->licenses_history($licenseVal->license_id);
                                        $currency_mapping = $this->licenceModel->get_currency_mapping($licenseVal->currency);
                                        $currency_isys = $currency_mapping->Currency_2;
                                        $Results_36 = '';

                                        if(!is_null($Categorie))
                                        {
                                                if(count($history_licence_isys) > 0)
                                                {
                                                        $input = array();
                                                        $history_licence_isys = array_reverse($history_licence_isys);
                                                        $Customer_accounts = array();
                                                        $Account_name = array();
                                                        $Currency_customer_accounts = array();
                                                        $Date_payments = array();
                                                        $Amountpaids = array();
                                                        $Currency_total_amounts = array();
                                                        $Comments = array();
                                                        $Document_delay = array();
                                                        $Doc_expirations = array();
                                                        $status = array();
                                                        $increment = 1;
                                                        $remaining = $amount;

                                                        foreach($history_licence_isys as $history)
                                                        {
                                                                if($history->difference_amount != $remaining)
                                                                {
                                                                        $date = $date1 = new \DateTime($history->updated_date);

                                                                        $Customer_accounts[$increment] = "";
                                                                        $Account_name[$increment] = "";
                                                                        $Currency_customer_accounts[$increment] = $currency_isys;
                                                                        $Date_payments[$increment] = $date->format('Y-m-d');
                                                                        $Amountpaids[$increment] = $amountpaids = floatval($history->amount) - floatval($history->difference_amount);
                                                                        $Currency_total_amounts[$increment] = $currency_isys;
                                                                        $Comments[$increment] = "";
                                                                        $Document_delay[$increment] = $Categorie->Document_delay_11;
                                                                        $Doc_expirations[$increment] = $date1->modify("+$Categorie->Document_delay_11 days")->format("Y-m-d");
                                                                        $remaining -= $amountpaids;

                                                                        if ($remaining > 0) $status[$increment] = 4;
                                                                        if ($remaining == 0) $status[$increment] = 9;
                                                                        $increment++;
                                                                }
                                                        }

                                                        $input['Accounts'] = $Customer_accounts;
                                                        $input['Accountnames'] = $Account_name;
                                                        $input['Currency'] = $Currency_customer_accounts;
                                                        $input['Date_paids'] = $Date_payments;
                                                        $input['Amounts'] = $Amountpaids;
                                                        $input['Camounts'] = $Currency_total_amounts;
                                                        $input['Comments'] = $Comments;
                                                        $input['Delays'] = $Document_delay;
                                                        $input['Expirations'] = $Doc_expirations;
                                                        $input['Status'] = $status;

                                                        $Results_36 = json_encode($input);
                                                }

                                                $elicense = new \stdClass();
                                                $elicense->Id_0 = NULL;
                                                $elicense->Date_1 = gmdate('Y-m-d H:i:s');
                                                $elicense->Status_2 = $status_2;
                                                $elicense->Account_3 = $this->session->userdata["account_id"];
                                                $elicense->Creator_4 = $this->session->userdata['user_id'];
                                                $elicense->Changes_5 = 0;
                                                $elicense->Changer_6 = '';
                                                $elicense->Compte_7 = '';
                                                $elicense->Devise_8 = '';
                                                $elicense->Designation_9 = $licenseVal->customer_name;
                                                $elicense->Cellphone_10 = '';
                                                $elicense->Email_11 = '';
                                                $elicense->Nif_12 = '';
                                                $elicense->Code_importers_13 = $licenseVal->client_code;
                                                $elicense->Date_initial_14 = $initial_date;
                                                $elicense->Ref_declaration_15 = '';
                                                $elicense->Ref_paiement_16 = '';
                                                $elicense->Numero_nrc_17 = '';
                                                $elicense->Numero_importexport_18 = '';
                                                $elicense->Numero_validation_19 = '';
                                                $elicense->Category_20 = $Category_20;
                                                $elicense->Amountpaid_21 = $amount_paid;
                                                $elicense->Devise_22 = $currency_isys;
                                                $elicense->Amountdue_23 = $amount;
                                                $elicense->Devise_24 = $currency_isys;
                                                $elicense->Initial_expiration_25 = $initial_expiration;
                                                $elicense->Force_26 = $remise_force;
                                                $elicense->is_complete_27 = $is_complete_27;
                                                $elicense->Doc_expiration_28 = '';
                                                $elicense->Address_29 = '';
                                                $elicense->Date_paiement_30 = '';
                                                $elicense->Comment_31 = '';
                                                $elicense->Date_extension_32 = '';
                                                $elicense->Amountremaining_33 = $amount_remaining;
                                                $elicense->Devise_34 = $currency_isys;
                                                $elicense->Licence_35 = $licenseVal->license_id;
                                                $elicense->Results_36 = $Results_36;
                                                $elicense->Documents_37 = '';
                                                $elicense->Prefinance_38 = '';
                                                $elicense->AmountPrefinance_39 = 0;
                                                $elicense->Devise_40 = '';
                                                $elicense->Merchandise_41 = '';

                                                return $elicense;
                                        }
                                        else{
                                                return NULL;
                                        }
                                }
                        }
                }
                elseif($obj == "parseExcelDate")
                {
                        if ($data === null || $data === "") return null;

                        // Si c'est un nombre (date Excel)
                        if (is_numeric($data)) {
                                try {
                                        return \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($data);
                                } catch (\Throwable $e) {
                                        return null;
                                }
                        }

                        // Si c'est déjà un format date texte
                        $formats = ['d/m/Y', 'Y-m-d', 'm/d/Y', 'd-m-Y'];

                        foreach ($formats as $format) {
                                $dt = \DateTime::createFromFormat($format, $data);
                                if ($dt) return $dt->format('Y-m-d');
                        }

                        return null;
                }

        }
}
