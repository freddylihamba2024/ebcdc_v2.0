<?php

namespace Modules\Eximtrade\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Eximtrade\Models\DashboardsModel;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\EncaissementModel;

class Dashboards extends BaseController
{
        /*
         * Presentation: Gestion des tableaux de bord
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('seguce', 'menus', 'summary', 'overview', 'invoices');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'dashboards';
        public $core_banking;
        public $temenos;
        public $options;
        private $dashboardsModel;
        private $logirefModel = null;
        private $role = null;
        private $encaissementModel;
        private $dataModel;
        private $branchesModel;
        private $integrationModel;
        private $ratesModel;
        private $usersModel;
        private $licenceModel;
        private $mainModel;

        public function __construct()
        {
                parent::__construct();
                $this->temenos = new Temenos();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->dashboardsModel = new DashboardsModel();
                $this->logirefModel = new LogirefModel();
                $this->branchesModel = new BranchesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->dataModel = new DataModel();
                $this->integrationModel = new IntegrationModel();
                $this->ratesModel = new RatesModel();
                $this->usersModel = new UsersModel();
                $this->licenceModel = new LicenceModel();
                $this->mainModel = new MainModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Exchange_rates'])) {
                        $this->data("set_exchange_rates");
                }

                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {

                        return redirect()->to(base_url($this->module));
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                if ($_SESSION['Logiref_role'] == 1) {
                        echo view('layouts/layout_admin', $this->data);
                }
                else {
                        echo view('layouts/layout_main', $this->data);
                }
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {

                        if($needle == "overview")
                        {

                                if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') {

                                        if(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                                        {
                                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                        }
                                        else
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if(!isset($_SESSION['Exchange_rates']))
                                                {
                                                        $this->display("set_exchange_rates");
                                                }

                                                $this->data['sidebar'] = '';
                                                $this->data['subview'] = '\Modules\Eximtrade\Views\container';

                                                echo view('layouts/layout_main', $this->data);
                                        }
                                }

                        }
                        else
                        {
                                $this->index();

                        }

                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                ############################ Menu Operateur ################
                if ($obj == "invoices")
                {
                        if ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 6 || $_SESSION['Logiref_role'] == 7 || $_SESSION['Logiref_role'] == 8) 
                        {
                                $this->data['alerts'] = array();
                                $this->data['menus'] = $this->logirefModel->menus_invoices;

                                echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                        }
                }
                elseif ($obj == "seguce")
                {
                        ini_set('memory_limit', '1024M');

                        $functionalities = json_decode($_SESSION['userdata']['options'], true);

                        if(array_key_exists("eximtrade_license_monitoring",$functionalities['ALL']))
                        {
                                if ($_SESSION['Logiref_role'] == 4)
                                {
                                        $this->data['paiement_cdf'] = array();
                                        $this->data['paiement_usd'] = array();
                                        $this->data['paiement_regie'] = array();
                                        $this->data['paiement'] = array();
                                        $this->data['pie_situation_cdf'] = array();
                                        $this->data['pie_situation_usd'] = array();
                                        $this->data['right_side'] = $id;
                                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                                        $this->data['encaissements'] = array();

                                        $this->data['licence_expires'] = $this->licenceModel->get_licences_expires();
                                        $this->data['licences_encours'] = $this->licenceModel->get_licences_encours();
                                        $this->data['licences_enforce'] = $this->licenceModel->get_licences_enforce();
                                        $this->data['licences_apures'] = $this->licenceModel->get_licences_apures();

                                        $this->data['all_declarations'] = $this->licenceModel->get_all_declations();
                                        $this->data['licence_es'] = $this->licenceModel->get_licence_es();
                                        $this->data['licence_is'] = $this->licenceModel->get_licence_is();
                                        $this->data['licence_rc'] = $this->licenceModel->get_licence_rc();
                                        $this->data['licence_eb'] = $this->licenceModel->get_licence_eb();
                                        $this->data['licence_ib'] = $this->licenceModel->get_licence_ib();

                                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\administrator', $this->data);

                                }
                                else
                                {
                                        $this->data['commission'] = $this->encaissementModel->get_stats("commission");
                                        $this->data['penalties'] = $this->dataModel->get_penalites();
                                        $this->data['paiement'] = $this->encaissementModel->get_stats("paiement");
                                        $this->data['pie_commission'] = $this->data("pie-chart", $this->data['commission'], "commission");
                                        $this->data['pie_paiement'] = $this->data("pie-chart", $this->data['paiement'], "paiement");
                                        $this->data['guichets'] = $this->branchesModel->get_branches();

                                        $this->data['licence_expires'] = $this->licenceModel->get_licences_expires();
                                        $this->data['licences_encours'] = $this->licenceModel->get_licences_encours();
                                        $this->data['licences_enforce'] = $this->licenceModel->get_licences_enforce();
                                        $this->data['licences_apures'] = $this->licenceModel->get_licences_apures();

                                        $this->data['all_declarations'] = $this->licenceModel->get_all_declations();
                                        $this->data['licence_es'] = $this->licenceModel->get_licence_es();
                                        $this->data['licence_is'] = $this->licenceModel->get_licence_is();
                                        $this->data['licence_rc'] = $this->licenceModel->get_licence_rc();
                                        $this->data['licence_eb'] = $this->licenceModel->get_licence_eb();
                                        $this->data['licence_ib'] = $this->licenceModel->get_licence_ib();

                                        $data = array();

                                        foreach ($this->data['guichets'] as $row) {
                                                $data[$row->Id_0] = $this->encaissementModel->get_paiements_stats("guichet", $row->Id_0);
                                        }
                                        $this->data['data'] = $data;
                                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\validator', $this->data);
                                }
                        }
                        else
                        {
                                if ($_SESSION['Logiref_role'] == 4)
                                {
                                        return redirect()->to(base_url("eximtrade/seguce/set/provision"));
                                }
                                else
                                {
                                        return redirect()->to(base_url("eximtrade/reports/display/nvalidated"));
                                }
                        }
                }
                elseif($obj == "overview")
                {
                        if($_SESSION['Logiref_privileges'] != 0)
                        {

                                if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && in_array($_SESSION['Logiref_role'],[3,4]))
                                {
                                        $this->display("default_values_new_taux");
                                        $this->display("set_exchange_rates");

                                        $this->data['module'] = 'branch';
                                        echo view('\Modules\Branch\Views\rates\_taux', $this->data);
                                }
                                else
                                {
                                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                                        $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')])?$this->data['guichets'][$this->session->get('Logiref_guichet')]:"";
                                        $this->data['agence']= isset($this->data['agences'][$this->session->get('Logiref_agence')])?$this->data['agences'][$this->session->get('Logiref_agence')]:"";
                                        $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                                        $this->data['region'] = (!is_null($region))?$region->Nom_7:'';
                                        $this->data['role_user'] = (!empty($_SESSION['roles_banks']))?$_SESSION['roles_banks'][$this->session->get('Logiref_role')]:"";

                                        $this->data['paiement_cdf'] = $paiement_cdf = array();//$this->encaissementModel->get_stats("paiement_situation_cdf");
                                        $this->data['paiement_usd'] = $paiement_usd = array();//$this->encaissementModel->get_stats("paiement_situation_usd");
                                        $this->data['paiement_regie'] = array();//$this->encaissementModel->get_stats("paiement_situation_regie");
                                        $this->data['paiement'] = array();//$this->encaissementModel->get_stats("paiement");
                                        $this->data['pie_situation_cdf'] = array();//$this->data("pie-chart_operator", $paiement_cdf, "paiement_situation_cdf");
                                        $this->data['pie_situation_usd'] = array();//$this->data("pie-chart_operator", $paiement_usd, "paiement_situation_usd");
                                        $this->data['right_side']= $id;
                                        $this->data['beneficiaires'] = array();//$this->logirefModel->get_dropdown("services", $service=NULL);
                                        $this->data['encaissements'] = array();//$this->encaissementModel->get_paiements('penalities');
                                        $this->data['guichets'] = array();//$this->encaissementModel->get_dropdown("guichets");

                                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                        echo view('\Modules\Main\Views\overview', $this->data);
                                }
                        }
                        else
                        {
                                echo view('\Modules\Main\Views\overview', $this->data);
                        }
                }
                ############################ Menu Operateur ################
                elseif ($obj == "menus") {
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                ############################ Menu OCC Operateur ################
                if ($obj == "menu_occ") {
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                ########################### Token ISYS-Regies ###############
                elseif ($obj == "get_token_isys")
                {
                        set_time_limit(250);

                        $data = array();

                        if (isset($_SESSION['token_isys']) && $_SESSION['token_isys'] != "") {
                                $token_time = $_SESSION['token_time'];
                                $current_time = gmdate('H:i:s');

                                $token_time_1 = strtotime($token_time);
                                $token_time_2 = strtotime($current_time);

                                $diff = $token_time_2 - $token_time_1;

                                $hour = floor(date('H:i:s', $diff));

                                if ($hour <= 3) {
                                        $message = "The token exist";
                                } else {
                                        $informations = $this->integrationModel->get_isys_account_info();

                                        $data['login'] = $informations->Login_7;
                                        $data['password'] = $informations->Password_8;

                                        $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");

                                        //$url = base_url('api/endpoints/logiref/login.php');
                                        //$this->load->library('curl');
                                        //$this->curl->create($url);
                                        //$this->curl->post($data);

                                        //$response = $this->curl->execute();

                                        //if($response!=NULL)
                                        //{
                                        //$message = " Login to isys_regie successful";
                                        //$this->data("set_log", $message, "isys");

                                        //$_SESSION['token_isys'] = $response;
                                        //$_SESSION['token_time'] = gmdate('H:i:s');


                                        //}
                                }
                        }
                        else {
                                $informations = $this->integrationModel->get_isys_account_info();

                                $data['login'] = $informations->Login_7;
                                $data['password'] = $informations->Password_8;

                                $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");

                                //$url = base_url('api/endpoints/logiref/login.php');
                                //$this->load->library('curl');
                                //$this->curl->create($url);
                                //$this->curl->post($data);

                                //$response = $this->curl->execute();

                                //if($response!=NULL)
                                //{
                                //$_SESSION['token_isys'] = $response;
                                //$_SESSION['token_time'] = gmdate('H:i:s');

                                //$this->save('token_isys', $response);
                                //}
                        }
                }
                elseif ($obj == "set_exchange_rates")
                {
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];
                        # Retrieve options configured based on the bank connected
                        if (isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0')
                        {
                                if (isset($this->options['ALL']['auto-fetch-exchange-rate']))
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Initialization
                                        * ------------------------------------------------
                                        */

                                        $usd = '';
                                        $pound = '';
                                        $eur = '';
                                        $rand = '';

                                        $data['from_currency'] = 'USD';
                                        $data['to_currency'] = 'CDF';
                                        $data['type'] = 'TTB';
                                        $data['language'] = 'P';

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (property_exists($this, $core_banking) && method_exists($this->{$core_banking}, 'get_exchange_rate'))
                                        {
                                                $return = $this->{$core_banking}->get_exchange_rate($data);

                                                $return = json_decode($return, true);

                                                if($return['code'] == '200')
                                                {
                                                        if (isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                                        {
                                                                if($core_banking == 'bsqr')
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $usd;
                                                                        $_POST['rand'] = "";
                                                                        $_POST['pound'] = "";
                                                                }
                                                                else
                                                                {
                                                                        $usd = $return['exchange_rate'];

                                                                        $data['from_currency'] = 'EUR';
                                                                        $data['to_currency'] = 'CDF';

                                                                        $return = $this->{$core_banking}->get_exchange_rate($data);

                                                                        $return = json_decode($return, true);

                                                                        $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = "";
                                                                        $_POST['pound'] = "";
                                                                }

                                                                $this->save('taux');

                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                        elseif (isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                                        {
                                                                foreach ($return['ExchangeRateList'] as $row)
                                                                {
                                                                        if (isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                                        {
                                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                                        {
                                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                                        {
                                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                        elseif (isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                                        {
                                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                                        }
                                                                }

                                                                if ($usd != "" && $eur != "")
                                                                {
                                                                        $_POST['usd'] = $usd;
                                                                        $_POST['eur'] = $eur;
                                                                        $_POST['rand'] = $rand;
                                                                        $_POST['pound'] = $pound;

                                                                        $this->save('taux');

                                                                        $this->ratesModel->get_exchange_rates();
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $this->ratesModel->get_exchange_rates();
                                                        }
                                                }
                                                else{
                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                        else
                                        {
                                                $this->ratesModel->get_exchange_rates();
                                        }
                                }
                        }
                }
                # Exchange rates
                #
                ################################################################################
                elseif($obj == "default_values_new_taux")
                {

                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                if(!empty($bank['Dollar_4'])){
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                        $this->data['id'] = $bank['Id_0'];
                                        $this->data['key'] = (!empty($bank['Id_2']))?$bank['Id_2']:'';
                                        $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['bank'] = $bank;
                                }
                        }

                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                if(!empty($bank['Dollar_4'])){
                                        $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                        if($bank['Checkerid_11']==0): 
                                                $this->data['id'] = $bank['Id_0']; 
                                        else :
                                                $this->data['id'] = ''; 
                                                $this->data['reset'] = 1; 
                                        endif;

                                        $this->data['bank'] = $bank;
                                }
                        }

                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                if(!empty($bank['Dollar_4'])){
                                        $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                        $this->data['usd'] = $bank['Dollar_4'];
                                        $this->data['eur'] = $bank['Euro_5'];
                                        $this->data['rand'] = $bank['Rand_6'];
                                        $this->data['pound'] = $bank['Pound_7'];
                                        $this->data['bank'] = $bank;
                                        $this->data['id'] = '';
                                }
                        }

                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';

                        }

                        $this->data['action'] = '...';

                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {

                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';

                        }

                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {

                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';

                        }

                        elseif($_SESSION['Logiref_role']==4)
                        {

                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')

                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';

                        }
                }
                #Default
                elseif ($obj == "deny") {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Eximtrade\Views\\' . $this->lang . '_denial', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == 'taux') {
                        $dollar = str_replace(' ', '', $_POST['usd']);
                        $dollar = str_replace(',', '.', $dollar);

                        if ($_POST['eur'] != "") {
                                $euro = str_replace(' ', '', $_POST['eur']);
                                $euro = str_replace(',', '.', $euro);
                                $data['Euro_5']     =   $euro;
                        }

                        $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                        $data['Status_2']   =   1;
                        $data['Account_3']  =   $this->session->userdata['account_id'];
                        $data['Dollar_4']   =   $dollar;
                        $data['Agence_8']   =   $_SESSION['Logiref_agence'];
                        $data['Day_9']      =   gmdate('Y-m-d');
                        $data['Checkerid_11'] = '0001';
                        $data['Makerid_10'] = '0002';

                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');

                        $cid = $this->ratesModel->save_taux($data, NULL);

                        if ($cid) {
                                echo $cid;
                        }
                }
                elseif ($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if ($obj == "set_privilegies") {
                        $this->usersModel->get_privilegies();
                }
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif ($obj == "set_exchange_rates") {
                        $this->ratesModel->get_exchange_rates();

                        if (!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates'] == '0') {
                                $this->ratesModel->get_exchange_rates();
                        }
                }

                # Exchange rates
                #
                ################################################################################
                elseif ($obj == "default_values_new_taux") {
                        if (isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0) {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['seguce'] = $bank['Seguce_12'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        } elseif (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0) {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['seguce'] = $bank['Seguce_12'];
                                if ($bank['Checkerid_11'] == 0) :
                                        $this->data['id'] = $bank['Id_0'];
                                else :
                                        $this->data['id'] = '';
                                        $this->data['reset'] = 1;
                                endif;

                                $this->data['bank'] = $bank;
                        } elseif (isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0) {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['seguce'] = $bank['Seguce_12'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        } else {
                                $this->data['msg'] =  '<div class="alert alert-warning">Le taux de la BCC n\'est pas disponible veuillez publier un taux !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['seguce'] =  0.0;
                                $this->data['id'] = '';
                        }

                        $this->data['action'] = '...';

                        if (isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 0) {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;

                        if ($_SESSION['Logiref_role'] == 3 && isset($_SESSION['Exchange_rates']) || $_SESSION['Makerid'] != $this->session->userdata['user_id'] && isset($_SESSION['Exchange_rates'])) {
                                $this->data['action'] = 'Confirmer';
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif ($_SESSION['Logiref_role'] == 4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 1) {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif ($_SESSION['Logiref_role'] == 4) {
                                if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')

                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }
                ################################################################################
                # Dashboard Pie chart
                ################################################################################
                if ($obj == "pie-chart") {
                        if ($arg == 'commission') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00C6F3",highlight:"green"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats[2] . ',label:"CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats[3] . ',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats[1] . ',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats[4] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                } elseif ($obj == "pie-chart_operator") {
                        if ($arg == 'paiement_situation_cdf') {
                                $stats = $data;
                                //var_dump($stats); die;
                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" CDF",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        } elseif ($arg == 'paiement_situation_usd') {
                                $stats = $data;

                                $datas = '
                                                {value:' . $stats['unvalidated'] . ',label:" USD",color:"#ffa500",highlight:"aqua"},
                                                {value:' . $stats['validated'] . ',label:" USD",color:"#00b461",highlight:"aqua"},
                                                {value:' . $stats['reversed'] . ',label:" USD",color:"#00bfff",highlight:"aqua"},
                                                {value:' . $stats['none'] . ',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                return $datas;
                        }
                } 
                elseif ($obj == "OBJ ") {

                } 
                elseif ($obj == "OBJ ") {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
