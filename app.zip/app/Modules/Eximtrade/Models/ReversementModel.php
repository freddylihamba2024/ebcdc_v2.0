<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Main;

class ReversementModel extends MY_Main {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_paiements_to_reverse($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		#Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                #Restriction
                if($this->session->get('Logiref_role')==3) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                
                #Filtre de recuperation
                if(isset($_POST['paiements']) && $_POST['paiements'] !=""):
                
                        $data1 = implode(",", $_POST['paiements']);
                        $st .= " AND Status_2 !='0' AND Id_0 IN (".$data1.") ";
                endif;
                
                if(isset($_POST['bulletins']) && $_POST['bulletins'] !=""):
                    
                        $data2 = implode(",", $_POST['bulletins']);
                        
                        if(!isset($_POST['paiements'])) $st .= " AND (Status_2 !='0' AND Sydonia_44 IN (".$data2.")) ";
                        
                        else $st .= " OR (Status_2 !='0' AND Sydonia_44 IN (".$data2.")) ";
                       
                endif;
                
                if(isset($_POST['prepayments']) && $_POST['prepayments'] !=""):
                        
                      
                        $data2 = implode(",", $_POST['prepayments']);
                        
                        if(!isset($_POST['paiements']) && !isset($_POST['bulletins'])) $st .= " AND (Status_2 !='0' AND Sydonia_49 IN (".$data2.")) ";
                        
                        else $st .= " OR (Status_2 !='0' AND Sydonia_49 IN (".$data2.")) ";
                        
                endif;
                
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function update_payment_tresor($data, $ids) {
                $this->db->where("logiref_paiements_tresor.Id_0 IN (".$ids.")");
                return $this->db->update('logiref_paiements_tresor', $data);
        }
        
        
        
}