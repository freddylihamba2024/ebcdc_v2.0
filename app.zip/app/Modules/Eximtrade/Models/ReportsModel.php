<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class ReportsModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
	
        public $regies = array(
            ''=>'',
            'DGI'=>'DGI',
            'DGRAD'=>'DGRAD'
        );
        
        
        
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_validated_paiements_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND (Status_2 = 1 OR Status_2 = 3) AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
                $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' ";
                
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}

        public function get_validated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10>'0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
                
                #Restriction
                if($this->session->get('Logiref_role')==3) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' ";
                
                #Run
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=1 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44=0 AND Sydonia_49=0";
		#Restriction
                if($this->session->get('Logiref_role')==3) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResultArray();
	}
        
        public function get_paiements_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                
                #Restriction
                $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
		
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
        
	public function get_paiements_to_extourne($day)
	{
                $agence = $this->session->get('Logiref_guichet');
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2=1 OR Status_2=3)  AND Checkerid_10 !='0' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Date_1 LIKE '%" . $day . "%'";
                
                #Restriction
                $st .= " AND Guichet_21='".$agence."'";
                
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
	
        public function get_filter_paiements_to_extourne()
        {
                $user = $this->session->userdata['user_id'];
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'AND (Status_2=1 OR Status_2=3)  AND Checkerid_10 !='0' ";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";

                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->order_by('Date_1 DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_tresor($type=NULL, $data=NULL) 
        {
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44 = 0 ";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                
                #Run
                $user = $this->session->userdata['user_id'];
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_tresor_gu($type=NULL, $data=NULL) 
        {
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44 != 0 AND Status_2 != 0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                
                $user = $this->session->userdata['user_id'];
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_propres_gu($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata['user_id'];
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Agence_20='".$this->session->get('Logiref_agence')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' ";
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44 != 0 AND Status_2 != 0";
                
                #Query
                $builder = $this->db->table('logiref_paiements_propres')
                        ->select('logiref_paiements_propres.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata['user_id'];
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Sydonia_44 = '0' ";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Agence_20='".$this->session->get('Logiref_agence')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' AND Makerid_9 ='".$user."'";
                
                #Query
                $builder = $this->db->table('logiref_paiements_propres')
                        ->select('logiref_paiements_propres.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_fond_propres($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata['user_id'];
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND 	Beneficaire_15 != 'DGDA' AND Sydonia_44 =0";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Agence_20='".$this->session->get('Logiref_agence')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' AND Makerid_9 ='".$user."'";
                
                #Query
                $builder = $this->db->table('logiref_paiements_propres')
                        ->select('logiref_paiements_propres.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_fond_tresor($type=NULL, $data=NULL) 
        {
                $user = $this->session->userdata['user_id'];
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['Typerecette_17']) && $_POST['Typerecette_17']!='') $st .= " AND Typerecette_17='".$_POST['Typerecette_17']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                if(isset($_POST['guichet']) && $_POST['guichet']!='') $st .= " AND Guichet_21='".$_POST['guichet']."'";
                
                #Restriction
                if($this->session->get('Logiref_role')>2) $st .= " AND Agence_20='".$this->session->get('Logiref_agence')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' AND Makerid_9 ='".$user."'";
                
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        public function get_report_paiements($type=NULL, $data=NULL) 
        {
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD') AND Sydonia_44 =0";
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_filter_nvalidated_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_10='0' AND Status_2=5 AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                
                #Filtre d'affichage
                if(isset($_POST['Beneficaire_15']) && $_POST['Beneficaire_15']!='') $st .= " AND Beneficaire_15='".$_POST['Beneficaire_15']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Datevaleur_31 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
 
                #Restriction
                if($this->session->get('Logiref_role')==3) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."'";
                if($this->session->get('Logiref_role')==4) $st .= " AND Guichet_21='".$this->session->get('Logiref_guichet')."' AND Makerid_9 ='".$user."'";
		
                #Query
                $builder = $this->db->table('logiref_paiements_tresor')
                        ->select('logiref_paiements_tresor.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}

        public function get_invoicess_occ($data=NULL)
        {
                $user = $this->session->userdata['user_id'];

                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Invoice_54 != 0 AND Status_2 != 0";

                #Filtre d'affichage
                if(isset($data['Typerecette_17']) && $data['Typerecette_17']!='') $st .= " AND Typerecette_17='".$data['Typerecette_17']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Query
                $builder = $this->db->table('logiref_paiements_propres')
                        ->select('logiref_paiements_propres.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }


        public function get_nvalidated_invoices()
        {
                $account = $_SESSION['userdata']['account_id'] ?? "";
                $guichet = $_SESSION['Logiref_guichet'] ?? "";
                //$st = "(Status_2 ='1' OR Status_2 ='2' ) AND Account_3='".$account."' AND Guichet_50 = '".$guichet."'";
                $st = "(Status_2 ='1' OR Status_2 ='2' ) AND Account_3='".$account."'";

                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }



        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        
}
