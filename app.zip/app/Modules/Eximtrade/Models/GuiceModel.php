<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class GuiceModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';

        
        public $documents = array(
                    ''  => '',
                    '1' => 'POST DEDOUANEMENT', 
                    '2' => 'PRE DEDOUANEMENT',
                    '3' => 'DEDOUANEMENT', 
                    '4' => 'LOGISTIQUE', 
                );
        
        public $recettes = array(
                    ''  => '',
                    'CTC' => 'Frais TVA', 
                    'CPB' => 'Frais BIVAC',
                    'CPO' => 'Frais OCC', 
                );
        
        public $status_provisions =  array(
            '0' => 'Annul&eacute;e',
            '1' => 'Epuiss&eacute;',
            '2' => 'Utilis&eacute;',
            '3'=>'Utilis&eacute; partiellement'
        );
        
        public $status_validate =  array(
            '0' => 'Annul&eacute;e',
            '1' => 'A valider',
            '2' => 'Valid&eacute;',
            '3' => 'Epuiss&eacute;',
            '4' => 'Utilis&eacute; partiellement',
            '5' => 'A regulariser',
        );
        
        public $color_provisions = array(
            '0' => 'label-cancelled',
            '1' => 'label-ongoing',
            '2' => 'label-completed',
            '3' => 'label-cancelled',
            '4' => 'label-upcoming',
            '5' => 'label-cancelled',
        );

        public $status_invoices =  array(
            '3' => 'Non acquitt&eacute;',
            '4' => 'Acquitt&eacute;',
        );
        
        public $color_invoices  = array(
            '3' => 'label-cancelled',
            '4' => 'label-completed',
        );

        public $modes = array(
            '' => '',
            '1' => 'Carte bancaire',
            '2' => 'Credoc',
            '3' => 'Transfert/Virement',
            '4' => 'Encaisssement documentaire',
            '5' => 'Esp&egrave;ce',
            '6' => 'Ch&egrave;que bancaire',
            '7' => 'Autres'
        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        

        public function get_invoices($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND Status_2 = '1' ";

                #Filtre d'affichage
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";

                $this->db->query('SET SESSION sql_mode =
                        REPLACE(REPLACE(REPLACE(
                        @@sql_mode,
                        "ONLY_FULL_GROUP_BY,", ""),
                        ",ONLY_FULL_GROUP_BY", ""),
                        "ONLY_FULL_GROUP_BY", "")');
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                        ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();

                return $builder->getResult();
        }

        public function get_invoice_by_reference($reference, $account_id)
        {
                $st = " Status_2 !='0' AND Account_3='".$account_id."' AND Reference_7 = '".$reference."' ";

                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();

                return $builder->getRow();
        }

        public function check_invoice()
        {
                $account = $_SESSION['userdata']['account_id'] ?? $_POST['Account'] ?? "";
                
                $st = " Account_3='" . $account . "'";
                
                if(isset($_POST['Ref'])) $st .= " AND Reference_7 ='".$_POST['Ref']."'";
                
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function check_invoices($data)
        {
                $st = " Account_3='" . ($data['Account'] ?? "") . "' AND Reference_7 ='".($data['Ref_invoice'] ?? "")."' ";
                
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_paiement_invoice($id = NULL) 
        {
                if ($id != NULL) 
                {
                        $acountid = $_SESSION['userdata']['account_id'] ?? "";
                        $this->set_table('logiref_integration_seguce I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(['Id_0' => $id, 'Account_3'=> $acountid], TRUE);
                }
        }

        public function get_unvalidated_invoice_by_id($id, $account_id = NULL)
        {
                $account = $_SESSION['userdata']['account_id'] ?? $account_id ?? "";
                $st = "Account_3='".$account."' AND Id_0 = '".$id."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }

        public function get_instructions_invoice($id, $account_id = NULL)
        {
                $account =  $_SESSION['userdata']['account_id'] ?? $account_id ?? "";
                $st = "Status_2 !=0 AND  Account_3='" . $account . "' AND Paiementid_4 ='" . $id . "' AND Priority_24='0'";
                
                $query = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }

        public function get_invoice_by_id($ref)
        {
                $this->set_table('logiref_integration_seguce I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(['Reference_7' => $ref], TRUE);
        }

        public function update_invoice($data, $ids)
        {
                $builder = $this->db->table("logiref_integration_seguce")
                        ->where("logiref_integration_seguce.Id_0 IN (".$ids.")")
                        ->update($data);
                return $builder;
        }

        function generate_unique_reference() 
        {
                $datetimePart = date('Hisdmy');
                $randomPart = substr(bin2hex(random_bytes(2)), 0, 4);
                $uniqueReference = $datetimePart . $randomPart;

                return $uniqueReference;
        }

}