<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class PrepaymentsModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        public $ackmessages =  array(
            'OK'=>'Cl&ocirc;turer la transaction',
            'KO'=>'Paiement non valid&eacute;',
            ''=>''
        );
        public $declaration_ackmessages =  array(
            'OK'=>'Cl&ocirc;turer la transaction',
            'KO'=>'D&eacute;claration non valid&eacute;e',
            ''=>''
        );
        
        public $prepayments_status_color = array(
            '1'=>'label-upcoming',
            '2' => 'label-ongoing',
            '3' => 'label-completed',
            '4' => 'label-completed',
            '5' => 'label-muted'
        );
        
        public $prepayments_status = array(
            '1'=> 'Nouveau paiement',
            '2' => 'En attente de validation',
            '3' => 'Paiement valid&eacute;',
            '4' => 'Transaction cl&ocirc;r&eacute;e',
            '5' => 'Paiement rejet&eacute;'
        );
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_unvalidated_bls()
        {
            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $role = $this->session->get('Logiref_role');
            $builder = $this->db->table('logiref_sydonia_prepayments')
                    ->select('logiref_sydonia_prepayments.*')
                    ->where("logiref_sydonia_prepayments.Account_3 ='".$account."'")
                    ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                    ->where("logiref_sydonia_prepayments.Status_2 = '2'")
                    ->orderBy('Date_1','DESC')
                    ->get();
            return $builder->getResult();
        }
        
        public function get_unvalidated_integrate()
        {
            $account = $this->session->userdata['account_id'];
            $user = $this->session->userdata['user_id'];
            $role = $this->session->get('Logiref_role');
            $builder = $this->db->table('logiref_sydonia_prepayments')
                    ->select('logiref_sydonia_prepayments.*')
                    ->where("logiref_sydonia_prepayments.Account_3 ='".$account."'")
                    ->where("logiref_sydonia_prepayments.Status_2 = '7'")
                    ->orderBy('Date_1','DESC')
                    ->get();
            return $builder->getResult();
        }
        
        public function get_validated_bls_by_user($type=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $role = $this->session->get('Logiref_role');
                $user = $this->session->userdata['user_id'];
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where("(Status_2 = '3' OR Status_2 = '4') AND logiref_sydonia_prepayments.Account_3 ='".$account."'")
                        ->where("logiref_sydonia_prepayments.Creator_4 = '".$user."'")
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
		
        public function get_validated_bls($type=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $role = $this->session->get('Logiref_role');
                $user = $this->session->userdata['user_id'];
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where("logiref_sydonia_prepayments.Status_2 = '3' AND logiref_sydonia_prepayments.Account_3 ='".$account."'")
                        ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                        ->orderBy('Date_1','DESC')
                        ->get();
                if($type=='penalities')
                {
                        $builder = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where("logiref_sydonia_prepayments.Status_2 = '3' AND logiref_sydonia_prepayments.Account_3 ='".$account."'")
                                ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                                ->where("(Status_2 = '3' OR Status_2 = '2') AND DATEDIFF('".gmdate('Y-m-d H:i:s')."', Date_1) >= 1")
                                ->orderBy('Date_1','DESC')
                                ->get();
                }
                return $builder->getResult();
        }
	
       public function get_unvalidated_bls_to_extourne($day)
        {
                $account = $this->session->userdata['account_id'];
                $role = $this->session->get('Logiref_role');
                $user = $this->session->userdata['user_id'];
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where("logiref_sydonia_prepayments.Status_2 = '3' AND logiref_sydonia_prepayments.Account_3 ='".$account."' AND logiref_sydonia_prepayments.Date_1 LIKE '%" . $day . "%'")
                        ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                        ->orWhere("logiref_sydonia_prepayments.Status_2 = '4'")
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        public function get_filter_unvalidated_bls_to_extourne()
        {
                $role = $this->session->get('Logiref_role');
                $user = $this->session->userdata['user_id'];
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                if((isset($data['start']) && $data['start']!='') && (isset($data['end']) && $data['end']!='')) $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
		
        public function  get_prepayments_by_lot($ids)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='1' AND Creator_4 = '".$user."' AND Account_3='".$account."' AND Id_0 IN (".$ids.")";
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*, Id_0, COUNT(Id_0) as total')
                        ->groupBy('logiref_sydonia_prepayments.AccountRef_14')
                        ->where($st)
                        ->orderBy('total','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function  get_prepayments_by_reference($account_reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='1' AND Account_3='".$account."' AND AccountRef_14 = '".$account_reference."' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' ";
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_prepayments($status=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $agence = $this->session->get('Logiref_guichet');
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='".$account."' AND Agence_30 = '".$agence."'"; 
                if($status == "new")
                $st .= " AND Status_2 = 1";
                elseif($status == "nvalidated")
                $st .= " AND Status_2 = 2";
                elseif($status == "validated")
                $st .= " AND (Status_2 = 3 || Status_2 = 4)";
                
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*, Id_0, COUNT(Id_0) as total')
                        ->groupBy('logiref_sydonia_prepayments.AccountRef_14')
                        ->where($st)
                        ->orderBy('Id_0','Id_0 ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_prepayments_reports($status=NULL)
        {
                
                $account = $this->session->userdata['account_id'];
                $agence = $this->session->get('Logiref_guichet');
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='".$account."' AND Agence_30 = '".$agence."'"; 
                if($status == "new")
                $st .= " AND Status_2 = 1";
                elseif($status == "nvalidated")
                $st .= " AND Status_2 = 2";
                elseif($status == "validated")
                $st .= " AND (Status_2 = 3 || Status_2 = 4)";
                
                if(isset($_POST['service']) && $_POST['service'] != "") $st .= " AND Office_8 = '".$_POST['service']."' ";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND DATE(Date_1) BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where($st)
                        ->orderBy('Id_0','Id_0 ASC')
                        ->get();
                
                return $builder->getResult();
        }
        
        public function get_unvalidated_bls_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $this->session->get('Logiref_role');
                $builder = $this->db->table('logiref_sydonia_prepayments')
                        ->select('logiref_sydonia_prepayments.*')
                        ->where("logiref_sydonia_prepayments.Account_3 ='".$account."'")
                        ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                        ->orderBy('Date_1','DESC')
                        ->get();
                if($role > 2)
                {
                        $builder = $this->db->table('logiref_sydonia_prepayments')
                                ->select('logiref_sydonia_prepayments.*')
                                ->where("logiref_sydonia_prepayments.Account_3 ='".$account."'")
                                ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."'")
                                ->where("logiref_sydonia_prepayments.Agence_30 ='".$this->session->get('Logiref_guichet')."' AND logiref_sydonia_prepayments.Status_2 = '5'")
                                ->orderBy('Date_1','DESC')
                                ->get();
                }
                return $builder->getResult();
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        
        public function update_prepayement($data, $ids) 
        {
                $this->db->where("logiref_sydonia_prepayments.Id_0 IN (".$ids.")");
                return $this->db->update('logiref_sydonia_prepayments', $data);
        }
        
        
        
}