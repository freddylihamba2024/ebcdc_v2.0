<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Main;

class BranchesModel extends MY_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_guichet_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Nom_4 = '';
                        $obj->Agence_5 = '';
                        $obj->Province_6 = '';
                        $obj->Ville_7 = '';
                        $obj->Adresse_8 = '';
                        $obj->Observation_9 = '';
                        $obj->Code_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Validation_12 = '';
                        $obj->Option_14 = '0';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_guichets p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="guichets")
                {   
                        if($this->session->get('Logiref_groupe')=='banks')
                        {
                                $agence = $arg;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";
                                $builder = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($builder->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                                $st = "Status_2='1'";
                                $builder = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($builder->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="agences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $builder = $this->db->table('logiref_agences')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_agences($type=NULL)
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_agences')
                        ->select('logiref_agences.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_branches($type=NULL)
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Agence_5='" . $this->session->get('Logiref_agence') . "'";
                $builder = $this->db->table('logiref_guichets')
                        ->select('logiref_guichets.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_branche_by_service_dgda($service)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Bureau_15 LIKE '%".$service."%' ";
                $builder = $this->db->table('logiref_guichets')
                        ->select('logiref_guichets.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_guichets($type=NULL) 
        {
                if($type=='Guichet')
                {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' "; 
                        $builder = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $st = "Status_2='1' "; 
                        $builder = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                }
            
        }
        
        
        #Checks if an agency has already been created with the entered code
        public function get_code_exists($code = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_guichets ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Code_10 '=>$code), TRUE);
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_branche($data, $id) 
        {
                $this->set_table('logiref_guichets', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
}