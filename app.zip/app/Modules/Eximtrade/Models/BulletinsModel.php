<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class BulletinsModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME')
                                ->get();
                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResultArray();
	}
        
        public function  get_bulletins_by_lot($ids)
        {
                $account = $this->session->userdata['account_id'];
                $st = "Status_2!='0' AND Account_3='".$account."' AND Id_0 IN (".$ids.")";
                $builder = $this->db->table('logiref_integration_sydonia')
                        ->select('logiref_integration_sydonia.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function  get_bulletins_by_logiredid($ids)
        {
                $account = $this->session->userdata['account_id'];
                $st = "Status_2 !='0' AND Account_3='".$account."' AND Logirefid_34 = '".$ids."' ";
                $builder = $this->db->table('logiref_integration_sydonia')
                        ->select('logiref_integration_sydonia.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
}
