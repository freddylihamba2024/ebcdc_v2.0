<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;
use Modules\Services\Bsqr\Controllers\Bsqr;

class RatesModel extends MY_Transaction {

        /* Presentation:
         * Last update
         * By Glodi  on the 05.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_orderBy = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';


	public function __construct()
	{
		parent::__construct();
	}

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];

                if($item=="OBJECT NAME")
                {
                        $this->db->orderBy('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }

                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE);
                        $this->db->orderBy('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_all_taux($from = NULL, $to = NULL)
        {

                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !=0 ";
                
                
                if($from != '' && $from != NULL)
                {
                        $st .= " AND Date_1 BETWEEN '".$from."' AND '".$to."' ";
                }
                
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                
                $query = $this->db->table('logiref_taux')
                        ->select('logiref_taux.*')
                        ->where($st)
                        ->limit('100')
                        ->get();

                return $query->getResult();
        }
        
        public function get_taux($from = NULL, $to = NULL) 
        {
//                $month = gmdate('Y-m');
//                $this->_table_name = '';
//                $this->db->select('logiref_taux.*', 'logiref_taux.Id_0 DESC');
//                $this->db->from('logiref_taux');
//                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "'";
//                if($_SESSION['Logiref_role']>2)
//                {
//                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
//                }
//                
//                if($from != NULL && $to != NULL)
//                {
//                        $st .= " AND (Day_9 BETWEEN '" . $from . " AND  '" . $to . "')";
//                }
//                $this->db->where($st, NULL, FALSE);
//                $this->db->where("DATE_FORMAT(Day_9,'%Y-%m')", $month);
//                $this->db->orderBy('logiref_taux.Id_0 DESC');
//                $this->db->limit('500');
//                return $this->get_all();
                
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "'";
                
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                if($from != NULL && $to != NULL)
                {
                        $st .= " AND (Day_9 BETWEEN '" . $from . " AND  '" . $to . "')";
                }
                
                $query = $this->db->table('logiref_taux')
                        ->select('logiref_taux.*')
                        ->where($st)
                        ->limit('500')
                        ->get();
                return $query->getResult();
        }

        public function get_exchange_rates($bank=null)
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $day = gmdate('Y-m-d');
                $agence = '';

                if($bank=="sofibanque")
                {
                        $data_to_send['from_currency']='USD';
                        $data_to_send['to_currency']="CDF";
                        $bsqr = new Bsqr();

                        $response=$bsqr->get_exchange_rate($data_to_send);
                        $return=json_decode($response,true);

                        if(isset($return['code']) && $return['code']=='200')
                        {

                                $taux['Dollar_4']=$return['exchange_rate'];

                                $_SESSION['Bank_rates']=json_encode($taux);
                        }
                        else
                        {
                                $_SESSION['Bank_rates']="";
                        }
                }
                else
                {
                        $db = \Config\Database::connect('ikwook_logiref_main');
                        $privilegy = $db->table('logiref_users')
                                ->where('Account_3',$account_id)
                                ->where('Userid_13',$user_id)
                                ->get()
                                ->getRow();

                        if(!is_null($privilegy)) $agence = $privilegy->Agence_7;

                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Day_9='" . $day. "' AND Agence_8='" . $agence. "'";

                        $query = $this->db->table('logiref_taux')
                                ->select('logiref_taux.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                        $results = $query->getResult();

                        if(!empty($results))
                        {
                                $_SESSION['Bcc_rates'] = 0;
                                $_SESSION['Bank_rates'] = 0;
                                $_SESSION['Bank_rates_not_validated'] = 0;
                                $_SESSION['Exchange_rates'] = 0;

                                foreach ($results as $row)
                                {
                                        //Données BCC
                                        if($row->Account_3==0 && $row->Makerid_10==0 && $row->Checkerid_11==0)
                                        {
                                                $_SESSION['Bcc_rates'] = json_encode($row);
                                        }
                                        elseif($row->Account_3 == $account_id)
                                        {
                                                if($row->Checkerid_11 == 0)
                                                {
                                                        $_SESSION['Exchange_rates'] = 1;
                                                        $_SESSION['Bank_rates_not_validated'] = json_encode($row);
                                                }
                                                else
                                                {
                                                        $_SESSION['Bank_rates'] = json_encode($row);
                                                        $_SESSION['Bank_rates_not_validated'] = 0;
                                                        $_SESSION['Exchange_rates'] = 2;
                                                }
                                        }
                                }
                        }
                        else
                        {
                                $_SESSION['Exchange_rates'] = 0;
                        }

                }

                return true;
        }

        public function get_taux_by_filter($agence = NULL, $date_start = NULL, $date_end = NULL)
        {
                if(!empty($agence) || !empty($date_start) || !empty($date_end))
                {
                        if(!empty($agence) && !empty($date_start) && !empty($date_end))
                        {
                                $st = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " AND Agence_8 ='".$agence."'";

                                if($date_start != '' && $date_start != NULL)
                                {
                                        //$date_start = date('Y-m-d', strtotime($date_start). '+1 days');
                                        $date_start_timestamp = strtotime($date_start);
                                        $date_start_timestamp = strtotime('+1 days', $date_start_timestamp);
                                        $date_start = date('Y-m-d', $date_start_timestamp);
                                        $st .= " AND Day_9 BETWEEN '".$date_start."' AND '".$date_start."' ";
                                }
                                
                                $query = $this->db->table('logiref_taux')
                                ->select('logiref_taux.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                        }
                        elseif (!empty($agence)) 
                        {
                                $st = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " AND Agence_8 ='".$agence."'";
                                
                                $query = $this->db->table('logiref_taux')
                                ->select('logiref_taux.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                        }
                        elseif (!empty($date_start) && !empty($date_end)) 
                        {
                                $st = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " ";
                                
                                if($date_start != '' && $date_start != NULL)
                                {
                                        //$date_start = date('Y-m-d', strtotime($date_start). '+1 days');
                                        $date_start_timestamp = strtotime($date_start);
                                        $date_start_timestamp = strtotime('+1 days', $date_start_timestamp);
                                        $date_start = date('Y-m-d', $date_start_timestamp);
                                        $st .= " AND Day_9 BETWEEN '".$date_start."' AND '".$date_start."' ";
                                }
                                
                                $query = $this->db->table('logiref_taux')
                                ->select('logiref_taux.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                        }
                        
                        
                        return $query->getResult();
                }
            
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_taux($data, $id) {
                $this->set_table('logiref_taux', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }	
	public function save_objects_name($data, $id)
	{
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);                
	}
        
        
        
}