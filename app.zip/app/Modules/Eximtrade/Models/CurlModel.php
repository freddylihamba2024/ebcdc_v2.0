<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Main;
use App\Libraries\Curl;

class CurlModel extends MY_Main
{

        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';
        public $curl;


        public function __construct()
        {
                parent::__construct();
                $this->curl = new Curl();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        //LOGS 
        public function call_set_log($data, $type = NULL)
        {
                $url = $_SERVER["SERVER_NAME"] . $_SERVER["PHP_SELF"];
                $log['url'] = $url;
                $log['message'] = $data;
                $log['bank_name'] = $this->session->userdata['account_business'];

                if ($type == NULL) {
                        $url = base_url('api/logs/logiref/encaissement/log.php');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "sydonia") {
                        $url = base_url('api/logs/logiref/sydonia/log.php');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "isys") {
                        $url = base_url('api/logs/logiref/isys/log.php');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "quittance") {
                        $url = base_url('api/logs/logiref/quittance/log.php');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                $response = $this->curl->execute();
        }

        //DGI 
        public function call_dgi_declaration($data)
        {
                //Fonction a activer apres integration avec la DGI
                //Ou apres integration du Internet banking
                /* 
                $url = base_url('api/endpoints/declaration/declaration.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                $response = $this->curl->execute();
                */
                return NULL;
        }

        public function call_logirad($data)
        {
                //Fonction a activer apres integration avec la DGI
                //Ou apres integration du Internet banking
                /* 
                $url = base_url('api/endpoints/declaration/declaration.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
		$this->curl->option('SSL_VERIFYPEER',0);
		$this->curl->option('SSL_VERIFYHOST',0);
                $response = $this->curl->execute();
                */
                return NULL;
        }


        //DGRAD
        public function call_dgrad_notes($data)
        {
                $data['User'] = $this->session->userdata['user_id'];
                $data['Account'] = $this->session->userdata['account_id'];
                $data['Agence'] = $this->session->get('Logiref_guichet');
                $url = base_url('api/endpoints/logirad/checknote.php');

                $url = "http://10.34.1.37/api/endpoints/logirad/checknote.php";
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //DGDA
        public function call_dgda_declaration($data)
        {
                $response = $data;
                return $response;
        }

        //DGDA
        public function call_dgda_prepayments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $apidata['bank'] = (isset($encryption->codebank)) ? $encryption->codebank : '';
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Agence'] = $this->session->get('Logiref_guichet');

                $url = "http://10.34.1.37/api/endpoints/sydonia/prepaymentsList.php";
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_dgda_payments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $taux = json_decode($this->session->get('Bank_rates'), true);
                $taux = $taux['Dollar_4'];

                $apidata['guichet'] = $_POST['guichet'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['cGuichet'] = $_POST['cGuichet'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['designation'] = $_POST['designation'];
                $apidata['taux'] = $taux;
                $apidata['Logirefid'] = $_POST['Logirefid'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['qserie'] = $_POST['qserie'];
                $apidata['qnumber'] = $_POST['qnumber'];

                $url = "http://10.34.1.37/api/endpoints/sydonia/paymentsList.php";
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();

                return trim($response);
        }

        public function call_dgda_procurement($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $apidata['bank'] = (isset($encryption->codebank)) ? $encryption->codebank : '';
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['Office'] = $_POST['Office'];

                $url = base_url('api/endpoints/sydonia/prepaymentsList.php');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }

        //DGDA
        public function call_dgda_send_ack_prepayments($credentials)
        {
                $apidata = array();
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Account'] = $this->session->userdata['account_id'];

                $apidata['messageKey'] = $_POST['messageKey'];
                $apidata['codeTr'] = $_POST['codeTr'];

                $url = base_url('api/endpoints/sydonia/prepaymentsAck.php');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }

        //BANK
        public function call_bank_comptant($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/comptant.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_virement($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/virement.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_checkbalance($data)
        {
                $response = '';
                $url = base_url('api/endpoints/bank/tmb/check.balance.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_account_info($data)
        {

                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/tmb/account.info.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }


        //DGDA
        public function call_dgda_checkbl_credit($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = base_url('api/endpoints/sydonia/checkblcredit.php');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                $response = '';
                return trim($response);
        }
        public function call_dgda_checkbl($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = "http://10.34.1.37/api/endpoints/sydonia/checkbl.single.php";
                $this->curl->create($url);
                $this->curl->post($apidata);

                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);

                $response = $this->curl->execute();

                return trim($response);
        }

        public function call_dgda_check_batch($data)
        {
                $url = "http://10.34.1.37/api/endpoints/sydonia/check.batch.php";
                //$url = base_url('api/endpoints/sydonia/check.batch.php');
                $this->curl->create($url);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);

                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
        }
        //BANK
        public function call_bank_comptant_single($credentials)
        {
                if ($_POST['Taux'] == "") {
                        $taux = json_decode($this->session->get('Bank_rates'), true);
                        $taux = $taux['Dollar_4'];
                }

                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'];
                $apidata['Commission'] = $_POST['Commission'];
                $apidata['Devise_commission'] = $_POST['Devise_commission'];
                $apidata['Total_amount'] = $_POST['Total_amount'];
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['Taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux;
                $apidata['bank_account'] = isset($_POST['bank_account']) ? $_POST['bank_account'] : "";
                $apidata['Devise_account'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                $apidata['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                $url = "http://10.34.1.37/api/endpoints/sydonia/comptant.single.php";
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();

                return trim($response);
        }

        //BANK
        public function call_bank_comptant_batch($data)
        {
                $url = "http://10.34.1.37/api/endpoints/sydonia/comptant.batch.php";
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_batch_recover($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = $_POST;
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = $Amount;
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = "http://10.34.1.37/api/endpoints/sydonia/check.batch.recover.php";
                $this->curl->create($url);
                $this->curl->post($apidata);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_dgda_quittance($data)
        {
                $url = "http://10.34.1.37/api/endpoints/sydonia/quittance.single.php";
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return trim($response);
        }



        public function call_bank_licence_bcc($data)
        {
                $response = '';
                $url = base_url('api/endpoints/sydonia/declarationsList.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_regularization($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/regularize.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_reversepayment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/extourne.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_verification($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/check.event.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/reservation.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_verify_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/verification.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_cancel_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/cancel.reservation.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        ###################################################################################################################### METHOD OCC BIVAC ###############################################################################################################################################

        public function call_bank_virement_occ($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/virement.invoice.occ.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                //var_dump($response); die;

                return $response;
        }

        public function call_bank_provision_regularization($data)
        {
                set_time_limit(250);

                $url = base_url('api/endpoints/bank/tmb/regularize.provision.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_bank_regularization_invoice($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/regularize.invoice.occ.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();

                return $response;
        }

        public function call_bank_virement_provision($data)
        {
                set_time_limit(250);
                $url = 'api/endpoints/bank/tmb/virement.provision.occ.php';
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_bank_reverse_provision($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/extourne.provision.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_bank_reverse_invoice($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/tmb/extourne.invoice.occ.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $this->curl->option('SSL_VERIFYPEER', 0);
                $this->curl->option('SSL_VERIFYHOST', 0);
                $response = $this->curl->execute();
                return $response;
        }
}
