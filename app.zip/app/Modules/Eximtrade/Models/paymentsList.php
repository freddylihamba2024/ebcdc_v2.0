<?php 
        //header("Content-type: text/xml");
        set_time_limit(250);
        ini_set('default_socket_timeout', 5000);
        /*
         * Initialization
         * @Webservice + methods
        */
        require_once('../../classes/sydonia.inc');
        $account = $_POST['Account'];
        $obj = new sydoniaClass($account);
        /* Variables initialisation
         * From application
        */

        $usersydonia = $_POST['login'];
        $password = $_POST['password'];
        $bankCode = $_POST['guichet'];
        $bankagence = $_POST['Agence'];
        $cGuichet = $_POST['cGuichet'];
        $officeCode = $_POST['Office'];
        $user = $_POST['User'];
        $companyCode = $_POST['Nif'];
        $taux = $_POST['taux'];
        $designation = $_POST['designation'];
        $Logirefid = $_POST['Logirefid'];
        $lot = $_POST['Logirefid'];
        $mode = '5';
        $array_datedebut = explode("-", $_POST['dateDebut']);
        $array_datefin  = explode("-", $_POST['dateFin']);
        $dateDebut =  $array_datedebut[2].'/'.$array_datedebut[1].'/'.$array_datedebut[0];
        $dateFin = $array_datefin[2].'/'.$array_datefin[1].'/'.$array_datefin[0];
        $ids = array();
        $error_code = array(

            '42'=>'Code Banque non autoris? pour vous',
            '44'=>'Aucune quiitance trouv&acute;e',
        );

        $InputInfo  = new stdClass();
        $InputInfo->banque = $bankCode; 
        $InputInfo->bureau = $officeCode;
        $InputInfo->dateDebutQuittance = $dateDebut; 
        $InputInfo->dateFinQuittance  = $dateFin;
        $InputInfo->company  = $companyCode;



        $getPaymentList = new stdClass();
        $getPaymentList->inputInfo = $InputInfo;
        $checked = "E444";
        if($usersydonia != "" && $password != "")
        {
                $identifiants = array(
                    'login' =>$usersydonia,
                    'password' => $password
                );

                $client = $obj->init_ws("paymentsList", $identifiants);

                if($client == "E404"):

                    $return = $client;

                else:

                    $checked = $client->getPaymentList($getPaymentList);

                    if(isset($checked->paymentListResult->codResult)) $codResult = $checked->paymentListResult->codResult;
                    if(isset($checked->paymentListResult->errorCode)) $errorCode = $checked->paymentListResult->errorCode;

                    if(isset($checked->paymentListResult->declarationPaymentListResult) && $codResult === 0)
                    {

                        $receiptes = $checked->paymentListResult->declarationPaymentListResult;
                        //var_dump($receiptes); die;


                        if(is_array($receiptes) && count($receiptes) > 1):

                           foreach($receiptes as $receipte)
                           {

                                    if(isset($receipte->declarationsPaid))
                                    {

                                            $declarations = $receipte->declarationsPaid;

                                            if(is_array($declarations) && count($declarations) > 1)
                                            {

                                                    foreach($declarations as $declaration)
                                                    {
                                                            $results = new stdClass();
                                                            $results->DateLi = date("Y-m-d");
                                                            $results->receiptDate = $receipte->receiptDate;
                                                            $results->receiptSerial = $receipte->receiptSerial;
                                                            $results->receiptNumber = $receipte->receiptNumber;

                                                            $results->declarationsPaid = $declaration;
                                                            $results = json_encode($results);
                                                            $integration = date("Y-m-d h:s");
                                                            $printing = date("Y-m-d h:s");
                                                            $pdf  = '';
                                                            $error  = '0';
                                                            $commission = 0;
                                                            $devisecom = 'CDF';
                                                            $reference = '';
                                                            $Bl_24 = '';
                                                            $Moyen = '7';
                                                            $Quittance ='';
                                                            $Beneficiare ='DGDA';
                                                            $cDevise =  'CDF';
                                                            $cCompte = '';
                                                            $account_name = '';
                                                            $Type = '';

                                                            $assessmentSerial = $declaration->assessmentSerial;
                                                            $assessmentNumber = $declaration->assessmentNumber;
                                                            $year = $declaration->registrationYear;

                                                            $paymentMean ='';
                                                            $declarantCode='';


                                                            $total = $amount = $declaration->amountToBePaid;
                                                            unset($client);

                                                            $pid = $obj->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$amount, $year);

                                                            if($pid)
                                                            {
                                                                    $rid = $obj->save_paiement($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode, $bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference, $lot, $cGuichet, $total, $commission, $devisecom, $cCompte, $cDevise, $mode, $taux, $designation, $bankagence, $account_name, $Logirefid);
                                                                    if($rid != 0 || $rid != FALSE)
                                                                    {
                                                                            $ids[] = $rid;
                                                                    }
                                                                    else
                                                                    {
                                                                            $return = "E002"; 
                                                                    }
                                                            }

                                                    }

                                            }
                                            elseif(is_object($declarations) && $declarations != NULL)
                                            {

                                                    $results = new stdClass();
                                                    $results->DateLi = date("Y-m-d");
                                                    $results->receiptDate = $receipte->receiptDate;
                                                    $results->receiptSerial = $receipte->receiptSerial;
                                                    $results->receiptNumber = $receipte->receiptNumber;

                                                    $results->declarationsPaid = $declarations;
                                                    $results = json_encode($results);
                                                    $integration = date("Y-m-d h:s");
                                                    $printing = date("Y-m-d h:s");
                                                    $pdf  = '';
                                                    $error  = '0';
                                                    $commission = 0;
                                                    $devisecom = 'CDF';
                                                    $reference = '';
                                                    $Bl_24 = '';
                                                    $Moyen = '7';
                                                    $Quittance ='';
                                                    $Beneficiare ='DGDA';
                                                    $cDevise =  'CDF';
                                                    $cCompte = '';
                                                    $account_name = '';
                                                    $Type = '';

                                                    $assessmentSerial = $declarations->assessmentSerial;
                                                    $assessmentNumber = $declarations->assessmentNumber;
                                                    $year = $declarations->registrationYear;

                                                    $paymentMean ='';
                                                    $declarantCode='';


                                                    $total = $amount = $declarations->amountToBePaid;
                                                    unset($client);

                                                    $pid = $obj->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$amount, $year);
                                                    if($pid)
                                                    {
                                                            $rid = $obj->save_paiement($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode, $bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference, $lot, $cGuichet, $total, $commission, $devisecom, $cCompte, $cDevise, $mode, $taux, $designation, $bankagence, $account_name, $Logirefid);
                                                            if($rid != 0 || $rid != FALSE)
                                                            {
                                                                    $ids[] = $rid;
                                                            }
                                                            else
                                                            {
                                                                    $return = "E002"; 
                                                            }
                                                    }
                                                    else
                                                    {

                                                    }

                                            }

                                    }
                                    else
                                    {

                                    }

                            }

                            if(isset($ids) && count($ids) > 0)
                            {
                                    $return = implode(",",$ids);
                            }
                            else
                            {
                                    $return = "E501";
                            }

                        elseif(is_object($receiptes) && $receiptes != NULL):

                                if(isset($receiptes->declarationsPaid))
                                {

                                        $declarations = $receiptes->declarationsPaid;

                                        if(is_array($declarations) && count($declarations) > 1)
                                        {

                                                foreach($declarations as $declaration)
                                                {
                                                        $results = new stdClass();
                                                        $results->DateLi = date("Y-m-d");
                                                        $results->receiptDate = $receiptes->receiptDate;
                                                        $results->receiptSerial = $receiptes->receiptSerial;
                                                        $results->receiptNumber = $receiptes->receiptNumber;

                                                        $results->declarationsPaid = $declaration;
                                                        $results = json_encode($results);
                                                        $integration = date("Y-m-d h:s");
                                                        $printing = date("Y-m-d h:s");
                                                        $pdf  = '';
                                                        $error  = '0';
                                                        $commission = 0;
                                                        $devisecom = 'CDF';
                                                        $reference = '';
                                                        $Bl_24 = '';
                                                        $Moyen = '7';
                                                        $Quittance ='';
                                                        $Beneficiare ='DGDA';
                                                        $cDevise =  'CDF';
                                                        $cCompte = '';
                                                        $account_name = '';
                                                        $Type = '';

                                                        $assessmentSerial = $declaration->assessmentSerial;
                                                        $assessmentNumber = $declaration->assessmentNumber;
                                                        $year = $declaration->registrationYear;

                                                        $paymentMean ='10';
                                                        $declarantCode='';


                                                        $total = $amount = $declaration->amountToBePaid;
                                                        unset($client);

                                                        $pid = $obj->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$amount, $year);
                                                        if($pid)
                                                        {
                                                                $rid = $obj->save_paiement($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode, $bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference, $lot, $cGuichet, $total, $commission, $devisecom, $cCompte, $cDevise, $mode, $taux, $designation, $bankagence, $account_name, $Logirefid);
                                                                if($rid != 0 || $rid != FALSE)
                                                                {
                                                                        $ids[] = $rid;
                                                                }
                                                                else
                                                                {
                                                                        $return = "E002"; 
                                                                }
                                                        }


                                                }


                                        }
                                        elseif(is_object($declarations) && $declarations != NULL)
                                        {

                                                $results = new stdClass();
                                                $results->DateLi = date("Y-m-d");
                                                $results->receiptDate = $receiptes->receiptDate;
                                                $results->receiptSerial = $receiptes->receiptSerial;
                                                $results->receiptNumber = $receiptes->receiptNumber;

                                                $results->declarationsPaid = $declarations;
                                                $results = json_encode($results);
                                                $integration = date("Y-m-d h:s");
                                                $printing = date("Y-m-d h:s");
                                                $pdf  = '';
                                                $error  = '0';
                                                $commission = 0;
                                                $devisecom = 'CDF';
                                                $reference = '';
                                                $Bl_24 = '';
                                                $Moyen = '7';
                                                $Quittance ='';
                                                $Beneficiare ='DGDA';
                                                $cDevise =  'CDF';
                                                $cCompte = '';
                                                $account_name = '';
                                                $Type = '';

                                                $assessmentSerial = $declarations->assessmentSerial;
                                                $assessmentNumber = $declarations->assessmentNumber;
                                                $year = $declarations->registrationYear;

                                                $paymentMean ='';
                                                $declarantCode='';


                                                $total = $amount = $declarations->amountToBePaid;
                                                unset($client);

                                                $pid = $obj->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$amount, $year);
                                                if($pid)
                                                {
                                                        $rid = $obj->save_paiement($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode, $bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference, $lot, $cGuichet, $total, $commission, $devisecom, $cCompte, $cDevise, $mode, $taux, $designation, $bankagence, $account_name, $Logirefid);
                                                        if($rid != 0 || $rid != FALSE)
                                                        {
                                                                $ids[] = $rid;
                                                        }
                                                        else
                                                        {
                                                                $return = "E002"; 
                                                        }
                                                }
                                                else
                                                {

                                                }

                                        }

                                }
                                else
                                {

                                }

                                if(isset($ids) && count($ids) > 0)
                                {
                                        $return = implode(",",$ids);
                                }
                                else
                                {
                                        $return = "E501";
                                }

                        else:
                                $return = "E501";
                        endif;


                    }
                    else if(isset($error_code[$errorCode]))
                    {
                            $return = "E".$errorCode;
                    }
                    else
                    {
                            $return = "E514";
                    }


                endif;
        }
        else
        {
                $return  = "E000";
        }

        //Return
        echo $return;

        //Save logs
        $log_request = var_export($getPaymentList, true);
        $filename = $bankCode."_request";
        $obj->save_log($log_request, $filename);

        $log_response = var_export($checked, true);
        $filename = $bankCode."_response";
        $obj->save_log($log_response, $filename);
?>