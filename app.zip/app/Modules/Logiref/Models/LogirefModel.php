<?php

        namespace Modules\Logiref\Models;

        use stdClass;
        use App\Models\MY_Main;

        class LogirefModel extends MY_Main
        {
                /* Presentation: 
                * Last update
                * By
                *  *************************************************************************************************************************SECTION 1
                */

                /*
                * Protected and public variables 
                * Use: forms validation constraintes, dropdowns static array, contextual variable etc
                */
                protected $_table_name = '';
                protected $_primary_key = '';
                protected $_order_by = '';
                protected $_timestamps = FALSE;
                protected $_date_created = '';
                protected $_date_modified = '';


                public $documents = array(
                        '1' => 'NOTE DE PERCEPTION',
                        '2' => 'QUITTANCE',
                        '3' => 'BULLETIN DE LIQUIDATION',
                        '4' => 'NOTE DE VERSEMENT',
                        '5' => 'DECLARATION'
                );
                public $devises = array(
                        '' => '',
                        'CDF' => 'CDF',
                        'USD' => 'USD',
                        // 'EUR' => 'EUR', 
                        // 'ZAF' => 'ZAF'
                );
                public $devises2 = array(
                        '' => '',
                        'CDF' => 'CDF',
                        'USD' => 'USD',
                        'EUR' => 'EUR'
                );
                public $modes = array(
                        '' => '',
                        '5' => 'ESPECE',
                        '7' => 'OP',
                        '8' => 'OV',
                        '9' => 'AUTRES'
                );
                public $reversementStatus = array(
                        '1' => 'Reverser',
                        '2' => 'Regler',
                        '3' => 'Niveller'
                );
                public $infos = array(
                        'type' => '',
                        'agence' => '',
                        'reference' => '',
                        'moyen' => '',
                        'standard' => '',
                        'QuotasINPP' => '',
                        'QuotasINSS' => '',
                        'QuotasONEM' => '',
                        'RefINSS' => '',
                        'RefINPP' => '',
                        'RefONEM' => '',
                );
                public $moyens = array(
                        '' => '',
                        '10' => 'Especes',
                        '20' => 'Cheque',
                        '21' => 'Lettre bancaire',
                        '22' => 'Lettre bancaire certifiee',
                        '23' => 'Cheque bancaire (issu par banque ou etablissement financier simil.)',
                        '24' => 'Cheque particulier signe par la banque',
                        '50' => 'Ordre',
                        '80' => 'Paiement partiel',
                        '90' => 'Consentement mutuel',
                );

                public $document_seguce = array(
                        ''  => '',
                        '1' => 'POST DEDOUANEMENT',
                        '2' => 'PRE DEDOUANEMENT',
                        '3' => 'DEDOUANEMENT',
                        '4' => 'LOGISTIQUE',
                );

                public $types_fonds = array(
                        '' => '',
                        'PROPRE' => 'PROPRE',
                        'TRESOR' => 'TRESOR',
                );

                public $referentiel = array(
                        '' => '',
                        'VILLE' => 'VILLE',
                        'PROVINCE' => 'PROVINCE',
                );

                /**
                 * Retourne les menus effectivement disponibles, en appliquant
                 * les options de l'utilisateur (comme pour $this->menus).
                 */
                public function get_menus()
                {
                        $menus = $this->get_menus_by_role();
                        $options = !empty($_SESSION['userdata']['options'])
                                ? json_decode($_SESSION['userdata']['options'], true)
                                : array();

                        if (is_array($options) && array_key_exists('provincial_tax_payments', $options['ALL'] ?? array())) {
                                $menus = array_merge(
                                        array(
                                                '' => '',
                                                'Taxes provinciales' => array('DGRK' => 'DGRK')
                                        ),
                                        array_slice($menus, 1, null, true)
                                );
                        }

                        return $menus;
                }

                private function get_menus_by_role()
                {
                        if(isset($_SESSION['Logiref_role']) && in_array($_SESSION['Logiref_role'], array(2,4,7)))
                        {
                                return array(
                                        '' => '',
                                        'DGI' => array(
                                                'declaration'   => 'Déclaration des impôts',
                                                'inv'           => 'Immatriculation nationale des véhicules',
                                                //'inv2'          => 'INV (Essaie technique)'
                                        ),
                                        'DGRAD' => array(
                                                'note_perception' => 'Note de perception',
                                                'batch_notes'     => 'Lot des notes',
                                                'note_passeport'  => 'Paiement passeport',
                                                //'passport'        => 'Passeport (Essaie technique)',
                                                //'note_permis'     => 'Paiement permis de conduire',
                                                //'gardienage'    => 'Taxe de gardienage',
                                                //'bon_a_payer'   => 'Traitement de bon à payer'
                                        ),
                                        'DGDA' => array(
                                                'bulletin'   => 'Bulletin de liquidation',
                                                'batch'      => 'Lot des bulletins',
                                                'recover'    => 'Récupération des paiements',
                                                'other'      => 'Autres paiements',
                                                'prepayment' => 'Bulletin des prépaiements'
                                        )
                                );
                        }
                        elseif(isset($_SESSION['Logiref_role']) && in_array($_SESSION['Logiref_role'], array(11)))
                        {
                                return array(
                                        '' => '',
                                        'Taxes provinciales' => array(

                                        ),
                                        'DGI' => array(

                                        ),
                                        'DGRAD' => array(
                                                'note_passeport'  => 'Paiement passeport',
                                        )
                                );
                        }
                        else
                        {
                                return array();
                        }
                }

                public $menus = array(
                        '' => '',
                        'DGI' => array(
                                'declaration'   => 'Déclaration des impôts',
                                'inv'           => 'Immatriculation nationale des véhicules',
                                //'inv2'          => 'INV (Essaie technique)'
                        ),
                        'DGRAD' => array(
                                'note_perception' => 'Note de perception',
                                'batch_notes'     => 'Lot des notes',
                                'note_passeport'  => 'Paiement passeport',
                                'passport'        => 'Passeport (Essaie technique)',
                                //'note_permis'     => 'Paiement permis de conduire',
                                //'gardienage'    => 'Taxe de gardienage',
                                //'bon_a_payer'   => 'Traitement de bon à payer'
                        ),
                        'DGDA' => array(
                                'bulletin'   => 'Bulletin de liquidation',
                                'batch'      => 'Lot des bulletins',
                                'recover'    => 'Récupération des paiements',
                                'other'      => 'Autres paiements',
                                'prepayment' => 'Bulletin des prépaiements'
                        )
                );

                public $menus_invoices = array(
                        '' => '',

                        'SEGUCE' => array(
                                'guice' => 'Facture GUICE',
                        ),
                        'OCC & BIVAC' => array(
                                'provision' => 'Provision des factures',
                                'invoice_occ_batch' => 'Bordereau OCC-BIVAC',
                        )
                );

                public $reports = array(
                        ''=>'',
                        'Paiements'=>array(
                        'dgda'=>'Tous les paiements DGDA',
                    'reporting_immatriculation_tresor_siop_sent'=>"Rapport détaillé des plaques d'immatriculation envoyés vers Amplitude",
                    'reporting_immatriculation_tresor_siop_pending'=>"Rapport détaillé des plaques d'immatriculation non envoyés vers Amplitude",
                    'reporting_immatriculation_propre_siop_sent'=>"Rapport détaillé des plaques d'immatriculation propres envoyés vers Amplitude",
                    'reporting_immatriculation_propre_siop_pending'=>"Rapport détaillé des plaques d'immatriculation propres non envoyés vers Amplitude",
                    'reporting_immatriculation_payments_sent'=>"Rapport global des plaques d'immatriculation envoyées vers Amplitude",
                    'reporting_immatriculation_payments_pending'=>"Rapport global des plaques d'immatriculation non envoyées vers Amplitude",
                    'immatriculation_paid_unconfirmed'=>"Plaques payées et non confirmées",
                    'immatriculation_regularization_report'=>"Plaques en régularisation",
                        'declaration'=>'Tous les paiements DGI',
                        'note_perception'=>'Tous les paiements DGRAD',
                        'tresor'=>'Guichet Unique Tresor',
                        'propre'=>'Guichet Unique Propre',
                        'fondpropre'=>'Paiements Propres des partenaires',
                        'prepaids'=>'Tous les prépaiements',
                        )
                );

                public $impressions = array(
                        ''=>'',
                        'Impressions'=>array(
                                'attestation'=>'Attestation des paiements',
                                'quitance'=>'Quittances',
                        )
                );

                public $reversements = array(
                        ''=>'',
                        'reversement_dgi'=>'Reversement DGI',
                        'reversement_dgrad'=>'Reversement DGRAD',
                        'reversement_dgda'=>'Reversement DGDA'
                );
                public $reportspay = array(
                        ''=>'', 
                        'R&eacute;ferentiel'=>array(    
                        'comptes'=>'Comptes bancaires',
                        'users'=>'Utilisateurs',
                        'commissions'=> 'Commissions'
                        )                                                                                       
                );
                
                public $situations = array(
                        ''=>'', 
                        'Situations journali&egrave;res' => array(    
                        'situationDGI'=>'DGI',
                        'situationDGRAD'=>'DGRAD',
                        'situationDGDA'=> 'DGDA'
                        )                                                                                   
                );
                
                public $regularisations = array(
                        ''=>'', 
                        'Paiements regularisés' => array(    
                                'regularisationDGI'=>'DGI',
                                'regularisationDGRAD'=>'DGRAD',
                                'regularisationDGDA'=> 'DGDA'
                        )                                                                                   
                );

                public function __construct()
                {
                        parent::__construct();

                        $options = !empty($_SESSION['userdata']['options'])
                                ? json_decode($_SESSION['userdata']['options'], true)
                                : array();

                        if (is_array($options) && array_key_exists('provincial_tax_payments', $options['ALL'] ?? array())) {
                                $this->menus = array_merge(
                                        array(
                                                '' => '',
                                                'Taxes provinciales' => array(
                                                        'DGRK' => 'DGRK'
                                                )
                                        ),
                                        array_slice($this->menus, 1, null, true)
                                );
                        }
                }

                /*
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * List:
                * *************************************************************************************************************************SCETION 2
                */
                public function get_titre_info($titre = NULL, $regie = NULL, $service = NULL)
                {
                        if ($titre == NULL && $regie == NULL && $service = NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = '';
                                $obj->Reference_4 = '';
                                $obj->Beneficiare_5 = '';
                                $obj->Service_6 = '';
                                $obj->Information_7 = '';
                                $obj->Extrateur_8 = '';
                                $obj->Integration_9 = '';
                                $obj->Integrateur_10 = '';
                                return $obj;
                        } else {
                                $this->set_table('logiref_titres p', 'p.Id_0', 'p.Id_0 DESC');
                                return $this->get_by(array('Reference_4' => $titre, 'Beneficiare_5' => $regie, 'Service_6' => $service), TRUE);
                        }
                }

                public function get_documents_info($id = NULL)
                {
                        if ($id == NULL) {
                                $order = new stdClass();
                                $order->Id_0 = '';
                                $order->Date_1 = '';
                                $order->Status_2 = '';
                                $order->Account_3 = '';
                                $order->Creator_4 = '';
                                $order->Changes_5 = '';
                                $order->Changer_6 = '';
                                $order->Nom_7 = '';
                                $order->Code_8 = '';
                                $order->Traitement_9 = '';
                                $order->Compte_10 = '';
                                $order->Devise_11 = '';
                                $order->Type_12 = '';
                                return $order;
                        } else {
                                $this->set_table('logiref_seguce_documents o', 'o.Id_0', 'o.Id_0 DESC');
                                return $this->get_by(array('Id_0' => $id), TRUE);
                        }
                }

                public function get_ipaddress_info($id = NULL)
                {
                        if ($id == NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = '';
                                $obj->Ip_7 = '';
                        } else {
                                $this->set_table('logiref_address_ip p', 'p.Id_0', 'p.Id_0 DESC');
                                return $this->get_by(array('Ip_7' => $id, 'Status_2' => '1'), TRUE);
                        }
                }
                public function get_recette_info($oid = NULL)
                {
                        if ($oid == NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = NULL;
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = $this->session->userdata['account_id'];
                                $obj->Type_4 = '';
                                $obj->Beneficiare_5 = '';
                                $obj->Recette_6 = '';
                                $obj->Code_7 = '';
                                return $obj;
                        } else {
                                $this->set_table('logiref_recettes', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }

                public function get_service_info($oid = NULL)
                {
                        if ($oid == NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = NULL;
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 =  $this->session->userdata['account_id'];
                                $obj->Direction_4 = '';
                                $obj->Service_5 = '';
                                $obj->Description_6 = '';
                                $obj->Code_7 = '';
                                $obj->Province_8 = '';
                                $obj->Type_9 = '';
                                $obj->Commune_10 = '';
                                return $obj;
                        } else {
                                $this->set_table('logiref_services', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }

                public function get_parameter_info($oid)
                {
                        if ($oid == NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = NULL;
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = '';
                                $obj->Category_3 = '';
                                $obj->Option_4 = '';
                                $obj->Code_5 = '';

                                return $obj;
                        } else {
                                $this->set_table('logiref_parametres', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }

                public function get_region_info($oid = NULL)
                {
                        if ($oid == NULL) {
                                $obj = new stdClass();
                                $obj->Id_0 = NULL;
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = $this->session->userdata['account_id'];
                                $obj->Nom_7  = '';
                                $obj->Province_8 = '';
                                $obj->Comment_9 = '';
                                return $obj;
                        } else {
                                $this->set_table('logiref_regions', 'Id_0', 'Id_0 DESC');
                                return $this->get_by(array('Id_0' => $oid), TRUE);
                        }
                }
                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * List
                *  *************************************************************************************************************************SECTION 3
                */
                public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL,$param_2=NULL)
                {
                        if(isset($_SESSION['userdata']['account_id']))
                        {
                                $account_id = $this->session->userdata['account_id'];
                        }
                        else
                        {
                                $account_id = '';
                        }

                        if ($item == "groups") 
                        {
                                $st = "Object_4='Role' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_categories');
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row) {
                                        $ddmenu[$row['Id_0']] = $row['Category_5'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "parameter")
                        {
                                $type = $arg;
                                if ($type != NULL) $st = "Status_2='1' AND Category_3='" . $type . "' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                                $query = $this->db->table('logiref_parametres')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) {
                                        $ddmenu[$row['Option_4']] = $row['Option_4'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "types")
                        {
                                $type = $arg;
                                if ($type == 'Beneficiaire') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Object_4='Beneficiaire'";
                                if ($type == 'Compte') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Object_4='Compte'";
                                if ($type == 'Recette') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Object_4='Recette'";
                                if ($type == 'Service') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Object_4='Service'";
                                if ($type == 'Regle') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Object_4='Regle'";

                                $query = $this->db->table('logiref_categories')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) {
                                        $ddmenu[$row['Category_5']] = $row['Comment_6'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "recettes")
                        {
                                if ($param == NULL)
                                {
                                        $direction = $arg;
                                        $type = $data;
                                        $code=$param_2;
                                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";
                                        if ($direction != NULL) $st .= " AND Beneficiare_5 = '" . $direction . "'";
                                        if ($type != NULL) $st .= " AND Type_4 = '" . $type . "'";
                                        if ($code!=NULL) $st .=" AND Code_7 = '".$code."'";

                                        $query = $this->db->table('logiref_recettes')
                                                        ->where($st)
                                                        ->orderBy('Code_7 ASC')
                                                        ->get();

                                        $ddmenu = array();
                                        $i = 0;
                                        foreach ($query->getResultArray() as $row) {
                                                if ($row['Beneficiare_5'] == 'DGI') {
                                                        if ($i == 0) $ddmenu['DGI'][''] = '';

                                                        if($code!=NULL)
                                                        {
                                                                $ddmenu[$row['Beneficiare_5']][$code] = $row['Recette_6'];
                                                        }
                                                        else
                                                        {
                                                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                        }

                                                } elseif ($row['Beneficiare_5'] == 'DGRAD') {
                                                        if ($i == 0) $ddmenu['DGRAD'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                } elseif ($row['Beneficiare_5'] == 'DGDA') {
                                                        if ($i == 0) $ddmenu['DGDA'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                } elseif ($row['Beneficiare_5'] == 'ESES') {
                                                        if ($i == 0) $ddmenu['ESES'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                }
                                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];

                                                $i++;
                                        }

                                }
                                else
                                {
                                        $direction = $arg;
                                        $type = $data;
                                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                        if ($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "'";
                                        if ($type != NULL) $st .= " AND Type_4='" . $type . "'";

                                        $query = $this->db->table('logiref_recettes')
                                                        ->where($st)
                                                        ->orderBy('Code_7 ASC')
                                                        ->get();

                                        $ddmenu = array();
                                        foreach ($query->getResultArray() as $row) {
                                                $ddmenu[''][''] = '';
                                                if ($row['Beneficiare_5'] != "" && $row['Code_7'] != "") $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];
                                        }
                                }
                                return $ddmenu;
                        } 
                        elseif ($item == "recettes_dgda_tresor") 
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Type_4='TRESOR' AND Beneficiare_5='DGDA'";

                                $query = $this->db->table('logiref_recettes')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Code_7']] = $row['Code_7'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "services")
                        {
                                $direction = $arg;
                                $province = $data;
                                $classer = $param;
                                $st = "Status_2='1'";
                                if ($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
                                if ($province != NULL) $st .= " AND Province_8='" . $province . "'";

                                $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Service_5 ASC')
                                                ->get();
                                $ddmenu = array();
                                $i = 1;

                                if ($classer)
                                {
                                        $ddmenu[''][''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Direction_4']][$row['Code_7']] = $row['Service_5'] . " (" . $row['Code_7'] . ")";
                                        }
                                }
                                else
                                {

                                        $ddmenu[1] = 'DGI';
                                        $ddmenu[2] = 'DGRAD';
                                        $ddmenu[3] = 'DGDA';
                                        $ddmenu[4] = 'ESES';

                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Code_7']] = $row['Service_5'] . " (" . $row['Code_7'] . ")";
                                        }
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "provinces")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Category_3='PROVINCE'";

                                $query = $this->db->table('logiref_parametres')
                                                ->where($st)
                                                ->orderBy('Option_4 ASC')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';

                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Option_4']] = $row['Option_4'];
                                }

                                return $ddmenu;
                        }
                        elseif ($item == "provinces_villes")
                        {
                                // $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Category_3='VILLE' AND Parent_9='" . $arg . "'";

                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Category_3='VILLE' ";

                                $query = $this->db->table('logiref_parametres')
                                                ->where($st)
                                                ->orderBy('Option_4 ASC')
                                                ->get();
                                return $query->getResultArray();
                        }
                        elseif ($item == "provinces_services")
                        {
                                $st = "Status_2='1'";

                                $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Service_5 ASC')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';

                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Province_8']] = $row['Province_8'];
                                }

                                return $ddmenu;
                        }
                        elseif ($item == "type_services")
                        {
                                $direction = $arg;
                                $province = $data;
                                $classer = $param;
                                $st = "Status_2='1'";
                                if ($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
                                if ($province != NULL) $st .= " AND Province_8='" . $province . "'";

                                $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Service_5', 'ASC')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[1] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Code_7']] = $row['Type_9'];
                                }

                                return $ddmenu;
                        } 
        //                elseif ($item == "commune_services") 
        //                {
        //                        $direction = $arg;
        //                        $province = $data;
        //                        $classer = $param;
        //                        $st = "Status_2='1'";
        //                        if ($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
        //                        if ($province != NULL) $st .= " AND Province_8='" . $province . "'";
        //                        
        //                        $query = $this->db->table('logiref_services')
        //                                        ->where($st)
        //                                        ->orderBy('Service_5', 'ASC')
        //                                        ->get();
        //
        //                        $ddmenu = array();
        //                        $ddmenu[1] = '';
        //                        foreach ($query->getResultArray() as $row) 
        //                        {
        //                                $ddmenu[$row['Code_7']] = $row['Commune_10'];
        //                        }
        //
        //                        return $ddmenu;
        //                } 
                        elseif ($item == "regies")
                        {
                                $ddmenu['Regies'] = array('' => '', 'DGI' => 'DGI', 'DGRAD' => 'DGRAD', 'DGDA' => 'DGDA', 'DGPEK' => 'DGPEK', 'DGRK' => 'DGRK');
                                return $ddmenu;
                        } 
                        elseif ($item == "recettes_by_beneficiare") 
                        {
                                $direction = $arg;
                                $type = $data;
                                $st = "Status_2='1' ";
                                if ($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "'";
                                if ($type != NULL) $st .= " AND Type_4='" . $type . "'";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_recettes');
                                $ddmenu = array();
                                $ddmenu[''][''] = '';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                return $ddmenu;
                        } 
                        elseif ($item == "type_recette") 
                        {
                                $st = "Status_2='1'";
                                
                                $query = $this->db->table('logiref_recettes')
                                                ->where($st)
                                                ->orderBy("Code_7", "ASC")
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Code_7']] = $row['Type_4'];
                                }
                                return $ddmenu;
                        } 
                        elseif ($item == "recettesBl")
                        {

                                $direction = $arg;
                                $type = $data;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                if ($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "' ";
                                if ($type != NULL) $st .= " AND Type_4='" . $type . "'";
                                
                                $query = $this->db->table('logiref_recettes')
                                                ->where($st)
                                                ->orderBy("Code_7", "ASC")
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Code_7']] = $row['Code_7'] . '-' . $row['Recette_6'];
                                }
                                
                                return $ddmenu;
                                
                        } 
                        elseif ($item == "code_province") 
                        {
                                $st = "Status_2='1' AND Category_3='PROVINCE' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                
                                $query = $this->db->table('logiref_parametres')
                                                ->where($st)
                                                ->orderBy("Id_0", "ASC")
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Option_4']] = substr($row['Option_4'], 0, 3);
                                }
                                return $ddmenu;
                        } 
                        elseif ($item == "beneficiaries") 
                        {
                                $type = $arg;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                $ddmenu = array();
                                $ddmenu[''][''] = '';
                                if ($type != NULL) 
                                {
                                        $st .= " AND Type_4='" . $type . "'";
                                } 
                                else 
                                {
                                        $ddmenu['BKC'][''] = ''; // Banque commerciale
                                        $ddmenu['RGF'][''] = ''; // Regies
                                        $ddmenu['AIP'][''] = ''; // Autres Institutions Publiques
                                }
        
                                $query = $this->db->table('logiref_beneficiaries')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Type_4']][$row['Code_7']] = $row['Description_5'] . " (" . $row['Code_7'] . ")";
                                }
                                return $ddmenu;

                        }
                        elseif ($item == "regions")
                        {
                                $st = "Status_2='1'";

                                $query = $this->db->table('logiref_regions')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) {
                                        $ddmenu[$row['Id_0']] = $row['Nom_7'];
                                }
                                return $ddmenu;
                        } 
                        elseif ($item == "nifs") 
                        {
                                $st = "Status_2='1'";
                                
                                $query = $this->db->table('logiref_nifs')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Nif_4']] = $row['Designation_5'];
                                }
                                
                                return $ddmenu;
                        }
                        elseif($item=="guichets")
                        {
                                if($_SESSION['Logiref_groupe']=='banks')
                                {
                                        $agence = $arg;
                                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                        if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                        if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";

                                        $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0','ASC')
                                                ->get();

                                        $ddmenu = array();
                                        $ddmenu[''] = '';

                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }
                                        return $ddmenu;
                                }
                                else
                                {

                                        $st = "Status_2='1'";

                                        $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0','ASC')
                                                ->get();

                                        $ddmenu = array();
                                        $ddmenu[''] = '';

                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }
                                        return $ddmenu;
                                }
                        }
                        elseif($item=="agences")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                                $query = $this->db->table('logiref_agences')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        elseif($item=="codeagences")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                $query = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Code_10'];
                                }
                                return $ddmenu;
                        }
                        elseif($item=="agence_principale")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                                $query = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Code_10']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        elseif($item=="main_branch")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                                $query = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Agence_principale_14'];
                                }
                                return $ddmenu;
                        }
                }

                public function get_recettes_immatric($account_id)
                {
                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";

                        $query = $this->db->table('logiref_recettes')
                                        ->where($st)
                                        ->orderBy('Code_7 ASC')
                                        ->get();

                        $ddmenu = array();
                        $i = 0;

                        foreach ($query->getResultArray() as $row)
                        {
                                if ($row['Beneficiare_5'] == 'DGI')
                                {
                                        if ($i == 0) $ddmenu['DGI'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'DGRAD')
                                {
                                        if ($i == 0) $ddmenu['DGRAD'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'DGDA')
                                {
                                        if ($i == 0) $ddmenu['DGDA'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'ESES')
                                {
                                        if ($i == 0) $ddmenu['ESES'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                //$ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];

                                $i++;
                        }

                        return $ddmenu;
                }

                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * List
                *  *************************************************************************************************************************SECTION 4
                */
                public function get_paiements($type = NULL)
                {
                        $this->_table_name = '';
                        #Query
                        $this->db->select('logiref_paiements_tresor.*', 'logiref_paiements_tresor.Id_0 DESC');
                        $this->db->from('logiref_paiements_tresor');
                        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND (Beneficaire_15='DGI' OR Beneficaire_15='DGRAD')";
                        #Filtre d'affichage
                        if ($type == 'attente') $st .= " AND Checkerid_10='0'";
                        elseif ($type == 'urgents') $st .= " AND Checkerid_10='0' AND Datevaleur_31<'" . gmdate('Y-m-d') . "'";
                        elseif ($type == 'validated') $st .= " AND Status_2 = '2'";
                        elseif ($type == 'nvalidated') $st .= " AND Status_2 = '1' AND Checkerid_10 = 0";
                        elseif ($type == 'transferred') $st .= " AND Status_2 = '3'";
                        elseif ($type == 'virement') $st .= " AND Mode_19 = '7'";
                        elseif ($type == 'penalities') $st .= " AND Status_2 = '1' AND DATEDIFF('" . gmdate('Y-m-d H:i:s') . "', Date_1) >= 1";
                        else $st .= " AND (Checkerid_10='0' OR Datevaleur_31<='" . gmdate('Y-m-d') . "')";
                        #Restriction
                        if ($_SESSION['Logiref_role'] > 2) $st .= " AND Agence_20='" . $_SESSION['Logiref_agence'] . "'";
                        if ($_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
                        #Reversement
                        if (isset($_POST['Chequeid_6']) && $_POST['Chequeid_6'] != '') $st .= " AND Checkerid_10>'0' AND Status_2='1' ";
                        if (isset($_POST['Journee_16']) && $_POST['Journee_16'] != '') $st .= " AND Datevaleur_31='" . $_POST['Journee_16'] . "'";
                        if (isset($_POST['Beneficaire_13']) && $_POST['Beneficaire_13'] != '') $st .= " AND Beneficaire_15='" . $_POST['Beneficaire_13'] . "'";
                        if (isset($_POST['Devise_12']) && $_POST['Devise_12'] != '') $st .= " AND Devise_12='" . $_POST['Devise_12'] . "'";
                        if (isset($_POST['Service_14']) && $_POST['Service_14'] != '') $st .= " AND Service_16='" . $_POST['Service_14'] . "'";
                        if (isset($_POST['Typerecette_15']) && $_POST['Typerecette_15'] != '') $st .= " AND Typerecette_17='" . $_POST['Typerecette_15'] . "'";
                        if (isset($_POST['Agence_7']) && $_POST['Agence_7'] != "") $st .= " AND Guichet_21='" . $_POST['Agence_7'] . "'";
                        if (isset($_POST['start']) && $_POST['start'] != "") $st .= " AND Datevaleur_31 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "'";
                        #Run
                        //var_dump($st); die;
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }

                public function get_main_account($userdata)
                {
                        $this->set_table('main_accounts', 'Id_0', 'Id_0');
                        return $this->get_by(array('Id_0' => $userdata['account_id']), TRUE);
                }

                public function get_paiements_douane($type = NULL)
                {
                        $this->_table_name = '';
                        $this->db->select('logiref_sydonia.*', 'logiref_sydonia.Id_0 DESC');
                        $this->db->from('logiref_sydonia');
                        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        #Restriction
                        if ($_SESSION['Logiref_role'] > 2) $st .= " AND Agence_20='" . $_SESSION['Logiref_agence'] . "'";
                        if ($_SESSION['Logiref_role'] == 4) $st .= " AND Guichet_21='" . $_SESSION['Logiref_guichet'] . "'";
                        #Reversement

                        #Run
                        //var_dump($st); die;
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }

                public function get_taxes_codes($type = NULL)
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $query = $this->db->table('logiref_recettes')
                                        ->select('logiref_recettes.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }

                public function get_services($type = NULL)
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $query = $this->db->table('logiref_services')
                                        ->select('logiref_services.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }
                public function get_regions($type = NULL)
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $query = $this->db->table('logiref_regions')
                                        ->select('logiref_regions.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }

                public function get_documents($type = NULL)
                {
                        $this->_table_name = '';
                        $this->db->select('logiref_seguce_documents.*', 'logiref_seguce_documents.Id_0 ASC');
                        $this->db->from('logiref_seguce_documents');
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }

                public function get_groups()
                {
                        $st = "Object_4='Role' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_categories')
                                        ->select('logiref_categories.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }

                public function get_ipaddress_by_id($id = NULL)
                {
                        $this->set_table('logiref_address_ip p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id, 'Status_2' => '1'), TRUE);
                }

                public function get_ipaddress_by_userid($id = NULL)
                {
                        $this->set_table('logiref_address_ip p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Userid_9 ' => $id, 'Status_2' => '1'), TRUE);
                }

                public function get_ipaddress()
                {
                        $st = "Status_2 = '1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                        $builder = $this->db->table("logiref_address_ip")
                                ->select("logiref_address_ip.*")
                                ->where($st)
                                ->orderBy("Id_0","DESC")
                                ->get();

                        return $builder->getResult();
                }


                public function get_comptes($type = NULL)
                {
                        $this->_table_name = '';
                        $this->db->select('logiref_comptes.*', 'logiref_comptes.Id_0 ASC');
                        $this->db->from('logiref_comptes');
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }

                public function get_guichets($type = NULL)
                {
                        $this->_table_name = '';
                        $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                        $this->db->from('logiref_guichets');
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }

                public function get_guichet_by_id($id = NULL)
                {
                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id, 'Status_2' => '1'), TRUE);
                }

                public function get_agences($type = NULL)
                {
                        $this->_table_name = '';
                        $this->db->select('logiref_agences.*', 'logiref_agences.Id_0 ASC');
                        $this->db->from('logiref_agences');
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }

                public function get_referentiel($type = NULL)
                {
                        $this->_table_name = '';
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        if ($type == 'PROVINCE') $st .= " AND Category_3='" . $type . "'";
                        if ($type == 'VILLE') $st .= " AND Category_3='" . $type . "'";
                        if ($type == 'COMMISSION') $st .= " AND Category_3='" . $type . "'";
                        $query = $this->db->table('logiref_parametres')
                                        ->select('logiref_parametres.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }

                public function get_recettes_array($list, $type = NULL)
                {
                        $st = " Status_2='1' AND Account_3='0' AND Code_7 IN ('$list')";
                        if ($type == 'RFTRESD') {
                                $st .= " AND (Type_4='RFTRESD' || (Type_4='TRESOR' AND Beneficiare_5='DGDA'))";
                        } else {
                                $st .= " AND (Type_4!='RFTRESD' AND Type_4!='TRESOR')";
                        }
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_recettes');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Beneficiare_5']][] = $row['Code_7'];
                        }
                        return $ddmenu;
                }

                public function get_id_by_reference($ref)
                {
                        $st = " Logirefid_4='" . $ref . "'";
                        $this->db->where($st, NULL, FALSE);
                        $query = $this->db->get('logiref_paiements_tresor');
                        $id = NULL;
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $id = $row['Id_0'];
                        }
                        return $id;
                }

                public function get_comptes_array($liste = '')
                {
                        $comptes = array();
                        $comptes[''][''] = '';
                        $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                        if ($liste != '') $st .= " AND Type_4 IN (" . $liste . ")";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        foreach ($query->result_array() as $row) {
                                if ($row['Agenceid_15'] != "") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15'] . "-" . $row['Compte_6'];
                                else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                if ($row['Clef_7'] != "") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-" . $row['Clef_7'];
                        }
                        return $comptes;
                }

                public function get_privilegies()
                {
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $user_module = $this->session->userdata['user_module'];
                        $selected_guichet = $_SESSION['Logiref_guichet'] ?? '';
                        
                        //Module_11
                        $this->set_table('main_relations','Id_0','Id_0');
                        if (\App\Libraries\OracleRelationCompatibility::enabled($this->db->DBDriver, $this->session->userdata ?? [], $account_id)) {
                                $query = $this->db->query(
                                        'SELECT * FROM "MAIN_RELATIONS" WHERE "USER_7" = ? AND "ACCOUNT_3" = ? AND DBMS_LOB.COMPARE("MODULE_11", TO_CLOB(?)) = 0 FETCH FIRST 1 ROWS ONLY',
                                        [$user_id, $account_id, $user_module]
                                );
                                if ($query === false) {
                                        throw new \RuntimeException('Oracle module privilege comparison failed.');
                                }
                                $relation = $query->getRow();
                                if (!$relation) {
                                        $_SESSION['Logiref_privileges'] = 0;
                                        return false;
                                }
                        } else {
                                $relation = $this->get_by(['User_7' => $user_id, 'Module_11'=>$user_module],TRUE);
                        }
                     
                        if($relation->Module_11 != "")
                        {
                                if(in_array($relation->Module_11,array("logiref","eximtrade","elicense","qleads","etoll","Main","Pay","quitusfiscal", "branchless")))
                                {
                                        $Module_11 = array($relation->Module_11);
                                }
                                else
                                {
                                        $Module_11 = json_decode($relation->Module_11);
                                }

                                $_SESSION['Logiref_privileges'] = 1;
                                $_SESSION['Logiref_module'] = $Module_11;
                                // Valeurs par défaut — évite "Undefined array key" quand logiref_users
                                // ne retourne pas de ligne (ex: utilisateur LDAP sans profil logiref_users)
                                if (!isset($_SESSION['Logiref_role']))    $_SESSION['Logiref_role']    = 0;
                                if (!isset($_SESSION['Logiref_guichet'])) $_SESSION['Logiref_guichet'] = '';
                                if (!isset($_SESSION['Logiref_agence']))  $_SESSION['Logiref_agence']  = '';
                                if (!isset($_SESSION['Logiref_branch']))  $_SESSION['Logiref_branch']  = '';
                                if (!isset($_SESSION['Logiref_groupe']))  $_SESSION['Logiref_groupe']  = '';
                                if (!isset($_SESSION['Logiref_province'])) $_SESSION['Logiref_province'] = '';
                                if (!isset($_SESSION['Logiref_ville']))   $_SESSION['Logiref_ville']   = '';
                                if (!isset($_SESSION['Logiref_service'])) $_SESSION['Logiref_service'] = '';
                                if (!isset($_SESSION['Logiref_regies']))  $_SESSION['Logiref_regies']  = '';
                                if (!isset($_SESSION['Logiref_user']))    $_SESSION['Logiref_user']    = '';
                                if (!isset($_SESSION['Logiref_region']))  $_SESSION['Logiref_region']  = '';
                                if (!isset($_SESSION['Logiref_option']))  $_SESSION['Logiref_option']  = null;
                       
                                if(count($Module_11) > 1)
                                {
                                        foreach($Module_11 as $value)
                                        {
                                                if(in_array($value,array("logiref","eximtrade","elicense","Main","Pay","quitusfiscal")))
                                                {
                                                        $this->set_table('logiref_users', 'Id_0', 'Id_0');
                                                        $privilegy = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_13' => $user_id], TRUE);
                                                        if($privilegy != NULL)
                                                        {
                                                                $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                                $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                                $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                                                                $_SESSION['Logiref_branch'] = $privilegy->Agence_7;
                                                                $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        }
                                                }
                                                elseif(in_array($value,array("branchless")))
                                                {
                                                        $this->set_table('logiref_bank_profiles', 'Id_0', 'Id_0');
                                                        $privilegy = $this->get_by(['Id_0' => $user_id, 'Status_2' => 2, 'Account_3' => $account_id], TRUE);

                                                        if($privilegy != NULL)
                                                        {
                                                                $_SESSION['Logiref_role'] = $privilegy->Role_8;
                                                                $_SESSION['Logiref_guichet'] = $privilegy->Branchid_9;
                                                        }
                                                }
                                                elseif($value == "etoll")
                                                {
                                                        $dbEtoll = \Config\Database::connect('ikwook_logiref_etoll');
                                                        $privilegy = $dbEtoll->table('logiref_users')
                                                                ->where('Status_2',1)
                                                                ->where('Account_3',$account_id)
                                                                ->where('Userid_13',$user_id)
                                                                ->get()
                                                                ->getRow();

                                                        if(!is_null($privilegy)){
                                                                $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                                $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                                $_SESSION['Logiref_guichet'] = $privilegy->Agence_7;
                                                                $_SESSION['Logiref_branch'] = $privilegy->Guichet_8;
                                                        }
                                                        break;
                                                }
                                                elseif($value == "qleads")
                                                {
                                                        $dbQleads = \Config\Database::connect('ikwook_logiref_qleads');
                                                        $privilegy = $dbQleads->table('qleads_users')
                                                                ->where('Status_2',1)
                                                                ->where('Account_3',$account_id)
                                                                ->where('Userid_7',$user_id)
                                                                ->get()
                                                                ->getRow();

                                                        if(!is_null($privilegy)){
                                                                $_SESSION['Logiref_role'] = $privilegy->Authorization_8;
                                                                $_SESSION['Logiref_groupe'] = 0;
                                                                $_SESSION['Logiref_guichet'] = $privilegy->Branchid_9;
                                                        }
                                                }
                                        }
                                }
                                else
                                {
                                        if(in_array("logiref",$Module_11))
                                        {
                                                $this->set_table('logiref_users', 'Id_0', 'Id_0');
                                                $privilegy = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_13' => $user_id], TRUE);

                                                if($privilegy != NULL)
                                                {
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                                                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                                                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                                                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                                                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                                                        $_SESSION['roles_banks'] = [
                                                                '1'  => 'ADMINISTRATEUR',
                                                                '2'  => 'SUPERVISEUR',
                                                                '3'  => 'VALIDATEUR',
                                                                '4'  => 'OPERATEUR',
                                                                '5'  => 'CONSULTATION',
                                                                '6'  => 'CONTROLEUR',
                                                                '7'  => 'SUPER OPERATEUR',
                                                                '8'  => 'SUPER VALIDATEUR',
                                                                '9'  => 'OPERATEUR DE TAUX',
                                                                '10' => 'VALIDATEUR DE TAUX',
                                                                '11' => 'GUICHETIER',
                                                        ];
                                                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_22))?json_decode($privilegy->Option_22):Null;

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                                                                $_SESSION['Guichet_options'] = json_decode($guichet->Options_13, true);
                                                        }
                                                }
                                                else
                                                {
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }

                                        }
                                        elseif(in_array("branchless",$Module_11))
                                        {
                                                $this->set_table('logiref_bank_profiles', 'Id_0', 'Id_0');
                                                $privilegy = $this->get_by(['Id_0' => $user_id, 'Status_2' => 2, 'Account_3' => $account_id], TRUE);

                                                $this->set_table('logiref_bank_users', 'Id_0', 'Id_0');
                                                $users = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_8' => $user_id], TRUE);

                                                if($privilegy != NULL)
                                                {
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_8;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_8;
                                                        $_SESSION['Logiref_province'] = $users->State_18;
                                                        $_SESSION['Logiref_ville'] = $users->City_19;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Branchid_9;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Branchid_9;
                                                        $_SESSION['roles_banks'] = [
                                                                '1' => 'ADMINISTRATEUR',
                                                                '2' => 'SUPERVISEUR',
                                                                '3' => 'VALIDATEUR',
                                                                '4' => 'OPERATEUR',
                                                                '5' => 'CONSULTATION',
                                                                '6' => 'CONTROLEUR',
                                                                '7' => 'SUPER OPERATEUR',
                                                                '8' => 'SUPER VALIDATEUR',
                                                        ];
                                                }
                                                else
                                                {
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("qleads",$Module_11))
                                        {
                                                $dbQleads = \Config\Database::connect('ikwook_logiref_qleads');
                                                $privilegy = $dbQleads->table('qleads_users')
                                                        ->where('Status_2',1)
                                                        ->where('Account_3',$account_id)
                                                        ->where('Userid_7',$user_id)
                                                        ->get()
                                                        ->getRow();

                                                if(!is_null($privilegy)){
                                                        $_SESSION['Logiref_role'] = $privilegy->Authorization_8;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Authorization_8;
                                                        $_SESSION['Logiref_province'] = 0;
                                                        $_SESSION['Logiref_ville'] = 0;
                                                        $_SESSION['Logiref_agence'] = 0;
                                                        $_SESSION['Logiref_branch'] = 0;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Branchid_9;
                                                        $_SESSION['Logiref_groupe'] = 0;
                                                        $_SESSION['Logiref_service'] = 0;
                                                        $_SESSION['Logiref_regies'] = 0;
                                                        $_SESSION['Logiref_user'] = 0;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_19;
                                                        $_SESSION['roles_banks'] = [
                                                                '1'=> 'MAKER | OPERATEUR',
                                                                '2'=> 'VALIDATEUR',
                                                                '3'=> 'SUPERVISEUR',
                                                                '4'=> 'CONSEILLER',
                                                                '5'=> 'DIRECTEUR'
                                                        ];
                                                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_20))?json_decode($privilegy->Option_20):Null;

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Branchid_9], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                                                        }
                                                }
                                                else{
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("etoll",$Module_11))
                                        {
                                                $dbEtoll = \Config\Database::connect('ikwook_logiref_etoll');
                                                $privilegy = $dbEtoll->table('logiref_users')
                                                        ->where('Status_2',1)
                                                        ->where('Account_3',$account_id)
                                                        ->where('Userid_13',$user_id)
                                                        ->get()
                                                        ->getRow();

                                                if(!is_null($privilegy)){
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                                                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_branch'] = $privilegy->Guichet_8;
                                                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                                                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                                                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_24;
                                                        $_SESSION['Logiref_caisse'] = $privilegy->Caisse_20;
                                                        $_SESSION['partner'] = $privilegy->Partner_21;
                                                        $_SESSION['pos'] = $privilegy->Pos_22;
                                                        $_SESSION['Sbbos_type'] = ($privilegy->Type_23 != 0)?$privilegy->Type_23:2;
                                                        $_SESSION['roles_banks'] = [
                                                                '1' => 'ADMINISTRATEUR',
                                                                '2' => 'SUPERVISEUR',
                                                                '3' => 'VALIDATEUR (Checkers)',
                                                                '4' => 'OPERATEUR (Makers)',
                                                                '5' => 'CONSULTATION',
                                                                '6' => 'PARTENAIRE',
                                                                '7' => 'RESPONSABLE'
                                                        ];
                                                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_26))?json_decode($privilegy->Option_26):Null;

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = "";
                                                        }
                                                }
                                                else{
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("eximtrade",$Module_11))
                                        {
                                                $this->set_table('logiref_users', 'Id_0', 'Id_0');
                                                $privilegy = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_13' => $user_id], TRUE);

                                                if($privilegy != NULL)
                                                {
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                                                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                                                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                                                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                                                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                                                        $_SESSION['roles_banks'] = [
                                                                '1'  => 'ADMINISTRATEUR',
                                                                '2'  => 'SUPERVISEUR',
                                                                '3'  => 'VALIDATEUR',
                                                                '4'  => 'OPERATEUR',
                                                                '5'  => 'CONSULTATION',
                                                                '6'  => 'CONTROLEUR',
                                                                '7'  => 'SUPER OPERATEUR',
                                                                '8'  => 'SUPER VALIDATEUR',
                                                                '9'  => 'OPERATEUR DE TAUX',
                                                                '10' => 'VALIDATEUR DE TAUX',
                                                        ];

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                                                        }
                                                }
                                                else
                                                {
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("quitusfiscal",$Module_11))
                                        {
                                                $this->set_table('logiref_users', 'Id_0', 'Id_0');
                                                $privilegy = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_13' => $user_id], TRUE);

                                                if($privilegy != NULL)
                                                {
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                                                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                                                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                                                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                                                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                                                        $_SESSION['roles_banks'] = [
                                                                '1'  => 'ADMINISTRATEUR',
                                                                '2'  => 'SUPERVISEUR',
                                                                '3'  => 'VALIDATEUR',
                                                                '4'  => 'OPERATEUR',
                                                                '5'  => 'CONSULTATION',
                                                                '6'  => 'CONTROLEUR',
                                                                '7'  => 'SUPER OPERATEUR',
                                                                '8'  => 'SUPER VALIDATEUR',
                                                                '9'  => 'OPERATEUR DE TAUX',
                                                                '10' => 'VALIDATEUR DE TAUX',
                                                        ];

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                                                        }
                                                }
                                                else
                                                {
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("elicense",$Module_11))
                                        {
                                                $this->set_table('logiref_users', 'Id_0', 'Id_0');
                                                $privilegy = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Userid_13' => $user_id], TRUE);

                                                if($privilegy != NULL)
                                                {
                                                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                                                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                                                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                                                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                                                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                                                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                                                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                                                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                                                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                                                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                                                        $_SESSION['roles_banks'] = [
                                                                '1'  => 'ADMINISTRATEUR',
                                                                '2'  => 'SUPERVISEUR',
                                                                '3'  => 'VALIDATEUR',
                                                                '4'  => 'OPERATEUR',
                                                                '5'  => 'CONSULTATION',
                                                                '6'  => 'CONTROLEUR',
                                                                '7'  => 'SUPER OPERATEUR',
                                                                '8'  => 'SUPER VALIDATEUR',
                                                                '9'  => 'OPERATEUR DE TAUX',
                                                                '10' => 'VALIDATEUR DE TAUX',
                                                        ];

                                                        //Get Guichet
                                                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                                                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                                                        $_SESSION['Guichet_code'] = "";

                                                        if ($guichet != NULL) {
                                                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                                                        }
                                                }
                                                else
                                                {
                                                        $_SESSION['Logiref_privileges'] = 0;
                                                }
                                        }
                                        elseif(in_array("2ibanking",$Module_11))
                                        {
                                                $_SESSION['Logiref_module'] = "2ibanking";
                                        }
                                        elseif(in_array("iabanking",$Module_11))
                                        {
                                                $_SESSION['Logiref_module'] = "iabanking";
                                        }
                                        elseif(in_array("debitorders",$Module_11))
                                        {
                                                $_SESSION['Logiref_module'] = "debitorders";
                                        }
                                }
                        }
                        else{
                                $_SESSION['Logiref_privileges'] = 0;
                        }

                        $this->preserve_switched_guichet($account_id, $selected_guichet);
                }

                public function  get_clients_by_nif($nif = NULL)
                {
                        if ($nif != NULL) {
                                $this->set_table('logiref_nifs N', 'N.Id_0', 'N.Id_0 DESC');
                                return $this->get_by(array('Nif_4' => $nif), TRUE);
                        }
                }


                /*
                * Save Information: insert or update an array
                * Use: inserting or updating 
                * List
                *  *************************************************************************************************************************SECTION 5
                */

                public function save_documents($data, $id)
                {
                        $this->set_table('logiref_seguce_documents', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_ipaddress($data, $id)
                {
                        $this->set_table('logiref_address_ip', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_taxe($data, $id)
                {
                        $this->set_table('logiref_recettes', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_service($data, $id)
                {
                        $this->set_table('logiref_services', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_parametre($data, $id)
                {
                        $this->set_table('logiref_parametres', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_beneficiaries($data, $id)
                {
                        $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_region($data, $id)
                {
                        $this->set_table('logiref_regions', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_users($data, $id) {
                        $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                protected function preserve_switched_guichet($account_id, $selected_guichet)
                {
                        if ((int) ($_SESSION['Logiref_role'] ?? 0) !== 6 || empty($selected_guichet)) {
                                return;
                        }

                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                        $guichet = $this->get_by([
                                'Status_2' => 1,
                                'Account_3' => $account_id,
                                'Id_0' => $selected_guichet,
                        ], true);

                        if ($guichet == null) {
                                return;
                        }

                        $_SESSION['Logiref_guichet'] = $guichet->Id_0;
                        $userdata = $this->session->get('userdata');
                        if (!is_array($userdata)) {
                                $userdata = [];
                        }
                        $userdata['Logiref_guichet'] = $guichet->Id_0;
                        $_SESSION['userdata'] = $userdata;

                        $this->session->set('Logiref_guichet', $guichet->Id_0);
                        $this->session->set('userdata', $userdata);

                        $_SESSION['Guichet_code'] = $guichet->Code_10 ?? "";
                        $_SESSION['main_branch'] = $guichet->Agence_principale_15 ?? "";
                        $_SESSION['Guichet_options'] = !empty($guichet->Options_13) ? json_decode($guichet->Options_13, true) : [];
                }
        }
