<?php

        namespace Modules\Logiref\Models;

        use App\Models\MY_Main;

        class InvLogirefModel extends MY_Main
        {
                /* Presentation:
                * Last update
                * By
                *  *************************************************************************************************************************SECTION 1
                */

                /*
                * Protected and public variables
                * Use: forms validation constraintes, dropdowns static array, contextual variable etc
                */
                protected $_table_name = '';
                protected $_primary_key = '';
                protected $_order_by = '';
                protected $_timestamps = FALSE;
                protected $_date_created = '';
                protected $_date_modified = '';

                public $documents = array(
                        '1' => 'NOTE DE PERCEPTION',
                        '2' => 'QUITTANCE',
                        '3' => 'BULLETIN DE LIQUIDATION',
                        '4' => 'NOTE DE VERSEMENT',
                        '5' => 'DECLARATION'
                );
                public $devises = array(
                        '' => '',
                        'CDF' => 'CDF',
                        'USD' => 'USD',
                        // 'EUR' => 'EUR',
                        // 'ZAF' => 'ZAF'
                );
                public $devises2 = array(
                        '' => '',
                        'CDF' => 'CDF',
                        'USD' => 'USD',
                        'EUR' => 'EUR'
                );
                public $modes = array(
                        '' => '',
                        '5' => 'ESPECE',
                        '7' => 'OP',
                        '8' => 'OV',
                        '9' => 'AUTRES'
                );
                public $reversementStatus = array(
                        '1' => 'Reverser',
                        '2' => 'Regler',
                        '3' => 'Niveller'
                );
                public $infos = array(
                        'type' => '',
                        'agence' => '',
                        'reference' => '',
                        'moyen' => '',
                        'standard' => '',
                        'QuotasINPP' => '',
                        'QuotasINSS' => '',
                        'QuotasONEM' => '',
                        'RefINSS' => '',
                        'RefINPP' => '',
                        'RefONEM' => '',
                );
                public $moyens = array(
                        '' => '',
                        '10' => 'Especes',
                        '20' => 'Cheque',
                        '21' => 'Lettre bancaire',
                        '22' => 'Lettre bancaire certifiee',
                        '23' => 'Cheque bancaire (issu par banque ou etablissement financier simil.)',
                        '24' => 'Cheque particulier signe par la banque',
                        '50' => 'Ordre',
                        '80' => 'Paiement partiel',
                        '90' => 'Consentement mutuel',
                );

                public $types_fonds = array(
                        '' => '',
                        'PROPRE' => 'PROPRE',
                        'TRESOR' => 'TRESOR',
                );

                public $referentiel = array(
                        '' => '',
                        'VILLE' => 'VILLE',
                        'PROVINCE' => 'PROVINCE',
                );

                public $menus_invoices = array(
                        '' => '',

                        'SEGUCE' => array(
                                'guice' => 'Facture GUICE',
                        ),
                        'OCC & BIVAC' => array(
                                'provision' => 'Provision des factures',
                                'invoice_occ_batch' => 'Bordereau OCC-BIVAC',
                        )
                );

                public $reports = array(
                                ''=>'',
                                'Paiements'=>array(
                                'dgda'=>'Tous les paiements DGDA',
                                'declaration'=>'Tous les paiements DGI',
                                'note_perception'=>'Tous les paiements DGRAD',
                                'tresor'=>'Guichet Unique Tresor',
                                'propre'=>'Guichet Unique Propre',
                                'fondpropre'=>'Paiements Propres des partenaires',
                                'prepaids'=>'Tous les prépaiements',
                        )
                );

                public $impressions = array(
                        ''=>'',
                        'Impressions'=>array(
                                'attestation'=>'Attestation des paiements',
                                'quitance'=>'Quittances',
                        )
                );

                public $reversements = array(
                        ''=>'',
                        'reversement_dgi'=>'Reversement DGI',
                        'reversement_dgrad'=>'Reversement DGRAD',
                        'reversement_dgda'=>'Reversement DGDA'
                );
                public $reportspay = array(
                        ''=>'',
                        'R&eacute;ferentiel'=>array(
                        'comptes'=>'Comptes bancaires',
                        'users'=>'Utilisateurs',
                        'commissions'=> 'Commissions'
                        )
                );

                public $situations = array(
                                ''=>'',
                                'Situations journali&egrave;res' => array(
                                'situationDGI'=>'DGI',
                                'situationDGRAD'=>'DGRAD',
                                'situationDGDA'=> 'DGDA'
                        )
                );

                public $regularisations = array(
                                ''=>'',
                                'Paiements regularisés' => array(
                                'regularisationDGI'=>'DGI',
                                'regularisationDGRAD'=>'DGRAD',
                                'regularisationDGDA'=> 'DGDA'
                        )
                );

                public function __construct()
                {
                        parent::__construct();
                }

                /*
                * Get Information: return a single item
                * Use: for creation, for display, for updates
                * List:
                * *************************************************************************************************************************SCETION 2
                */

                public function get_guichet_info($id = NULL)
                {
                        if ($id == NULL)
                        {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '';
                                $obj->Account_3 = '';
                                $obj->Nom_4 = '';
                                $obj->Agence_5 = '';
                                $obj->Province_6 = '';
                                $obj->Ville_7 = '';
                                $obj->Adresse_8 = '';
                                $obj->Observation_9 = '';
                                $obj->Code_10 = '';
                                $obj->Checkerid_11 = '';
                                $obj->Validation_12 = '';
                                $obj->Region_14  = '';
                                $obj->Latitude_15  = '';
                                $obj->Longitude_16  = '';
                                $obj->Files_17  = '';
                                $obj->Agence_principale_15  = '';

                                return $obj;
                        }
                        else
                        {
                                $this->set_table('logiref_guichets p', 'p.Id_0', 'p.Id_0 DESC');
                                return $this->get_by(array('Id_0' => $id), TRUE);
                        }
                }

                public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL,$param_2=NULL)
                {
                        if(isset($_SESSION['userdata']['account_id']))
                        {
                                $account_id = $this->session->userdata['account_id'];
                        }
                        else
                        {
                                $account_id = '';
                        }

                        if($item=="guichets")
                        {
                                if($arg=="force")
                                {
                                        $st = "Status_2='1' AND Account_3='" . $account_id . "'";
                                        $query = $this->db->table('logiref_guichets')
                                                        ->where($st)
                                                        ->orderBy('Id_0')
                                                        ->get();
                                        $ddmenu = array();
                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }

                                        return $ddmenu;
                                }
                                elseif($arg=="regions")
                                {
                                        $regions = $data;
                                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Region_14='" .$regions. "' ";
                                        $query = $this->db->table('logiref_guichets')
                                                        ->where($st)
                                                        ->orderBy('Id_0')
                                                        ->get();
                                        $ddmenu = array();
                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }

                                        return $ddmenu;
                                }
                                elseif($arg=="ville")
                                {
                                        $ville = $data;
                                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Ville_7='" .$ville. "' ";
                                        $query = $this->db->table('logiref_guichets')
                                                        ->where($st)
                                                        ->orderBy('Id_0')
                                                        ->get();
                                        $ddmenu = array();
                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }

                                        return $ddmenu;
                                }
                                elseif($_SESSION['Logiref_groupe']=='banks')
                                {
                                        $agence = $arg;
                                        $st = "Status_2='1' AND (Account_3='" . $account_id . "')";
                                        if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                        if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";

                                        $query = $this->db->table('logiref_guichets')
                                                        ->where($st)
                                                        ->orderBy('Id_0')
                                                        ->get();

                                        $ddmenu = array();
                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }
                                        return $ddmenu;
                                }
                                else
                                {
                                        $st = "Status_2='1'";
                                        $query = $this->db->table('logiref_guichets')
                                                        ->where($st)
                                                        ->orderBy('Id_0')
                                                        ->get();
                                        $ddmenu = array();
                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                        }
                                        return $ddmenu;
                                }
                        }
                        elseif($item=="immatriculation_beneficiaries")
                        {
                                $accountBank = (!is_null($arg))?$arg:0;

                                $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";

                                $query = $this->db->table('logiref_beneficiaries')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Code_7']] = $row;
                                }
                                return $ddmenu;
                        }
                        elseif($item=="codeagences")
                        {
                                $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";
                                $query = $this->db->table('logiref_guichets')
                                        ->where($st)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Id_0']] = $row['Code_10'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "users_array")
                        {
                                if ($param == NULL)
                                        $where = "Account_3='" . $account_id . "'";
                                else
                                        $where = " Status_2 = 1";

                                $query = $this->db->table('main_profiles')
                                        ->where($where)
                                        ->orderBy('Firstname_9')
                                        ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) {
                                        $ddmenu[$row['Id_0']] = $row['Firstname_9'] . ' ' . $row['Lastname_10'];
                                        $pprofiles[$row['Id_0']] = $row['Profile_16'];
                                }
                                $returns = $ddmenu;
                                return $returns;
                        }
                        elseif ($item == "recettes")
                        {
                                if ($param == NULL)
                                {
                                        $direction = $arg;
                                        $type = $data;
                                        $code=$param_2;
                                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";
                                        if ($direction != NULL) $st .= " AND Beneficiare_5 = '" . $direction . "'";
                                        if ($type != NULL) $st .= " AND Type_4 = '" . $type . "'";
                                        if ($code!=NULL) $st .=" AND Code_7 = '".$code."'";

                                        $query = $this->db->table('logiref_recettes')
                                                        ->where($st)
                                                        ->orderBy('Code_7 ASC')
                                                        ->get();

                                        $ddmenu = array();
                                        $i = 0;
                                        foreach ($query->getResultArray() as $row) {
                                                if ($row['Beneficiare_5'] == 'DGI') {
                                                        if ($i == 0) $ddmenu['DGI'][''] = '';

                                                        if($code!=NULL)
                                                        {
                                                                $ddmenu[$row['Beneficiare_5']][$code] = $row['Recette_6'];
                                                        }
                                                        else
                                                        {
                                                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                        }

                                                } elseif ($row['Beneficiare_5'] == 'DGRAD') {
                                                        if ($i == 0) $ddmenu['DGRAD'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                } elseif ($row['Beneficiare_5'] == 'DGDA') {
                                                        if ($i == 0) $ddmenu['DGDA'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                } elseif ($row['Beneficiare_5'] == 'ESES') {
                                                        if ($i == 0) $ddmenu['ESES'][''] = '';
                                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                                }
                                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];

                                                $i++;
                                        }

                                }
                                else
                                {
                                        $direction = $arg;
                                        $type = $data;
                                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";
                                        if ($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "'";
                                        if ($type != NULL) $st .= " AND Type_4='" . $type . "'";

                                        $query = $this->db->table('logiref_recettes')
                                                        ->where($st)
                                                        ->orderBy('Code_7 ASC')
                                                        ->get();

                                        $ddmenu = array();
                                        foreach ($query->getResultArray() as $row) {
                                                $ddmenu[''][''] = '';
                                                if ($row['Beneficiare_5'] != "" && $row['Code_7'] != "") $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];
                                        }
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "services")
                        {
                                $direction = $arg;
                                $province = $data;
                                $classer = $param;
                                $st = "Status_2='1'";
                                if ($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
                                if ($province != NULL) $st .= " AND Province_8='" . $province . "'";

                                $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Service_5 ASC')
                                                ->get();
                                $ddmenu = array();
                                $i = 1;

                                if ($classer)
                                {
                                        $ddmenu[''][''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Direction_4']][$row['Code_7']] = $row['Service_5'] . " (" . $row['Code_7'] . ")";
                                        }
                                }
                                else
                                {

                                        $ddmenu[1] = 'DGI';
                                        $ddmenu[2] = 'DGRAD';
                                        $ddmenu[3] = 'DGDA';
                                        $ddmenu[4] = 'ESES';

                                        $ddmenu[''] = '';
                                        foreach ($query->getResultArray() as $row)
                                        {
                                                $ddmenu[$row['Code_7']] = $row['Service_5'] . " (" . $row['Code_7'] . ")";
                                        }
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "type_services")
                        {
                                $direction = $arg;
                                $province = $data;
                                $classer = $param;
                                $st = "Status_2='1'";
                                if ($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
                                if ($province != NULL) $st .= " AND Province_8='" . $province . "'";

                                $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Service_5', 'ASC')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[1] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Code_7']] = $row['Type_9'];
                                }

                                return $ddmenu;
                        }
                        elseif ($item == "regies")
                        {
                                $ddmenu['Regies'] = array('' => '', 'DGI' => 'DGI', 'DGRAD' => 'DGRAD', 'DGDA' => 'DGDA', 'DGPEK' => 'DGPEK', 'DGRK' => 'DGRK');
                                return $ddmenu;
                        }
                        elseif ($item == "recettes_by_beneficiare")
                        {
                                $direction = $arg;
                                $type = $data;
                                $st = "Status_2='1' ";
                                if ($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "'";
                                if ($type != NULL) $st .= " AND Type_4='" . $type . "'";
                                $this->db->where($st, NULL, FALSE);
                                $this->db->order_by('Id_0');
                                $query = $this->db->get('logiref_recettes');
                                $ddmenu = array();
                                $ddmenu[''][''] = '';
                                foreach ($query->result_array() as $row)
                                {
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                return $ddmenu;
                        }
                        elseif ($item == "type_recette")
                        {
                                $st = "Status_2='1'";

                                $query = $this->db->table('logiref_recettes')
                                                ->where($st)
                                                ->orderBy("Code_7", "ASC")
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Code_7']] = $row['Type_4'];
                                }
                                return $ddmenu;
                        }
                }

                public function get_recettes_immatric($account_id)
                {
                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0')";

                        $query = $this->db->table('logiref_recettes')
                                        ->where($st)
                                        ->orderBy('Code_7 ASC')
                                        ->get();

                        $ddmenu = array();
                        $i = 0;

                        foreach ($query->getResultArray() as $row)
                        {
                                if ($row['Beneficiare_5'] == 'DGI')
                                {
                                        if ($i == 0) $ddmenu['DGI'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'DGRAD')
                                {
                                        if ($i == 0) $ddmenu['DGRAD'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'DGDA')
                                {
                                        if ($i == 0) $ddmenu['DGDA'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                elseif ($row['Beneficiare_5'] == 'ESES')
                                {
                                        if ($i == 0) $ddmenu['ESES'][''] = '';
                                        $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                                }
                                //$ddmenu[$row['Beneficiare_5']][$row['Code_7']] = '' . $row['Code_7'] . '-' . $row['Recette_6'];

                                $i++;
                        }

                        return $ddmenu;
                }

                /*
                * Get Information: returns an array
                * Use: for indexation, for dropdon etc
                * List
                *  *************************************************************************************************************************SECTION 4
                */

                public function get_comptes_dgi_immatric($liste = null,$beneficiary = null,$agence = null,$account = null,$code_agence = null)
                {
                        $builder = $this->db->table('logiref_comptes');

                        $builder->select('logiref_comptes.*');

                        // Conditions fixes
                        $builder->where('Status_2', '1');
                        $builder->where('Checkerid_11 <>', '0');

                        // Account_3 = compte OU 0
                        $builder->groupStart()
                                        ->where('Account_3', $account)
                                        ->orWhere('Account_3', '0')
                                ->groupEnd();

                        // Type_4 IN (...)
                        if (!is_array($liste))
                        {
                                $liste = explode(',', $liste);

                                $liste = array_map(function($item) {
                                        return trim($item, " '\"");
                                }, $liste);
                        }

                        // Filtre agence
                        if (!empty($agence)) {
                                $builder->where('Agence_12', $agence);
                        }

                        // Filtre code agence
                        if (!empty($code_agence)) {
                                $builder->where('Agenceid_15', $code_agence);
                        }

                        // Filtre bénéficiaire
                        if (!empty($beneficiary)) {

                               $builder->where('Beneficiaires_5', $beneficiary);
                        }

                        $query = $builder
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                        return $query->getResultArray();
                }

                public function get_users_immatric($account_id)
                {
                        $where = "Status_2!='0' AND Account_3='" . $account_id . "'";

                        $query = $this->db->table('main_profiles')
                                ->where($where)
                                ->orderBy('Firstname_9')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Firstname_9'] . ' ' . $row['Lastname_10'];
                        }
                        return $ddmenu;
                }

                public function get_comptes_immatriculation($liste=NULL, $account_id)
                {
                        $comptes = array();
                        $comptes[''][''] = '';
                        $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                        if($liste!='') $st .= " AND Type_4 IN (" . $liste . ")";

                        $builder = $this->db->table('logiref_comptes')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();

                        return $builder->getResultArray();
                }

                public function get_main_account($userdata)
                {
                        $this->set_table('main_accounts', 'Id_0', 'Id_0');
                        return $this->get_by(array('Id_0' => $userdata['account_id']), TRUE);
                }

                public function get_services($type = NULL)
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $query = $this->db->table('logiref_services')
                                        ->select('logiref_services.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }
                public function get_regions($type = NULL)
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                        $query = $this->db->table('logiref_regions')
                                        ->select('logiref_regions.*')
                                        ->where($st)
                                        ->orderBy('Id_0', 'ASC')
                                        ->get();
                        return $query->getResult();
                }

                public function get_recettes_array($list, $type = NULL)
                {
                        $st = " Status_2='1' AND Account_3='0' AND Code_7 IN ('$list')";
                        if ($type == 'RFTRESD') {
                                $st .= " AND (Type_4='RFTRESD' || (Type_4='TRESOR' AND Beneficiare_5='DGDA'))";
                        } else {
                                $st .= " AND (Type_4!='RFTRESD' AND Type_4!='TRESOR')";
                        }
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_recettes');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Beneficiare_5']][] = $row['Code_7'];
                        }
                        return $ddmenu;
                }

                public function get_comptes_array($liste = '')
                {
                        $comptes = array();
                        $comptes[''][''] = '';
                        $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                        if ($liste != '') $st .= " AND Type_4 IN (" . $liste . ")";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_comptes');
                        foreach ($query->result_array() as $row) {
                                if ($row['Agenceid_15'] != "") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15'] . "-" . $row['Compte_6'];
                                else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                if ($row['Clef_7'] != "") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-" . $row['Clef_7'];
                        }
                        return $comptes;
                }

                /*
                * Save Information: insert or update an array
                * Use: inserting or updating
                * List
                *  *************************************************************************************************************************SECTION 5
                */

                public function save_documents($data, $id)
                {
                        $this->set_table('logiref_seguce_documents', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_ipaddress($data, $id)
                {
                        $this->set_table('logiref_address_ip', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_taxe($data, $id)
                {
                        $this->set_table('logiref_recettes', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_service($data, $id)
                {
                        $this->set_table('logiref_services', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_parametre($data, $id)
                {
                        $this->set_table('logiref_parametres', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_beneficiaries($data, $id)
                {
                        $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
                public function save_region($data, $id)
                {
                        $this->set_table('logiref_regions', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }

                public function save_users($data, $id) {
                        $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id);
                }
        }