<?php
namespace Modules\Logiref\Models;

use App\Models\MY_Transaction;
use stdClass;

class TaxesModel extends MY_Transaction{
	
        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */

        protected $table            = 'logiref_comptes'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
    
        public $types_declaration = array(
                "en"=>'',
                "fr"=> array(
                    "1"=>'Imp&ocirc;t sp&eacute;cial sur les profits exc&eacute;dentaires.',
                    "2"=>'D&eacute;claration mensuelle unique des imp&ocirc;ts...',
                    "3"=>'Quotite trimestrielle de l\'imp&ocirc;t professionnel sur les r&eacute;mun&eacute;rations du personnel...',
                    "4"=>'La taxe sur la valeur ajout&eacute;e',
                    "6"=>'Imatriculation V&eacute;hicule'
            )
        );
        
        public $types_declarations = array(
                "1"=>'D&eacute;clarataion (DGI)',
                "2"=>'Bulletin de liquidation (DGDA)',
                "3"=>'Note de perception (DGRAD)',
                ""=>''
        );
        public $devises = array(
                            ''=>'', 
                            'CDF' => 'CDF', 
                            'USD' => 'USD'
                        );
        
        public $forfaits = array(
                            ''=>'', 
                            '1' => '6', 
                            '2' => '9'
                           
                        );
        public  $regimes = array(
                    "en"=>'',
                    "fr"=> array(
                        "1"=>'Droit commun',
                        "2"=>'Particulier',
                        ""=>''
                    )
        );
        
        public $periodes = array(
                    ''=>"",
                    '1'=>"Premier trimestre",
                    '2'=>"Deuxi&egrave;me trimestre",
                    '3'=>"Troisi&egrave;me trimestre",
                    '4'=>"Quatri&egrave;me trimestre",
        );
        
        public $modes = array(
                    ''=>"",
                    '1'=>"Esp&egrave;ce",
                    '2'=>"Ch&egrave;que certifi&eacute;",
                    '3'=>"Virement",
        );
        
        public $categories = array(
                ''=>"",
                '1'=>"Salari&eacute;s domestiques",
                '2'=>"Salari&eacute;s Micro-entreprises"
        );
        
        public $statut = array(
                ''=>"",
                '1'=>"Nouvelle demande en cours",
                '2'=>"Traitement en cours",
                '3'=>"Rejeter",
                '4' => "Octroyer"
        );
        
        public $statut_denonciation = array(
                '1'=>"Nouveau",
                '2'=>"Traitement encours",
                '3'=>"Rejet&eacute;",
                '4'=>"Valid&eacute;",
                '5'=>"Recompens&eacute;"
        );
        
        public $statuscolor = array(
            
            '1'=>'label-ongoing',
            '2'=>'label-upcoming',
            '3'=>'label-danger',
            '4'=>'label-completed',
            '5'=>'label label-info'
        );
        
        public $types_person = array(
                ''=>"",
                '1'=>"Personne physique",
                '2'=>"Personne morale"
        );
        
        
        public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_paiement_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Logirefid_4 = round(1000,9999).mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')).$this->session->userdata['account_id'].$this->session->userdata['user_id'];
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Chequeid_6 = '';
                        $obj->Isysid_7 = '';
                        $obj->Rtgsid_8 = '';
                        $obj->Makerid_9 = '';

                        $obj->Checkerid_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Devise_12 = '';
                        $obj->Nif_13 = '';
                        $obj->Designation_14 = '';
                        $obj->Beneficaire_15 = '';
                        $obj->Service_16 = '';
                        $obj->Typerecette_17 = '';
                        $obj->Mode_19 = '';
                        $obj->Artbudgetaire_18 = '';

                        $obj->Agence_20 = '';
                        
                        $obj->Guichet_21 = '';
                        $obj->Contrevaleur_22 = ''; // Tjrs en CDF
                        $obj->Commission_23= '';
                        $obj->Devise_24= '';
                        $obj->Notetype_25 = '5';
                        $obj->Noteid_26 = '';
                        $obj->Notedate_27 = gmdate('Y-m-d H:i:s');
                        $obj->Notemontant_28 = '';
                        $obj->Notedevise_29 = '';

                        $obj->Notereference_30 = ''; 
                        $obj->Datevaleur_31 = gmdate('Y-m-d H:i:s');
                        $obj->Reference_32 = '';
                        $obj->Compte_33 = '';
                        $obj->Devise_34 = '';
                        $obj->Changement_35 = ''; //Date
                        $obj->Validation_36 = '';
                        $obj->Integration_37 = '';
                        $obj->Reversement_38 = '';
                        $obj->Nivellement_39 = '';

                        $obj->Suppression_40 = '';
                        $obj->Taux_41 = '';
                        $obj->Devise_42 = '';
                        $obj->Attestation_43 = '';
                        $obj->Sydonia_44 = '0';
                        $obj->Tresor_45 = '0';                        

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_paiements p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function get_souscription_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Identifier_7= '';
                        $obj->Code_8= '';
                        $obj->Clientid_9= '';
                        $obj->Starting_10= '';
                        $obj->Expiring_11= '';
                        $obj->Category_12= '';
                        $obj->Firstname_13= '';
                        $obj->Lastname_14= '';
                        $obj->Birthdate_15= '';
                        $obj->Session_16= '';
                        $obj->Authorities_17= '';
                        $obj->Validation_18= '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_subscriptions', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function get_prospect_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Denomination_7= '';
                        $obj->Category_8= '';
                        $obj->Telephone_9= '';
                        $obj->Email_10= '';
                        $obj->Siege_social_11= '';
                        $obj->Site_exploitation_12= '';
                        $obj->Idnat_13= '';
                        $obj->Rccm_14= '';
                        $obj->Idfiscal_15= '';
                        $obj->Activities_16= '';
                        $obj->Comments_17= '';
                        $obj->Latitude_18= '';
                        $obj->Longitude_19= '';
                        $obj->Controler_20= '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_prospects', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function  get_client_info($oid =NULL)
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1= gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';
                        $obj->Account_3= $this->session->userdata['account_id'];
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Denomination_7='';
                        $obj->Acronyme_8='';
                        $obj->Telephone_9='';
                        $obj->Email_10='';
                        $obj->Siege_social_11='';
                        $obj->Site_exploitation_12='';
                        $obj->Idnat_13='';
                        $obj->Rccm_14='';
                        $obj->Idfiscal_15='';
                        $obj->Engagement_16='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_clients  d', 'd.Id_0', 'd.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function  get_subjugation_info($sid =NULL)
        {
                if($sid == NULL)
                {
                        $subjugation = new stdClass();
                        $subjugation->Id_0 = '';
                        $subjugation->Date_1='';
                        $subjugation->Status_2='';
                        $subjugation->Denomination_7='';
                        $subjugation->Initials_8='';
                        $subjugation->Phone_9='';
                        $subjugation->Mail_10='';
                        $subjugation->Site_social_address_11='';
                        $subjugation->Site_exp_address_12='';
                        $subjugation->Id_nat_13='';
                        $subjugation->RCMM_14='';
                        $subjugation->NIF_15='';
                        $subjugation->Engagement_16='';
                        $subjugation->Responsable_17='';
                        $subjugation->First_turnover_18='';
                        $subjugation->Second_turnover_19='';
                        $subjugation->Validation_20='';
                        $subjugation->Comment_21='';
                        $subjugation->Types_22='';
                        $subjugation->Contacts_23='';
                        return $subjugation;
                }
                else
                {
                        $this->set_table('logiref_subjugations s', 's.Id_0', 's.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $sid), TRUE);
                }
        }
        
        public function  get_declaration_info($did =NULL)
        {
                if($did == NULL)
                {
                        $declaration = new stdClass();
                        $declaration->Id_0 = '';
                        $declaration->Date_1='';
                        $declaration->Status_2='';
                        $declaration->Account_3='';
                        $declaration->Creator_4='';
                        $declaration->Changes_5='';
                        $declaration->Changer_6='';
                        $declaration->Content_7='';
                        $declaration->Category_8='';
                        $declaration->Information_9='';
                        $declaration->Amount_10='';
                        $declaration->Currency_11='';
                        $declaration->Period_12='';
                        $declaration->Deadline_13='';
                        $declaration->Reference_14='';
                        $declaration->Provinceid_15='';
                        $declaration->Content_16='';
                        $declaration->Province_17='';
                        return $declaration;
                }
                else
                {
                        $this->set_table('logiref_declarations  d', 'd.Id_0', 'd.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $did), TRUE);
                }
        }
        public function get_payment_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Subscriber_7= '';
                        $obj->Amount_8= '';
                        $obj->Currency_9= '';
                        $obj->Declaration_10= '';
                        $obj->Channel_11= '';
                        $obj->Reference_12= '';
                        $obj->Means_13= '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_payments', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function get_controller_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Identifier_7= '';
                        $obj->Code_8= '';
                        $obj->Matricule_9= '';
                        $obj->User_10= '';
                        $obj->Service_11= '';
                        $obj->Province_12= '';
                        
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_controllers', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function get_penalitie_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Subscriber_7= '';
                        $obj->Controler_8= '';
                        $obj->Date_9= '';
                        $obj->Amount_10= '';
                        $obj->Currency_11= '';
                        $obj->Penalities_12= ''; 
                        $obj->Paiement_13= '';
                        $obj->Deadline_14= '';
                        $obj->Comments_15= '';
                        
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_fines', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        public function get_denunciation_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Subscriber_7= '';
                        $obj->Name_8= '';
                        $obj->Subjet_9= '';
                        $obj->Address_10= '';
                        $obj->Activities_11= '';
                        $obj->Category_12= '';
                        $obj->Confirmation_13= '';
                        $obj->Comments_14= '';
                        $obj->Regies_15='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_denunciations', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_reclamation_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6= '';
                        $obj->Name_7= '';
                        $obj->Subjet_8= '';
                        $obj->Comments_9= '';
                        $obj->Activities_10= '';
                        $obj->Address_11='';
                        $obj->Regies_12='';
                        $obj->Confirmations_13='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_reclamations', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 3
        */
   
        public function get_souscriptions($type=NULL)
        {
                if($type != NULL)
                {
                        $this->table = '';
                        $this->db->select('logiref_subscriptions.*', 'logiref_subscriptions.Id_0 ASC');
                        $this->db->from('logiref_subscriptions');
                        $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }
                else
                {
                        $st = "S.Status_2='2'";
                        $query = $this->db->select(' C.Denomination_7, C.Id_0, C.Siege_social_11, C.Site_exploitation_12, C.Idnat_13, C.Rccm_14, C.Idfiscal_15, S.Id_0, S.Firstname_13, S.Validation_18, S.Lastname_14')
                        ->from('logiref_clients as C')  
                        ->join('logiref_subscriptions as S', 'C.Id_0 = S.Clientid_9') 
                        ->where($st, NULL, FALSE)
                        ->get();
                        return $query->result();
                }
        }
        
        public function get_subjugations($type = NULL)
        {
                if($type == "tous")
                {
                    $this->table = '';
                    $this->db->select('logiref_subjugations.*', 'logiref_subjugations.Id_0 ASC');
                    $this->db->from('logiref_subjugations');
                    $st = "Status_2!='0'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
                else
                {
                    $this->table = '';
                    $this->db->select('logiref_subjugations.*', 'logiref_subjugations.Id_0 ASC');
                    $this->db->from('logiref_subjugations');
                    $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
        }
    
        public function  get_prospects()
        {
                $this->table = '';
                $this->db->select('logiref_prospects.*', 'Id_0 ASC');
                $this->db->from('logiref_prospects'); 
                $st = " Status_2!='0' AND (Account_3='" . $this->session->userdata['account_id'] . "' )";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_clients()
        {
                $this->table = '';
                $this->db->select('logiref_clients.*', 'logiref_clients.Id_0 ASC');
                $this->db->from('logiref_clients');
                $st = "Status_2='2' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_controllers()
        {
                $this->table = '';
                $this->db->select('logiref_controllers.*', 'Id_0 ASC');
                $this->db->from('logiref_controllers'); 
                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_penalites()
        {
                $this->table = '';
                $this->db->select('logiref_fines.*', 'Id_0 ASC');
                $this->db->from('logiref_fines'); 
                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_client_by_account_id()
        {
                $aid = $this->session->userdata['account_id'];
                $this->set_table('logiref_clients', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' => $aid), TRUE);
        }
        
        public function get_subjugation_by_account()
        {
            //die;
            $aid = $this->session->userdata['account_id'];
            $this->set_table('logiref_subjugations', 'Id_0', 'Id_0 DESC');
            return $this->get_by(array('Account_3' =>$aid), TRUE);
        }
        
        public function get_payments()
        {
                $this->table = '';
                $this->db->select('logiref_payments.*', 'logiref_payments.Id_0 ASC');
                $this->db->from('logiref_payments');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        
        public function get_denunciations($type = NULL, $status = NULL)
        {
                if($type=='tous')
                {
                        $this->table = '';
                        $this->db->select('logiref_denunciations.*', 'logiref_denunciations.Id_0 ASC');
                        $this->db->from('logiref_denunciations');
                        $st = "Status_2 != '0'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }
                else
                {
                        $this->table = '';
                        $this->db->select('logiref_denunciations.*', 'logiref_denunciations.Id_0 ASC');
                        $this->db->from('logiref_denunciations');
                        //$st = "Status_2 = '" . $status . "' AND Regies_15='" .$_SESSION['Logiref_regies'] . "'";
                        $st = "Status_2 = '" . $status . "' AND Account_3='" .$this->session->userdata['account_id']  . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        return $this->get_all();
                }
        }
        
        public function get_declarations($type = NULL)
        {
                if($type == "tous")
                {
                    $this->table = '';
                    $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ASC');
                    $this->db->from('logiref_declarations');
                    $st = "Status_2!='0'";
                    if($_SESSION['Logiref_role']=='3' || $_SESSION['Logiref_role']=='4') $st .= " AND Province_17='".$_SESSION['Logiref_province']."'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
                else
                {
                    $this->table = '';
                    $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ASC');
                    $this->db->from('logiref_declarations');
                    $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                    if($_SESSION['Logiref_role']=='3' || $_SESSION['Logiref_role']=='4') $st .= " AND Province_17='".$_SESSION['Logiref_province']."'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
                
        }
        
        public function get_reclamations($type = NULL, $status = NULL)
        {
                if($type == 'tous')
                {
                    $this->table = '';
                    $this->db->select('logiref_reclamations.*', 'logiref_reclamations.Id_0 ASC');
                    $this->db->from('logiref_reclamations');
                    $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
                else
                {
                    $this->table = '';
                    $this->db->select('logiref_reclamations.*', 'logiref_reclamations.Id_0 ASC');
                    $this->db->from('logiref_reclamations');
                    $st = "Status_2 ='" .$status. "' AND Regies_12='" . $_SESSION['Logiref_regies'] . "'";
                    $this->db->where($st, NULL, FALSE);
                    $this->db->order_by('Id_0');
                    return $this->get_all();
                }
                
        }
        
        public function check_phone_exist($number) 
        {
                $this->table = '';
                $this->db->select('Identifier_7', 'logiref_subscriptions.Id_0 ASC');
                $this->db->from('logiref_subscriptions');
                $st = "Status_2=1 AND Account_3='" . $this->session->userdata['account_id'] . "' AND Identifier_7 = '".$number."'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 ASC');
                return $this->get_all();
        }
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */
        
        
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                if($item=="categories")
                {
                        $type= $arg;
                        
                        if($type == 'toutes') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'denonciation') $st = " Object_4='Denunciation'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'declare') $st = "Object_4='Declaration'   AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'chanel') $st = " Object_4='Channel'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'prospect') $st = " Object_4='Prospect'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'account') $st = " Object_4='Account'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'fines') $st = " Object_4='Fines'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if($type == 'subscriber') $st = " Object_4='Subscriber'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_categories');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Fr_6'];
                        }
                        return $ddmenu;
                }
                elseif($item=="means")
                {
                        $st = "Status_2='1' AND(Account_3='" . $this->session->userdata['account_id'] . "'" ;
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('logiref_means');
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->result_array() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Operator_8'];
                        }
                        return $ddmenu;
                }
        }
        
                
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */
        
        public function save_souscription($data, $id)
	{
		$this->set_table('logiref_subscriptions', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_controller($data, $id)
	{
		$this->set_table('logiref_controllers', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_prospects($data, $id)
	{
		$this->set_table('logiref_prospects', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}	
        
        public function save_denonciation($data, $id)
	{
		$this->set_table('logiref_denunciations', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_penalite($data, $id)
	{
		$this->set_table('logiref_fines', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_subjugation($data, $id)
	{
		$this->set_table('logiref_subjugations', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_client($data, $id) 
        {
                $this->set_table('logiref_clients', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_reclamation($data, $id) 
        {
                $this->set_table('logiref_reclamations', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

}