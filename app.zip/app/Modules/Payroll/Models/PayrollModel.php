<?php

namespace Modules\Payroll\Models;

use App\Models\MY_Payroll;
use CodeIgniter\Model;

class PayrollModel extends MY_Payroll
{

    public function check_if_file_exists($file_id)
    {
                $st="File_id_7='".$file_id."' AND (Status_2=1 OR Status_2=2)";

                $builder=$this->db->table('logiref_integration_sftp_files')
                        ->select('*')
                        ->where($st)
                        ->orderBy('Id_0 DESC')
                        ->get();

                $result = $builder->getRowArray();
                
                return $result;
    }  
    public function migrate_files_data($files,$single=TRUE)
    {   
                $file_data=array();
                $files_list=array();

                if($files!=NULL)
                {
                        if($single)
                        {
                                $file_data['Date_1']=gmdate('Y-m-d h:i:s');
                                $file_data['File_id_7']=$files['file_id'];
                                $file_data['Filename_8']=$files['file_name'];
                                $file_data['Download_date_9']=$files['download_date'];
                                $file_data['File_content_10']=$files['file_content'];
                                $file_data['Has_error_11']=filter_var($files['has_error'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                                $file_data['Error_text_12']=$files['error_text'];
                                $file_data['Is_processed_13']=filter_var($files['is_processed'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                                $file_data['Id_subscriber_14']=$files['partner_id'];
                                $file_data['Partner_name_15']=$files['partner_name'];
                                $file_data['Upload_date_16']=$files['upload_date'];
                                $file_data['Results_17']=(isset($files['data']) && $files['data']!=NULL)?json_encode($files['data']):"";
                                $file_data['File_source_18']=(isset($files['file_source']) && $files['file_source']!=NULL)?$files['file_source']:"API";

                                return $file_data;
                        }
                        else
                        {
                                foreach($files as $file)
                                {
                                        $file_data['Date_1']=gmdate('Y-m-d h:i:s');
                                        $file_data['File_id_7']=$file['file_id'];
                                        $file_data['Filename_8']=$file['file_name'];
                                        $file_data['Download_date_9']=$file['download_date'];
                                        $file_data['File_content_10']=$file['file_content'];
                                        $file_data['Has_error_11']=filter_var($file['has_error'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                                        $file_data['Error_text_12']=$file['error_text'];
                                        $file_data['Is_processed_13']=filter_var($file['is_processed'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                                        $file_data['Id_subscriber_14']=$file['partner_id'];
                                        $file_data['Partner_name_15']=$file['partner_name'];
                                        $file_data['Upload_date_16']=$file['upload_date'];
                                        $file_data['Results_17']=(isset($file['data']) && $file['data']!=NULL)?json_encode($file['data']):"";
                                        $file_data['File_source_18']=(isset($file['file_source']) && $file['file_source']!=NULL)?$file['file_source']:"API";
                                        array_push($files_list,$file_data);
                                        
                                }
                                return $files_list;
                        }
                        
                }
              
    }  

    public function migrate_file_details_data($file_details)
    {
                $details = array();
                if($file_details != NULL)
                {
                        $details['Id_0']='';
                        $details['Date_1']=gmdate('Y-m-d h:i:s');
                        $details['Status_2']=1;
                        $details['Account_3']=$this->session->userdata['account_id'];
                        $details['Creator_4']=(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role']==4)?$this->session->userdata['user_id']:'';
                        $details['Changer_5']=(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role']==3)?$this->session->userdata['user_id']:'';
                        $details['Changes_6']=(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role']==3)?gmdate('Y-m-d h:i:s'):'';
                        $details['File_id_7']=$file_details['original_file_id'];
                        $details['Line_id_8']=$file_details['line_id'];
                        $details['Debit_account_9']=$file_details['debit_account'];
                        $details['Credit_account_10']=$file_details['credit_account'];
                        $details['Debit_amount_11']=$file_details['debit_amount'];
                        $details['Designation_12']=$file_details['remark_1']." ".$file_details['remark_2'];
                        $details['Motif_13']=$file_details['motif'];
                        $details['Is_processed_14']=filter_var($file_details['is_processed'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                        $details['Is_errored_15']=filter_var($file_details['is_errored'],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE);
                        $details['Error_text_16']=is_array($file_details['error_text'])?json_encode($file_details['error_text']):$file_details['error_text'];
                        $details['Branch_code_17']=$file_details['credit_account_branch_code'];
                }
                return $details;
    }

    public function get_file_by_id($id)
    {
                $this->set_table("logiref_integration_sftp_files","Id_0","Id_0 DESC");
                return $this->get_by(array('Id_0'=>$id),TRUE);
    }
    public function get_file_by_fileid($file_id)
    {
                $this->set_table("logiref_integration_sftp_files","Id_0","Id_0 DESC");
                return $this->get_by(array('File_id_7'=>$file_id),TRUE);
    }
    public function get_count_integration_files($status=null)
    {
                $st="CAST(Date_1 as date)=CURDATE()";
                if($status=="pending")
                {
                        $st.=" AND Status_2=2 AND Is_processed_13=0";
                }
                elseif($status=="validated")
                {
                        $st.=" AND Status_2=2 AND Is_processed_13=1";
                }
                else
                {
                        $st.=" AND Status_2=2";
                }

                $row_count=$this->db->table('logiref_integration_sftp_files')
                ->where($st)
                ->countAllResults();

                return $row_count;
    }
    public function get_count_integration_files_by_frequency($frequency,$value=null,$status=array())
    {
                $st="";

                if($frequency=='daily')
                {
                        // $today=gmdate('d');
                        $st.="day(Date_1)=DAY(CURDATE())";
                }
                elseif($frequency=='weekly')
                {
                        $st.="File_source_18='weekly'";
                }
                elseif($frequency=='monthly')
                {
                        $st.="month(Date_1)='".$value."'";
                }
                elseif($frequency=='yearly')
                {
                        $st.="year(Date_1)='".$value."'";
                }

                if($value!=null && in_array($status,array('pending','validated','errored','all')))
                {
                        if($status=='pending')
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=0 ";
                        }
                        elseif($status=='validated')
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=1 ";
                        }
                        elseif($status=='errored')
                        {
                                $st.=" AND (Status_2=5 AND Is_processed_13=0) || (Status_2=2 AND Is_processed_13=5) || (Status_2=5 AND Is_processed_13=5) ";
                        }
                        elseif($status=='all')
                        {
                                $st.=" AND Status_2<>0 ";
                        }
                }

                $row_count=$this->db->table('logiref_integration_sftp_files')
                ->where($st)
                ->countAllResults();

                return $row_count;

    }
    public function get_montant_total_files()
    {
                $st="CAST(Date_1 as date)=CURDATE()";

                $total=0;

                $file_contents=$this->db->table('logiref_integration_sftp_files')
                ->select('logiref_integration_sftp_files.File_content_10')
                ->where($st)
                ->get()->getResultArray();

                foreach($file_contents as $file_content)
                {
                        $content=explode(';',$file_content['File_content_10']);
                        $total=$total+$content[2];
                }

                return $total;
    }

    public function get_file_details($file_id)
    {
                $st="(Status_2=1 OR Status_2=2 OR Status_2=5) AND File_id_7='".$file_id."'";
                $builder=$this->db->table('logiref_integration_sftp_file_details')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResult();

                return $results;
    }
    public function get_nvalidated_file_details($file_id)
    {
                $st="(Status_2=1 OR  Status_2=5) AND File_id_7='".$file_id."'";
                $builder=$this->db->table('logiref_integration_sftp_file_details')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResult();

                return $results; 
    }
    public function get_validated_file_details($file_id)
    {
                $st="Status_2=2 AND Is_processed_14=1  AND File_id_7='".$file_id."'";
                $builder=$this->db->table('logiref_integration_sftp_file_details')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResult();

                return $results; 
    }
    public function get_file_details_by_lineid($line_id)
    {
                $st="Line_id_8='".$line_id."'";
                $builder=$this->db->table('logiref_integration_sftp_file_details')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $result = $builder->getRow();

                return $result;
    }
    public function get_integration_sftp_files($is_processed=null,$file_id=null,$start_upload_date=null,$end_upload_date=null,$start_date=null,$end_date=null,$status=null)
    {
                $st="Status_2 > 0";
                if($is_processed!=NULL) $st.=" AND Is_processed_13='".$is_processed."'";
                if($file_id !=NULL) $st.=" AND File_id_7='".$file_id."'";
                if($start_upload_date!=NULL) $st.=" AND CAST(Upload_date_16 as date)='".$start_upload_date."' OR (CAST(Upload_date_16 as date) BETWEEN'".$start_upload_date."' AND '".$end_upload_date."')";

                if($start_date!=NULL) $st.=" AND CAST(Date_1 as date)='".$start_date."' OR (CAST(Date_1 as date) BETWEEN'".$start_date."' AND '".$end_date."') ";

                if($status!=null)
                {
                        if($status=="pending")
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=0";
                        }
                        elseif($status=="validated")
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=1";
                        }
                }

                $builder=$this->db->table('logiref_integration_sftp_files')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResultArray();
             
                return $results;
    }

    public function get_files_nvalidated()
    {
                $st="Status_2=2 AND Is_processed_13=0";
                $builder=$this->db->table('logiref_integration_sftp_files')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResultArray();

                return $results;
    }

    public function get_files_nvalidated_cron()
    {
                $st="(Status_2=2 AND Is_processed_13=0) OR (Status_2=5 AND Is_processed_13=0) OR (Status_2=2 AND Is_processed_13=5)";
                $builder=$this->db->table('logiref_integration_sftp_files')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResultArray();

                return $results;
    }

    public function get_files_equalize()
    {
                $st="Status_2=5 || (Status_2=2 AND Is_processed_13=5)";
                $builder=$this->db->table('logiref_integration_sftp_files')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC')
                ->get();

                $results = $builder->getResultArray();

                return $results;
    }

    public function get_files_by_frequency($frequency,$value=null,$status=array(),$limit=null)
    {
                $st="";

                if($frequency=='daily')
                {
                        // $today=gmdate('d');
                        $st.="day(Date_1)=DAY(CURDATE())";
                }
                elseif($frequency=='weekly')
                {
                        $st.="File_source_18='weekly'";
                }
                elseif($frequency=='monthly')
                {
                        $st.="month(Date_1)='".$value."'";
                }
                elseif($frequency=='yearly')
                {
                        $st.="year(Date_1)='".$value."'";
                }

                if($value!=null && in_array($status,array('pending','validated','errored','all')))
                {
                        if($status=='pending')
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=0 ";
                        }
                        elseif($status=='validated')
                        {
                                $st.=" AND Status_2=2 AND Is_processed_13=1 ";
                        }
                        elseif($status=='errored')
                        {
                                $st.=" AND (Status_2=5 AND Is_processed_13=0) || (Status_2=2 AND Is_processed_13=5) || (Status_2=5 AND Is_processed_13=5) ";
                        }
                        elseif($status=='all')
                        {
                                $st.=" AND Status_2<>0 ";
                        }
                }

                $builder=$this->db->table('logiref_integration_sftp_files')
                ->select('*')
                ->where($st)
                ->orderBy('Id_0 DESC');
                if($limit!=null)
                {
                        $builder->limit($limit);
                }

                $results = $builder->get()->getResultArray();

                return $results;

    }

    public function update_file_details_by_lineid($data,$line_id,$file_id=null)
    {
                $builder=$this->db->table('logiref_integration_sftp_file_details');
                return $builder->update($data,['Line_id_8'=>$line_id,'File_id_7'=>$file_id]);
    }

    public function update_file_by_fileid($data,$fileid)
    {
                $builder=$this->db->table('logiref_integration_sftp_files');
                return $builder->update($data,['File_id_7'=>$fileid]);
    }

    public function save_file($data,$id=null)
    {
                $this->set_table("logiref_integration_sftp_files","Id_0","Id_0 DESC");
                return $this->saveData($data,$id);
    }
    public function save_file_details($data,$id=null)
    {
                $this->set_table("logiref_integration_sftp_file_details","Id_0","Id_0 DESC");
                return $this->saveData($data,$id);
    }
    
}
