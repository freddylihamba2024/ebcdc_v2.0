<?php

namespace Modules\Payroll\Controllers;

use App\Controllers\BaseController;
use Modules\Payroll\Models\PayrollModel;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Sftp\Payroll\Controllers\SftpPayroll;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Controllers\TemenosGateway;

class Payroll extends BaseController
{
    
        /*
         * Presentation:
         * Last update:
         * By Donald on the 06.08.2024
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('files', 'file_details','nvalidated','equalize'); //Menus of the module
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'payroll';
        public $folder = 'payroll';
        public $role;
        public $mail;
        public $mainModel;
        private $payrollModel=null;
        private $sftpPayroll=null;
        private $comptabilisation=null;
        private $comptabilisationModel=null;
        private $temenosGateway=null;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->payrollModel=new PayrollModel();
                $this->sftpPayroll=new SftpPayroll();
                $this->comptabilisation=new Comptabilisation();
                $this->comptabilisationModel=new ComptabilisationModel();
                $this->temenosGateway=new Temenos();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'bank';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                // $this->data['documents'] = $this->logirefModel->documents;
                // $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                // $this->data['moyens'] = $this->logirefModel->moyens;
                // $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['sidebar'] = $this->sidebars->logiref_payroll($this->data['role']);
          

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }

                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                }
                else 
                {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Payroll\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();    
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "files")
                {
                        $this->data['status']=[''=>'--- Statut du fichier ---',0=>'Non traités',1=>'Traités',2=>'Avec erreurs'];

                        return view("\Modules\Payroll\Views\\".$this->folder."\\".$obj,$this->data);
                }
                elseif($obj=="_files")
                {
                        $data = $_POST;
                        $files=[];
                        
                      /*   $files = $this->payrollModel->get_integration_sftp_files($data['is_processed'],$data['file_id'],$data['start_date'],$data['end_date']);
                        
                        if(!empty($files))
                        {
                                $response_data['code']=200;
                                $response_data['message']="OK";
                                $result=$response_data;
                        }
                        else
                        { */       
                        $payroll_api=$this->sftpPayroll->sftp_get_files($data);
                       
                        $result=json_decode($payroll_api,true);
                        /* } */

                        if(isset($result['code']) && $result['code']==200)
                        {
                                $response_data['code']=200;
                                $response_data['message']=$result['message'];

                                if(isset($result['data']))
                                {
                                        if(isset($result['data']['file_id']))
                                        {
                                                
                                                $file=$this->payrollModel->migrate_files_data($result['data'],TRUE);
                                                $files[]=$file;
                                                
                                        }
                                        else
                                        {
                                                
                                                $files=$this->payrollModel->migrate_files_data($result['data'],FALSE);
                                                
                                        }

                                }

                                $response_data['files']=$files;
								
                        }
                        elseif(isset($result['code']) && $result['code']==401)
                        {
                                 $response_data['code']=401;
                                 $response_data['message']="Échec d’authentification";
                        }    
                        elseif(isset($result['code']) && $result['code']==403)
                        {
                                 $response_data['code']=403;
                                 $response_data['message']="Identifiants invalides";
                        }  
                        elseif(isset($result['code']) && $result['code']==404)
                        {
                                 $response_data['code']=404;
                                 $response_data['message']="Le point de terminaison demandé n’est pas disponible.";
                        }  
                        elseif(isset($result['code']) && ($result['code']==506 || $result['code']==500 || $result['code']==305))
                        {
                                 $response_data['code']=$result['code'];
                                 $response_data['message']=$result['message'];
                        }     
                        $this->data['response']=$response_data;
                        // return $this->response->setJSON($response_data);
                        return view("\Modules\Payroll\Views\payroll\_files",$this->data);
                        // return view("\Modules\Payroll\Views\\".$this->folder."\\".$obj,$this->data);
                }
                elseif($obj=="file-details")
                {
                        $data=$_POST;

                        $check=$this->check_request($obj,$data);
						
                        if($check==false)
                        {
                                $response_data['code']=400;
                                $response_data['message']="Failed to read the request";
                        }
                        else
                        {
                                $payroll_api=$this->sftpPayroll->sftp_get_file_details($data);
                                $result=json_decode($payroll_api,true);
                        }
						
                        if(isset($result['code']) && $result['code']==200)
                        {
                                $response_data['code']=200;
                                $response_data['message']=$result['message'];
                                $response_data['lines']=$result['data'];
                                $response_data['fileInfo']=$data;

                                $file=$this->payrollModel->check_if_file_exists($data['File_id_7']);

                                if($file==NULL || empty($file))
                                {
                                        $data_to_save=(array)$data;
                                        $data_to_save['Results_17']=json_encode($result['data']);
                                        $id=$this->payrollModel->save_file($data_to_save);
                                }
                                else
                                {
                                        $data_to_save['Results_17']=json_encode($result['data']);
                                        $this->payrollModel->save_file($data_to_save,$data['File_id_7']);
										
                                        $response_data['fileInfo']=(array)$file;
                                }
                        }
                        elseif(isset($result['code']) && $result['code']==401)
                        {
                                 $response_data['code']=401;
                                 $response_data['message']="Échec d’authentification";
                        }    
                        elseif(isset($result['code']) && $result['code']==403)
                        {
                                 $response_data['code']=403;
                                 $response_data['message']="Identifiants invalides";
                        }  
                        elseif(isset($result['code']) && $result['code']==404)
                        {
                                 $response_data['code']=404;
                                 $response_data['message']="Le point de terminaison demandé n’est pas disponible.";
                        }  
                        elseif(isset($result['code']) && ($result['code']==506 || $result['code']==500 || $result['code']==305))
                        {
                                 $response_data['code']=$result['code'];
                                 $response_data['message']=$result['message'];
                        }     
                        $this->data['response']=$response_data;
                        return view("\Modules\Payroll\Views\payroll\_file_details",$this->data);
                        // return view("\Modules\Payroll\Views\\".$this->folder."\\_file_details",$this->data);
                }
                elseif($obj=="nvalidated")
                {
                        $nvalidated_files=$this->payrollModel->get_files_nvalidated();
                        $files_list=array();
                        $nvalidate_file=array();
   
                        foreach($nvalidated_files as $nvalidated_file)
                        {
                                $instructions=$this->comptabilisationModel->get_instructions_sftp_payroll($nvalidated_file['Id_0']);
                                $file=$nvalidated_file;

                                $nvalidate_file['fileInfo']=$file;
                                $nvalidate_file['lines']=$instructions;
                                array_push($files_list,$nvalidate_file);

                        }
                        
                        $this->data['nvalidated_files']=$files_list;
                        return view("\Modules\Payroll\Views\\".$this->folder."\\".$obj,$this->data);
                }
                elseif($obj=="equalize")
                {
                        $equalize_files=$this->payrollModel->get_files_equalize();
                        $files_list=array();
   
                        foreach($equalize_files as $equalize_file)
                        {
                                $instructions=$this->comptabilisationModel->get_instructions_sftp_payroll($equalize_file['Id_0']);
                                $file=$equalize_file;

                                $equalize_file['fileInfo']=$file;
                                $equalize_file['lines']=$instructions;

                                array_push($files_list,$equalize_file);
                        }

                        $this->data['equalize_files']=$files_list;

                        return view("\Modules\Payroll\Views\\".$this->folder."\\".$obj,$this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                
                if ($obj == "file-details")
                {
                        $response_data=array();

                        $file=(array)$this->payrollModel->get_file_by_fileid($id);
                        
                        if($file != NULL)
                        {
                         
                                $file_status_api=$this->sftpPayroll->verify_file_status($file);
                                $file_status_result=json_decode($file_status_api,true);
                          

                                if(isset($file_status_result['code']) && $file_status_result['code']==200)
                                {
                                        if(isset($file_status_result['status']) && $file_status_result['status']==true)
                                        {
                                                $file['Status_2']=2;
                                                $file['Is_processed_13']=1;
                                        }
                                        else
                                        {
                                                $file['Status_2']=1;
                                        }
                                }
                                else
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Une erreur est survenue lors de la vérification du statut du fichier";
                                        return $this->response->setJSON($response_data);
                                }
                                
                                $file_lines=json_decode($file['Results_17'],true);
                               
                                if($file['Status_2'] == 1)
                                {
                                        $instructions_payroll = $this->comptabilisation->generate_instructions_sftp_payroll($file,$file_lines);
                                        // var_dump($instructions_payroll);die;
                                        if(!empty($instructions_payroll))
                                        {
                                                //check if instructions already exist
                                                $existent_instructions=$this->comptabilisationModel->get_instructions_sftp_payroll($file['Id_0']);
                                               
                                                if(empty($existent_instructions))
                                                {
                                                        //Delete existent instructions before saving new ones
                                                        $this->comptabilisationModel->save_instructions_sftp_payroll($file,$instructions_payroll);
                                                }

                                                //updating files informations
                                                $data_to_update['Status_2']=2;
                                                $result=$this->payrollModel->save_file($data_to_update,$file['Id_0']);
                                             
                                                if($result > 0)
                                                {
                                                        $response_data['code']=200;
                                                        $response_data['message']="Enregistrement effectué avec succès";
                                                }
                                                else
                                                {
                                                        $response_data['code']=400;
                                                        $response_data['message']="Une erreur est survenue lors de l'enregistrement";
                                                }
                                        }
                            
                                        
                                        if(isset($response_data['code']) && $response_data['code']==200)
                                        {
                                                //check if file details already exist
                                                $existent_lines = $this->payrollModel->get_file_details($file['File_id_7']);
                                                if(empty($existent_lines))
                                                {
                                                        foreach($file_lines as $file_line)
                                                        {
                                                                $data_line=$this->payrollModel->migrate_file_details_data($file_line);
                                                                $this->payrollModel->save_file_details($data_line);
                                                        }
                                                } 
                                        }
                                        else
                                        {
                                                $response_data['code']=400;
                                                $response_data['message']="Une erreur est survenue lors de l'enregistrement des détails du fichier";
                                        }
                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==1)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Le fichier a été déjà traité";
                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==0)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Ce fichier existe déjà mais son traitement est incomplet. Veuillez procéder à la validation des détails du fichier.";
                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==5)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Le traitement ou la validation de ce fichier a échoué précédemment. Veuillez contacter le validateur pour la régularisation.";
                                }
                                else
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Statut du fichier inconnu. Veuillez contacter l'administrateur.";
                                } 
                        }
                        
                        return $this->response->setJSON($response_data);
                }
                elseif($obj=="validate_file_detail")
                {
                        $data=$_POST;

                        $response_data=array();

                        $file =(array) $this->payrollModel->get_file_by_id($data['file_id']);
                        
                        if($file!=NULL)
                        {
                                $apidata['Id_0']=$data['line']['Id_0'];

                                // $api_response = $this->temenosGateway->virement_payroll_single($apidata);
                                $api_response['code']=200;
                                // var_dump($api_response);die;
                                if(isset($api_response['code']) && $api_response['code']==200)
                                { 
                                        $line = $data['line']['Line_14'];
                                        
                                        $file_detail = $this->data('file-detail',(array)$file,$line);
                                        
                                        $file_detail['Id_0']=$data['line']['Id_0'];
                                        
                                        $response_data = $this->confirm_file_detail($file_detail,$line);
                                }
                                elseif(isset($api_response['code']) && $api_response['code']==412)
                                {
                                        $file['Status_2']=5;
                                        $file['Is_processed_13']=0;
                                        $this->payrollModel->save_file($file,$file['Id_0']);

                                        $response_data['code']=500;
                                        $response_data['message']=$api_response['error_message'];
                                        $response_data['line']=$data['line']['Id_0'];
                                }
                                else
                                {
                                        $file['Status_2']=5;
                                        $file['Is_processed_13']=0;
                                        $this->payrollModel->save_file($file,$file['Id_0']);

                                        $response_data['code']=500;
                                        $response_data['message']="Une erreur est survenue lors de la comptabilisation...";
                                        $response_data['line']=$data['line']['Id_0'];
                                }
                        }
                        else
                        {
                                $response_data['code']=404;
                                $response_data['message']="Le fichier n'existe plus";
                        }
                        return $this->response->setJSON($response_data);
                        
                }
                elseif($obj=="validate_file")
                {
                        $data=$_POST;
                    
                        $response_data=array();
                    
                        $file=(array)$this->payrollModel->get_file_by_fileid($data['file_id']);
                        
                        if($file!=NULL)
                        {

                                $nvalidated_file_details=$this->payrollModel->get_validated_file_details($data['file_id']);
                                $nbr_file_lines=$data['nbr_lines'];
                                
                                if(count($nvalidated_file_details)===count($nbr_file_lines))
                                {
                                        //this function will call the confirm_file function to confirm the file after validation
                                        $response_data=$this->confirm_file($data['file_id']);
                                }
                                else
                                {
                                        $file_to_update['Is_processed_13']=5;
                                        $this->payrollModel->save_file($file_to_update,$file['Id_0']);
												
                                        $response_data['code']=300;
                                        $response_data['message']="Confirmation a échoué car les détails du fichier sont intégrés partiellement";
                                }
                        }
                        else
                        {
                                $response_data['code']=404;
                                $response_data['message']="Le fichier n'existe plus";
                        }
                        return $this->response->setJSON($response_data);
                }
                elseif($obj=="equalize_file_detail")
                {
                        $data=$_POST;

                        $response_data=array();

                        $file =(array) $this->payrollModel->get_file_by_id($data['file_id']);
                        
                        if($file!=NULL)
                        {
                                if(isset($data['line']))
                                {
                                        if($data['line']['Status_2']==2 && $data['line']['Is_processed_14']==5)
                                        {
                                                //Proceed to confirmation detail info 
                                                $line = $data['line']['Line_14'];
                                                $file_detail = $this->data('file-detail',(array)$file,$line);
                                                $file_detail['Id_0']=$data['line']['Id_0'];

                                                $response_data = $this->confirm_file_detail($file_detail,$line);
                                        }
                                        else
                                        {
                                                //Normal regularization process
                                                $apidata['Id_0']=$data['line']['Id_0'];
								
                                                // $api_response = $this->temenosGateway->virement_payroll_single($apidata,"equalize");
                                                $api_response['code']=200;
                                                if(isset($api_response['code']) && $api_response['code']==200)
                                                {
                                                        $line = $data['line']['Line_14'];
                                                        
                                                        $file_detail = $this->data('file-detail',(array)$file,$line);
                                                        $file_detail['Id_0']=$data['line']['Id_0'];
                                                        
                                                        $response_data = $this->confirm_file_detail($file_detail,$line);
                                                }
                                                elseif(isset($api_response['code']) && $api_response['code']==412)
                                                {
                                                        $file['Status_2']=5;
                                                        $file['Is_processed_13']=0;
                                                        $this->payrollModel->save_file($file,$file['Id_0']);

                                                        $response_data['code']=500;
                                                        $response_data['message']=$api_response['error_message'];
                                                        $response_data['line']=$data['line']['Id_0'];
                                                }
                                                else
                                                {
                                                        $file['Status_2']=5;
                                                        $file['Is_processed_13']=0;
                                                        $this->payrollModel->save_file($file,$file['Id_0']);

                                                        $response_data['code']=500;
                                                        $response_data['message']="Une erreur est survenue lors de la comptabilisation...";
                                                        $response_data['line']=$data['line']['Id_0'];
                                                }
                                        }
                                }
                                else
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Le détail du fichier est manquant";
                                }
                                
                        }
                        else
                        {
                                $response_data['code']=404;
                                $response_data['message']="Le fichier n'existe plus";
                        }
                        return $this->response->setJSON($response_data);
                }
                elseif($obj=="regularize_file")
                {
                        $data=$_POST;
                    
                        $response_data=array();
                    
                        $file=(array)$this->payrollModel->get_file_by_fileid($data['file_id']);
                        
                        if($file!=NULL)
                        {
                                // if($file['Status_2'] == 2 && $file['Is_processed_13']==5)
                                // {
                                //         $response_data=$this->confirm_file($data['file_id']);
                                // }
                                // else
                                // {
                                        // $nvalidated_file_details=$this->payrollModel->get_validated_file_details($data['file_id']);
                                $nbr_lines_to_regularize=isset($data['nbr_lines_to_regularize'])?$data['nbr_lines_to_regularize']:0;
                                $nbr_lines_regularized=isset($data['nbr_lines_regularized'])?$data['nbr_lines_regularized']:0;

                                if($nbr_lines_to_regularize===$nbr_lines_regularized)
                                {
                                        //This function will call the confirm_file function to confirm the file after regularization
                                        $response_data=$this->confirm_file($data['file_id']);
                                }
                                else
                                {
                                        $file_to_update['Is_processed_13']=5;
                                        $this->payrollModel->save_file($file_to_update,$file['Id_0']);
                                                                                                
                                        $response_data['code']=300;
                                        $response_data['message']="Confirmation a échoué car les détails du fichier sont intégrés partiellement";
                                }
                                // }
                                
                        }
                        else
                        {
                                $response_data['code']=404;
                                $response_data['message']="Le fichier n'existe plus";
                        }
                        return $this->response->setJSON($response_data);
                }
        }
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */

        public function confirm_file_detail($file_detail,$line_id=null)
        {
                $response_data=array();
                
                if($file_detail!=NULL)
                {

                        $file_detail['is_processed']=1;
                        $file_detail['is_errored']=0;
                        $file_id = $file_detail['original_file_id'];

                        $update_line_api = $this->sftpPayroll->sftp_update_file_details($file_detail);
                        $result_line_api=json_decode($update_line_api,true);

                        if(isset($result_line_api['code']) && $result_line_api['code']==200)
                        {
                                $response_data['code']=200;
                                $response_data['message']="Le détail du fichier est validé avec succès";
                                $response_data['line']=$file_detail['Id_0'];

                                $line_to_update['Status_2']=2;
                                $line_to_update['Is_processed_14']=1;

                                $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);
                        }
                        else
                        {
                                $line_to_update['Is_processed_14']=5;
                                $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);

                                $response_data['code']=300;
                                $response_data['message']="Une erreur est survenue lors de la confirmation du détail du fichier";
                                $response_data['line']=$file_detail['Id_0'];
                        }
                }
                else
                {
                        $response_data['code']=404;
                        $response_data['message']="Le détail du fichier n'existe plus";
                }
                return $response_data;
        }

        public function confirm_file($file_id)
        {
                $response_data=array();

                $file=(array)$this->payrollModel->get_file_by_fileid($file_id);
                
                if($file!=NULL)
                {
                        $api_data['is_processed']=1;
                        $api_data['file_id']=$file['File_id_7'];

                        $update_file_api = $this->sftpPayroll->sftp_update_file($api_data);
                        $result_file_api=json_decode($update_file_api,true);

                        if(isset($result_file_api['code']) && $result_file_api['code']==200)
                        {

                                $response_data['code']=200;
                                $response_data['message']="Le fichier est validé avec succès";

                                $file_to_update['Status_2']=2;
                                $file_to_update['Is_processed_13']=1;

                                $this->payrollModel->save_file($file_to_update,$file['Id_0']);
                        }
                        else
                        {
                                $file_to_update['Is_processed_13']=5;
                                $this->payrollModel->save_file($file_to_update,$file['Id_0']);

                                $response_data['code']=300;
                                $response_data['message']="Une erreur est survenue lors de la confirmation du fichier";
                        }
                }
                else
                {
                        $response_data['code']=404;
                        $response_data['message']="Le fichier n'existe plus";
                }
                return $response_data;
        }

        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "file-detail")
                {
                        $file_results=json_decode($data['Results_17'],true);
                        $index=array_search($arg,array_column($file_results,'line_id'));
                        return $index!==false ? $file_results[$index]:null;
                }   
        }


        public function check_request($obj,$request)
        {
                if($obj=='file-details')
                {
                        if(!isset($request['File_id_7']) && $request['File_id_7']=="")
                        {
                                return false;
                        }
                }
                return true;
        }

}
