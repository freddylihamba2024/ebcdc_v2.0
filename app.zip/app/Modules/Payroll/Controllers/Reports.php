<?php

namespace Modules\Payroll\Controllers;

use App\Controllers\BaseController;
use Modules\Payroll\Models\PayrollModel;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Sftp\Payroll\Controllers\SftpPayroll;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Controllers\TemenosGateway;

class Reports extends BaseController
{
    
        /*
         * Presentation:
         * Last update:
         * By Donald on the 06.08.2024
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('files');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'payroll';
        public $folder = 'reports';
        public $role;
        public $mail;
        public $mainModel;
        private $payrollModel=null;
        private $sftpPayroll=null;
        private $comptabilisation=null;
        private $comptabilisationModel=null;
        private $temenosGateway=null;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->payrollModel=new PayrollModel();
                $this->sftpPayroll=new SftpPayroll();
                $this->comptabilisation=new Comptabilisation();
                $this->temenosGateway=new Temenos();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                // $this->data['documents'] = $this->logirefModel->documents;
                // $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                // $this->data['moyens'] = $this->logirefModel->moyens;
                // $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['sidebar'] = $this->sidebars->logiref_payroll($this->data['role']);
          

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }

                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');

                }
                else 
                {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Payroll\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                
                if (in_array($needle, $this->menus)) {
                        $this->index();    
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "files")
                {
                        $this->data['status']=[''=>'--- Statut du fichier ---',0=>'En cours de traitement',1=>'Traité'];

                        $sftp_files=$this->payrollModel->get_integration_sftp_files(null,null,null,null,null,date('Y-m-d h:i:s'),date('Y-m-d h:i:s'));

                        $files=[];
                        $line_detail=array();
                        $file_data=[];
                       
                        foreach($sftp_files as $file)
                        {
                                $files[]=$file;
                                $lines=$this->payrollModel->get_file_details($file['File_id_7']);
                                foreach($lines as $line)
                                {
                                        $line_detail[$file['File_id_7']][]=$line;
                                }
                                
                                $file_data['file']=$files;
                                $file_data['lines']=$line_detail; 
                        }
                 
                        $this->data['files']=$file_data;
                        return view("\Modules\Payroll\Views\\".$this->folder."\\file_reports",$this->data);
                }  
                elseif($obj=="filter_files")
                {
                        $data=$_POST;
                        

                        $check_fields=$this->check_request('filter_files',$data);

                        if($check_fields)
                        {
                              
                                $sftp_files=$this->payrollModel->get_integration_sftp_files(null,null,null,null,$data['date_start'],$data['date_end'],$data['status']);
                            
                                $files=[];
                                $line_detail=[];
                                $file_data=[];
                        
                                foreach($sftp_files as $file)
                                {
                                        $files[]=$file;
                                        $lines=$this->payrollModel->get_file_details($file['File_id_7']);
                                        foreach($lines as $line)
                                        {
                                                $line_detail[]=$line;
                                        }
                                        
                                        $file_data['file']=$files;
                                        $file_data['lines']=$line_detail; 
                                }

                                $this->data['files']=$file_data;

                                return view("\Modules\Payroll\Views\\".$this->folder."\\filter_file_reports",$this->data);
                        }
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                
                if ($obj == "")
                {
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
               
        }
        public function check_request($obj,$request)
        {
                if($obj=="filter_files")
                {
                        if((!isset($request['date_start']) && $request['date_start']=="") ||  (!isset($request['date_end']) && $request['date_end']=="") || (!isset($request['status']) && $request['status']=="") )
                        {
                                return false;
                        }
                }
                return true;
        }

}
