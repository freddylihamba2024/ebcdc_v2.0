<?php

namespace Modules\Payroll\Controllers;

use App\Controllers\BaseController;
use Modules\Payroll\Models\PayrollModel;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Sftp\Payroll\Controllers\SftpPayroll;
use Modules\Services\Temenos\Controllers\Temenos;
use Modules\Services\Temenos\Controllers\TemenosGateway;

class Dashboards extends BaseController
{
    
        /*
         * Presentation:
         * Last update:
         * By Donald on the 06.08.2024
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('overview');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'payroll';
        public $folder = 'dashboards';
        public $role;
        public $mail;
        public $mainModel;
        private $payrollModel=null;
        private $sftpPayroll=null;
        private $comptabilisation=null;
        private $comptabilisationModel=null;
        private $temenosGateway=null;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->payrollModel=new PayrollModel();
                $this->sftpPayroll=new SftpPayroll();
                $this->comptabilisation=new Comptabilisation();
                $this->comptabilisationModel=new ComptabilisationModel();
                $this->temenosGateway=new Temenos();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                // $this->data['documents'] = $this->logirefModel->documents;
                // $this->data['devises'] = $this->licenceModel->get_dropdown("devises");
                // $this->data['moyens'] = $this->logirefModel->moyens;
                // $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['sidebar'] = $this->sidebars->logiref_payroll($this->data['role']);
          

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }

                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');

                }
                else 
                {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Payroll\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                
                if (in_array($needle, $this->menus)) {
                        $this->index();    
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "overview")
                {
                        
                        if(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role']==3)
                        {
                                // var_dump($obj);die;
                                // $this->data['status']=[''=>'--- Statut du fichier ---',0=>'En cours de traitement',1=>'Traité'];

                                $chart_data_monthly = $this->prepare_chart_data('monthly_payrolls');
                                $status_data = $this->prepare_chart_data('status_distribution');

                                $files=$this->payrollModel->get_files_by_frequency('daily',gmdate('d'),'all',5);

                                $nvalidated_files=$this->payrollModel->get_files_nvalidated();
                                $files_list=array();
        
                                foreach($nvalidated_files as $nvalidated_file)
                                {
                                        $instructions=$this->comptabilisationModel->get_instructions_sftp_payroll($nvalidated_file['Id_0']);
                                        $file=$nvalidated_file;

                                        $nvalidated_file['fileInfo']=$file;
                                        $nvalidated_file['lines']=$instructions;

                                        array_push($files_list,$nvalidated_file);

                                }

                                $this->data['nvalidated_files']=$files_list;

                                $this->data['pending']=$this->payrollModel->get_count_integration_files('pending');
                                $this->data['validated']=$this->payrollModel->get_count_integration_files('validated');
                                $this->data['all']=$this->payrollModel->get_count_integration_files('all');

                                $this->data['montant_total']=$this->payrollModel->get_montant_total_files();
                                $this->data['chart_data_monthly']=json_encode($chart_data_monthly);
                                $this->data['status_data']=json_encode($status_data);
                                $this->data['files']=$files;

                                return view('\Modules\Payroll\Views\\'.$this->folder."\\dashboard_validateur",$this->data);
                        }
                        else
                        {
                                $this->data['status']=[''=>'--- Statut du fichier ---',0=>'Non traités',1=>'Traités',2=>'Avec erreurs'];
                                
                                return view("\Modules\Payroll\Views\\".$this->folder."\\files",$this->data);
                        }
                }  
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
 
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "file-detail")
                {
                        $file_results=json_decode($data['Results_17'],true);
                        $index=array_search($arg,array_column($file_results,'line_id'));
                        return $index!==false ? $file_results[$index]:null;
                }   
        }
        public function check_request($obj,$request)
        {
                if($obj=='file-details')
                {
                        if(!isset($request['File_id_7']) && $request['File_id_7']=="")
                        {
                                return false;
                        }
                }
                return true;
        }
        public function prepare_chart_data($type)
        {
                if($type=='monthly_payrolls')
                {
                        $labels=[];
                        $months=[1=>'Janvier',2=>'Février',3=>'Mars',4=>'Avril',5=>'Mai',6=>'Juin',7=>'Juillet',8=>'Août',9=>'Septembre',10=>'Octobre',11=>'Novembre',12=>'Décembre'];
                        $saved_files=[];
                        $validated_files=[];
                        $errored_files=[];
                        $monthly_data=[];

                        foreach($months as $key=>$value)
                        {
                                $count_saved=$this->payrollModel->get_count_integration_files_by_frequency('monthly',$key,'all');
                                $count_validated=$this->payrollModel->get_count_integration_files_by_frequency('monthly',$key,'validated');
                                $count_errored=$this->payrollModel->get_count_integration_files_by_frequency('monthly',$key,'errored');

                                array_push($labels,$value);

                                array_push($saved_files,$count_saved);
                                array_push($validated_files,$count_validated);
                                array_push($errored_files,$count_errored);

                        } 

                        $monthly_data=[ ['label'=>'Enregistrés','data'=>$saved_files,'backgroundColor'=>'#1976d2'],
                                        ['label'=>'Validés','data'=>$validated_files,'backgroundColor'=>'#00C48C'],
                                        ['label'=>'Échecs','data'=>$errored_files,'backgroundColor'=>'#E30613']];


                        return ['labels'=>$labels,'datasets'=>$monthly_data];
                }
                elseif($type=='status_distribution')
                {
                        $labels=['Réussies', 'En attente', 'Échecs'];
                        $data=[];
                        $count_array=[];
                        $background_colors=[];

                        $success_files_count=$this->payrollModel->get_count_integration_files_by_frequency('yearly',gmdate('Y'),'validated');
                        $pending_files_count=$this->payrollModel->get_count_integration_files_by_frequency('yearly',gmdate('Y'),'pending');
                        $errored_files_count=$this->payrollModel->get_count_integration_files_by_frequency('yearly',gmdate('Y'),'errored');

                        $count_array=[$success_files_count,$pending_files_count,$errored_files_count];
                        $background_colors=['#00C48C','#FFA500','#E30613'];
                        
                        $datasets=[['data'=>$count_array,'backgroundColor'=>$background_colors]];

                        return ['labels'=>$labels,'datasets'=>$datasets];
                }
        }

}
