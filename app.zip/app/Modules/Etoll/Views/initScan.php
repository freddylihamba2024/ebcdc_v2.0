    <div class="offset-md-1 col-md-10 mt-4 wrapper wrapper-content">
        <div class="row">
            <div class="col-lg-9">
                <div class="mail-box-header">
                    <div class="float-right tooltip-demo">
                        <button class="btn btn-danger btn-circle btn-lg" data-toggle="tooltip" data-placement="top" style="margin-top:-10px;" title="Quitter"><i class="fa fa-times"></i></button>
                    </div>
                    <h2>
                       Scannage Qr Code
                    </h2>
                </div>
                <div class="mail-box">
                    <div class="mail-text">
                        
                    <div class="ibox-content">
                        <div class="row">
                            <div class="col-sm-6 b-r">
                                <h3 class="m-t-none m-b">Scanner</h3>
                                <p>Commencer par scanner le Qr Code de chauffeur pour enregistrer</p>
                                <form role="form">
                                    <div class="form-group">
                                        <label>Référence Qr Code</label> 
                                        <input type="text" id="refQrCode" disabled placeholder="Réf. QrCode" class="form-control">
                                    </div>
                                    <div>
                                        <button class="btn btn-info off" type="button" id="camera-on-off"><i class="fa fa-bandcamp"></i> <span class="bold">Scanner Qr Code </span>(On/Off)</button>
                                        <button class="btn btn-danger" type="button" id="validatateQrCode"><i class="fa fa-chevron-circle-right"></i> <span class="bold">Suivant</span></button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-sm-6 qrCode">
                                <span class="fa fa-qrcode"></span>
                                <video id="video-scanning"></video>
                            </div>
                        </div>
                    </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-3 animated fadeInRight">
                <div class="ibox">
                    <div class="ibox-content mailbox-content">
                        <div class="file-manager">
                            <h5>Menu</h5>
                            <ul class="folder-list m-b-md" style="padding: 0">
                                <li><a href="mailbox.html"> <i class="fa fa-inbox "></i> Inbox</a></li>
                                <li><a href="mailbox.html"> <i class="fa fa-envelope-o"></i> Send Mail</a></li>
                                <li><a href="mailbox.html"> <i class="fa fa-certificate"></i> Important</a></li>
                                <li><a href="mailbox.html"> <i class="fa fa-file-text-o"></i> Drafts</a></li>
                                <li><a href="mailbox.html"> <i class="fa fa-trash-o"></i> Trash</a></li>
                            </ul>
                            <h5>Categories</h5>
                            <ul class="category-list" style="padding: 0">
                                <li><a href="mail_compose.html#"> <i class="fa fa-circle text-navy"></i> Work </a></li>
                                <li><a href="mail_compose.html#"> <i class="fa fa-circle text-danger"></i> Documents</a></li>
                                <li><a href="mail_compose.html#"> <i class="fa fa-circle text-primary"></i> Social</a></li>
                                <li><a href="mail_compose.html#"> <i class="fa fa-circle text-info"></i> Advertising</a></li>
                                <li><a href="mail_compose.html#"> <i class="fa fa-circle text-warning"></i> Clients</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- script start -->
        <script src="<?= base_url('ikwook_bootstraps'); ?>/instascan/adapter.min.js"></script>
        <script src="<?= base_url('ikwook_bootstraps'); ?>/instascan/vue.min.js"></script>
        <script src="<?= base_url('ikwook_bootstraps'); ?>/instascan/instascan.min.js"></script>
        <script type="text/javascript">
            let scanner = new Instascan.Scanner({ video: document.getElementById('video-scanning')});
            $("#camera-on-off").on('click',function(){
                if($(this).hasClass('on')){
                    $(this).removeClass('on');
                    $(this).addClass('off');
                    Instascan.Camera.getCameras().then(function(cameras){
                        scanner.stop(cameras[0]);
                    }).catch(function(e){
                        console.error(e);
                    });
                }
                else{
                    $(this).removeClass('off');
                    $(this).addClass('on');
                    Instascan.Camera.getCameras().then(function(cameras){
                        if(cameras.length > 0){
                           scanner.start(cameras[0]);
                        }
                        else{
                            alert("Pas de camera disponible");
                        }
                    }).catch(function(e){
                        console.error(e);
                    });

                    scanner.addListener('scan',function(c){
                        document.getElementById('refQrCode').value = c;
                    });
                }
            });
            $("#validatateQrCode").on("click",function(){
                var refQrCode = $("#refQrCode").val();
                if(refQrCode.length == 0){
                    swal({
                        title: "Erreur",
                        text: "Veuillez scanner un Qr Code",
                        type: "error",
                        showCancelButton: false,
                        confirmButtonColor: "#dd4b39",
                        confirmButtonText: "OK",
                        closeOnConfirm: true
                    });
                    
                }
                else{
                    swal({
                        title: "Succès",
                        text: "Vous avez scanné un Qr Code",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#a5dc86",
                        confirmButtonText: "OK",
                        closeOnConfirm: true
                    });
                }
            });
        </script>