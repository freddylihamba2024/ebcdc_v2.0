<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\CashbooksModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\AccountsModel;
use Modules\Etoll\Models\ComptabilisationModel;
use Modules\Etoll\Models\CurlModel;
use Modules\Etoll\Models\PartnersModel;
use Modules\Etoll\Models\RatesModel;
use Modules\Services\Amplitude\Controllers\Amplitude;

class Equalize extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 11.08.2022
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('unequalized','toll_unequalized','cancelling');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'etoll';
        public $folder = 'equalize';
        public $role;
        public $cashbooksModel;
        public $encaissementModel;
        public $caissesModel;
        public $productsModel;
        public $usersModel;
        public $branchesModel;
        public $ticketsModel;
        public $eventsModel;
        public $accountsModel;
        public $comptabilisationModel;
        public $curlModel;
        public $partnersModel;
        public $logirefModel;
        public $mainModel;
        public $ratesModel;
        public $amplitude;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->cashbooksModel = new CashbooksModel();
                $this->encaissementModel = new EncaissementModel();
                $this->caissesModel = new CaissesModel();
                $this->productsModel = new ProductsModel();
                $this->usersModel = new UsersModel();
                $this->branchesModel = new BranchesModel();
                $this->ticketsModel = new TicketsModel();
                $this->eventsModel = new EventsModel();
                $this->accountsModel = new AccountsModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->curlModel = new CurlModel();
                $this->partnersModel = new PartnersModel();
                $this->logirefModel = new LogirefModel();
                $this->mainModel = new MainModel();
                $this->amplitude = new Amplitude();
                $this->ratesModel = new ratesModel();
                
                $this->folder = 'equalize';
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'equalize';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                $this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "toll_unequalized") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['paiements'] = $this->encaissementModel->get_paiements_toll_to_regularize();
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "cancelling") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['paiements'] = $paiements = $this->encaissementModel->get_paiements_toll_to_cancel();
                        
                        # unset the value of the nverify session
                        unset($_SESSION['paiement_cancelling']);
                        
                        $total = 0;
                        
                        $result = $this->ratesModel->get_last_published_rate();
                        $result = current($result);
                        
                        $taux = isset($result->Dollar_7) ? $result->Dollar_7 : 0;
                        
                        foreach ($paiements as $row):

                            if($row->Devise_11 == 'CDF')
                            {
                                    $total += $row->Amount_10;
                            }
                            else
                            {
                                    $total += $taux * $row->Amount_10;
                            }
                            
                        endforeach;
                        
                        $this->data['total'] = $total;
                        
                        echo view('\Modules\Etoll\\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_toll_cancelling") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        $this->data['paiements'] = $_SESSION['paiement_cancelling'] = $this->encaissementModel->get_paiements_toll_to_cancel_by_filter();
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_cancelling', $this->data);
                }
                elseif($obj == "ticket_unequalized") 
                {
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['paiements'] = $this->encaissementModel->get_paiements_ticket_to_regularize();
                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_toll_unequalized") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['paiements'] = $_SESSION['regularize_tolls'] = $this->encaissementModel->get_paiements_toll_to_regularize_filter($_POST);

                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\filter_unequalized', $this->data);
                }
                elseif($obj == "filter_ticket_unequalized") 
                {
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_ticket_filter();
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\filter_unequalized', $this->data);
                }
                elseif($obj == "toll")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['modes'] = $this->encaissementModel->sbbos_modes;
                        $this->data['products'] = $this->productsModel->get_dropdown("product_toll");
                        $this->data['modes'] = $this->ticketsModel->modes;
                        
                        $this->data['paiement'] = $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        $this->data['product'] = $product = $this->productsModel->get_product_info($paiement->Type_12);
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'));
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($this->session->get('Logiref_branch'));
                        
                        $this->data['number'] = $paiement->Carnetnumber_35;
                        $this->data['carnetid'] = $paiement->Carnetid_34;
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "toll_cancelling")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['modes'] = $this->encaissementModel->sbbos_modes;
                        $this->data['products'] = $this->productsModel->get_dropdown("product_toll");
                        
                        $this->data['modes'] = $this->ticketsModel->modes;
                        
                        $this->data['paiement'] = $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        $this->data['product'] = $product = $this->productsModel->get_product_info($paiement->Type_12);
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'));
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($this->session->get('Logiref_branch'));
                        
                        $this->data['number'] = $paiement->Carnetnumber_35;
                        $this->data['carnetid'] = $paiement->Carnetid_34;
                        
                        # Get the instructions line of payments
                        $lines = $this->comptabilisationModel->get_instructions($paiement->Refpaiement_22);
                        $lines = current($lines);
                        $this->data['lines'] = $lines;
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "ticket") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['modes'] = $this->ticketsModel->modes;
                        $this->data['paiement'] = $paiement = $this->encaissementModel->get_paiement_info($id);
                        $this->data['ticket'] = $ticket = $this->ticketsModel->get_ticket_info($paiement->Ticket_24);
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'));
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($this->session->get('Logiref_branch'));
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "get_details_toll") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_details_toll', $this->data);
                }
                elseif($obj == "get_details_toll_cancelling") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_details_toll_cancelling', $this->data);
                }
                elseif($obj == "get_details_ticket") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_details_ticket', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->folder . '_denial', $this->data);
                }
	}
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "toll")
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                        $data['refpaiement'] = $logirefid = $_POST['reference'].$id;
                        $data['Designation_8'] = $_POST['designation'];
                        $data['refcbs'] = isset($_POST['refcbs']) ? $_POST['refcbs'] : "";
                        
                        // Forcage de l'ecriture
                        if($_POST['action'] == "forcing")
                        {
                                $result =  $this->amplitude->regularize_sbbos($data);
                                
                                //$result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;
                                    
                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                        
                                }
                                elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions($logirefid);
                                
                                
                                foreach($instructions as $value):
                                   $succes[] = $value->Status_2; 
                                endforeach;
                                
                                if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes))  
                                {
                                        $reverse['validate'] = true;
                                }
                                
                                echo json_encode($reverse);
                                die;

                        }  
                        elseif($_POST['action'] == "reverse")
                        {
                                $result =  $this->amplitude->extourne_sbbos($data);
                                
                                //$result = json_decode($response, true);
                                
                                $succes = array();
                                $reverse = array();
                                $reverse['delete'] = false;

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                        
                                }
                                elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        
                                        $reverse['response'] = "E".$result['response'];
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions($logirefid);
                                foreach($instructions as $value):
                                   $succes[] = $value->Status_2; 
                                endforeach;
                                
                                if(in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes))  
                                {
                                        $reverse['validate'] = true;
                                }
                                
                                if(!in_array('2', $succes)) 
                                {
                                        $reverse['delete'] = true;
                                }
                                
                                echo json_encode($reverse);
                                die;
                        }
                        
                        elseif($_POST['action'] == "verify")
                        {       
                                $result =  $this->amplitude->account_event_sbbos($data);
                                
                                //$result = json_decode($response, true);
                                
                                $succes = array();
                                $reverse = array();

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                        
                                }
                                elseif($result['response'] == '300')
                                {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                elseif($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                echo json_encode($reverse);
                                die;
                        }
                        
                }
                if($obj == "ticket")
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                        $data['refpaiement'] = $_POST['reference'].$id;
                        $data['Designation_8'] = $_POST['designation'];
                        
                        
                        // Forcage de l'ecriture
                        if($_POST['action'] == "forcing")
                        {
                                $result =  $this->amplitude->regularize_sbbos($data);
                                
                                //$result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;
                                    
                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                }
                                elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions($_POST['reference']);
                                
                                foreach($instructions as $value):
                                   $succes[] = $value->Status_2; 
                                endforeach;
                                
                                if(!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes) && !in_array('5', $succes))  
                                {
                                        $reverse['validate'] = true;
                                }
                                
                                echo json_encode($reverse);
                                die;

                        }  
                        elseif($_POST['action'] == "reverse")
                        {
                                $result =  $this->amplitude->extourne_sbbos($data);
                                
                                //$result = json_decode($response, true);
                                
                                $succes = array();
                                $reverse = array();
                                $reverse['delete'] = false;

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                        
                                }
                                elseif($result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        
                                        $reverse['response'] = "E".$result['response'];
                                }
                                else
                                {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions($_POST['reference']);
                                foreach($instructions as $value):
                                   $succes[] = $value->Status_2; 
                                endforeach;
                                
                                if(in_array('3', $succes) || in_array('4', $succes))  
                                {
                                        $reverse['validate'] = true;
                                }
                                
                                if(!in_array('2', $succes)) 
                                {
                                        $reverse['delete'] = true;
                                }
                                
                                echo json_encode($reverse);
                                die;
                        }
                        
                        elseif($_POST['action'] == "verify")
                        {       
                                $result =  $this->amplitude->account_event_sbbos($data);
                                
                                //$result = json_decode($response, true);
                                
                                $succes = array();
                                $reverse = array();

                                if($result['response'] == '200')
                                {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                        
                                }
                                elseif($result['response'] == '300')
                                {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                elseif($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405')
                                {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        
                                        $pid = $this->comptabilisationModel->update_instructions_cbs($id, $data);
                                        $reverse['response'] = "E".$result['response'];
                                }
                                
                                echo json_encode($reverse);
                                die;
                        }
                        
                }
                elseif($obj == "validate_toll")
                {
                        $data = array();
                        $data['validation_32'] = $this->session->userdata['user_id'];
                        $data['Status_2'] = 1;
                        # Update the paiement
                        $pid = $this->encaissementModel->update_encaissement($data, $id);
                        if($pid) echo $pid;
                        else echo "E002";
                }
                elseif($obj == "validate_ticket")
                {
                        $data = array();
                        $data['validation_32'] = $this->session->userdata['user_id'];
                        $data['Status_2'] = 1;
                        # Update the paiement
                        $pid = $this->encaissementModel->update_encaissement($data, $id);
                        if($pid) echo $pid;
                        else echo "E002";
                }
                else if($obj == "delete")
                {
                        $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;
                        
                        if($rType=='TRESOR' || $rType=='RFTRESD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_tresor($id);
                        }
                        elseif($rType=='PROPRES' || $rType=='RFPROPD')
                        {
                                $pid = $this->encaissementModel->delete_paiement_propre($id);
                        }
                        if($pid > 0)
                        {
                                $this->comptabilisationModel->delete_instructions_dgi($id);
                        }
                        #Return
                        echo $pid;
                        die;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "")
                {
                        
                }
               
                
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */

