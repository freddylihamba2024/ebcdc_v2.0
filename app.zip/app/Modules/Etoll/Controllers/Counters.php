<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\CountersModel;

class Counters extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('guichets');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'counters';
        public $role;
        public $mainModel;
        public $countersModel;
        public $logirefModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->countersModel = new CountersModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'counters';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view("layouts/layout_main", $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "guichets")
                {
                        $this->data['agences'] = $this->countersModel->get_dropdown("agences", NULL, "ALL");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['type'] = $this->countersModel->type;
                        $this->data['guichets'] = $this->countersModel->get_guichets();
                        
                        echo view("\Modules\Etoll\Views\counters\guichets", $this->data);
                }
                elseif($obj == "guichet") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['agences'] = $this->countersModel->get_dropdown("agences", NULL, "ALL");
                        $this->data['guichet'] = $this->countersModel->get_guichet_info($id);
                        $this->data['types'] = $this->countersModel->type;
                        
                        echo view("\Modules\Etoll\Views\counters\_guichet", $this->data);
                }
                elseif($obj == "caisses")
                {
                        $this->data['caisses'] = $this->countersModel->get_caisses();
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        echo view("\Modules\Etoll\Views\counters\caisses", $this->data);
                }
                elseif($obj == "caisse") 
                {
                        $this->data['caisse'] = $this->countersModel->get_caisse_info($id);
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        
                        echo view("\Modules\Etoll\Views\counters\_caisse", $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view("\Modules\Etoll\Views\\".$this->lang . "_denial", $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "guichet")
                {
                        $data=$_POST;
                        if($_POST['Name_7']=='0' || $_POST['Code_8']=='' || $_POST['Location_9']==''  || $_POST['Type_10']==''  || $_POST['Agence_11']=='' || $_POST['Province_12']==''  || $_POST['Ville_13']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                die;
                        endif;
                        
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                // checks if the code entered has already been used 
                                $guichet = $this->countersModel->get_code_exists($data['Code_8']);
                                if(!empty($guichet))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; un point de vente avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $branche = $this->countersModel->get_guichet_info($id);
                                if($branche->Code_8 !== $data['Code_8'])
                                {
                                        //checks if the code entered has already been used 
                                        $guichet = $this->countersModel->get_code_exists($_POST['Code_8']);
                                        if(!empty($guichet))
                                        {
                                                echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; un point de vente avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                die;
                                        }
                                        
                                }
                                
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        $data['Name_7']= $_POST['Name_7'];
                        $data['Code_8']= $_POST['Code_8'];
                        $data['Location_9']= $_POST['Location_9'];
                        $data['Type_10']= $_POST['Type_10'];
                        $data['Agence_11']= $_POST['Agence_11'];
                        $data['Province_12']= $_POST['Province_12'];
                        $data['Ville_13']= $_POST['Ville_13'];
                        $data['Description_14']= $_POST['Description_14'];
                        
                        // Illicocash credentials data
                        
                        $credentials = new \stdClass();
                        $credentials->merchantid = trim($_POST['merchantid']);
                        $credentials->encryptKey = trim($_POST['encryptKey']); 
                        $credentials->logInName = trim($_POST['logInName']);
                        $credentials->loginPass = trim($_POST['loginPass']); 
                        $credentials->userAuth = trim($_POST['userAuth']);
                        $credentials->passwordAuth = trim($_POST['passwordAuth']); 
                        $data['Credentials_15']= json_encode($credentials);
                        
                        unset($data['merchantid']);
                        unset($data['encryptKey']);
                        unset($data['logInName']);
                        unset($data['loginPass']);
                        unset($data['userAuth']);
                        unset($data['passwordAuth']);
                       
                        #Database
                        $cid = $this->countersModel->save_branche($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "caisse")
                {
                        $data = $_POST;
                       
                        if($data['Reference_7']=='0' || $data['Compte_9']==''  || $data['Guichet_8']=='' || $data['Name_10']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        endif;
                        
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                // checks if the code entered has already been used 
                                $caisse_exist = $this->countersModel->get_caisse_exists($data['Compte_9']);
                                
                                if(!empty($caisse_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une caisse cr&eacute;e avec ce compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                
                                $caisse = $this->countersModel->get_caisse_info($id);
                                if($caisse->Compte_9 !== $data['Compte_9'])
                                {
                                        //checks if the code entered has already been used 
                                        $caisse_exist = $this->countersModel->get_caisse_exists($data['Compte_9']);
                                        if(!empty($caisse_exist))
                                        {
                                                echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une caisse cr&eacute;e avec ce compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                die;
                                        }
                                }
                        }
                        
                        #Database
                        $cid = $this->countersModel->save_caisse($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! caisse enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */