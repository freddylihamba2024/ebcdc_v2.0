<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Branch\Models\RatesModel;
use Modules\Admin\Models\EtollRatesModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CurlModel;
use Modules\Etoll\Models\DataModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Admin\Models\UserModel;
use Modules\Services\Igor\Controllers\Igor;
use Modules\Services\Amplitude\Controllers\Amplitude;

class Rates extends BaseController {
        /*
         * Presentation: gestion des taux de change
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('list','taux','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $role;
        public $module = 'etoll';
        public $folder = 'rates';
        public $amplitude;
        public $ratesModel;
        public $caissesModel;
        public $branchesModel;
        public $curlModel;
        public $logirefModel;
        public $dataModel;
        public $mainModel;
        public $usersModel;
        public $userModel;
        public $options;
        public $igor;
        public $core_banking;
        public $etollRatesModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->ratesModel = new RatesModel();
                $this->caissesModel = new CaissesModel();
                $this->branchesModel = new BranchesModel();
                $this->curlModel = new CurlModel();
                $this->logirefModel = new LogirefModel();
                $this->dataModel = new DataModel();
                $this->amplitude = new Amplitude();
                $this->mainModel = new MainModel();
                $this->igor = new Igor();
                $this->userModel = new UserModel();
                $this->usersModel = new UsersModel();
                $this->etollRatesModel = new EtollRatesModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'rates';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                $this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "taux")
                {
                        $this->data("set_exchange_rates");
                        $this->data("default_values_new_taux");
                        
                        $this->data['caisse_cdf'] = $caisse_cdf = $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'), 'CDF');
                        $this->data['caisse_usd'] = $caisse_usd =  $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'), 'USD');
                        
                        $data_usd['bank_account'] = isset($caisse_usd->Compte_9) ? $caisse_usd->Compte_9 : "000000000000000000000000";
                        $data_usd['devise_account'] = 'USD';
                        
                        $data_cdf['bank_account'] = isset($caisse_cdf->Compte_9) ? $caisse_cdf->Compte_9 : "000000000000000000000000";
                        $data_cdf['devise_account'] = 'CDF';
                        
                        //$this->data['balance_usd'] = $this->data('get_balance_by_account', $data_usd);
                        //$this->data['balance_cdf'] = $this->data('get_balance_by_account', $data_cdf);
                        $this->data['balance_usd'] = '';
                        $this->data['balance_cdf'] = '';
                       
                        $this->data['caisse'] = $this->caissesModel->get_caisse_by_branchid($this->session->get('Logiref_branch'));
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_taux', $this->data); 
                }
                elseif($obj == "list") 
                {
                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                        $this->data['taux'] = $this->etollRatesModel->get_taux();
                        $cumules = $this->dataModel->get_rates_by_day();
                        $cumulous = $this->dataModel->get_month_of_rates();
                        $this->data['chart'] = $this->dataModel->get_rates_of_last_days($cumules, $cumulous);
                        $this->data("set_exchange_rates");
                       
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\taux', $this->data);
                }
                elseif($obj == "taux_filter") 
                {
                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                        $start = $this->request->getPost('start');
                        $end = $this->request->getPost('end');
                        $agence = $this->request->getPost('agence');
                        $this->data['taux'] = $this->etollRatesModel->get_taux_by_filter($agence, $start, $end);
                        
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == 'taux')
                {
                        if($_POST['usd']=='0' || $_POST['usd']=='')
                        {
                                $data_return['msg'] = '<div class="alert alert-danger">ERROR! Valeurs incorrectes...<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return = json_encode($data_return);
                                echo $return; 
                                die;
                        }
                        elseif($_SESSION['Logiref_role']!=4 && $_POST['action']!='Confirmer')
                        {
                                $data_return['msg'] = '<div class="alert alert-warning">Vous ne pouvez pas publier un taux. Veuillez contacter la personne habilet&eacute;e &agrave; le faire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return = json_encode($data_return);
                                echo $return;  
                                die;
                        }
                        else
                        {
                                $dollar = str_replace(' ','',$_POST['usd']);
                                $dollar = str_replace(',','.',$dollar);
                                
                                $euro = str_replace(' ','',$_POST['eur']);
                                $euro = str_replace(',','.',$euro);
                                
                                $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                               
                                $data['Account_3']  =   $this->session->userdata['account_id'];
                                $data['Dollar_7']   =   $dollar;
                                $data['Euro_8']     =   $euro;
                                $data['Euro_8']     =   $euro;
                                $data['Compte_9']   =   $_POST['Compte_9'];
                                
                                $data['Balance_10'] = str_replace(' ','',$_POST['Balance_10']);
                                $data['Balance_10'] = str_replace(',','.',$data['Balance_10']);
                                
                                if(isset($_POST['Compte_14']) && $_POST['Compte_14'] !="")
                                {
                                        $data['Compte_14']   =   $_POST['Compte_14'];
                                        
                                        $data['Balance_15'] = str_replace(' ','',$_POST['Balance_15']);
                                        $data['Balance_15'] = str_replace(',','.',$data['Balance_15']);
                                }
                                $action =  $data['Action_12']  =   $_POST['operation_caisse'];
                                
                                $data['Devise_16']   =   $_POST['Devise_16'];
                                $data['Devise_17']   =   $_POST['Devise_17'];
 
                                # Recuperer la caisse en fonction du point de peage
                                $caisse = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                                
                                if(isset($caisse->Id_0)) $caisse_id = $caisse->Id_0; else $caisse_id = 0;
                                
                                if($_POST['is_checker']==1 && $id != NULL)
                                {
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        
                                        if($action  == "opening"):
                                            
                                                $caissegdata['Status_2'] = 2; // statut d'une caisse ouverte
                                                
                                        elseif($action  == "closing"):
                                            
                                                $caissegdata['Status_2'] = 1; // statut d'une caisse fermee
                                                
                                        endif;
                                        
                                        $this->caissesModel->save_caisse($caissegdata, $caisse_id); 
                                            
                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');
                                }
                                else 
                                {
                                        $data['Status_2'] = 1;
                                        //$data['Guichet_11'] = $_SESSION['Logiref_caisse'];
                                        $data['Guichet_11'] = $_SESSION['Logiref_branch'];
                                        $data['Agence_13']  =  $_SESSION['Logiref_guichet'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        
                                        $caissegdata['Date_14'] = gmdate('Y-m-d H:i:s');
                                        
                                        if($action  == "opening"):
                                            
                                                $caissegdata['Status_2'] = 4; // statut d'une caisse en attente de l'ouverture
                                                $caissegdata['Opener_12'] = $this->session->userdata['user_id'];
                                                
                                        elseif($action  == "closing"):
                                            
                                                $caissegdata['Status_2'] = 3; // statut d'une caisse en attente de fermeture 
                                                $caissegdata['Closer_13'] = $this->session->userdata['user_id'];
                                        endif;
                                        
                                        $this->caissesModel->save_caisse($caissegdata, $caisse_id);
                                }
                                
                                if(isset($_POST['id_taux']) && $_POST['id_taux'] != "")
                                {
                                        $id = $_POST['id_taux'];
                                }
                                
                                $cid = $this->etollRatesModel->save_taux($data, $id);
                                
                                if($cid)
                                {
                                        $data_return = array();
                                        
                                        if($id != "")
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success">Bravo! Modification enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                                $data_return['id'] = $id;
                                        }
                                        else
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                $data_return['id'] = $id;
                                        }
                                        $return = json_encode($data_return);
                                        
                                        echo $return;
                                        
                                        $this->data("set_exchange_rates","noredirect");
                                        die;
                                }
                        }
                        
                }
                elseif($obj == 'taux2')
                {
                        if($_POST['usd']=='0' || $_POST['usd']=='')
                        {
                                $data_return['msg'] = '<div class="alert alert-danger">ERROR! Valeurs incorrectes...<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return = json_encode($data_return);
                                echo $return; 
                                die;
                        }
                        elseif($_SESSION['Logiref_role']!=4 && $_POST['action']!='Confirmer')
                        {
                                $data_return['msg'] = '<div class="alert alert-warning">Vous ne pouvez pas publier un taux. Veuillez contacter la personne habilet&eacute;e &agrave; le faire.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return = json_encode($data_return);
                                echo $return;  
                                die;
                        }
                        else
                        {
                                # Nouveau Taux Etoll
                                # ==================
                                $dollar = str_replace(' ','',$_POST['usd']);
                                $dollar = str_replace(',','.',$dollar);
                                
                                $euro = str_replace(' ','',$_POST['eur']);
                                $euro = str_replace(',','.',$euro);
                                
                                $data = array();

                                $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                               
                                $data['Account_3']  =   $this->session->userdata['account_id'];
                                $data['Dollar_7']   =   $dollar;
                                $data['Euro_8']     =   $euro;
                                $data['Euro_8']     =   $euro;
                                $data['Compte_9']   =   $_POST['Compte_9'];
                                
                                $data['Balance_10'] = str_replace(' ','',$_POST['Balance_10']);
                                $data['Balance_10'] = str_replace(',','.',$data['Balance_10']);
                                
                                if(isset($_POST['Compte_14']) && $_POST['Compte_14'] !="")
                                {
                                        $data['Compte_14']   =   $_POST['Compte_14'];
                                        
                                        $data['Balance_15'] = str_replace(' ','',$_POST['Balance_15']);
                                        $data['Balance_15'] = str_replace(',','.',$data['Balance_15']);
                                }
                                $action =  $data['Action_12']  =   $_POST['operation_caisse'];
                                
                                $data['Devise_16'] = $_POST['Devise_16'];
                                $data['Devise_17'] = $_POST['Devise_17'];

                                $user_etoll = $this->usersModel->get_user_connected();
                                
                                # Recuperer la caisse en fonction du point de peage
                                $caisse = $this->caissesModel->get_caisse_by_branchid($user_etoll->Guichet_8);
                                
                                if(isset($caisse->Id_0)) $caisse_id = $caisse->Id_0; else $caisse_id = 0;
                                
                                if($_POST['is_checker']==1 && $id != NULL)
                                {
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        
                                        if($action  == "opening"):
                                            
                                                $caissegdata['Status_2'] = 2; // statut d'une caisse ouverte
                                                
                                        elseif($action  == "closing"):
                                            
                                                $caissegdata['Status_2'] = 1; // statut d'une caisse fermee
                                                
                                        endif;
                                        
                                        $this->caissesModel->save_caisse($caissegdata, $caisse_id); 
                                            
                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');
                                }
                                else 
                                {
                                        $data['Status_2'] = 1;
                                        //$data['Guichet_11'] = $_SESSION['Logiref_caisse'];
                                        $data['Guichet_11'] = $user_etoll->Guichet_8;
                                        $data['Agence_13']  =  $user_etoll->Agence_7;
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        
                                        $caissegdata['Date_14'] = gmdate('Y-m-d H:i:s');
                                        
                                        if($action  == "opening"):
                                            
                                                $caissegdata['Status_2'] = 4; // statut d'une caisse en attente de l'ouverture
                                                $caissegdata['Opener_12'] = $this->session->userdata['user_id'];
                                                
                                        elseif($action  == "closing"):
                                            
                                                $caissegdata['Status_2'] = 3; // statut d'une caisse en attente de fermeture 
                                                $caissegdata['Closer_13'] = $this->session->userdata['user_id'];
                                        endif;
                                        
                                        $this->caissesModel->save_caisse($caissegdata, $caisse_id);
                                }
                                
                                if(isset($_POST['id_taux']) && $_POST['id_taux'] != "")
                                {
                                        $id = $_POST['id_taux'];
                                }
                                
                                $cid = $this->etollRatesModel->save_taux($data, $id);
                                
                                if($cid)
                                {
                                       $this->data("set_exchange_rates","noredirect");
                                }

                                # Nouveau Taux Logiref
                                # ====================
                                $dollar = str_replace(' ','',$_POST['usd']);
                                $dollar = str_replace(',','.',$dollar);
                                
                                $euro = str_replace(' ','',$_POST['eur']);
                                $euro = str_replace(',','.',$euro);
                                
                                $rand = str_replace(' ','',$_POST['rand']);
                                $rand = str_replace(',','.',$rand);
                                
                                $pound = str_replace(' ','',$_POST['pound']);
                                $pound = str_replace(',','.',$pound);

                                $user_logiref = $this->userModel->get_user_connected();
                                $data = array();
                                
                                $data['Date_1']     =   gmdate('Y-m-d H:i:s');
                                $data['Status_2']   =   1;
                                $data['Account_3']  =   $this->session->userdata['account_id'];
                                $data['Dollar_4']   =   $dollar;
                                $data['Euro_5']     =   $euro;
                                $data['Rand_6']     =   $rand;
                                $data['Pound_7']    =   $pound;
                                $data['Agence_8']   =   $user_logiref->Agence_7;
                                $data['Day_9']      =   gmdate('Y-m-d');

                                if($_POST['is_checker']==1 && $id != "")
                                {
                                        $data['Checkerid_11']= $this->session->userdata['user_id'];
                                        
                                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');
                                }
                                else 
                                {
                                        $data['Makerid_10']= $this->session->userdata['user_id'];
                                }
                                if(isset($_POST['key_taux']) && $_POST['key_taux'] != "")
                                {
                                        $id = $_POST['key_taux'];
                                }
                                
                                $cid2 = $this->ratesModel->save_taux($data, $id); 
                                
                                if($cid2)
                                {
                                        $this->data("set_exchange_rates","noredirect");
                                }

                                if($cid || $cid2)
                                {
                                        $data_return = array();

                                        if($id != "")
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success">Bravo! Modification enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                                $data_return['id'] = $id;
                                        }
                                        else
                                        {
                                                $data_return['msg'] = '<div class="alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                $data_return['id'] = $id;
                                        }

                                        $return = json_encode($data_return);
                                        
                                        echo $return;
                                }

                        }
                        
                }
                elseif($obj == "validate")
                {
                        # Validate Etoll
                        # ==============
                        $id = $_GET['id'];
                        $action = $_GET['action'];
                        
                        $movement = current($this->caissesModel->get_current_movement($id,$action));
                       
                        $caissegdata['Id_0'] = $id;
                        
                        if($action == 'opening')
                        {
                                $caissegdata['Status_2'] = 2; // statut d'une caisse ouverte
                        }
                        elseif($action == 'closing')
                        {
                                $datamovement['Status_2']= 2;
                                $caissegdata['Status_2'] = 1; // statut d'une caisse fermee
                        }
                        
                        $datamovement['Changes_5']= gmdate('Y-m-d H:i:s');
                        $datamovement['Changer_6']= $this->session->userdata['user_id'];
                        $_SESSION['Date_new_taux'] = gmdate('Y-m-d');
                        
                        $this->caissesModel->save_caisse($caissegdata, $id);
                        
                        $cid = $this->etollRatesModel->update_taux($datamovement, $id);
                        
                        if($cid)
                        {
                                $msg = '<div class="alert alert-success">Bravo! Validation effectu&eacute;e avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        } 
                        else
                        {
                                $msg ='<div class="alert alert-warning"> Echec de validation ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        }
                        
                        echo $msg;
                        
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                 # Exchange rates
                #
                ################################################################################
                elseif($obj == "default_values_new_taux")
                {   

                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['cmpt'] = $bank['Compte_9'];
                                $this->data['balance'] = $bank['Balance_10'];
                                $this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['id'] = $bank['Id_0'];
                                #$this->data['id'] = ''; 
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['cmpt'] = '';
                                $this->data['balance'] = '';
                                //$this->data['guichet'] = $bank['Guichet_11'];
                               
                                /*if($bank['Changer_6']==0): 
                                        $this->data['id'] = $bank['Id_0'];
                                        $this->data['id'] = ''; 
                                else :*/
                                        $this->data['id'] = ''; 
                                        $this->data['reset'] = 1; 
                                //endif;
                                
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                //$this->data['cmpt'] = $bank['Compte_9'];
                                //$this->data['balance'] = $bank['Balance_10'];
                                //$this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['cmpt'] = 01233;
                                $this->data['balance'] = 0.0;
                                $this->data['guichet'] = 0;
                                $this->data['id'] = '';
                        }
                        
                        $this->data['action'] = '...';
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }
                        
                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer';
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] != 0):

                                        $this->data['action'] = 'Fermer';
                                        $this->data['operation_caisse'] = 'Fermeture de la caisse';

                                else :
                                        $this->data['action'] = 'Publier';
                                        $this->data['operation_caisse'] = 'Ouverture d\'une caisse';
                                endif;
                        }
                }
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif($obj == "set_exchange_rates")
                {
                        
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata ["account_cbs"];
                        # Retrieve options configured based on the bank connected
                        if(isset($_SESSION['userdata']['options']))
                        {
                                $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                        }
                        else
                        {
                                $this->data['options'] = $this->options = array();
                        }

                        if(!isset($_SESSION['Exchange_rates']) || $_SESSION['Exchange_rates']=='0')
                        {
                                if(isset($this->options['ALL']['manuel-input-exchange-rate']))
                                {
                                        $this->ratesModel->get_exchange_rates();
                                }
                                else
                                {
                                        /*
                                        * ------------------------------------------------
                                        * Initialization
                                        * ------------------------------------------------
                                        */

                                        $usd = '';
                                        $pound = '';
                                        $eur = '';
                                        $rand = '';

                                        $data['from_currency'] = 'USD';
                                        $data['to_currency'] = 'CDF';
                                        $data['type'] = 'TTB';
                                        $data['language'] = 'P';

                                        # Nom du core banking
                                        $core_banking = strtolower($this->core_banking);

                                        # Vérifier si la méthode get_exchange_rate existe dans la classe
                                        if (method_exists($this->{$core_banking}, 'get_exchange_rate')) 
                                        {
                                                $return = $this->{$core_banking}->get_exchange_rate($data);
                                        } 
                                        else 
                                        {
                                                $result['code'] = '407';
                                                echo json_encode($result); die;
                                        }

                                        $return = json_decode($return, true);

                                        if(isset($return['exchange_rate']) && $return['exchange_rate'] != "")
                                        {
                                                $usd = $return['exchange_rate'];

                                                $data['from_currency'] = 'EUR';
                                                $data['to_currency'] = 'CDF';

                                                $return = $this->igor->get_exchange_rate($data);

                                                $return = json_decode($return, true);

                                                $eur = isset($return['exchange_rate']) ? $return['exchange_rate'] : "";

                                                $_POST['usd'] = $usd;
                                                $_POST['eur'] = $eur;
                                                $_POST['rand'] = "";
                                                $_POST['pound'] = "";

                                                $this->save('taux');

                                                $this->ratesModel->get_exchange_rates();
                                        }
                                        elseif(isset($return['ExchangeRateList']) && $return['ExchangeRateList'] != "")
                                        {
                                                foreach($return['ExchangeRateList'] as $row)
                                                {
                                                        if(isset($row['ccyISO']) && $row['ccyISO'] == 'GBP')
                                                        {
                                                                $pound = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'ZAR')
                                                        {
                                                                $rand = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'USD')
                                                        {
                                                                $usd = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                        elseif(isset($row['ccyISO']) && $row['ccyISO'] == 'EUR')
                                                        {
                                                                $eur = isset($row['buyExchangeRate']) ? $row['buyExchangeRate'] : "";
                                                        }
                                                }

                                                if($usd != "" && $eur !="")
                                                {
                                                        $_POST['usd'] = $usd;
                                                        $_POST['eur'] = $eur;
                                                        $_POST['rand'] = $rand;
                                                        $_POST['pound'] = $pound;

                                                        $this->save('taux');

                                                        $this->ratesModel->get_exchange_rates();
                                                }
                                        }
                                }
                        }
                        
                        $this->etollRatesModel->get_exchange_rates();
                }
                elseif($obj == "get_balance_by_account")
                {       
                        $response = $this->amplitude->check_balance_sbbos($data);
                       
                        //$response = json_decode($return, true);

                        if($response['code'] == '200')
                        {
                                return $response['balance'];
                        }
                        else 
                        {
                                return $response['balance'] = '';
                        }

                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */