<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\PartnersModel;

class Events extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('events');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'events';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
             
                $this->mainModel = new MainModel();
                $this->branchesModel = new BranchesModel();
                $this->eventsModel = new EventsModel();
                $this->encaissementModel = new EncaissementModel();
                $this->partnersModel = new PartnersModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'events';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                if($this->session->get('Logiref_role')==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "events")
                {
                        $this->data['events'] = $this->eventsModel->get_events();
                        $this->data['status'] = $this->eventsModel->status;
                        $this->data['status_color'] = $this->eventsModel->status_color;
                        $this->data['type_event'] = $this->eventsModel->type;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\events', $this->data);
                }
                elseif($obj == "event") 
                {
                        $this->data['event'] = $this->eventsModel->get_event_info($id);
                        $this->data['type_event'] = $this->eventsModel->type;
                        $this->data['partners'] = $this->partnersModel->get_dropdown("partners");
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_event', $this->data);
                }
                elseif($obj == "_events") 
                {
                        $this->data['events'] = $this->events_model->get_events();
                        $this->data['status'] = $this->events_model->status;
                        $this->data['status_color'] = $this->events_model->status_color;
                        $this->data['type_event'] = $this->events_model->type;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_events', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "event")
                {
                        if($_POST['Name_7']=='0' || $_POST['Type_8']==''  || $_POST['Location_9']=='' || $_POST['Start_10']=='' || $_POST['Time_12']=='' || $_POST['End_11']=='' || $_POST['Time_13']=='' || $_POST['Start_16']=='' || $_POST['Time_18']=='' || $_POST['End_17']=='' || $_POST['Time_19']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        $infos = array();
                        
                        $data['Name_7']= $_POST['Name_7'];
                        $data['Type_8']= $_POST['Type_8'];
                        $data['Location_9']= $_POST['Location_9'];
                        $data['Start_10']= $_POST['Start_10'];
                        $data['End_11']= $_POST['End_11'];
                        $data['Time_12']= $_POST['Time_12'];
                        $data['Time_13']= $_POST['Time_13'];
                        $data['Start_16']= $_POST['Start_16'];
                        $data['End_17']= $_POST['End_17'];
                        $data['Time_18']= $_POST['Time_18'];
                        $data['Time_19']= $_POST['Time_19'];
                        $data['Description_15']= $_POST['Description_15'];

                        $infos['partner'] = isset($_POST['Partners_14']) ? $_POST['Partners_14'] : "";
                        $infos['quota_bank'] = isset($_POST['quota_bank']) ? $_POST['quota_bank'] : "";
                        $infos['quota_partner'] = isset($_POST['quota_partner']) ? $_POST['quota_partner'] : "";
                                
                        $data['Partners_14']= json_encode($infos);
                        
                        #Database
                        $cid = $this->eventsModel->save_events($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! &eacute;v&egrave;nement enregistr&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '0'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->eventsModel->save_events($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success">Ev&egrave;nement annul&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'annulation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "activate")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '1'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->eventsModel->save_events($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success">Ev&egrave;nement activ&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'activation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
