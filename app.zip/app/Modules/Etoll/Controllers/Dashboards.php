<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Admin\Models\EtollCaisseModel;
use Modules\Admin\Models\EtollRatesModel;
use Modules\Etoll\Models\DashboardsModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\RatesModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\CurlModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\CashbooksModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Services\Amplitude\Controllers\Amplitude;

class Dashboards extends BaseController {
        /*
         * Presentation: Gestion des tableaux de bord
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('points','menus','summary','overview','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'dashboards';
        public $role;
        public $dashboardsModel;
        public $logirefModel;
        public $branchesModel;
        public $caissesModel;
        public $encaissementModel;
        public $ratesModel;
        public $integrationModel;
        public $usersModel;
        public $curlModel;
        public $productsModel;
        public $cashbooksModel;
        public $etollCaissesModel;
        public $etollRatesModel;
        public $eventsModel;
        public $ticketsModel;
        public $mainModel;
        public $amplitude;

        public function __construct()
	{

		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->dashboardsModel = new DashboardsModel();
                $this->logirefModel = new LogirefModel();
                $this->branchesModel= new BranchesModel();
                $this->caissesModel = new CaissesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->ratesModel = new RatesModel();
                $this->integrationModel = new IntegrationModel();
                $this->usersModel = new UsersModel();
                $this->curlModel = new CurlModel();
                $this->productsModel = new ProductsModel();
                $this->cashbooksModel = new CashbooksModel();
                $this->eventsModel = new EventsModel();
                $this->ticketsModel = new TicketsModel();
                $this->etollRatesModel = new EtollRatesModel();
                $this->etollCaissesModel = new EtollCaisseModel();

                $this->mainModel = new MainModel();
                $this->amplitude = new Amplitude();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'dashboards';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                
                //$this->data("set_exchange_rates");
                
                if(!$this->session->has('Logiref_privileges'))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if($this->session->has('Logiref_groupe') && $this->session->has('Logiref_role'))
                {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
	} 
	
        
	public function index()
	{
                $this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view("layouts/layout_main", $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($needle == "overview"){

                                if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') {

                                        if(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                                        {
                                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                        }
                                        else
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if(!isset($_SESSION['Exchange_rates']))
                                                {
                                                        $this->data("set_exchange_rates");
                                                }

                                                $this->data['sidebar'] = "";
                                                $this->data['subview'] = '\Modules\Etoll\Views\container';

                                                echo view('layouts/layout_main', $this->data);
                                        }
                                }

                        }
                        else{
                                $this->index();
                        }
                }
	}


        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                ############################ Menu Operateur ################
                if($obj == "points")
                {
                        
                        /*if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && ($_SESSION['Logiref_role'] > 2) )
                        {
                                $this->data['caisse_cdf'] = $caisse_cdf = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'CDF');
                                $this->data['caisse_usd'] = $caisse_usd =  $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'USD');
                        
                                $data_usd['bank_account'] = isset($caisse_usd->Compte_9) ? $caisse_usd->Compte_9 : "000000000000000000000000";
                                $data_usd['devise_account'] = 'USD';
                                $data_usd['amount'] = 0;

                                $data_cdf['bank_account'] = isset($caisse_cdf->Compte_9) ? $caisse_cdf->Compte_9 : "000000000000000000000000";
                                $data_cdf['devise_account'] = 'CDF';
                                $data_cdf['amount'] = 0;

                                $this->data['balance_usd'] = 0;
                                $this->data['balance_cdf'] = 0;
				//$this->data['balance_usd'] = $this->data('get_balance_by_account', $data_usd);
                                //$this->data['balance_cdf'] = $this->data('get_balance_by_account', $data_cdf);				
                                
                                $this->data['sidebar'] = '';
                                $this->data("default_values_new_taux");
                                $this->data("set_exchange_rates");
                             
                                
                                echo view('\Modules\Etoll\Views\rates\_taux', $this->data);
                        }*/
                        if($this->session->get('Logiref_role')==1)
                        {
                                echo view("\Modules\Etoll\Views\dashboards\_administrator",$this->data);
                        }
                        elseif($this->session->get('Logiref_role')==2 || $this->session->get('Logiref_role')==5 || $this->session->get('Logiref_role')==6 || $this->session->get('Logiref_role')==7)
                        {
                                echo view("\Modules\Etoll\Views\dashboards\_supervisor",$this->data);
                        }
                        elseif($this->session->get('Logiref_role')==3)
                        {
                                /*$this->data['colors'] = $this->caissesModel->status_color;
                                $this->data['status'] = $this->caissesModel->status;
                                $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                                $this->data['caisses'] = $this->caissesModel->get_caisses_by_agence();
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : "";
                                $this->data['agences'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");*/
                                echo view("\Modules\Etoll\Views\dashboards\_validator",$this->data);
                        }
                        elseif($this->session->get('Logiref_role')==4)
                        {

                                /*$this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                                $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                                $this->data['paiement'] = $this->encaissementModel->get_recents_paiements_partner();
                                $this->data['products'] = $this->productsModel->get_dropdown("products");
                                $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : 2850;
                                $this->data['status'] = $this->encaissementModel->status_tolls;
                                $this->data['status_color'] = $this->encaissementModel->color_tolls;
                                $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets_toll");
                                $this->data['stats'] = $this->data('stats_partner');
                                $this->data['stats_partner_pos'] = $this->data('stats_partner_by_pos');

                                echo view('\Modules\Etoll\Views\dashboards\_operator', $this->data);*/

                                $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                                $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                                $this->data['paiement'] = $this->encaissementModel->get_recents_paiements();
                                $this->data['cashbooks'] = $this->cashbooksModel->get_cashbooks();
                                $this->data['products'] = $this->productsModel->get_dropdown("products");
                                $this->data['branch_ticktes'] = $branch_ticktes = $this->ticketsModel->get_tickets_by_branch();
                                $this->data['evenement'] = $evenement = $this->eventsModel->get_events();

                                $event_tickets = array();

                                foreach($evenement as $row)
                                {
                                        foreach($branch_ticktes as $line)
                                        {
                                                if($line->Id_0 == $row->Id_0)
                                                {
                                                        $event_tickets[$row->Name_7][]= $line;
                                                }
                                        }
                                }

                                $this->data['event_tickets'] = $event_tickets; 

                                $this->data['events'] = $event = $this->eventsModel->get_dropdown("event");
                                $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                                $this->data['tpaiement'] = $this->encaissementModel->get_recents_paiements_ticket();
                                $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                                $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');

                                $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : "";
                                $this->data['status'] = $this->encaissementModel->status_tolls;
                                $this->data['status_color'] = $this->encaissementModel->color_tolls;
                                $this->data['type_product'] = $this->session->get('Sbbos_type');

                                $this->data['stats'] = $this->data('stats');
                                echo view('\Modules\Etoll\Views\dashboards\_menus', $this->data);

                        }
                        /*elseif($this->session->get('Logiref_role')==6)
                        {
                                $this->data['colors'] = $this->caissesModel->status_color;
                                $this->data['status'] = $this->caissesModel->status;
                                $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                                $this->data['caisses'] = $this->caissesModel->get_caisses_by_agence();
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : 2850;
                                $this->data['agences'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                                echo view('\Modules\Etoll\Views\dashboards\summary', $this->data);
                        }*/

                }
                ########################### Token ISYS-Regies ###############
                /*elseif($obj == "get_token_isys")
                {
                        set_time_limit(250);
                        
                        $data= array();
                        
                        if(isset($_SESSION['token_isys']) && $_SESSION['token_isys'] !="")
                        {
                                $token_time = $_SESSION['token_time'];
                                $current_time = gmdate('H:i:s');
                                
                                $token_time_1=strtotime($token_time);
                                $token_time_2=strtotime($current_time);
                                
                                $diff = $token_time_2 - $token_time_1;
 
                                $hour = floor(date('H:i:s', $diff));
                                
                                if($hour <= 3)
                                {
                                        $message = "The token exist";
                                }
                                else 
                                {
                                        $informations = $this->integrationModel->get_isys_account_info();
                                        
                                        $data['login'] = $informations->Login_7;
                                        $data['password'] = $informations->Password_8;
                                        
                                        $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");
                                        
                                        //$url = base_url('api/endpoints/logiref/login.php');
                                        //$this->load->library('curl');
                                        //$this->curl->create($url);
                                        //$this->curl->post($data);
                                        
                                        //$response = $this->curl->execute();
                                        
                                       //if($response!=NULL)
                                        //{
                                                //$message = " Login to isys_regie successful";
                                                //$this->data("set_log", $message, "isys");
                                                
                                                //$_SESSION['token_isys'] = $response;
                                                //$_SESSION['token_time'] = gmdate('H:i:s');
                                                
                                                
                                        //}
                                }
                        }
                        else
                        {
                                $informations = $this->integrationModel->get_isys_account_info();
                                        
                                $data['login'] = $informations->Login_7;
                                $data['password'] = $informations->Password_8;
                                
                                $this->save('token_isys', "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiJiYW5xdWUxQGlzeXMuYzJkZ291dmZpbi5uZXQiLCJyb2xlIjoiQkFOUVVFIiwibmJmIjoxNjA2MTM5NTE5LCJleHAiOjE2MDYyMjU5MTksImlhdCI6MTYwNjEzOTUxOX0.1f5HP8Fym9Cr-m5ThnqD8qNCHPJUuWxRrVVNNXCL76g");
                                        
                                //$url = base_url('api/endpoints/logiref/login.php');
                                //$this->load->library('curl');
                                //$this->curl->create($url);
                                //$this->curl->post($data);
                                
                                //$response = $this->curl->execute();
                                
                                //if($response!=NULL)
                                //{
                                        //$_SESSION['token_isys'] = $response;
                                        //$_SESSION['token_time'] = gmdate('H:i:s');
                                        
                                        //$this->save('token_isys', $response);
                                //}
                        }
                }*/
                ############################ Menu Operateur ################
                elseif($obj == "overview")
                {
                        if($_SESSION['Logiref_privileges'] != 0)
                        {

                                if(($_SESSION['Exchange_rates']==0 || $_SESSION['Exchange_rates']==1) && in_array($_SESSION['Logiref_role'],[3,4]))
                                {

                                        $this->data("default_values_new_taux");
                                        $this->data("set_exchange_rates");

                                        $this->data['caisse_cdf'] = $caisse_cdf = $this->etollCaissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'CDF');
                                        $this->data['caisse_usd'] = $caisse_usd =  $this->etollCaissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'USD');

                                        $data_usd['bank_account'] = isset($caisse_usd->Compte_9) ? $caisse_usd->Compte_9 : "000000000000000000000000";
                                        $data_usd['devise_account'] = 'USD';
                                        $data_usd['amount'] = 0;

                                        $data_cdf['bank_account'] = isset($caisse_cdf->Compte_9) ? $caisse_cdf->Compte_9 : "000000000000000000000000";
                                        $data_cdf['devise_account'] = 'CDF';
                                        $data_cdf['amount'] = 0;

                                        $this->data['balance_usd'] = 0;
                                        $this->data['balance_cdf'] = 0;

                                        echo view('\Modules\Etoll\Views\rates\_taux', $this->data); 

                                }
                                else
                                {
                                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                                        $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')])?$this->data['guichets'][$this->session->get('Logiref_guichet')]:"";
                                        $this->data['agence']= isset($this->data['agences'][$this->session->get('Logiref_agence')])?$this->data['agences'][$this->session->get('Logiref_agence')]:"";
                                        $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                                        $this->data['region'] = (!is_null($region))?$region->Nom_7:'';
                                        $this->data['role_user'] = (!empty($_SESSION['roles_banks']))?$_SESSION['roles_banks'][$this->session->get('Logiref_role')]:"";

                                        $this->data['paiement_cdf'] = $paiement_cdf = array();//$this->encaissementModel->get_stats("paiement_situation_cdf");
                                        $this->data['paiement_usd'] = $paiement_usd = array();//$this->encaissementModel->get_stats("paiement_situation_usd");
                                        $this->data['paiement_regie'] = array();//$this->encaissementModel->get_stats("paiement_situation_regie");
                                        $this->data['paiement'] = array();//$this->encaissementModel->get_stats("paiement");
                                        $this->data['pie_situation_cdf'] = array();//$this->data("pie-chart_operator", $paiement_cdf, "paiement_situation_cdf");
                                        $this->data['pie_situation_usd'] = array();//$this->data("pie-chart_operator", $paiement_usd, "paiement_situation_usd");
                                        $this->data['right_side']= $id;
                                        $this->data['beneficiaires'] = array();//$this->logirefModel->get_dropdown("services", $service=NULL);
                                        $this->data['encaissements'] = array();//$this->encaissementModel->get_paiements('penalities');
                                        $this->data['guichets'] = array();//$this->encaissementModel->get_dropdown("guichets");

                                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                        echo view('\Modules\Main\Views\overview', $this->data);
                                }
                        }
                        else
                        {
                                echo view('\Modules\Main\Views\overview', $this->data);
                        }
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }



        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if($obj == "set_privilegies")
                {
                        $this->usersModel->get_privilegies();
                }
                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                /*elseif($obj == "set_exchange_rates")
                {
                        $this->ratesModel->get_exchange_rates();
                }*/

                # Exchange rates
                #
                ################################################################################
                /*elseif($obj == "default_values_new_taux")
                {
                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['cmpt'] = $bank['Compte_9'];
                                $this->data['balance'] = $bank['Balance_10'];
                                $this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['cmpt'] = $bank['Compte_9'];
                                $this->data['balance'] = $bank['Balance_10'];
                                $this->data['guichet'] = $bank['Guichet_11'];
                                if($bank['Changer_6']==0): 
                                        $this->data['id'] = $bank['Id_0']; 
                                else :
                                        $this->data['id'] = ''; 
                                        $this->data['reset'] = 1; 
                                endif;   
                                
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['cmpt'] = $bank['Compte_9'];
                                $this->data['balance'] = $bank['Balance_10'];
                                $this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['cmpt'] = '';
                                $this->data['balance'] = 0.0;
                                $this->data['id'] = '';
                        }
                        
                        $this->data['action'] = '...';
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }
                        
                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] != '0')
                                    
                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                }*/

                elseif($obj == "set_exchange_rates")
                {
                        $this->etollRatesModel->get_exchange_rates();
                }

                # Exchange rates
                #
                ################################################################################
                elseif($obj == "default_values_new_taux")
                {

                        if(isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0)
                        {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['cmpt'] = '';//$bank['Compte_9'];
                                //$this->data['balance'] = $bank['Balance_10'];
                                //$this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-success">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_7'];
                                $this->data['eur'] = $bank['Euro_8'];
                                $this->data['cmpt'] = '';//$bank['Compte_9'];
                                //$this->data['balance'] = $bank['Balance_10'];
                                //$this->data['guichet'] = $bank['Guichet_11'];
                                #if($bank['Changer_6']==0): 
                                #        $this->data['id'] = $bank['Id_0']; 
                                #else :
                                #        $this->data['id'] = ''; 
                                #        $this->data['reset'] = 1; 
                                #endif;

                                $this->data['bank'] = $bank;
                        }
                        elseif(isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0)
                        {
                                $this->data['msg'] =  '<div class="alert alert-danger">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['cmpt'] = '';//$bank['Compte_9'];
                                //$this->data['balance'] = $bank['Balance_10'];
                                //$this->data['guichet'] = $bank['Guichet_11'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        }
                        else
                        {
                                $this->data['msg'] =  '<div class="alert alert-warning">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['cmpt'] = '';
                                $this->data['balance'] = 0.0;
                                $this->data['id'] = '';
                        }

                        $this->data['action'] = '...';

                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==0) 
                        {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;

                        if($_SESSION['Logiref_role']==3 && isset($_SESSION['Exchange_rates']))
                        {
                                $this->data['action'] = 'Confirmer'; 
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert alert-danger">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates']==1)
                        {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert alert-info">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        }
                        elseif($_SESSION['Logiref_role']==4)
                        {
                                if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] != '0')

                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }

                }

                ################################################################################
                # Dashboard Pie chart
                ################################################################################
                if($obj == "pie-chart")
                {
                        if($arg=='commission')
                        {
                                    $stats = $data;

                                    $datas = '
                                                {value:'.$stats[2].',label:"CDF",color:"#00C6F3",highlight:"green"},
                                                {value:'.$stats[3].',label:"CDF",color:"#0073b7",highlight:"aqua"},
                                                {value:'.$stats[1].',label:"CDF",color:"#00a65a",highlight:"aqua"},
                                                {value:'.$stats[4].',label:"Aucune commission",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                        elseif($arg=='paiement')
                        {
                                    $stats = $data;

                                    $datas = '
                                                {value:'.$stats[2].',label:"CDF",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats[3].',label:"CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats[1].',label:"CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats[4].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                }
                elseif($obj == "pie-chart_operator")
                {
                        if($arg=='paiement_situation_cdf')
                        {
                                    $stats = $data;
                                    //var_dump($stats); die;
                                    $datas = '
                                                {value:'.$stats['unvalidated'].',label:" CDF",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats['validated'].',label:" CDF",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats['reversed'].',label:" CDF",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats['none'].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                        elseif($arg=='paiement_situation_usd')
                        {
                                    $stats = $data;

                                    $datas = '
                                                {value:'.$stats['unvalidated'].',label:" USD",color:"#ffa500",highlight:"aqua"},
                                                {value:'.$stats['validated'].',label:" USD",color:"#00b461",highlight:"aqua"},
                                                {value:'.$stats['reversed'].',label:" USD",color:"#00bfff",highlight:"aqua"},
                                                {value:'.$stats['none'].',label:"Aucun paiement",color:"#dcdcdc",highlight:"aqua"},
                                            ';
                                    return $datas;
                        }
                }
                elseif($obj == "stats")
                {
                        $paiements = $this->encaissementModel->get_all_paiements('current_day');
                        
                        $stats = array(
                            'qte_ticket_sold'=>0,
                            'qte_toll_sold'=>0,
                            'qte_gopass_sold'=>0,
                            'amount_ticket_sold'=>0,
                            'amount_toll_sold'=>0,
                            'amount_gopass_sold'=>0,
                        );
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $taux = $result['Dollar_7'];
                        
                        foreach($paiements as $row)
                        {
                                if($row->Productid_7 == '1')
                                {
                                        $stats['qte_gopass_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '2')
                                {
                                        $stats['qte_toll_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '3')
                                {
                                        $stats['qte_ticket_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                }
                        }
                        
                        return $stats;
                }
                elseif($obj == "stats_partner")
                {
                        $paiements = $this->encaissementModel->get_paiements_partners();
                        
                        $stats = array(
                            'qte_toll_sold'=>0,
                            'amount_toll_sold'=>0,
                            'quote_part'=>0,
                        );
                        
                        if(isset($_SESSION['Bank_rates']))
                        {
                                $result = json_decode($_SESSION['Bank_rates'], true);
                                $taux = $result['Dollar_7'];
                        }
                        else
                        {
                                $taux = 200;
                        }
                        
                        foreach($paiements as $row)
                        {
                                if($row->Productid_7 == '2')
                                {
                                        $partners_info = json_decode($row->Partner_25, true);
                                        
                                        if (isset($partners_info['quota_partner']) && $partners_info['quota_partner'] != '')
                                        {
                                                for($i=0; $i<count($partners_info['quota_partner']); $i++)
                                                {
                                                        if($partners_info['partner'][$i] == $_SESSION['partner'])
                                                        {
                                                                $stats['qte_toll_sold']++;

                                                                if($row->Devise_11 == 'CDF')
                                                                {
                                                                        $partners_info['quota_partner'][$i] = ($partners_info['quota_partner'][$i] * $row->Amount_10)/100;

                                                                        $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;

                                                                        $stats['quote_part'] = $stats['quote_part'] + $partners_info['quota_partner'][$i];
                                                                }
                                                                else
                                                                {
                                                                        $row->Amount_10 = $row->Amount_10 * $taux;

                                                                        $partners_info['quota_partner'][$i] = ($partners_info['quota_partner'][$i] * $row->Amount_10)/100;

                                                                        $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                                                        $stats['quote_part'] = $stats['quote_part'] + $partners_info['quota_partner'][$i];
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                        
                        return $stats;
                }
                elseif($obj == "stats_partner_by_pos")
                {
                        $paiements = $this->encaissementModel->get_paiements_partners();
                        
                        $branches = $this->branchesModel->get_dropdown("guichets_toll");
                        
                        $branch_montant= array();
                        
                        $stats = array(
                            'qte_toll_sold'=>0,
                            'amount_toll_sold'=>0,
                            'quote_part'=>0,
                        );
                        
                        if(isset($_SESSION['Bank_rates']))
                        {
                                $result = json_decode($_SESSION['Bank_rates'], true);
                                
                                $taux = $result['Dollar_7'];
                        }
                        else
                        {
                                $taux = 200;
                        }
                        
                        foreach($branches as $key=>$line)
                        {
                                $branch_montant[$key] = 0;
                        }
                        
                        foreach($branches as $key=>$line)
                        {
                                foreach($paiements as $row)
                                {
                                        if($row->Branchid_26 == $key)
                                        {
                                                if($row->Productid_7 == '2')
                                                {
                                                        $partners_info = json_decode($row->Partner_25, true);
                                                        
                                                        if (isset($partners_info['quota_partner']) && $partners_info['quota_partner'] != '')
                                                        {
                                                                for($i=0; $i<count($partners_info['quota_partner']); $i++)
                                                                {
                                                                        if($partners_info['partner'][$i] == $_SESSION['partner'])
                                                                        {
                                                                                $stats['qte_toll_sold']++;

                                                                                if($row->Devise_11 == 'CDF')
                                                                                {
                                                                                        $partners_info['quota_partner'][$i] = ($partners_info['quota_partner'][$i] * $row->Amount_10)/100;

                                                                                        $branch_montant[$key] += $partners_info['quota_partner'][$i];
                                                                                }
                                                                                else
                                                                                {
                                                                                        $row->Amount_10 = $row->Amount_10 * $taux;
                                                                                        $partners_info['quota_partner'][$i] = ($partners_info['quota_partner'][$i] * $row->Amount_10)/100;

                                                                                        $branch_montant[$key] += $partners_info['quota_partner'][$i];
                                                                                }

                                                                        }
                                                                }
                                                        }

                                                }
                                        }
                                }
                        }

                        return $branch_montant;
                }
                elseif($obj == "get_balance_by_account")
                {
                        $response = $this->amplitude->check_balance_sbbos($data);
                       
                        //$response = json_decode($return, true);

                        if($response['code'] == '200')
                        {
                                return $response['balance'];
                        }
                        else 
                        {
                                 return $response['balance'] = 0;
                        }

                }
                elseif($obj == "OBJ ")
                {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */