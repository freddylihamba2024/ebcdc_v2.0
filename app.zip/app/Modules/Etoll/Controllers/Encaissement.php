<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Etoll\Models\CashbooksModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\AccountsModel;
use Modules\Etoll\Models\ComptabilisationModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\CurlModel;
use Modules\Etoll\Models\PartnersModel;
use Modules\Etoll\Models\RatesModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Services\Amplitude\Controllers\Amplitude;

class Encaissement extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('toll','closing','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'encaissements';
        public $amplitude;
        public $bank;
        public $role;
        public $core_banking;
        public $logirefModel;
        public $cashbooksModel;
        public $encaissementModel;
        public $caissesModel;
        public $productsModel;
        public $usersModel;
        public $branchesModel;
        public $ticketsModel;
        public $eventsModel;
        public $accountsModel;
        public $comptabilisationModel;
        public $integrationModel;
        public $curlModel;
        public $partnersModel;
        public $ratesModel;
        public $countersModel;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->logirefModel = new LogirefModel();
                $this->cashbooksModel = new CashbooksModel();
                $this->encaissementModel = new EncaissementModel();
                $this->caissesModel = new CaissesModel();
                $this->productsModel = new ProductsModel();
                $this->usersModel = new UsersModel();
                $this->branchesModel = new BranchesModel();
                $this->ticketsModel = new TicketsModel();
                $this->eventsModel = new EventsModel();
                $this->accountsModel = new AccountsModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->integrationModel = new IntegrationModel();
                $this->curlModel = new CurlModel();
                $this->partnersModel = new PartnersModel();
                $this->ratesModel = new RatesModel();
                $this->countersModel = new CountersModel();
                $this->amplitude = new Amplitude();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'encaissement';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
	} 
	
        
	public function index()
	{
                $this->data['subview'] = 'Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "ticket")
                {
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['modes'] = $this->ticketsModel->modes;
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                if($obj == "closing")
                {       
                        $closing_data_usd = $this->comptabilisationModel->get_closing_instructions("USD");
                        $closing_data_cdf = $this->comptabilisationModel->get_closing_instructions("CDF");
                        
                        $total_amount_usd = $this->data('closing', $closing_data_usd);
                        $total_amount_cdf = $this->data('closing', $closing_data_cdf);

                        $this->data['total_amount_usd'] = $total_amount_usd['USD'];
                        $this->data['total_amount_cdf'] = $total_amount_cdf['CDF'];

                        $agence_src = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                        
                        $this->data['compte_suspens_peage_cdf'] = isset($comptes['Rawbank']['CSP']['CDF']) ? $comptes['Rawbank']['CSP']['CDF'] : '000000000000000000000000';
                        $this->data['compte_secope_cdf'] = isset($comptes['SECOPE']['CPI']['CDF']) ? $comptes['SECOPE']['CPI']['CDF'] : '000000000000000000000000';
                        
                        $this->data['compte_suspens_peage_usd'] = isset($comptes['Rawbank']['CSP']['USD']) ? $comptes['Rawbank']['CSP']['USD'] : '000000000000000000000000';
                        $this->data['compte_secope_usd'] = isset($comptes['SECOPE']['CPI']['USD']) ? $comptes['SECOPE']['CPI']['USD'] : '000000000000000000000000';
                        
                        $this->data['daily_closing'] = $this->integrationModel->get_daily_closing();
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                if($obj == "__ticket")
                {
                        $this->data['paiement'] = $paiement =$this->encaissementModel->get_paiement_info($id);
                        $this->data['ticket'] = $ticket = $this->ticketsModel->get_ticket_info($paiement->Ticket_24);
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['modes'] = $this->ticketsModel->modes;
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        echo view('\Modules\Etoll\Views\encaissements\\'.$obj, $this->data);
                }
                elseif($obj == "get_ticket")
                {
                        $this->data['ticket'] = $ticket = $this->ticketsModel->get_ticket_info($id);
                        
                        if($ticket->Quantity_10 > 0)
                        {
                                $return ['qte'] = $ticket->Quantity_10;
                                echo json_encode($return);
                        }
                        else 
                        {
                                $return ['message'] = '<div class="alert alert-danger">Ce ticket n\'est plus disponible.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return ['qte'] = 0;
                                echo json_encode($return);
                        }
                }
                elseif($obj == "get_toll")
                {
                        $this->data("set_exchange_rates");
                        
                        if(isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] !=0)
                        {
                                $this->data['cashbooks'] = $cashbook = $this->cashbooksModel->get_cashbook_to_sell();
                                $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                                $this->data['modes'] = $this->encaissementModel->sbbos_modes;
                                $this->data['products'] = $this->productsModel->get_dropdown("product_toll");
                                $this->data['modes'] = $this->ticketsModel->modes;

                                if(!empty($cashbook))
                                {
                                        $return ['qte'] = $cashbook->Quantity_14;
                                        $qte_ticket = $cashbook->End_8 - $cashbook->Beginning_7 + 1;  
                                        $ticket_number = $cashbook->Beginning_7 + $qte_ticket - $cashbook->Quantity_14;
                                        $return ['number'] = $cashbook->Reference_13."-".$ticket_number;
                                        $return ['carnetid'] = $cashbook->Id_0;

                                        echo json_encode($return);
                                }
                                else 
                                {
                                        $return ['message'] = '<div class="alert alert-danger">Il n\'y a plus de ticket disponible, veuillez contacter votre superviseur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        $return ['qte'] = 0;

                                        echo json_encode($return);
                                }
                        }
                        else 
                        {
                                $return ['message'] = '<div class="alert alert-danger">Votre caisse est ferm&eacute;e, vous ne pouvez pas vendre un ticket. Veuillez vous d&eacute;connecter et vous reconnecter pour ouvrir la caisse.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return ['qte'] = 0;

                                echo json_encode($return);
                        }
                }
                elseif($obj == "illico_payment_ticket")
                {   
                        $result = array();
                        $mobile_length = strlen($_POST['phone']);
                        
                        if($mobile_length == 10)
                        {
                                $prefix = substr($_POST['phone'], 0,1);
                                
                                if($prefix == "0")
                                {
                                        $mobile = substr($_POST['phone'], 1);
                                        $mobile = "00243".$mobile;
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        elseif($mobile_length == 13)
                        {
                                $prefix = substr($_POST['phone'], 0,4);
                                
                                if($prefix == '+243')
                                {
                                        $mobile = substr($_POST['phone'], 1);
                                        $mobile = "00".$mobile;
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        elseif($mobile_length == 14)
                        {
                                $prefix = substr($_POST['phone'], 0,5);
                                
                                if($prefix == '00243')
                                {
                                        $mobile = substr($_POST['phone'], 1);
                                        $mobile = "00".$mobile;
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        else
                        {
                                $result['code'] = "E423";
                                echo json_encode($result['code']); die;
                        }
                        
                        #Data to send to illicocash API
                        $data_to_send = array();
                        
                        $data_to_send['mobilenumber'] = $mobile;
                        $data_to_send['trancurrency'] = isset($_POST['currency']) ? $_POST['currency'] : "";
                        $data_to_send['amount'] = isset($_POST['price']) ? $_POST['price'] : "";
                        $data_to_send['invoiceid'] = isset($_POST['refpaiement']) ? $_POST['refpaiement'] : "";
                        $data_to_send['terminalid'] = "1234567890123";
                        $data_to_send['gpslatitude'] = "24.864190";
                        $data_to_send['gpslongitude'] = "67.09042";
                        
                        $credentials = $this->countersModel->get_credentials($_SESSION['Logiref_branch']);
                        $data_to_send['credentials'] = $credentials->Credentials_15;
                        
                        $response = $this->amplitude->call_bank_illico_payment_sbbos($data_to_send);
                        
                        $return = json_decode($response);
                        
                        if(isset($return->code) && $return->code == '200')
                        {
                                $result['code'] = $return->code;
                                $result['refnumber'] = $return->payment->referencenumber;
                                $result['rrn'] = $return->payment->rrn;
                                $result['stan'] = $return->payment->stan;
                                
                                echo json_encode($result);
                        }
                        elseif(isset($return->code))
                        {
                                $result['code'] = $return->code;
                                $result['msg'] = $return->msg;
                                
                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = "E400";
                                echo json_encode($result['code']); die;
                        }
                }
                elseif($obj == "illico_payment_toll")
                {   
                        $result = array();
                        $mobile_length = strlen($_POST['phone']);
                        
                        if($mobile_length == 10)
                        {
                                $prefix = substr($_POST['phone'], 0,1);
                                
                                if($prefix == "0")
                                {
                                        $mobile = substr($_POST['phone'], 1);
                                        $mobile = "00243".$mobile;
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        elseif($mobile_length == 13)
                        {
                                $prefix = substr($_POST['phone'], 0,4);
                                
                                if($prefix == '+243')
                                {
                                        $mobile = substr($_POST['phone'], 1);
                                        $mobile = "00".$mobile;
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        elseif($mobile_length == 14)
                        {
                                $prefix = substr($_POST['phone'], 0,5);
                                
                                if($prefix == '00243')
                                {
                                        $mobile = $_POST['phone'];
                                }
                                else
                                {
                                        $result['code'] = "E423";
                                        echo json_encode($result['code']); die;
                                }
                        }
                        else
                        {
                                $result['code'] = "E423";
                                echo json_encode($result['code']); die;
                        }
                        
                        #Data to send to illicocash API
                        $data_to_send = array();
                        
                        $data_to_send['mobilenumber'] = $mobile;
                        $data_to_send['trancurrency'] = isset($_POST['Devise_11']) ? $_POST['Devise_11'] : "";
                        $data_to_send['amount'] = isset($_POST['Amount_10']) ? $_POST['Amount_10'] : "";
                        $data_to_send['invoiceid'] = isset($_POST['refpaiement']) ? $_POST['refpaiement'] : "";
                        $data_to_send['terminalid'] = "1234567890123";
                        $data_to_send['gpslatitude'] = "24.864190";
                        $data_to_send['gpslongitude'] = "67.09042";
                        $data_to_send['gpslongitude'] = "67.09042";
                        
                        $credentials = $this->countersModel->get_credentials($_SESSION['Logiref_branch']);
                        
                        $data_to_send['credentials'] = isset($credentials->Credentials_15) ? $credentials->Credentials_15 : "";
                        $return = $this->amplitude->call_bank_illico_payment_sbbos($data_to_send);
                        
                        if($return['code'] == 200)
                        {
                                $result['code'] = $return['code'];
                                $result['refnumber'] = $return['payment']['referencenumber'];
                                $result['rrn'] = $return['payment']['rrn'];
                                $result['stan'] = $return['payment']['stan'];
                                
                                echo json_encode($result);
                        }
                        elseif($return['code'] == 400)
                        {
                                $result['code'] = $return['code'];
                                $result['msg'] = $return['msg'];
                                
                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = "E400";
                                echo json_encode($result['code']); die;
                        }
                }
                elseif($obj == "card_confirmation_ticket")
                { 
                        #Data to send to mpgs API
                        $data_to_send = array();
                        
                        $expire_date = isset($_POST['expire_date']) ? $_POST['expire_date'] : "";
                        $date = explode("-", $expire_date);
                        
                        if(isset($date[0])) $year = substr($date[0], 2,3);
                        else $year ="";
                        
                        $data_to_send['pan'] = isset($_POST['card_number']) ? $_POST['card_number'] : "";
                        $data_to_send['expmonth'] = isset($date[1]) ? $date[1] : "";
                        $data_to_send['expyear'] = $year;
                        $data_to_send['ordercurrency'] = isset($_POST['amount_currency']) ? $_POST['amount_currency'] : "";
                        $data_to_send['amount'] = isset($_POST['amount']) ? $_POST['amount'] : "";
                        $data_to_send['orderid'] = isset($_POST['refnumber_card']) ? $_POST['refnumber_card'] : "";
                        $data_to_send['transactid'] = isset($_POST['refnumber_card']) ? $_POST['refnumber_card'] : "";
                        $data_to_send['browser'] = 'CHROME';
                        $data_to_send['ipAddress'] = '34.68.198.15';
                        $data_to_send['urlredirect'] = "http://34.68.198.15";
                        
                        $response = $this->curlModel->call_bank_mpgs_payment($data_to_send);
                        $return = json_decode($response);
                        
                        $html = str_replace("'", "", $return->transaction->redirectHtml);
                        
                        $returns = array();
                        $returns['html'] = htmlspecialchars_decode($html);
                        
                        echo json_encode($returns);
                }
                elseif($obj == "_additional_field_ticket")
                {
                        $this->data['ticket'] = $ticket = $this->ticketsModel->get_ticket_info($id);
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");

                        echo view('\Modules\Etoll\Views\encaissements\\'.$obj, $this->data);
                }
                elseif($obj == "toll")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['products'] = $this->productsModel->get_dropdown("product_toll");
                        $this->data['modes'] = $this->ticketsModel->modes;
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                elseif($obj == "gopass")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['products'] = $this->productsModel->get_dropdown("product_gopass");
                        $this->data['modes'] = $this->ticketsModel->modes;
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                elseif($obj == "_additional_field_product")
                {
                        $product = $this->productsModel->get_product_info($id);
                        
                        if($product->Type_13 == '1')
                        {
                                $this->display('_additional_field_gopass', $id);
                        }
                        else
                        {
                                $this->display('_additional_field_toll', $id);
                        }
                }
                elseif($obj == "_additional_field_toll")
                {       
                        $this->data['product'] = $product = $this->productsModel->get_product_info($id);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        
                        if($product->Currency_10 == '')
                        {
                                if(isset($product->Range_19) &&$product->Range_19 !="")
                                {
                                        $range = json_decode($product->Range_19);
                                        $result = current($range);
                                        $product->Currency_10 = isset($result->currency) ? $result->currency : ""; 
                                }
                        }
                        
                        if($product->Currency_10 == 'USD')
                        {
                                $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'USD');
                        }
                        else
                        {
                                $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch'], 'CDF');
                        }
                        
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($_SESSION['Logiref_branch']);
                        
                        $this->data['number'] = $_GET['number'];
                        $this->data['carnetid'] = $_GET['carnetid'];
                        $this->data['mode'] = $_GET['mode'];
                        
			echo view('\Modules\Etoll\Views\encaissements\\'.$obj, $this->data);
                }
                elseif($obj == "_additional_field_gopass")
                {
                        $this->data['product'] = $this->productsModel->get_product_info($id);
                        $airports = $this->encaissementModel->get_dropdown("airport");
                        $this->data['airport_national'] = $airport_national = $this->encaissementModel->get_dropdown("airport_national");
                        $this->data['airport_by_branch'] = $airport_by_branch = $this->encaissementModel->get_dropdown("airport_by_branch");
                        $this->data['companies'] = $this->encaissementModel->airline_companies;
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                        $this->data['branch_info'] = $branch = $this->branchesModel->get_guichet_info($_SESSION['Logiref_branch']);
                        
                        $airport_id = isset($airport_by_branch[$branch->Id_0]) ? $airport_by_branch[$branch->Id_0] : "";
                        
                        if(isset($airports[$airport_id]))
                        {
                                unset($airports[$airport_id]);
                        }
                        
                        $this->data['airports'] = $airports;
                        
                        echo view('\Modules\Etoll\Views\encaissements\\'.$obj, $this->data);
                }
                elseif($obj == "dropdown_toll")
                {
                        $products = $this->productsModel->get_product_info($id);
                        echo json_encode($products);
                }
                elseif($obj == "companies_dropdowns")
                {
                        if ($id == 2):
                            $airport = $this->encaissementModel->international_airline;
                            echo form_dropdown('Company_14', $airport, '',  ' required="required" class="form-control"');
                            
                        else:
                            $airport = $this->encaissementModel->national_airline;
                            echo form_dropdown('Company_14', $airport, '',  ' required="required" class="form-control"');
                        endif;
                }
                elseif($obj == "preview_gopass") 
                {
                        $this->data['airport'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['types'] = $this->encaissementModel->types_vol;
                        $this->data['national_airline'] = $this->encaissementModel->national_airline;
                        $this->data['international_airline'] = $this->encaissementModel->international_airline;
                        $this->data['paiement'] = $this->encaissementModel->get_paiement_info($id);
                        
                        echo view('\Modules\Etoll\Views\encaissements\_preview_gopass', $this->data);
                }
                elseif($obj == "preview_toll") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['paiement'] = $this->encaissementModel->get_paiement_info($id);
                        
                        echo view('\Modules\Etoll\Views\encaissements\_preview_toll', $this->data);
                }
                elseif($obj == "toll_detail") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['modes'] = $this->encaissementModel->sbbos_modes;
                        $this->data['products'] = $this->productsModel->get_dropdown("product_toll");
                        $this->data['modes'] = $this->ticketsModel->modes;
                        
                        $this->data['paiement'] = $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        $this->data['product'] = $product = $this->productsModel->get_product_info($paiement->Type_12);
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($_SESSION['Logiref_branch']);
                        
                        $this->data['number'] = $paiement->Carnetnumber_35;
                        $this->data['carnetid'] = $paiement->Carnetid_34;
                        $this->data['element'] = $arg;
                        $this->data['datas'] = json_encode($_GET);
                        
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                elseif($obj == "ticket_detail") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['modes'] = $this->ticketsModel->modes;
                        $this->data['paiement'] = $paiement = $this->encaissementModel->get_paiement_info($id);
                        $this->data['ticket'] = $ticket = $this->ticketsModel->get_ticket_info($paiement->Ticket_24);
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['caisse_info'] = $this->caissesModel->get_caisse_by_branchid($_SESSION['Logiref_branch']);
                        $this->data['branch_info'] = $this->branchesModel->get_guichet_info($_SESSION['Logiref_branch']);
                        
                        echo view('\Modules\Etoll\Views\encaissements\_'.$obj, $this->data);
                }
                elseif($obj == "airport_dropdown")
                {
                        $airport = $this->encaissementModel->get_airport_info($id); 
                        echo json_encode($airport);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "closing")
                {
                        $data = $_POST;
                        $uid = '';
                        $cid = '';
                        
                        if (isset($data['USD']))
                        {
                                $data['USD']['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['USD']['Status_2'] = '1';
                                $data['USD']['Account_3'] = $this->session->userdata['account_id'];
                                $data['USD']['Creator_4'] = $this->session->userdata['user_id'];
                                $data['USD']['Counter_14'] = $_SESSION['Logiref_branch'];
                                
                                $uid = $this->integrationModel->save_closing($data['USD'], NULL);
                        }
                        
                        if (isset($data['CDF']))
                        {
                                $data['CDF']['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['CDF']['Status_2'] = '1';
                                $data['CDF']['Account_3'] = $this->session->userdata['account_id'];
                                $data['CDF']['Creator_4'] = $this->session->userdata['user_id'];
                                $data['CDF']['Counter_14'] = $_SESSION['Logiref_branch'];
                                
                                $cid = $this->integrationModel->save_closing($data['CDF'], NULL);
                        }
 
                        if(!empty($cid) || !empty($uid))
                        {
                                $agence_src = $_SESSION['Logiref_guichet'];
                                $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                                
                                $counters = $this->branchesModel->get_dropdown("guichets_toll");
                                $ref = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');

                                if (isset($data['USD']))
                                {
                                        $instructions_usd = $this->comptabilisationModel->get_instructions_closing($data['USD'], $comptes, $counters);
                                        
                                        if(!empty($instructions_usd))
                                        {
                                                $this->comptabilisationModel->save_instructions_closing($uid, $data['USD'], $instructions_usd, $ref);
                                        }
                                }
                                
                                if (isset($data['CDF']))
                                {
                                        $instructions_cdf = $this->comptabilisationModel->get_instructions_closing($data['CDF'], $comptes, $counters);
                                        
                                        if(!empty($instructions_cdf))
                                        {
                                                $this->comptabilisationModel->save_instructions_closing($cid, $data['CDF'], $instructions_cdf, $ref);
                                        }
                                }
                                
                                $return['message'] = '<div class="alert alert-success">Bravo! le nivellement est fait avec succ&egrave;s. <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return['cid'] = $cid;
                                $return['uid'] = $uid;
                                $return['ref'] = $ref;

                                echo json_encode($return);
                        }
                        else 
                        {
                                echo 0;
                        }
                }
                elseif($obj == "toll")
                {
                        if($_POST['Departure_15']=='' || $_POST['cashregister_id']==''  || $_POST['Destination_16']=='' || $_POST['Amount_10']=='' || $_POST['Devise_11']=='' || $_POST['Type_12']=='' || $_POST['Productid_7']==''):
                                $return['message'] = '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        endif;
                        
                        $data['Productid_7'] = $this->request->getPost('Productid_7');
                        $data['Designation_8'] = isset($_POST['Designation_8']) ? $_POST['Designation_8'] : "";
                        $data['Amount_10'] = $this->request->getPost('Amount_10');
                        $data['Devise_11'] = $this->request->getPost('Devise_11');
                        $data['Numero_13'] = $this->request->getPost('Numero_13');
                        $data['Type_12'] = $this->request->getPost('Type_12');
                        $data['Departure_15'] = $this->request->getPost('Departure_15');
                        $data['Destination_16'] = $this->request->getPost('Destination_16');
                        $data['Cashregister_20'] = $_POST['cashregister_id'];
                        if(isset($_POST['Company_14']) && $_POST['Company_14'] != '') $data['Company_14'] = $this->request->getPost('Company_14');
                        $data['Reference_19'] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        $data['Agence_21'] = $_SESSION['Logiref_guichet'];
                        $data['Branchid_26']= isset($_SESSION['Logiref_branch']) ? $_SESSION['Logiref_branch'] : 0;
                        $data['Mode_29']= isset($_POST['mode']) ? $_POST['mode'] : "";
                        if(isset($_POST['phone']) && $_POST['phone'] !="") $data['Phone_30']= $_POST['phone'];
                        if(isset($_POST['email']) && $_POST['email'] !="") $data['Email_31']= $_POST['email'];
                        $data['Carnetid_34']= isset($_POST['carnetid']) ? $_POST['carnetid'] : "";
                        $data['Carnetnumber_35']= isset($_POST['carnetnumber']) ? $_POST['carnetnumber'] : "";
                        
                        if(isset($_POST['Numero_13']) && $_POST['Numero_13'] != "")
                        {
                                $data['Numero_13'] = $this->request->getPost('Numero_13');
                        }
                        
                        # Reference CBS (6 chiffres)
                        if(isset($_POST['refcbs']) && $_POST['refcbs'] != "")
                        {
                                $data['Refcbs_38'] = $this->request->getPost('refcbs');
                        }
                        
                        $result = $this->encaissementModel->get_paiement_by_cbs_reference($data['Refcbs_38']);
                        
                        if(isset($result->Id_0) && $result->Id_0 > 0)
                        {
                                $return['message'] =  '<div class="alert alert-danger">D&eacute;sol&eacute;, le paiement avec cette r&eacute;f&eacute;rence cbs '.$data['Refcbs_38'].' existe d&eacute;j&agrave;.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                echo json_encode($return);
                        }
                        else
                        {
                                if(isset($_POST['Additionnal_field']) && $_POST['Additionnal_field'] !="")
                                {
                                        $data['Additional_27']= json_encode($_POST['Additionnal_field']);
                                }
                                else
                                {
                                        if($_POST['toll_id'] !="")
                                        {
                                                $data['Additional_27']= "";
                                        }
                                }

                                if(isset($_POST['Weight_15']) && $_POST['Weight_15'] != "") $data['Weight_15'] = $_POST['Weight_15'];

                                if($_POST['toll_id'] =="")
                                {
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']=$this->session->userdata['account_id'];
                                        $data['Creator_4']=$this->session->userdata['user_id'];

                                        if($data['Productid_7'] == '1') $data['Refpaiement_22'] = "G".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');

                                        else $data['Refpaiement_22'] = "P".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                }
                                else
                                {
                                        $data['Changes_5']=gmdate('Y-m-d H:i:s');
                                        $data['Changer_6']=$this->session->userdata['user_id'];

                                        $data['Refpaiement_22'] = $_POST['refpaiement'];
                                }

                                $product = $this->productsModel->get_product_info($data['Type_12']);

                                if($product->Partners_20 !="")
                                {
                                        #Comptabilisation
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $agence_dst=NULL;
                                        $list = NULL;
                                        $comptes_recettes = NULL;

                                        $data['compte'] = isset($_POST['compte']) ? $_POST['compte'] : "";

                                        $comptes = $this->accountsModel->get_comptes_array($list, $agence_src, $agence_dst);

                                        $product_names = $this->data['products'] = $this->productsModel->get_dropdown("products");

                                        $data['tarif'] = isset($product_names[$data['Type_12']]) ? $product_names[$data['Type_12']] : "";

                                        $data_partners = array();
                                        $partners = json_decode($product->Partners_20, true);

                                        $partner_names = $this->partnersModel->get_dropdown('partners');

                                        $j=0;

                                        for($i=0; $i<count($partners['beneficiaire']); $i++)
                                        {
                                                if($partners['beneficiaire'][$i] == 'Banque')
                                                {
                                                        $data['montant'] =  $data['Amount_10'];
                                                        $data['devise'] = $data['Devise_11'];

                                                        if($_POST['mode'] != 8)
                                                        {
                                                                $instruction = $this->comptabilisationModel->get_instructions_bank_fees_toll($data, $comptes);

                                                                $instructions = array();

                                                                foreach ($instruction as $row)
                                                                {
                                                                        $instructions[] = $row;
                                                                }
                                                        }
                                                        else
                                                        {
                                                                # If payment method is illicocash, no instructions saved
                                                                $instructions = array();
                                                        }
                                                }
                                                else
                                                {
                                                        $data_partners['quota_partner'][$j] = isset($partners['quota'][$i]) ? ($partners['quota'][$i] * $data['Amount_10'])/100 : "";
                                                        $data_partners['partner'][$j] = isset($partners['beneficiaire'][$i]) ? $partners['beneficiaire'][$i] : "";

                                                        $j++;
                                                }
                                        }

                                        unset($data['tarif']);
                                        unset($data['compte']);
                                        unset($data['montant']);
                                        unset($data['devise']);


                                        if(!empty($instructions))
                                        {
                                                if(isset($_POST['toll_id']) && $_POST['toll_id'] !="")
                                                {
                                                        $this->comptabilisationModel->delete_instructions($data['Refpaiement_22']);
                                                }

                                                $this->comptabilisationModel->save_instructions($data['Refpaiement_22'], $data, $instructions, $data['Refpaiement_22']);
                                        } 

                                        $data['Partner_25'] = json_encode($data_partners);
                                }
                                else
                                {
                                        #Comptabilisation
                                        $agence_src= $_SESSION['Logiref_guichet'];
                                        $agence_dst=NULL;
                                        $list = NULL;
                                        $comptes_recettes = NULL;

                                        $data['compte'] = isset($_POST['compte']) ? $_POST['compte'] : "";

                                        $comptes = $this->accountsModel->get_comptes_array($list, $agence_src, $agence_dst);

                                        $product = $this->data['products'] = $this->productsModel->get_dropdown("products");

                                        $data['montant'] =  $data['Amount_10'];
                                        $data['devise'] = $data['Devise_11'];
                                        $data['tarif'] = isset($product[$data['Type_12']]) ? $product[$data['Type_12']] : "";

                                        if($_POST['mode'] != 8)
                                        {
                                                $instructions = $this->comptabilisationModel->get_instructions_bank_fees_toll($data, $comptes);
                                        }
                                        else
                                        {
                                                # If payment method is illicocash, no instructions saved
                                                $instructions = array();
                                        }

                                        unset($data['montant']);
                                        unset($data['devise']);
                                        unset($data['compte']);
                                        unset($data['tarif']);


                                        if(!empty($instructions))
                                        {
                                                if(isset($_POST['toll_id']) && $_POST['toll_id'] !="")
                                                {
                                                        $this->comptabilisationModel->delete_instructions($data['Refpaiement_22']);
                                                }

                                                $this->comptabilisationModel->save_instructions($data['Refpaiement_22'], $data, $instructions, $data['Refpaiement_22']);
                                        }
                                }
                                
                                if(isset($_POST['toll_id']) && $_POST['toll_id'] !="")
                                {
                                        $oid = $this->encaissementModel->save_paiements($data, $_POST['toll_id']);
                                }
                                else
                                {
                                        $oid = $this->encaissementModel->save_paiements($data, NULL);
                                }

                                if (isset($oid) && $oid!=NULL) 
                                {
                                        if(isset($_POST['toll_id']) && $_POST['toll_id'] !="")
                                        {
                                                $return['message'] = '<div class="alert alert-success">La modification est faite avec succes !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                $return['id'] = $oid;
                                                $return['product'] = $data['Productid_7'];
                                                $return['ref'] = $data['Refpaiement_22'];

                                                echo json_encode($return);
                                        }
                                        else 
                                        {
                                                $data_ticket = array();
                                                $ticket = $this->cashbooksModel->get_cashbook_info($_POST['carnetid']);

                                                $data_ticket['Quantity_14'] = $ticket->Quantity_14 - 1;
                                                $data_ticket['Lock_15'] = 1;

                                                $this->cashbooksModel->update_ticket_number($data_ticket, $_POST['carnetid']);

                                                $return['message'] = '<div class="alert alert-success">Votre enregistrement est fait avec succes !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                $return['id'] = $oid;
                                                $return['product'] = $data['Productid_7'];
                                                $return['ref'] = $data['Refpaiement_22'];

                                                echo json_encode($return);
                                        }
                                }
                                else
                                {
                                       $return['message'] =  '<div class="alert alert-danger">D&eacute;sol&eacute; Vos donn&eacute;es ne sont pas enregistr&eacute;es!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                       echo json_encode($return);
                                }
                        }
                }
                elseif($obj == "gopass_batch")
                {
                        $airports = $this->encaissementModel->get_dropdown("airport");
                        $departure = $this->request->getPost('Departure_15');
                        $destination = $this->request->getPost('Destination_16');
                        $number_vol = $this->request->getPost('Numero_13');
                        
                        $designation = $airports[$departure]. " \\ " .$airports[$destination] ." - ". $number_vol;
                        
                        $start_series = (int) $this->request->getPost('Number_start');
                        $end_series = (int) $this->request->getPost('Number_end');
                        
                        if ($start_series == $end_series):
                                echo '<div class="alert alert-warning">Le numéro série de la tête ne peut pas être égal à celui de la queue!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                die;
                        elseif ($end_series < $start_series):
                                echo '<div class="alert alert-warning">Le numéro série de la tête doit toujours être inférieur à celui de la queue!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                die;
                        else :
                            $series_number = ($end_series - $start_series) + 1;
                        endif;
                        
                        $date = new DateTime();
                        $date = $date->format('Y-m-d H:i:s');

                        for ($i = 0; $i < $series_number; $i++ ) 
                        {

                                $inserdata[$i]['Date_1'] = $date;
                                $inserdata[$i]['Status_2'] = '1';
                                $inserdata[$i]['Account_3'] = $this->session->userdata['account_id'];
                                $inserdata[$i]['Creator_4'] = $this->session->userdata['user_id'];
                                $inserdata[$i]['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $inserdata[$i]['Changer_6'] = $this->session->userdata['user_id'];
                                $inserdata[$i]['Designation_8'] = $designation;
                                $inserdata[$i]['Amount_10'] = $this->request->getPost('Amount_10');
                                $inserdata[$i]['Devise_11'] = "USD";
                                $inserdata[$i]['Type_12'] = $this->request->getPost('Type_12');
                                $inserdata[$i]['Numero_13'] = $this->request->getPost('Numero_13'). ''.$i ;
                                $inserdata[$i]['Company_14'] = $this->request->getPost('Company_14');
                                $inserdata[$i]['Departure_15'] = $this->request->getPost('Departure_15');
                                $inserdata[$i]['Destination_16'] = $this->request->getPost('Destination_16');
                                $inserdata[$i]['Serial_17'] = $start_series + $i;
                                $data['Controller_18'] = 'B';
                                $inserdata[$i]['Cashregister_20'] = $_SESSION['Logiref_caisse'];
                                $inserdata[$i]['Agence_21'] = $_SESSION['Logiref_guichet'];
                                $inserdata[$i]['Reference_19 '] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        }

                        $result = $this->encaissementModel->save_paiements_batch($inserdata, "logiref_sbbos_paiements");
                    
                        if($result):
                        
                                echo '<div class="alert alert-success">Donn&eacute;e enr&eacute;gistrer avec succ&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';    
                        else:
                                echo '<div class="alert alert-danger">Ce type fichier n\'est pas autoris&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        endif;
                }
                elseif($obj == "toll_batch")
                {
                        if($_POST['Departure_15']=='' || $_POST['cashregister_id']==''  || $_POST['Destination_16']=='' || $_POST['Amount_10']=='' || $_POST['Devise_11']=='' || $_POST['Numero_13']=='' || $_POST['Designation_8']=='' || $_POST['Type_12']=='' || $_POST['Productid_7']=='' || $_POST['quantity']==''):
                                $return['message'] = '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        endif;
                        
                        for($i=0; $i < $_POST['quantity']; $i++):
                        
                                if($id =='0' || $id ==''):
                                        $inserdata[$i]['Date_1']=gmdate('Y-m-d H:i:s');
                                        $inserdata[$i]['Status_2']=1;
                                        $inserdata[$i]['Account_3']=$this->session->userdata['account_id'];
                                        $inserdata[$i]['Creator_4']=$this->session->userdata['user_id'];
                                else:
                                        $inserdata[$i]['Changes_5']=gmdate('Y-m-d H:i:s');
                                        $inserdata[$i]['Changer_6']=$this->session->userdata['user_id'];
                                endif;
                                
                                # Value product for ticket events
                                $inserdata[$i]['Productid_7'] = $this->request->getPost('Productid_7');
                                $inserdata[$i]['Designation_8'] = $this->request->getPost('Designation_8');
                                
                                #Formatting amount
                                $inserdata[$i]['Amount_10'] = str_replace(' ','',$_POST['Amount_10']);
                                $inserdata[$i]['Amount_10'] = str_replace(',','.',$inserdata[$i]['Amount_10']);
                                
                                $inserdata[$i]['Devise_11'] = $this->request->getPost('Devise_11');
                                $inserdata[$i]['Numero_13'] = $this->request->getPost('Numero_13');
                                $inserdata[$i]['Type_12'] = $this->request->getPost('Type_12');
                                $inserdata[$i]['Departure_15'] = $this->request->getPost('Departure_15');
                                $inserdata[$i]['Destination_16'] = $this->request->getPost('Destination_16');
                                $inserdata[$i]['Cashregister_20'] = $_POST['cashregister_id'];
                                
                                if(isset($_POST['Company_14']) && $_POST['Company_14'] != '') $inserdata[$i]['Company_14'] = $this->request->getPost('Company_14');
                                
                                $inserdata[$i]['Reference_19'] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $inserdata[$i]['Agence_21'] = $_SESSION['Logiref_guichet'];

                                if($_POST['Productid_7'] == '1') :
                                        $inserdata[$i]['Refpaiement_22'] = "G".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                else:
                                        $inserdata[$i]['Refpaiement_22'] = "P".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                endif;
                        endfor;
                        

                        #$oid = $this->encaissement_model->save_paiements($data, $id);
                        
                        $oid = $this->encaissementModel->save_paiements_batch($inserdata, "logiref_sbbos_paiements");

                        if (isset($oid) && $oid!=NULL):
                                $return['message'] = '<div class="alert alert-success">Votre enregistrement est fait avec succes !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return['id'] = $oid;
                                $return['product'] = $_POST['Productid_7'];
                                echo json_encode($return);
                        else:
                               $return['message'] =  '<div class="alert alert-danger">D&eacute;sol&eacute; Vos donn&eacute;es ne sont pas enregistr&eacute;es!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                               echo json_encode($return);
                        endif;
                }
                elseif($obj == "gopass_batch")
                {
                        $airports = $this->encaissementModel->get_dropdown("airport");
                        $departure = $this->request->getPost('Departure_15');
                        $destination = $this->request->getPost('Destination_16');
                        $number_vol = $this->request->getPost('Numero_13');
                        
                        $designation = $airports[$departure]. " \\ " .$airports[$destination] ." - ". $number_vol;
                        
                        $start_series = (int) $this->request->getPost('Number_start');
                        $end_series = (int) $this->request->getPost('Number_end');
                        
                        if ($start_series == $end_series):
                                echo '<div class="alert alert-warning">Le numéro série de la tête ne peut pas être égal à celui de la queue!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                die;
                        elseif ($end_series < $start_series):
                                echo '<div class="alert alert-warning">Le numéro série de la tête doit toujours être inférieur à celui de la queue!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                die;
                        else :
                            $series_number = ($end_series - $start_series) + 1;
                        endif;
                        
                        $date = new DateTime();
                        $date = $date->format('Y-m-d H:i:s');

                        for ($i = 0; $i < $series_number; $i++ ) 
                        {

                                $inserdata[$i]['Date_1'] = $date;
                                $inserdata[$i]['Status_2'] = '1';
                                $inserdata[$i]['Account_3'] = $this->session->userdata['account_id'];
                                $inserdata[$i]['Creator_4'] = $this->session->userdata['user_id'];
                                $inserdata[$i]['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $inserdata[$i]['Changer_6'] = $this->session->userdata['user_id'];
                                $inserdata[$i]['Designation_8'] = $designation;
                                $inserdata[$i]['Amount_10'] = $this->request->getPost('Amount_10');
                                $inserdata[$i]['Devise_11'] = "USD";
                                $inserdata[$i]['Type_12'] = $this->request->getPost('Type_12');
                                $inserdata[$i]['Numero_13'] = $this->request->getPost('Numero_13'). ''.$i ;
                                $inserdata[$i]['Company_14'] = $this->request->getPost('Company_14');
                                $inserdata[$i]['Departure_15'] = $this->request->getPost('Departure_15');
                                $inserdata[$i]['Destination_16'] = $this->request->getPost('Destination_16');
                                $inserdata[$i]['Serial_17'] = $start_series + $i;
                                $data['Controller_18'] = 'B';
                                $inserdata[$i]['Cashregister_20'] = $_SESSION['Logiref_caisse'];
                                $inserdata[$i]['Agence_21'] = $_SESSION['Logiref_guichet'];
                                $inserdata[$i]['Reference_19 '] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        }

                        $result = $this->encaissementModel->save_paiements_batch($inserdata, "logiref_sbbos_paiements");
                    
                        if($result):
                        
                                echo '<div class="alert alert-success">Donn&eacute;e enr&eacute;gistrer avec succ&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';    
                        else:
                                echo '<div class="alert alert-danger">Ce type fichier n\'est pas autoris&eacute;<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        endif;
                }
                elseif($obj == "ticket_paiement")
                {
                        if($_POST['ticket']==''  || $_POST['compte']=='' || $_POST['price']=='' || $_POST['currency']=='' || $_POST['reference']=='' || $_POST['quantity']==''):
                                $return['message'] = '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        endif;
                        
                        $ticket = $this->ticketsModel->get_ticket_info($_POST['ticket']);
                        
                        if($_POST['quantity'] > $ticket->Quantity_10)
                        {
                                $return['message'] = '<div class="alert alert-info">Il ne reste que "'.$ticket->Quantity_10.'" ticket(s) pour ce type &agrave; vendre, veuillez saisir une quantit*eacute; sup&eacute;pieure ou &eacute;gale &agrave; "'.$ticket->Quantity_10.'" s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        }
                        
                        if($_POST['ticket_id'] =="")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                $data['Refpaiement_22'] = "T".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        }
                        else
                        {
                                $data['Changes_5']=gmdate('Y-m-d H:i:s');
                                $data['Changer_6']=$this->session->userdata['user_id'];
                                
                                $data['Refpaiement_22'] = $_POST['refpaiement'];
                        }
                        
                        # Value product for ticket events
                        $data['Productid_7'] = 3;
                        $data['Designation_8'] = $this->request->getPost('reference');
                        
                        //Formatting amount
                        $data['Amount_10'] = str_replace(' ','',$_POST['price']);
                        $data['Amount_10'] = str_replace(',','.',$data['Amount_10']);
                        $data['Devise_11'] = $this->request->getPost('currency');
                        $data['Reference_19 '] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        $data['Agence_21'] = $_SESSION['Logiref_guichet'];
                        
                        $data['Cashregister_20'] = isset($_POST['cashregister_id']) ? $_POST['cashregister_id'] : "0";
                        $data['Event_23'] = isset($_POST['event']) ? $_POST['event'] : "0";
                        $data['Ticket_24'] = isset($_POST['ticket']) ? $_POST['ticket'] : "0";
                        $data['Branchid_26']= isset($_SESSION['Logiref_branch']) ? $_SESSION['Logiref_branch'] : 0;
                        $data['Mode_29']= isset($_POST['mode']) ? $_POST['mode'] : "";
                        $data['Phone_30']= isset($_POST['phone']) ? $_POST['phone'] : "";
                        $data['Email_31']= isset($_POST['email']) ? $_POST['email'] : "";
                        
                        $event = $this->eventsModel->get_event_info($_POST['event']);
                        
                        #Comptabilisation
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $agence_dst=NULL;
                        $list = NULL;
                        $comptes_recettes = NULL;
                        $data['event'] = isset($event->Name_7) ? $event->Name_7 : "";
                        $data['compte'] = isset($_POST['compte']) ? $_POST['compte'] : "";
                        
                        $comptes = $this->accountsModel->get_comptes_array($list, $agence_src, $agence_dst);
                        
                        if($event->Partners_14 !="")
                        {
                                $data_partners = array();
                                $partners = json_decode($event->Partners_14, true);
                                
                                $data_partners['Rawbank'] = isset($partners['quota_bank']) ? ($partners['quota_bank'] * $data['Amount_10'])/100 : "";
                                $data_partners['quota_partner'] = isset($partners['quota_partner']) ? ($partners['quota_partner'] * $data['Amount_10'])/100 : "";
                                $data_partners['partner'] = isset($partners['partner']) ? $partners['partner'] : "";
                                
                                $data['Partner_25'] = json_encode($data_partners);
                                
                                $instructions = array();
                                
                                $data['montant'] =  $data['Amount_10'];
                                $data['devise'] = $data['Devise_11'];
                                
                                
                                if($_POST['mode'] != 8)
                                {
                                        $instruction = $this->comptabilisationModel->get_instructions_bank_fees($data, $comptes);

                                        foreach ($instruction as $row)
                                        {
                                                $instructions[] = $row;
                                        }
                                }
                                else
                                {
                                        # If payment method is illicocash, no instructions saved
                                        $instructions = array();
                                }
                                
                                unset($data['event']);
                                unset($data['compte']);
                                unset($data['montant']);
                                unset($data['devise']);
                                
                                if(!empty($instructions))
                                {
                                        if(isset($_POST['ticket_id']) && $_POST['ticket_id'] !="")
                                        {
                                                $this->comptabilisationModel->delete_instructions($data['Refpaiement_22']);
                                        }
                                        $this->comptabilisationModel->save_instructions($data['Refpaiement_22'], $data, $instructions, $data['Refpaiement_22']);
                                }
                        }
                        else 
                        {
                                $data['montant'] =  $data['Amount_10'];
                                $data['devise'] = $data['Devise_11'];
                                
                                if($_POST['mode'] != 8)
                                {
                                        $instructions = $this->comptabilisationModel->get_instructions_bank_fees($data, $comptes);
                                }
                                else
                                {
                                        # If payment method is illicocash, no instructions saved
                                        $instructions = array();
                                }
                                
                                unset($data['event']);
                                unset($data['compte']);
                                unset($data['montant']);
                                unset($data['devise']);

                                if(!empty($instructions))
                                {
                                        if(isset($_POST['ticket_id']) && $_POST['ticket_id'] !="")
                                        {
                                                $this->comptabilisationModel->delete_instructions($data['Refpaiement_22']);
                                        }
                                        $this->comptabilisationModel->save_instructions($data['Refpaiement_22'], $data, $instructions, $data['Refpaiement_22']);
                                }
                        }

                        $id = $this->encaissementModel->save_paiements($data, $id);

                        if (isset($id) && $id!=NULL) 
                        {
                                if(isset($_POST['ticket_id']) && $_POST['ticket_id'] !="")
                                {
                                        $return['message'] = '<div class="alert alert-success">La modification est faite avec succes !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        $return['id'] = $id;
                                        $return['ref'] = $data['Refpaiement_22'];
                                        
                                        echo json_encode($return);
                                }
                                else
                                {
                                        $return['message'] = '<div class="alert alert-success">Ticket enregistr&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        $return['id'] = $id;
                                        $return['ref'] = $data['Refpaiement_22'];
                                        echo json_encode($return);

                                        $data_ticket = array();
                                        $ticket = $this->ticketsModel->get_ticket_info($_POST['ticket']);

                                        if(isset($ticket->Quantity_10))
                                        {
                                                $data_ticket['Quantity_10'] = $ticket->Quantity_10 - 1;
                                                $data_ticket['Quantity_15'] = $ticket->Quantity_15 + 1;

                                                $this->ticketsModel->update_ticket_number($data_ticket, $_POST['ticket']);
                                        }
                                }
                        }
                        else
                        {
                               $return['message'] =  '<div class="alert alert-danger">D&eacute;sol&eacute; Vos donn&eacute;es ne sont pas enregistr&eacute;es!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                               echo json_encode($return);
                        }
                }
                elseif($obj == "ticket_paiement_batch")
                {
                        if($_POST['ticket']==''  || $_POST['compte']=='' || $_POST['price']=='' || $_POST['currency']=='' || $_POST['reference']=='' || $_POST['quantity']==''):
                                $return['message'] = '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        endif;
                        
                        $ticket = $this->ticketsModel->get_ticket_info($_POST['ticket']);
                        
                        if($_POST['quantity'] > $ticket->Quantity_10)
                        {
                                $return['message'] = '<div class="alert alert-info">Il ne reste que '.$ticket->Quantity_10.' ticket(s) de ce type, veuillez saisir une quantit&eacute; inf&eacute;rieure ou &eacute;gale &agrave; '.$ticket->Quantity_10.' s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                        }
                        
                        $data = array();
                        
                        $quota_bank = 0;
                        $quota_partner = 0;
                        $quota_bank_only = 0;
                        
                        $reference_batch = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                        
                        for($i=1; $i<= $_POST['quantity']; $i++)
                        {
                                $inserdata[$i]['Date_1']=gmdate('Y-m-d H:i:s');
                                $inserdata[$i]['Status_2']=1;
                                $inserdata[$i]['Account_3']=$this->session->userdata['account_id'];
                                $inserdata[$i]['Creator_4']=$this->session->userdata['user_id'];
                                
                                # Value product for ticket events
                                $inserdata[$i]['Productid_7'] = 3;
                                $inserdata[$i]['Designation_8'] = $this->request->getPost('reference');

                                //Formatting amount
                                $inserdata[$i]['Amount_10'] = str_replace(' ','',$_POST['price']);
                                $inserdata[$i]['Amount_10'] = str_replace(',','.',$inserdata[$i]['Amount_10']);
                                $inserdata[$i]['Devise_11'] = $this->request->getPost('currency');
                                $inserdata[$i]['Reference_19 '] = rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');
                                $inserdata[$i]['Agence_21'] = $_SESSION['Logiref_guichet'];
                                $inserdata[$i]['Refpaiement_22'] = "T".rand(1,99).date('H').date('i').date('s').date('j').date('m').date('y');

                                $inserdata[$i]['Cashregister_20'] = isset($_POST['cashregister_id']) ? $_POST['cashregister_id'] : "0";
                                $inserdata[$i]['Event_23'] = isset($_POST['event']) ? $_POST['event'] : "0";
                                $inserdata[$i]['Ticket_24'] = isset($_POST['ticket']) ? $_POST['ticket'] : "0";
                                $inserdata[$i]['Branchid_26'] = isset($_SESSION['Logiref_branch']) ? $_SESSION['Logiref_branch'] : 0;
                                $inserdata[$i]['Mode_29'] = isset($_POST['mode']) ? $_POST['mode'] : "";
                                $inserdata[$i]['Phone_30'] = isset($_POST['phone']) ? $_POST['phone'] : "";
                                $inserdata[$i]['Email_31'] = isset($_POST['email']) ? $_POST['email'] : "";
                                $inserdata[$i]['Refbatch_33'] = $reference_batch;

                                $event = $this->eventsModel->get_event_info($_POST['event']);
                                
                                if($event->Partners_14 !="")
                                {
                                        $data_partners = array();
                                        $partners = json_decode($event->Partners_14, true);

                                        $data_partners['Rawbank'] = isset($partners['quota_bank']) ? ($partners['quota_bank'] * $inserdata[$i]['Amount_10'])/100 : "";
                                        $data_partners['quota_partner'] = isset($partners['quota_partner']) ? ($partners['quota_partner'] * $inserdata[$i]['Amount_10'])/100 : "";
                                        $data_partners['partner'] = isset($partners['partner']) ? $partners['partner'] : "";
                                        
                                        $quota_bank = $quota_bank + $data_partners['Rawbank'];
                                        $quota_partner = $quota_bank + $data_partners['quota_partner'];

                                        $inserdata[$i]['Partner_25'] = json_encode($data_partners);
                                }
                                
                                $quota_bank_only = $quota_bank_only + $inserdata[$i]['Amount_10'];
                        }
                        
                        #Comptabilisation
                        $agence_src= $_SESSION['Logiref_guichet'];
                        $agence_dst=NULL;
                        $list = NULL;
                        $comptes_recettes = NULL;
                        $data['Mode_29']= isset($_POST['mode']) ? $_POST['mode'] : "";
                        $data['event'] = isset($event->Name_7) ? $event->Name_7 : "";
                        $data['compte'] = isset($_POST['compte']) ? $_POST['compte'] : "";
                        
                        $comptes = $this->accountsModel->get_comptes_array($list, $agence_src, $agence_dst);
                        
                        if($quota_partner > 0)
                        {
                                $data['montant'] =  $quota_bank;
                                $data['devise'] = isset($_POST['currency']) ? $_POST['currency'] : "";

                                $instruction = $this->comptabilisationModel->get_instructions_bank_fees($data, $comptes);

                                foreach ($instruction as $row)
                                {
                                        $instructions[] = $row;
                                }

                                $data['montant'] =  $quota_partner;
                                $data['devise'] = isset($_POST['currency']) ? $_POST['currency'] : "";

                                $partners = $this->partnersModel->get_dropdown("partners");

                                $partners_name = isset($partners[$data_partners['partner']]) ? $partners[$data_partners['partner']] : "";

                                $instruction = $this->comptabilisationModel->get_instructions_partners_fees($data, $comptes, $partners_name);

                                $instructions[] = current($instruction);
                                
                                $data['Refpaiement_22'] = $reference_batch;
                                
                                unset($data['event']);
                                unset($data['compte']);
                                unset($data['montant']);
                                unset($data['devise']);

                                if(!empty($instructions))
                                {
                                        $this->comptabilisationModel->save_instructions($reference_batch, $data, $instructions, $data['Refpaiement_22']);
                                }
                        }
                        else
                        {
                                $data['montant'] =  $quota_bank_only;
                                $data['devise'] = isset($_POST['currency']) ? $_POST['currency'] : "";
                                $data['Refpaiement_22'] = $reference_batch;
                                
                                $instructions = $this->comptabilisationModel->get_instructions_bank_fees($data, $comptes);
                        
                                unset($data['event']);
                                unset($data['compte']);
                                unset($data['montant']);
                                unset($data['devise']);

                                if(!empty($instructions))
                                {
                                        $this->comptabilisationModel->save_instructions($reference_batch, $data, $instructions, $data['Refpaiement_22']);
                                }
                        }
                        
                        $ids = array();
                        
                        if(!empty($inserdata))
                        {
                                $id = $this->encaissementModel->save_ticket_batch($inserdata, "logiref_sbbos_paiements");
                                
                                if($id != "")
                                {
                                        $id = $id - 1;
                                        
                                        for($i=0; $i< $_POST['quantity']; $i++)
                                        {   
                                                $id = $id + 1;
                                                $ids[$i] = $id;
                                        }
                                        
                                        $_SESSION['batch_ids'] = $ids;
                                }
                                
                                $data_ticket = array();
                                $ticket = $this->ticketsModel->get_ticket_info($_POST['ticket']);
                                
                                if(isset($ticket->Quantity_10))
                                {
                                        $data_ticket['Quantity_10'] = $ticket->Quantity_10 - $_POST['quantity'];
                                        $data_ticket['Quantity_15'] = $ticket->Quantity_15 + $_POST['quantity'];
                                        
                                        $this->ticketsModel->update_ticket_number($data_ticket, $_POST['ticket']);
                                }
                        }
                        else
                        {
                                $ids = array();
                        }

                        if (!empty($ids)) 
                        {
                                $return['message'] = '<div class="alert alert-success">Ticket enregistr&eacute; avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                $return['id'] = $id;
                                $return['ref'] = $reference_batch;
                                echo json_encode($return);
                        }
                        else
                        {
                               $return['message'] =  '<div class="alert alert-danger">D&eacute;sol&eacute; Vos donn&eacute;es ne sont pas enregistr&eacute;es!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                               echo json_encode($return);
                        }
                }
                elseif($obj == "delete")
                {
                        $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        if(isset($paiement->Carnetid_34) && $paiement->Carnetid_34 > 0)
                        {
                                $data_ticket = array();
                                $ticket = $this->cashbooksModel->get_cashbook_info($paiement->Carnetid_34);
                                
                                $data_ticket['Quantity_14'] = $ticket->Quantity_14 + 1;
                                
                                $this->cashbooksModel->update_ticket_number($data_ticket, $paiement->Carnetid_34);
                        }
                        
                        $pid = $this->encaissementModel->delete_paiement($id);
                        
                        if($pid)
                        {
                                $this->comptabilisationModel->delete_instructions($paiement->Refpaiement_22);
                        }
                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "delete_batch")
                {
                        $pid = $this->encaissementModel->delete_paiement_batch($id);
                        
                        $this->comptabilisationModel->delete_instructions_batch($id);
                        
                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "validate")
                {
                        #Data to send to the cbs
                        $data = array();
                        
                        if(isset($_POST['refpaiement']) && $_POST['refpaiement'] != "")
                        {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data["Designation_8"] = $_POST['Designation_8'];
                                $data['refpaiement'] = $_POST['refpaiement'];
                                $data['refcbs'] = isset($_POST['refcbs']) ? $_POST['refcbs'] : "";
                                $data['paiement_id'] = $id;
                                $data['action'] = 'payment';
                                
                                #Invocation of the api transfer
                                @set_time_limit(300);
                                
                                $data_to_update['Status_2'] = 5;
                                
                                $this->encaissementModel->update_encaissement($data_to_update, $id);
                                
                                #Invocation of the api transfer
                                $core_banking = strtolower($this->core_banking);
                                $return = $this->{$core_banking}->virement_sbbos($data);
                                $return = json_decode($return, true);
                                
                                if(isset($return['response']) && $return['response'] == "200")
                                {
                                        $data = array();
                                        $code = 200;

                                        $data['validation_32'] = $this->session->userdata['user_id'];
                                        $data['Status_2'] = 1;
                                        # Update the paiement
                                        $pid = $this->encaissementModel->update_encaissement($data, $id);

                                }
                                elseif(isset($return['response']) && $return['response'] == "300")
                                {
                                        $code = 300;
                                }
                                elseif(isset($return['response']) && $return['response'] == "404")
                                {
                                        $code = 404;
                                }
                                elseif(isset($return['response']) && $return['response'] == "411")
                                {
                                        $code = 411;
                                }
                                elseif(isset($return['response']) && $return['response'] == "405")
                                {
                                        # Aucune ecriture trouvE 
                                        $code = 405;
                                }
                                elseif($return==false || $return ==NULL)
                                {
                                        $code = 412;
                                }
                                
                                echo $code;
                                
                        }
                        else
                        {
                                echo 404;
                        }
                }
                elseif($obj == "illico_confirm")
                {
                        #Data to send to illicocash API
                        $data_to_send = array();
                        $result = array();
                        
                        $data_to_send['referencenumber'] = isset($_POST['refnumber']) ? $_POST['refnumber'] : "";
                        $data_to_send['otp'] = isset($_POST['otp']) ? $_POST['otp'] : "";
                        
                        $credentials = $this->countersModel->get_credentials($_SESSION['Logiref_branch']);
                        $data_to_send['credentials'] = isset($credentials->Credentials_15) ? $credentials->Credentials_15 : "";
                        #Invocation of the api transfer
                        $return = $this->amplitude->call_bank_illico_confirmation_sbbos($data_to_send);
			
                        if($return['code'] == 200)
                        {
                                $ticketid = isset($_POST['ticketid']) ? $_POST['ticketid'] : "";
                                
                                $data = array();

                                $data['validation_32'] = $this->session->userdata['user_id'];
                                $data['Status_2'] = 1;
                                # Update the paiement
                                $pid = $this->encaissementModel->update_encaissement($data, $ticketid);
                                
                                $result['code'] = $return['code'];
                                
                                echo json_encode($result);
                        }
                        elseif($return['code'] == 400)
                        {
                                $result['code'] = $return['code'];
                                $result['msg'] = $return['msg'];

                                echo json_encode($result);
                        }
                        else
                        {
                                $result['code'] = "E400";
                                echo json_encode($result['code']);
                        }
                }
                elseif($obj == "validate_ticket")
                {
                        $data = $_POST;
                        $code = '';
                        $data_to_update = array();
                        
                        if(isset($_POST['refpaiement']) && $_POST['refpaiement'] != "")
                        {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data["Designation_8"] = isset($data['reference']) ? $data['reference'] : "";
                                #Invocation of the api transfer
                                @set_time_limit(300);
                                
                                $data_to_update['Status_2'] = 5;
                                
                                $this->encaissementModel->update_encaissement($data_to_update, $id);
                                
                                $return = $this->amplitude->virement_sbbos($data);
                                
                                if(isset($return['response']) && $return['response'] == "200")
                                {   
                                        $data = array();
                                        $code = 200;
                                        
                                        $data['validation_32'] = $this->session->userdata['user_id'];
                                        $data['Status_2'] = 1;
                                        # Update the paiement
                                        $pid = $this->encaissementModel->update_encaissement($data, $id);
                                }
                                elseif(isset($return['response']) && $return['response'] == "300")
                                {
                                        $code = 300;
                                }
                                elseif(isset($return['response']) && $return['response'] == "404")
                                {
                                        $code = 404;
                                }
                                elseif(isset($return['response']) && $return['response'] == "411")
                                {
                                        $code = 411;
                                }
                                elseif(isset($return['response']) && $return['response'] == "405")
                                {
                                        # Aucune ecriture trouvE 
                                        $code = 405;
                                }
                                elseif($return==false || $return ==NULL)
                                {
                                        $code = 412;
                                }
                                
                               
                                echo $code;
                                
                        }
                }
                elseif($obj == "validate_closing")
                {
                        $data = $_POST;
                        $code = '';
                        #$data_to_update = array();
                        
                        if(isset($_POST['refpaiement']) && $_POST['refpaiement'] != "")
                        {
                                # Priority of transactions to send to the API set to 1.
                                $data['Priority'] = 1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                #Invocation of the api transfer
                                @set_time_limit(300);
                                
                                $return = $this->amplitude->virement_sbbos($data);

                                if(isset($return['response']) && $return['response'] == "200")
                                {   
                                        $data = array();
                                        $code = 200;
                                        
                                        #$data['Status_2'] = 1;
                                        # Update the paiement
                                        #$pid = $this->encaissement_model->update_encaissement($data, $id);
                                        
                                }
                                elseif(isset($return['response']) && $return['response'] == "300")
                                {
                                        $code = 300;
                                }
                                elseif(isset($return['response']) && $return['response'] == "404")
                                {
                                        $code = 404;
                                }
                                elseif(isset($return['response']) && $return['response'] == "411")
                                {
                                        $code = 411;
                                }
                                elseif(isset($return['response']) && $return['response'] == "405")
                                {
                                        # Aucune ecriture trouvE 
                                        $code = 405;
                                }
                                elseif($return==false || $return ==NULL)
                                {
                                        $code = 412;
                                }
                                
                               
                                echo $code;
                                
                        }
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "set_exchange_rates")
                {
                        $this->ratesModel->get_exchange_rates();
                }
                elseif($obj == "stats")
                {
                        $paiements = $this->ticketsModel->get_all_paiements('current_day');
                        
                        $stats = array(
                            'qte_ticket_sold'=>0,
                            'qte_toll_sold'=>0,
                            'qte_gopass_sold'=>0,
                            'amount_ticket_sold'=>0,
                            'amount_toll_sold'=>0,
                            'amount_gopass_sold'=>0,
                        );
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $taux = $result['Dollar_7'];
                        
                        foreach($paiements as $row)
                        {
                                if($row->Productid_7 == '1')
                                {
                                        $stats['qte_gopass_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '2')
                                {
                                        $stats['qte_toll_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '3')
                                {
                                        $stats['qte_ticket_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                }
                        }
                        
                        return $stats;
                }
                if($obj == "stats_eticket")
                {
                        $paiements = $this->ticketsModel->get_all_paiements('current_day');
                        
                        $stats = array(
                            'qte_ticket_sold'=>0,
                            'qte_toll_sold'=>0,
                            'qte_gopass_sold'=>0,
                            'amount_ticket_sold'=>0,
                            'amount_toll_sold'=>0,
                            'amount_gopass_sold'=>0,
                        );
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $taux = $result['Dollar_7'];
                        
                        foreach($paiements as $row)
                        {
                                if($row->Productid_7 == '1')
                                {
                                        $stats['qte_gopass_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_gopass_sold'] = $stats['amount_gopass_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '2')
                                {
                                        $stats['qte_toll_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_toll_sold'] = $stats['amount_toll_sold'] + $row->Amount_10;
                                        }
                                }
                                elseif($row->Productid_7 == '3')
                                {
                                        $stats['qte_ticket_sold']++;
                                        
                                        if($row->Devise_11 == 'CDF')
                                        {
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                        else
                                        {
                                                $row->Amount_10 = $row->Amount_10 * $taux;
                                                $stats['amount_ticket_sold'] = $stats['amount_ticket_sold'] + $row->Amount_10;
                                        }
                                }
                        }
                        
                        return $stats;
                }
                elseif($obj == "closing")
                {
                        #$total_amount = 0;
                        $total_amount_usd = 0;
                        $total_amount_cdf = 0;

                        foreach($data as $row)
                        {
                                if ($row->Devise_12 == "USD"):
                                        $total_amount_usd = $total_amount_usd + $row->Montant_11;
                                elseif ($row->Devise_12 == "CDF"):
                                        $total_amount_cdf = $total_amount_cdf + $row->Montant_11;
                                else:
                                        $total_amount = 0;
                                endif;
                                
                        }
                        $total_amount = ['USD'=> $total_amount_usd, 'CDF' => $total_amount_cdf];
                        
                        return $total_amount;
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */