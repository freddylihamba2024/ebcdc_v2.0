<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\PartnersModel;
use Modules\Etoll\Models\PosModel;

class Users extends BaseController {
        /*
         * Presentation: gestion des beneficiaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('privileges','settings','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'users';
        private $method = "aes-256-cbc";
        private $pass = '0123456789*';
        public $role;
        public $mainModel;
        public $usersModel;
        public $logirefModel;
        public $integrationModel;
        public $countersModel;
        public $branchesModel;
        public $caissesModel;
        public $partnersModel;
        public $posModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->mainModel = new MainModel();
                $this->usersModel = new UsersModel();
                $this->logirefModel = new LogirefModel();
                $this->integrationModel = new IntegrationModel();
                $this->countersModel = new CountersModel();
                $this->branchesModel = new BranchesModel();
                $this->caissesModel = new CaissesModel();
                $this->partnersModel = new PartnersModel();
                $this->posModel = new PosModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'users';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                $this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "privileges")
                {
                    
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        $this->data['isys'] = $this->integrationModel->get_isys_account_info();
                        $this->data['sydonia'] = $this->integrationModel->get_sydonia_account_info();
                        $this->data['members'] = $this->data("get_users");
                        $users['0'] = 'Member';
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences_main", NULL, "ALL");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets_main");
                        $this->data['guichets_toll'] = $this->branchesModel->get_dropdown("guichets_toll");
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['pos'] = $this->posModel->get_dropdown("pos");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['pos'] = $this->posModel->get_dropdown("pos");
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                                $this->data['roles'] = $this->usersModel->role;
                        }
                        else
                        {
                                $this->data['fonctions'] = $this->usersModel->fonction;

                        }
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\users', $this->data);
                }
                elseif($obj == "user") 
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['products'] = $this->usersModel->products;
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences_main");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets_main");
                        $this->data['guichets_toll'] = $this->branchesModel->get_dropdown("guichets_toll");
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        
                        $this->data['sales_points'] = $this->branchesModel->get_dropdown("guichets_events");
                        $this->data['beneficiaires'] = $this->partnersModel->get_dropdown('partners');
                        
                        $this->data['from'] = $arg;
                        
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        $this->data['noms'] = $this->data['users'];
                        
                        $members = $this->usersModel->get_dropdown("users");
                        foreach($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['user'] = $user = $this->usersModel->get_user_info($id);
                        
                        $this->data['caisses'] = $this->caissesModel->get_dropdown("caisses");
                        
                        $this->data['pos'] = $this->posModel->get_dropdown("pos", $user->Guichet_8);
                        $pos_members = $this->usersModel->get_dropdown("pos");
                        
                        
                        if (isset($id) && $id > 0)
                        {
                                foreach($pos_members as $key=>$val) 
                                {
                                        if(isset($user->Id_0) && $user->Id_0 !="")
                                        {
                                                if($key != $user->Id_0)
                                                {
                                                        if (array_key_exists($val, $this->data['pos']))
                                                        {
                                                                unset($this->data['pos'][$val]);
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                if (array_key_exists($val, $this->data['pos']))
                                                {
                                                        unset($this->data['pos'][$val]);
                                                }
                                        }
                                } 
                        }
                        else
                        {
                                foreach($pos_members as $val) unset($this->data['pos'][$val]);
                        }
                        
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['roles'] = $this->usersModel->role;
                        }
                        else
                        {
                            $this->data['fonctions'] = $this->usersModel->fonction;
                            $this->data['fonctions'][1] ="";

                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_user', $this->data);  
                }
                elseif($obj == "accountsydonia")
                {   
                        $user = $this->session->userdata['user_id'];
                        $this->data['identifiants'] = $this->usersModel->get_sydoniaccount_by_accountid($user);
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_sydonia', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "user")
                {
                        if($_POST['userid']=='0' || $_POST['role']=='' || $_POST['ville']==''):
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        else:
                                if ($id == NULL):
                                        if(isset($_POST['pos']) && $_POST['pos'] !="")
                                        {
                                                $pos_exist = $this->usersModel->get_pos_by_imei($_POST['pos']);

                                                if (!empty($pos_exist)):
                                                        echo '<div class="alert alert-warning">Avertissement! D&eacute;sol&eacute; ce POS est déjà affect&eacute; à un autre utilisateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                        die;
                                                endif;
                                        }
                                endif;

                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):

                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']= 2;
                                        $data['Statusvalidate_19']= 2;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Maker_14']= $this->session->userdata['user_id'];

                                endif;


                                if($_SESSION['Logiref_role']==1)
                                {
                                        $data['Role_4']=$_POST['role'];
                                        $data['Checker_15']= $this->session->userdata['user_id'];
                                        $data['Validation_16']= gmdate('Y-m-d H:i:s');

                                        $data['Province_5']=$_POST['province'];
                                        $data['Ville_6']= $_POST['ville'];
                                        $data['Agence_7']= isset($_POST['agence'])? $_POST['agence']: "0";
                                        if($_SESSION['Logiref_groupe']== 'banks')
                                        {
                                            $data['Guichet_8']= (isset($_POST['guichet']) && $_POST['guichet'] !="") ? $_POST['guichet']: "0";
                                            $data['Regies_11']='';
                                        }
                                        else
                                        {
                                            $data['Service_10']=$_POST['service'];
                                            $data['Regies_11']=$_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9']=$_SESSION['Logiref_groupe'];
                                        $data['Code_12']=$_POST['code'];
                                        $data['Userid_13']=$_POST['userid'];

                                        $data['Partner_21']= (isset($_POST['partner']) && $_POST['partner'] !="") ? $_POST['partner'] : "0";
                                        $data['Type_23']= $_POST['Type'];

                                        $data['Pos_22']= (isset($_POST['pos']) && $_POST['pos'] !="") ? $_POST['pos'] : "0";


                                        if(isset($_POST['guichet']) && $_POST['guichet'] !="")
                                        {
                                                $caisse = $this->caissesModel->get_caisse_by_branchid($_POST['guichet']);

                                                $data['Caisse_20']= isset($caisse->Id_0) ? $caisse->Id_0 : 0;
                                        }

                                        $Module_11 = "etoll";
                                        $relation = $this->mainModel->get_relation_infos($_POST['userid']);
                                        if($relation->Module_11 != "" && $relation->Module_11 != "etoll")
                                        {
                                                if(in_array($relation->Module_11,array("elicense","eximtrade","qleads","etoll","logiref","Main","Pay"))){
                                                        $Module_11 = json_encode(array($relation->Module_11,"etoll"));
                                                }
                                                else{
                                                        $array = json_decode($relation->Module_11);
                                                        if(!in_array("etoll",$array)){
                                                                array_push($array,"etoll");
                                                        }
                                                        $Module_11 = json_encode($array);
                                                }
                                        }

                                        if($_POST['role'] == '1' || $_POST['role'] == '2')
                                        {
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $rdata['Module_11'] = $Module_11;
                                                $userid = $_POST['userid'];
                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if($id != "" || $id !='0')
                                        {
                                                if($_POST['role'] != '1' && $_POST['role'] != '2'):

                                                        $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                        $rdata['Type_10'] = '300';
                                                        $rdata['Module_11'] = $Module_11;
                                                        $userid = $_POST['userid'];
                                                        $relationid = $this->mainModel->update_relation($rdata, $userid);

                                                endif;
                                        }
                                        $data['Checker_15'] = 0;
                                        $data['Validation_16'] = '0000-00-00';
                                        $data['Option_26'] = (!empty($_POST["Option_26"]))?json_encode($_POST["Option_26"]):Null;

                                }
                                else {
                                        $data['Checker_15'] = $this->session->userdata['user_id'];
                                        $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                        if ($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] != '0') {
                                                $data['Status_2'] = 1;
                                                $data['Statusvalidate_19'] = $_POST['statusvalidate'];
                                        }
                                }

                                #Database
                                $cid = $this->usersModel->save_users($data, $id);
			endif;
                        if($cid):
                                echo '<div class="alert alert-success">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "account_sydonia")
                {
                        $encryption = array('codebank'=>$_POST['code'], 'encryption'=>$_POST['password']);
                        $user = $this->session->userdata['user_id'];
                        $data['Login_17'] = $_POST['login'];
                        $data['Password_18'] = json_encode($encryption);
                        $cid = $this->usersModel->update_users($data, $user);
                        if($cid): 
                                echo '<div class="alert alert-success">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif; 
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        $members = $this->usersModel->get_members();
                        $type = $this->session->userdata['user_type'];
                        if(empty($members) && $type==200){
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Role_4']=3;
                                $data['Province_5']=0;
                                $data['Ville_6']=0;
                                $data['Agence_7']=0;
                                $data['Guichet_8']=0;
                                $data['Privileges_10']=0;
                                $data['Regies_11']='';
                                $data['Code_12']=0;
                                $data['Userid_13']=$this->session->userdata['user_id'];
                                $cid = $this->usersModel->save_users($data, NULL);
                                if($cid) $members = $this->usersModel->get_members();
                        }
                        return $members;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */