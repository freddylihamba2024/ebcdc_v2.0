<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\StakeholdersModel;
use Modules\Etoll\Models\UsersModel;

class Rawbank extends BaseController {
        public $months = array('',"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov", "Dec");
        public $roles_banks = array('1'=>'admin', '2'=>'director', '3'=>'manager', '4'=> 'operator');
        
        public $group = ''; //Banks, Regies, Clients
        public $category = '202'; //Family, SMB, Enterprise
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $roles = '';
        public $lang = 'fr';
        public $country = '0';
        
        
        public function __construct()
	{
		parent::__construct();
                
                $this->logirefModel = new LogirefModel();
                $this->integrationModel = new IntegrationModel();
                $this->encaissementModel = new EncaissementModel();
                $this->stakeholdersModel = new StakeholdersModel();
                $this->usersModel = new UsersModel();
                
                $this->lang = $this->session->userdata['user_lang'];
                $this->country = $this->session->userdata['account_country'];
                $this->data['Toggle'] = true;
                
                $this->data['module'] = 'etoll';
                $this->data['application'] = 'rawbank';
                $this->data['function'] = $this->uri->segment(3);
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                
                $accounts = array('101'=>'enterprise', '202'=>'business', '303'=>'family'); 
                $account_category = $this->session->userdata['account_category'];
                $this->category = $accounts[$account_category]; 
                $account_id = $this->session->userdata['account_id'];
                $banks_account_id = array('REN45',); //A completer ...
                $isys_account = $this->integrationModel->get_isys_account_info();
                $sydonia_account = $this->integrationModel->get_sydonia_account_info();
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                //Isys account initialisation
                if($isys_account == NULL)
                {
                        $this->save('isys');
                }

                //Sydonia account initialisation
                if($sydonia_account == NULL)
                {
                        $this->save('sydonia');
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                */
                
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->usersModel->get_privilegies();
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                
                /* Known group */
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_groupe']!='')
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                /* Unregistered bank */
                elseif(in_array($account_id, $banks_account_id))
                {
                        $this->save("beneficiaire");
                        $this->usersModel->get_privilegies();
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                /* Log out */
                elseif(!isset($_SESSION['account_id']))
                {
                        return redirect()->to(base_url('/page/logiref'));
                }
                /* else*/
                else
                {
                        //Nothing
                }
                
                
                
                
	}
        
	
	public function index()
	{      
                
                /* Registered businesses: banks & revenues authorities */
                if(isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 0 && $this->group != '' && $this->country=='60')
                {
                        if($_SESSION['Logiref_role']==1)
                        {
                                $this->data['users_stats'] = $this->usersModel->get_users_stats();
                        }
                        
                        if($this->group == 'banks')
                        {
                                return redirect()->to(base_url('rawbank/dashboards/set/overview'));
                        }
                }
                /** Unknown */                
                else 
                {
                        $this->data['country'] = $this->country;
                        $this->data['subview'] = '\Modules\Etoll\Views\\' . $this->lang.'_denial';
                }
                $this->data['lang'] = $this->session->userdata['user_lang'];
		echo view('layouts/layout_main', $this->data);
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj=="OBJ")
                {
                    
                }
        }
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj=="beneficiaire")
                {
                        /* A completer pour creer metadonn?es des banques... */
                        $beneficiaires = $this->stakeholdersModel->get_beneficiaries("Banks");
                
                        if(empty($beneficiaires))
                        {
                                $data['Date_1']= gmdate('Y-m-d H:i:s');
                                $data['Status_2']= 1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Type_4']= 'BKC';
                                $data['Description_5']= $this->session->userdata['account_business'];
                                $this->stakeholdersModel->save_beneficiairie($data, NULL);
                        }
                }
                elseif($obj=="isys")
                {
                        
                        $data['Date_1']= gmdate('Y-m-d H:i:s');
                        $data['Status_2']= 1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Login_7']= 'BKC';
                        $data['Password_8']= 'BKC';
                        $this->integrationModel->save_isys_account($data, NULL);
                }
                elseif($obj=="sydonia")
                {
                        $data['Date_1']= gmdate('Y-m-d H:i:s');
                        $data['Status_2']= 1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Creator_4'] = $this->session->userdata['user_id']; 
                        $data['Bank_7']= '0000';
                        $this->integrationModel->save_sydonia_account($data, NULL);
                }
                
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * List:
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                        
                }
        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */