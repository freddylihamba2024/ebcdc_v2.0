<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\RatesModel;
use Modules\Etoll\Models\EncaissementModel;

class Caisses extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('caisses');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'caisses';
        public $mainModel;
        public $branchesModel;
        public $countersModel;
        public $caissesModel;
        public $ratesModel;
        public $encaissementModel;
        public $logirefModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->mainModel = new MainModel();
                $this->branchesModel = new BranchesModel();
                $this->countersModel = new CountersModel();
                $this->caissesModel = new CaissesModel();
                $this->ratesModel = new RatesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'caisses';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                if($this->session->get('Logiref_role')==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "caisses")
                {
                        $this->data['caisses'] = $this->caissesModel->get_caisses();
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['from'] = $id;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\caisses', $this->data);
                }
                elseif($obj == "caisse") 
                {
                        $this->data['caisse'] = $this->caissesModel->get_caisse_info($id);
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['from'] = $arg;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_caisse', $this->data);
                }
                elseif($obj == "manage")
                {
                        $this->data['caisse'] = $this->caissesModel->get_caisse_info($id);
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['movements'] = $this->caissesModel->get_movement_caisse();
                        $this->data['guichets'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['agences'] = $this->branchesModel->get_dropdown("guichets_main", NULL, "ALL");
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_manage', $this->data);
                }
                elseif($obj == "manage_filter")
                {
                        $this->data['caisse'] = $this->caissesModel->get_caisse_info($id);
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['movements'] = $this->caissesModel->get_movement_caisse();
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_caisses', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "caisse")
                {
                        $data = $_POST;
                       
                        if($data['Reference_7']=='0' || $data['Compte_9']==''  || $data['Guichet_8']=='' || $data['Name_10']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL && $_SESSION['Logiref_role']==1)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                // checks if the code entered has already been used 
                                $caisse_exist = $this->caissesModel->get_caisse_exists($data['Compte_9']);
                                
                                if(!empty($caisse_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une caisse cr&eacute;e avec ce compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                $data['Status_2']=1;
                        }
                        
                        $data['Agence_15'] = $_SESSION['Logiref_guichet'];
                        
                        $caisse = $this->caissesModel->get_caisse_info($id);
                        
                        if(!is_null($caisse) && $caisse->Compte_9 !== $data['Compte_9'])
                        {
                                //checks if the code entered has already been used 
                                $caisse_exist = $this->caissesModel->get_caisse_exists($data['Compte_9']);
                                if(!empty($caisse_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une caisse cr&eacute;e avec ce compte !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                        }
                        #Database
                        $cid = $this->caissesModel->save_caisse($data, $id);
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! caisse enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "validate")
                {   
                        $data = array();
                        $id = $_GET['id'];
                        $status = $_GET['status'];
                        $user_id = $_GET['userid'];
                        
                        if($status == 4)
                        {
                                $data['Status_2'] = 2;
                                
                                $data_rate = array();
                                $data_rate['Changer_6'] = $this->session->userdata['user_id'];
                                
                                $rate = $this->ratesModel->get_rate_opened_by_userid($user_id);
                                $rate = current($rate);
                                
                                $rate_id = $rate->Id_0;
                        }
                        else
                        {
                                $data['Status_2'] = 1; 
                                
                                $data_rate = array();
                                $data_rate['Status_2'] = 2;
                                
                                $rate = $this->ratesModel->get_rate_closed_by_userid($user_id);
                                $rate = current($rate);
                        }
                        
                        $cid = $this->caissesModel->save_caisse($data, $id);
                        
                        if($cid) 
                        {
                                if(isset($rate->Id_0))
                                {
                                        $rate_id = $rate->Id_0;
                                        $this->ratesModel->save_taux($data_rate, $rate_id); 
                                }
                                
                                $msg = '<div class="alert alert-success">Bravo! Validation effectu&eacute;e avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        }
                        else 
                        {
                                $msg ='<div class="alert alert-warning"> Echec de validation ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                        }
                        
                        echo $msg;
                }
                elseif($obj == "validated")
                {
                        $data = array();
                        
                        $pid = 0;
                        
                        $data['Status_2'] = 2;

                        $pid = $this->caissesModel->update_caisses($data, $id);

                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "delete")
                {
                        $data = array();
                        
                        $pid = 0;
                        
                        $data['Status_2'] = (isset($arg) && $arg != "") ? '0': '3';

                        $pid = $this->caissesModel->update_caisses($data, $id);

                        #Return
                        echo $pid;
                        die;
                }
               
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
