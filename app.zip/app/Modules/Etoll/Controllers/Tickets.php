<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Etoll\Models\EventsModel;

class Tickets extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('tickets');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'tickets';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->mainModel = new MainModel();
                $this->branchesModel = new BranchesModel();
                $this->caissesModel = new CaissesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->ticketsModel = new TicketsModel();
                $this->eventsModel = new EventsModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'tickets';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "tickets")
                {
                        $this->data['tickets'] = $this->ticketsModel->get_tickets();
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['status'] = $this->ticketsModel->status;
                        $this->data['status_color'] = $this->ticketsModel->status_color;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\tickets', $this->data);
                }
                elseif($obj == "ticket") 
                {
                        $this->data['ticket'] = $this->ticketsModel->get_ticket_info($id);
                        $this->data['sales_points'] = $this->branchesModel->get_dropdown("guichets_events");
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['agences'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_ticket', $this->data);
                }
                elseif($obj == "_tickets")
                {
                        $this->data['tickets'] = $this->ticketsModel->get_tickets();
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['status'] = $this->ticketsModel->status;
                        $this->data['status_color'] = $this->ticketsModel->status_color;
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_tickets', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "ticket")
                {
                        if($_POST['Name_7']=='0' || $_POST['Quantity_10']==''  || $_POST['Price_8']=='' || $_POST['Currency_9']=='' || $_POST['Event_13']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        endif;
                        
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        $data['Name_7']= $_POST['Name_7'];
                        $data['Quantity_10']= $_POST['Quantity_10'];
                        $data['Price_8']= $_POST['Price_8'];
                        $data['Currency_9']= $_POST['Currency_9'];
                        if(isset($_POST['Guichet_11']) && $_POST['Guichet_11'] != "")$data['Guichet_11']= $_POST['Guichet_11'];
                        $data['Description_12 ']= isset($_POST['Description_12']) ? $_POST['Description_12'] : "";
                        $data['Event_13']= $_POST['Event_13'];
                        
                        
                        #Database
                        $cid = $this->ticketsModel->save_tickets($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! ticket enregistr&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '0'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->ticketsModel->save_tickets($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success">Ticket annul&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'annulation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "activate")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '1'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->ticketsModel->save_tickets($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success">Ticket activ&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'activation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                        
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
