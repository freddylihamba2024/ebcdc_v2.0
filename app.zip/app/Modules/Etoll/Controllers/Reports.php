<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\RatesModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\ReportsModel;
use Modules\Etoll\Models\CashbooksModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\AccountsModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\ComptabilisationModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\PartnersModel;
use Modules\Etoll\Models\StakeholdersModel;

class Reports extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('cashbooks','caisses_status','paiements','caisses_movements', 'tickets', 'tolls', 'partners', 'report_partners', 'toll_partners', 'toll_offline','payment_toll','report_closing','payment_cancelled');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'etoll';
        public $folder = 'reports';
        public $role;
        public $reportsModel;
        public $logirefModel;
        public $cashbooksModel;
        public $productsModel;
        public $branchesModel;
        public $accountsModel;
        public $usersModel;
        public $caissesModel;
        public $encaissementModel;
        public $integrationModel;
        public $comptabilisationModel;
        public $ticketsModel;
        public $eventsModel;
        public $ratesModel;
        public $partnersModel;
        public $countersModel;
        public $stakeholdersModel;
        public $mainModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->reportsModel = new ReportsModel();
                $this->logirefModel = new LogirefModel();
                $this->cashbooksModel = new CashbooksModel();
                $this->productsModel = new ProductsModel();
                $this->accountsModel = new AccountsModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->caissesModel = new CaissesModel();
                $this->encaissementModel = new EncaissementModel();
                $this->integrationModel = new IntegrationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->ticketsModel = new TicketsModel();
                $this->eventsModel = new EventsModel();
                $this->ratesModel = new RatesModel();
                $this->partnersModel = new PartnersModel();
                $this->countersModel = new CountersModel();
                $this->stakeholdersModel = new StakeholdersModel();
                $this->mainModel = new MainModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                $this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view("layouts/layout_main", $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "cashbooks") 
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['cashbooks'] = $this->cashbooksModel->get_cashbooks();
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "payment_gopass")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_gopass();
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\report_gopass', $this->data);
                }
                elseif($obj == "payment_toll")
                {
                        $payment_means = $id;
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);

                        $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                        
                        $paiement_verify = $this->encaissementModel->get_paiements_toll_verify($payment_means);
                        $paiement_nverify = $this->encaissementModel->get_paiements_toll_nverify($payment_means);
                        
                        $montant_nverify= 0;
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    //$row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    //$row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;
                        
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        $this->data['nvpaiement'] = $paiement_nverify;
                        $this->data['vpaiement'] = $paiement_verify;
                        
                        $this->data['payment_means'] = $payment_means;
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\report_toll', $this->data);
                }
                elseif($obj == "payment_ticket")
                {
                        $payment_means = $id;
                        
                        $this->data['payment_unverified'] = $this->encaissementModel->get_paiements_ticket_no_verify($payment_means);
                        $this->data['payment_verified'] = $this->encaissementModel->get_paiements_ticket_verify($payment_means);
                        
                        $unverified_payment_amount= 0;
                        $total_unverified_payment = 0;

                        $verified_payment_amount = 0; 
                        $total_verified_payment = 0;
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                        
                        foreach ($this->data['payment_unverified'] as $row)
                        {
                                $unverified_payment_amount += $row->Amount_10;

                                if($row->Devise_11 == 'CDF')
                                {
                                        $total_unverified_payment += $row->Amount_10;
                                }
                                else
                                {
                                        $row->Amount_10 = $taux * $row->Amount_10;
                                        $total_unverified_payment += $row->Amount_10;
                                }
                        }
                        
                        foreach ($this->data['payment_verified'] as $row)
                        {
                                $verified_payment_amount += $row->Amount_10;

                                if($row->Devise_11 == 'CDF')
                                {
                                        $total_verified_payment += $row->Amount_10;
                                }
                                else
                                {
                                        $row->Amount_10 = $taux * $row->Amount_10;
                                        $total_verified_payment += $row->Amount_10;
                                }
                        }
                        
                        $this->data['total_verified_payment'] = $total_verified_payment;
                        $this->data['total_unverified_payment'] = $total_unverified_payment;
                        $this->data['payment_means'] = $payment_means;
                        
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets');
                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\report_ticket', $this->data);
                }
                elseif($obj == "report_closing")
                {
                        $this->data['nivellement'] = $this->integrationModel->get_report_closing();
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\report_closing', $this->data);
                }
                elseif($obj == "report_partners")
                {
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_ticket();
                        $this->data['partners'] = $this->partnersModel->get_dropdown("partners");
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\report_partners', $this->data);
                }
                elseif($obj == "caisses_status")
                {
                        $this->data['colors'] = $this->caissesModel->status_color;
                        $this->data['status'] = $this->caissesModel->status;
                        $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['caisses'] = $this->caissesModel->get_caisses_by_agence();
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "caisses_movements")
                {
                        $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                        $this->data['status'] = $this->caissesModel->get_guichets_status();
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['agences'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "tickets")
                {   
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_ticket();
                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\tickets', $this->data);
                }
                elseif($obj == "toll_partners")
                {   
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['paiement'] = $this->encaissementModel->get_paiement_toll_partners();
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : "1";
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['stats'] = $this->data('stats_partner');
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\toll_partners', $this->data);

                }
                elseif($obj == "tolls")
                {   
                        if(isset($_SESSION['Bank_rates']))
                        {
                                $result = json_decode($this->session->get('Bank_rates'), true);
                                $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                        }
                        else
                        {
                               $taux = 1;
                        }

                        $paiement_verify = $this->encaissementModel->get_paiements_toll_verify();
                        $paiement_nverify = $this->encaissementModel->get_paiements_toll_nverify();

                        $montant_nverify= 0; 
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;

                        $users = $this->mainModel->get_dropdown('users');
                        $returns = $this->integrationModel->get_cbs_returns_tolls_array();

                        $cbs_returns = array();
                        foreach ($returns as $rKey => $values) 
                        {
                                foreach ($values as $key => $value) 
                                {
                                        if (is_array($value) && isset($value['Num_evenement']) && isset($value['code'])):
                                                $cbs_returns[$rKey] = $value;
                                        endif;
                                }
                        }

                        $this->data['cbs_returns'] = $cbs_returns;
                        $this->data['users'] = $this->usersModel->get_dropdown('operators', $users);
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['cashbook'] = $this->cashbooksModel->get_dropdown("cashbook");

                        $this->data['nvpaiement'] = $paiement_nverify;
                        $this->data['vpaiement'] = $paiement_verify;
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\tolls', $this->data);
                }
                elseif($obj == "tolls_filter")
                {
                        $paiement_nverify  = $this->encaissementModel->get_paiements_toll_nverify_filter($_POST);
                        $paiement_verify = $this->encaissementModel->get_paiements_toll_verify_filter($_POST);
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        
                        $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                    
                        $montant_nverify = 0;
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;

                        $users = $this->mainModel->get_dropdown('users');
                        $returns = $this->integrationModel->get_cbs_returns_tolls_array();

                        $cbs_returns = array();
                        foreach ($returns as $rKey => $values) 
                        {
                                foreach ($values as $key => $value) 
                                {
                                        if (is_array($value) && isset($value['Num_evenement']) && isset($value['code'])):
                                                $cbs_returns[$rKey] = $value;
                                        endif;
                                }
                        }
                        
                        $this->data['cbs_returns'] = $cbs_returns;
                        $this->data['users'] = $this->usersModel->get_dropdown('operators', $users);
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                    
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_toll();
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['cashbook'] = $this->cashbooksModel->get_dropdown("cashbook");
                        
                        $this->data['npaiement'] = $_SESSION['nverify'] = $paiement_nverify;
                        $this->data['vpaiement'] = $_SESSION['verify'] = $paiement_verify;

                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "toll_offline")
                {   
                        if(isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0'):
                                $result = json_decode($_SESSION['Bank_rates'], true);
                                $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                        else:
                                $taux = 1;
                        endif;
                        
                        $paiement_verify = $this->encaissementModel->get_paiements_toll_offline_verify();
                        $paiement_nverify = $this->encaissementModel->get_paiements_toll_offline_nverify();
                        
                        $montant_nverify= 0; 
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;
                        
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        
                        $this->data['nvpaiement'] = $paiement_nverify;
                        $this->data['vpaiement'] = $paiement_verify;
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "paiements_filter")
                {
                        $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                        $this->data['airport'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['types'] = $this->encaissementModel->types_vol;
                        
                        $national = $this->encaissementModel->national_airline;
                        $international = $this->encaissementModel->international_airline;
                        
                        $airports = array_merge($national,$international);
                        $this->data['company'] = $airports;
                        
                        $this->data['paiements'] = $this->encaissementModel->get_paiements_filter($_POST);
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "toll_filter")
                {
                        if (isset($_GET['Type_12']) && isset($_GET['start']) && isset($_GET['end']))
                        {
                            $_POST['Type_12'] = $_GET['Type_12'];
                            $_POST['start'] = $_GET['start'];
                            $_POST['end'] = $_GET['end'];
                        }
                        
                        $paiement_nverify  = $this->encaissementModel->get_paiements_toll_nverify_filter($_POST);
                        $paiement_verify = $this->encaissementModel->get_paiements_toll_verify_filter($_POST);
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 1;
                        
                        $montant_nverify = 0;
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;
                        
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                    
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_toll();
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        $this->data['npaiement'] = $_SESSION['print_toll_nverify'] = $paiement_nverify;
                        $this->data['vpaiement'] = $_SESSION['print_toll_verify'] = $paiement_verify;

                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        
                        if (isset($_GET['Type_12']) && isset($_GET['start']) && isset($_GET['end']))
                        {
                                echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);

                        }
                        else
                        {
                                echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                        }
                        
                }
                elseif($obj == "toll_offline_filter")
                {
                        $paiement_nverify  = $this->encaissementModel->get_paiements_toll_offline_nverify_filter($_POST);
                        $paiement_verify = $this->encaissementModel->get_paiements_toll_offline_verify_filter($_POST);
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                    
                        $montant_nverify = 0;
                        $total_nverify = 0;

                        $montant_verify = 0; 
                        $total_verify = 0;
                        
                        foreach ($paiement_nverify as $row):
                            $montant_nverify+= $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_nverify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_nverify += $row->Amount_10;
                            }
                        endforeach;
                        
                        
                        foreach ($paiement_verify as $row):
                            $montant_verify += $row->Amount_10;
                        
                            if($row->Devise_11 == 'CDF')
                            {
                                    $total_verify += $row->Amount_10;
                            }
                            else
                            {
                                    $row->Amount_10 = $taux * $row->Amount_10;
                                    $total_verify += $row->Amount_10;
                            }
                        endforeach;
                        
                        $this->data['total_verify'] = $total_verify;
                        $this->data['total_nverify'] = $total_nverify;
                    
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_toll();
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        $this->data['npaiement'] = $paiement_nverify;
                        $this->data['vpaiement'] = $paiement_verify;

                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_toll_filter', $this->data);
                }
                elseif($obj == "toll_partners_filter")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['paiement'] = $_SESSION['toll_partners']= $this->encaissementModel->get_paiement_toll_partners_filter($_POST);
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        $this->data['taux'] = isset($result['Dollar_7']) ? $result['Dollar_7'] : "1";
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['stats'] = $this->data('stats_partner');
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "ticket_filter")
                {
                        $payment_means = $id;
                        
                        $this->data['payment_unverified'] = $this->encaissementModel->get_paiements_ticket_no_verify_filter($payment_means);
                        $this->data['payment_verified'] = $this->encaissementModel->get_paiements_ticket_verify_filter($payment_means);
                        
                        $unverified_payment_amount= 0;
                        $total_unverified_payment = 0;

                        $verified_payment_amount = 0; 
                        $total_verified_payment = 0;
                        
                        $result = json_decode($_SESSION['Bank_rates'], true);
                        $taux = isset($result['Dollar_7']) ? $result['Dollar_7'] : 1;
                        
                        foreach ($this->data['payment_unverified'] as $row)
                        {
                                $unverified_payment_amount += $row->Amount_10;

                                if($row->Devise_11 == 'CDF')
                                {
                                        $total_unverified_payment += $row->Amount_10;
                                }
                                else
                                {
                                        $row->Amount_10 = $taux * $row->Amount_10;
                                        $total_unverified_payment += $row->Amount_10;
                                }
                        }
                        
                        foreach ($this->data['payment_verified'] as $row)
                        {
                                $verified_payment_amount += $row->Amount_10;

                                if($row->Devise_11 == 'CDF')
                                {
                                        $total_verified_payment += $row->Amount_10;
                                }
                                else
                                {
                                        $row->Amount_10 = $taux * $row->Amount_10;
                                        $total_verified_payment += $row->Amount_10;
                                }
                        }
                        
                        $this->data['total_verified_payment'] = $total_verified_payment;
                        $this->data['total_unverified_payment'] = $total_unverified_payment;
                        
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['event_date_start'] = $this->eventsModel->get_dropdown("event_date_start");
                        $this->data['event_date_end'] = $this->eventsModel->get_dropdown('event_date_end');
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_tickets_filter', $this->data);
                }
                elseif($obj == "partner_filter")
                {
                        $this->data['events'] = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_ticket_filter();
                        $this->data['partners'] = $this->partnersModel->get_dropdown("partners");
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "gopass_filter")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_toll();
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_gopass_filter();
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "guichets_status_filter")
                {
                        $this->data['guichets'] = $this->caissesModel->get_dropdown("caisses");
                        $this->data['status'] = $this->caissesModel->filter_caisses_status($_POST);
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['agences'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "filter_contribuable")
                {
                        $this->data['regies'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $encaissements= $this->reportsModel->get_filter_contribuable_paiements();
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        echo view('\Modules\Etoll\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "payment_cancelled") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['paiements'] = $paiements = $this->encaissementModel->get_paiements_toll_cancelled();
                        
                        # unset the value of the nverify session
                        unset($_SESSION['paiement_cancelling']);
                        
                        $total = 0;
                        
                        $result = $this->ratesModel->get_last_published_rate();
                        $result = current($result);
                        
                        $taux = isset($result->Dollar_7) ? $result->Dollar_7 : 0;
                        
                        foreach ($paiements as $row):

                            if($row->Devise_11 == 'CDF')
                            {
                                    $total += $row->Amount_10;
                            }
                            else
                            {
                                    $total += $taux * $row->Amount_10;
                            }
                            
                        endforeach;
                        
                        $this->data['total'] = $total;
                        
                        echo view('\Modules\Etoll\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_toll_cancelling") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        
                        if(isset($_SESSION['paiement_cancelling']))
                        {
                                unset($_SESSION['paiement_cancelling']);
                        }
                        
                        $this->data['paiements'] = $paiements = $_SESSION['paiement_cancelling'] = $this->encaissementModel->get_paiements_toll_cancelled_by_filter();
                        
                        $total = 0;
                        
                        $result = $this->ratesModel->get_last_published_rate();
                        $result = current($result);
                        
                        $taux = isset($result->Dollar_7) ? $result->Dollar_7 : 0;
                        
                        foreach ($paiements as $row):

                            if($row->Devise_11 == 'CDF')
                            {
                                    $total += $row->Amount_10;
                            }
                            else
                            {
                                    $total += $taux * $row->Amount_10;
                            }
                            
                        endforeach;
                        
                        $view = view('\Modules\Etoll\Views\\'.$this->folder.'\_cancelling', $this->data);
                        
                        $return = array();
                        
                        $return ['view'] = $view;
                        $return ['total'] = $total;
                        
                        echo json_encode($return);
                }
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->folder . '_denial', $this->data);
                }
	}
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        if($data !="" && $data != NULL)
                        {
                                $members = $this->usersModel->get_members($data);
                        }
                        else
                        {
                                $members = $this->usersModel->get_members();
                        }
                        
                        $members = $this->usersModel->get_members();
                        
                        return $members;
                }
               
                
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */