<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;

class scanningQrCode extends BaseController
{
    public $roles = '5';
    public $group = 'banks';
    public $module = 'etoll';
    public $folder = 'etoll';
    public $mainModal;
        
    public function __construct()
    {
        parent::__construct();
                
        $this->mainModal = new MainModel();

        $this->data['module'] = $this->module;
        $this->data['application'] = 'admin';
        $this->data['function'] = '';
        $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
        $this->data['currency'] = $this->session->userdata['account_currency'];
        $this->data['fullname'] = $this->session->userdata['user_fname'];
        $this->data['userid'] = $this->session->userdata["user_id"];
        $user_roles = $this->session->userdata['user_roles'];
        $this->data['sidebar'] = '';

        /*
            * Control user access to this module
            * If string is empty, then access denied
            * A garder si uniquement c'est necessaire !!
        */
        if (!isset($_SESSION['Logiref_privileges'])) {
            // $this->data("set_privilegies");
        } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
            $this->roles = json_decode($user_roles['Logiref_privileges'], true);
        } elseif ($this->session->userdata['user_type'] == "400") {
            #$this->display('deny');
        }

        //Group - A garder si uniquement c'est necessaire !!
        if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
            $this->group = $_SESSION['Logiref_groupe'];
            $this->role = $_SESSION['Logiref_role'];
        } else {
            redirect('main/signin', 'refresh');
        }
    }

    public function init_scan()
    {
        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
            $this->data['sidebar'] = '';
        }
        $this->data['subview'] = '\Modules\Etoll\Views\initScan';
        return view('layouts/layout_main', $this->data);
    }
    
}