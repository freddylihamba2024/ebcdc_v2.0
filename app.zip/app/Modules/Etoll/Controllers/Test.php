<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;

class Test extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array(); 
        
        public $group = ''; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $roles = '5';
        public $lang = 'fr';
        public $module = '';
        public $folder = '';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                */
	} 
	
        
	public function index()
	{
                $email_address = 'alvinbauma10@gmail.com';
                $account = $this->session->userdata['account_id'];
                $customer = 'Guy Mubiayi';
                $file = "";
                
		$return = $this->mail->mail_send_ticket_confirmation($email_address, $account, $customer, "en", $file);
                
                echo $return;
	}
}

/* End of file welcome.php  */
/* Location: /project/activities  */