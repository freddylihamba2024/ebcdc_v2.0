<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\PartnersModel;

class Products extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('products','weights');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'products';

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->MainModel = new MainModel();
                $this->productsModel = new ProductsModel();
                $this->branchesModel = new BranchesModel();
                $this->caissesModel = new CaissesModel();
                $this->partnersModel = new PartnersModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'products';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == '400')
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                if($this->session->get('Logiref_role')==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($this->session->get('Logiref_role')==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "product")
                {
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences", NULL, "ALL");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets_toll");
                        $this->data['product'] = $this->productsModel->get_product_info($id);
                        $this->data['type_product'] = $this->productsModel->type_product;
                        $this->data['type_trajet'] = $this->productsModel->type_trajet;
                        $this->data['beneficiaires'] = $this->partnersModel->get_dropdown('partners');
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_product', $this->data);
                }
                elseif($obj == "products")
                {
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences", NULL, "ALL");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['products'] = $this->productsModel->get_products();
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\products', $this->data);
                }
                elseif($obj == "select_partners")
                {
                        $partners = $this->partnersModel->get_dropdown('partners');
                        echo form_dropdown('beneficiaire[]', $partners, '', 'class="form-control " required="required" id="beneficiaire"'); 
                }
                elseif($obj == "weight")
                {
                        $this->data['products'] = $this->productsModel->get_dropdown("product_weight");
                        $this->data['sales_points'] = $this->branchesModel->get_dropdown("guichets_events");
                        $this->data['weight'] = $this->productsModel->get_weight_info($id);
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_weight', $this->data);
                }
                elseif($obj == "weights")
                {
                        $this->data['products'] = $this->productsModel->get_dropdown("product_weight");
                        $this->data['weights'] = $this->productsModel->get_weights();
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\weights', $this->data);
                }
                elseif($obj == "weight_range")
                {
                        $data = array();
                        $data = $_POST;
                        
                        $return = $this->data('get_weights', $data);
                        
                        echo json_encode($return);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "product")
                {
                        $data = $_POST;
                        
                        if(isset($data['Additionnal_field']) && $data['Additionnal_field'] != "")
                        {
                                $data['Additional_14'] = json_encode($data['Additionnal_field']);
                                unset($data['Additionnal_field']);
                        }
                        
                        if($data['Name_7']=='0' || $data['Description_8']==''):
                            
                                $return['message'] = '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                echo json_encode($return);
                                die;
                                
                        endif;
                        
                        $price =  str_replace(' ','',$_POST['Price_9']);
                        $data['Price_9']= str_replace(',','.',$price);
                        
                        $infos = array();
                        
                        $infos['beneficiaire'] = $data['beneficiaire'];
                        $infos['quota'] = $data['quota'];
                        
                        $data['Partners_20'] = json_encode($infos);

                        unset($data['beneficiaire']);
                        unset($data['quota']);
                        
                        $data['Weight_15'] = isset($_POST['Weight_15']) ? 1 : 0;
                        
                        if($data['Weight_15'] == 1)
                        {
                                foreach ($data['weightrange'] as $row)
                                {
                                        $data_weight_range = array();
                                        $procductid = $this->productsModel->get_last_product();
                                        
                                        if($id == NULL)     
                                        {
                                                $procductid = (int)$procductid;
                                                $data_weight_range['Tarif_7'] = $procductid + 1;
                                        }
                                        else
                                        {
                                                $data_weight_range['Tarif_7'] = $id;
                                                $this->productsModel->delete_weights_range($id);
                                        }
                                        
                                        $data_weight_range['Min_8'] = isset($row['min']) ? $row['min'] : "";
                                        $data_weight_range['Max_9'] = isset($row['max']) ? $row['max'] : "";
                                        $data_weight_range['Currency_11'] = isset($row['currency']) ? $row['currency'] : "";
                                        
                                        if(isset($row['price']))
                                        {
                                                $amount =  str_replace(' ','',$row['price']);
                                                $data_weight_range['Amount_10']= str_replace(',','.',$amount);
                                        }
                                        
                                        $data_weight_range['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data_weight_range['Status_2']=1;
                                        $data_weight_range['Account_3']=$this->session->userdata['account_id'];
                                        $data_weight_range['Creator_4']=$this->session->userdata['user_id'];
                                        
                                        $cid = $this->productsModel->save_weights($data_weight_range, NULL); 
                                }
                                
                                $data['Range_19'] = json_encode($data['weightrange']);
                                unset($data['weightrange']);
                        }
                        
                        if(isset($data['weightrange']))unset($data['weightrange']);
                        
                        $data['Status_2']=1;
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $tid = $this->productsModel->save_product($data, $id);    
                        if($tid):
                                $return['id'] = $tid;
                                $return['message'] = '<div class="alert alert-success">Bravo! tarif enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';  
                                echo json_encode($return);
                        else: 
                                $return['id'] = 0;
                                $return['message'] = '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';  
                                echo json_encode($return);
                        endif;
                }
                elseif($obj == "weight")
                {
                        $data = $_POST;
                       
                        if($data['Tarif_7']=='' || $data['Min_8']=='' || $data['Max_9']=='' || $data['Amount_10']=='' || $data['Currency_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        endif;
                        
                        $amount =  str_replace(' ','',$_POST['Amount_10']);
                        $data['Amount_10']= str_replace(',','.',$amount);
                        
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $cid = $this->productsModel->save_weights($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! param&eacute;trage enregistr&eacute; avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "validate")
                {
                        $data = array();
                        
                        $pid = 0;
                        
                        $data['Status_2'] = 2;

                        $pid = $this->productsModel->update_product($data, $id);

                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "delete")
                {
                        $data = array();
                        
                        $pid = 0;
                        
                        $data['Status_2'] = (isset($arg) && $arg != "") ? '0': '3';

                        $pid = $this->productsModel->update_product($data, $id);

                        #Return
                        echo $pid;
                        die;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_weights")
                {
                        $data['weight'] = isset($data['weight']) ? $data['weight'] : 0;
                        $data['tarif'] = isset($data['tarif']) ? $data['tarif'] : 0;
                        
                        $result = $this->productsModel->get_weight_range($data);
                        
                        $return = array("weight"=>$result['weight'], "currency"=>$result['currency']);  
                        
                        return $return; exit;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                        
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */

