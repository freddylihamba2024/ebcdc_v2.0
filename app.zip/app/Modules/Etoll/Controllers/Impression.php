<?php

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\StakeholdersModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\ProductsModel;
use Modules\Etoll\Models\ComptabilisationModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\AccountsModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\CashbooksModel;
use Modules\Etoll\Models\ReportsModel;
use Modules\Etoll\Models\TicketsModel;
use Modules\Etoll\Models\EventsModel;
use Modules\Etoll\Models\CountersModel;
use App\Libraries\Mail;
use PhpOffice\PhpSpreadsheet\IOFactory;

class Impression extends BaseController {
        /*
         * Presentation: gestion des impression(production des documents PDF)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'impression';
        public $logirefModel;
        public $stakeholdersModel;
        public $encaissementModel;
        public $productsModel;
        public $comptabilisationModel;
        public $integrationModel;
        public $accountsModel;
        public $branchesModel;
        public $usersModel;
        public $mainModel;
        public $cashbooksModel;
        public $reportsModel;
        public $ticketsModel;
        public $eventsModel;
        public $countersModel;
        public $mail;
        
        private static $OPENSSL_CIPHER_NAME = "aes-128-cbc"; //Name of OpenSSL Cipher 
        private static $CIPHER_KEY_LEN = 16; //128 bits

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->logirefModel = new LogirefModel();
                $this->stakeholdersModel = new StakeholdersModel();
                $this->encaissementModel = new EncaissementModel();
                $this->productsModel = new ProductsModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->integrationModel = new IntegrationModel();
                $this->accountsModel = new AccountsModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->mainModel = new MainModel();
                $this->cashbooksModel = new CashbooksModel();
                $this->reportsModel = new ReportsModel();
                $this->ticketsModel = new TicketsModel();
                $this->eventsModel = new EventsModel();
                $this->countersModel = new CountersModel();
                $this->mail = new Mail();
                
                $this->folder = 'impression';
                
	} 
	
        
	public function index()
	{
               
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "export_gu") 
                {  
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $agence = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountsModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'",$agence);
                        $encaissements  = $this->integrationModel->get_sucess_instructions_dgda($day);
                        $events = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $users = $this->mainModel->get_dropdown('users_array');
                        $cgu = isset($comptes['DGDA']['CGU']['CDF'])? $comptes['DGDA']['CGU']['CDF']: "";
                          
                        $regie = 'DGDA';
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[8]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                           
                        $table_columns = array("Date comptant","Date validation","Operateur","Validateur","Numéro événement","Code opération", "Libellé","Débit","Crédit");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        foreach($encaissements as $row)
                        {
                                # Montant paye
                                
                                if($row->Compte_13 == $cgu || $row->Compte_9 == $cgu)
                                {
                                        if($row->Compte_13 == $cgu)
                                        {
                                                $credit= $row->Montant_10;
                                                $debit= "";
                                        }
                                        else
                                        {
                                                $debit= $row->Montant_10;
                                                $credit="";
                                        }
                                        $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                
                                        if(isset($events[$row->Paiementid_4][$row->Id_0]['Num_evenement'])? $references[$row->Id_0] = $events[$row->Paiementid_4][$row->Id_0]['Num_evenement'] : $references[$row->Id_0] = '');
                                        if(isset($users[$row->Makerid_16])? $users[$row->Makerid_16] : $users[$row->Makerid_16]="" );
                                        if(isset($users[$row->Checkerid_17])? $users[$row->Checkerid_17] : $users[$row->Checkerid_17]="" );

                                        $worksheet->setCellValue('A'.$erow, $date_paiement);
                                        $worksheet->setCellValue('B'.$erow, $row->Validation_18);
                                        $worksheet->setCellValue('C'.$erow, $users[$row->Makerid_16]);
                                        $worksheet->setCellValue('D'.$erow, $users[$row->Checkerid_17]);
                                        $worksheet->setCellValue('E'.$erow, $references[$row->Id_0]);
                                        $worksheet->setCellValue('F'.$erow, "147");
                                        $worksheet->setCellValue('G'.$erow, $row->Libelle_12);
                                        $worksheet->setCellValue('H'.$erow, $debit);
                                        $worksheet->setCellValue('I'.$erow, $credit);

                                        if($i != $array_length)
                                        {   
                                            $erow++;
                                        }
                                        $i++;

                                }
                                
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_'.$regie.'_report_gu_'.time().'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/reportings';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                                
                        return $path;

                }
                elseif($obj == "export_commission")
                {
                        $paiements = $this->encaissementModel->get_paiements();
                        $equivalence = 0;
                        $calcul = 0;
                        $tva = 0.16;
                        $usd = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2850;
                        $guichets = $this->branchesModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                              
                        $table_columns = array("Date","Client","Commission","TVA","Agence");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiements);
                        foreach($paiements as $row)
                        {
                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $calcul = $row->Commission_23*$tva;

                                if($row->Devise_24 == "USD")
                                {
                                        $equivalence = $row->Commission_23*$usd;
                                }
                                else
                                {
                                        $equivalence = $row->Commission_23;
                                }
                                #var_dump($equivalence);die;

                                $worksheet->setCellValue('A'.$erow, $date_paiement);
                                $worksheet->setCellValue('B'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('C'.$erow, $equivalence);
                                $worksheet->setCellValue('D'.$erow, $calcul);
                                $worksheet->setCellValue('E'.$erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_commissions_'.time().'.xlsx';
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-commission';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }

                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);

                        return $path;
                }
                elseif($obj == "export_toll_reconciliation_nverify")
                {
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2850;

                        #$paiement = $this->encaissement_model->get_paiements_toll();
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport");
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        $cashbook = $this->cashbooksModel->get_dropdown("cashbook");

                        $returns = $this->integrationModel->get_cbs_returns_tolls_array();
                        $cbs_returns = array();
                        foreach ($returns as $rKey => $values)
                        {
                                foreach ($values as $key => $value)
                                {
                                        if (is_array($value) && isset($value['Num_evenement']) && isset($value['code'])):
                                                $cbs_returns[$rKey] = $value;
                                        endif;
                                }
                        }

                        if(isset($_SESSION['nverify']))
                        {
                                $paiement = $_SESSION['nverify'];
                        }
                        else
                        {
                                $paiement = $this->encaissementModel->get_paiements_toll_nverify();
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[10];
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex

                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));

                        $table_columns = array("Date de paiement","Départ","Déstination","Montant","Devise","Catégorie","Plaque", "Num.Amplitude", "Sopeco", "Opérateur","Mode");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);

                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($paiement);
                        /*$datas = $this->session->userdata['datas'];

                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }*/

                        $users = $this->mainModel->get_dropdown('users');
                        $operators_list = $this->usersModel->get_dropdown('operators', $users);

                        $modes = $this->logirefModel->modes;

                        foreach($paiement as $row)
                        {
                                $worksheet->getStyle('F')->applyFromArray(
                                        array(
                                                'code' =>'###'
                                        )
                                );

                                $user = isset($operators_list[$row->Creator_4]) ? $operators_list[$row->Creator_4] : '';

                                $worksheet->getStyle('D')->getNumberFormat()->setFormatCode('###');

                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                                $worksheet->setCellValue('D'.$erow, number_format($row->Amount_10,2,","," "));
                                $worksheet->setCellValue('E'.$erow, $row->Devise_11);
                                $worksheet->setCellValue('F'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('G'.$erow, $row->Numero_13);
                                $worksheet->setCellValue('H'.$erow, isset($cbs_returns[$row->Id_0]["Num_evenement"]) ? $cbs_returns[$row->Id_0]["Num_evenement"].' ': "");
                                $worksheet->setCellValue('I'.$erow, $row->Refcbs_38);
                                $worksheet->setCellValue('J'.$erow, $user);
                                $worksheet->setCellValue('K'.$erow, isset($modes[$row->Mode_29]) ? $modes[$row->Mode_29] : '');

                                if($i != $array_length)
                                {
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';


                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['verify']);
                                
                        return $path;
                }
                if($obj == "export_toll_cancelling") 
                {  
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        
                        #$paiement = $this->encaissement_model->get_paiements_toll();
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport"); 
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        $cashbook = $this->cashbooksModel->get_dropdown("cashbook");
                        
                        $returns = $this->integrationModel->get_cbs_returns_tolls_array();
                        $cbs_returns = array();
                        foreach ($returns as $rKey => $values) 
                        {
                                foreach ($values as $key => $value) 
                                {
                                        if (is_array($value) && isset($value['Num_evenement']) && isset($value['code'])):
                                                $cbs_returns[$rKey] = $value;
                                        endif;
                                }
                        }
                        
                        if(isset($_SESSION['paiement_cancelling']))
                        {
                                $paiement = $_SESSION['paiement_cancelling'];
                        }
                        else
                        {
                                $paiement = $this->encaissementModel->get_paiements_toll_to_cancel();
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[9]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_plates');
                        //set cell A1 content with some tex

                        $styleArray = array(
                                'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));

                        $table_columns = array("Date de paiement","Départ","Déstination","Montant","Devise","Catégorie","Plaque","Num.Amplitude", "Sopeco", "Opérateur", "Mode");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }

                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;

                        $array_length = count($paiement);
                        $datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }
                        
                        $users = $this->mainModel->get_dropdown('users');
                        $operators_list = $this->usersModel->get_dropdown('operators', $users);
                        
                        $modes = $this->logirefModel->modes;

                        foreach($paiement as $row)
                        {
                                $user = isset($operators_list[$row->Creator_4]) ? $operators_list[$row->Creator_4] : '';

                                $worksheet->getStyle('D')->getNumberFormat()->setFormatCode('###');

                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                                $worksheet->setCellValue('D'.$erow, number_format($row->Amount_10,2,","," "));
                                /*if($row->Devise_11 == 'CDF')
                                {
                                        $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($row->Amount_10,2,","," "));
                                }
                                else
                                {
                                        $montant = $taux * $row->Amount_10;
                                        $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($montant,2,","," "));

                                }*/
                                $worksheet->setCellValue('E'.$erow, $row->Devise_11);
                                $worksheet->setCellValue('F'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('G'.$erow, $row->Numero_13);
                                $worksheet->setCellValue('H'.$erow, isset($cbs_returns[$row->Id_0]["Num_evenement"]) ? $cbs_returns[$row->Id_0]["Num_evenement"].' ': "");
                                $worksheet->setCellValue('I'.$erow, $row->Refcbs_38);
                                $worksheet->setCellValue('J'.$erow, $user);
                                $worksheet->setCellValue('K'.$erow, isset($modes[$row->Mode_29]) ? $modes[$row->Mode_29] : '');

                                if($i != $array_length)
                                {
                                    $erow++;

                                }
                                $i++;
                        }

                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['verify']);
                                
                        return $path;
                }
                elseif($obj == "export_toll_reconciliation_verify") 
                {  
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;

                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport"); 
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        $cashbook = $this->cashbooksModel->get_dropdown("cashbook");

                        $returns = $this->integrationModel->get_cbs_returns_tolls_array();
                        $cbs_returns = array();
                        foreach ($returns as $rKey => $values) 
                        {
                                foreach ($values as $key => $value) 
                                {
                                        if (is_array($value) && isset($value['Num_evenement']) && isset($value['code'])):
                                                $cbs_returns[$rKey] = $value;
                                        endif;
                                }
                        }

                        if(isset($_SESSION['verify']))
                        {
                                $paiement = $_SESSION['verify'];
                        }
                        else
                        {
                                $paiement =  $this->encaissementModel->get_paiements_toll_verify();
                        }

                        $alphas = range('A', 'Z');
                        $atoz = $alphas[10]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex

                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));

                        $table_columns = array("Date de paiement","Départ","Déstination","Montant","Devise","Catégorie","Plaque", "Num.Amplitude", "Sopeco", "Opérateur","Mode");
                        $column = 0;

                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiement);
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }*/

                        $users = $this->mainModel->get_dropdown('users');
                        $operators_list = $this->usersModel->get_dropdown('operators', $users);

                        $modes = $this->logirefModel->modes;
                        
                        foreach($paiement as $row)
                        {
                                $user = isset($operators_list[$row->Creator_4]) ? $operators_list[$row->Creator_4] : '';

                                $worksheet->getStyle('D')->getNumberFormat()->setFormatCode('###');

                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                                $worksheet->setCellValue('D'.$erow, number_format($row->Amount_10,2,","," "));
                                $worksheet->setCellValue('E'.$erow, $row->Devise_11);
                                $worksheet->setCellValue('F'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('G'.$erow, $row->Numero_13);
                                $worksheet->setCellValue('H'.$erow, isset($cbs_returns[$row->Id_0]["Num_evenement"]) ? $cbs_returns[$row->Id_0]["Num_evenement"].' ': "");
                                $worksheet->setCellValue('I'.$erow, $row->Refcbs_38);
                                $worksheet->setCellValue('J'.$erow, $user);
                                $worksheet->setCellValue('K'.$erow, isset($modes[$row->Mode_29]) ? $modes[$row->Mode_29] : '');

                                if($i != $array_length)
                                {
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);

                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['verify']);

                        return $path;

                }
                elseif($obj == "export_tolls")
                {
                        
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2850;
                        
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport"); 
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        
                        if(isset($_SESSION['print_toll_nverify']))
                        {
                                $paiement = $_SESSION['print_toll_nverify'];
                        }
                        else
                        {
                                $paiement = $this->encaissementModel->get_paiements_toll_nverify();
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                        
                        $table_columns = array("Date de paiement","Départ","Déstination","Montant","Devise","Catégorie","Plaque");
                        
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;


                        $array_length = count($paiement);
                        /*$datas = $this->session->userdata['datas'];
                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }*/
                        
                        foreach($paiement as $row)
                        {
                                $worksheet->getStyle('D')->getNumberFormat()->setFormatCode('##0.00');
                                
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                //$worksheet->setCellValue('B'.$erow, $row->Changes_5);
                                $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                             
                                $worksheet->setCellValue('D'.$erow, $row->Amount_10);
                             
                                $worksheet->setCellValue('E'.$erow, $row->Devise_11);
                                $worksheet->setCellValue('F'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('G'.$erow, $row->Numero_13);
                                //$worksheet->setCellValue('H'.$erow, ($row->Status_2 == 1)? "Non vérifié":"Vérifié");

                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0');
                        
                        if($id == NULL)
                        {  
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['toll_filter_nverify']);
                                
                        return $path;
                }
                elseif($obj == "export_tolls_verify") 
                {  
                        
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2850;
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport"); 
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        
                        if(isset($_SESSION['print_toll_verify']))
                        {
                                $paiement = $_SESSION['print_toll_verify'];
                        }
                        else
                        {
                                $paiement =  $this->encaissementModel->get_paiements_toll_verify();
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                               
                        $table_columns = array("Date de paiement","Date de vérification","Départ","Déstination","Montant","Catégorie","Plaque","Statut");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiement);
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }*/
                        
                        foreach($paiement as $row)
                        {
                                $worksheet->getStyle('E')->getNumberFormat()->setFormatCode('###');
                                
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Changes_5);
                                $worksheet->setCellValue('C'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('D'.$erow, $row->Destination_16);
                                if($row->Devise_11 == 'CDF')
                                {
                                        $worksheet->setCellValue('E'.$erow, 'CDF '.number_format($row->Amount_10,2,","," "));
                                }
                                else
                                {
                                        $montant = $taux * $row->Amount_10;
                                        $worksheet->setCellValue('E'.$erow, 'CDF '.number_format($montant,2,","," "));

                                }
                                $worksheet->setCellValue('F'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('G'.$erow, $row->Numero_13);
                                $worksheet->setCellValue('H'.$erow, ($row->Status_2 == 1)? "Non vérifié":"Vérifié");
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['toll_filter_nverify']);
                                
                        return $path;

                }
                elseif($obj == "export_toll_partners") 
                {  

                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $airports = $this->encaissementModel->get_dropdown("airport");
                        $products = $this->productsModel->get_dropdown("products");
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : "2000";
                        $stats = $this->data('stats_partner');
                        
                        if(isset($_SESSION['toll_partners']))
                        {
                                $paiement = $_SESSION['toll_partners'];
                        }
                        else
                        {
                                $paiement = $this->encaissementModel->get_paiement_toll_partners();
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                              
                        $table_columns = array("Date","Départ","Déstination","Montant","Catégorie","Quote-parts");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiement);
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $paiement = $datas;
                        }*/
                        
                        foreach($paiement as $row)
                        {
                                $partners_info = json_decode($row->Partner_25, true);
                                
                                        for($j=0; $j<count($partners_info['quota_partner']); $j++):

                                                if($partners_info['partner'][$j] == $_SESSION['partner']):
                                
                                                        $worksheet->getStyle('D')->getNumberFormat()->setFormatCode('###');

                                                        $worksheet->setCellValue('A'.$erow, $row->Date_1);

                                                        if($row->Productid_7 == '1'):
                                                            $worksheet->setCellValue('B'.$erow, isset($airports[$row->Departure_15]) ? $airports[$row->Departure_15] : "");
                                                            $worksheet->setCellValue('C'.$erow, isset($airports[$row->Destination_16]) ? $airports[$row->Destination_16] : "");
                                                        else:
                                                            $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                                            $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                                                        endif;

                                                        if($row->Devise_11 == 'CDF')
                                                        {
                                                                $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($row->Amount_10,2,","," "));
                                                        }
                                                        else
                                                        {
                                                                $montant = $taux * $row->Amount_10;
                                                                $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($montant,2,","," "));

                                                        }

                                                        $worksheet->setCellValue('E'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");

                                                        if($row->Devise_11 != 'CDF'):
                                                                $worksheet->setCellValue('F'.$erow, $partners_info['quota_partner'][$j] * $taux);
                                                        else:
                                                                $worksheet->setCellValue('F'.$erow, $partners_info['quota_partner'][$j]);
                                                        endif;
                                                endif;
                                        endfor;
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_peages.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['toll_partners']);
                                
                        return $path;

                }
                elseif($obj == "export_regularize_tolls") 
                {  
                        $taux = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2850;
                        $airports = $this->encaissementModel->get_dropdown("airport"); 
                        $products = $this->productsModel->get_dropdown("products");
                        $status = $this->encaissementModel->status_tolls;
                        $status_color = $this->encaissementModel->color_tolls;
                        
                        if(isset($_SESSION['regularize_tolls']))
                        {
                                $paiements = $_SESSION['regularize_tolls'];
                        }
                        else
                        {
                                $paiements = $this->encaissementModel->get_paiements_toll_to_regularize();
                        }
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                        
                        $table_columns = array("Date","Départ","Déstination","Montant","Catégorie","Plaque");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($paiements);
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $paiements = $datas;
                        }*/
                        
                        foreach($paiements as $row)
                        {
                                $worksheet->setCellValue('A'.$erow, $row->Date_1);
                                $worksheet->setCellValue('B'.$erow, $row->Departure_15);
                                $worksheet->setCellValue('C'.$erow, $row->Destination_16);
                                if($row->Devise_11 == 'CDF')
                                {
                                        $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($row->Amount_10,2,","," "));
                                }
                                else
                                {
                                        $montant = $taux * $row->Amount_10;
                                        $worksheet->setCellValue('D'.$erow, 'CDF '.number_format($montant,2,","," "));

                                }
                                $worksheet->setCellValue('E'.$erow, isset($products[$row->Type_12]) ? $products[$row->Type_12] : "");
                                $worksheet->setCellValue('F'.$erow, $row->Numero_13);
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename= 'paiement_regularise_peages.xlsx';
                        

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-plaques';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                        unset($_SESSION['regularize_tolls']);
                                
                        return $path;

                }
                elseif($obj == "report_dgidgrad")
                {
                        $beneficiaires= $this->reportsModel->regies;
                        $encaissements = $this->reportsModel->get_report_paiements();
                        $guichets = $this->branchesModel->get_dropdown("guichets");
                        $recettes = $this->logirefModel->get_dropdown("recettes");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                               
                        $table_columns = array("Date","R&eacute;gie","Service","Client","Montant", "Commissions", "Agences");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $encaissements = $datas;
                        }*/

                        foreach($encaissements as $row)
                        {
                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));
                                $worksheet->setCellValue('A'.$erow, $date_paiement);
                                $worksheet->setCellValue('B'.$erow, $row->Beneficaire_15);
                                $worksheet->setCellValue('C'.$erow, $row->Service_16);
                                $worksheet->setCellValue('D'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('E'.$erow, $row->Contrevaleur_22);
                                $worksheet->setCellValue('F'.$erow, $row->Commission_23);
                                $worksheet->setCellValue('G'.$erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_dgidgrad'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-dgidgrad';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                                
                        return $path;
                }
                 elseif($obj == "report_paydgda")
                {
                        $services = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $bulletins = $this->integrationModel->get_reports_bls();
                        $guichets = $this->branchesModel->get_dropdown("guichets");
                        $deadline = date('Y-m-d');
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[6]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                                
                        $table_columns = array("Date", "Service","Client","Montant", "Commissions", "Agences");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($bulletins);
                        
                        /*$datas = $this->session->userdata['datas'];
                        if(isset($datas) && $datas !="")
                        {
                                $bulletins = $datas;
                        }*/

                        foreach($bulletins as $row)
                        {

                                $date_paiement = strftime('%d/%m/%Y',strtotime($row->Date_1));

                                $worksheet->setCellValue('A'.$erow, $date_paiement);
                                $worksheet->setCellValue('B'.$erow, $services['DGDA'][$row->Office_6]);
                                $worksheet->setCellValue('C'.$erow, $row->Designation_23);
                                $worksheet->setCellValue('D'.$erow, $row->Amount_12);
                                $worksheet->setCellValue('E'.$erow, $row->Commission_26);
                                $worksheet->setCellValue('F'.$erow, $guichets[$row->Agence_32]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_paydgda'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-paydgda';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                                
                        return $path;
                }
                elseif($obj == "penalitie_dgda")
                {
                        $penalite=0;
                        $beneficiaires = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $encaissements = $this->encaissementModel->get_paiements('penalities');
                        $guichets = $this->branchesModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[7]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                                
                        $table_columns = array("Date", "Client", "Beneficiaire", "Recette", "Montant", "Retard","Penalité", "Agences");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($encaissements);
                        foreach($encaissements as $row)
                        {
                                #Trouver le nombre de jour/mois/annee entre les dates
                                $date1 = $row->Datevaleur_31;
                                $date2 = gmdate('Y-m-d');
                                $diff = abs(strtotime($date2) - strtotime($date1));
                                $years = floor($diff / (365*60*60*24));
                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                
                                $penalite =$row->Montant_11*0.03*$days; 
                                
                                
                                $dateTime = new DateTime($row->	Datevaleur_31); $date= $dateTime->format('U'); $deadline = date('Y-m-d', strtotime("+60 day",$date));
                                $worksheet->setCellValue('A'.$erow, $row->Datevaleur_31);
                                $worksheet->setCellValue('B'.$erow, $row->Designation_14);
                                $worksheet->setCellValue('C'.$erow, $row->Beneficaire_15);
                                if($row->Beneficaire_15 =="DGRAD")$worksheet->setCellValue('D'.$erow, $row->Typerecette_17." ".$row->Noteid_26);
                                else$worksheet->setCellValue('D'.$erow, $row->Typerecette_17);
                                $worksheet->setCellValue('E'.$erow, $row->Montant_11);
                                $worksheet->setCellValue('F'.$erow, $days." "."jours");
                                $worksheet->setCellValue('G'.$erow, $penalite);
                                $worksheet->setCellValue('H'.$erow, $guichets[$row->Guichet_21]);

                                if($i != $array_length)
                                {   
                                    $erow++;
                                }
                                $i++;
                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename=$user_id.'_report_paydgda'.time().'.xlsx';

                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 

                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/report-paydgda';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                                
                        return $path;
                }
                 elseif($obj == "export_comptes") 
                {  
                        $comptes = $this->accountsModel->get_export_comptes();
                        $types = $this->logirefModel->get_dropdown("types","Compte");
                        $users = $this->mainModel->get_dropdown('users_array');
                        $agences = $this->branchesModel->get_dropdown("guichets");
                        $services =$this->logirefModel->get_dropdown("services");
                        $recettes = $this->logirefModel->get_dropdown("recettes");
                        $villes = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $guichets = $this->branchesModel->get_dropdown("guichets");
                        
                        $alphas = range('A', 'Z');
                        $atoz = $alphas[5]; 
                        //load our new PHPExcel library
                        $worksheet = $this->spreadsheet->setActiveSheetIndex(0);
                        //name the worksheet
                        $worksheet->setTitle('report_tolls');
                        //set cell A1 content with some tex
                        
                        $styleArray = array(
                            'font'  => array(
                                'bold'  => true,
                                'color' => array('rgb' => '000000'),
                                'size'  => 12,
                                'name'  => 'Book Antiqua'
                        ));  
                                
                        $table_columns = array("Agence","Type","Taxe","Comptes","Devise","Bénéficiaire");
                        $column = 0;
                        
                        foreach ($table_columns as $columnIndex => $columnName) 
                        {

                                $cellCoordinate = $alphas[$columnIndex] . '1';
                                $worksheet->setCellValue($cellCoordinate, $columnName);
                            
                        }
                        $worksheet->getStyle('A1:' . $atoz . '1')->applyFromArray($styleArray);
                        $erow = 2;
                        $i = 0;
                        
                        $array_length = count($comptes);
                        
                        /*$datas = $this->session->userdata['datas'];
                        
                        if(isset($datas) && $datas !="")
                        {
                                $comptes = $datas;
                        }*/
                        
                        foreach($comptes as $row)
                        {
                                if(isset($guichets[$row->Agence_12]))$worksheet->setCellValue('A'.$erow, $guichets[$row->Agence_12]);
                                $worksheet->setCellValue('B'.$erow, $row->Type_4);
                                $worksheet->setCellValue('C'.$erow, $row->Recette_13);
                                $worksheet->setCellValue('D'.$erow, $row->Agenceid_15.'-'.$row->Compte_6.'-'.$row->Clef_7.' ');
                                $worksheet->setCellValue('E'.$erow, $row->Devise_8);
                                $worksheet->setCellValue('F'.$erow, $row->Beneficiaires_5);
                                
                                if($i != $array_length)
                                {   
                                    $erow++;

                                }
                                $i++;

                        }
                        //Sizing
                        $highestColumn = $this->spreadsheet->getActiveSheet()->getHighestColumn();

                        for ($col = 'A'; $col <= $highestColumn; $col++) 
                        {
                                $this->spreadsheet->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                        }

                        $styleArray = [
                            'borders' => [
                                'allBorders' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['argb' => '000000'], // Couleur de la bordure, vous pouvez personnaliser
                                ],
                            ],
                        ];

                        $worksheet->getStyle('A1:' . $atoz . $erow)->applyFromArray($styleArray);
                        unset($styleArray);
                        
                        $user_id = $this->session->userdata['user_id'];
                        $filename= $guichets[$row->Agence_12].'.xlsx';
                        
                        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                        header('Content-Disposition: attachment;filename="'.$filename.'"');
                        header('Cache-Control: max-age=0'); 
                        
                        if($id == NULL)
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $path = "./drive/logiref/".$account_id."/".date('Y-m').'/les-comptes';
                                if (is_dir($path)==false)
                                {
                                        mkdir($path,0777,true);
                                }
                                $path = $path."/".$filename;
                        }
                        //download the file in the browser
                        $objWriter = IOFactory::createWriter($this->spreadsheet, 'Xlsx');
                        $objWriter->save($path);
                                
                        return $path;
                }
                elseif($obj == "schema")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        $guichet = $this->branchesModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        //get instuctions
                        if($encaissement->Beneficaire_15 == "DGI"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgi($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGRAD"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgrad($encaissement->Logirefid_4);
                        
                        elseif($encaissement->Beneficaire_15 == "DGDA"):
                            
                            $instrcutions = $this->comptabilisationModel->get_instructions_dgda($encaissement->Sydonia_44);
                        
                        endif;
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        
                        $this->data['lines'] = $instrcutions;
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_schema', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj == "schemabl")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_paiement_tresor_bl($id);
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_paiement_propres_bl($id);  
                        }
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchesModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_schema_dgda', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
 
                }
                if($obj == "schema_prepayment")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        
                        $encaissement = $this->encaissementModel->get_prepaiement_tresor_bl($id);
                        
                        
                        if(empty($encaissement))
                        {
                              $encaissement = $this->encaissementModel->get_prepaiement_propres_bl($id);  
                        }
                        
                        $encaissement->Beneficaire_15 = 'DGDA';
                        $encaissement->Contrevaleur_22 = $encaissement->Notemontant_28;
                        
                        $this->data['encaissement'] = $encaissement;
                        $guichet = $this->branchesModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_prepayments_cbs_returns($id);
                        //var_dump($cbs_return); die;
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['lines'] = $instrcutions;
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_schema_prepayment', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj == "attestation")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        
                        #var_dump($this->data['encaissement']);die;
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        
                        $guichet = $this->branchesModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $service_type =$this->logirefModel->get_dropdown("type_services");
                         
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        //$this->data['qrcode'] = $params['savename'] = $dir."/".$this->data['encaissement']->Logirefid_4.'.png';
                        //$this->ciqrcode->generate($params);
                        if($encaissement->Beneficaire_15 == "DGRAD")
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgrad', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'AMRA')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi_amra', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'IBP')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi_ibp', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != 'IPRIER')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI"  && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'IPRIER')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_cdi_iprier', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGDA")
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgda', $this->data);
                        }
                        
                        #$html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj == "attestationbl")
                {
                        //now pass the data//
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->encaissementModel->modes;
                        $this->data['months'] = $this->comptabilisationModel->months;
                        $this->data['months_abrv'] = $this->comptabilisationModel->months_abrv;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $beneficiaires = $this->data['beneficiaires'] = $this->logirefModel->get_dropdown('regies');
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        
                        #var_dump($this->data['encaissement']);die;
                        if(empty($encaissement))
                        {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }
                        
                        $this->data['number_letter'] = $this->data('number_letter',$encaissement->Contrevaleur_22, 'CDF');
                        
                        $guichet = $this->branchesModel->get_guichet_info($this->data['encaissement']->Guichet_21);
                        $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $service_type =$this->logirefModel->get_dropdown("type_services");
                         
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        $params['data'] = 'www.ikwook.com/logiref/code/'.$this->data['encaissement']->Logirefid_4;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        //$this->data['qrcode'] = $params['savename'] = $dir."/".$this->data['encaissement']->Logirefid_4.'.png';
                        //$this->ciqrcode->generate($params);
                        if($encaissement->Beneficaire_15 == "DGRAD")
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgrad', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'AMRA')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi_amra', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'IBP')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi_ibp', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI" && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 != 'IPRIER')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgi', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGI"  && isset($encaissement->Typerecette_17) && $encaissement->Typerecette_17 == 'IPRIER')
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_cdi_iprier', $this->data);
                        }
                        elseif($encaissement->Beneficaire_15 == "DGDA")
                        {
                                $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_attestation_dgda', $this->data);
                        }
                        
                        #$html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        if($arg !="" && $arg =="payment_order")
                        {
                                $this->mpdf->Output($pdfFilePath, "F");
                                return $pdfFilePath;
                        }

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj=="go_pass")
                {       
                        $encaissement = $this->encaissementModel->get_paiement_info($id);
                        $this->data['national_airline'] = $this->encaissementModel->national_airline;
                        $this->data['international_airline'] = $this->encaissementModel->international_airline;

                        $this->data['types'] = $type = $this->encaissementModel->types_vol;
                        $this->data['airports'] = $airport = $this->encaissementModel->get_dropdown("airport");

                        $this->data['encaissement'] = $encaissement;
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }

                        $data['Product'] = "Go-Pass";
                        $data['Reference'] = $encaissement->Reference_19;
                        $data['Amount'] = $encaissement->Amount_10." USD";
                        $data['Name'] = $encaissement->Designation_8;
                        $data['Airport_depart'] = isset($type[$encaissement->Departure_15]) ? $type[$encaissement->Departure_15] : "";
                        $data['Airport_dest'] = isset($airport[$encaissement->Destination_16]) ? $airport[$encaissement->Destination_16] : "";
                        $data['Company'] = isset($company[$type[$encaissement->Type_12]][$encaissement->Company_14]) ? $company[$type[$encaissement->Type_12]][$encaissement->Company_14] : "";
                        $data['NumberVol'] = $encaissement->Numero_13;
                        $data['Date'] = $encaissement->Date_1;
                        $data['Key'] = 'iK_s2bos';  
                        
                        $encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");

                        $params['data'] = $encrypted;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".'gopass.png';
                        //$ciqrcode = $this->ciqrcode->generate($params);
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_go_pass', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj=="toll")
                {     
                        $encaissement = $this->encaissementModel->get_paiement_info($id);
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');


                        $this->data['products'] = $products ;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['product_info'] = $this->productsModel->get_product_info($encaissement->Type_12);
                        
                        $this->data['provinces'] = $provinces;

                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }

                        $data['Product'] = "Peage";
                        $data['Reference'] = $encaissement->Reference_19;
                        $data['Amount'] = $encaissement->Amount_10." USD";
                        #$data['Driver'] = $encaissement->Designation_8;
                        #$data['weight'] = $encaissement->Weight_28;
                        #$data['Provenance'] = isset($provinces[$encaissement->Departure_15]) ? $provinces[$encaissement->Departure_15] : "";
                        #$data['Provenance'] = $encaissement->Departure_15;
                        #$data['Departure'] = $encaissement->Departure_15;
                        #$data['Destination'] = $encaissement->Destination_16;
                        #$data['Category'] = $encaissement->Type_12;
                        #$data['CategoryName'] = isset($products[$encaissement->Type_12]) ? $products[$encaissement->Type_12] : "";
                        #$data['NumberPlaque'] = $encaissement->Numero_13;
                        #$data['Date'] = $encaissement->Date_1;
                        $data['Key'] = 'iK_s2bos';
                        
                        #$encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");
                        
                        #$encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");

                        $encrypted = Impression::encrypts('0123456789abcdef', 'fedcba9876543210', json_encode($data));
                        #$encrypted = Impression::encrypts('0123456789abcdef', 'fedcba9876543210', 'Hello World!!!!');
                        
                        $params['data'] = $encrypted;
                        #$params['data'] = json_encode($data);
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".'gopass.png';
                        //$this->ciqrcode->generate($params);
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_toll', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
                        
                }
                elseif($obj=="batch_ticket")
                {       
                        $batch_ids = sprintf("'%s'", implode("','", $_SESSION['batch_ids']));
                        
                        $encaissements = $this->encaissementModel->get_batch_tickets_by_id($batch_ids);
                        
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');

                        $this->data['products'] = $products ;
                        $this->data['encaissements'] = $encaissements;
                        $this->data['provinces'] = $provinces;
                        
                        $this->data['events'] = $events = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $tickets= $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        
                        $qrcode = array();
                        
                        foreach($encaissements as $encaissement)
                        {
                                $data['Product'] = "Ticket";
                                $data['Reference'] = $encaissement->Reference_19;
                                $data['Amount'] = $encaissement->Amount_10." ".$encaissement->Devise_11;
                                $data['Ticket'] = isset($tickets[$encaissement->Ticket_24]) ? $tickets[$encaissement->Ticket_24] : "";
                                $data['Event'] = isset($events[$encaissement->Event_23]) ? $events[$encaissement->Event_23] : "";
                                $data['Date'] = $encaissement->Date_1;
                                $data['Client'] = isset($events[$encaissement->Designation_8]) ? $events[$encaissement->Designation_8] : "";
                                $data['Key'] = 'iK_s2bos';

                                $encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");

                                $params['data'] = $encrypted;
                                $params['level'] = 'H';
                                $params['size'] = '4';
                                $qrcode[$encaissement->Id_0] = $params['savename'] = $dir."/".'gopass.png';
                                //$this->ciqrcode->generate($params);
                        }
                        $this->data['qrcode'] = $qrcode;
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_ticket_batch', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";	
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;
                        
                }
                elseif($obj=="ticket")
                {       
                        $encaissement = $this->encaissementModel->get_paiement_info($id);
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');

                        $this->data['products'] = $products ;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['provinces'] = $provinces;
                        
                        $this->data['events'] = $events = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $tickets= $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }

                        $data['Product'] = "EVENT";
                        $data['Reference'] = $encaissement->Reference_19;
                        $data['Amount'] = $encaissement->Amount_10;
                        $data['Currency'] = $encaissement->Devise_11;

                        #$data['Ticket'] = isset($tickets[$encaissement->Ticket_24]) ? $tickets[$encaissement->Ticket_24] : "";
                        #$data['Event'] = isset($events[$encaissement->Event_23]) ? $events[$encaissement->Event_23] : "";
                        #$data['Date'] = $encaissement->Date_1;
                        #$data['Client'] = isset($events[$encaissement->Designation_8]) ? $events[$encaissement->Designation_8] : "";
                        $data['Key'] = 'iK_s2bos';
                        
                        #$encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");
                        $encrypted = Impression::encrypts('0123456789abcdef', 'fedcba9876543210', json_encode($data));
                        
                        $params['data'] = $encrypted;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".'gopass.png';
                        //$this->ciqrcode->generate($params);
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_ticket', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $path = "./drive/sbbos/".$account_id;
                        
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $pdfFilePath = $path."/".$id."_".$user_id."_".time().".pdf";
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        $this->mpdf->Output($pdfFilePath, 'I');

                        exit;

                }
                elseif($obj == "email")
                {
                        $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        $email_address = $paiement->Email_31;
                        $account = $this->session->userdata['account_id'];
                        $customer = $paiement->Designation_8;
                        
                        if($arg == 'single')
                        {
                                $file = $this->display('ticket_mail', $id);
                        }
                        else
                        {
                                $file = $this->display('batch_ticket_mail', $id);
                        }
                        
                        $return = $this->mail->send_mail($email_address, 'Paiement PEAGE', '', 'glodi.kasongo@ikwook.cd', $customer, $bcc = false, $file, $cc = null);
                        
                        if($return)
                        {
                                echo 1;
                        }
                        else
                        {
                                echo 0;
                        }
                }
                elseif($obj == "email_toll")
                {
                        $paiement = $this->encaissementModel->get_paiement_info($id);
                        
                        $email_address = $paiement->Email_31;
                        $account = $this->session->userdata['account_id'];
                        $customer = $paiement->Designation_8;
                        
                        $file = $this->display('toll_mail', $id);
                        
                        $return = $this->mail->send_mail($email_address, 'Ticket confirmation PEAGE', '', 'glodi.kasongo@ikwook.cd', $customer, $bcc = false, $file, $cc = null);
                        
                        if($return)
                        {
                                echo 1;
                        }
                        else
                        {
                                echo 0;
                        }
                }
                elseif($obj=="ticket_mail")
                {
                        $encaissement = $this->encaissementModel->get_paiement_info($id);
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');

                        $this->data['products'] = $products ;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['provinces'] = $provinces;
                        
                        $this->data['events'] = $events = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $tickets= $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }

                        $data['Product'] = "Ticket";
                        $data['Reference'] = $encaissement->Reference_19;
                        $data['Amount'] = $encaissement->Amount_10." ".$encaissement->Devise_11;
                        $data['Ticket'] = isset($tickets[$encaissement->Ticket_24]) ? $tickets[$encaissement->Ticket_24] : "";
                        $data['Event'] = isset($events[$encaissement->Event_23]) ? $events[$encaissement->Event_23] : "";
                        $data['Date'] = $encaissement->Date_1;
                        $data['Client'] = isset($events[$encaissement->Designation_8]) ? $events[$encaissement->Designation_8] : "";
                        $data['Key'] = 'iK_s2bos';
                        
                        $encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");
                        
                        $params['data'] = $encrypted;
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".'gopass.png';
                        //$this->ciqrcode->generate($params);
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_ticket', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $path = "./drive/sbbos/".$account_id;
                        
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $pdfFilePath = $path."/".$id."_".$user_id."_".time().".pdf";
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        return $pdfFilePath;
                        
                }
                elseif($obj=="batch_ticket_mail")
                {       
                        $batch_ids = sprintf("'%s'", implode("','", $_SESSION['batch_ids']));
                        
                        $encaissements = $this->encaissementModel->get_batch_tickets_by_id($batch_ids);
                        
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');

                        $this->data['products'] = $products ;
                        $this->data['encaissements'] = $encaissements;
                        $this->data['provinces'] = $provinces;
                        
                        $this->data['events'] = $events = $this->eventsModel->get_dropdown("event");
                        $this->data['tickets'] = $tickets= $this->ticketsModel->get_dropdown('tickets', 'ALL');
                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }
                        
                        $qrcode = array();
                        
                        foreach($encaissements as $encaissement)
                        {
                                $data['Product'] = "Ticket";
                                $data['Reference'] = $encaissement->Reference_19;
                                $data['Amount'] = $encaissement->Amount_10." ".$encaissement->Devise_11;
                                $data['Ticket'] = isset($tickets[$encaissement->Ticket_24]) ? $tickets[$encaissement->Ticket_24] : "";
                                $data['Event'] = isset($events[$encaissement->Event_23]) ? $events[$encaissement->Event_23] : "";
                                $data['Date'] = $encaissement->Date_1;
                                $data['Client'] = isset($events[$encaissement->Designation_8]) ? $events[$encaissement->Designation_8] : "";
                                $data['Key'] = 'iK_s2bos';

                                $encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");

                                $params['data'] = $encrypted;
                                $params['level'] = 'H';
                                $params['size'] = '4';
                                $qrcode[$encaissement->Id_0] = $params['savename'] = $dir."/".'gopass.png';
                                //$this->ciqrcode->generate($params);
                        }
                        $this->data['qrcode'] = $qrcode;
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_ticket_batch', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];		
                        $path = "./drive/sbbos/".$account_id;
                        
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $pdfFilePath = $path."/".$id."_".$user_id."_".time().".pdf";
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        return $pdfFilePath;
                        
                }
                elseif($obj=="toll_mail")
                {       
                        $encaissement = $this->encaissementModel->get_paiement_info($id);
                        $products = $this->productsModel->get_dropdown("products");
                        $provinces = $this->logirefModel->get_dropdown("parameters",'PROVINCE');

                        $this->data['products'] = $products ;
                        $this->data['encaissement'] = $encaissement;
                        $this->data['product_info'] = $this->productsModel->get_product_info($encaissement->Type_12);
                        
                        $this->data['provinces'] = $provinces;

                        //creation de qrcode
                        $dir = "./drive/logiref/". $this->session->userdata['account_id']."/".date('Y-m')."/qrcode/". $this->session->userdata['user_id']."/go-pass";
                        if(is_dir($dir)==false)
                        {
                                mkdir($dir,0777,true);
                        }

                        $data['Product'] = "Peage";
                        $data['Reference'] = $encaissement->Reference_19;
                        #$data['Amount'] = $encaissement->Amount_10." USD";
                        #$data['Driver'] = $encaissement->Designation_8;
                        #$data['weight'] = $encaissement->Weight_28;
                        #$data['Provenance'] = isset($provinces[$encaissement->Departure_15]) ? $provinces[$encaissement->Departure_15] : "";
                        #$data['Provenance'] = $encaissement->Departure_15;
                        #$data['Departure'] = $encaissement->Departure_15;
                        #$data['Destination'] = $encaissement->Destination_16;
                        #$data['Category'] = $encaissement->Type_12;
                        #$data['CategoryName'] = isset($products[$encaissement->Type_12]) ? $products[$encaissement->Type_12] : "";
                        #$data['NumberPlaque'] = $encaissement->Numero_13;
                        #$data['Date'] = $encaissement->Date_1;
                        $data['Key'] = 'iK_s2bos';
                        
                        #$encrypted = Impression::encryptBase64(json_encode($data), "s+FZFDjBKMUVDpu=");

                        $encrypted = Impression::encrypts('0123456789abcdef', 'fedcba9876543210', json_encode($data));
                        
                        $params['data'] = $encrypted;
                        #$params['data'] = json_encode($data);
                        $params['level'] = 'H';
                        $params['size'] = '4';
                        $this->data['qrcode'] = $params['savename'] = $dir."/".'gopass.png';
                        //$this->ciqrcode->generate($params);
                        
                        $html = view('\Modules\Etoll\Views\\'.$this->folder.'\_toll_mail', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];	
                        
                        $path = "./drive/sbbos/peage/".$account_id;
                        
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $pdfFilePath = $path."/".$id."_".$user_id."_".time().".pdf";
                        
                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        $this->mpdf->Output($pdfFilePath, "F");
                        return $pdfFilePath;

                }
                elseif($obj=="print_gopass") 
                {
                        
                        $this->data['airport'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['types'] = $this->encaissementModel->types_vol;
                        $this->data['company'] = $this->encaissementModel->airline_company;
                        
                        if(isset($_POST['paiement']) && $_POST['paiement'] !="")
                        {
                                $this->data['paiement'] = json_decode($_POST['paiement']);
                        }
                        else
                        {
                                $this->data['paiement'] = array();
                        }

                        $html = view('\Modules\Etoll\Views\impression\_print_gopass', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');
                        
                        echo $pdfFilePath;

                }
                elseif($obj=="print_toll") 
                {
                        
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['paiement'] = $this->encaissementModel->get_paiements_toll();
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        
                        #$this->data['paiement'] = $this->encaissement_model->get_paiements_toll_filter($_POST);

                        if(isset($_POST['paiement']) && $_POST['paiement'] !="")
                        {
                                #$paiement = preg_replace("/'/", '’', $_POST['paiement']);
                                #var_dump(json_decode($_POST['paiement'], true)); die;

                                $this->data['paiement'] = json_decode($_POST['paiement'], true);
                        }
                        else
                        {
                                $this->data['paiement'] = array();
                        }

                        $html = view('\Modules\Etoll\Views\impression\_print_toll', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, 'I');
                    
                        echo $pdfFilePath;
                }
                elseif($obj=="print_toll_partners") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['taux'] = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        
                        if(isset($_SESSION['toll_partners']))
                        {
                                $this->data['paiement'] = $_SESSION['toll_partners'];
                        }
                        else
                        {
                                $this->data['paiement'] = $this->encaissementModel->get_paiement_toll_partners();
                        }
                        
                        $html = view('\Modules\Etoll\Views\impression\_print_toll_partners', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                        
                        unset($_SESSION['toll_partners']); 

                }
                elseif($obj=="print_tolls") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['taux'] = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        $this->data['cashbook'] = $this->cashbooksModel->get_dropdown("cashbook");
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        
                        if(!empty($_SESSION['print_toll_nverify']))
                        {
                                $this->data['paiement'] = $_SESSION['print_toll_nverify'];
                                
                        } 
                        else if ($_POST['paiement'] == 'nverify')
                        {
                                $this->data['paiement'] = $this->encaissementModel->get_paiements_toll_nverify();
                        }
                        
                        if(!empty($_SESSION['print_toll_verify']))
                        {
                                $this->data['paiement'] = $_SESSION['print_toll_verify'];
                        } 
                        else if ($_POST['paiement'] == 'verify')
                        {
                                $this->data['paiement'] = $this->encaissementModel->get_paiements_toll_verify();
                        }

                        $html = view('\Modules\Etoll\Views\impression\_print_tolls', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
                elseif($obj=="print_toll_reconciliation")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameters",'PROVINCE');
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport");
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['taux'] = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        $this->data['cashbook'] = $this->cashbooksModel->get_dropdown("cashbook");

                        if(isset($_SESSION['nverify']))
                        {
                                $this->data['paiement'] = $_SESSION['nverify'];
                        }
                        else if ($_POST['paiement'] == 'nverify')
                        {
                                $this->data['paiement'] = $this->encaissementModel->get_paiements_toll_nverify();
                        }

                        if(isset($_SESSION['verify']))
                        {
                                $this->data['paiement'] = $_SESSION['verify'];
                        }
                        else if ($_POST['paiement'] == 'verify')
                        {
                                $this->data['paiement'] = $this->encaissementModel->get_paiements_toll_verify();
                        }

                        $html = view('\Modules\Etoll\Views\impression\_prints_tolls', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string

                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;

                }

                elseif($obj=="print_regularize_tolls")
                {
                        
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['taux'] = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        
                        if (isset( $_SESSION['regularize_tolls'])):
                               $this->data['paiements'] = $_SESSION['regularize_tolls'];
                        else:
                                $this->data['paiements'] = $this->encaissementModel->get_paiements_toll_to_regularize();
                        endif;
                        
                        $html = view('\Modules\Etoll\impression/_print_regularize_tolls', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;

                }
                elseif($obj=="print_cancelled_paiement") 
                {
                        
                        $this->data['airports'] = $this->encaissementModel->get_dropdown("airport"); 
                        $this->data['products'] = $this->productsModel->get_dropdown("products");
                        $this->data['status'] = $this->encaissementModel->status_tolls;
                        $this->data['status_color'] = $this->encaissementModel->color_tolls;
                        $this->data['taux'] = isset($result['Dollar_4']) ? $result['Dollar_4'] : 2000;
                        
                        if (isset( $_SESSION['paiement_cancelling'])):
                               $this->data['paiements'] = $_SESSION['paiement_cancelling'];
                        else:
                                $this->data['paiements'] = $this->encaissementModel->get_paiements_toll_to_cancel();
                        endif;
                        
                        $html = view('\Modules\Etoll\impression\_print_cancelled_payments', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];

                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;
                }
                elseif($obj=="print_users")
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        
                        if(isset($_POST['members']) && $_POST['members'] !="")
                        {
                                $this->data['members'] = json_decode($_POST['members']);
                        }
                        else
                        {
                                $this->data['members'] = array();
                        }

                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);

                        $this->data['roles'] = $this->usersModel->role;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = view('\Modules\Etoll\Views\impression\_print_users', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;
                }

                elseif($obj=="print_client")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        
                        if(isset($_POST['encaissements']) && $_POST['encaissements'] !="")
                        {
                                $this->data['encaissements'] = json_decode($_POST['encaissements']);
                                
                        }
                        else 
                        {
                                $this->data['encaissements'] = array();
                        }
                        
                        $this->data['agences'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $html = view('\Modules\Etoll\Views\impression\_print_client', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
                elseif($obj=="print_gu_paiements_tresor")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = view('\Modules\impression\_print_gu_paiements_tresor', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;

                }
                elseif($obj=="print_gu_paiements_propres")
                {
                        
                        $this->data['encaissements'] = json_decode($_POST['paiements']);
                        $this->data['office'] = $_POST['Office'];
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = view('\Modules\Etoll\Views\impression\_print_gu_paiements_propres', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;

                }
                elseif($obj=="print_paiements_gu")
                {
                        $this->data['office'] = $_POST['Office'];
                        if(isset($_POST['paiements']) && $_POST['paiements'] !="")
                        {
                                
                                $bls = implode(',', $_POST['paiements']);
                                $this->data['bulletins'] = $this->integrationModel->get_bulletins_by_lot($bls);
                               
                                
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $html = $this->load->view('\Modules\Etoll\Views\impression\_print_paiements_gu', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;

                }
                elseif($obj=="print_bl")
                {
                        if(isset($_POST['bulletins']) && $_POST['bulletins'] !="")
                        {
                                $this->data['bulletins'] = json_decode($_POST['bulletins']);
                        }
                        else 
                        {
                                $this->data['bulletins'] = array();
                        }
                        $this->data['agences'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        $html = view('\Modules\Etoll\Views\impression\_print_bl', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }

                elseif($obj=="print_commissions")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");

                        if(isset($_POST['commissions']) && $_POST['commissions'] !="")
                        {
                                $p = $this->data['paiements'] = json_decode($_POST['commissions']);
                        }
                        else
                        {
                                $this->data['paiements'] = array();
                        }

                        $html = view('\Modules\Etoll\Views\impression\_print_commissions', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
              
                elseif($obj == "print_regles")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        if(isset($_POST['regles']) && $_POST['regles'] !="")
                        {
                                $this->data['regles'] = json_decode($_POST['regles']);
                        }
                        else
                        {
                                $this->data['regles'] = array();
                        }
                        
                        $html = view('\Modules\Etoll\Views\impression\_print_regles', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");

                        echo $pdfFilePath;
                }
                elseif($obj == "print_comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                       
                      
                        if(isset($_POST['comptes']) && $_POST['comptes'] !="")
                        {
                            
                                $this->data['comptes'] = json_decode($_POST['comptes']);
                                
                        }
                        else
                        {
                                $this->data['comptes'] = array();
                        }
                        $html = view('\Modules\Etoll\Views\impression\_print_comptes', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
                elseif($obj == "print_penalites")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                       
                        $this->data['encaissements'] = (isset($_POST['encaissements']) && $_POST['encaissements'] !="")? json_decode($_POST['encaissements']) : array();
                        $this->data['bulletins'] = (isset($_POST['bulletins']) && $_POST['bulletins'] !="")?json_decode($_POST['bulletins']) : array();
                        
                        $html = view('\Modules\Etoll\Views\impression\_print_penalites', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
                elseif($obj == "print_recettes")
                {
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchesModel->get_branches();
                        if(isset($_POST['data']) && $_POST['data'] !="")
                        {
                               $this->data['data'] = json_decode($_POST['data'], true);
                        }
                        else
                        {
                                $this->data['data'] = array();
                        }
                        
                        $html = view('\Modules\Etoll\Views\impression\_print_recettes', $this->data);
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        $pdfFilePath = "./drive/logiref/".$account_id."/".date('Y-m')."/rapports/";	
                        if(is_dir($pdfFilePath)==false)
                        {
                                mkdir($pdfFilePath,0777,true);
                        }
                        $pdfFilePath = $pdfFilePath.$user_id."_".time().".pdf";

                        $this->mpdf->AddPageByArray([
                                'margin-left' => 10,
                                'margin-right' => 10,
                        ]);
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);
    
                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        
                        $this->mpdf->Output($pdfFilePath, "F");
                        
                        echo $pdfFilePath;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
               if($obj == "number_letter")
               {
                   $value = $this->number_letter->converter($data, $arg);
                   
                   return $value;
               }
        }
        
        public static function encryptBase64($plaintext, $key) 
        {
		$data = Impression::encrypt($plaintext, $key);
		$data = base64_encode($data);
		#$data = bin2hex($data);
                return $data; 
	}
        
        private static function encrypt($plaintext, $key) 
        {
		return openssl_encrypt($plaintext, "aes-128-ecb", $key, OPENSSL_RAW_DATA); 
	}
        
        static function encrypts($key, $iv, $data) 
        {
            if (strlen($key) < Impression::$CIPHER_KEY_LEN) 
            {
                $key = str_pad("$key", Impression::$CIPHER_KEY_LEN, "0"); //0 pad to len 16
            } 
            else if (strlen($key) > Impression::$CIPHER_KEY_LEN) 
            {
                $key = substr($str, 0, Impression::$CIPHER_KEY_LEN); //truncate to 16 bytes
            }

            $encodedEncryptedData = base64_encode(openssl_encrypt($data, Impression::$OPENSSL_CIPHER_NAME, $key, OPENSSL_RAW_DATA, $iv));
            $encodedIV = base64_encode($iv);
            $encryptedPayload = $encodedEncryptedData.":".$encodedIV;

            return $encryptedPayload;

        }

}

/* End of file welcome.php  */
/* Location: /project/activities  */