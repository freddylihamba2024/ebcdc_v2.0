<?php 

namespace Modules\Etoll\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\PosModel;
use Modules\Etoll\Models\EncaissementModel;
use Modules\Etoll\Models\UsersModel;

class Pos extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('pos');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'etoll';
        public $folder = 'pos';
        public $role;
        public $mainModel;
        public $branchesModel;
        public $countersModel;
        public $caissesModel;
        public $posModel;
        public $encaissementModel;
        public $usersModel;
        public $logirefModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->mainModel = new MainModel();
                $this->branchesModel = new BranchesModel();
                $this->countersModel = new CountersModel();
                $this->caissesModel = new CaissesModel();
                $this->posModel = new PosModel();
                $this->encaissementModel = new EncaissementModel();
                $this->usersModel = new UsersModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'pos';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                
                if($this->session->get('Logiref_role') == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_etoll();
                }
                else           
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etoll($this->session->get('Logiref_role'));
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Etoll\Views\container';
		echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "pos")
                {
                        $this->data['pos'] = $this->posModel->get_pos();
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['users_pos'] = $this->usersModel->get_dropdown("users_pos");
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\pos', $this->data);
                }
                elseif($obj == "_pos") 
                {
                        $this->data['products'] = $this->posModel->products;
                        $this->data['pos'] = $this->posModel->get_pos_info($id);
                        $this->data['sales_points'] = $this->branchesModel->get_dropdown("guichets_events");
                        $this->data['agences'] = $this->countersModel->get_dropdown("guichets", NULL, "ALL");
                        
                        echo view('\Modules\Etoll\Views\\'.$this->folder.'\_pos', $this->data);
                }
                elseif($obj == "verify") 
                {
                        $pos = "";
                        
                        if ($arg == "imei")  $pos = $this->posModel->get_pos_imei_exists($id);
                        elseif ($arg == "serial") $pos = $this->posModel->get_pos_serial_exists($id);
                        elseif ($arg == "mac") $pos = $this->posModel->get_pos_mac_exists($id);
                        
                        $response['code'] = ($pos) ? 'ERR401' : '400';
                        echo json_encode($response);
                        die;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Etoll\Views\\'.$this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "pos")
                {
                        $data = $_POST;
                        
                        if($data['Mac_7']=='' || $data['Serial_9']=='' || $data['Name_10']=='' || $data['Imei_11']=='' || $data['Model_12']=='')
                        {
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        }
                        
                        if (isset($data['Type_13']) && $data['Type_13'] == '2')
                        {
                                $data['Guichet_8'] = $data['Guichet_toll'];
                        }
                        elseif (isset($data['Type_13']) && $data['Type_13'] == '3')
                        {
                                $data['Guichet_8'] = $data['Guichet_ticket'];

                        }
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];

                                
                                //checks if the code entered has already been used 
                                $pos_mac_exist = $this->posModel->get_pos_mac_exists($data['Mac_7']);
                                $pos_imei_exist = $this->posModel->get_pos_imei_exists($data['Imei_11']);
                                $pos_serial_exist = $this->posModel->get_pos_serial_exists($data['Serial_9']);

                                if(!empty($pos_mac_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; l\'adresse mac cr&eacute;e avec un autre pos !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                                
                                if(!empty($pos_imei_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; le numéro imei cr&eacute;e avec un autre pos !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                                
                                if(!empty($pos_serial_exist))
                                {
                                        echo '<div class="alert alert-danger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; le numéro série cr&eacute;e avec un autre pos !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                
                        }
                        
                        unset($data['Guichet_ticket']);
                        unset($data['Guichet_toll']);
                        
                        #Database
                        $cid = $this->posModel->save_pos($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! pos enregistr&eacute; avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
