<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class PosModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $products = array(
            '0' => '',
            '1' => 'Go-Pass',
            '2' => 'Péage',
            '3' => 'Ticket'
        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_pos_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Mac_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Serial_9 = '';
                        $obj->Name_10 = '';
                        $obj->Imei_11 = '';
                        $obj->Model_12 = '';
                        $obj->Type_13 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_pos g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="beneficiaries")
                {
                        $type = $arg;
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        if($type != NULL)
                        {
                                $st .= " AND Type_4='" . $type . "'";
                        }
                        else
                        {
                                $ddmenu['BKC'][''] = ''; // Banque commerciale
                                $ddmenu['RGF'][''] = ''; // Regies
                                $ddmenu['AIP'][''] = ''; // Autres Institutions Publiques
                        }
                        $query = $this->db->table('logiref_beneficiaries')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $i=0;
                        foreach ($query->getResultArray() as $row) 
                        {
                                if($i==0 && $type=='RGF') $ddmenu['RGF'][''] = '';
                                $ddmenu[$row['Type_4']][$row['Code_7']] = $row['Description_5']." (".$row['Code_7'].")";
                        }
                        $i++;
                        
                        return $ddmenu;
                }
                elseif($item=="pos")
                {
                        $type = $arg;
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        
                        if (isset($type) && $type != "") $where = " Guichet_8='".$type."' ";
                        
                        $query = $this->db->table('logiref_sbbos_pos')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = "";
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_10'] ." ". $row['Model_12']. " ". substr($row['Serial_9'], -7);
                        }
                        return $ddmenu;
                }
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $query = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_pos($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_sbbos_pos')
                        ->select('logiref_sbbos_pos.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        #Checks if the book has already been created with the entered account
        public function get_pos_mac_exists($mac = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_pos ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Mac_7'=>$mac), TRUE);
        }
        
        public function get_pos_imei_exists($imei = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_pos ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Imei_11'=>$imei), TRUE);
        }
        
        public function get_pos_serial_exists($serial = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_pos ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Serial_9'=>$serial), TRUE);
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_pos($data, $id) {
                $this->set_table('logiref_sbbos_pos', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
}