<?php

namespace Modules\Etoll\Models;

use App\Libraries\Curl;
use stdClass;
use App\Models\MY_Etoll;

class CurlModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
                $this->curl = new Curl();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        
        //BANK
        public function call_bank_comptant($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/sbbos/comptant.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_virement($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/sbbos/virement.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_illico_payment($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        /*public function call_bank_mpgs_payment($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/mpgs/auth.initiate.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}*/
        
        //BANK
        public function call_bank_illico_confirmation($data)
	{
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.validate.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_checkbalance($data)
	{
                $response = '';
                $url = base_url('api/endpoints/bank/rawbank/sbbos/check.balance.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_account_info($data)
	{
                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/rawbank/sbbos/account.info.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
	}
        
        //BANK
        public function call_bank_regularization($data)
        {
                
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/sbbos/regularize.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        //BANK
        public function call_bank_reversepayment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/sbbos/extourne.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        //BANK
        public function call_bank_verification($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/sbbos/account.event.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        // Illicocash
        
        public function call_illicocash_make_payment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        
        //Illicocash
        
        public function call_illicocash_confirm_payment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.validate.php');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }
        
        
}