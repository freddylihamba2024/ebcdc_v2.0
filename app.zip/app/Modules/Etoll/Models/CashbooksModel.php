<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class CashbooksModel extends MY_Etoll {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        
        
        public function get_cashbook_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        
                        $obj->Beginning_7 = '';
                        $obj->End_8 = '';
                        $obj->Agence_9 = '';
                        $obj->Tickets_10 = '';
                        $obj->Guichet_11 = '';
                        $obj->User_12 = '';
                        $obj->Reference_13 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_cashbooks c', 'p.Id_0', 'c.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_airport_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        
                        $obj->Name_7 = '';
                        $obj->Price_8 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_airport c', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="cashbooks")
                {   
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_cashbooks')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="cashbook")
                {   
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_cashbooks')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Reference_13'];
                        }
                        return $ddmenu;
                }
                
        }
        
        
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_cashbooks($profile = NULL)
        {
                $agence = $this->session->get('Logiref_guichet');
                $counter = $this->session->get('Logiref_branch');
                
                if($this->session->get('Logiref_role') < '3')
                {
                        $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' ";
                }
                else
                {
                        $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' AND  Guichet_11 = '".$counter."' ";
                }
                
                $builder = $this->db->table('logiref_sbbos_cashbooks')
                        ->select('logiref_sbbos_cashbooks.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_cashbook_to_sell()
        {
                $counter = $this->session->get('Logiref_branch');
                
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' AND  Guichet_11 = '".$counter."' AND Quantity_14 > 0 ";
                $builder = $this->db->table('logiref_sbbos_cashbooks')
                        ->select('logiref_sbbos_cashbooks.*')
                        ->where($st)
                        ->limit(1)
                        ->orderBy('Id_0','ASC')
                        ->get();
                $result = $builder->getResult();
                
                if(!empty($result))
                {
                        $result = current($result);
                }
                
                return $result;
        }
        
        
        public function get_movements_gucihet()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $day = gmdate('Y-m-d');
                $agence = $this->session->get('Logiref_guichet');
                
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Date_1 LIKE '%" . $day. "%' AND Agence_13 ='" . $agence. "'";
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                
                $results = $query->getResultArray();
                
                return $results;
        }
      
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_cashbook($data, $id) {
                $this->set_table('logiref_sbbos_cashbooks', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function update_ticket_number($data, $id) {
                $builder = $this->db->table('logiref_sbbos_cashbooks')
                        ->update($data, $id);
                return $builder;
        }
        
}