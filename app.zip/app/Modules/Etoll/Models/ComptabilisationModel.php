<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class ComptabilisationModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
       
	
	public function __construct()
	{
		parent::__construct();
	}
        
        public $months = array
                        (
                            '00' => '',
                            '01' => 'Janvier',
                            '02' => 'Fevrier',
                            '03' => 'Mars',
                            '04' => 'Avril',
                            '05' => 'Mai',
                            '06' => 'Juin',
                            '07' => 'Juillet',
                            '08' => 'Aout',
                            '09' => 'Septembre',
                            '10' => 'Octobre',
                            '11' => 'Novembre',
                            '12' => 'Decembre'
                        );
        
        public $months_abrv = array
                        (
                            '00' => '',
                            '01' => 'Jan',
                            '02' => 'Feb',
                            '03' => 'Mar',
                            '04' => 'Apr',
                            '05' => 'May',
                            '06' => 'Ju',
                            '07' => 'Jly',
                            '08' => 'Aug',
                            '09' => 'Sep',
                            '10' => 'Oct',
                            '11' => 'Nov',
                            '12' => 'Dec'
                        );
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions($ref) 
        {
                $st = " Paiementid_7='" . $ref . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_sbbos_instructions')
                        ->select('logiref_sbbos_instructions.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        public function get_instructions_by_id($ref) 
        {
                $st = " Reference_15='" . $ref . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_sbbos_instructions')
                        ->select('logiref_sbbos_instructions.*')
                        ->where($st)
                        ->orderBy('logiref_sbbos_instructions.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        public function get_closing_instructions() 
        {
                $st = " Status_2 = 2 AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Counter_17='" . $this->session->get('Logiref_branch') . "'";
                $builder = $this->db->table('logiref_sbbos_instructions')
                        ->select('logiref_sbbos_instructions.*')
                        ->where($st)
                        ->orderBy('logiref_sbbos_instructions.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Instruction de comptabilisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_bank_fees($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CSE']['CDF']) ? $comptes[$bank_code]['CSE']['CDF'] : '000000000000000000000000'; 
                $libelle = gmdate('d-m-Y').' Vente ticket '.$data['event'];
                
                
                $instruction = array(
                                        'Operation_9'=>'V', 
                                        'Compte_10'=>$data['compte'], 
                                        'Libelle_13'=>$libelle, 
                                        'Montant_11'=>$data['montant'], 
                                        'Devise_12'=>$data['devise'],
                                        'Compte_14'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_instructions_bank_fees_toll($data, $comptes)
        {
                $instructions = array();
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                
                $compte_cfb = isset($comptes['Peage']['CSP'][$data['devise']]) ? $comptes['Peage']['CSP'][$data['devise']] : '000000000000000000000000'; 
                $libelle = gmdate('d-m-Y').' ventes peages '.$data['tarif'];
                
                if($data['devise'] == 'CDF')
		{
                    $data['compte'] = '65101-00999997064-20';
		}
		else
		{
                    $data['compte'] = '65101-00999997065-17';
		}

		if($data['devise'] == 'CDF')
		{
                    $compte_cfb = '05121-01005296603-19';
		}
		else
		{
                    $compte_cfb = '05121-01005296604-16';
		}
                
                $instruction = array(
                                        'Operation_9'=>'V', 
                                        'Compte_10'=>$data['compte'], 
                                        'Libelle_13'=>$libelle, 
                                        'Montant_11'=>$data['montant'], 
                                        'Devise_12'=>$data['devise'],
                                        'Compte_14'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        public function get_instructions_closing($data, $comptes, $counters)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                
                $tool_branch = isset($counters[$_SESSION['Logiref_branch']]) ? $counters[$_SESSION['Logiref_branch']] : "";
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_dst = isset($comptes['SECOPE']['CPI']['CDF']) ? $comptes['SECOPE']['CPI']['CDF'] : '000000000000000000000000'; 
                $libelle = ''. gmdate('d-m-Y').' Nivellement des paiements de p&eacute;age '.$tool_branch;
                
                
                $instruction = array(
                                        'Operation_9'=>'V', 
                                        'Compte_10'=>$data['Compte_10'], 
                                        'Libelle_13'=>$libelle, 
                                        'Montant_11'=>$data['Montant_7'], 
                                        'Devise_12'=>$data['Devise_8'],
                                        'Compte_14'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_instructions_partners_fees_toll($data, $comptes, $beneficiaire)
        {
                $instructions = array();
                
                $bank_code = 'Rawbank';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte = isset($comptes[$bank_code]['CSO']['CDF']) ? $comptes[$bank_code]['CSO']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Quote-part '.$beneficiaire.' '.$data['tarif'];
              
                $instruction = array(
                                        'Operation_9'=>'V', 
                                        'Compte_10'=>$data['compte'], 
                                        'Libelle_13'=>$libelle, 
                                        'Montant_11'=>$data['montant'], 
                                        'Devise_12'=>$data['devise'],
                                        'Compte_14'=>$compte
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        public function get_instructions_partners_fees($data, $comptes, $beneficiaire)
        {
                $instructions = array();
                
                $bank_code = 'Rawbank';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte = isset($comptes[$bank_code]['CSO']['CDF']) ? $comptes[$bank_code]['CSO']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Quote-part '.$beneficiaire.' '.$data['event'];
                
                
                if(isset($data['Mode_29']) && $data['Mode_29'] =="5")
                {
                        $instruction = array(
                                                'Operation_9'=>'Deposit', 
                                                'Libelle_13'=>$libelle, 
                                                'Montant_11'=>$data['montant'], 
                                                'Devise_12'=>$data['devise'],
                                                'Compte_14'=>$compte
                                            );
                        $instructions[] = $instruction;
                }
                else 
                {
                        $instruction = array(
                                                'Operation_9'=>'V', 
                                                'Compte_10'=>$data['compte'], 
                                                'Libelle_13'=>$libelle, 
                                                'Montant_11'=>$data['montant'], 
                                                'Devise_12'=>$data['devise'],
                                                'Compte_14'=>$compte
                                            );
                        $instructions[] = $instruction;
                }
                return $instructions;
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Cles de repartition
         * *************************************************************************************************************************SCETION 2
        */
        
        //Guichet Unique en douane
        public function get_instructions_gu_dgda($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]) && ($data['Typerecette_17'] =='AT3' || $data['Typerecette_17'] =='AT4'))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']];
                        
                        if($data['Typerecette_17']=='AT3' || $data['Typerecette_17']=='AT4')
                        {
                                # Le type de la recette c'est AT3, AT4 mais le service n'est pas defini.
                                $compte_dst = isset($compte_dst['']) ? $compte_dst[''] : $compte_sus;
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'B'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                
                if($compte_dst == $compte_sus)
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst,
                                                'Details_23'=>'Nouvelle taxe'
                                            );
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_cgu,
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                }
                
                return $instruction;
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function save_instructions_closing($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                $data['Status_2']=1;
                                
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_7']= $pid;
                                $data['Guichet_8']= $_SESSION['Logiref_guichet'];
                                $data['Mode_16']= '7';
                                $data['Creator_4']= $this->session->userdata['user_id'];
                                $data['Reference_15']= $logirefid;
                                $data['Counter_17']= $this->session->get('Logiref_branch');
                                
                                $this->set_table('logiref_sbbos_instructions', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        public function save_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL, $type=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                
                                $data['Status_2']=1;
                                
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_7']= $pid;
                                $data['Guichet_8']= $this->session->get('Logiref_guichet');
                                $data['Mode_16']= $paiement['Mode_29'];
                                $data['Creator_4']= $this->session->userdata['user_id'];
                                $data['Reference_15']= $paiement['Refpaiement_22'];
                                $data['Counter_17']= $this->session->get('Logiref_branch');
                                
                                $this->set_table('logiref_sbbos_instructions', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }
        public function update_instructions_cbs($ids, $data)
        {
                $builder = $this->db->table('logiref_sbbos_instructions')
                        ->where("logiref_sbbos_instructions.Id_0 IN (".$ids.")")
                        ->update($data);
                return $builder;
                
        }
        public function delete_instructions($id)
	{
		$builder = $this->db->table('logiref_sbbos_instructions')
                        ->where('Reference_15', $id)
                        ->delete();
                return $builder;
	}
        public function delete_instructions_batch($id)
	{
		$builder = $this->db->table('logiref_sbbos_instructions')
                        ->where('Reference_15', $id)
                        ->delete();
                return $builder;
	}
}