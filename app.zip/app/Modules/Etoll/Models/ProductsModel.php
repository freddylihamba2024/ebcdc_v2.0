<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class ProductsModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $type_product = array(
                            ''=>'', 
                            '1' => 'Go-pass', 
                            '2' => 'P&eacute;age'
                        );
        
        public $type_trajet = array(
                            ''=>'', 
                            '1' => 'Long-trajet', 
                            '2' => 'Demi-trajet'
                        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_product_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Name_7='';
                        $obj->Description_8 ='';
                        $obj->Price_9 ='';
                        $obj->Currency_10 ='';
                        $obj->Agence_11 ='';
                        $obj->Guichet_12 ='';
                        $obj->Type_13 ='';
                        $obj->Additional_14 ='';
                        $obj->Weight_15 ='';
                        $obj->Trajet_16 ='';
                        $obj->Departure_17 ='';
                        $obj->Destination_18 ='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_sbbos_products', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_weight_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Tarif_7='';
                        $obj->Min_8 ='';
                        $obj->Max_9 ='';
                        $obj->Amount_10 ='';
                        $obj->Currency_11 ='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_sbbos_weights_range', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="product_gopass")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0' AND Type_13 = '1' ";
                        $query = $this->db->table('logiref_sbbos_products')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                            
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="product_toll")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 ='2' AND Type_13 = '2' AND Guichet_12 = ".$this->session->get('Logiref_branch')." ";
                        $query = $this->db->table('logiref_sbbos_products')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                            
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="product_weight")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 ='2' AND Type_13 = '2' AND Weight_15 = '1' ";
                        $query = $this->db->table('logiref_sbbos_products')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                            
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="products")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 ='2'";
                        $query = $this->db->table('logiref_sbbos_products')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                            
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_products($type=NULL)
        {
                $st = "Status_2 <> '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_sbbos_products')
                        ->select('logiref_sbbos_products.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_last_product($type=NULL)
        {
                $st = " (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_sbbos_products')
                        ->select('Id_0','ASC')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit('1')
                        ->get();
                
                $result = $builder->getResult();
                
                if(isset($result[0]->Id_0))
                {
                        return $result[0]->Id_0;
                }
                else
                {
                        return 0;
                }
        }
        
        public function get_weights($type=NULL)
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_sbbos_weights_range')
                        ->select('logiref_sbbos_weights_range.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_weights_by_parameters($data=NULL)
        {   
                $st = "Status_2='1' AND  Min_8='" . $data['Min_8'] . "' AND Max_9='" . $data['Max_9'] . "' AND Tarif_7='" . $data['Tarif_7'] . "' ";
                $builder = $this->db->table('logiref_sbbos_weights_range')
                        ->select('logiref_sbbos_weights_range.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_weights_by_branch($account=NULL)
        {
                if($account != "")
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" .$account. "')";
                        $builder = $this->db->table('logiref_sbbos_weights_range')
                                ->select('logiref_sbbos_weights_range.*')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
                else 
                {
                        $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Guichet_13='" .$_SESSION['Logiref_branch']. "'";
                        $builder = $this->db->table('logiref_sbbos_weights_range')
                                ->select('logiref_sbbos_weights_range.*')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
        }
        
        public function get_weight_range($data) 
        {
                $weight = 0;
                $currency = '';
                $account = $this->session->userdata['account_id'];
                $where = "(Account_3='0' OR Account_3='" . $account . "') AND Tarif_7 = '".$data['tarif']."' ";
                $query = $this->db->table('logiref_sbbos_weights_range')
                        ->where($where)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                $ddmenu = array();

                foreach ($query->getResultArray() as $row)
                {
                        if($row['Min_8'] <= $data['weight'] && $row['Max_9'] >= $data['weight'])
                        {
                                $weight = $row['Amount_10'];
                                $currency = $row['Currency_11'];
                                
                                break;
                        }
                }
                $ddmenu = array('weight' =>$weight, 'currency'=>$currency);
               
                return $ddmenu;
                
        }
        
        public function get_products_by_branch($account_id = NULL, $guichet=NULL)
	{
                if($account_id != "")
                {
                        $builder = $this->db->table('logiref_sbbos_products')
                                ->select('logiref_sbbos_products.*')
                                ->where("logiref_sbbos_products.Account_3 ='".$account_id."'")
                                ->where("logiref_sbbos_products.Guichet_12 ='".$guichet."'")
                                ->orderBy('logiref_sbbos_products.Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $account_id=$this->session->userdata['account_id'];
                        $builder = $this->db->table('logiref_sbbos_products')
                                ->select('logiref_sbbos_products.*')
                                ->where("logiref_sbbos_products.Account_3 ='".$account_id."'")
                                ->where("logiref_sbbos_products.Guichet_12 ='".$guichet."'")
                                ->orderBy('logiref_sbbos_products.Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
	}
        
        
        public function update_product($data, $id)
	{
                $builder = $this->db->table('logiref_sbbos_products')
                        ->where("logiref_sbbos_products.Id_0 ='".$id."'")
                        ->update($data);
                return $builder;
	}
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_product($data, $id)
	{
		$this->set_table('logiref_sbbos_products', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_weights($data, $id)
	{
		$this->set_table('logiref_sbbos_weights_range', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function delete_weights_range($tarifid)
	{
		$builder = $this->db->table('logiref_sbbos_weights_range')
                        ->where('Tarif_7', $tarifid)
                        ->delete();
                return $builder;
	}
        
}

