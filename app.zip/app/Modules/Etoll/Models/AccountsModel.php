<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class AccountsModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Type_4 = '';
                        $obj->Beneficiaires_5 = '';
                        $obj->Compte_6 = '';
                        $obj->Clef_7 = '';
                        $obj->Devise_8 = '';
                        $obj->Makerid_9 = '';
                        $obj->Validation_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Recette_13 = '';
                        $obj->Regie_14 = '';
                        $obj->Agenceid_15= '';
                        $obj->Serviceid_16= '';
                        $obj->Nif_17	= '';
                        $obj->Comptesydonia_18	= '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_comptes p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_prepaid_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Nifimportateur_7 = '';
                        $obj->Accountnumber_8 = '';
                        $obj->Refsydonia_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Makerid_11 = '';
                        $obj->Checkerid_12 = '';
                        $obj->Validation_13 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_prepaid_accounts p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        
                        $query = $this->db->table('main_countries')
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $query = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id = $this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_latest_validated_accounts()
	{
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !='0'"; 
                $builder = $this->db->table('logiref_comptes')
                        ->select('logiref_comptes.*')
                        ->where($st)
                        ->orderBy('Date_1','ASC')
                        ->limit(20)
                        ->get();
                return $builder->getResult();
	}
        
        public function get_agence_accounts()
	{
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_12 = '".$guichet."'"; 
                $builder = $this->db->table('logiref_comptes')
                        ->select('logiref_comptes.*')
                        ->where($st)
                        ->orderBy('Date_1','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_comptes($type=NULL) 
        {
                if($type=='cptes')
                {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 ='0'"; 
                        $builder = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $st = "Status_2='1' AND Beneficiaires_5='" .$this->session->get('Logiref_regies'). "'"; 
                        $builder = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                }

        }
        
        public function get_filtered_accounts($data)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'"; 
                if(isset($data['type']) && $data['type'] !="") $st.= " AND Type_4 ='".$data['type']."'";
                if(isset($data['agence']) && $data['agence'] !="") $st.= " AND Agence_12 ='".$data['agence']."'";
                if(isset($data['taxe']) && $data['taxe'] !="") $st.= " AND Recette_13 ='".$data['taxe']."'";
                if(isset($data['devise']) && $data['devise']) $st.= " AND Devise_8 ='".$data['devise']."'";
                
                $builder = $this->db->table('logiref_comptes')
                        ->select('logiref_comptes.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        public function get_export_comptes()
        {
                $st = "Status_2 !='0' AND Account_3='" . $this->session->userdata['account_id'] . "'"; 
                $builder = $this->db->table('logiref_comptes')
                        ->select('logiref_comptes.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        #Recuperer la devise par rapport ? un compte
        public function get_comptes_by_parameters($compte = NULL, $devise = NULL, $type = NULL, $beneficiaire = NULL, $agence = NULL, $recette = NULL, $service = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                $array = array('Account_3'=>$account_id,'Type_4'=>$type,'Compte_6'=>$compte, 'Beneficiaires_5'=>$beneficiaire, 'Devise_8'=>$devise, 'Agence_12'=>$agence);
                if(isset($recette))$array["Recette_13"] = $recette;
                if(isset($service))$array["Serviceid_16"] = $service;
                
                return $this->get_by($array, TRUE);
        }
        
        public function get_compte_by_number($data=NULL) 
        {
                $account_id = $this->session->userdata['account_id'];
                
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Compte_6'=>$data,'Account_3' =>$account_id), TRUE);
        }
        
        public function get_comptes_inter_agence_array($liste='') 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ")"; 
                
                $query = $this->db->table('logiref_comptes')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_array($liste='', $agence_src=NULL, $agence_dst=NULL, $regie =NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $agence_src= ($this->session->has('Logiref_guichet')) ? $this->session->get('Logiref_guichet') : $agence_src;
                
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Agence_12 = ".$agence_src." AND Checkerid_11 <>'0'";
                
                $query = $this->db->table('logiref_comptes')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_agence_comptes_array($liste='', $agence) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                
                $query = $this->db->table('logiref_comptes')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_recettes_agence_array($liste='', $agence, $beneficiaire = NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0' ";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                if($beneficiaire != "") $st .= " AND Beneficiaires_5 ='".$beneficiaire."' ";
                
                $query = $this->db->table('logiref_comptes')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Recette_13'] == 'TVA' && $row['Beneficiaires_5'] == 'DGDA')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Recette_13'] == 'TVA' && $row['Beneficiaires_5'] == 'DGI')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Recette_13'] != 'TVA')
                        {
                                if($row['Agenceid_15']!="" && ($row['Recette_13'] == 'AT3' || $row['Recette_13'] == 'AT4'))
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];

                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                   
                }
                return $comptes;
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_prepaid_accounts($data, $id) {
                $this->set_table('logiref_prepaid_accounts', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_compte($data, $id)
        {
                $this->set_table('logiref_comptes', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}