<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class EncaissementModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $documents = array(
                            '1' => 'NOTE DE PERCEPTION', 
                            '2' => 'QUITTANCE',
                            '3' => 'BULLETIN DE LIQUIDATION', 
                            '4' => 'NOTE DE VERSEMENT', 
                            '5' => 'DECLARATION'
                        );
	public $devises = array(
                            ''=>'', 
                            'CDF' => 'CDF', 
//                            'USD' => 'USD', 
//                            'EUR' => 'EUR', 
//                            'ZAF' => 'ZAF'
                        );
        public $modes = array(
                            ''=>'', 
                            '5' => 'ESPECE', 
                            '7' => 'OP', 
                            '8' => 'OV',
                            '9' => 'CQ',
                            '10' => 'CM'
                        );
        
        public $sbbos_modes = array(
                    ''=>'', 
                    '5' => 'ESPECE', 
                    '8' => 'ILLICO CASH'
                );
        
        public $reversementStatus = array(
                                        '1' => 'Reverser', 
                                        '2' => 'Regler', 
                                        '3' => 'Niveller'
                                    );
        public $infos = array(
                            'type' => '', 
                            'agence' => '', 
                            'reference' => '', 
                            'moyen' => '', 
                            'standard' => '',
                            'QuotasINPP' => '', 
                            'QuotasINSS' => '', 
                            'QuotasONEM' => '', 
                            'RefINSS' => '', 
                            'RefINPP' => '', 
                            'RefONEM' => '', 
                        ); 
        public $moyens = array(
                            '' => '', 
                            '10' => 'Especes',
                            '20' => 'Cheque', 
                            '21' => 'Lettre bancaire',
                            '22' => 'Lettre bancaire certifiee', 
                            '23' => 'Cheque bancaire (issu par banque ou etablissement financier simil.)', 
                            '24' => 'Cheque particulier signe par la banque',
                            '50' => 'Ordre', 
                            '80' => 'Paiement partiel', 
                            '90' => 'Consentement mutuel',
                        );
	public $order_status = array(
            
                '1'=>"En cours",
                '2'=>"Valid&eacute; (pay&eacute;)",
                '3'=>"Finalis&eacute; (rejet&eacute;)",
                '4'=>"Expir&eacute;",
                ''=>""
        );
        public $color_orders = array(
                '1'=>'label-upcoming',
                '2'=>'label-ongoing',
                '3'=>'label-cancelled',
                '4'=>'label-ongoing',
        );
        
        public $color_tolls = array(
            '1' => 'label-cancelled',
            '2' => 'label-completed',
            '5' => 'label-upcoming',

        );
        
        public $status_tolls =  array(
            '1' => 'Non v&eacuterifi&eacute;',
            '2' => 'V&eacuterifi&eacute;',
            '5'=>'&agrave; r&eacute;gulariser'
        );
        
        public $types_vol = array(
            '0' => '', 
            '1' => 'NATIONAL',
            '2' => 'INTERNATIONAL', 
        );
        
        public $national_airline = array(
                '' => '',
                '1'=> "AIR KASAI",
                '2'=> "AIR TROPIQUES",
                '3'=> "COMPAGNIE AFRICAINE D'AVIATION",
                '4'=> "CONGO AIRWAYS"
        );
        
        public $international_airline = array(
                '' => '',
                '5'=> "AIR CÔTE D'IVOIRE",
                '6'=> "AIR FRANCE",
                '7'=> "BRUSSELS AIRLINES",
                '8'=> "ECAIR",
                '9'=> "ETHIOPIAN AIRLINES",
                '10'=> "KENYA AIRWAYS",
                '11'=> "RWAND'AIR",
                '12'=> "ROYAL AIR MAROC",
                '13'=> "SOUTH AFRICAN AIRWAYS",
                '14'=> "TURKISH AIRLINE",
        );
        public $airline_companies = array(
                '' => '',
                '1'=> "AIR KASAI",
                '2'=> "AIR TROPIQUES",
                '3'=> "COMPAGNIE AFRICAINE D'AVIATION",
                '4'=> "CONGO AIRWAYS",
                '5'=> "AIR CÔTE D'IVOIRE",
                '6'=> "AIR FRANCE",
                '7'=> "BRUSSELS AIRLINES",
                '8'=> "ECAIR",
                '9'=> "ETHIOPIAN AIRLINES",
                '10'=> "KENYA AIRWAYS",
                '11'=> "RWAND'AIR",
                '12'=> "ROYAL AIR MAROC",
                '13'=> "SOUTH AFRICAN AIRWAYS",
                '14'=> "TURKISH AIRLINE",
        );
        public $foreign_airport = array(
                '' => '',
                '100' => 'Etrangers'
        );
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_airport_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        
                        $obj->Name_7 = '';
                        $obj->Price_8 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_airport c', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        public function get_paiement_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        
                        $obj->Productid_7 = '';
                        $obj->Designation_8 = '';
                        $obj->Genrepassenger_9 = '';
                        $obj->Amount_10 = '';
                        $obj->Devise_11 = '';
                        $obj->Type_12 = '';
                        $obj->Numero_13 = '';
                        $obj->Company_14 = '';
                        $obj->Departure_15 = '';
                        $obj->Destination_16 = '';
                        $obj->Serial_17 = '';
                        $obj->Controller_18 = '';
                        $obj->Reference_19 = '';
                        $obj->Cashregister_20 = '';
                        $obj->Agence_21 = '';
                        $obj->Refpaiement_22 = '';
                        $obj->Event_23 = '';
                        $obj->Ticket_24 = '';
                        $obj->Partner_25 = '';
                        $obj->Branchid_26 = '';
                        $obj->Additional_27 = '';
                        $obj->Weight_28 = '';
                        $obj->Mode_29 = '';
                        $obj->Phone_30 = '';
                        $obj->Email_31 = '';
                        $obj->validation_32 = '';
                        $obj->Refbatch_33 = '';
                        $obj->Carnetid_34 = '';
                        $obj->Carnetnumber_35 = '';
                        $obj->Refcbs_38 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_paiements c', 'p.Id_0', 'c.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_stats($type=NULL)
        {
                if(isset($_SESSION['Bank_rates']))
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        $usd = $bank['Dollar_7'];
                        $eur = $bank['Euro_8'];
                   
                }
                if($type=='commission')
                {
                        $stats = array(

                                "1" => '0', //'Commission de l'annee,
                                "2" => '0', //'Commission du mois,
                                "3" => '0', //'Commission de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where('Account_3',$this->session->userdata['account_id'])
                                ->where('Agence_20',$_SESSION['Logiref_agence'])
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();


                        foreach ($query->getResultArray() as $row)
                        {
                                //$stats['1'] = $stats['1'] + $row['Commission_23'];

                                $dateTime = new \DateTime($row['Datevaleur_31']); $date= $dateTime->format('U'); 
                                $year = date('Y', strtotime("+0 day",$date));
                                $month = date('m', strtotime("+0 day",$date));

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Commission_23'];
                                        } 
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Commission_23'];
                                        }
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_24']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Commission_23']*$usd);
                                        }
                                        elseif($row['Devise_24']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Commission_23'];
                                        }
                                }


                        }
                        
                        return $stats;
                }
                elseif($type=='paiement')
                {
                        $$stats = array(

                                "1" => '0', //'Paiement de l'annee,
                                "2" => '0', //'Paiement du mois,
                                "3" => '0', //'Paiement de la journee,
                                "4" => '1', //'Aucun paiement,
                        );

                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where('Account_3',$this->session->userdata['account_id'])
                                ->where('Agence_20',$_SESSION['Logiref_agence'])
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();


                        foreach ($query->getResultArray() as $row)
                        {
                                $dateTime = new \DateTime($row['Datevaleur_31']); $date= $dateTime->format('U'); 
                                $year = date('Y', strtotime("+0 day",$date));
                                $month = date('m', strtotime("+0 day",$date));

                                if($year==gmdate('Y'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['1'] = $stats['1'] + $row['Montant_11'];
                                        }   
                                }
                                if($month==gmdate('m'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['2'] = $stats['2'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['2'] = $stats['2'] + $row['Montant_11'];
                                        } 
                                }
                                if($row['Datevaleur_31']==gmdate('Y-m-d'))
                                {
                                        if($row['Devise_12']=='USD')
                                        {
                                                $stats['3'] = $stats['3'] + ($row['Montant_11']*$usd);
                                        }
                                        elseif($row['Devise_12']=='CDF')
                                        {
                                                $stats['3'] = $stats['3'] + $row['Montant_11'];
                                        } 
                                }

                        }
                        return $stats;
                }
                elseif($type=='paiement_guichet')
                {
                        if(!empty($data))
                        {
                                if(isset($data['agence']) && !empty($data['agence']))
                                {
                                        $st0 .= " AND Guichet_21 ='".$data['agence']."'";
                                }

                                if((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end'])))
                                {
                                        $st0 .= " AND (Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."')";
                                }
                                
                                $builder = $this->db->table('logiref_integration_isys')
                                        ->select('logiref_paiements_tresor.*')
                                        ->where($st0)
                                        ->like('Date_1', gmdate('Y-m-d'))
                                        ->orderBy('logiref_paiements_tresor.Id_0','logiref_paiements_tresor.Id_0 DESC')
                                        ->get();
                                
                                return $builder->getResult();
                                
                                if($row['Devise_12']=='USD')
                                {
                                        $stats['1'] = $stats['1'] + ($row['Montant_11']*$usd);
                                }
                                elseif($row['Devise_12']=='CDF')
                                {
                                        $stats['1'] = $stats['1'] + $row['Montant_11'];
                                } 
                        }
                        
                }
                elseif($type=='paiement_situation_cdf')
                {
                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );
                        
                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where('Account_3',$this->session->userdata['account_id'])
                                ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();
                        
                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='CDF')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='CDF')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }
                        
                        return $stats;
                }
                elseif($type=='paiement_situation_usd')
                {
                        $stats = array(

                                "unvalidated" => '0', //'Paiement non validE,
                                "validated" => '0', //'Paiement validE,
                                "reversed" => '0', //'Paiement reversE,
                                "unvalidated_number" => '0', //'Nombre de paiements non validE,
                                "validated_number" => '0', //'Nombre de paiements validE,
                                "none" => '1', //'Aucun paiement,
                        );
                        
                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where('Account_3',$this->session->userdata['account_id'])
                                ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();
                        
                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Checkerid_10']==0 && $row['Devise_12']=='USD')
                                {
                                        $stats['unvalidated'] = $stats['unvalidated'] + $row['Montant_11'];
                                        $stats['unvalidated_number'] = $stats['unvalidated_number'] +1;
                                }
                                elseif($row['Checkerid_10']>0 && $row['Devise_12']=='USD')
                                {
                                        $stats['validated'] = $stats['validated'] + $row['Montant_11'];
                                        $stats['validated_number'] = $stats['validated_number'] +1;
                                }
                                elseif($row['Status_2']==2 && $row['Devise_12']=='USD')
                                {
                                        $stats['reversed'] = $stats['reversed'] + $row['Montant_11'];
                                }
                        }
                        
                        return $stats;
                }
                elseif($type=='paiement_situation_regie')
                {
                        $stats = array(

                                "dgi_unvalidated" => '0',
                                "dgi_unvalidated_number" => '0',
                                "dgi_validated" => '0',
                                "dgi_validated_number" => '0',
                                "dgda_unvalidated" => '0',
                                "dgda_unvalidated_number" => '0',
                                "dgda_validated" => '0',
                                "dgda_validated_number" => '0',
                                "dgrad_unvalidated" => '0',
                                "dgrad_unvalidated_number" => '0',
                                "dgrad_validated" => '0',
                                "dgrad_validated_number" => '0',
                        );
                        
                        $query = $this->db->table('logiref_paiements_tresor')
                                ->select('logiref_paiements_tresor.*')
                                ->where('Account_3',$this->session->userdata['account_id'])
                                ->where('Guichet_21',$_SESSION['Logiref_guichet'])
                                ->like('Date_1', gmdate('Y-m-d'))
                                ->get();
                        
                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Checkerid_10']==0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgi_unvalidated'] = $stats['dgi_unvalidated'] + $row['Montant_11'];
                                                        }
                                                        $stats['dgi_unvalidated_number'] = $stats['dgi_unvalidated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Sydonia_44'] !='0' && $row['Status_2'] !='1')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgda_unvalidated'] = $stats['dgda_unvalidated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgda_unvalidated_number'] = $stats['dgda_unvalidated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgrad_unvalidated'] = $stats['dgrad_unvalidated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgrad_unvalidated_number'] = $stats['dgrad_unvalidated_number'] +1;
                                                }
                                        }
                                }
                                elseif($row['Checkerid_10']>0)
                                {
                                        if($row['Beneficaire_15']=='DGI')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgi_validated'] = $stats['dgi_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgi_validated'] = $stats['dgi_validated'] + $row['Montant_11'];
                                                        }
                                                        $stats['dgi_validated_number'] = $stats['dgi_validated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGDA')
                                        {
                                                if($row['Sydonia_44'] !='0' && $row['Status_2'] =='1')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgda_validated'] = $stats['dgda_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgda_validated'] = $stats['dgda_validated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgda_validated_number'] = $stats['dgda_validated_number'] +1;
                                                }
                                        }
                                        elseif($row['Beneficaire_15']=='DGRAD')
                                        {
                                                if($row['Sydonia_44'] =='0')
                                                {
                                                        if($row['Devise_12']=='USD')
                                                        {
                                                                $stats['dgrad_validated'] = $stats['dgrad_validated'] + ($row['Montant_11']*$usd);
                                                        }
                                                        elseif($row['Devise_12']=='CDF')
                                                        {
                                                                $stats['dgrad_validated'] = $stats['dgrad_validated'] + $row['Montant_11'];
                                                        } 
                                                        $stats['dgrad_validated_number'] = $stats['dgrad_validated_number'] +1;
                                                }
                                        }
                                }
                        }
                        
                        return $stats;
                }
        }
        
        public function get_paiement_by_reference($reference=NULL)
        {
                $this->set_table('logiref_sbbos_paiements c', 'p.Id_0', 'c.Id_0 DESC');
                return $this->get_by(array('Reference_19' => $reference), TRUE);
        }
        
        public function get_paiement_by_cbs_reference($ref_cbs)
        {
                $this->set_table('logiref_sbbos_paiements c', 'p.Id_0', 'c.Id_0 DESC');
                return $this->get_by(array('Refcbs_38' => $ref_cbs), TRUE);
        }
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if($item=="airport_national")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_airport')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Name_7'] != "Etrangers")
                                {
                                        $ddmenu[$row['Id_0']] = $row['Name_7'];
                                }
                        }

                        return $ddmenu;
                }
                elseif($item=="airport_by_branch")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_airport')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Name_7'] != "Etrangers")
                                {
                                        $ddmenu[$row['Branchid_9']] = $row['Id_0'];
                                }
                        }

                        return $ddmenu;
                }
                elseif($item=="airport")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        
                        $builder = $this->db->table('logiref_sbbos_airport')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($builder->getResultArray() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        
        public function get_paiements()
        {
                $agence = $_SESSION['Logiref_guichet'];
                $counter = $_SESSION['Logiref_branch'];
                
                $st = "Status_2 > '0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_21 = '".$agence."' ";
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->limit(500)
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_partners()
        {
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2 > '0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Partner_25 != '' ";
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->limit(500)
                        ->get();
                return $builder->getResult();
        }
        
        public function get_batch_tickets_by_id($ids)
        {
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2 > '0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Id_0 IN ($ids) ";
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_by_caisseid($id)
        {
                $day = gmdate('Y-m-d');
                #Query
                $st = "Date_1 LIKE '%".$day."%' AND Status_2='1' AND Cashregister_20 = '".$id."'";
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_by_userid($userid)
        {
		#Query
                $st = "Status_2='1' AND Creator_4 = '".$userid."'";
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_gopass($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1' AND 	Productid_7 = '1' ";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch');
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 > '0' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_nverify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch');
		
                #Query
                if ($_SESSION['Logiref_role']==4)
                {
                        if($status == 'illicocash'):
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."' AND Creator_4 = '".$user."'";
                        elseif($status == 'carte'):
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."' AND  Creator_4 = '".$user."'";
                        else :
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'  AND Creator_4 = '".$user."'";
                        endif;
                }
                else
                {
                        if($status == 'illicocash'): 
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        elseif($status == 'carte'):
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        else :
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        endif;
                }

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}

        
        
        public function get_paiements_toll_verify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch'); 
                
                #Query
                if ($_SESSION['Logiref_role']==4)
                {
                        if($status == 'illicocash'): 
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."' AND Creator_4 = '".$user."'  ";
                        elseif($status == 'carte'):
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."' AND Creator_4 = '".$user."' ";
                        else :
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."' AND Creator_4 = '".$user."'  ";
                        endif;
                }
                elseif ($_SESSION['Logiref_role']==4)
                {
                        if($status == 'illicocash'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%'";
                        elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%'";
                        else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%'";
                        endif;
                }
                else
                {
                        if($status == 'illicocash'): 
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        elseif($status == 'carte'):
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        else :
                                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '2' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                        endif;
                }
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_offline_nverify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch'); 
                
		#Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1'  AND OffLine_36 = '1' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                return $builder->getResult();
	}
        
        public function get_paiements_toll_to_regularize($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '5' AND Productid_7 = '2' ";

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_ticket_to_regularize($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '5' AND Productid_7 = '3' ";

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}

        public function get_paiements_toll_to_cancel($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch');
                $role = $this->session->get('Logiref_role');
                $agence = $this->session->get('Logiref_guichet');
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '6' AND Productid_7 = '2' ";
                if($role == '7') $st .= " AND Agence_21 = '".$agence."' ";
                if($role == '3') $st .= " AND Agence_21 = '".$agence."' AND Branchid_26 = '".$counter."' ";
                
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_cancelled($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch');
                $role = $this->session->get('Logiref_role');
                $agence = $this->session->get('Logiref_guichet');

                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '7' AND Productid_7 = '2' ";
                
                if($role == '7') $st .= " AND Agence_21 = '".$agence."' ";
                if($role == '3') $st .= " AND Agence_21 = '".$agence."' AND Branchid_26 = '".$counter."' ";
                
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_to_regularize_filter($data=NULL)
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '5' AND Productid_7 = '2' ";

                #Filtre d'affichage
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_paiements_toll_to_cancel_by_filter()
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->get('Logiref_guichet');
                $counter = $this->session->get('Logiref_branch');
                $role = $this->session->get('Logiref_role');
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '6' AND Productid_7 = '2' ";
                
                if($role == '7') $st .= " AND Agence_21 = '".$agence."' ";
                if($role == '3') $st .= " AND Agence_21 = '".$agence."' AND Branchid_26 = '".$counter."' ";

                
                #Filtre d'affichage
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }

                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                
                return $builder->getResult();
        }
        
        public function get_paiements_toll_cancelled_by_filter()
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->get('Logiref_guichet');
                $counter = $this->session->get('Logiref_branch');
                $role = $this->session->get('Logiref_role');
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '7' AND Productid_7 = '2' ";
                
                if($role == '7') $st .= " AND Agence_21 = '".$agence."' ";
                if($role == '3') $st .= " AND Agence_21 = '".$agence."' AND Branchid_26 = '".$counter."' ";

                #Filtre d'affichage
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                 
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                
                return $builder->getResult();
        }
        
        public function get_paiements_toll_nverify_to_regularize($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '5' AND Productid_7 = '2' ";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_verify_to_regularize($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '5' AND Productid_7 = '2' ";
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_toll_offline_verify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '2'  AND OffLine_36 = '1' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                return $builder->getResult();
	}

        public function get_paiements_toll_online_verify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '2'  AND OffLine_36 = '0' AND Productid_7 = '2' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}

        public function get_paiements_toll_online_nverify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $_SESSION['Logiref_branch']; 
                
		#Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1'  AND OffLine_36 = '0' AND Productid_7 = '2' AND Date_1 Like '%". gmdate('Y-m-d')."%' AND Branchid_26 = '".$counter."'";

                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}

        public function get_recents_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                $counter = $this->session->get('Logiref_branch');
                
		#Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 > 0 AND Status_2 != 5 AND Productid_7 = '2' AND Branchid_26 = '".$counter."'";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit(5)
                        ->get();

                return $builder->getResult();
	}
        
        public function get_recents_paiements_ticket($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1' AND Productid_7 = '3'";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit(5)
                        ->get();
                return $builder->getResult();
	}
        
        public function get_recents_paiements_partner($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 > 0 AND Productid_7 = '2' AND Partner_25 != '' ";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit(5)
                        ->get();

                return $builder->getResult();
	}

        public function get_paiements_recent_toll($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1' AND 	Productid_7 = '2'";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit(5)
                        ->get();

                return $builder->getResult();
	}
        
        public function get_paiement_toll_partners($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 > 0 AND Productid_7 = '2' AND Partner_25 != '' ";
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();

                return $builder->getResult();
	}
        
        public function get_paiements_ticket($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1' AND Productid_7 = '3' AND Date_1 Like '%". gmdate('Y-m-d')."%' ";
                if($status == 'illicocash'): 
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                endif;
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        public function get_paiements_ticket_no_verify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                if($status == 'illicocash'): 
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '3' AND Date_1 Like '%". gmdate('Y-m-d')."%' ";
                elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '3' AND Date_1 Like '%". gmdate('Y-m-d')."%' ";
                else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '3' AND Date_1 Like '%". gmdate('Y-m-d')."%' ";
                endif;
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*', 'logiref_sbbos_paiements.Id_0')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        public function get_paiements_ticket_verify($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                if($status == 'illicocash'): 
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '2' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '2' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '2' AND Productid_7 = '3' AND Changes_5 Like '%". gmdate('Y-m-d')."%' ";
                endif;
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_all_paiements($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2='1'";
                if($status == "current_day") $st .= " AND Date_1 Like '%". gmdate('Y-m-d')."%' ";
                if(isset($_SESSION['Logiref_branch']) && $_SESSION['Logiref_branch'] != "") $st .= " AND Branchid_26 = '". $_SESSION['Logiref_branch']."' ";
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        
        public function filter_paiements($data)
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_21 = '".$agence."'";
                
                #Filtre d'affichage
                if(isset($_POST['Guichet_20']) && $_POST['Guichet_20']!='') $st .= " AND Cachregister_20='".$_POST['Guichet_20']."'";
                if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
              
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiement_toll_partners_filter()
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 > 0 AND Productid_7 = '2' AND Partner_25 != '' ";
                
                #Filtre d'affichage
                if(isset($_POST['Type_12']) && $_POST['Type_12']!='') $st .= " AND Type_12='".$_POST['Type_12']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_toll_filter()
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Productid_7 = '2' ";
                
                #Filtre d'affichage
                if(isset($_POST['Departure_15']) && $_POST['Departure_15']!='') $st .= " AND Departure_15='".$_POST['Departure_15']."'";
                if(isset($_POST['Type_12']) && $_POST['Type_12']!='') $st .= " AND Type_12='".$_POST['Type_12']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_toll_nverify_filter($data=NULL)
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1' AND Productid_7 = '2'";

                #Filtre d'affichage
                if(isset($data['Departure_15']) && $data['Departure_15']!='') $st .= " AND Departure_15='".$data['Departure_15']."'";
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";
                if(isset($data['Creator_4']) && $data['Creator_4']!='') $st .= " AND Creator_4='".$data['Creator_4']."'";
                if(isset($data['Creator_4']) && $data['Creator_4']!='') $st .= " AND Creator_4='".$data['Creator_4']."'";
                if(isset($data['Branchid_26']) && $data['Branchid_26']!='') $st .= " AND Branchid_26='".$data['Branchid_26']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_toll_verify_filter($data)
        {
                $data = $_POST;
                
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '2' AND Productid_7 = '2'";

                #Filtre d'affichage
                if(isset($data['Departure_15']) && $data['Departure_15']!='') $st .= " AND Departure_15='".$data['Departure_15']."'";
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";
                if(isset($data['Creator_4']) && $data['Creator_4']!='') $st .= " AND Creator_4='".$data['Creator_4']."'";
                if(isset($data['Branchid_26']) && $data['Branchid_26']!='') $st .= " AND Branchid_26='".$data['Branchid_26']."'";


                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Changes_5 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_toll_offline_nverify_filter($data=NULL)
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1'  AND OffLine_36 = '1' AND Productid_7 = '2'";

                #Filtre d'affichage
                if(isset($data['Departure_15']) && $data['Departure_15']!='') $st .= " AND Departure_15='".$data['Departure_15']."'";
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";
                
                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_toll_offline_verify_filter($data)
        {
                $data = $_POST;
                
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '2'   AND OffLine_36 = '1' AND Productid_7 = '2'";

                #Filtre d'affichage
                if(isset($data['Departure_15']) && $data['Departure_15']!='') $st .= " AND Departure_15='".$data['Departure_15']."'";
                if(isset($data['Type_12']) && $data['Type_12']!='') $st .= " AND Type_12='".$data['Type_12']."'";
                
                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Changes_5 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_ticket_filter()
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Productid_7 = '3' ";
                
                #Filtre d'affichage
                if(isset($_POST['Event_23']) && $_POST['Event_23']!='') $st .= " AND Event_23='".$_POST['Event_23']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        public function get_paiements_ticket_no_verify_filter($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['user_id'];
                
		#Query
                if($status == 'illicocash'): 
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '1' AND Productid_7 = '3' ";
                elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '1' AND Productid_7 = '3' ";
                else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '1' AND Productid_7 = '3' ";
                endif;
                
                #Filtre d'affichage
                if(isset($_POST['Event_23']) && $_POST['Event_23']!='') $st .= " AND Event_23='".$_POST['Event_23']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        public function get_paiements_ticket_verify_filter($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user = $this->session->userdata['account_id'];
                
		#Query
                if($status == 'illicocash'): 
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '8' AND Status_2 = '2' AND Productid_7 = '3' ";
                elseif($status == 'carte'):
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '9' AND Status_2 = '2' AND Productid_7 = '3' ";
                else :
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Mode_29 = '5' AND Status_2 = '2' AND Productid_7 = '3' ";
                endif;
                
                #Filtre d'affichage
                if(isset($_POST['Event_23']) && $_POST['Event_23']!='') $st .= " AND Event_23='".$_POST['Event_23']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Changes_5 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_paiements_gopass_filter()
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Productid_7 = '1' ";
                
                #Filtre d'affichage
                if(isset($_POST['Departure_15']) && $_POST['Departure_15']!='') $st .= " AND Departure_15='".$_POST['Departure_15']."'";
                if(isset($_POST['Type_12']) && $_POST['Type_12']!='') $st .= " AND Type_12='".$_POST['Type_12']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paiements_filter($data)
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                #Filtre d'affichage
                if(isset($_POST['Guichet_20']) && $_POST['Guichet_20']!='') $st .= " AND Cashregister_20='".$_POST['Guichet_20']."'";
                
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
              
                #Run
                $builder = $this->db->table('logiref_sbbos_paiements')
                        ->select('logiref_sbbos_paiements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        
        public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		//($id >0) || $this->db->where('Id_0', $id);
		return $this->saveData($data, $id);
	}
        
        public function save_paiements($data, $id) {
                $this->set_table('logiref_sbbos_paiements', 'Id_0', 'Id_0 DESC');
                //($id > 0) || $this->db->where('Id_0', $id);
                return $this->saveData($data, $id);
        }
        
        public function update_paiements($data, $reference) {
                $this->set_table('logiref_sbbos_paiements', 'Reference_19', 'Id_0 DESC');
                $this->db->where('Reference_19', $reference);
                return $this->saveData($data, $reference);
        }
        
        public function update_encaissement($data, $id) {
                $query = $this->db->table('logiref_sbbos_paiements')
                        ->where('Id_0', $id)
                        ->update($data);
                return $query;
        }
        
        public function save_paiements_batch($data, $table, $id = NULL) 
        {
                $res = $this->db->insert_batch($table, $data);
                if($res){
                    return TRUE;
                }else{
                    return FALSE;
                }
        }
        
        public function delete_paiement($id)
	{
		$query = $this->db->table('logiref_sbbos_paiements')
                        ->where('Id_0', $id)
                        ->delete();
                return $query;
	}
        public function delete_paiement_batch($id)
	{
		$builder = $this->db->table('logiref_sbbos_paiements')
                        ->where('Refbatch_33', $id)
                        ->delete();
                return $builder;
	}
        public function save_ticket_batch($data, $table, $id = NULL) 
        {
                $res = $this->db->insert_batch($table, $data);
                if($res){
                    return $this->db->insert_id();
                }else{
                    return FALSE;
                }
        }
}