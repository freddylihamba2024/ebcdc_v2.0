<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class PartnersModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_partner_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Name_7='';
                        $obj->Description_8='';
                        $obj->Adresse_9='';
                        $obj->Nif_10='';
                        $obj->Phone_11='';
                        $obj->Email_12='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_sbbos_partners', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="partners")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0') AND Status_2 !='0'";
                        
                        $query = $this->db->table('logiref_sbbos_partners')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_partners($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('logiref_sbbos_partners')
                        ->select('logiref_sbbos_partners.*')
                        ->where("logiref_sbbos_partners.Status_2 ='1'")
                        ->where("logiref_sbbos_partners.Account_3 ='".$account_id."'")
                        ->orderBy('logiref_sbbos_partners.Id_0','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_partners($data, $id)
	{
		$this->set_table('logiref_sbbos_partners', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
}