<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class UsersModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $role = array(
                           ''  =>'',
                           '1' => 'Administrateurs', 
                           '2' => 'Superviseur',
                           '3' => 'Validateur (Checkers)', 
                           '4' => 'Operateurs (Makers)',
                           '5' => 'Consultation',
                           '6' => 'Partenaire',
                           '7' => 'Responsable'
                       );
        
        public $fonction = array(
                            '1' => 'Administrateurs', 
                            '2' => 'Directeur g&eacute;n&eacute;ral',
                            '3' => 'Directeur', 
                            '4' => 'Controlleur', 
                        );
        
        public $status = array(
                            '1' => 'Actif',
                            '2' => 'Inactif',
                            '3' => 'Suspendu'
                        );
        public $state_Color = array('3' => 'label-danger', '2' => 'label-info', '1' => 'label-completed');
        
        public $products = array(
                    '0' => '',
                    '1' => 'Go-Pass',
                    '2' => 'Péage',
                    '3' => 'Ticket'
                );
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_user_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Role_4 = '';
                        $obj->Province_5 = '';
                        $obj->Ville_6 = '';
                        $obj->Agence_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Profile_9 = '';
                        $obj->Service_10 = '';
                        $obj->Regies_11 = '';
                        $obj->Code_12 = '';
                        $obj->Userid_13 = '';
                        $obj->Maker_14 = '';
                        $obj->Checker_15 = '';
                        $obj->Validation_16 = '';
                        $obj->Login_17 = '';
                        $obj->Password_18 = '';
                        $obj->Statusvalidate_19 = '';
                        $obj->Caisse_20 = '';
                        $obj->Partner_21 = '';
                        $obj->Pos_22 = '';
                        $obj->Type_23 = '';
                        $obj->Region_24 = '';
                        $obj->Subscriptionid_25 = '';
                        $obj->Option_26 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_users p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $data = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="users")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Userid_13'];
                        }
                        return $ddmenu;
                }
                if($item=="operators")
                {
                        #$st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Role_4 = 4 AND Guichet_8 = '".$_SESSION['Logiref_guichet']."' ";
                        if ($_SESSION['Logiref_role']==2)
                        {
                                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Role_4 = 4  ";

                        }
                        else
                        {
                                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Role_4 = 4 AND Agence_7 = '".$_SESSION['Logiref_agence']."' ";

                                
                        }
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row)
                        {
                                if(isset($data[$row['Userid_13']])) $ddmenu[$row['Userid_13']] = $data[$row['Userid_13']];
                        }
                        return $ddmenu;
                }
                
                if($item=="pos")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Pos_22'];
                        }
                        return $ddmenu;
                }
                if($item=="users_pos")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Pos_22 !='0' ";
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Pos_22']] = $row['Userid_13'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $query = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_privilegies() 
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit('1')
                        ->get();
                $results = $query->getResultArray();
                
                if(!empty($results))
                {
                        foreach ($results as $row) 
                        {
                                $_SESSION['Logiref_role'] = $row['Role_4'];
                                $_SESSION['Logiref_privileges'] = $row['Role_4'];
                                $_SESSION['Logiref_province'] = $row['Province_5'];
                                $_SESSION['Logiref_ville'] = $row['Ville_6'];
                                $_SESSION['Logiref_agence'] = $row['Agence_7'];
                                $_SESSION['Logiref_guichet'] = $row['Agence_7'];
                                $_SESSION['Logiref_groupe'] = strtolower($row['Groupe_9']);                                
                                $_SESSION['Logiref_service'] = $row['Service_10'];
                                $_SESSION['Logiref_regies'] = $row['Regies_11'];
                                $_SESSION['Logiref_user'] = $row['Code_12'];
                                $_SESSION['Logiref_caisse'] = $row['Caisse_20'];
                                $_SESSION['Logiref_branch'] = $row['Guichet_8'];
                                $_SESSION['partner'] = $row['Partner_21'];
                                $_SESSION['pos'] = $row['Pos_22'];
                                $_SESSION['Sbbos_type'] = ($row['Type_23'] != 0)?$row['Type_23']:2;
                                $_SESSION['Logiref_region'] = $row['Region_24'];
                                $_SESSION['roles_banks'] = [
                                                '1'=> 'ADMINISTRATEUR', 
                                                '2'=> 'SUPERVISEUR', 
                                                '3'=> 'VALIDATEUR', 
                                                '4'=> 'OPERATEUR'
                                        ];
                        }
                }
                else
                {
                        $_SESSION['Logiref_guichet'] = "";
                        $_SESSION['Logiref_privileges'] = 0;
                }
                
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Id_0 ='" . $_SESSION['Logiref_guichet'] . "'";
                $query = $this->db->table('logiref_guichets')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit('1')
                        ->get();
                $results = $query->getResultArray();
                $_SESSION['Guichet_code'] = "";
                
                if(!empty($results))
                {
                        foreach ($results as $row) 
                        {
                                $_SESSION['Guichet_code'] = $row['Code_10'];
                                $_SESSION['main_branch'] = $row['Agence_principale_15'];
                        }
                }
                return true;
        }

        public function get_user_connected()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $st = "Account_3='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->limit('1')
                        ->get();

                return $query->getRow();
        }
        
        public function get_users_stats() 
        {
                $return = array(
                        'Inactifs' => 0,
                        'Suspendus' => 0,
                        'Actifs' => 0,
                        'Total' => 0
                );

                $this->set_table('logiref_users', 'Id_0', 'Id_0 ASC');
                $return['useres']= $this->get_by(array('Status_2 !=' => 0, 'Account_3' => $this->session->userdata['account_id']));

                foreach ($return['useres'] as $val) 
                {
                        if ($val->Status_2 == 1)
                            $return['Actifs']++;
                        if ($val->Status_2 == 2)
                            $return['Inactifs']++;
                        if ($val->Status_2 == 3)
                            $return['Suspendus']++;

                        $return['Total']++;
                }
                return $return;
        }
        
        public function get_members($id=NULL) 
        {
                $builder = $this->db->table('logiref_users')
                        ->select('*')->where("logiref_users.Account_3 ='" . $this->session->userdata['account_id'] . "'")
                        ->orderBy('logiref_users.Id_0','ASC')
                        ->get();
                if ($id != NULL && $id > 0) 
                {
                        $builder = $this->db->table('logiref_users')
                                ->select('*')
                                ->where("logiref_users.Userid_13 ='" . $id . "'")
                                ->where("logiref_users.Account_3 ='" . $this->session->userdata['account_id'] . "'")
                                ->orderBy('logiref_users.Id_0','ASC')
                                ->get();
                }
                if (isset($_POST['agence']) && $_POST['agence'] != "") 
                {
                        $builder = $this->db->table('logiref_users')
                                ->select('*')
                                ->where("logiref_users.Agence_7 ='" . $_POST['agence'] . "'")
                                ->where("logiref_users.Account_3 ='" . $this->session->userdata['account_id'] . "'")
                                ->orderBy('logiref_users.Id_0','ASC')
                                ->get();
                }
                return $builder->getResult();
        }
        
        public function get_members_array() 
        {
                $where = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $query = $this->db->table('logiref_users')
                        ->where($where)
                        ->orderBy('Firstname_4','ASC')
                        ->get();
                $ddmenu = array();
                foreach ($query->getResultArray() as $row) 
                {
                        $ddmenu[$row['Userid_7']] = $row['Firstname_4'] . ' ' . $row['Lastname_5'];
                }
                return $ddmenu;
        }
        
        public function get_member_by_user_id()
        {
                $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Userid_13' => $this->session->userdata['user_id']));
                return $result;
        }
        
        public function get_sydoniaccount_by_accountid($param)
	{
                
                $this->set_table('logiref_users ', 'Userid_13', 'Userid_13 DESC');
                
                return $this->get_by(array('Userid_13 '=>$param), TRUE);
	}
        
        public function get_pos_by_imei($id =NULL)
        {
                $this->set_table('logiref_users I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Pos_22' => $id), TRUE);
        }
        
       
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function update_users($data, $ids) {
                $builder = $this->db->table('logiref_users')
                        ->where("logiref_users.Userid_13 IN (".$ids.")")
                        ->update($data);
                return $builder;
        }
        
        public function save_users($data, $id) {
                $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        
        
}