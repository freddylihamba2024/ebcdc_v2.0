<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class TicketsModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $sales_points = array
                              (
                                ""=>'',
                                "1"=>'30 juin'
                                , "2"=>'Atruim', 
                                "3"=>'Minafep'
                               );
        
        public $status_color = array(
            
                    '1' => 'label-completed',
                    '0'=>'label-cancelled'
        );
        
        public $status =  array(
                                '1' => 'Actif',
                                '0' => 'Annul&eacute;'
                            );
        
        public $modes = array(
                            ''=>'', 
                            '5' => 'ESPECE', 
                            '8' => 'ILLICO CASH',
                            '9' => 'CARTE',
                        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_ticket_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        
                        $obj->Name_7='';
                        $obj->Price_8='';
                        $obj->Currency_9='';
                        $obj->Quantity_10='';
                        $obj->Quantity_15 = '';
                        $obj->Guichet_11='';
                        $obj->Description_12='';
                        $obj->Event_13='';
                        
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_sbbos_tickets', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_branch');
                
                if($item=="tickets")
                {
                        if($arg=='ALL')
                        {   
                            $where ="Status_2 !='0' AND (Account_3='".$account_id."' OR Account_3='0')";
                        }
                        else
                        {
                            $where ="Status_2 !='0' AND (Guichet_11 ='".$guichet."' OR Guichet_11 ='0') AND (Account_3='".$account_id."' OR Account_3='0')";
                        }
                        $query = $this->db->table('logiref_sbbos_tickets')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_tickets($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('logiref_sbbos_tickets')
                        ->select('logiref_sbbos_tickets.*')
                        ->where("logiref_sbbos_tickets.Account_3 ='".$account_id."'")
                        ->orderBy('logiref_sbbos_tickets.Id_0','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_tickets_by_event($account_id = NULL, $event=NULL, $guichet=NULL)
	{
                if($account_id != "")
                {
                        $builder = $this->db->table('logiref_sbbos_tickets')
                                ->select('logiref_sbbos_tickets.*')
                                ->where("logiref_sbbos_tickets.Account_3 ='".$account_id."'")
                                ->where("logiref_sbbos_tickets.Guichet_11 ='".$guichet."'")
                                ->where("logiref_sbbos_tickets.Event_13 ='".$event."'")
                                ->orderBy('logiref_sbbos_tickets.Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $account_id=$this->session->userdata['account_id'];
                        $guichet = $_SESSION['Logiref_branch'];
                        
                        $builder = $this->db->table('logiref_sbbos_tickets')
                                ->select('logiref_sbbos_tickets.*')
                                ->where("logiref_sbbos_tickets.Account_3 ='".$account_id."'")
                                ->where("logiref_sbbos_tickets.Guichet_11 ='".$guichet."'")
                                ->where("logiref_sbbos_tickets.Event_13 ='".$event."'")
                                ->orderBy('logiref_sbbos_tickets.Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
	}
        
        public function get_tickets_by_branch($account_id = NULL, $event=NULL, $guichet=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_branch');

                $builder = $this->db->table('logiref_sbbos_tickets')
                        ->select('logiref_sbbos_tickets.*')
                        ->where("logiref_sbbos_tickets.Account_3 ='".$account_id."'")
                        ->where("logiref_sbbos_tickets.Guichet_11 ='".$guichet."'")
                        ->orderBy('logiref_sbbos_tickets.Id_0','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_tickets($data, $id)
	{
		$this->set_table('logiref_sbbos_tickets', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function update_ticket_number($data, $id) {
                $builder = $this->db->table('logiref_sbbos_tickets')
                        ->update($data, $id);
                return $builder;
        }
        
}