<?php

namespace Modules\Etoll\Models;

use stdClass;
use App\Models\MY_Etoll;

class CaissesModel extends MY_Etoll {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $status_color = array(
            
                    '0'=>'label-ongoing',
                    '1' => 'label-new-order',
                    '2' => 'label-completed',
                    '3' => 'label-cancelled',
                    '4' => 'label-upcoming'
        );
        
        public $status =  array(
                                '0' => 'Supprim&eacute;e',
                                '1' => 'Ferm&eacute;e',
                                '2' => 'Ouverte', 
                                '3' => 'Fermeture en attente', 
                                "4"=>'Ouverture en attente'
                            );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_caisse_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Reference_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Compte_9 = '';
                        $obj->Name_10 = '';
                        $obj->Devise_11 = '';
                        $obj->Opener_12 = '';
                        $obj->Closer_13 = '';
                        $obj->Date_14 = '';
                        $obj->Agence_15 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_caisses g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="caisses")
                {   
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('logiref_sbbos_caisses')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_10'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_caisses($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_sbbos_caisses')
                        ->select('logiref_sbbos_caisses.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_caisse_by_branchid($id =NULL, $currency= NULL)
        {
                if($currency == NULL)
                {
                        $this->set_table('logiref_sbbos_caisses I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Guichet_8' => $id), TRUE);
                }
                else
                {
                        $this->set_table('logiref_sbbos_caisses I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Guichet_8' => $id, 'Devise_11'=>$currency), TRUE);
                }
                
        }
        
        public function get_caisses_by_agence()
        {
                $agence = $this->session->get('Logiref_guichet');
                
                $st = "Status_2 !=0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Agence_15 ='" . $agence . "'";
                $builder = $this->db->table('logiref_sbbos_caisses')
                        ->select('logiref_sbbos_caisses.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_movement_caisse_by_id($id=NULL)
        {
                $this->set_table('logiref_sbbos_guichet_movements g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Guichet_11' => $id), TRUE);
        }
        
        public function get_movement_caisse($id=NULL)
        {
                $agence = $this->session->get('Logiref_guichet');
                $guichet = $this->session->get('Logiref_branch');
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_11 = '".$guichet."' AND Agence_13 = ".$agence;
                
                #Filtre d'affichage
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }
                
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_guichets_status()
        {
                $agence = $this->session->get('Logiref_guichet');
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_13 = ".$agence;
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        
        public function get_current_movement($id, $action)
        {
                $day = gmdate('Y-m-d');
                
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_11 = '".$id."' AND Action_12 ='".$action."'";
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->like('Date_1',$day)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        #Checks if the book has already been created with the entered account
        public function get_caisse_exists($account = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_caisses ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Account_3'=>$account_id,'Compte_9'=>$account), TRUE);
        }
        
        
        public function filter_caisses_status($data)
        {
                $this->_table_name = '';
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->get('Logiref_guichet');
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_13 = '".$agence."'";
                
                #Filtre d'affichage
                if(isset($_POST['Guichet_11']) && $_POST['Guichet_11']!='') $st .= " AND Guichet_11='".$_POST['Guichet_11']."'";
                #if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
              
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                
                #Run
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
            
        }
        
        public function get_balances_stats()
        {
                $agence = $this->session->get('Logiref_guichet');
                $day = gmdate('Y-m-d');
                $status = array(
                    
                            'opening' => 0, 
                            'closing' => 0,
                            'open' => 0,
                            'closed' => 0,
                            'toclose' => 0,
                            'toopen' => 0,
                            'cashrigesters'=> 0
                            );
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'  AND Agence_13 = '".$agence."'";
               
                #Run
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                $result = $builder->getResult();
                
                // Monatnts d'ouvertures et des fermetures
                foreach($result as $row):
                    
                    if($row->Action_12 == "opening" && $row->Changer_6 != 0)
                    {
                        $status['opening'] += $row->Balance_10;
                    }
                    elseif($row->Action_12 == "closing" && $row->Changer_6 != 0)
                    {
                        $status['closing'] += $row->Balance_10;
                    }
                    
                endforeach;
                
                
                
                // Nombre des caisses fermées et nombre des caisses ouvertes
                foreach($result as $row):
                    
                    if($row->Status_2 == 1 && $row->Changer_6 != 0)
                    {
                        $status['open'] += 1;
                    }
                    elseif($row->Status_2 == 2 && $row->Changer_6 != 0)
                    {
                        $status['closed'] += 1;
                    }
                    
                endforeach;
                
                
                // Nombre des caisses en attente d'ouverture et nombre des caisses en attente de fermeture
                foreach($result as $row):
                    
                    if($row->Action_12 == "opening" && $row->Changer_6 == 0)
                    {
                        $status['toopen'] += 1;
                    }
                    elseif($row->Action_12 == "closing" && $row->Changer_6 == 0)
                    {
                        $status['toclose'] += 1;
                    }
                    
                endforeach;
              
          
                return $status;
                
                
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function update_caisses($data, $id)
	{
                $builder = $this->db->table('logiref_sbbos_caisses')
                        ->where("logiref_sbbos_caisses.Id_0 ='".$id."'")
                        ->update($data);
                return $builder;
	}
        
        public function save_caisse($data, $id) {
                $this->set_table('logiref_sbbos_caisses', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_objects_name($data, $id)
	{
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
}