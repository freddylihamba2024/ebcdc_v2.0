<?php

namespace Modules\MigrateFlow\Controllers;

use App\Controllers\BaseController;
use Modules\MigrateFlow\Models\MigrateFlowModel;
use Modules\MigrateFlow\Models\BackupModel;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of MigrateFlow
 *
 * @author macbookpro
 */
class MigrateFlow extends BaseController
{
        //put your code here
        private $migrationModel = null;
        private $source_migration_model = null;
        private $target_migration_model = null;
        public function __construct()
        {
                parent::__construct();
        }

        public function index()
        {
                return view('Modules\MigrateFlow\migrate_flow');
        }
        public function test_connection()
        {
                //                $dbsettings['connection']="localhost";
                //                $dbsettings['username']="root";
                //                $dbsettings['password']="root";
                //                $this->migrationModel=new MigrateFlowModel($dbsettings);
                //                $connected=$this->migrationModel->is_connected();
                //                if($connected)
                //                {
                //                        echo 'connected successfully';
                //                }
                //                else
                //                {
                //                        echo 'Failed to connect to the host';
                //                }
        }
        public function action($action, $obj = null)
        {
                if ($action == "dbconnect") 
                {

                        $dbconnection = $this->request->getPost('dbhost');
                        $dbusername = $this->request->getPost('dbusername');
                        $dbpassword = $this->request->getPost('dbpassword');
                        $dbtype = $this->request->getPost('dbtype');

                        $dbsettings['connection'] = $dbconnection;
                        $dbsettings['username'] = $dbusername;
                        $dbsettings['password'] = $dbpassword;
                        $dbsettings['dbtype'] = $dbtype;


                        if ($this->connect_db($dbsettings)->is_connected()) 
                        {
                                $db_list = $this->migrationModel->get_database_list();

                                $response['status'] = true;
                                $response['message'] = '<span class="text-success">Connected successfully</span>';
                                $response['databases'] = $db_list;
                        } 
                        else 
                        {
                                $response['status'] = false;
                                $response['message'] = '<span class="text-danger">Failed to connect to the database server</span>';
                        }
                        echo json_encode($response);
                } 
                elseif ($action == "show_tables") 
                {
                        $database = $this->request->getPost("database");
                        $dbtype = $this->request->getPost("dbtype");

                        $connection_status = $this->request->getPost("connection_status");
                        if ($connection_status)
                        {
                                if (isset($_SESSION['source_db']) || $_SESSION['source_db'] != null) 
                                {

                                        if ($dbtype == "source_db") 
                                        {
                                                $_SESSION['source_db']['dbname'] = $database;
                                                $dbconnection = $this->connect_db($_SESSION['source_db']);
                                        } 
                                        elseif ($dbtype == "target_db") 
                                        {
                                                $_SESSION['target_db']['dbname'] = $database;
                                                $dbconnection = $this->connect_db($_SESSION['target_db']);
                                        }

                                        $table_list = $dbconnection->get_table_list($database);

                                        if (!empty($table_list) || count($table_list) > 0) 
                                        {
                                                $response['code'] = 200;
                                                $response['message'] = "<span class='text-success'> " . count($table_list) . " tables found</span>";
                                                $response['table_list'] = $table_list;
                                        } 
                                        else 
                                        {
                                                $response['code'] = 404;
                                                $response['message'] = "<span class='text-danger'>No tables found</span>";
                                        }
                                }
                        } 
                        else 
                        {
                                $response['code'] = 405;
                                $response['message'] = "Not connected";
                        }
                        echo json_encode($response);
                } 
                elseif ($action == "show_table_structure") 
                {
                        $table = $this->request->getPost("table");

                        $connection_status = $this->request->getPost("connection_status");

                        if ($connection_status) 
                        {
                                if (isset($_SESSION['source_db']) || $_SESSION['source_db'] != null) 
                                {

                                        $dbconnection = $this->connect_db($_SESSION['source_db']);

                                        $table_list = $dbconnection->get_table_structure($table);

                                        var_dump($table_list);
                                        die();
                                        //                                        if(!empty($table_list) || count($table_list)>0){
                                        //                                                $response['code']=200;
                                        //                                                $response['message']="<span class='text-success'> ".count($table_list)." tables found</span>";
                                        //                                                $response['table_list']=$table_list;
                                        //                                        }
                                        //                                        else
                                        //                                        {
                                        //                                                $response['code']=404;
                                        //                                                $response['message']="<span class='text-danger'>No tables found</span>";
                                        //                                        }
                                }
                        } 
                        else 
                        {
                                echo 'Unable to connect';
                                //                                $response['code']=405;
                                //                                $response['message']="Not connected";
                        }
                        //                        echo json_encode($response);
                } 
                elseif ($action == "table_structures") 
                {
                        $source_table = $this->request->getPost("source_table");
                        $target_table = $this->request->getPost("target_table");

                        $source_db = $this->request->getPost("source_db");

                        $connection_status = $this->request->getPost("connection_status");

                        if ($source_table == NULL && $target_table == NULL) 
                        {
                                $dbconnectionSource = $this->connect_db($_SESSION['source_db']);
                                $table_list = $dbconnectionSource->get_table_list($source_db);

                                $data['table_db_name'] = $source_db;
                                $data['table_list'] = $table_list;


                                $view = view('Modules\MigrateFlow\Views\table_list', $data);

                                $response['code'] = 200;
                                $response['view'] = $view;

                                echo json_encode($response);
                        } 
                        else 
                        {
                                if ($connection_status) 
                                {
                                        if ((isset($_SESSION['source_db']) || $_SESSION['source_db'] != null) && (isset($_SESSION['target_db']) || $_SESSION['target_db'] != null)) 
                                        {

                                                $dbconnectionSource = $this->connect_db($_SESSION['source_db']);
                                                $source_structure = $dbconnectionSource->get_table_structure($source_table);

                                                $dbconnectionTarget = $this->connect_db($_SESSION['target_db']);
                                                $target_structure = $dbconnectionTarget->get_table_structure($target_table);

                                                $data['table_structure']['source'] = $source_structure;
                                                $data['table_structure']['source_table_name'] = $source_table;

                                                $data['table_structure']['target'] = $target_structure;
                                                $data['table_structure']['target_table_name'] = $target_table;

                                                $view = view('Modules\MigrateFlow\Views\table_structure', $data);

                                                $response['code'] = 200;
                                                $response['view'] = $view;

                                                echo json_encode($response);
                                        } 
                                        else 
                                        {
                                                echo 'Not connected yet';
                                        }
                                } 
                                else 
                                {
                                        echo 'Unable to connect';
                                        //                                $response['code']=405;
                                        //                                $response['message']="Not connected";
                                }
                        }


                        //                        echo json_encode($response);
                }
                //                elseif($action=="show_table_data")
                //                {
                //                        $table=$this->request->getPost("table");
                //                        
                //                        $connection_status=$this->request->getPost("connection_status");
                //                        
                //                        if($connection_status){
                //                                 if(isset($_SESSION['source_db']) || $_SESSION['source_db']!=null){
                //                                     
                //                                        $dbconnection = $this->connect_db($_SESSION['source_db']);
                //                                        
                //                                        $table_list=$dbconnection->get_table_data($table);
                //
                //                                        if(!empty($table_list)){
                //                                                $response['code']=200;
                //                                                $response['message']="<span class='text-success'> ".count($table_list)." data found</span>";
                //                                                $response['table_list']=$table_list;
                //                                        }
                //                                        else
                //                                        {
                //                                                $response['code']=404;
                //                                                $response['message']="<span class='text-danger'>No data found</span>";
                //                                        }
                //                                }
                //                        }
                //                        else
                //                        {
                //                                $response['code']=405;
                //                                $response['message']="Not connected";
                //                        }
                //                        echo json_encode($response);
                //                }
                elseif ($action == "table_structure_compare") 
                {
                        $source_table_name = $_POST['source_table_name'];
                        $source_table = json_decode($_POST['source_table_structure']);

                        $target_table_name = $_POST['target_table_name'];
                        $target_table = json_decode($_POST['target_table_structure']);

                        $total_fields = $this->analyze_compare_table($target_table_name, $source_table, $target_table);

                        var_dump($total_fields);

                        //                    for($i=0;$i<count($source_table);$i++){
                        //                        var_dump($source_table[$i]["object"]);
                        //                    }

                } 
                elseif ($action == "create_table_structure") 
                {

                        $table_name = $_POST['table_name'];

                        $dbConnectionSource = $this->connect_db($_SESSION['source_db']);

                        $columns = $dbConnectionSource->get_table_structure($table_name);

//                        var_dump($table_name);
//                        var_dump($columns);
//                        die();
                        
                        $columns_tabs = array();

                        for ($i = 0; $i < count($columns); $i++) 
                        {
                                array_push($columns_tabs, $columns[$i]->Field . "  " . $columns[$i]->Type . "  " . (($columns[$i]->Null == "NO") ? "NOT NULL" : "NULL") . "  " . (($columns[$i]->Key == "PRI") ? "PRIMARY KEY" : "") . "  " . (($columns[$i]->Default == NULL) ? "" : "Default "."'".$columns[$i]->Default."'") . "  " . $columns[$i]->Extra);
                        }

                        $final_fields_construct = implode(",", $columns_tabs);
                        
                        if (!empty($final_fields_construct) || $final_fields_construct != null) 
                        {
                                $table['table_name'] = $table_name;
                                $table['table_fields'] = $final_fields_construct;

                                $dbconnectionSoucre = $this->connect_db($_SESSION['source_db']);
                                $dbconnectionTarget = $this->connect_db($_SESSION['target_db']);

                                $success = $dbconnectionTarget->create_new_table($table);

//                                if ($success) {
//
//                                        $data_list = $dbconnectionSoucre->get_table_data($table_name);


                                if ($success) 
                                {

                                        $num_data = $dbConnectionSource->count_data($table_name);

                                        if ($num_data > 1000) 
                                        {
                                                $pagination_number = ceil($num_data / 1000);
                                                $data_list = $dbconnectionSoucre->get_table_data_by_chunks($table_name, 1);
                                        } 
                                        else 
                                        {
                                                $data_list = $dbconnectionSoucre->get_table_data($table_name);
                                        }


                                        $data['source_table_name'] = $table_name;
                                        $data['target_table_name'] = $table['table_name'];

                                        $data['source_database_name'] = $_SESSION['source_db']['dbname'];
                                        $data['target_database_name'] = $_SESSION['target_db']['dbname'];

                                        $data['data_list'] = $data_list;

                                        if (!empty($data_list)) 
                                        {
                                                $response['code'] = 200;

                                                $response['message'] = count($data_list) . " data found";
                                                $response['data'] = $data_list;

                                                $response['message'] = $num_data . " data found";
                                                $response['data_length'] = $num_data;
                                                $response['data'] = $data_list;
                                                $response['pagination_number'] = ($num_data > 1000) ? $pagination_number : 0;
                                        } 
                                        else 
                                        {
                                                $response['code'] = 404;
                                                $response['message'] = "No Data found";

                                                $response['data_length'] = 0;

                                                $response['data'] = $data_list;
                                        }
                                } 
                                else 
                                {
                                        $response['code'] = 405;
                                        $response['message'] = "An error occured while trying to create the new table";
                                }
                                //
                                echo json_encode($response);
                                //
                          
                        }
                } 
                elseif ($action == "single_migrate") 
                {
                        // $data_to_migrate = $_POST['table_data'];
                        // $request_data = json_decode($data_to_migrate);

                        // $dbconnect = $this->connect_db($_SESSION['target_db']);

                        // $table = $request_data->table;
                        // $table_data = json_decode($request_data->table_data);

                        // $total_size = count($table_data);
                        // $transfered_size = 0;

                        // foreach ($table_data as $data) {
                        //         $array_data = (array)$data;
                        //         $filtered_array_data = isset($array_data['Id_0']) ? array_diff($array_data, [$array_data['Id_0']]) : $array_data;

                        //         $success = $dbconnect->insert_into_database($table, $filtered_array_data);

                        //         if ($success) {
                        //                 $transfered_size++;
                        //         }
                        // }
                        // if ($transfered_size >= $total_size) {
                        //         $response['code'] = 200;
                        //         $response['message'] = "All the data are migrated successfully";
                        // } else {
                        //         $response['code'] = 503;
                        //         $response['message'] = "Only some data are migrated";
                        // }
                        // echo json_encode($response);
                        $json=$this->request->getJSON(true);
                        $page_offset = $json['page_number'];
                        $table_name=$json['table'];
                        $table_data_d = $json['table_data'];

                        // $request_data = json_decode($data_to_migrate);
                        
                        $table = $table_name;

                        $dbconnectSource = $this->connect_db($_SESSION['source_db']);
                        $dbconnect = $this->connect_db($_SESSION['target_db']);

                        if ($page_offset == 0) 
                        {

                                $table_data = $table_data_d;
                                
                                $total_size = count($table_data);
                                $transfered_size = 0;
                                
                                foreach ($table_data as $data) 
                                {
                                        $array_data = $data;
                                        
//                                        $filtered_array_data = isset($array_data['Id_0']) ? array_diff($array_data, [$array_data['Id_0']]) : $array_data;

                                        $success = $dbconnect->insert_into_database($table, $array_data);

                                        if ($success) 
                                        {
                                                $transfered_size++;
                                        }
                                }
                                if ($transfered_size >= $total_size)
                                {
                                        $response['code'] = 200;
                                        $response['message'] = "All the data are migrated successfully";
                                } 
                                else 
                                {
                                        $response['code'] = 503;
                                        $response['message'] = "Only some data are migrated";
                                }
                                echo json_encode($response);
                        } 
                        else 
                        {
                                $transfered_size = 0;

                                for ($i = 0; $i < $page_offset; $i++) 
                                {
                                        $data_table = $dbconnectSource->get_table_data_by_chunks($table, $i);
                                 
                                        $total_size = count($data_table);

                                        foreach ($data_table as $data) 
                                        {
                                                $array_data = (array)$data;
//                                              $filtered_array_data = isset($array_data['Id_0']) ? array_diff($array_data, [$array_data['Id_0']]) : $array_data;

                                                $success = $dbconnect->insert_into_database($table, $array_data);

//                                                var_dump($success);
//                                                if ($success) 
//                                                {
//                                                        $transfered_size++;
//                                                }
                                        }
                                            
                                }
                                if ($success) 
                                {
                                        $response['code'] = 200;
                                        $response['message'] = "All the data are migrated successfully";
                                } 
                                else 
                                {
                                        $response['code'] = 503;
                                        $response['message'] = "Only some data are migrated";
                                }
                                echo json_encode($response);  
                                
                        }
                } 
                elseif ($action == "migration") 
                {
                        $data_to_migrate = $_POST['data_to_migrate'];

                        $dbconnect = $this->connect_db($_SESSION['target_db']);

                        $final_response = array();

                        foreach ($data_to_migrate as $json_data) 
                        {
                                if ($json_data != NULL || $json_data != "") 
                                {
                                        $decoded_data = json_decode($json_data);

                                        $table = $decoded_data->table;

                                        $table_data = json_decode($decoded_data->table_data);

                                        $total_size = count($table_data);
                                        $transfered_size = 0;
                                        $progress = 0;

                                        foreach ($table_data as $data) 
                                        {
                                                $array_data = (array)$data;
                                                $filtered_array_data = isset($array_data['Id_0']) ? array_diff($array_data, [$array_data['Id_0']]) : $array_data;

                                                $success = $dbconnect->insert_into_database($table, $filtered_array_data);

                                                if ($success) 
                                                {
                                                        $transfered_size++;
                                                        $progress = round(($transfered_size / $total_size) * 100);
                                                }
                                        }

                                        if ($transfered_size >= $total_size) 
                                        {
                                                $response['code'] = 200;
                                                $response['message'] = "All the data are migrated successfully";
                                        } 
                                        else 
                                        {
                                                $response['code'] = 503;
                                                $response['message'] = "Only some data are migrated";
                                        }
                                        array_push($final_response, $response);
                                }
                        }
                        echo json_encode($response);
                } 
                elseif ($action == "show_migration_data") 
                {
                        $source_table_name = $_POST['source_table_name'];
                        $target_table_name = $_POST['target_table_name'];

                        if (!isset($target_table_name) || $target_table_name == "") 
                        {
                                $source_table_structure = json_decode($_POST['source_table_structure']);
                                $columns = $source_table_structure;

                                $columns_tabs = array();

                                for ($i = 0; $i < count($columns); $i++) 
                                {
                                        array_push($columns_tabs, $columns[$i]->Field . "  " . $columns[$i]->Type . "  " . (($columns[$i]->Null == "NO") ? "NOT NULL" : "NULL") . "  " . (($columns[$i]->Key == "PRI") ? "PRIMARY KEY" : "") . "  " . (($columns[$i]->Default == "NULL") ? "" : $columns[$i]->Default) . "  " . $columns[$i]->Extra);
                                }
                                $final_fields_construct = implode(",", $columns_tabs);

                                if (!empty($final_fields_construct) || $final_fields_construct != null) 
                                {
                                        $table['table_name'] = $source_table_name;
                                        $table['table_fields'] = $final_fields_construct;

                                        $dbconnectionSoucre = $this->connect_db($_SESSION['source_db']);
                                        $dbconnectionTarget = $this->connect_db($_SESSION['target_db']);

                                        $success = $dbconnectionTarget->create_new_table($table);

                                        if ($success) 
                                        {

                                                $data_list = $dbconnectionSoucre->get_table_data($source_table_name);

                                                $data['source_table_name'] = $source_table_name;
                                                $data['target_table_name'] = $table['table_name'];

                                                $data['source_database_name'] = $_SESSION['source_db']['dbname'];
                                                $data['target_database_name'] = $_SESSION['target_db']['dbname'];

                                                $data['data_list'] = $data_list;

                                                if (!empty($data_list)) 
                                                {
                                                        $response['code'] = 200;
                                                        $response['message'] = count($data_list) . " data found";
                                                        $response['data'] = $data_list;
                                                        $response['view'] = view("Modules\MigrateFlow\Views\data_migration", $data);
                                                } 
                                                else 
                                                {
                                                        $response['code'] = 404;
                                                        $response['message'] = "No Data found";
                                                }
                                        } 
                                        else 
                                        {
                                                $response['code'] = 405;
                                                $response['message'] = "An error occured while trying to create the new table";
                                        }

                                        echo json_encode($response);
                                }
                        } 
                        else 
                        {
                                if (isset($_SESSION['source_db']) || $_SESSION['source_db'] != null) 
                                {

                                        $dbconnection = $this->connect_db($_SESSION['source_db']);

                                        $data_list = $dbconnection->get_table_data($source_table_name);

                                        $data['source_table_name'] = $source_table_name;
                                        $data['target_table_name'] = $target_table_name;

                                        $data['source_database_name'] = $_SESSION['source_db']['dbname'];
                                        $data['target_database_name'] = $_SESSION['target_db']['dbname'];
                                        $data['data_list'] = $data_list;

                                        if (!empty($data_list)) 
                                        {
                                                $response['code'] = 200;
                                                $response['message'] = count($data_list) . " data found";
                                                $response['data'] = $data_list;
                                                $response['view'] = view("Modules\MigrateFlow\Views\data_migration", $data);
                                        } 
                                        else 
                                        {
                                                $response['code'] = 404;
                                                $response['message'] = "No Data found";
                                        }
                                } 
                                else 
                                {
                                        $response['code'] = 405;
                                        $response['message'] = "Not connected to the server";
                                }

                                echo json_encode($response);
                        }
                }
        }

        private function analyze_compare_table($target_table_name, $source_table, $target_table)
        {
                $dbconnection = $this->connect_db($_SESSION['target_db']);
                $total_source = count($source_table);
                $i = 0;

                $target_array = array();

                foreach ($target_table as $target) 
                {
                        array_push($target_array, $target->Field);
                }

                foreach ($source_table as $source) 
                {

                        if (!in_array($source->Field, $target_array)) 
                        {
                                //                                    var_dump($source->Field);
                                $success = $dbconnection->alter_table($target_table_name, $source);
                                //                        
                                //                                        if($success)
                                //                                        {
                                //                                               $i++; 
                                //                                        }
                                //                                        else
                                //                                        {
                                //                                               $i++;
                                //                                        }
                        } 
                        else 
                        {
                                //reject the alter command
                                $i++;
                        }
                }
                return $i;
        }

        private function connect_db($dbsettings)
        {
                $this->migrationModel = new MigrateFlowModel($dbsettings);
                if ($this->migrationModel->is_connected()) 
                {
                        if ($dbsettings['dbtype'] == "sourcedb") 
                        {
                                $_SESSION['source_db'] = $dbsettings;
                        } 
                        elseif ($dbsettings['dbtype'] == "targetdb") 
                        {
                                $_SESSION['target_db'] = $dbsettings;
                        }
                        return $this->migrationModel;
                } 
                else 
                {
                        if ($dbsettings['dbtype'] == "sourcedb") 
                        {
                                $_SESSION['source_db'] = NULL;
                        } 
                        elseif ($dbsettings['dbtype'] == "targetdb") 
                        {
                                $_SESSION['target_db'] = NULL;
                        }
                        return $this->migrationModel;
                }
        }

        public function backup_data($type=null, $year = null)
        {
                $this->source_migration_model = new BackupModel('ikwook_logiref_transact_test');
                $this->target_migration_model = new BackupModel('ikwook_logiref_reporting_test');

                $tables_from_db = $this->source_migration_model->get_table_list("ikwook_logiref_transact_test");

                $new_tables=array();
                
                $tables=$this->source_migration_model->get_hardcoded_table_list();
               
                foreach($tables_from_db as $table)
                {
                        if(array_key_exists($table->Tables_in_ikwook_logiref_transact_test, $tables))
                        {
                            
                                $table_obj=array(
                                    $table->Tables_in_ikwook_logiref_transact_test=>$tables[$table->Tables_in_ikwook_logiref_transact_test]
                                );
                                array_push($new_tables, $table_obj);
                        }    
                }
                
                foreach ($new_tables as $new_table)
                {
                        $actual_table=key($new_table);
                        $conditions=$new_table[key($new_table)];
                }

                $status=false;
                
                if ($type == "all_tables") 
                {
                        foreach ($new_tables as $table) 
                        {
                                $actual_table=key($table);
                                $conditions=$table[key($table)];
                              
                                $data_list = $this->source_migration_model->get_all_data($actual_table,$conditions,'migrate');

                                if (!empty($data_list)) 
                                {
                                        $log_data="------------- Debut insertion et migration des données d'hier -----------";
                                        $return = $this->target_migration_model->insert_batch_data($actual_table,$data_list);
                                        if($return){
                                            $log_data.= json_encode($data_list);  
                                        }
                                        $log_data.="------------- Fin insertion -----------";
                                        $this->source_migration_model->save_log($log_data, "backup");
                                            
                                }
                                
                        }
                } 
                elseif ($type == "clean_up") 
                {
                    
                        foreach ($new_tables as $table) 
                        {
                                $actual_table=key($table);
                                $conditions=$table[key($table)];
         
                                $data_list = $this->source_migration_model->get_all_data($actual_table,$conditions,'clean_up');

                                if (!empty($data_list)) 
                                {
                                        
                                        foreach ($data_list as $data) 
                                        {
                                                $data_to_array = (array)$data;
                                                $log_data="------------- Debut du clean up -----------";
                                                $checked=$this->target_migration_model->check_if_data_exist($actual_table, $data_to_array['Id_0']);
                                                if($checked==null)
                                                {
                                                        $status = $this->target_migration_model->insert_into_database($actual_table, $data_to_array);
                                                        if($status)
                                                        {
                                                              $this->source_migration_model->delete_data($actual_table, $data_to_array['Id_0']);
                                                              $log_data.= json_encode($data_to_array);
                                                        }  
                                                }
                                                else
                                                {
                                                        $this->source_migration_model->delete_data($actual_table, $data_to_array['Id_0']);
                                                        $log_data.= json_encode($data_to_array);
                                                }
                                                $log_data.="------------- Fin de clean up -----------";
                                                $this->source_migration_model->save_log($log_data, "clean up");
                                        }
                                }
                                
                        }
                    
                }
        }
        
}
