<?php
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */
namespace Modules\MigrateFlow\Models;

/**
 * Description of MY_Migration_Model
 *
 * @author macbookpro
 */
class BackupModel 
{
    
        private $dbConnection=null;
        
        public function __construct($database_name) 
        {
                
//                $this->DBGroup="$database";
//
//                if (isset($this->db)) {
//                        $this->db->close();
//                        $this->db = NULL;
//                }
//                $this->db = Database::connect($this->DBGroup);
                
//                if($environnement=="cloud"){
                $server="localhost";
                $dbname=$database_name;
                $username="root";
                $password="root";
//                }
//                else{
//                    $server="localhost";
//                    $dbname="ikwook_logiref_reporting_test";
//                    $username="root";
//                    $password="root";
//                }
//            
                try
                { 
                        $this->dbConnection = new \PDO("mysql:host=$server;dbname=$dbname",$username ,$password);
                        $this->connected=true;
                } 
                catch (\PDOException $ex) 
                {
                        $this->connected=false;
                }  
        }

//        public function insert_data($data) {
//                $this->set_table("logiref_paiements_tresor", "Id_0", "Id_0 ASC");
//                return $this->saveData($data);
//        }
//
//        public function get_all_data(){
//                $this->set_table("logiref_paiements_tresor", "Id_0", "Id_0 ASC");
//                return $this->get_by("Status_2=1");
//        }
//
//        public function delete_data($id) {
//                $this->set_table("logiref_paiements_tresor", "Id_0", "Id_0 ASC");
//                return $this->delete($id);
//        }
        public function get_table_list($database){
                try
                {
                        $sql="SHOW TABLES FROM $database";
                        $query=$this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                        $results=$query->fetchAll();
                } 
                catch (\PDOException $ex) 
                {
                        $ex->getTrace();
                }
                return $results;
        }
        
        public function get_hardcoded_table_list(){
                $yesterday= date("Y-m-d", strtotime("-1 day"));
                $tables=array(
                            'logiref_paiements_propres'=>"Status_2=3 AND Checkerid_10!=0 AND Validation_36=$yesterday",
                            'logiref_paiements_tresor'=>"Status_2=3 AND Checkerid_10!=0 AND Validation_36=$yesterday",
                            'logiref_integration_sydonia'=>"Status_2=4 AND Integration_16=$yesterday",
                            'logiref_sydonia_prepayments'=>"Status_2=4 AND Date_1=$yesterday",
                            'logiref_sydonia_isys'=>"Status_2=1",
                            'logiref_prepayments_traitements'=>"Status_2=1",
                            'logiref_integration_sftp'=>"Status_2=2",
                            'logiref_integration_sydonia_batchs'=>"Status_2=2",                 
                            "logiref_cbs_instructions_dgda"=>"Status_2=2",
                            "logiref_cbs_instructions_dgi"=>"Status_2=2",
                            "logiref_cbs_instructions_dgrad"=>"Status_2=2",
                            "logiref_cbs_instructions_invoice_occ"=>"Status_2=2",
                            "logiref_cbs_instructions_invoice_occ_regul"=>"Status_2=2",
                            "logiref_cbs_instructions_licence"=>"Status_2=2",
                            "logiref_cbs_instructions_provision"=>"Status_2=2",
                            "logiref_cbs_instructions_seguce"=>"Status_2=2",
                            "logiref_rbo_cbs_instructions_dgda"=>"Status_2=2",
                            "logiref_rbo_cbs_instructions_dgi"=>"Status_2=2",
                            "logiref_rbo_cbs_instructions_dgrad"=>"Status_2=2"
                    );
                return $tables;
        }
        
        public function get_all_data($table,$conditions=null,$action=null)
        {
                try
                {
                        if($action=="clean_up")
                        {
                                $sql="SELECT * FROM $table WHERE $conditions AND (Date_1 < CURDATE() - INTERVAL 90 DAY)"; 
                        }
                        else
                        {
                                $yesterday=date('Y-m-d', strtotime('-1 day'));

    //                            $sql="SELECT * FROM $table WHERE $conditions AND Date_1=$yesterday"; 
                                $sql="SELECT * FROM $table WHERE $conditions"; 
                        }
                        
                        $query = $this->dbConnection->query($sql, \PDO::FETCH_ASSOC);
                        $results = $query->fetchAll();                         

                        return $results;
                } 
                catch (\PDOException $ex) 
                {
                        return null;
                        $ex->getTrace();
                }
        }
        
        function check_if_data_exist($table,$id){
               try
                {

                        $sql="SELECT * FROM $table WHERE Id_0=:id"; 

                        $query = $this->dbConnection->prepare($sql);
                        $query->bindParam(":id", $id);
                        $query->execute();
                        $result = $query->fetch();                         

                        return $result;
                } 
                catch (\PDOException $ex) 
                {
                        return null;
                        $ex->getTrace();
                }
        }
        
        function insert_into_database(string $table, array $data): bool {
                try 
                {
                        // Extract column names and values
                        $columns = array_keys($data);
                        $placeholders = array_map(fn($col) => ":$col", $columns);

                        // Build the SQL query
                        $sql = "INSERT INTO $table (" . implode(", ", $columns) . ") 
                                VALUES (" . implode(", ", $placeholders) . ")";

                        // Prepare the statement
                        $stmt = $this->dbConnection->prepare($sql);

                        // Bind values
                        foreach ($data as $key => $value) {
                            $stmt->bindValue(":$key", $value);
                        }

                        // Execute the query
                        return $stmt->execute();
                } 
                catch (Exception $e) 
                {
                        // Log or handle error
                        error_log("Database Error: " . $e->getMessage());
                        return false;
                }
        }
        function insert_batch_data($table,$data){
                // Ensure we have data to insert
                
                if (empty($data)) 
                {
                        echo "No data to insert!";
                        return;
                }

                // Get the columns from the first row
                $columns = array_keys($data[0]);

                // Prepare the column names for the insert statement
                $columnsString = implode(',', $columns);

                // Prepare placeholders for the values
                $placeholders = rtrim(str_repeat('?,', count($columns)), ',');

                // Prepare the SQL query
                $sql = "INSERT INTO $table ($columnsString) VALUES ($placeholders)";
                $stmt = $this->dbConnection->prepare($sql);

                // Start a transaction for efficiency
                $this->dbConnection->beginTransaction();

                try {
                        // Loop through each row of data and execute the prepared statement
                        foreach ($data as $row) 
                        {
                                $checked=$this->check_if_data_exist($table, $row['Id_0']);
                                if($checked==null)
                                {
                                        $stmt->execute(array_values($row));  // Insert the values of the row
                                }    
                        }

                        // Commit the transaction
                        $this->dbConnection->commit();
                        return true;
                } 
                catch (PDOException $e) 
                {
                        // If something goes wrong, roll back the transaction
                        $this->dbConnection->rollBack();
                        return false;
    //                    echo "Batch insert failed: " . $e->getMessage();
                }
        }
        
        public function delete_data($table,$id)
        {
                try 
                {
                     
                        // Build the SQL query
                        $sql = "DELETE FROM $table WHERE Id_0=:id";

                        // Prepare the statement
                        $stmt = $this->dbConnection->prepare($sql);

                        // Bind values
                        $stmt->bindValue(":id", $id);
                        // Execute the query
                        return $stmt->execute();
                } 
                catch (Exception $e) 
                {
                        // Log or handle error
                        error_log("Database Error: " . $e->getMessage());
                        return false;
                }
        }
        
       
        
        //Save Log
        public function save_log($data, $prefix = NULL)
        {
                $name = gmdate('Y-m-d')."_".$prefix;
                
                $path = APPPATH . "Modules/Services/Logs/Backup_reporting";
                
                if (is_dir($path)==false)
                {
                        mkdir($path,0777,true);
                }
                
                $path = $path."/".$name;
                
                $handle = fopen($path.".logs", 'a+');
//                $data = gmdate('Y-m-d H:s:i')."-------------------------------------------------\n".$data;
                fwrite($handle, $data);   
                fclose($handle);
        }
    
}
