<?php
namespace Modules\MigrateFlow\Models;

use Exception;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of MigrateFlowModel
 *
 * @author macbookpro
 */
class MigrateFlowModel{
    //put your code here
    private $dbConnection=null;
    private $connected=false;
    
    public function __construct($dbsettings) {
            try
            {
                $connection=$dbsettings['connection'];
                $dbusername=$dbsettings['username'];
                $dbpassword=$dbsettings['password'];
                
                $db = isset($dbsettings['dbname'])?$dbsettings['dbname']:"";
                $dbname=isset($dbsettings['dbname'])? ";dbname=$db":"";
                
                $this->dbConnection = new \PDO("mysql:host=$connection$dbname",$dbusername , $dbpassword);
                $this->dbConnection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                $this->connected=true;
            } 
            catch (\PDOException $ex) {
                $this->connected=false;
            }  
    }

    public function get_database_list() {
            try{
                $sql="SHOW DATABASES";
                $query=$this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results=$query->fetchAll();
            } catch (\PDOException $ex) {
                $ex->getTrace();
            }
            return $results;
    }
    
    public function get_table_list($database) {
            try{
                $sql="SHOW TABLES FROM $database";
                $query=$this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results=$query->fetchAll();
            } catch (\PDOException $ex) {
                $ex->getTrace();
            }
            return $results;
    }
    
    public function get_table_structure($table){
            try{
                $sql="DESCRIBE $table";
                $query = $this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results = $query->fetchAll();
                return $results;
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
           
    }
    
    public function get_table_meta_data($database,$table){
            try{
                $sql="SELECT * FROM COLUMNS WHERE COLUMNS.TABLE_SCHEMA=$database AND TABLE_NAME=$table";
                $query = $this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results = $query->fetchAll();
                return $results;
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
    }




    public function get_table_data($table)
    {
            try{
                $sql="SELECT * FROM $table";
                $query = $this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results = $query->fetchAll();                         

                return $results;
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
    }

    public function count_data($table)
    {
            try{
                $sql_count="SELECT COUNT(*) FROM $table";
                $queryC = $this->dbConnection->query($sql_count, \PDO::FETCH_OBJ);
                $count=$queryC->fetchColumn();
                    
                return $count;    
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
    }


    public function get_table_data_by_chunks($table,$offset=null)
    {
            try{
                $limit = 1000;
                $query_offset = $limit * $offset;
     
                $sql="SELECT * FROM $table LIMIT $limit OFFSET $query_offset";
                   
                $query = $this->dbConnection->query($sql, \PDO::FETCH_OBJ);

                $data_list=$query->fetchAll();
                    
                return $data_list;    
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
    }

    function insert_into_database(string $table, array $data): bool {
            // Turn on error reporting
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            
            try {
                // Extract column names and values
                $columns = array_keys($data);
                $placeholders = array_map(fn($col) => ":$col", $columns);

                // Build the SQL query
                $sql = "INSERT INTO $table (" . implode(", ", $columns) . ") 
                        VALUES (" . implode(", ", $placeholders) . ")";

                // Prepare the statement
                $stmt = $this->dbConnection->prepare($sql);

                // Bind values
                foreach ($data as $key => $value) {
                    $stmt->bindValue(":$key", $value);
                }

                // Execute the query
                return $stmt->execute();
            } catch (Exception $e) {
                // Log or handle error
                error_log("Database Error: " . $e->getMessage());
                echo $e->getMessage();
                return false;
            }
    }

    public function is_connected() {
        return $this->connected;
    }
    
    public function alter_table($table,$fields){
            try{
                $sql="ALTER TABLE $table ADD COLUMN ".$fields->Field."  ".$fields->Type."  ".(($fields->Null="No")?" NOT NULL SET DEFAULT ".$fields->Default:" NULL")." ".((isset($fields->Key) || $fields->Key=="PRI"))." PRIMARY KEY "."  ".$fields->Extra."  ";
                $this->dbConnection->exec($sql);
                return true;
            } catch (\PDOException $ex) {
                return false;
                $ex->getTrace();
            }
    }
    
    public function check_if_table_exists($table)
    {
            try{
                $sql="SHOW TABLES LIKE '$table'";
                $query = $this->dbConnection->query($sql, \PDO::FETCH_OBJ);
                $results = $query->fetchAll();
                return $results;
            } catch (\PDOException $ex) {
                return null;
                $ex->getTrace();
            }
    }
    
    public function create_new_table($table)
    {
        // Turn on error reporting
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
           
            try{

                $sql="CREATE TABLE IF NOT EXISTS ".$table['table_name']." (".$table['table_fields'].");";

                $this->dbConnection->exec($sql);
                return true;
            } catch (\PDOException $ex) {
                
                echo $ex->getMessage();
                
                return false;

                $ex->getTrace();
            }
    }
    
    public function get_all_data_to_backup(){
        
    }
    
    
}
