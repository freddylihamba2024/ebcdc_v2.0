<style>
    .display_none
    {
        display: none;
    }
    .btn_single_migrate_container
    {
        border-radius: 10px;
    }
    .btn_single_migrate_container span
    {
        background-color: rgba(0,0,0,0.2);
        padding: 10px 20px;
        border-radius: 10px 0px 0px 10px;
        font-weight: bold;
        font-size: 17px;
    }
    .btn_single_migrate_container button
    {
        padding: 10px;
        border-radius: 0px 10px 10px 0px;
        border:none;
        outline: none;
        background-color: sandybrown ;
        color: white;
    }
</style>
<div class="table-list">
    <form id="migration-form">
    <div class="container-fluid">
        <?php $tab_items=(array)$table_list?>
        <div class="row">
            <input type="hidden" name="table_name" id="table_names"/>
            <input type="hidden" name="" id="table" value="<?= $table_db_name ?>"/>
            
            <?php foreach($table_list as $table): ?>
            <?php $tab=(array)$table?>
            
                <div class="col-md-6">
                    <div class="table-list-card" style="border: solid 1px rgba(0,0,0,0.2);margin-top: 15px; padding: 10px; border-radius: 10px; display: flex;justify-content: space-between;align-items: center; ">
                        <div>
                            <h4><?= $tab["Tables_in_$table_db_name"] ?></h4>
                            <input type="hidden" id="data_to_migrate_<?= $tab["Tables_in_$table_db_name"] ?>" name="data_to_migrate[]" value=""/>

                            <input type="hidden" id="page_number_<?= $tab["Tables_in_$table_db_name"] ?>" name="page_number" value=""/>

                            <div class="data-migrate-container d-none" style="display:flex; justify-content: space-between; align-items: center;">
                                <div style="display:flex; justify-content: start; align-items: center;">
                                    <input type="checkbox" id="data_to_migrate_checkbox_<?= $tab["Tables_in_$table_db_name"]?>" name="data_to_migrate[]" value=""/>
                                    &nbsp;&nbsp;
                                </div>
                                <div id="btn_single_migrate_container_<?= $tab["Tables_in_$table_db_name"]?>" class="btn_single_migrate_container display_none">
                                    <span id="data_amount_<?= $tab["Tables_in_$table_db_name"] ?>"></span>

                                    <button type="button" id="data_to_migrate_button_<?= $tab["Tables_in_$table_db_name"] ?>" onclick="migrate_data_single('btn_single_migrate_container_<?= $tab["Tables_in_$table_db_name"]?>','data_to_migrate_<?= $tab["Tables_in_$table_db_name"] ?>','data_to_migrate_button_<?= $tab["Tables_in_$table_db_name"] ?>','page_number_<?= $tab["Tables_in_$table_db_name"] ?>')"><i class="fa fa-sync"></i>&nbsp;Migrate</button>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div> 
                            <span id="loader_<?= $tab["Tables_in_$table_db_name"] ?>"></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <br/>
        <button type="button" class="btn btn-primary" id="btn-next" value="suivant">Suivant&nbsp;<i class="fa fa-chevron-right"></i></button>
        <button type="submit" class="btn btn-success" id="btn-migrate" value="migrate">Migrate Data</button>
     </div>       
    </form>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $("#table_names").val('<?= json_encode($tab_items) ?>');
    });
    
    var data_list=[];
    
    $("#btn-next").on('click',function(){   

            var table_names=$("#table_names").val();
            var table=$("#table").val();

            var table_list=JSON.parse(table_names);

            var this_button=$(this).val();

            if(this_button==="suivant")
            {
                    create_table_structure(table_list,table);
            }
            else if(this_button==="migrate")
            {
                    
            }
            
    });
    $("#migration-form").on('submit',function(e){
            e.preventDefault();
            
            var formData=$(this).serialize();
            
            var url='<?= base_url('migrateflow/action/migration') ?>';
            
            $('#btn-migrate').attr('disabled',true);
            $("#btn-migrate").html("<i class='fa fa-spinner fa-spin'></i>&nbsp;Migrating Data...");
            $.ajax({
             type: 'POST',
             url: url,
             data: formData,
             contentType:'application/json',
             encode: true,
             success: function (response) {
                    var result=JSON.parse(response);
                    $('#btn-next').attr('disabled',true);
                    $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');

                    if(result.code===200)
                    {
                            alert(result.message);
                    }
                    else if(result.code===404)
                    {
                            
                    }
                    $("#btn-migrate").html("Migrate Data");
             },
             error: function (error) {
                 alert('Une erreur est survenue.veuillez reessayer plus tard');
                 $('#btn-next').attr('disabled',false);
                 $('#btn-migrate').attr('disabled',false);
                 $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');
                 $("#btn-migrate").html("Migrate Data");
             }
         });
            
    });
    
    function get_migration_data_from_list(id)
    {
        return data_list.filter((value,index)=>{
            return value.id===id;
        })
    }

    function migrate_data_single(container,obj,e,page_number)
    {
            var input_data=$(`#${obj}`).val();

            var data=get_migration_data_from_list(obj);

            var cont=$(`#${container}`);
            var btn=$(`#${e}`);

            var pages=$(`#${page_number}`).val();

            btn.attr('disabled',true);
            btn.html("<i class='fa fa-spinner fa-spin'></i>&nbsp;&nbsp;Migration in progress...");
            
            var request_data={table:data[0].table,table_data:data[0].table_data,page_number:pages};

            var url='<?= base_url('migrateflow/action/single_migrate') ?>';
            
            $.ajax({
                type: 'POST',
                url: url,
                data: JSON.stringify(request_data),
                contentType: 'application/json',
                success: function (response) {
                        var result=JSON.parse(response);
                        if(result.code===200)
                        {
                                
                                btn.attr('disabled',true);
                                btn.html(result.message);
                                btn.css('background-color','rgba(0,0,0,0.2)');
                        }
                        else if(response.code===503)
                        {
                                btn.attr('disabled',true);
                                btn.html("<i class='fa fa-sync'></i>&nbsp;Migrate");
                        }

                },
                error: function (error) {
                    alert('Une erreur est survenue.veuillez reessayer plus tard');
                    btn.attr('disabled',false);
                    btn.html("<i class='fa fa-sync'></i>&nbsp;Migrate");
                }
            })
            
            
    }
    
    function create_table_structure(table_list,table)
    {
            var url='<?= base_url('migrateflow/action/create_table_structure') ?>';
            
            $.each(table_list,function(index,value){

                    var data={table_name:value[`Tables_in_${table}`]};

                    $(`#loader_${value[`Tables_in_${table}`]}`).removeClass('display_none');
                    $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-spinner fa-1x fa-spin"></i>');
                    
                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function (response) {
                          
                                var result=JSON.parse(response);
                                $('#btn-next').attr('disabled',true);
                                $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');

                                if(result.code===200)
                                {
                                        $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-check text-success"></i>');

                                        $(`#data_amount_${value[`Tables_in_${table}`]}`).html(result.data_length);

                                        
                                        var newData=new Object();
                                        newData.id="data_to_migrate_"+value[`Tables_in_${table}`];
                                        newData.table=value[`Tables_in_${table}`];
                                        newData.table_data=result.data;

                                        data_list.push(newData);
                                        
                                        var data_list_json=JSON.stringify(data_list);
                                        
                                        $("#table_names").val(data_list_json);
                                        
                                        $(`#btn_single_migrate_container_${value[`Tables_in_${table}`]}`).removeClass("display_none");
                                        $(`#data_to_migrate_${value[`Tables_in_${table}`]}`).val(JSON.stringify(newData));
                                        $(`#page_number_${value[`Tables_in_${table}`]}`).val(result.pagination_number);

                                        $(`#data_to_migrate_button_${value[`Tables_in_${table}`]}`).removeClass("display_none");
                                        $(`#data_to_migrate_checkbox_${value[`Tables_in_${table}`]}`).val(JSON.stringify(newData));
                                        $(`#data_to_migrate_checkbox_${value[`Tables_in_${table}`]}`).attr('checked',true);
                                }
                                else if(result.code===404)
                                {
                                        $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-check text-success"></i>');
                                        $(`#data_amount_${value[`Tables_in_${table}`]}`).html(result.data.length);
                                }

                        },
                        error: function (error) {
                            alert('Une erreur est survenue.veuillez reessayer plus tard');
                            $(`#loader_${value[`Tables_in_${table}`]}`).addClass('display_none');
                            $('#btn-next').attr('disabled',false);
                            $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');
                        }
                    });

            });
    }
    
    function migrate_data(table_list)
    {
            var url='<?= base_url('migrateflow/action/batch_migrate') ?>';
        
            $.each(table_list,function(index,value){

                    var data={table_name:value[`Tables_in_${table}`]};

                    $(`#loader_${value[`Tables_in_${table}`]}`).removeClass('display_none');
                    $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-spinner fa-1x fa-spin"></i>');
                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        dataType: 'html',
                        encode: true,
                        success: function (response) {


                                var result=JSON.parse(response);
                                $('#btn-next').attr('disabled',false);
                                $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');

                                if(result.code===200)
                                {
                                        $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-check text-success"></i>');
                                        $(`#data_amount_${value[`Tables_in_${table}`]}`).html(result.data.length);

                                }
                                else if(result.code===404)
                                {
                                        $(`#loader_${value[`Tables_in_${table}`]}`).html('<i class="fa fa-check text-success"></i>');
                                        $(`#data_amount_${value[`Tables_in_${table}`]}`).html(result.data.length);
                                }

                        },
                        error: function (error) {
                            alert('Une erreur est survenue.veuillez reessayer plus tard');
                            $(`#loader_${value[`Tables_in_${table}`]}`).addClass('display_none');
                            $('#btn-next').attr('disabled',false);
                            $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');
                        }
                    });

            });
    }
</script>