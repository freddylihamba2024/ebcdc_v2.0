<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="<?= base_url('ikwook_bootstraps/v5/css/bootstrap.min.css') ?>"/>
        <link rel="stylesheet" href="<?= base_url('ikwook_bootstraps/inspinia/font-awesome/css/fontawesome-all.min.css') ?>"/>
        <link rel="stylesheet" href="<?= base_url('ikwook_bootstraps/styles/migrate-flow-style.css') ?>"/>
    </head>
    <body>
    <div class="migrate-page-header">
        <div class="container-fluid">
            <span class="page-header-title">MigrateFlow</span>
        </div>

    </div>
    <div class="migrate-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="source-db-wrapper">
                        <h4>Source Database SERVER</h4>
                        <br/>
                        <form class="form" id="source_db_form">
                            <div class="form-group">
                                <table>
                                    <tr>
                                        <td>
                                            <input type="text" class="form-control" name="dbhost" placeholder="DB Host IP ADDRESS/ Hostname"/>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control input-group-append" name="dbusername" placeholder="DB Username"/>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control input-group-append" name="dbpassword" placeholder="DB Password"/>
                                            <input type="hidden" name="dbtype" value="sourcedb"/>
                                        </td>
                                        <td>
                                            <button type="button" id="btn-db-connect-source-db" class="btn btn-primary btn-sm" value="dbconnect" onclick="dbconnect(this, 'source_db')"><i class="fa fa-database"></i>&nbsp;Test Connection</button>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <p id="btn-db-connect-source-db_connection_message"></p>
                            <input type="hidden" id="btn-db-connect-source-db_connection_status" class="connection_status" name="connectionStatus"/>
                            <div class="form-group">
                                <select class="form-control" id="btn-db-connect-source-db_dbsource_db_select" onchange="select_db(this,'source_db')">
                                    <option value="">--- Choose a database ---</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <table class="table">
                                    <tr>
                                        <td>
                                            <p id="btn-db-connect-source-db_dbsource_db_select_table_description"></p>
                                            <h5>DB Tables</h5>
                                            <div class="db-table-container">
                                                <select id="btn-db-connect-source-db_dbsource_db_select_table_select" class="table_select">
                                                    <option value="">--- Table list ---</option>
                                                </select>
                                                <!--                                                    <ul id="source_tables">
                                                                                                    <li><a href="">Logiref_users</a></li>
                                                                                                        <li><a href="">Logiref_accounts</a></li>
                                                                                                    </ul>-->
                                            </div>
                                            <div class="db-table-structure-container">

                                            </div>
                                        </td>   
                                    </tr>
                                </table>
                            </div>
                        </form> 
                    </div>
                    
                    <button id="btn_start_migration" class="btn btn-success" onclick="select_table_structure()"><i class="fa fa-play"></i>&nbsp;&nbsp;Start migration</button>
                    
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="target-db-wrapper">
                        <h4>Target Database SERVER</h4>
                        <br/>
                        <form class="form" id="target_db_form">
                            <div class="form-group">
                                <table>
                                    <tr>
                                        <td>
                                            <input type="text" class="form-control" name="dbhost" placeholder="DB Host IP ADDRESS/ Hostname"/>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control input-group-append" name="dbusername" placeholder="DB Username"/>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control input-group-append" name="dbpassword" placeholder="DB Password"/>
                                            <input type="hidden" name="dbtype" value="targetdb"/>
                                        </td>
                                        <td>
                                            <button type="button" id="btn-db-connect-target-db" class="btn btn-primary btn-sm" value="dbconnect" onclick="dbconnect(this, 'target_db')"><i class="fa fa-database"></i>&nbsp;Test Connection</button>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <p id="btn-db-connect-target-db_connection_message"></p>
                            <input type="hidden" id="btn-db-connect-target-db_connection_status" class="connection_status" name="connectionStatus"/>
                            <div class="form-group">
                                <select class="form-control" id="btn-db-connect-target-db_dbsource_db_select" onchange="select_db(this,'target_db')">
                                    <option value="">--- Choose a target database ---</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <table class="table">
                                    <tr>
                                        <td>
                                            <p id="btn-db-connect-target-db_dbsource_db_select_table_description"></p>
                                            <h5>DB Tables</h5>
                                            <div class="db-table-container">
                                                <select id="btn-db-connect-target-db_dbsource_db_select_table_select" class="table_select">
                                                    <option value="">--- Table list ---</option>
                                                </select>
                                                <!--                                                    <ul id="source_tables">
                                                                                                    <li><a href="">Logiref_users</a></li>
                                                                                                        <li><a href="">Logiref_accounts</a></li>
                                                                                                      </ul>-->
                                            </div>
                                            <div class="db-table-structure-container">

                                            </div>
                                        </td>   
                                    </tr>
                                </table>

                            </div>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo view("Modules\MigrateFlow\Views\data_migration_wizard"); ?>



    <script type="text/javascript" src="<?= base_url('ikwook_bootstraps/v5/js/jquery-3.6.0.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('ikwook_bootstraps/v5/js/bootstrap.min.js') ?>"></script>

    <script type="text/javascript">
    $(document).ready(function () {

    });

    function dbconnect(e, db_type) {

        var btn_connect_id = $(e).attr('id');

        var formData = null;
        if (db_type == "source_db") {
            formData = $("#source_db_form").serialize();
        } else if (db_type == "target_db")
        {
            formData = $("#target_db_form").serialize();
        }


        var connectionURL = '<?= base_url('migrateflow/action/dbconnect') ?>';
        var source_db_select = $(`#${btn_connect_id}_dbsource_db_select`);

        $(`#${btn_connect_id}`).html('<i class"fa fa-sync fa-spin"></i> En cours...');
        $(`#${btn_connect_id}`).attr('disabled', true);

        $(`#${btn_connect_id}_connection_message`).html("");

        source_db_select.append("");

        $.ajax({
            type: 'POST',
            url: connectionURL,
            data: formData,
            dataType: 'html',
            encode: true,
            success: function (response) {
                $(`#${btn_connect_id}`).html('<i class="fa fa-database"></i>&nbsp;Test Connection');
                $(`#${btn_connect_id}`).attr('disabled', false);

                var result = JSON.parse(response);

                $(".connection_status").val(result.status);
                $(`#${btn_connect_id}_connection_message`).html(result.message);


                $.each(result.databases, function (index, value) {
                    source_db_select.append(`<option value="${value.Database}">${value.Database}</option>`);
                });
            },
            error: function (error) {
                $(`#${btn_connect_id}`).html('<i class="fa fa-database"></i>&nbsp;Test Connection');
                $(`#${btn_connect_id}`).attr('disabled', false);
                alert('Une erreur est survenue. veuillez reessayer plus tard');
            }
        });
    }

//            $("#source_db_select").on('change',function(e){
//                    
//                    var source_db = e.target.value;
//                    var connection_status=$(".connection_status").val();
//
//                    var data={database:source_db,connection_status:connection_status};
//                    
//                    var url='<?= base_url('migrateflow/action/show_tables') ?>';
//                    
//                    $table_html='';
//                    $(".db-source-table-select").append("");
//                    $("#source_table_description").html('<i class="fa fa-spin fa-spinner fa-1x"></i>&nbsp; Retrieving the database tables');
//                    $.ajax({
//                    type: 'POST',
//                    url: url,
//                    data: data,
//                    dataType: 'html',
//                    encode: true,
//                    success: function (response) {
//                        
//                        $("#source_table_description").html('');
//                        
//                        if(response!==null){
//                                var result=JSON.parse(response);
//                                $('#source_table_description').html(result.message);
//                                if(result.code===200){
//                                        $.each(result.table_list,function(index,value){
//                                            $(".db-source-table-select").append(`<option value="${value[`Tables_in_${source_db}`]}">${value[`Tables_in_${source_db}`]}</option>`);
//                                        });
//                                }
//                        }
//                    },
//                    error: function (error) {
//                        alert('Une erreur est survenue.veuillez reessayer plus tard');
//                        $("#source_table_description").html('');
//                    }
//                });
//
//            });

    function select_db(e,dbtype) {

        var source_db = $(e).val();
        var select_id = $(e).attr("id");

        var connection_status = $(".connection_status").val();

        var data = {database: source_db,dbtype:dbtype, connection_status: connection_status};

        var url = '<?= base_url('migrateflow/action/show_tables') ?>';

        $table_html = '';
        $(`#${select_id}_table_select`).append("");
        $(`#${select_id}_table_description`).html('<i class="fa fa-spin fa-spinner fa-1x"></i>&nbsp; Retrieving the database tables');
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (response) {

                $(`#${select_id}_table_description`).html('');

                if (response !== null) {
                    var result = JSON.parse(response);
                    $(`#${select_id}_table_description`).html(result.message);
                    if (result.code === 200) {
                        $.each(result.table_list, function (index, value) {
                            $(`#${select_id}_table_select`).append(`<option value="${value[`Tables_in_${source_db}`]}">${value[`Tables_in_${source_db}`]}</option>`);
                        });
                    }
                }
            },
            error: function (error) {
                alert('Une erreur est survenue.veuillez reessayer plus tard');
                $(`#${select_id}_table_description`).html('');
            }
        });

    }

    function select_table_structure() {

        var source_table = $("#btn-db-connect-source-db_dbsource_db_select_table_select").val();
        var target_table = $("#btn-db-connect-target-db_dbsource_db_select_table_select").val();
        
        var source_db = $("#btn-db-connect-source-db_dbsource_db_select").val();
        
        var connection_status = $(".connection_status").val();

        var data = {source_table: source_table, target_table: target_table,source_db:source_db, connection_status: connection_status};
        var url = '<?= base_url('migrateflow/action/table_structures') ?>';
        $('#btn_start_migration').attr('disabled',true);
        $('#btn_start_migration').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;Please wait...');
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (response) {
                $('#btn_start_migration').attr('disabled',false);
                $('#btn_start_migration').html('<i class="fa fa-play"></i>&nbsp;&nbsp;Start migration');
                
                var result=JSON.parse(response);
        
                if(result.code===200)
                {
                        $(".migration-popup").addClass("migration-popup-display");
                        $(".migration-popup .migration_step_body").html(result.view);
                }
                
            },
            error: function (error) {
                alert('Une erreur est survenue.veuillez reessayer plus tard');
                $('#btn_start_migration').attr('disabled',false);
                $('#btn_start_migration').html('<i class="fa fa-play"></i>&nbsp;&nbsp;Start migration');
            }
        });


    }
    
    
    function start_migration(){
            var url = '<?= base_url('migrateflow/action/show_migration_data') ?>';
            
            $.get(url,function(response){
                $(".migration-popup").addClass("migration-popup-display");
                $(".migration-popup .migration_step_body").html(response);
            })
            .fail(function(err){
                alert("Une erreur est survenue au serveur. veuillez reessayer plus tard");
            });    
    }

    function select_table_data(e) {

        var source_table = $(e).val();

        var table_id = $(e).attr("id");

        var connection_status = $(".connection_status").val();

        var data = {table: source_table, connection_status: connection_status};

        var url = '<?= base_url('migrateflow/action/show_table_data') ?>';

//                    $("#source_table_description").html('<i class="fa fa-spin fa-spinner fa-1x"></i>&nbsp; Retrieving the table structure...');
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (response) {

//                        $("#source_table_description").html('');


                if (response !== null) {
                    var result = JSON.parse(response);
                    $('#source_table_description').html(result.message);
                    if (result.code === 200)
                    {
                        $(".migration-popup").addClass("migration-popup-display");

//                                        $.each(result.table_list,function(index,value){
//                                            $(".db-source-table-select").append(`<option value="${source_db}">${value[`Tables_in_${source_db}`]}</option>`);
//                                        });
                    }
                }
            },
            error: function (error) {
                alert('Une erreur est survenue.veuillez reessayer plus tard');
//                        $("#source_table_description").html('');
            }
        });

    }

//            $(".db-source-table-select").on('change',function(e){
//                    
//                     var source_table=e.target.value;
//                    
//                     var connection_status=$("#connection_status").val();
//                    
//                    
//                    var data={table:source_table,connection_status:connection_status};
//                    
//                    var url='<?= base_url('migrateflow/action/show_table_structure') ?>';
//                    
////                    $("#source_table_description").html('<i class="fa fa-spin fa-spinner fa-1x"></i>&nbsp; Retrieving the table structure...');
//                    $.ajax({
//                    type: 'POST',
//                    url: url,
//                    data: data,
//                    dataType: 'html',
//                    encode: true,
//                    success: function (response) {
//                        
////                        $("#source_table_description").html('');
//                        
//                        console.log(response);
//                        
////                        if(response!==null){
////                                var result=JSON.parse(response);
////                                $('#source_table_description').html(result.message);
////                                if(result.code===200){
////                                        $.each(result.table_list,function(index,value){
////                                            $(".db-source-table-select").append(`<option value="${source_db}">${value[`Tables_in_${source_db}`]}</option>`);
////                                        });
////                                }
////                        }
//                    },
//                    error: function (error) {
//                        alert('Une erreur est survenue.veuillez reessayer plus tard');
////                        $("#source_table_description").html('');
//                    }
//                });
//                    
//            });
    $(".btn-close").on('click', function () {
        $(".migration-popup").removeClass("migration-popup-display");
    });
    </script>
</body>
</html>
