<?php
function compare_table_structure($source, $targetField){
        if(!empty($source) || !empty($target)){
                foreach ($source as $s){
                        if($s->Field==$targetField){
                                return '<span class="text-success"><i class="fa fa-check"></i></span>';
                        }
                        
                }
        }
}
?>
<form class="form" id="table_structure_form" method="post">
    <div class="container">
        
        
    <div class="row">
        <div class="col-md-6">
            <div class="table_structure">
                <div class="table_structure_header">
                    Source Table Structure : <?= $table_structure['source_table_name'] ?>
                </div>
                <div class="table_structure_body">
                    <input type="hidden" name="source_table_name" id="source_table_name" value="<?= $table_structure['source_table_name'] ?>"/>
                    <input type="hidden" name="source_table_structure" id="source_table_structure"/>
                    
                    <input type="hidden" name="target_table_name" id="target_table_name" value="<?= $table_structure['target_table_name'] ?>"/>
                    <input type="hidden" name="target_table_structure" id="target_table_structure"/>
                    
                    <ul>
                    <?php foreach ($table_structure['source'] as $source_table):?>
                    
                    <li><?php echo (compare_table_structure($table_structure['target'], $source_table->Field)!=NULL)?compare_table_structure($table_structure['target'], $source_table->Field):"<span class='text-danger'><i class='fa fa-window-close'></i></span>" ?>&nbsp;&nbsp;<?= $source_table->Field ?></li>
                    <?php endforeach; ?>
                    </ul>
                </div>
                
            </div>
            <br/>
            <button type="button" id="btn-next" class="btn btn-primary">Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i></button>
        </div>
        <div class="col-md-6">
            <div class="table_structure">
                <div class="table_structure_header">
                    Target Table Structure : <?= $table_structure['target_table_name'] ?>
                </div>
                <div class="table_structure_body">
                    <?php if(!empty($table_structure['target'])): ?>
                    <ul>
                    
                    <?php foreach ($table_structure['target'] as $target_table):?>
                        <li><?php echo (compare_table_structure($table_structure['source'], $target_table->Field)!=NULL)?compare_table_structure($table_structure['source'], $target_table->Field):"<span class='text-danger'><i class='fa fa-window-close'></i></span>" ?>&nbsp;&nbsp;<?= $target_table->Field ?></li>
                    <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    </div>
</form>
<script type="text/javascript">
    
      $(document).ready(function(){
            $("#source_table_structure").val('<?php echo json_encode($table_structure['source']) ?>');
            $("#target_table_structure").val('<?php echo json_encode($table_structure['target']) ?>');
      });
      
      $("#btn-next").on('click',function(){
          
            var formData=$("#table_structure_form").serialize();
    
            var connection_status = $(".connection_status").val();

            var url = '<?= base_url('migrateflow/action/show_migration_data') ?>';
            
            $('#btn-next').attr('disabled',true);
            $('#btn-next').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;Please wait...');
            
            $.ajax({
                type: 'POST',
                url: url,
                data: formData,
                dataType: 'html',
                encode: true,
                success: function (response) {
                        var result=JSON.parse(response);
                        $('#btn-next').attr('disabled',false);
                        $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');
                        
                        if(result.code===200)
                        {
                            $(".migration-popup").addClass("migration-popup-display");
                            $(".migration-popup .migration_step_body").html(result.view);
                        }
                        
                },
                error: function (error) {
                    alert('Une erreur est survenue.veuillez reessayer plus tard');
                    $('#btn-next').attr('disabled',false);
                    $('#btn-next').html('Suivant&nbsp;&nbsp;<i class="fa fa-chevron-right"></i>');
                }
            });
//            
//            $.ajax({
//            type: 'POST',
//            url: url,
//            data: formData,
//            dataType: 'html',
//            encode: true,
//            success: function (response) {
//                console.log(response);
//            },
//            error: function (error) {
//                alert('Une erreur est survenue.veuillez reessayer plus tard');
//
//            }
//        });
            
      });
</script>

