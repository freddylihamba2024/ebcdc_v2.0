<form class="form" method="post"> 
    
    <div class="data_migration">
        
        <input type="hidden" name="data_to_migrate" id="data_to_migrate"/>
        <input type="hidden" name="target_table_name" id="target_table_name" value="<?= $target_table_name ?>"/>
        <div class="data_migration_container">
            <div class="data_migration_title">
                <span>Source Database : </span><span class="text-danger"><?= $source_database_name ?></span>
                <p><span>Table : </span><span><?= $source_table_name ?></span></p>
            </div>
            <div class="data_migration_body text-center">
                <img src="<?= base_url('ikwook_files/images/database.png') ?>"/>
                <br/>
                <br/>
                <p><b><u>Total Amount of data</u></b></p>
                <span style="background-color: gainsboro; padding: 10px; border-radius: 20px; font-weight: bold; font-size: 18px;"><?= count($data_list) ?></span>
            </div>
        </div>
        <div class="data_migration_progress_container">
            <!-- <p>Total size : <span id="total_size" class="text-danger"></span></p>
            <div class="data_migration_progressbar">
                <div class="data_migration_progress text-center">
                    <span style="color: white; font-weight: bold;" class="progress-text"></span>
                </div>
            </div>-->
            <!--<br/>-->
            <div class="errorMessage"></div>
            <br/>
            <button type="button" id="btn-start-migration" class="btn btn-success"><i class="fa fa-play"></i>&nbsp;&nbsp;Start Migration</button>
        </div>
        <div class="data_migration_container">
            <div class="data_migration_title">
                <span>Target Database : </span><span class="text-danger"><?= $target_database_name ?></span>
                <p><span>Table : </span><span><?= $target_table_name ?></span></p>
            </div>
            <div class="data_migration_body">
                <img src="<?= base_url('ikwook_files/images/target_database.png') ?>"/>
            </div>
        </div>


    </div>

</form>
<script>

    $(document).ready(function () {
        $("#data_to_migrate").val('<?= json_encode($data_list) ?>');
    });

    function start_progress() {
       
    }
    
    $("#btn-start-migration").on('click', function () {

        var progress_bar = $(".data_migration_progress");
        var progress_text = $(".progress-text");

        var data_list = $("#data_to_migrate").val();

        var data = {target_table_name: $("#target_table_name").val(), data_to_migrate: data_list};

        var url = '<?= base_url('migrateflow/action/migration') ?>';

        $('#btn-start-migration').attr('disabled', true);
        $('#btn-start-migration').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;Migration in progress...');
        $(".errorMessage").html("");
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function (response) {
                 var result=JSON.parse(response);
                 $('#btn-start-migration').attr('disabled', true);
                 $('#btn-start-migration').html('<i class="fa fa-play"></i>&nbsp;&nbsp;Start Migration');
                 if(result.code===200)
                 {
                        $(".errorMessage").html(`<span class="text-success">${result.message}</span>`);
                 }
                 else
                 {
                        $(".errorMessage").html(`<span class="text-danger">${result.message}</span>`);
                 }

            },
            error: function (error) {
                alert('Une erreur est survenue.veuillez reessayer plus tard');
                $(".errorMessage").html("");
                $('#btn-start-migration').attr('disabled', false);
                $('#btn-start-migration').html('<i class="fa fa-play"></i>&nbsp;&nbsp;Start Migration');
            }

        });
    });
</script>
