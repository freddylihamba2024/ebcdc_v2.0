<div class="migration-popup">
    <div class="migration-form-container">
        <div class="migration-form-container-header">
            <h4>Data Migration</h4>
            <button type="button" class="btn-close">X</button>
        </div>
        <div class="migration-form-container-body">
            <div class="data_migration_wizard">
                <div class="migration_steps_container">
                    <div class="migration_step">
                        <span class="step_index">1</span>&nbsp;<span class="step_index_label">Table structure</span>
                    </div>
                    <div class="migration_step">
                        <span class="step_index">2</span>&nbsp;<span class="step_index_label">Table Data</span>
                    </div>
                </div>
                <div class="migration_step_body">
                    
                </div>
            </div>
        </div>
    </div>
</div>
