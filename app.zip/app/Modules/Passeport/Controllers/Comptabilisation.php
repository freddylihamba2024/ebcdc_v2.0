<?php

        namespace Modules\Passeport\Controllers;

        use App\Controllers\BaseController;
        use Modules\Passeport\Models\PasseportCurlModel;
        use Modules\Logiref\Models\LogirefModel;

        class Comptabilisation extends BaseController
        {
                public $menus = [];
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'passeport';
                public $application = 'comptabilisation';
                public $folder = 'comptabilisation';
                public $logirefModel;
                public $passeportCurlModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->passeportCurlModel = new PasseportCurlModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = $this->application;
                        $this->data['function'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $_SESSION['userdata']['account_currency'] ?? null;
                        $this->data['fullname'] = $_SESSION['userdata']['user_fname'] ?? null;
                        $this->data['userid'] = $_SESSION['userdata']['user_id'] ?? null;
                        $this->data['accountid'] = $_SESSION['userdata']['account_id'] ?? null;
                        $this->data['bank'] = $_SESSION['userdata']['account_pageid'] ?? null;
                        $this->data['core_banking'] = $_SESSION['userdata']['account_cbs'] ?? null;
                        $this->data['functionalities'] = json_decode($_SESSION['userdata']['options'] ?? '[]', true);
                        $this->data['options'] = $this->data['functionalities'];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Passeport\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function display($obj = NULL, $id = NULL, $data = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "get_details_passeport")
                        {
                                $ref = $id;

                                $result = $this->passeportCurlModel->instructions_passeport(['id' => $ref]);
                                $result = json_decode($result, true);

                                $this->data['lines'] = $result['data']['lines'] ?? [];

                                echo view('\Modules\Passeport\Views\comptabilisation\_comptabilisation_passeport', $this->data);
                        }
                }
        }