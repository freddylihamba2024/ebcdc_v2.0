<?php

        namespace Modules\Passeport\Controllers;

        use App\Controllers\BaseController;
        use Modules\Logiref\Models\LogirefModel;

        class Passeport extends BaseController
        {
                public $menus = array('','','');
                public $role = '5';
                public $group = 'banks'; //Banks, Regies, Clients
                public $tva = 0.16;
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'passeport';
                public $folder = 'passeports';

                public $bank = '';
                public $bank_uppercase = '';
                public $core_banking = '';
                public $functionalities = array();
                public $options = array();
                public $roles = array();
                public $branch = '';

                public $logirefModel;
                public $encaissementModel;
                public $integrationModel;
                public $comptabilisationModel;
                public $accountsModel;
                public $dataModel;
                public $passeportModel;
                public $curlModel;
                public $ratesModel;
                public $amplitude;
                public $amplitudeSolidaireBanque;
                public $comptabilisation;
                public $bsqr;
                public $igor;
                public $flexcube;
                public $synergies;
                public $fiBridge;
                public $finacle;
                public $finacleStandardBank;
                public $logirad;
                public $passeportDataValidator;
                public $passeportDataFormatter;
                public $passeportDataBuilder;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();

                        $this->role = $_SESSION['Logiref_role'];
                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'taxpasseport';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->encaissementModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata['user_id'];
                        $this->data['accountid'] = $account = $this->session->userdata['account_id'];
                        $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                        $this->data['bank'] = $this->bank = $this->session->userdata['account_pageid'];
                        $this->data['core_banking'] = $this->core_banking = $this->session->userdata['account_cbs'];
                        $this->data['i'] = 0;
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Passeport\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if(in_array($needle, $this->menus))
                        {
                                $this->index();
                        }
                }

                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "start")
                        {
                                $this->data['step'] = 1;
                                echo view('\Modules\Passeport\Views\\'.$this->folder.'\_passport', $this->data);
                        }
                        elseif ($obj == "verification")
                        {
                                $payload['Reference_8'] = trim($_POST['Reference_8']  ?? "");
                                $payload['Account']     = $_SESSION['userdata']['account_id'] ?? "";
                                $payload['Branchid']    = $_SESSION['Logiref_guichet'] ?? "";
                                $payload['Agence']      = $_SESSION['Logiref_agence'] ?? "";
                                $payload['Makerid']     = $_SESSION['userdata']['user_id'] ?? '';

                                $response = $this->curl(base_url('services/passeportVerification/verification_notes'), 'POST', $payload);
                                $result = json_decode($response, true);

                                if (!is_array($result))
                                {
                                        echo json_encode(['code' => 'E500', 'message' => 'Impossible de joindre le service de vérification.']);
                                        return;
                                }

                                $code = $result['code'] ?? '';
                                $message = $result['message'] ?? '';

                                if ($code !== 'E200')
                                {
                                        echo json_encode(['code' => $code, 'message' => $message ?: 'Erreur de vérification.']);
                                        return;
                                }

                                $data = $result['data'] ?? [];

                                $this->data = array_merge($this->data, $data);

                                // Ensure objects are objects
                                if (isset($this->data['encaissement'])) {
                                $this->data['encaissement'] = (object) $this->data['encaissement'];
                                }
                                if (isset($this->data['note'])) {
                                $this->data['note'] = (object) $this->data['note'];
                                }

                                $html = view('\Modules\Passeport\Views\\' . $this->folder . '\_passport_2', $this->data);
                                echo json_encode(['code' => 'E200', 'data' => array_merge($data, ['html' => $html])]);
                        }
                        elseif($obj == "edit")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = '';
                                $this->data['encaissement'] = $encaissement = $this->passeportModel->get_paiement_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_passport_3', $this->data);
                        }
                        elseif($obj == "preview")
                        {
                                $this->ratesModel->get_exchange_rates();
                                $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logirefModel->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] !="")?$_GET['controller']:'';
                                $this->data['from'] = (isset($_GET['from']) && $_GET['from'] !="")?$_GET['from']:'';
                                $this->data['view'] = 'view';
                                $this->data['encaissement'] = $encaissement = $this->passeportModel->get_paiement_info($id);

                                echo view('\Modules\Branch\Views\\'.$this->folder.'\_passport_3', $this->data);
                        }
                        #Default
                        elseif($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                echo view($this->lang . '_denial', $this->data);
                        }
                }

                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        //Nouvel enregistrement
                        //Tables concernées: tresor, integration
                        if($obj == 'initiation')
                        {
                                if( !empty($_POST) && ($_POST['Id_0'] == NULL || $_POST['Id_0'] == "") && ($this->role == 4 || $this->role == 9))//Conditions maker nouveau
                                {
                                        //Récupération des données
                                        $error_code = 0;
                                        $return = $this->passeportModel->get_data_passeport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Formattage des données
                                                $data  = $return['data'];
                                                $return = $this->passeportModel->get_formatage_data_passeport($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        //Traitements spécifiques
                                                        //Comptabilisation
                                                        $data  = $return['data'];

                                                        $check_existing_reference = $this->passeportModel->check_paiement_tresor_passeport_by_reference($data['Noteid_26']);

                                                        if(isset($check_existing_reference['code']) && $check_existing_reference['code']!='E200')
                                                        {
                                                                $data = array();
                                                                $data['Id_0'] = $check_existing_reference['id'];
                                                        }
                                                        else
                                                        {
                                                                //Enregistrement base de données
                                                                $data['Id_0'] = $this->passeportModel->save_paiement_tresor($data);

                                                                if($data['Id_0'] > 0)
                                                                {
                                                                        $debit_mad_instructions = $this->comptabilisation->get_instructions_passeport_mad($data);

                                                                        if(!empty($debit_mad_instructions))
                                                                        {
                                                                                $first_instruction = $this->comptabilisationModel->save_instructions_passeport($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'], 0);

                                                                                if($first_instruction)
                                                                                {
                                                                                        $debit_sequestre_instructions = $this->comptabilisation->get_instructions_passeport_sequestre($data);

                                                                                        $second_instructions = $this->comptabilisationModel->save_instructions_passeport($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                                        if($second_instructions == false)
                                                                                        {
                                                                                                // breakdown instructions not saved
                                                                                                $error_code = 403;
                                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                        }
                                                                                }
                                                                                else
                                                                                {
                                                                                        // first instruction not saved
                                                                                        $error_code = 402;
                                                                                        $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                }
                                                                        }
                                                                        else{
                                                                                $error_code = 406;
                                                                                $error_description = 'Erreur de construction des instructions de comptabilisation MAD';
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        // paiement not saved in the database
                                                                        $error_code = 401;
                                                                        $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                                }
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits d\'initier un paiement, veuillez contacter l\'op&eacute;rateur qui encaisse le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        //Modification enregistrement
                        //Tables concernées: propres, integration
                        elseif($obj == "update")
                        {
                                if( !empty($_POST) && $_POST['Id_0'] > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                                {
                                        //Récupération des données
                                        $error_code = 0;
                                        $return = $this->passeportModel->get_data_passeport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Formattage des données
                                                $data  = $return['data'];
                                                $return = $this->passeportModel->get_formatage_data_passeport($data);

                                                if(isset($return['code']) && $return['code'] == 200)
                                                {
                                                        $data  = $return['data'];

                                                        $data['Id_0'] = $this->passeportModel->update_payment_tresor($data, $data['Id_0']);

                                                        if($data['Id_0'] > 0)
                                                        {
                                                                //Delete former instructions
                                                                $this->comptabilisationModel->delete_instructions_passeport($data['Id_0']);

                                                                $debit_mad_instructions = $this->comptabilisation->get_instructions_passeport_mad($data);

                                                                if(!empty($debit_mad_instructions))
                                                                {
                                                                        $debit_sequestre_instructions = $this->comptabilisation->get_instructions_passeport_sequestre($data);

                                                                        $first_instruction= $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $debit_mad_instructions, $data['Logirefid_4'],0);

                                                                        if($first_instruction)
                                                                        {
                                                                                $second_instructions = $this->comptabilisationModel->save_instructions_dgrad($data['Id_0'], $data, $debit_sequestre_instructions, $data['Logirefid_4'], 1);

                                                                                if($second_instructions == false)
                                                                                {
                                                                                        // breakdown instructions not saved
                                                                                        $error_code = '403';
                                                                                        $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                                }
                                                                        }
                                                                        else
                                                                        {
                                                                                // first instruction not saved
                                                                                $error_code = '402';
                                                                                $error_description = 'Paiement enregistr&eacute; partiellement';
                                                                        }
                                                                }
                                                                else{
                                                                        $error_code = 406;
                                                                        $error_description = 'Erreur de construction des instructions de comptabilisation MAD';
                                                                }
                                                        }
                                                        else
                                                        {
                                                                // paiement not saved in the database
                                                                $error_code = '401';
                                                                $error_description = 'Paiement non enregistr&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                        }
                                                }
                                                else
                                                {
                                                        $error_code = $return['code'];
                                                        $error_description = $return['message'];
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de modifier ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }
                        }
                        //Validation
                        //Tables concernées: propres, integration
                        elseif($obj == "validation")//Conditions maker pour modification
                        {
                                if($id > 0 && ($this->role == 2 || $this->role == 3))//Conditions maker pour modification
                                {
                                        $error_code = 0;
                                        //Formattage des données
                                        $return = $this->passeportModel->get_data_validation_passport($id);

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                //Traitements spécifiques

                                                // Mise à jour du statut de paiement en statut regularisation
                                                // Pour la premiere sequence

                                                //$this->passeport_model->update_payment_validation($id, 5);

                                                $data = $return['data']['firstTrans'];

                                                $core_banking = strtolower($this->core_banking);
                                                $response = $this->{$core_banking}->virement($data);

                                                $result = json_decode($response, true);

                                                if(isset($result['response']) && $result['response'] == 200)
                                                {
                                                        // Mise à jour du statut de paiement en statut en cours
                                                        // Pour la deuxieme sequence
                                                        $this->passeportModel->update_payment_validation($id, 6);

                                                        $data = $return['data']['secondTrans'];

                                                        $core_banking = strtolower($this->core_banking);
                                                        $response = $this->{$core_banking}->virement($data);

                                                        if(isset($result['response']) && $result['response'] == 200)
                                                        {
                                                                // Mise à jour du statut de paiement en statut en cours
                                                                // Pour la confirmation dans Logirad
                                                                $this->passeportModel->update_payment_validation($id, 7);
                                                                //Formattage des données pour la confirmation dans Logirad
                                                                $return = $this->passeportModel->get_data_confirmation_passport();

                                                                if(isset($return['code']) && $return['code'] == 200)
                                                                {

                                                                        $apidata = $return['data'];
                                                                        //$response = $this->logirad->confirm_note_passport($apidata);
                                                                        $response = "E200";

                                                                        if($response == "E200" || $response == "CP200")
                                                                        {
                                                                                // Mise à jour du statut de paiement en statut validE et confirmE
                                                                                $this->passeportModel->update_payment_validation($id, 2);
                                                                        }
                                                                        else
                                                                        {
                                                                                $error_code = $response;
                                                                                $error_description = "Paiement valid&eacute; dans Finacle, Mais la confirmation n'a pas abouti dans Logirad.";
                                                                        }
                                                                }
                                                                else
                                                                {
                                                                        $error_code = $return['code'];
                                                                        $error_description = $return['message'];
                                                                }
                                                        }
                                                        else
                                                        {
                                                                // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                                $this->integrationModel->update_integration_passeport_attempts($id, 1);

                                                                $error_code = $return['code'];
                                                                $error_description = $return['message'];
                                                        }
                                                }
                                                else
                                                {
                                                        // Mettre a jour le champ Attempts_29 dans la table instructions_dgrad
                                                        $this->integrationModel->update_integration_passeport_attempts($id, 0);

                                                        $error_code = $return['code'];
                                                        $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = 'Paiement valid&eacute; partiellement, allez dans le menu r&eacute;gularisation pour le r&eacute;gulariser.';
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $data['Id_0'];
                                                $data_return['message'] = 'Bravo ! paiement enregsitr&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.';
                                        echo json_encode($data_return);
                                }
                        }

                        //Suppression
                        //Tables concernées: propres, integration
                        elseif($obj == "deletion")//Conditions maker pour modification
                        {
                                if($id > 0 && ($this->role == 4 || $this->role == 9))//Conditions maker pour modification
                                {
                                        $error_code = 0;
                                        //Récupération des données
                                        $return = $this->passeportModel->get_data_deletion_passport();

                                        if(isset($return['code']) && $return['code'] == 200)
                                        {
                                                $data = $return['data'];
                                                // Mise à jour du statut de paiement en statut en supprimé
                                                $pid = $this->encaissementModel->update_payment_tresor_passeport($data, $id);

                                                //Traitements spécifiques
                                                if($pid == 0)
                                                {
                                                        $error_code = 404;
                                                        $error_description = 'Paiement non supprim&eacute;, un probl&egrave;me est survenu. Veuillez ressaisir s\'il vous pla&icirc;t.';
                                                }
                                        }
                                        else
                                        {
                                                $error_code = $return['code'];
                                                $error_description = $return['message'];
                                        }

                                        //Return utilisateurs
                                        if($error_code != 0)
                                        {
                                                $data_return['code'] = $error_code;
                                                $data_return['id'] = '';
                                                $data_return['message'] = $error_description;
                                        }
                                        else
                                        {
                                                $data_return['code'] = 200;
                                                $data_return['id'] = $id;
                                                $data_return['message'] = 'Bravo ! paiement suppri&eacute; avec succ&egrave;s.';
                                        }

                                        echo json_encode($data_return);
                                }
                                else
                                {
                                        $data_return['code'] = 403;
                                        $data_return['id'] = '';
                                        $data_return['message'] = 'Vous n\'avez pas les droits de supprimer ce paiement, veuillez contacter l\'op&eacute;rateur qui a initi&eacute; le paiement.';
                                        echo json_encode($data_return);
                                }

                        }
                }
        }