<?php

        namespace Modules\Inv\Controllers;

        use App\Controllers\BaseController;
        use Modules\Inv\Models\InvCurlModel;
        use Modules\Logiref\Models\LogirefModel;

        class Impression extends BaseController
        {
                public $menus = [];
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'inv';
                public $application = 'impression';
                public $folder = 'impression';
                public $logirefModel;
                public $invCurlModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->invCurlModel = new InvCurlModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = $this->application;
                        $this->data['function'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $_SESSION['userdata']['account_currency'] ?? null;
                        $this->data['fullname'] = $_SESSION['userdata']['user_fname'] ?? null;
                        $this->data['userid'] = $_SESSION['userdata']['user_id'] ?? null;
                        $this->data['accountid'] = $_SESSION['userdata']['account_id'] ?? null;
                        $this->data['bank'] = $_SESSION['userdata']['account_pageid'] ?? null;
                        $this->data['core_banking'] = $_SESSION['userdata']['account_cbs'] ?? null;
                        $this->data['functionalities'] = json_decode($_SESSION['userdata']['options'] ?? '[]', true);
                        $this->data['options'] = $this->data['functionalities'];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Inv\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function display($obj = null, $id = null, $arg = null, $param = null)
                {
                        if ($obj === 'attestation_immatriculation')
                        {
                                $payload = $_POST;

                                if ($id !== null) {
                                        $payload['id'] = $id;
                                }

                                $result = $this->invCurlModel->attestation($payload);
                                $response = json_decode($result, true);

                                if (!$this->request->isAJAX() && isset($response['code'], $response['data']['url']) && $response['code'] == 200) {
                                        return redirect()->to($response['data']['url']);
                                }

                                return $this->invCurlModel->respondApiResult($result);
                        }
                        elseif ($obj === 'email_immatriculation')
                        {
                                $payload = $_POST;

                                if ($id !== null) {
                                        $payload['id'] = $id;
                                }

                                $result = $this->invCurlModel->mail($payload);

                                return $this->invCurlModel->respondApiResult($result);
                        }
                        elseif($obj == "schema_immatriculation")
                        {
                                $payload = ['id' => $id];
                                $result = $this->invCurlModel->schemaImmatriculation($payload);
                                $response = json_decode($result, true);

                                if (!$this->request->isAJAX() && isset($response['code'], $response['data']['url']) && $response['code'] == 200) {
                                        return redirect()->to($response['data']['url']);
                                }

                                return $this->invCurlModel->respondApiResult($result);
                        }


                        elseif($obj == "attestation")
                        {
                                //now pass the data//
                                $this->data['typeDoc'] = $this->logiref_model->documents;
                                $this->data['devises'] = $this->logiref_model->devises;
                                $this->data['modes'] = $this->logiref_model->modes;
                                $this->data['months'] = $this->comptabilisation_model->months;
                                $this->data['users'] = $this->main_model->get_dropdown('users');
                                $beneficiaires = $this->data['beneficiaires'] = $this->logiref_model->get_dropdown('regies');
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                                if(empty($encaissement))
                                {
                                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                                }
                                                        
                                # Suite numerique
                                if($id !='')
                                {
                                        $number = '';
                                        $nb = strlen($id);

                                        $iteration = 10 - $nb;

                                        for($i=1; $i<=$iteration; $i++)
                                        {
                                                        $number .= '0';
                                        }
                                        $number = $number.$id;

                                        $this->data['number'] = $number;
                                }
                                $agence = $this->branches_model->get_branches_by_account_id($this->data['encaissement']->Agence_20);
                                
                                $guichet = $this->branches_model->get_guichet_info($this->data['encaissement']->Guichet_21);
                                $this->data['ville'] = (isset($guichet->Ville_7) && $guichet->Ville_7 != NULL)?$guichet->Ville_7:'...................';
                                $this->data['agences'] = (isset($agence->Nom_4) && $agence->Nom_4 != NULL)? $agence->Nom_4:'...................';
                                $recettes = $this->data['recettes'] = $this->logiref_model->get_dropdown('recettes');
                                $services = $this->data['services'] = $this->logiref_model->get_dropdown("services", "DGI", $province=NULL, true);
                                # Display the amaount in letter
                                
                                $montant = number_format($encaissement->Montant_11,2,",","");
                                $contre_valeur = number_format($encaissement->Contrevaleur_22,2,",","");
                                $this->data['number_letter'] = $this->data('number_letter',$montant, $encaissement->Devise_12);
                                $this->data['number_letters'] = $this->data('number_letter', $contre_valeur, "CDF");
                                
                                # Treatment of information returned by the CBS
                                $cbs_return = $this->integration_model->get_cbs_returns($id);
                                if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                                {
                                        $cbs_return = json_decode($cbs_return->Result_6, true);
                                        $this->data['cbs_return'] = $cbs_return;
                                }
                                
                                //creation de qrcode
                                $dir = "./drive/logiref/". $this->session->userdata('account_id')."/". $this->session->userdata('user_id')."/".$beneficiaires['Regies'][$encaissement->Beneficaire_15]."/";
                                if(is_dir($dir)==false)
                                {
                                        mkdir($dir,0777,true);
                                }

                                $service_type =$this->logiref_model->get_dropdown("type_services");
                                if($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27022470")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_taxegardienage', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27421600")
                                {
                                        $modes =$this->encaissement_model->modes;
                                        // Données à envoyer
                                        $data_params['passport_number'] = $encaissement->Typerecette_17;
                                        $data_params['requester_name'] = $encaissement->Designation_14;
                                        $data_params['request_reference'] = $encaissement->Noteid_26;
                                        $data_params['payment_date'] = $encaissement->Date_1;
                                        $data_params['payment_method'] = isset($modes[$encaissement->Mode_19]) ? $modes[$encaissement->Mode_19]:"";
                                        
                                        $encrypted_data = json_encode($data_params);

                                        // Conversion en JSON avant chiffrement
                                        $return_data = $this->data('encrypt_data', $encrypted_data);
                                        
                                        // Génération de l'URL sécurisée
                                        $url = "http://34.133.93.180/qrcode/equitybcdc/preview.php?data=" . urlencode($return_data);
                                        //$params['data'] = $url;
                                        
                                        //$params['data'] = $encaissement->Montant_11. ' USD ' .$encaissement->Typerecette_17. ' '.$encaissement->Designation_14. ' '.$encaissement->Noteid_26;
                                        $params['data'] = $encaissement->Designation_14. ' '.$encaissement->Montant_11. ' USD ' .$encaissement->Noteid_26. ' ' .$encaissement->Datevaleur_31;
                                        $params['level'] = 'H';
                                        $params['size'] = '4';
                                        $this->data['qrcode'] = $params['savename'] = $dir.$this->data['encaissement']->Logirefid_4.'.png';
                                                        
                                        $this->ciqrcode->generate($params);
                                                        
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_passport_agence', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGRAD")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dgrad', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] !="CIS" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="IRPPDR11" && $encaissement->Typerecette_17 =="AMRA")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge_amra', $this->data, true);
                                        
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="DGE" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="IRPPDR11" && $encaissement->Typerecette_17 =="TVA")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="DGE" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="IRPPDR11" && $encaissement->Typerecette_17 !="TVA")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dge_htva', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CDI" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="IRPPDR11")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cdi', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && ($service_type[$encaissement->Service_16] =="DGE" || $service_type[$encaissement->Service_16] =="CDI") && ($encaissement->Typerecette_17 =="IPRIER" || $encaissement->Typerecette_17 =="IRPPDR11"))
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_iprier', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGDA")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_dgda', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CIS" && ($encaissement->Typerecette_17 =="IPRIER" || $encaissement->Typerecette_17 =="IRPPDR11"))
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cis', $this->data, true);
                                }
                                elseif($encaissement->Beneficaire_15 == "DGI" && $service_type[$encaissement->Service_16] =="CIS" && $encaissement->Typerecette_17 !="IPRIER" && $encaissement->Typerecette_17 !="IRPPDR11")
                                {
                                        $html = $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_attestation_cis_amra', $this->data, true);
                                }
                                                        
                                $account_id = $this->session->userdata('account_id');
                                $user_id = $this->session->userdata('user_id');	


                                if($encaissement->Beneficaire_15 == "DGRAD"  && $encaissement->Typerecette_17 =="27421600")
                                {
                                        $dir = "./drive/logiref/".$account_id."/passeport/";
                                }
                                else
                                {
                                        $dir = "./drive/logiref/".$account_id."/";
                                }

                                if (!is_dir($dir)) 
                                {
                                        mkdir($dir, 0777, true);
                                }

                                $pdfFilePath = $dir.$id."_".$user_id."_".time().(($encaissement->Beneficaire_15 == "DGRAD" && $encaissement->Typerecette_17 =="27421600") ? "_passeport.pdf" : ".pdf");
                                
                                //actually, you can pass mPDF parameter on this load() function
                                $pdf = $this->m_pdf->load();
                                $pdf->WriteHTML('',1);
                                $pdf->WriteHTML($html,2);

                                //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                                //I: standard output  D: Download  F: Save on HDD  S: output as string

                                $pdf->Output($pdfFilePath, "F");

                                if($arg !="" && $arg =="payment_order" || $arg =="passport_agence")
                                {
                                        //$pdf->Output($pdfFilePath, "F");
                                        return $pdfFilePath;
                                }
                                
                                $pdf->Output($pdfFilePath, "I");
                                
                                exit;
                        }
                        elseif ($obj == "email_passport") 
                        {
                                $account_id = $this->session->userdata('account_id');
                                $dir        = "./drive/logiref/{$account_id}/passeport/";

                                # Création du dossier si nécessaire
                                if (!is_dir($dir)) mkdir($dir, 0777, true);

                                #Recherche du fichier PDF
                                $files = glob($dir . $id . "_*_passeport.pdf");
                                $pdfFilePath = !empty($files) ? $files[0] : $this->display('attestation', $id, "passport_agence");

                                # Récupération des infos paiement
                                $paiement = $this->encaissement_model->get_paiement_info($id);

                                $date          = strftime('%d/%m/%Y', strtotime($paiement->Datevaleur_31));
                                $email_address = $paiement->Email_54;
                                $customer      = $paiement->Designation_14;
                                $amount        = $paiement->Montant_11;
                                $commission    = $paiement->Commission_23;
                                $currency      = $paiement->Devise_12;
                                $ref_note      = $paiement->Noteid_26;
                                                        $canal         = $paiement->Type_56;

                                # Envoi de l’email
                                $return = $this->mail->mail_send_proof_agence(
                                        $email_address, $customer, 'fr',
                                        $pdfFilePath, 'DGRAD_PASSPORT',
                                        $amount, $commission, $currency,
                                        $ref_note, $date, $canal
                                );

                                //echo $return;

                                #Réponse JSON propre
                                echo json_encode([
                                        'status' => $return ? 1 : 0,
                                        'file'   => $pdfFilePath,
                                        'error'  => $return ? null : 'Échec de l’envoi du mail'
                                ]);

                                exit;
                        }
                        elseif($obj == "export_passport") 
                        { 
                                # Charger les modèles nécessaires
                                $modes = $this->logiref_model->modes;
                                $users = $this->main_model->get_dropdown('users');
                                $guichets = $this->branches_model->get_dropdown("guichets");
                                $status_list = $this->reports_model->status;
                                
                                # On détecte s’il y a un filtrage (POST) ou pas
                                $isFiltered = !empty($_POST['Status_2']) || !empty($_POST['start']) || !empty($_POST['Noteid_26']);

                                if ($isFiltered) 
                                {
                                        # Obtenir les paiements filtrés
                                        $encaissements = $this->reports_model->get_paiements_passport_dgrad();
                                } 
                                else 
                                {
                                        $_POST['start'] = gmdate('Y-m-d');
                                        $_POST['end']   = gmdate('Y-m-d');

                                        # Obtenir les paiements filtrés
                                        $encaissements  = $this->reports_model->get_paiements_passport_dgrad();
                                }
                                                
                                $alphas = range('A', 'Z');
                                $atoz = $alphas[11]; 

                                # load our new PHPExcel library
                                $this->load->library('Excel');
                                $objPHPExcel = new Excel();
                                $objPHPExcel->setActiveSheetIndex(0);
                                $objPHPExcel->getActiveSheet()->setTitle('report_passport');

                                $style4Array = [
                                        'font'  => [
                                        'bold'  => true,
                                        'color' => ['rgb' => '000000'],
                                        'size'  => 12,
                                        'name'  => 'Book Antiqua'
                                        ]
                                ];   

                                $table_columns = ["Date Paiement","Status","Regie","Recette","Client","Email","Note","Montant","Commission","Agence","Operateur"];
                                $column = 0;
                                foreach($table_columns as $field)
                                {
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
                                        $column++;
                                }
                                $objPHPExcel->getActiveSheet()->getStyle('A1:K1')->applyFromArray($style4Array);

                                $erow = 2;
                                $paiements = 0;

                                foreach($encaissements as $row)
                                {
                                        $infos = json_decode($row->Notereference_30);
                                        $operateur = isset($users[$row->Makerid_9]) ? $users[$row->Makerid_9] : '-';
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, $row->Datevaleur_31);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $erow, isset($status_list[$row->Status_2]) ? $status_list[$row->Status_2] : "-");
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $erow, $row->Beneficaire_15);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $erow, $row->Typerecette_17);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $erow, $row->Designation_14);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $erow, (isset($row->Email_54) && $row->Email_54 != "") ? $row->Email_54 : (isset($infos->Email) ? $infos->Email : ''));
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $erow, $row->Noteid_26);
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, $row->Devise_12.' '.number_format($row->Notemontant_28, 2, ",", " "));
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $erow, $row->Devise_12.' '.number_format($row->Commission_23, 2, ",", " "));
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $erow, isset($guichets[$row->Guichet_21]) ? $guichets[$row->Guichet_21] : "-");
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $erow, $operateur);

                                        $paiements += $row->Notemontant_28;
                                        $erow++;
                                }

                                // Ligne total
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $erow, "Montant général");
                                $objPHPExcel->getActiveSheet()->mergeCells("A{$erow}:F{$erow}");
                                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $erow, "USD ".number_format($paiements, 2, ",", " "));

                                for ($col = 'A'; $col <= 'K'; $col++) {
                                        $objPHPExcel->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);
                                }

                                // Envoi du fichier
                                header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
                                header('Content-Disposition: attachment;filename="paiements_passport.xlsx"');
                                header('Cache-Control: max-age=0'); 
                                $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
                                $objWriter->save('php://output');
                        }

                }
        }
