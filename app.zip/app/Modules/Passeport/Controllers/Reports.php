<?php

        namespace Modules\Inv\Controllers;

        use App\Controllers\BaseController;
        use Modules\Inv\Models\InvCurlModel;
        use Modules\Logiref\Models\LogirefModel;

        class Reports extends BaseController
        {
                public $menus = ['passport','paiements_passports','nvalidatedpassport','validatedpassport','passports','nvalidatedpassports'];
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'inv';
                public $application = 'reports';
                public $folder = 'reports';
                public $logirefModel;
                public $invCurlModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->invCurlModel = new InvCurlModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = $this->application;
                        $this->data['function'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $_SESSION['userdata']['account_currency'] ?? null;
                        $this->data['fullname'] = $_SESSION['userdata']['user_fname'] ?? null;
                        $this->data['userid'] = $_SESSION['userdata']['user_id'] ?? null;
                        $this->data['accountid'] = $_SESSION['userdata']['account_id'] ?? null;
                        $this->data['bank'] = $_SESSION['userdata']['account_pageid'] ?? null;
                        $this->data['core_banking'] = $_SESSION['userdata']['account_cbs'] ?? null;
                        $this->data['functionalities'] = json_decode($_SESSION['userdata']['options'] ?? '[]', true);
                        $this->data['options'] = $this->data['functionalities'];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Inv\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "validated_plaques")
                        {
                                $return = $this->invCurlModel->getValidatedImmatriculation();
                                $response = json_decode($return, true);

                                $this->data['beneficiaires'] = $response['data']['beneficiaires'] ?? [];
                                $this->data['guichets'] = $response['data']['guichets'] ?? [];
                                $this->data['regies'] = $response['data']['regies'] ?? [];
                                $this->data['users'] = $response['data']['users'] ?? [];
                                $this->data['operators'] = $response['data']['operators'] ?? [];
                                $this->data['banques'] = $response['data']['banques'] ?? [];
                                $this->data['encaissements_immatriculation'] = $response['data']['encaissements_immatriculation'] ?? [];

                                echo view('\Modules\Inv\Views\reports\validatedImmatric', $this->data);
                        }
                        elseif($obj == "nvalidatedimmatric")
                        {
                                $return = $this->invCurlModel->getNvalidatedImmatriculation();
                                $response = json_decode($return, true);

                                $this->data['beneficiaires'] = $response['data']['beneficiaires'] ?? [];
                                $this->data['encaissements_immatriculation_agence'] = $response['data']['encaissements_immatriculation_agence'] ?? [];
                                $this->data['encaissements_immatriculation_enligne'] = $response['data']['encaissements_immatriculation_enligne'] ?? [];
                                $this->data['guichets'] = $response['data']['guichets'] ?? [];
                                $this->data['users'] = $response['data']['users'] ?? [];

                                echo view('\Modules\Inv\Views\reports\nvalidatedImmatric', $this->data);
                        }

                        elseif($obj == "nvalidatedpassports")
                        {
                                $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                                $this->data['encaissements'] = $this->reportsModel->get_nvalidated_paiements_passports();
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\reports\nvalidatedpassports', $this->data);
                        }
                        elseif($obj == "validatedpassport")
                        {
                                $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                                $this->data['encaissements'] = $this->reportsModel->get_validated_paiements_passports();
                                //$this->data['bulletins'] = $this->integration_model->get_validated_bls();
                                //$this->data['prepayments'] = $this->prepayments_model->get_validated_bls();
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                echo view('\Modules\Branch\Views\reports\validatedpassport', $this->data);
                        }
                        elseif($obj == "passport")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements_agence'] = $this->reportsModel->get_paiements_passport_dgrad();
                                $this->data['encaissements_online'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');

                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                                $this->data['display'] = $obj;

                                echo view('\Modules\Branch\Views\reports\\' . $obj, $this->data);

                        }
                        elseif($obj == "paiements_passports")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements_agence'] = $this->reportsModel->get_paiements_passport_dgrad();
                                $this->data['encaissements_online'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                                $this->data['display'] = $obj;

                                echo view('\Modules\Branch\Views\reports\_paiements_passports', $this->data);
                        }
                        elseif($obj == "filterresult_passports")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;

                                $this->data['encaissements'] = $this->reportsModel->get_paiements_filter_passport_dgrad($id);

                                $_SESSION['encaissements'] = $this->data['encaissements'];
                                $data = array();

                                $this->data['display'] = $obj;
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                                echo view('\Modules\Branch\Views\reports\_filter_passport', $this->data);
                        }

                        elseif($obj == "passports")
                        {
                                echo view('\Modules\Branch\Views\reports\_passports', $this->data);
                        }
                        elseif($obj == "passport_agence")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad();
                                $this->data['status'] = $this->reportsModel->status;
                                $this->data['colors'] = $this->reportsModel->status_color;
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                                $this->data['display'] = "passports";

                                echo view('\Modules\Branch\Views\reports\_passport_agence', $this->data);
                        }
                        elseif($obj == "filter_passport_agence")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad();
                                $this->data['status'] = $this->reportsModel->status;
                                $this->data['colors'] = $this->reportsModel->status_color;
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['display'] = "passports";

                                echo view('\Modules\Branch\Views\reports\_filter_passport_agence', $this->data);
                        }
                        elseif($obj == "passport_online")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                                $this->data['status'] = $this->reportsModel->status;
                                $this->data['colors'] = $this->reportsModel->status_color;
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['types'] = "online";
                                $this->data['display'] = "passports";

                                echo view('\Modules\Branch\Views\reports\_passport_online', $this->data);
                        }
                        elseif($obj == "filter_passport_online")
                        {
                                $this->data['modes'] = $this->logirefModel->modes;
                                $this->data['users'] = $this->mainModel->get_dropdown('users');
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_passport_dgrad('mobile');
                                $this->data['status'] = $this->reportsModel->status;
                                $this->data['colors'] = $this->reportsModel->status_color;
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['display'] = "passports";
                                $this->data['types'] = "online";

                                echo view('\Modules\Branch\Views\reports\_filter_passport_online', $this->data);
                        }

                }
        }