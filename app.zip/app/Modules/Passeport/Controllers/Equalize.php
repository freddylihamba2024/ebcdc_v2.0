<?php

        namespace Modules\Passeport\Controllers;

        use App\Controllers\BaseController;
        use Modules\Passeport\Models\PasseportCurlModel;
        use Modules\Logiref\Models\LogirefModel;

        class Equalize extends BaseController
        {
                public $menus = [];
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'passeport';
                public $application = 'equalize';
                public $folder = 'equalize';
                public $logirefModel;
                public $passeportCurlModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->passeportCurlModel = new PasseportCurlModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = $this->application;
                        $this->data['function'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $_SESSION['userdata']['account_currency'] ?? null;
                        $this->data['fullname'] = $_SESSION['userdata']['user_fname'] ?? null;
                        $this->data['userid'] = $_SESSION['userdata']['user_id'] ?? null;
                        $this->data['accountid'] = $_SESSION['userdata']['account_id'] ?? null;
                        $this->data['bank'] = $_SESSION['userdata']['account_pageid'] ?? null;
                        $this->data['core_banking'] = $_SESSION['userdata']['account_cbs'] ?? null;
                        $this->data['functionalities'] = json_decode($_SESSION['userdata']['options'] ?? '[]', true);
                        $this->data['options'] = $this->data['functionalities'];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Passeport\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
                {
                        if($obj == "unequalizedpassports")
                        {
                                $this->data['beneficiaires'] = $this->logiref_model->get_dropdown("services", $service=NULL);
                                $this->data['encaissements'] = $this->reports_model->get_paiements_passports_to_regulate();
                                //$this->data['bulletins'] = $this->integration_model->get_unvalidated_bls_to_regulate();
                                //$this->data['prepayments'] = $this->prepayments_model->get_unvalidated_bls_to_regulate();
                                $this->data['guichets'] = $this->branches_model->get_dropdown("guichets");
                                $this->data['users'] = $this->main_model->get_dropdown('users_array');

                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/'.$obj, $this->data);
                        }
                        elseif($obj == "passeport")
                        {
                                $this->rates_model->get_exchange_rates();
                                $this->data['services'] =  $this->logiref_model->get_dropdown("services", "DGRAD", $province=NULL, true);
                                $recettes = $this->logiref_model->get_dropdown('recettes',"DGRAD");
                                $this->data['recettes'] = $recettes["DGRAD"];
                                $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_tresor_info($id);
                                if(empty($encaissement))
                                {
                                        $this->data['encaissement'] = $encaissement = $this->encaissement_model->get_paiement_propre_info($id);
                                }

                                $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                                $succes = array();

                                $instructions  = $this->comptabilisation_model->get_instructions_dgrad($logirefid);
                                foreach($instructions as $value):
                                $succes[] = $value->Status_2;
                                endforeach;

                                if(!in_array('3', $succes) && !in_array('1', $succes))
                                {
                                        $this->data['validate'] = '';
                                }
                                else
                                {
                                        $this->data['validate'] = 'disabled';
                                }

                                if(!in_array('2', $succes))
                                {
                                        $this->data['delete'] = '';
                                }
                                else
                                {
                                        $this->data['delete'] = 'disabled';
                                }

                                $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_'.$obj, $this->data);
                        }
                        elseif($obj == "get_details_dgrad")
                        {
                                /* Get data from DB Integration*/
                                $ref = $id;
                                $this->data['lines'] = $this->comptabilisation_model->get_instructions_dgrad($ref);

                                $this->load->view($this->module.'/'.$this->group. '/' . $this->folder.'/_details_dgrad', $this->data);

                                $data = $this->invCurlModel->getDetailsImmatriculation($id);
                                $data = json_decode($data, true);
                                $this->data['lines'] = $data['data']['lines'] ?? [];

                                echo view('\Modules\Inv\Views\equalize\_details_immatriculation', $this->data);
                        }
                }

                public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "validate_passeport")
                        {
                                if ($id > 0 && ($this->role == 2 || $this->role == 3))
                                {
                                        $return = $this->passeport_model->get_data_validation_passport($id);

                                        if (isset($return['code']) && $return['code'] == 200)
                                        {
                                                $transaction = array_keys($return['data']);

                                                if (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[0])
                                                {
                                                        # Cas 1 : première transaction
                                                        $data = $return['data'];
                                                        $data_return = $this->data('get_first_transaction', $data, $id);
                                                }
                                                elseif (isset($_POST['Trans']) && $_POST['Trans'] === $transaction[1])
                                                {
                                                        # Cas 2 : deuxième transaction
                                                        $data = $return['data']['secondTrans'];
                                                        $data_return = $this->data('get_second_transaction', $data, $id, $return['data']);
                                                }
                                                else
                                                {
                                                        $data_return = [
                                                                'code' => 400,
                                                                'id' => '',
                                                                'message' => 'Transaction invalide ou manquante.'
                                                        ];
                                                }
                                        }
                                        else
                                        {
                                                $data_return = [
                                                        'code' => $return['code'],
                                                        'id' => '',
                                                        'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                                ];
                                        }
                                }
                                else
                                {
                                        $data_return = [
                                                'code' => 403,
                                                'id' => '',
                                                'message' => 'Vous n\'avez pas les droits de valider ce paiement, veuillez contacter le validateur.'
                                        ];
                                }

                                echo json_encode($data_return);
                        }
                        elseif($obj == "confirm_note")
                        {
                                if ($id > 0)
                                {
                                        # On appelle directement la confirmation via la méthode data()
                                        $return = $this->data('get_confirmation', null, $id);
                                        echo json_encode($return);
                                }
                                else
                                {
                                        echo json_encode([
                                                'code' => 400,
                                                'id' => '',
                                                'message' => 'Identifiant de paiement manquant ou invalide.'
                                        ]);
                                }
                        }
                }

                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if ($obj == "get_first_transaction")
                        {
                                $first_data  = $data['firstTrans'];
                                $second_data = $data['secondTrans'];
                                $id = $arg;

                                # Statut régularisation (1ère séquence)
                                $this->passeport_model->update_payment_validation($id, 5);

                                # First transaction
                                $response = $this->curl_model->call_bank_virement_passport($first_data);
                                $first_result = json_decode($response, true);

                                if (isset($first_result['response']) && $first_result['response'] == 200)
                                {
                                        # Statut en cours (2ème séquence)
                                        $this->passeport_model->update_payment_validation($id, 6);

                                        # Second transaction
                                        $response = $this->curl_model->call_bank_virement_passport($second_data);
                                        $second_result = json_decode($response, true);

                                        if (isset($second_result['response']) && $second_result['response'] == 200)
                                        {
                                                # Confirmation
                                                return $this->data('get_confirmation', null, $id, $data);
                                        }
                                        else
                                        {
                                                $this->integration_model->update_integration_dgrad_attempts($id, 1);

                                                return [
                                                        'code' => $second_result['response'] ?? 500,
                                                        'id' => '',
                                                        'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                                ];
                                        }
                                }
                                else
                                {
                                        $this->integration_model->update_integration_dgrad_attempts($id, 0);

                                        return [
                                                'code' => $first_result['response'] ?? 500,
                                                'id' => '',
                                                'message' => 'Paiement non validé, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        }
                        elseif ($obj == "get_second_transaction")
                        {
                                $second_data = $data;
                                $id = $arg;

                                # Statut en cours (2ème séquence)
                                $this->passeport_model->update_payment_validation($id, 6);

                                # Second transaction
                                $response = $this->curl_model->call_bank_virement_passport($second_data);
                                $result = json_decode($response, true);

                                if (isset($result['response']) && $result['response'] == 200)
                                {
                                        # Confirmation
                                        return $this->data('get_confirmation', null, $id);
                                }
                                else
                                {
                                        $this->integration_model->update_integration_dgrad_attempts($id, 1);

                                        return [
                                                'code' => $result['response'] ?? 500,
                                                'id' => '',
                                                'message' => 'Paiement validé partiellement, allez dans le menu régularisation pour le régulariser.'
                                        ];
                                }
                        }
                        elseif ($obj == "get_confirmation")
                        {
                                $id = $arg;

                                $this->passeport_model->update_payment_validation($id, 7);

                                $return = $this->passeport_model->get_data_confirmation_passport();

                                if (isset($return['code']) && $return['code'] == 200)
                                {
                                        $apidata = $return['data'];

                                        #Call api confirmation
                                        $response = $this->curl_model->call_dgrad_confirmation_notepassport($apidata);

                                        if ($response == "E200" || $response == "CP200")
                                        {
                                                $this->passeport_model->update_payment_validation($id, 2);

                                                return [
                                                        'code' => 200,
                                                        'id' => $id ?? '',
                                                        'message' => 'Paiement validé dans Finacle et confirmé avec succès dans Logirad'
                                                ];
                                        }
                                        else
                                        {
                                                return [
                                                        'code' => $response,
                                                        'id' => $id ?? '',
                                                        'message' => 'Paiement validé dans Finacle, mais la confirmation n\'a pas abouti dans Logirad.'
                                                ];
                                        }
                                }
                                else
                                {
                                        return [
                                                'code' => $return['code'],
                                                'id' => $id ?? '',
                                                'message' => $return['message']
                                        ];
                                }
                        }
                }

        }