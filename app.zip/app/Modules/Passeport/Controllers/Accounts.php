<?php

        namespace Modules\Passeport\Controllers;

        use App\Controllers\BaseController;
        use Modules\Passeport\Models\PasseportCurlModel;
        use Modules\Logiref\Models\LogirefModel;

        class Accounts extends BaseController
        {
                public $menus = [];
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'passeport';
                public $application = 'accounts';
                public $folder = 'accounts';
                public $logirefModel;
                public $passeportCurlModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->passeportCurlModel = new PasseportCurlModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = $this->application;
                        $this->data['function'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $_SESSION['userdata']['account_currency'] ?? null;
                        $this->data['fullname'] = $_SESSION['userdata']['user_fname'] ?? null;
                        $this->data['userid'] = $_SESSION['userdata']['user_id'] ?? null;
                        $this->data['accountid'] = $_SESSION['userdata']['account_id'] ?? null;
                        $this->data['bank'] = $_SESSION['userdata']['account_pageid'] ?? null;
                        $this->data['core_banking'] = $_SESSION['userdata']['account_cbs'] ?? null;
                        $this->data['functionalities'] = json_decode($_SESSION['userdata']['options'] ?? '[]', true);
                        $this->data['options'] = $this->data['functionalities'];
                        $this->data['i'] = 0;
                        $this->data['deny'] = false;

                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] > 2)
                        {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['sidebar'] = '';
                        }

                        $this->data['subview'] = '\Modules\Passeport\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
                {
                        if ($obj == "get_accountname")
                        {
                                $data = array();

                                $data['compte'] = $_POST['compte'];
                                $data['devise'] = $_POST['devise'];

                                $return = $this->passeportCurlModel->get_accountname($data);
                                $return = json_decode($return, true);

                                if (isset($return['code']) && in_array($return['code'], ['404', '405', '406'], true))
                                {
                                        echo json_encode($return);
                                }
                                else
                                {
                                        if (isset($return['data']['account_name']) && $return['data']['account_name'] != "")
                                        {
                                                echo json_encode($return['data']);
                                        }
                                        else
                                        {
                                                echo '404';
                                        }
                                }
                        }
                        elseif ($obj == "get_customeraccounts")
                        {
                                $data = array();

                                $data['customer_number'] = $_POST['customer_number'];

                                $return = $this->passeportCurlModel->get_customeraccounts($data);
                                $return = json_decode($return, true);

                                if (isset($return['code']) && in_array($return['code'], ['404', '405', '406'], true))
                                {
                                        echo json_encode($return);
                                }
                                else
                                {
                                        if (isset($return['data'][0]['accountNumber']) && $return['data'][0]['accountNumber'] != '')
                                        {
                                                echo json_encode($return['data']);
                                        }
                                        else
                                        {
                                                echo '404';
                                        }
                                }
                        }
                        elseif ($obj == "get_accountinternal")
                        {
                                $data = array();
                                $data['devise'] = isset($_POST['devise']) ? $_POST['devise'] : "";
                                $data['regie'] = isset($_POST['regie']) ? $_POST['regie'] : "";

                                $return = $this->passeportCurlModel->get_accountinternal($data);
                                $return = json_decode($return, true);

                                if (isset($return['code']) && $return['code'] == 200)
                                {
                                        echo json_encode($return['data']);
                                }
                                else
                                {
                                        echo '405';
                                }
                        }
                        elseif ($obj == "get_accountname_internal")
                        {
                                $data = array();
                                $data['compte'] = $_POST['compte'];
                                $data['devise'] = $_POST['devise'];

                                $return = $this->passeportCurlModel->get_accountname_internal($data);
                                $return = json_decode($return, true);

                                if (isset($return['code']) && in_array($return['code'], ['404', '405', '406'], true))
                                {
                                        echo json_encode($return);
                                }
                                else
                                {
                                        if (isset($return['data']) && $return['data'] != "")
                                        {
                                                echo json_encode($return['data']);
                                        }
                                        else
                                        {
                                                echo '405';
                                        }
                                }
                        }
                        elseif ($obj == "get_account_balance")
                        {
                                $data = array();
                                $data['montant'] = $_POST['montant'];
                                $data['commission'] = $_POST['commission'];
                                $data['compte'] = $_POST['compte'];
                                $data['devise'] = $_POST['devise'];
                                $data['devise_compte'] = $_POST['devise_compte'];
                                $data['devise_commission'] = $_POST['devise_commission'];
                                $data['balance'] = $_POST['balance'];

                                $return = $this->passeportCurlModel->get_account_balance($data);
                                $return = json_decode($return, true);

                                if (isset($return['code']) && in_array($return['code'], [200, 300], true))
                                {
                                        echo $return['code'];
                                }
                                else
                                {
                                        echo '411';
                                }
                        }
                        elseif ($obj == "get_account_exemption")
                        {
                                $data = array();
                                $data['compte'] = $_POST['compte'];
                                $data['devise'] = $_POST['devise'];

                                $return = $this->passeportCurlModel->get_account_exemption($data);
                                $return = json_decode($return, true);

                                echo json_encode($return['data']);
                        }
                }
        }