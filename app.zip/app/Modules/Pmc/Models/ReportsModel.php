<?php

    namespace App\Modules\Pmc\Models;

    use CodeIgniter\Model;

    class ReportsModel extends Model
    {
            public function get_all_reports_dashboard($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
            {

            }
            public function get_validated_paiements_permis_by_user($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
            {

            }
            public function get_paiements_permis_to_regulate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
            {

            }
            public function get_nvalidated_paiements_permis($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
            {

            }
    }