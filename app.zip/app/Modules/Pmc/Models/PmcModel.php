<?php

    namespace App\Modules\Pmc\Models;

    use CodeIgniter\Model;

    class PmcModel extends Model
    {
            public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
            {

            }
            public function get_paiement_tresor_permis_by_reference($reference=NULL)
            {

            }
    }