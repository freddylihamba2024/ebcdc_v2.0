<?php

        namespace App\Modules\Permis\Controllers;

        use App\Controllers\BaseController;

        class Reports extends BaseController
        {
                public function __construct()
                {
                        parent::__construct();
                }

                public function index()
                {

                }

                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if ($obj == "nvalidated_permis")
                        {
                                // Permis non validé
                        }
                        elseif ($obj == "validated_permis")
                        {
                                // Permis validé
                        }
                        elseif ($obj == "filterresult_permis")
                        {
                                // Filtrage
                        }
                        elseif($obj == "deny")
                        {

                        }
                }

        }