<?php

namespace App\Modules\Pmc\Controllers;

use App\Controllers\BaseController;

class Permis extends BaseController
{

        public function __construct()
        {
                parent::__construct();
        }

        public function index()
        {

        }

        public function set($needle)
        {

        }

        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "start")
                {

                }
                elseif ($obj == "verification")
                {

                }
                elseif($obj == "edit")
                {

                }
                elseif($obj == "preview")
                {

                }
                elseif($obj == "deny")
                {

                }
        }

        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                //Nouvel enregistrement
                //Tables concernées: tresor, integration
                if($obj == 'initiation')
                {

                }
                //Modification enregistrement
                //Tables concernées: propres, integration
                elseif($obj == "update")
                {

                }
                //Validation
                //Tables concernées: propres, integration
                elseif($obj == "validation")//Conditions maker pour modification
                {

                }

                //Suppression
                //Tables concernées: propres, integration
                elseif($obj == "deletion")//Conditions maker pour modification
                {

                }
                elseif($obj=="confirmation_note")
                {

                }
                //Arret du script
                //Tables concernées: propres, integration
                else
                {

                }
        }
}