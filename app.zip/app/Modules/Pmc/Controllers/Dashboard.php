<?php

        namespace App\Modules\Pmc\Controllers;

        use App\Controllers\BaseController;

        class Dashboard extends BaseController
        {
                public function __construct()
                {
                        parent::__construct();
                }

                public function index()
                {

                }

                public function set($needle)
                {

                }

                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "overview")
                        {

                        }
                }

        }