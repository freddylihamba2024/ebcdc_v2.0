<?php

        namespace App\Modules\Pmc\Controllers;

        use App\Controllers\BaseController;

        class Impression extends BaseController
        {
                public function __construct()
                {
                        parent::__construct();
                }

                public function index()
                {

                }

                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "schema")
                        {

                        }
                        elseif ($obj == "attestation")
                        {

                        }
                        elseif($obj == "deny")
                        {

                        }
                }

        }