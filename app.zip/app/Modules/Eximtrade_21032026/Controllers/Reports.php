<?php

namespace Modules\Eximtrade\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\FeesModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use Modules\Admin\Models\StakeholderModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\ReportsModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\PrepaymentsModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Quitus\Models\QuitusModel;

class Reports extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('taux','encaissements','list','reversements','reports','commissions','penalties','reporting','declarations','gudouane','ordres','nvalidated','validated','transferred','penalities', 'rapport', 'report_agence','report_clients', 'report_users', 'report_bl', 'pending', 'report_paydgda', 'report_dgrad_dgi', 'nvalidated_pepele', 'provision', 'invoices', 'invoice_occ', 'invoices_validated', 'invoices_batchs', 'invoices_occ', 'alerts', 'invoices_paid', 'paid_invoices', 'invoice_occ_batchs', 'exempted_customers', 'nvalidated_occ', 'licences_current', "licences_expire","licence_documents","invoice_license","report_occ","fees_licence","prelevement_filter",'report_notification',"report_customer");
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'eximtrade';
        public $folder = 'reports';
        public $reportsModel;
        public $feesModel;
        public $logirefModel;
        public $integrationModel;
        public $comptabilisationModel;
        public $prepaymentsModel;
        public $dataModel;
        public $accountsModel;
        public $branchesModel;
        public $usersModel;
        public $encaissementModel;
        public $ratesModel;
        public $seguceModel;
        public $stakeholdersModel;
        public $mainModel;
        public $licenceModel;
        public $functionalities;
        public $bank;
        public $core_banking;
        public $quitusModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->reportsModel = new ReportsModel();
                $this->feesModel = new FeesModel();
                $this->logirefModel = new LogirefModel();
                $this->integrationModel = new integrationModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->dataModel = new DataModel();
                $this->accountsModel = new AccountsModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->encaissementModel = new EncaissementModel();
                $this->ratesModel = new RatesModel();
                $this->seguceModel = new SeguceModel();
                $this->stakeholdersModel = new StakeholderModel();
                $this->licenceModel = new LicenceModel();
                $this->quitusModel = new QuitusModel();

                $this->mainModel = new MainModel();
                $this->folder = 'reports';
                $this->data['module'] = $this->module;
                $this->data['application'] = 'reports';
                $this->data['function'] = '';
                $this->data['role'] = $this->session->get('Logiref_role');
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->roles = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }

	}


	public function index()
	{
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
		echo view("layouts/layout_main", $this->data);
	}


        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "validated")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_validated_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                if($obj == "pending") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_validated_paiements_by_user();
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls_by_user();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_validated_bls_by_user();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "transferred") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->integrationModel->get_integrations_isys();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "nvalidated") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_nvalidated_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        
                        $unvalidated = [];
                        
//                        foreach ($this->data['encaissements'] as $row)
//                        {
//                                $payment = new stdClass();
//                                $payment->id = $row->Id_0;
//                                $payment->date = $row->Date_1;
//                                $payment->beneficaire = $row->Beneficaire_15;
//                                $payment->designation = $row->Designation_14;
//                                $payment->recette = $row->Typerecette_17;
//                                $payment->montant = $row->Montant_11;
//                                $payment->devise = $row->Devise_12;
//                                $payment->commision = $row->Commission_23;
//                                $payment->devise_commission = $row->Devise_24;
//                                $payment->contrevaleur = $row->Contrevaleur_22;
//                                $payment->agence = $row->Agence_32;
//                                $payment->user = $row->User_15;
//                                $payment->user = $row->User_15;
//                                
//                                $unvalidated[]= $payment;                        }
//                        
//                        foreach ($this->data['bulletins'] as $row)
//                        {
//                                $bulletin = new stdClass();
//                                $bulletin->id = $row->Id_0;
//                                $bulletin->date = $row->Date_1;
//                                $bulletin->beneficaire = 'DGDA';
//                                $bulletin->designation = $row->Designation_23;
//                                $bulletin->recette = $row->Serie_7.''.$row->Number_8;
//                                $bulletin->montant = $row->Amount_12;
//                                $bulletin->devise = 'CDF';
//                                $bulletin->commision = $row->Commission_26;
//                                $bulletin->devise_commission = $row->Devise_27;
//                                $bulletin->contrevaleur = $row->Amount_12;
//                                
//                                $unvalidated[]= $bulletin;
//                        }
//                        
//                        foreach ($this->data['prepayments'] as $row)
//                        {
//                                $prepayment = new stdClass();
//                                $prepayment->id = $row->Id_0;
//                                $prepayment->date = $row->Date_1;
//                                $prepayment->beneficaire = 'DGDA';
//                                $prepayment->designation = $row->Designation_21;
//                                $prepayment->recette = $row->Serial_9.''.$row->Number_10;
//                                $prepayment->montant = $row->Amount_18;
//                                $prepayment->devise = 'CDF';
//                                $prepayment->commision = $row->Commission_24;
//                                $prepayment->devise_commission = $row->Devise_25;
//                                $prepayment->contrevaleur = $row->Amount_18;
//                                
//                                $unvalidated[]= $prepayment;
//                        }
                        
                        
                        
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
	        elseif($obj == "nvalidated_pepele") 
                {
                        $this->data['beneficiaires'] = array();
                        $this->data['encaissements'] = array();
                        $this->data['bulletins'] = $this->integrationModel->get_ppmobile_unvalidated_bls();
                        $this->data['prepayments'] = array();
                        
                        $unvalidated = [];
                        
//                        foreach ($this->data['encaissements'] as $row)
//                        {
//                                $payment = new stdClass();
//                                $payment->id = $row->Id_0;
//                                $payment->date = $row->Date_1;
//                                $payment->beneficaire = $row->Beneficaire_15;
//                                $payment->designation = $row->Designation_14;
//                                $payment->recette = $row->Typerecette_17;
//                                $payment->montant = $row->Montant_11;
//                                $payment->devise = $row->Devise_12;
//                                $payment->commision = $row->Commission_23;
//                                $payment->devise_commission = $row->Devise_24;
//                                $payment->contrevaleur = $row->Contrevaleur_22;
//                                $payment->agence = $row->Agence_32;
//                                $payment->user = $row->User_15;
//                                $payment->user = $row->User_15;
//                                
//                                $unvalidated[]= $payment;                        }
//                        
//                        foreach ($this->data['bulletins'] as $row)
//                        {
//                                $bulletin = new stdClass();
//                                $bulletin->id = $row->Id_0;
//                                $bulletin->date = $row->Date_1;
//                                $bulletin->beneficaire = 'DGDA';
//                                $bulletin->designation = $row->Designation_23;
//                                $bulletin->recette = $row->Serie_7.''.$row->Number_8;
//                                $bulletin->montant = $row->Amount_12;
//                                $bulletin->devise = 'CDF';
//                                $bulletin->commision = $row->Commission_26;
//                                $bulletin->devise_commission = $row->Devise_27;
//                                $bulletin->contrevaleur = $row->Amount_12;
//                                
//                                $unvalidated[]= $bulletin;
//                        }
//                        
//                        foreach ($this->data['prepayments'] as $row)
//                        {
//                                $prepayment = new stdClass();
//                                $prepayment->id = $row->Id_0;
//                                $prepayment->date = $row->Date_1;
//                                $prepayment->beneficaire = 'DGDA';
//                                $prepayment->designation = $row->Designation_21;
//                                $prepayment->recette = $row->Serial_9.''.$row->Number_10;
//                                $prepayment->montant = $row->Amount_18;
//                                $prepayment->devise = 'CDF';
//                                $prepayment->commision = $row->Commission_24;
//                                $prepayment->devise_commission = $row->Devise_25;
//                                $prepayment->contrevaleur = $row->Amount_18;
//                                
//                                $unvalidated[]= $prepayment;
//                        }
                        
                        
                        
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "list") 
                {
                        $this->data['agences'] = $this->branchesModel->get_dropdown('agences');
                        $this->data['taux'] = $this->ratesModel->get_taux();
                        $cumules = $this->dataModel->get_rates_by_day();
                        $cumulous = $this->dataModel->get_month_of_rates();
                        $this->data['chart'] = $this->dataModel->get_rates_of_last_days($cumules, $cumulous);
                        $this->data("set_exchange_rates");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\taux', $this->data);
                }
                elseif($obj == "paiement_tresor") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor_gu();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "paiement_propre") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "fond_propre") 
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['encaissements'] = $this->reportsModel->get_fond_propres();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_gu")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        if($status == 'tresor')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor_gu();
                        }
                        elseif($status == 'propre')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_propres_gu();
                        }
                        else 
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_fond_tresor();
                        }
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder. '\filterresult', $this->data);
                }
                elseif($obj == "filterresult")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        if($status == 'tresor')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_tresor();
                        }
                        elseif($status == 'propre')
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_paiements_propres();
                        }
                        else 
                        {
                                $this->data['encaissements'] = $this->reportsModel->get_fond_tresor();
                        }
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder. '\\'.$obj, $this->data);
                }
                elseif($obj == "filterresult_dgda")
                {
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['bulletins'] = $this->integrationModel->get_reports_filter();
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Viewx\\' . $this->folder. '\\'.$obj, $this->data);
                }
                elseif($obj == "filter_nvalidated")
                {
                        $this->data['encaissements'] = $this->reportsModel->get_filter_nvalidated_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls();
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder. '\\'.$obj, $this->data);
                }
                elseif($obj == "pepele_mobile")
                {
                        echo view('\Modules\Eximtrade\Views\ppmobile\payments', $this->data);
                }
                elseif($obj == "pepele_unvalidated")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['payments'] = $this->integrationModel->get_ppmobile_unvalidated_bls();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Eximtrade\ppmobile\_unvalidated', $this->data);
                }
                elseif($obj == "pepele_regularisation")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['payments'] = $this->integrationModel->get_ppmobile_unvalidated_bls_to_regulate();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Eximtrade\ppmobile\_regularisation', $this->data);
                }
                elseif($obj == "pepele_validated")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['payments'] = $this->integrationModel->get_ppmobile_validated_bls();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Eximtrade\ppmobile\_validated', $this->data);
                }
                elseif($obj == "ordres")
                {
                        $bank = $this->session->userdata['account_id'];
                        if($id !="") $this->data['title'] = "Nouveaux odres des paiements";
                        else $this->data['title'] = "Tous les odres des paiements";
                        $this->data['ordres'] = $this->encaissementModel->get_ordres('bank',$bank, $id);
                        $this->data['from'] = $id;
                        $this->data['status'] = $this->encaissementModel->order_status;
                        $this->data['OrderColor'] = $this->encaissementModel->color_orders;
                        echo view('\Modules\Eximtrade\Views\ordres\\'.$obj, $this->data);
                }
                elseif($obj == "prepayments")
                {
                        $this->data['messages'] = $this->prepaymentsModel->ackmessages;
                        echo view('\Modules\Eximtrade\Views\prepayments\prepayments', $this->data);
                }
                elseif($obj == "declarationslist")
                {
                        $this->data['messages'] = $this->integrationModel->declaration_ackmessages;;
                        $this->data['status'] = $this->integrationModel->prepayments_status;
                        $this->data['color'] = $this->integrationModel->prepayments_status_color;
                        $this->data['declarations'] = $this->integrationModel->get_douane_declarations();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\declarations', $this->data);
                }
                elseif($obj == "reports") 
                {
			echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_paydgda")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['display'] = $obj;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_dgrad_dgi")
                {
                        $status = $id;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['beneficiaires'] = $this->reportsModel->regies;
                        $this->data['encaissements'] = $this->reportsModel->get_report_paiements();
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['display'] = $obj;
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_nvalidated")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_regulate();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls_to_regulate();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "gu_bulletin")
                {
                        $this->data['typeDoc'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                       
                        # Treatment of information returned by the CBS
                        $cbs_return = $this->integrationModel->get_cbs_returns_dgda($id);
                        if(isset($cbs_return->Result_6) && $cbs_return->Result_6 != "")
                        {
                                $cbs_return = json_decode($cbs_return->Result_6, true);
                                $this->data['cbs_return'] = $cbs_return;
                        }
                        //get instuctions
                        $instrcutions = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['lines'] = $instrcutions;
                         $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['bulletin'] = $this->integrationModel->get_paiement_sydonia($id);
                        $this->data['encaissementBl'] = $this->dataModel->sydonia_migrate_bl($id);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "situation_dgda")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integrationModel->get_all_instructions_dgda($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgda_array($encaissements);
                        $this->data['comptes'] = $this->accountsModel->get_agence_comptes_array("'CGU','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "situation_dgi")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integrationModel->get_all_instructions_dgi($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accountsModel->get_agence_comptes_array("'CPT','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "situation_dgrad")
                {
                        $agence = $_SESSION['Logiref_guichet'];
                        $day = gmdate('Y-m-d');//$day = '2021-04-03';
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['encaissements'] = $encaissements  = $this->integrationModel->get_all_instructions_dgrad($day);
                        $this->data['events'] = $this->integrationModel->get_cbs_returns_dgi_dgrad_array($encaissements);
                        $this->data['comptes'] = $this->accountsModel->get_agence_comptes_array("'CPT','CFB','CSO','TVA'",$agence);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "dropdowns")
                {
                        $recettes = $this->logirefModel->get_dropdown('recettes',$id);
                        
                        echo form_dropdown('Typerecette_17', $recettes[$id], "", 'class="form-control"   id="recette" ');
                }
                elseif($obj == "commissions") 
                {
                        $this->data['paiement'] = $this->encaissementModel->get_paiements();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "rapport")
                {
                        if($_SESSION['Logiref_role'] == 3):
                            
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_validateur_rapport', $this->data);
                        
                        else:
                            
                                echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                        
                        endif;
                }
                elseif($obj == "report_agence")
                {
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchesModel->get_branches();
                        
                        $_SESSION['agences'] = $this->data['agences'];
                        
                        $data = array();
                        
                        foreach ($this->data['agences'] as $row)
                        {
                                $data[$row->Id_0]= $this->encaissementModel->get_paiements_stats("guichet", $row->Id_0);
                        }
                        $this->data['data'] = $data;
                        
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_comptes")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['services'] =$this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountsModel->get_agence_accounts();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_regles")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->feesModel->get_agence_regles();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_commissions")
                {
                        ini_set('max_input_vars','3000' );
                        $this->data['paiement'] = $this->encaissementModel->get_paiements();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_penalites")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "agence_filter")
                {
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['agences'] = $this->branchesModel->get_branches();
                        $_SESSION['agences'] = $this->data['agences'];
                        $data = array();
                        
                        if(isset($_POST['agence']) && $_POST['agence'] !="")
                        {
                                $this->data['agences'] = $this->branchesModel->get_branches($_POST['agence']);
                                $_SESSION['agences'] = $this->data['agences'];
                                $return= $this->encaissementModel->get_paiements_stats("guichet_filter", $_POST['agence']);
                                if(empty($return))
                                {
                                        $data = $return;
                                        $_SESSION['return_id'] = $_POST['agence'];
                                        $this->data['agences'] = [];
                                }
                                else
                                {
                                        $return['id_agence'] = $_POST['agence'];
                                
                                        $_SESSION['return'] = $return;
                                        
                                        $data[$_POST['agence']]= $return;
                                }
                        }
                        else 
                        {
                                foreach ($this->data['agences'] as $row)
                                {   
                                        $return = $this->encaissementModel->get_paiements_stats("guichet_filter", $row->Id_0);
                                        
                                        if(empty($return))
                                        {
                                                $data = $return;
                                        }
                                        else
                                        {
                                                $data[$row->Id_0]= $return;
                                        }
                                }
                        }
                        $this->data['data'] = $data;
                        if(empty($data))
                        {
                                $this->data['agences'] = array();
                        }
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                        
                }
                elseif($obj == "regles_filter")
                {
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['regies'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regles'] = $this->feesModel->get_agence_regles_filtered($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "report_clients")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements();
                        $this->data['bulletins'] = $this->integrationModel->get_reports_bls();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users']= $users = $this->mainModel->get_dropdown('users_array');
                        $this->data['operators'] = $this->usersModel->get_dropdown('operators', $users);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'/'.$obj, $this->data);
                }
                elseif($obj == "client_filter")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_filterd_paiements("virement", $_POST);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "report_users")
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        $this->data['members'] = $this->data("get_users");
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['roles'] = $this->usersModel->role;
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "penalities")
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['encaissements'] = $this->encaissementModel->get_paiements('penalities');
                        $this->data['bulletins'] = $this->integrationModel->get_validated_bls('penalities');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "user_filter")
                {
                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['statutColor'] = $this->usersModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        
                        if(isset($_POST['agence']) && $_POST['agence'] !="")
                        {
                                $this->data['members'] = $this->data("get_users", $_POST['agence']);
                        }
                        else
                        {
                                $this->data['members'] = $this->data("get_users");
                        }
                        
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        
                        $this->data['roles'] = $this->usersModel->role;
                        
                      
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "account_filter")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types","Compte");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountsModel->get_filtered_accounts($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "report_bl")
                {
                        $this->data['bulletins'] = $this->integrationModel->get_bulletins();
                        $this->data['agences'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "bl_filter")
                {
                        $this->data['bulletins'] = $this->integrationModel->get_bulletins($_POST);
                        $this->data['agences'] = $this->branchesModel->get_dropdown('guichets');
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "paiements_gu")
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_reports_gu_paiements();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_paiements_gu")
                {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", $service=NULL);
                        $this->data['recettes'] = $this->logirefModel->get_dropdown('recettes');
                        $this->data['offices'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['regies'] = $this->encaissementModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_filter_gu_paiements($_POST);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_paiements_gu', $this->data);
                }
                elseif($obj == "regularisations")
                {
                        $day = gmdate('Y-m-d');
                        $this->data['users'] = $this->mainModel->get_dropdown('users');
                        $this->data['regularisations'] = $this->integrationModel->get_regularisations($day);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoices_batchs")
                {
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "nvalidated_invoices_batchs")
                {
                        $this->data['invoices'] = $this->seguceModel->get_nvalidated_invoicess_occ_batchs();
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "validated_invoices_batchs")
                {
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoicess_occ_batchs();
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "provision")
                {
                        $this->data['provisions_pending'] = $provisions_pending = $this->seguceModel->get_provisions_nvalidated();
                        $this->data['provisions_validated'] = $provisions_validated = $this->seguceModel->get_provisions_validated();
                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $amount_prov_pending = 0;
                        $amount_prov_validated = 0;

                        foreach($provisions_pending as $row)
                        {
                                $amount_prov_pending += $row->Montantprov_10;
                        }

                        foreach($provisions_validated as $row)
                        {
                                $amount_prov_validated += $row->Montantprov_10;
                        }

                        $this->data['amount_prov_pending'] = $amount_prov_pending;
                        $this->data['amount_prov_validated'] = $amount_prov_validated;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\report_provision', $this->data);
                }
                elseif($obj == "report_notification")
                {
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories", "ib_eb_rc_es_is");
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['id'] = $id;
                        $this->data['arg'] = $arg;
                        //$this->data["status_licence"] = $this->licenceModel->status;
                        //$this->data["notifications"] = $this->licenceModel->get_elicense_notification();

                        echo view("\Modules\Eximtrade\Views\\".$this->folder."\_".$obj, $this->data);
                }
                elseif($obj == "fees_licence")
                {
                        $this->data['fees_pending'] = $fees_pending = $this->seguceModel->get_prelevement_frais_nvalidated();
                        $this->data['fees_validated'] = $fees_validated = $this->seguceModel->get_prelevement_frais_validated();
                        $this->data['feeseb_pending'] = $feeseb_pending = $this->seguceModel->get_fees_licence_eb_nvalidated();
                        $this->data['feeseb_validated'] = $feeseb_validated = $this->seguceModel->get_fees_licence_eb_validated();

                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");

                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        // Calcul des montants
                        $fees_licence_pending = $this->data('calculate_total', $fees_pending) + $this->data('calculate_total', $feeseb_pending);
                        $fees_licence_validated = $this->data('calculate_total', $fees_validated) + $this->data('calculate_total', $feeseb_validated);

                        $this->data['fees_licence_pending'] = $fees_licence_pending;
                        $this->data['fees_licence_validated'] = $fees_licence_validated;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\fees_licence', $this->data);

                }
                elseif($obj == "fees_licence_filter")
                {
                        $this->data['fees_pending'] = $fees_pending = $this->seguceModel->get_prelevement_frais_nvalidated();
                        $this->data['fees_validated'] = $fees_validated = $this->seguceModel->get_prelevement_frais_validated();
                        $this->data['feeseb_pending'] = $feeseb_pending = $this->seguceModel->get_licence_eb_nvalidated_filter();
                        $this->data['feeseb_validated'] = $feeseb_validated = $this->seguceModel->get_licence_eb_validated_filter();

                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");

                        // Calcul des montants
                        $fees_licence_pending = $this->data('calculate_total', $fees_pending) + $this->data('calculate_total', $feeseb_pending);
                        $fees_licence_validated = $this->data('calculate_total', $fees_validated) + $this->data('calculate_total', $feeseb_validated);

                        // Assignation des données
                        $this->data['fees_licence_pending'] = $fees_licence_pending;
                        $this->data['fees_licence_validated'] = $fees_licence_validated;

                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $this->data['tab_active'] = isset($_POST['tab_active']) ? $_POST['tab_active'] : "";
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "prelevement_filter")
                {
                        $this->data['frais_licence'] = $frais_licence = $this->seguceModel->get_frais_licence_filter();
                        
                        $amount_total = 0;
                        
                        foreach($frais_licence as $row)
                        {
                                $amount_total += $row->MontantCIF_8;
                        }
                        
                        $this->data['amount_total'] = $amount_total;
                        
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "provision_filter")
                {
                        $this->data['provisions_pending'] = $provisions_pending = $this->seguceModel->get_provisions_nvalidated_filter();
                        $this->data['provisions_validated'] = $provisions_validated = $this->seguceModel->get_provisions_validated_filter();

                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;
                        $this->data['tab_active'] = isset($_POST['tab_active']) ? $_POST['tab_active'] : "";

                        $amount_prov_pending = 0;
                        $amount_prov_validated = 0;

                        foreach($provisions_pending as $row)
                        {
                                $amount_prov_pending += $row->Montantprov_10;
                        }

                        foreach($provisions_validated as $row)
                        {
                                $amount_prov_validated += $row->Montantprov_10;
                        }

                        $this->data['amount_prov_pending'] = $amount_prov_pending;
                        $this->data['amount_prov_validated'] = $amount_prov_validated;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_'.$obj, $this->data);
                }
                elseif($obj == "invoice_occ")
                {
                        $this->data['recettes'] = $this->seguceModel->recettes;
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['invoices'] = $this->reportsModel->get_invoicess_occ();
                        unset($_SESSION['invoices_occ']);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoice_license") 
                {
                        $this->data['num_bordereau'] = $this->seguceModel->get_dropdown("bordereau_number");
                        $this->data['code_imports'] = $this->seguceModel->get_dropdown("code_imports");
                        $this->data['invoices'] = $this->seguceModel->get_invoices_occ();
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        unset($_SESSION['invoices_license']);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_invoice_license")
                {
                        $this->data['num_bordereau'] = $this->seguceModel->get_dropdown("bordereau_number");
                        $this->data['code_imports'] = $this->seguceModel->get_dropdown("code_imports");
                        $this->data['invoices'] = $_SESSION['invoices_license'] = $this->seguceModel->get_invoices_occ($_POST);
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "filter_invoice_occ")
                {
                        $this->data['recettes'] = $this->seguceModel->recettes;
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['invoices'] = $_SESSION['invoices_occ'] = $this->reportsModel->get_invoicess_occ($_POST);
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder. '\\'.$obj, $this->data);
                }
                elseif($obj == "invoices_occ")
                {
                        $invoice_batchId = $id;

                        $this->data['invoice_batchId'] = $invoice_batchId;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoices_pending")
                {
                        $invoice_batchId = $id;

                        if(array_key_exists('eximtrade_validate_in_batch_by_customer',$this->functionalities['ALL']))
                        {
                                $instructions = $this->seguceModel->get_instructions_invoices_occ_by_batchid($invoice_batchId);

                                if (!empty($instructions))
                                {
                                        foreach($instructions as $row)
                                        {
                                                $data_clt[] = $row->Codeimport_28;
                                        }
                                }

                                $this->data['code_imports'] = (!empty($data_clt) && isset($data_clt)) ? array_unique($data_clt) : array();
                                $this->data['instructions'] = $instructions;
                                $this->data['batch'] = $this->seguceModel->get_invoices_occ_batchs_info($invoice_batchId);
                        }
                        else{

                                $invoice = $this->seguceModel->get_invoice_occ_by_batchid($invoice_batchId);

                                if (isset($invoice) && !empty($invoice))
                                {

                                        $date_bordereau = explode('-', $invoice->Datebordereau_15);
                                        $annee_bordereau = $date_bordereau[0];
                                        $num_bordereau = $invoice->Numbordereau_14;

                                        $ref_bordereau = $invoice_batchId. "" .$num_bordereau. "" .$annee_bordereau;
                                }
                                else
                                {
                                        $ref_bordereau = "";
                                }

                                $this->data['ref_bordereau'] = $ref_bordereau;
                                $this->data['instructions'] = $this->seguceModel->get_instructions_frais_occ_bivac_not_integrated($ref_bordereau);
                        }

                        $this->data['batch_id'] = $invoice_batchId;
                        $this->data['invoices'] = $this->seguceModel->get_invoices_occ_by_batch_id($invoice_batchId);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoices_validated")
                {
                        $invoice_batchId = $id;

                        if(array_key_exists('eximtrade_validate_in_batch_by_customer',$this->functionalities['ALL']))
                        {
                                $instructions = $this->seguceModel->get_instructions_invoices_occ_by_batchid_validated($invoice_batchId);

                                if (!empty($instructions))
                                {
                                        foreach($instructions as $row)
                                        {
                                                $data_clt[] = $row->Codeimport_28;
                                        }
                                }

                                $this->data['batch_id'] = $invoice_batchId;
                                $this->data['code_imports'] = (!empty($data_clt) && isset($data_clt)) ? array_unique($data_clt) : array();
                                $this->data['instructions'] = $instructions;
                                $this->data['invoices'] = $this->seguceModel->get_invoices_occ_by_batch_id($invoice_batchId);
                        }
                        else{

                                $this->data['invoices'] = $this->seguceModel->get_invoices_occ_validated($invoice_batchId);

                        }
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoice_occ_batchs")
                {
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');

                        if ($_SESSION['Logiref_role'] == 3)
                        {
                                $this->data['invoices'] = $this->seguceModel->get_validated_invoices_occ_batch();
                        }

                        if ($_SESSION['Logiref_role'] == 4)
                        {
                                $this->data['invoices'] = $this->seguceModel->get_invoicess_occ_batchs();
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_occ_batchs")
                {
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices_occ_batch();

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_occ")
                {
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['invoices'] = $this->seguceModel->get_invoicess_occ_batch_regul();

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "_report_occ") 
                {
                        $invoice_batchId = $id;

                        if ($_SESSION['Logiref_role'] == '3')
                        {
                                $instructions_pending = $this->seguceModel->get_instructions_invoices_occ_not_integrated($invoice_batchId);
                        }

                        if ($_SESSION['Logiref_role'] == '4')
                        {
                                $instructions_pending = $this->seguceModel->get_instructions_invoices_occ($invoice_batchId);
                        }

                        $instructions_validated = $this->seguceModel->get_instructions_invoices_occ_by_batchid_validated($invoice_batchId);
                        $instructions = $this->seguceModel->get_instructions_invoices_occ_batchs($invoice_batchId);
                        if (!empty($instructions_pending))
                        {
                                foreach($instructions_pending as $row)
                                {
                                        $clt_pending[] = $row->Codeimport_28;
                                }
                        }

                        if (!empty($instructions_validated))
                        {
                                foreach($instructions_validated as $row)
                                {
                                        $clt_validated[] = $row->Codeimport_28;
                                }
                        }

                        if (!empty($instructions))
                        {
                                foreach($instructions as $row)
                                {
                                        $data_clt[] = $row->Codeimport_28;
                                }
                        }

                        $this->data['batch_id'] = $invoice_batchId;
                        $this->data['clt_pending'] = (!empty($clt_pending) && isset($clt_pending)) ? array_unique($clt_pending) : array();
                        $this->data['clt_validated'] = (!empty($clt_validated) && isset($clt_validated)) ? array_unique($clt_validated) : array();
                        $this->data['instructions'] = $instructions;
                        $this->data['instructions_pending'] = $instructions_pending;
                        $this->data['instructions_validated'] = $instructions_validated;
                        $this->data['invoice_batchId'] = $invoice_batchId;
                        $this->data['data_clt'] = json_encode(array_unique($data_clt));

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "report_regularisation") 
                {
                        $this->data['invoices'] = $this->seguceModel->get_report_invoice_occ_issues();
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\' .$obj, $this->data);
                }
                elseif($obj == "invoice_numbord") 
                {
                        $invoices = $this->seguceModel->get_invoicess_occ_batchs();
                        
                        $total_amount_cif = 0;
                        $total_amount_occ = 0;
                        $total_amount_bivac = 0;
                        $total_amout_ctrl = 0;
                        $total_amount_tva_ctrl = 0;
                        
                        $licenses = array();
                        $tables = array();
                        
                        foreach ($invoices as $row)
                        {
                            $licenses = new \stdClass();
                            $licenses->num_bordereau = $row->Numbordereau_9;
                            $licenses->date = $row->Date_10;

                            $license = json_decode($row->Licenses_11, true);
                            
                            foreach ($license as $line)
                            {
                                    $line['frais_cif'] = str_replace(' ','',$line['frais_cif']);
                                    $line['frais_cif'] = str_replace(',','.',$line['frais_cif']);

                                    $line['frais_ctrl'] = str_replace(' ','',$line['frais_ctrl']);
                                    $line['frais_ctrl'] = str_replace(',','.',$line['frais_ctrl']);

                                    $line['frais_bivac'] = str_replace(' ','',$line['frais_bivac']);
                                    $line['frais_bivac'] = str_replace(',','.',$line['frais_bivac']);

                                    $line['frais_occ'] = str_replace(' ','',$line['frais_occ']);
                                    $line['frais_occ'] = str_replace(',','.',$line['frais_occ']);

                                    $line['frais_tva_ctrl'] = str_replace(' ','',$line['frais_tva_ctrl']);
                                    $line['frais_tva_ctrl'] = str_replace(',','.',$line['frais_tva_ctrl']);

                                    $line['frais_cif'] = round($line['frais_cif'], 2);
                                    $line['frais_bivac'] = round($line['frais_bivac'], 2);
                                    $line['frais_occ'] = round($line['frais_occ'], 2);
                                    $line['frais_tva_ctrl'] = round($line['frais_tva_ctrl'], 2);

                                    $total_amount_cif += $line['frais_cif'];
                                    $total_amount_occ += $line['frais_occ'];
                                    $total_amount_bivac += $line['frais_bivac'];
                                    $total_amout_ctrl += $line['frais_ctrl'];
                                    $total_amount_tva_ctrl += $line['frais_tva_ctrl'];

                            }

                            $licenses->cif = $total_amount_cif;
                            $licenses->occ = $total_amount_occ;
                            $licenses->bivac = $total_amount_bivac;
                            $licenses->ctrl = $total_amout_ctrl;
                            $licenses->tva_ctrl = $total_amount_tva_ctrl;

                            $tables[] = $licenses;

                        }
                        #echo '<pre>'; print_r($tables); echo '</pre>'; die;

                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['invoices'] = $tables;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "nvalidated_occ")
                {
                        $this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['invoices'] = $this->seguceModel->get_validated_invoices_occ_batch();

                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "invoices_paid")
                {
                        $this->data['invoices'] = $this->seguceModel->get_invoices_paid();
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "paid_invoices")
                {
                        $cbs_return = $this->integrationModel->get_cbs_returns_seguce_array();

                        $this->data['cbs_return'] = $cbs_return;
                        $this->data['invoices'] = $this->seguceModel->get_paid_invoices();
                        $this->data['colors'] = $this->seguceModel->color_invoices;
                        $this->data['status'] = $this->seguceModel->status_invoices;
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "paid_invoices_filter")
                {
                        $cbs_return = $this->integrationModel->get_cbs_returns_seguce_array();

                        $this->data['cbs_return'] = $cbs_return;
                        $this->data['invoices'] = $this->seguceModel->get_paid_invoices_filter($_POST);
                        $this->data['colors'] = $this->seguceModel->color_invoices;
                        $this->data['status'] = $this->seguceModel->status_invoices;
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "exempted_customers")
                {
                        $this->data['exempts'] = $this->feesModel->get_exempt_customers();

                        $this->data['beneficiaires'] = $this->stakeholdersModel->get_dropdown("beneficiaries");
                        $this->data['agences'] = $this->branchesModel->get_dropdown("agences");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['from'] = $id;
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets", NULL, "ALL");
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif($obj == "viewpdf")
                {
                        $document = $this->licenceModel->get_documents_saving_by_id($id);
                        $filePath = ROOTPATH . $document->Link_9;

                        if (file_exists($filePath)) {
                                return $this->response->setHeader('Content-Type', 'application/pdf')
                                        ->setHeader('Content-Disposition', 'inline; filename="' . basename($document->Link_9) . '"')
                                        ->setBody(file_get_contents($filePath));
                        }
                        else {
                                return redirect()->to(base_url("404"));
                        }
                }
                elseif($obj == "licence_documents")
                {
                        $declaration = $this->licenceModel->get_licence_by_id($id);
                        $categorie = $this->licenceModel->get_categorie_by_object($declaration->Category_20);
                        $documents =  explode(",",$categorie->Document_list_12);
                        $this->data['description_document'] = array();

                        foreach($documents as $document){
                                $this->data['description_document'][$document] = $this->licenceModel->get_description_document($document);
                        }

                        if (isset($declaration->Documents_37) && $declaration->Documents_37 !=""):
                                $docs = json_decode($declaration->Documents_37);
                        else:
                                $docs = array();
                        endif;

                        $this->data["documents"] = $documents;
                        $this->data["Expeditions"] = $docs;
                        $this->data["declaration"] = $declaration;

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj,$this->data);
                }
                elseif ($obj == "licences_current")
                {
                        ini_set('memory_limit', '512M');

                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['total_partial'] = 0;
                        $this->data['total_force'] = 0;
                        $this->data['total_licences'] = 0;
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","ib_eb_rc_es_is");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif ($obj == "filter_licencecurent")
                {
                        ini_set('memory_limit', '512M');

                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['total_partial'] = 0;
                        $this->data['total_force'] = 0;
                        $this->data['total_licences'] = 0;
                        $this->data['licences'] = $this->licenceModel->get_filter_currentlicenses();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories", "ib_eb_rc_es_is");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_filter_licencecurent', $this->data);
                }
                elseif ($obj == "licences_expire")
                {
                        ini_set('memory_limit', '512M');

                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['total_partial'] = 0;
                        $this->data['total_force'] = 0;
                        $this->data['total_licences'] = 0;
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories", "ib_eb_rc_es_is");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\\'.$obj, $this->data);
                }
                elseif ($obj == "filter_licencexpire")
                {
                        ini_set('memory_limit', '512M');

                        $this->data['colors'] = $this->licenceModel->colors;
                        $this->data['status'] = $this->licenceModel->status;
                        $this->data['total_partial'] = 0;
                        $this->data['total_force'] = 0;
                        $this->data['total_licences'] = 0;
                        $this->data['licences'] = $this->licenceModel->get_filter_licensesexpire();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories", "ib_eb_rc_es_is");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\'.$this->folder.'\_filter_licencesexpire', $this->data);
                }
                elseif ($obj == "report_customer")
                {
                        $this->data["legalstatus"] = $this->quitusModel->legalstatus;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['clients_fiscal'] = $this->quitusModel->get_clients_fiscal();

                        echo view('\Modules\Eximtrade\\' . $this->folder . '\\'.$obj, $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Eximtrade\Views\\'.$this->folder . '_denial', $this->data);
                }
	}




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }


        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "get_users")
                {
                        if($data !="" && $data != NULL)
                        {
                                $members = $this->usersModel->get_members($data);
                        }
                        else
                        {
                                $members = $this->usersModel->get_members();
                        }

                        $members = $this->usersModel->get_members();

                        return $members;
                }
                elseif ($obj == "calculate_total")
                {
                        if (!is_array($data))
                        {
                                return 0;
                        }

                        return array_reduce($data, function ($carry, $row) {
                                return $carry + $row->MontantCIF_8;
                        }, 0);
                }
                elseif($obj == "get_notifications")
                {
                        $request = service('request');

                        $start  = (int) $request->getPost('start', FILTER_SANITIZE_NUMBER_INT);
                        $length = (int) $request->getPost('length', FILTER_SANITIZE_NUMBER_INT);
                        $draw   = (int) $request->getPost('draw', FILTER_SANITIZE_NUMBER_INT);

                        $length = $length > 0 ? $length : 10;
                        $draw   = $draw > 0 ? $draw : 1;

                        $search  = $request->getPost('search')['value'] ?? '';

                        $filters = [
                                'Licence_35'  => $request->getPost('Licence_35'),
                                'Category_20' => $request->getPost('Category_20'),
                                'Status_2'    => $request->getPost('Status_2'),
                                'start'       => $request->getPost('begin'),
                                'end'         => $request->getPost('end')
                        ];

                        $categ = (!is_null($data))?strtoupper($data):NULL;
                        $arg = (!is_null($arg))?strtoupper($arg):NULL;

                        $status_licence = $this->licenceModel->status;

                        $notifications = $this->licenceModel->get_elicense_notification($length, $start, $search, $filters, $categ, $arg);
                        $totalRecords = $this->licenceModel->get_elicense_notification_count($filters, $categ, $arg);
                        $totalFiltered = $this->licenceModel->get_elicense_notification_count_filtered($search, $filters, $categ, $arg);

                        $response = [];
                        $i = $start + 1;
                        foreach ($notifications as $row)
                        {
                                $Amountduedocument = 0;
                                $Amountpaidocument = 0;
                                $Amountremainingdocument = 0;
                                $Amountdocument = 0;
                                $Amountcertifiedocument = 0;
                                $docusaved = array();
                                $Daterapat = "";
                                $Datepaid = "";
                                $Datedocdelay = "";

                                if (isset($row->Documents_25) && $row->Documents_25 != "")
                                {
                                        $docs = json_decode($row->Documents_25);
                                        foreach($docs as $expedition)
                                        {
                                                if(!empty($expedition) && isset($expedition->Documents))
                                                {
                                                        foreach($expedition->Documents as $key => $document)
                                                        {
                                                                if($document == "CVI" || $document == "AVB" || $document == "CVEE")
                                                                {
                                                                        if((isset($expedition->Confirmed) || isset($expedition->Amountcertified) || isset($expedition->Amountpaid)) && $expedition->Confirmed == 2)
                                                                        {
                                                                                $Amountduedocument += $expedition->Amountcertified;
                                                                        }
                                                                        else{
                                                                                $Amountduedocument += $expedition->Amountpaid->$key;
                                                                        }

                                                                        $Amountdocument = $expedition->Amountpaid->$key;
                                                                        $Amountcertifiedocument = $expedition->Amountcertified;
                                                                }
                                                                elseif($document == "FF")
                                                                {
                                                                        $Amountpaidocument += $expedition->Amountpaid->$key;
                                                                }
                                                                elseif($document == "DDT")
                                                                {
                                                                        if(isset($expedition->Datexport) && $expedition->Datexport != "")
                                                                        {
                                                                                $date1 = new \DateTime($expedition->Datexport);

                                                                                if($row->Merchandise_29 == "OR")
                                                                                {
                                                                                        $Daterapat = $date1->modify("+20 days")->format("Y-m-d");
                                                                                }
                                                                                else{
                                                                                        $Daterapat = $date1->modify("+60 days")->format("Y-m-d");
                                                                                }
                                                                        }
                                                                        else{
                                                                                $Daterapat =  $row->Initial_expiration_23;
                                                                        }
                                                                }

                                                                if(!in_array($document, $docusaved))
                                                                {
                                                                        $docname = $this->licenceModel->get_description_document($document);
                                                                        array_push($docusaved,$docname);
                                                                }
                                                        }
                                                }
                                        }

                                        $Amountremainingdocument = $Amountduedocument - $Amountpaidocument;
                                }
                                else{
                                        $Amountduedocument = $row->Amountdue_13;
                                        $Amountremainingdocument = $Amountduedocument;
                                }

                                if (!empty($row->Results_26))
                                {
                                        $Results_26 = json_decode($row->Results_26, true);

                                        if (is_array($Results_26) && !empty($Results_26['Date_paids']))
                                        {
                                                foreach ($Results_26['Date_paids'] as $key => $datepaid)
                                                {
                                                        $Datepaid = $datepaid;
                                                        $Datedocdelay = $Results_26['Expirations'][$key] ?? null;
                                                }
                                        }
                                }

                                if(is_null($categ) && is_null($arg))
                                {
                                        $response[] = [
                                                "rownum"                => $i++,
                                                "Date_1"                => date("Y-m-d",strtotime($row->Date_1)),
                                                "Numdec_21"             => $row->Numdec_21,
                                                "Designation_22"        => $row->Designation_22,
                                                "Amountdue_13"          => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                "Amountpaid_10"         => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                "Amountremaining_15"    => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                "Initial_expiration_23" => $row->Initial_expiration_23,
                                                "Etat"                  => $status_licence[$row->Status_2] ?? "N/A",
                                                "Intitule_8"            => $row->Intitule_8,
                                                "Document"              => (!empty($row->Linkdocument_9))
                                                                                ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                "Action"                => '<div class="btn-group" id="envoyer">
                                                                        <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                        . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                        ' data-toggle="dropdown" aria-expanded="false">
                                                                        Envoyer
                                                                        </button>
                                                                        <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                        <li>
                                                                                <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                <i class="fa fa-envelope f11"></i> Par mail
                                                                                </a>
                                                                        </li>
                                                                        <li class="divider"></li>
                                                                        </ul>
                                                                </div>'

                                        ];
                                }
                                else{
                                        if($categ == "IS" || $categ == "ES" || $categ == "RC")
                                        {
                                                $response[] = [
                                                        "rownum"                => $i++,
                                                        "Date_1"                => date("Y-m-d",strtotime($row->Date_1)),
                                                        "Numdec_21"             => $row->Numdec_21,
                                                        "Designation_22"        => $row->Designation_22,
                                                        "Amountdue_13"          => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                        "Amountpaid_10"         => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                        "Amountremaining_15"    => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                        "Initial_expiration_23" => $row->Initial_expiration_23,
                                                        "Intitule_8"            => $row->Intitule_8,
                                                        "Document"              => (!empty($row->Linkdocument_9))
                                                                                        ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                        : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                        "Action"                => '<div class="btn-group" id="envoyer">
                                                                                <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                                . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                                ' data-toggle="dropdown" aria-expanded="false">
                                                                                Envoyer
                                                                                </button>
                                                                                <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                                <li>
                                                                                        <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                        <i class="fa fa-envelope f11"></i> Par mail
                                                                                        </a>
                                                                                </li>
                                                                                <li class="divider"></li>
                                                                                </ul>
                                                                        </div>'

                                                ];
                                        }
                                        elseif($categ == "IB")
                                        {
                                                if($arg == "APUREMENT")
                                                {
                                                        if((in_array($row->Code_24,['IB20','IB21','IB22']) && strtotime(date("Y-m-d")) > strtotime($Datedocdelay)) || !in_array($row->Code_24,['IB20','IB21','IB22']))
                                                        {
                                                                $response[] = [
                                                                        "rownum"                        => $i++,
                                                                        "Date_1"                        => date("Y-m-d",strtotime($row->Date_1)),
                                                                        "Numdec_21"                     => $row->Numdec_21,
                                                                        "Code_24"                       => $row->Code_24,
                                                                        "Designation_22"                => $row->Designation_22,
                                                                        "Amountdue_13"                  => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                                        "Amountpaid_10"                 => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                                        "Amountremaining_15"            => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                                        "Documents_25"                  => implode(',',$docusaved),
                                                                        "Amountremainingdocument"       => $Amountremainingdocument,
                                                                        "Initial_expiration_23"         => $row->Initial_expiration_23,
                                                                        "Intitule_8"                    => $row->Intitule_8,
                                                                        "Document"                      => (!empty($row->Linkdocument_9))
                                                                                                                ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                                                : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                                        "Action"                        => '<div class="btn-group" id="envoyer">
                                                                                                                <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                                                                . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                                                                ' data-toggle="dropdown" aria-expanded="false">
                                                                                                                Envoyer
                                                                                                                </button>
                                                                                                                <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                                                                <li>
                                                                                                                        <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                                                        <i class="fa fa-envelope f11"></i> Par mail
                                                                                                                        </a>
                                                                                                                </li>
                                                                                                                <li class="divider"></li>
                                                                                                                </ul>
                                                                                                        </div>'

                                                                ];
                                                        }
                                                }
                                                else{
                                                        if(in_array($row->Code_24,['IB20','IB21','IB22']) && strtotime(date("Y-m-d")) <= strtotime($Datedocdelay))
                                                        {
                                                                $response[] = [
                                                                        "rownum"                        => $i++,
                                                                        "Date_1"                        => date("Y-m-d",strtotime($row->Date_1)),
                                                                        "Numdec_21"                     => $row->Numdec_21,
                                                                        "Code_24"                       => $row->Code_24,
                                                                        "Designation_22"                => $row->Designation_22,
                                                                        "Amountdue_13"                  => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                                        "Datepaid"                      => $Datepaid,
                                                                        "Amountpaid_10"                 => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                                        "Amountremaining_15"            => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                                        "Doc_expiration_19"             => $Datedocdelay,
                                                                        "Documents_25"                  => implode(',',$docusaved),
                                                                        "Amountremainingdocument"       => $Amountremainingdocument,
                                                                        "Initial_expiration_23"         => $row->Initial_expiration_23,
                                                                        "Intitule_8"                    => $row->Intitule_8,
                                                                        "Document"                      => (!empty($row->Linkdocument_9))
                                                                                                                ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                                                : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                                        "Action"                        => '<div class="btn-group" id="envoyer">
                                                                                                                <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                                                                . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                                                                ' data-toggle="dropdown" aria-expanded="false">
                                                                                                                Envoyer
                                                                                                                </button>
                                                                                                                <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                                                                <li>
                                                                                                                        <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                                                        <i class="fa fa-envelope f11"></i> Par mail
                                                                                                                        </a>
                                                                                                                </li>
                                                                                                                <li class="divider"></li>
                                                                                                                </ul>
                                                                                                        </div>'

                                                                ];
                                                        }
                                                }
                                        }
                                        elseif($categ == "EB")
                                        {
                                                if($arg == "APUREMENT")
                                                {
                                                        if(strtotime(date("Y-m-d")) > strtotime($Daterapat))
                                                        {
                                                                $response[] = [
                                                                        "rownum"                        => $i++,
                                                                        "Date_1"                        => date("Y-m-d",strtotime($row->Date_1)),
                                                                        "Numdec_21"                     => $row->Numdec_21,
                                                                        "Code_24"                       => $row->Code_24,
                                                                        "Designation_22"                => $row->Designation_22,
                                                                        "Amountdue_13"                  => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                                        "Amountpaid_10"                 => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                                        "Amountremaining_15"            => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                                        "Documents_25"                  => implode(',',$docusaved),
                                                                        "Amountremainingdocument"       => $Amountremainingdocument,
                                                                        "Initial_expiration_23"         => $row->Initial_expiration_23,
                                                                        "Intitule_8"                    => $row->Intitule_8,
                                                                        "Document"                      => (!empty($row->Linkdocument_9))
                                                                                                                ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                                                : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                                        "Action"                        => '<div class="btn-group" id="envoyer">
                                                                                                                <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                                                                . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                                                                ' data-toggle="dropdown" aria-expanded="false">
                                                                                                                Envoyer
                                                                                                                </button>
                                                                                                                <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                                                                <li>
                                                                                                                        <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                                                        <i class="fa fa-envelope f11"></i> Par mail
                                                                                                                        </a>
                                                                                                                </li>
                                                                                                                <li class="divider"></li>
                                                                                                                </ul>
                                                                                                        </div>'

                                                                ];
                                                        }
                                                }
                                                else{
                                                        if(strtotime(date("Y-m-d")) <= strtotime($Daterapat))
                                                        {
                                                                $response[] = [
                                                                        "rownum"                        => $i++,
                                                                        "Date_1"                        => date("Y-m-d",strtotime($row->Date_1)),
                                                                        "Numdec_21"                     => $row->Numdec_21,
                                                                        "Designation_22"                => $row->Designation_22,
                                                                        "Code_24"                       => $row->Code_24,
                                                                        "Amountdue_13"                  => $row->Devise_14." ".number_format($row->Amountdue_13, 2, ","," "),
                                                                        "AmountPrefinance_28"           => (isset($row->AmountPrefinance_28) && $row->AmountPrefinance_28 != "")?($row->AmountPrefinance_28):0,
                                                                        "Amountpaid_10"                 => $row->Devise_11." ".number_format($row->Amountpaid_10, 2, ",", " "),
                                                                        "Daterapat"                     => $Daterapat,
                                                                        "Amountremaining_15"            => $row->Devise_16." ".number_format($row->Amountremaining_15, 2, ",", " "),
                                                                        "Documents_25"                  => implode(',',$docusaved),
                                                                        "Amountremainingdocument"       => $Amountremainingdocument,
                                                                        "Intitule_8"                    => $row->Intitule_8,
                                                                        "Document"                      => (!empty($row->Linkdocument_9))
                                                                                                                ? "<span onclick=\"openPDF('{$row->Id_0}')\" class='text-danger cursor-pointer f15'><i class='fa fa-file-pdf-o'></i></span>"
                                                                                                                : "<span class='text-muted cursor-not-allowed f15'><i class='fa fa-file-pdf-o'></i></span>",
                                                                        "Action"                        => '<div class="btn-group" id="envoyer">
                                                                                                                <button type="button" class="btn btn-primary no-border no-margin dropdown-toggle p-1 f13" '
                                                                                                                . (empty($row->Linkdocument_9) ? 'disabled' : '') .
                                                                                                                ' data-toggle="dropdown" aria-expanded="false">
                                                                                                                Envoyer
                                                                                                                </button>
                                                                                                                <ul class="dropdown-menu" role="menu" style="min-width:6rem;">
                                                                                                                <li>
                                                                                                                        <a onclick="mail(' . $row->Declarationid_7 . ', \'' . addslashes($row->Comment_17) . '\', \'' . (!empty($row->Linkdocument_9) ? $row->Linkdocument_9 : 0) . '\')" class="pl-1">
                                                                                                                        <i class="fa fa-envelope f11"></i> Par mail
                                                                                                                        </a>
                                                                                                                </li>
                                                                                                                <li class="divider"></li>
                                                                                                                </ul>
                                                                                                        </div>'

                                                                ];
                                                        }
                                                }
                                        }
                                }
                        }

                        $json_data = [
                                "draw"            => intval($draw),
                                "recordsTotal"    => intval($totalRecords),
                                "recordsFiltered" => intval($totalFiltered),
                                "data"            => $response,
                        ];

                        return $this->response->setJSON($json_data);
                }
                elseif($obj == "get_current_licenses")
                {
                        $request = service('request');

                        $start  = (int) $request->getPost('start', FILTER_SANITIZE_NUMBER_INT);
                        $length = (int) $request->getPost('length', FILTER_SANITIZE_NUMBER_INT);
                        $draw   = (int) $request->getPost('draw', FILTER_SANITIZE_NUMBER_INT);

                        $length = $length > 0 ? $length : 10;
                        $draw   = $draw > 0 ? $draw : 1;

                        $search  = $request->getPost('search')['value'] ?? '';

                        $filters = [
                                'Licence_35'  => $request->getPost('Licence_35'),
                                'Category_20' => $request->getPost('Category_20'),
                                'Status_2'    => $request->getPost('Status_2'),
                                'start'       => $request->getPost('begin'),
                                'end'         => $request->getPost('end')
                        ];

                        $categ = (!is_null($data))?strtoupper($data):NULL;

                        $current_licences = $this->licenceModel->get_current_licenses($length, $start, $search, $filters, $categ);
                        $totalRecords = $this->licenceModel->get_current_licenses_count($filters, $categ);
                        $totalFiltered = $this->licenceModel->get_current_licenses_count_filtered($search, $filters, $categ);

                        $data = [];
                        $i = $start + 1;
                        foreach ($current_licences as $row)
                        {
                                $Amountduedocument = 0;
                                $Amountpaidocument = 0;
                                $Amountremainingdocument = 0;
                                $Amountdocument = 0;
                                $Amountcertifiedocument = 0;

                                if (isset($row->Documents_37) && $row->Documents_37 != "")
                                {
                                        $docs = json_decode($row->Documents_37);
                                        foreach($docs as $expedition)
                                        {
                                                if(!empty($expedition) && isset($expedition->Documents))
                                                {
                                                        foreach($expedition->Documents as $key => $document)
                                                        {
                                                                if($document == "CVI" || $document == "AVB" || $document == "CVEE")
                                                                {
                                                                        if((isset($expedition->Confirmed) || isset($expedition->Amountcertified) || isset($expedition->Amountpaid)) && $expedition->Confirmed == 2)
                                                                        {
                                                                                $Amountduedocument += $expedition->Amountcertified;
                                                                        }
                                                                        else{
                                                                                $Amountduedocument += $expedition->Amountpaid->$key;
                                                                        }

                                                                        $Amountdocument = $expedition->Amountpaid->$key;
                                                                        $Amountcertifiedocument = $expedition->Amountcertified;
                                                                }
                                                                elseif($document == "FF")
                                                                {
                                                                        $Amountpaidocument += $expedition->Amountpaid->$key;
                                                                }
                                                        }
                                                }
                                        }

                                        $Amountremainingdocument = $Amountduedocument - $Amountpaidocument;
                                }
                                else{
                                        $Amountduedocument = $row->Amountdue_23;
                                        $Amountremainingdocument = $Amountduedocument;
                                }

                                if(is_null($categ))
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", ""),
                                                "Amountcertifiedocument"        => $row->Devise_24 .' '. number_format($Amountcertifiedocument, 2, ",", ""),
                                                "Amountremaining"               => $row->Devise_34 .' '. number_format($row->Amountremaining_33, 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 => strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   => strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "TypeMerchandise"               => (isset($row->Merchandise_41) && $row->Merchandise_41 != "")
                                                                                ?(($row->Merchandise_41 == "AUTRE")?"AUTRES":"OR ou DIAMANT")
                                                                                :"",
                                                "TypePrefinance"                => (isset($row->Prefinance_38) && $row->Prefinance_38 != "")
                                                                                ?(($row->Prefinance_38 == "P")?"Partiel":"Total")
                                                                                :"",
                                                "AmountPrefinance"              => $row->Devise_24 .' '. number_format($row->AmountPrefinance_39, 2, ",", " "),
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif($categ == "EB")
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", ""),
                                                "Amountremaining"               => $row->Devise_34 .' '. number_format($row->Amountremaining_33, 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 => strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   => strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "TypeMerchandise"               => (isset($row->Merchandise_41) && $row->Merchandise_41 != "")
                                                                                ?(($row->Merchandise_41 == "AUTRE")?"AUTRES":"OR ou DIAMANT")
                                                                                :"",
                                                "TypePrefinance"                => (isset($row->Prefinance_38) && $row->Prefinance_38 != "")
                                                                                ?(($row->Prefinance_38 == "P")?"Partiel":"Total")
                                                                                :"",
                                                "AmountPrefinance"              => $row->Devise_24 .' '. number_format($row->AmountPrefinance_39, 2, ",", " "),
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif(in_array($categ,["IS","ES","RC"]))
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountremaining"               => $row->Devise_34 .' '. number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "DateValidated"                 => strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   => strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif($categ == "IB")
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", " "),
                                                "Amountcertifiedocument"        => $row->Devise_24 .' '. number_format($Amountcertifiedocument, 2, ",", " "),
                                                "Amountremaining"               => $row->Devise_34 .' '. number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 => strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   => strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                        }

                        $json_data = [
                                "draw"            => intval($draw),
                                "recordsTotal"    => intval($totalRecords),
                                "recordsFiltered" => intval($totalFiltered),
                                "data"            => $data,
                                "totals"          => [
                                        "partial" => $this->licenceModel->get_total_current_partial($filters, $categ),
                                        "force"   => $this->licenceModel->get_total_current_force($filters, $categ),
                                        "total"   => intval($totalFiltered)
                                ]
                        ];

                        return $this->response->setJSON($json_data);
                }
                elseif($obj == "get_expired_licenses")
                {
                        $request = service('request');

                        $start  = (int) $request->getPost('start', FILTER_SANITIZE_NUMBER_INT);
                        $length = (int) $request->getPost('length', FILTER_SANITIZE_NUMBER_INT);
                        $draw   = (int) $request->getPost('draw', FILTER_SANITIZE_NUMBER_INT);

                        $length = $length > 0 ? $length : 10;
                        $draw   = $draw > 0 ? $draw : 1;

                        $search  = $request->getPost('search')['value'] ?? '';

                        $filters = [
                                'Licence_35'  => $request->getPost('Licence_35'),
                                'Category_20' => $request->getPost('Category_20'),
                                'Status_2'    => $request->getPost('Status_2'),
                                'start'       => $request->getPost('begin'),
                                'end'         => $request->getPost('end')
                        ];

                        $categ = (!is_null($data))?strtoupper($data):NULL;

                        $expired_licences = $this->licenceModel->get_expired_licenses($length, $start, $search, $filters, $categ);
                        $totalRecords = $this->licenceModel->get_expired_licenses_count($filters, $categ);
                        $totalFiltered = $this->licenceModel->get_expired_licenses_count_filtered($search, $filters, $categ);

                        $data = [];
                        $i = $start + 1;
                        foreach ($expired_licences as $row)
                        {
                                $Amountduedocument = 0;
                                $Amountpaidocument = 0;
                                $Amountremainingdocument = 0;
                                $Amountdocument = 0;
                                $Amountcertifiedocument = 0;

                                if (isset($row->Documents_37) && $row->Documents_37 != "")
                                {
                                        $docs = json_decode($row->Documents_37);
                                        foreach($docs as $expedition)
                                        {
                                                if(!empty($expedition) && isset($expedition->Documents))
                                                {
                                                        foreach($expedition->Documents as $key => $document)
                                                        {
                                                                if($document == "CVI" || $document == "AVB" || $document == "CVEE")
                                                                {
                                                                        if((isset($expedition->Confirmed) || isset($expedition->Amountcertified) || isset($expedition->Amountpaid)) && $expedition->Confirmed == 2)
                                                                        {
                                                                                $Amountduedocument += $expedition->Amountcertified;
                                                                        }
                                                                        else{
                                                                                $Amountduedocument += $expedition->Amountpaid->$key;
                                                                        }

                                                                        $Amountdocument = $expedition->Amountpaid->$key;
                                                                        $Amountcertifiedocument = $expedition->Amountcertified;
                                                                }
                                                                elseif($document == "FF")
                                                                {
                                                                        $Amountpaidocument += $expedition->Amountpaid->$key;
                                                                }
                                                        }
                                                }
                                        }

                                        $Amountremainingdocument = $Amountduedocument - $Amountpaidocument;
                                }
                                else{
                                        $Amountduedocument = $row->Amountdue_23;
                                        $Amountremainingdocument = $Amountduedocument;
                                }

                                if(is_null($categ))
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", " "),
                                                "Amountcertifiedocument"        => $row->Devise_24 .' '. number_format($Amountcertifiedocument, 2, ",", " "),
                                                "Amountremaining"               => $row->Devise_34 .' '. number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 => strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   => strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "TypeMerchandise"               => (isset($row->Merchandise_41) && $row->Merchandise_41 != "")
                                                                                ?(($row->Merchandise_41 == "AUTRE")?"AUTRES":"OR ou DIAMANT")
                                                                                :"",
                                                "TypePrefinance"                => (isset($row->Prefinance_38) && $row->Prefinance_38 != "")
                                                                                ?(($row->Prefinance_38 == "P")?"Partiel":"Total")
                                                                                :"",
                                                "AmountPrefinance"              => $row->Devise_24 .' '. number_format($row->AmountPrefinance_39, 2, ",", " "),
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif($categ == "EB")
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", " "),
                                                "Amountremaining"               => $row->Devise_34 . ' ' .number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 =>  strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   =>  strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "TypeMerchandise"               => (isset($row->Merchandise_41) && $row->Merchandise_41 != "")
                                                                                ?(($row->Merchandise_41 == "AUTRE")?"AUTRES":"OR ou DIAMANT")
                                                                                :"",
                                                "TypePrefinance"                => (isset($row->Prefinance_38) && $row->Prefinance_38 != "")
                                                                                ?(($row->Prefinance_38 == "P")?"Partiel":"Total")
                                                                                :"",
                                                "AmountPrefinance"              => $row->Devise_24 . ' ' .number_format($row->AmountPrefinance_39, 2, ",", " "),
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif(in_array($categ,["IS","ES","RC"]))
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountremaining"               => $row->Devise_34 . ' ' .number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "DateValidated"                 =>  strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   =>  strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                                elseif($categ == "IB")
                                {
                                        $data[] = [
                                                "rownum"                        => $i++,
                                                "Status"                        => $row->Status_2,
                                                "NumDec"                        => $row->Licence_35,
                                                "Customer"                      => $row->Designation_9,
                                                "Amountdue"                     => $row->Devise_22 . ' ' .number_format($row->Amountdue_23, 2, ",", " "),
                                                "Amountpaid"                    => ($row->Amountdue_23 > $row->Amountpaid_21)
                                                                                ?'<b><span class="text-danger">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>'
                                                                                :'<b><span class="text-green">'. $row->Devise_22 . " " .number_format($row->Amountpaid_21, 2, ",", " ") .'</span></b>',
                                                "Amountduedocument"             => $row->Devise_24 .' '. number_format($Amountdocument, 2, ",", " "),
                                                "Amountcertifiedocument"        => $row->Devise_24 .' '. number_format($Amountcertifiedocument, 2, ",", " "),
                                                "Amountremaining"               => $row->Devise_34 . ' ' .number_format($row->Amountremaining_33 , 2, ",", " "),
                                                "Amountremainingdocument"       => $row->Devise_24 .' '. number_format($Amountremainingdocument, 2, ",", " "),
                                                "DateValidated"                 =>  strftime('%d-%m-%Y',strtotime($row->Date_initial_14)),
                                                "DateExpired"                   =>  strftime('%d-%m-%Y',strtotime($row->Initial_expiration_25)),
                                                "Devise"                        => $row->Devise_22,
                                                "LinkUpdateDocument"            => (isset($row->Documents_37) && $row->Documents_37 != "")
                                                                                ?'<a style="cursor:pointer" onclick="view_doc('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item" ><span class="fa fa-fw text-blue fa-folder-open f14"></span></a>'
                                                                                :'<span class="fa fa-fw text-muted fa-folder-open f14"></span>',
                                                "LinkUpdatePay"                 => '<a style="cursor:pointer" onclick="view('.$row->Id_0.')" id="item'.$row->Id_0.'" data-id-item="'.$row->Id_0.'" class="item"><span class="fa fa-fw fa-pencil text-warning"> </span></a>'
                                        ];
                                }
                        }

                        $json_data = [
                                "draw"            => intval($draw),
                                "recordsTotal"    => intval($totalRecords),
                                "recordsFiltered" => intval($totalFiltered),
                                "data"            => $data,
                                "totals"          => [
                                        "partial" => $this->licenceModel->get_total_expired_partial($filters, $categ),
                                        "force"   => $this->licenceModel->get_total_expired_force($filters, $categ),
                                        "total"   => intval($totalFiltered)
                                ]
                        ];

                        return $this->response->setJSON($json_data);
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */