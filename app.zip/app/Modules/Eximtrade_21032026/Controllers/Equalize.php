<?php

namespace Modules\Eximtrade\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Eximtrade\Models\CurlModel;
use Modules\Eximtrade\Models\DataModel;
use Modules\Eximtrade\Models\FeesModel;
use Modules\Eximtrade\Models\RatesModel;
use Modules\Eximtrade\Models\UsersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\SeguceModel;
use Modules\Eximtrade\Models\LicenceModel;
use Modules\Eximtrade\Models\ReportsModel;
use Modules\Etoll\Models\StakeholdersModel;
use Modules\Eximtrade\Models\AccountsModel;
use Modules\Eximtrade\Models\BranchesModel;
use Modules\Eximtrade\Models\IntegrationModel;
use Modules\Eximtrade\Models\PrepaymentsModel;
use Modules\Eximtrade\Models\EncaissementModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Services\Flexcube\Controllers\Flexcube;
use Modules\Services\Amplitude\Controllers\Amplitude;
use Modules\Services\FIBridge\Controllers\FIBridge;

class Equalize extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Dimitri on the 11.03.2021
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('unequalized', 'extourne', 'extourne_provision','seguce_invoices', 'invoices', 'invoices_occ', 'regul_provision', 'extourne_provision', 'regul_invoice', 'extourne_fees');
        public $roles = '5';
        public $role;
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $module = 'eximtrade';
        public $folder = 'equalize';

        public $reportsModel;
        public $feesModel;
        public $integrationModel;
        public $dataModel;
        public $accountsModel;
        public $curlModel;
        public $branchesModel;
        public $usersModel;
        public $encaissementModel;
        public $comptabilisationModel;
        public $prepaymentsModel;
        public $ratesModel;
        public $stakeholdersModel;
        public $seguceModel;
        public $logirefModel;
        public $mainModel;
        public $amplitude;
        public $flexcube;
        public $bank;
        public $functionalities;
        public $core_banking;
        public $licenceModel;
        public $fibridge;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->reportsModel = new ReportsModel();
                $this->feesModel = new FeesModel();
                $this->integrationModel = new IntegrationModel();
                $this->dataModel = new DataModel();
                $this->accountsModel = new AccountsModel();
                $this->curlModel = new CurlModel();
                $this->branchesModel = new BranchesModel();
                $this->usersModel = new UsersModel();
                $this->encaissementModel = new EncaissementModel();
                $this->comptabilisationModel = new ComptabilisationModel();
                $this->prepaymentsModel = new PrepaymentsModel();
                $this->ratesModel = new RatesModel();
                $this->stakeholdersModel = new StakeholdersModel();
                $this->seguceModel = new SeguceModel();
                $this->logirefModel = new LogirefModel();
                $this->mainModel = new MainModel();
                $this->flexcube = new Flexcube();
                $this->amplitude = new Amplitude();
                $this->licenceModel = new LicenceModel();
                $this->fibridge = new FIBridge();

                $this->folder = 'equalize';

                $this->data['module'] = $this->module;
                $this->data['application'] = 'equalize';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['folder'] = $this->folder;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->get('account_currency');
                $this->data['fullname'] = $this->session->get('user_fname');
                $this->data['userid'] = $this->session->get("user_id");
                $this->data['i'] = 0;
                $user_roles = $this->session->get('user_roles');
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {

                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->get('user_type') == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect($this->module, 'refresh');
                }

                $this->data['sidebar'] = $this->sidebars->logiref_seguce(($_SESSION['Logiref_role'] != 4)?3:4);

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $this->session->get('Logiref_groupe');
                        $this->role = $this->session->get('Logiref_role');
                } else {
                        return redirect()->to(base_url($this->module));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
                echo view('layouts/layout_main', $this->data);
        }


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "unequalized") 
                {
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_regulate();
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls_to_regulate();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls_to_regulate();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif ($obj == "extourne") 
                {
                        $day = gmdate('Y-m-d');
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("services", $service = NULL);
                        $this->data['encaissements'] = $this->reportsModel->get_paiements_to_extourne($day);

                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['bulletins'] = $this->integrationModel->get_unvalidated_bls_to_extourne($day);

                        $this->data['prepayments'] = $this->prepaymentsModel->get_unvalidated_bls_to_extourne($day);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif ($obj == "filter_extourne") 
                {
                        $this->data['regies'] = $this->logirefModel->get_dropdown("regies");
                        $this->data['encaissements'] = $this->reportsModel->get_filter_paiements_to_extourne();
                        $this->data['bulletins'] = $this->integrationModel->get_filter_unvalidated_bls_to_extourne();
                        $this->data['prepayments'] = $this->prepaymentsModel->get_filter_unvalidated_bls_to_extourne();
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif ($obj == "declaration") 
                {

                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGI", $province = NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGI");
                        $this->data['recettes'] = $recettes["DGI"];
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if (empty($encaissement)) {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                        $succes = array();

                        $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                        foreach ($instructions as $value) :
                                $succes[] = $value->Status_2;
                        endforeach;

                        if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                $this->data['validate'] = '';
                        } else {
                                $this->data['validate'] = 'disabled';
                        }

                        if (!in_array('2', $succes) && !in_array('4', $succes)) {
                                $this->data['delete'] = '';
                        } else {
                                $this->data['delete'] = 'disabled';
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif ($obj == "note") 
                {
                        $this->ratesModel->get_exchange_rates();
                        $this->data['services'] =  $this->logirefModel->get_dropdown("services", "DGRAD", $province = NULL, true);
                        $recettes = $this->logirefModel->get_dropdown('recettes', "DGRAD");
                        $this->data['recettes'] = $recettes["DGRAD"];
                        $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_tresor_info($id);
                        if (empty($encaissement)) {
                                $this->data['encaissement'] = $encaissement = $this->encaissementModel->get_paiement_propre_info($id);
                        }

                        $logirefid = isset($encaissement->Logirefid_4) ? $encaissement->Logirefid_4 : "";

                        $succes = array();

                        $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                        foreach ($instructions as $value) :
                                $succes[] = $value->Status_2;
                        endforeach;

                        if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                $this->data['validate'] = '';
                        } else {
                                $this->data['validate'] = 'disabled';
                        }

                        if (!in_array('2', $succes) && !in_array('4', $succes)) {
                                $this->data['delete'] = '';
                        } else {
                                $this->data['delete'] = 'disabled';
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif ($obj == "bulletin") 
                {
                        $bl = $id;
                        $bulletin = $this->integrationModel->get_paiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_bl($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_dgda($id);
                        $this->data['encaissement'] = $encaissement;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif ($obj == "prepayment") 
                {
                        $bl = $id;
                        $bulletin = $this->integrationModel->get_prepaiement_sydonia($id);
                        $encaissement = $this->dataModel->sydonia_migrate_prepayment($id);
                        $this->ratesModel->get_exchange_rates();
                        $this->data['bulletin'] = $bulletin;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                        $this->data['integrations'] = $this->comptabilisationModel->get_prepayment_instructions($id);
                        $this->data['encaissement'] = $encaissement;
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "get_details") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_dgda', $this->data);
                } 
                elseif ($obj == "get_details_dgi") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgi($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_dgi', $this->data);
                } 
                elseif ($obj == "get_details_dgrad") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgrad($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_dgrad', $this->data);
                } 
                elseif ($obj == "extourne_provision") 
                {
                        $this->data['provisions_validated'] = $provisions_validated = $this->seguceModel->get_provisions_validated();
                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $amount_prov_pending = 0;
                        $amount_prov_validated = 0;

                        foreach ($provisions_validated as $row) 
                        {
                                $amount_prov_validated += $row->Montantprov_10;
                        }

                        $this->data['amount_prov_pending'] = $amount_prov_pending;
                        $this->data['amount_prov_validated'] = $amount_prov_validated;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif ($obj == "regul_provision") 
                {
                        $this->data['provisions_regul'] = $provisions_regul = $this->seguceModel->get_provisions_to_regulate();
                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $amount_prov_pending = 0;
                        $amount_prov_validated = 0;

                        foreach ($provisions_regul as $row) {
                                $amount_prov_pending += $row->Montantprov_10;
                        }

                        $this->data['amount_prov_pending'] = $amount_prov_pending;
                        $this->data['amount_prov_validated'] = $amount_prov_validated;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                } 
                elseif($obj == "extourne_fees") 
                {
                        $this->data['feeseb_validated'] = $feeseb_validated = $this->seguceModel->get_fees_licence_eb_validated();
                        $this->data['fees_validated'] = $fees_validated = $this->seguceModel->get_prelevement_frais_validated();
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");

                        // Calcul des montants
                        $licence_amount = $this->data('calculate_total', $feeseb_validated) + $this->data('calculate_total', $fees_validated);

                        $this->data['licence_amount'] = $licence_amount;
                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "provision_filter") 
                {
                        $status = $id;
                        $this->data['provisions'] = $provisions = $this->seguceModel->get_provisions_filter($status);

                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $amount_prov = 0;

                        foreach ($provisions as $row) {
                                $amount_prov += $row->Montantprov_10;
                        }

                        $this->data['amount_prov'] = $amount_prov;

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif ($obj == "fees_filter") 
                {
                        $this->data['fees_validated'] = $fees_validated = $this->seguceModel->get_prelevement_frais_validated();
                        $this->data['feeseb_validated'] = $feeseb_validated = $this->seguceModel->get_licence_eb_validated_filter();

                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories");

                        // Calcul des montants
                        $licence_amount = $this->data('calculate_total', $feeseb_validated) + $this->data('calculate_total', $fees_validated);

                        $this->data['licence_amount'] = $licence_amount;

                        $this->data['statuts'] = $this->seguceModel->status_provisions;
                        $this->data['status'] = $this->seguceModel->status_validate;
                        $this->data['colors'] = $this->seguceModel->color_provisions;

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif ($obj == "provision") 
                {
                        $this->data['categories'] = $this->licenceModel->categories;
                        $this->data['merchandises'] = $this->licenceModel->merchandises;
                        $this->data['provision'] = $provision = $this->seguceModel->get_provision_info($id);

                        if (preg_match('/^EB/', $provision->CodeType_38))
                        {
                                $this->data['sub_categories'] = $this->licenceModel->get_dropdown("licence_eb");
                        }
                        elseif (preg_match('/^IB/', $provision->CodeType_38))
                        {
                                $this->data['sub_categories'] = $this->licenceModel->get_dropdown("licence_ib");
                        }
                        else
                        {
                                $this->data['sub_categories'] = array();
                        }

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                } 
                elseif($obj == "fees_licence")
                {
                        $this->data['licence'] = $this->seguceModel->get_licence_info($id);
                        $this->data['categories'] = $this->licenceModel->get_dropdown("categories","licence");

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif($obj == "seguce_invoices")
                {
                        $this->data['invoices']=$this->seguceModel->get_invoices_to_regularize();

                        return view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj,$this->data);
                }
                elseif($obj=="seguce_invoice")
                {
                        $facture = $this->seguceModel->get_invoice_by_id($id);

                        $this->ratesModel->get_exchange_rates();
                        $this->data['facture'] = $facture;
                        $this->data['controller'] = (isset($_GET['controller']) && $_GET['controller'] != "") ? $_GET['controller'] : '';
                        $this->data['view'] = (isset($_GET['view']) && $_GET['view'] != "") ? $_GET['view'] : '';
                        $this->data['integrations'] = $this->comptabilisationModel->get_instructions_seguice($id);
                        $this->data['previous_menu'] = isset($_GET['previous_menu']) ? $_GET['previous_menu'] : "";

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_seguce_invoice', $this->data);

                }
                elseif ($obj == "invoices") 
                {

                        $data_batch = array();

                        $batch_invoice = $this->seguceModel->get_invoicess_occ_batch_regul();

                        foreach ($batch_invoice as $row) {
                                $instructions = $this->seguceModel->get_instructions_invoices_occ_not_integrated($row->Id_0);

                                if (!empty($instructions)) {
                                        $data_batch[] = $this->seguceModel->get_invoices_occ_batchs_info($row->Id_0);

                                        foreach ($instructions as $row) {
                                                $data_clt[] = $row->Codeimport_28;
                                        }
                                } else {
                                        $data_batch = array();
                                }
                        }

                        $this->data['invoices'] = $data_batch;
                        //$this->data['code_imports'] = (isset($data_clt) && !empty($data_clt)) ? array_unique($data_clt) : array();
                        $this->data['code_imports'] = array();
                        //$this->data['licenses'] = $this->seguceModel->get_dropdown("invoices_occ");
                        $this->data['licenses'] = array();
                        $this->data['agence'] = $this->branchesModel->get_dropdown('guichets');
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\\' . $obj, $this->data);
                }
                elseif ($obj == "invoice") 
                {
                        $data_codeimport = array();

                        # Generation of transactions based on each licence number
                        $agence_src = $_SESSION['Logiref_guichet'];
                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);
                        $provision_account = isset($comptes['TMB']['CPF']['USD']) ? $comptes['TMB']['CPF']['USD'] : '000000000000000000000000';

                        $batch_id = $id;
                        //$instructions = $this->seguceModel->get_instructions_invoices_occ_batchs($invoice_batchId);
                        $instructions = $this->seguceModel->get_instructions_invoices_occ_not_integrated($batch_id);

                        if (!empty($instructions)) {
                                foreach ($instructions as $row) {
                                        if (!in_array($row->Codeimport_28, $data_codeimport)) {
                                                $data_codeimport[] = $row->Codeimport_28;
                                        }
                                }
                        }

                        $this->data['provision_account'] = $provision_account;
                        $this->data['batch_id'] = $batch_id;
                        $this->data['code_imports'] = $data_codeimport;
                        //$this->data['code_imports'] = (isset($data_clt) && !empty($data_clt)) ? array_unique($data_clt) : array();
                        $this->data['instructions'] = $instructions;
                        $this->data['batch'] = $this->seguceModel->get_invoices_occ_batchs_info($batch_id);
                        $this->data['invoices'] = $this->seguceModel->get_invoices_occ_by_batch_id($batch_id);
                        $this->data['guichets'] = $this->branchesModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_' . $obj, $this->data);
                }
                elseif($obj == "invoices_occ")
                {
                        $this->data['invoices'] = $this->seguceModel->get_unvalidated_invoices_occ_to_regulate();

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\\'.$obj, $this->data);
                }
                elseif ($obj == "get_details_provision")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instruction_provision($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_provision', $this->data);
                }
                elseif ($obj == "get_details_fees") 
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instruction_licence($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder . '\_details_fees', $this->data);
                }
                #Default
                elseif ($obj == "deny") {
                        $this->data['denied'] = TRUE;
                        echo view($this->folder . '_denial', $this->data);
                }
        }




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "declaration") 
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                        $data['Logirefid_4'] = $logirefid = $_POST['reference'] . $id;
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['branch_code'] = isset($_POST['branch_code']) ? $_POST['branch_code'] : "";

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing") {
                                $this->save('regularisation', $id, $_POST['action'], "DGI");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->regularize($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "reverse") {
                                $this->save('regularisation', $id, $_POST['action'], "DGI");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->extourne($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['delete'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgi($logirefid);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }

                                if (!in_array('2', $succes)) {
                                        $reverse['delete'] = true;
                                }

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "verify") {
                                $core_banking = strtolower($this->core_banking);
                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgi($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "note") 
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Paiementid_4'] = $paiementid = $_POST['paiementid'];
                        $data['Logirefid_4'] = $logirefid = $_POST['reference'] . $id;
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['branch_code'] = isset($_POST['branch_code']) ? $_POST['branch_code'] : "";

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing") {
                                $this->save('regularisation', $id, $_POST['action'], "DGRAD");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->regularize($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }
                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "reverse") {
                                //var_dump($data); die;
                                $this->save('regularisation', $id, $_POST['action'], "DGRAD");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->extourne($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['delete'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }
                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgrad($logirefid);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (in_array('3', $succes) || in_array('1', $succes) || in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }

                                if (!in_array('2', $succes)) {
                                        $reverse['delete'] = true;
                                }
                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "verify") {
                                $core_banking = strtolower($this->core_banking);

                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgrad($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }
                                if (!in_array('2', $succes)) {
                                        $reverse['delete'] = true;
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "bulletin") 
                {
                        $data['Priority'] = 1;
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Logirefid_4'] = $_POST['reference'] . $id;
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['Sydonia_44'] = $paiementid = $_POST['paiementid'];

                        $agence_src = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';


                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing") {
                                $this->save('regularisation', $id, $_POST['action'], "DGDA");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->regularize($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {

                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instructions_dgda($paiementid);

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "reverse") {
                                $this->save('regularisation', $id, $_POST['action'], "DGDA");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->extourne($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                        $reverse['response'] = $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "verify") {

                                $core_banking = strtolower($this->core_banking);
                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_dgda($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "prepayment") 
                {
                        $data['Priority'] = 1;
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Logirefid_4'] = $_POST['reference'] . $id;
                        $data['Designation_14'] = $_POST['designation'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['Type'] = 'prepayment';
                        $data['Sydonia_49'] = $paiementid = $_POST['paiementid'];

                        $agence_src = $_SESSION['Logiref_guichet'];

                        $comptes = $this->accountsModel->get_comptes_array(NULL, $agence_src, NULL);

                        $data['account_cgu'] = isset($comptes['DGDA']['CGU']['CDF']) ? $comptes['DGDA']['CGU']['CDF'] : '00000000000000000000000';

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing") {
                                $this->save('regularisation', $id, $_POST['action'], "DGDA");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->regularize($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {

                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_prepayment_instructions($paiementid);

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "reverse") {
                                $this->save('regularisation', $id, $_POST['action'], "DGDA");
                                $core_banking = strtolower($this->core_banking);

                                $response =  $this->{$core_banking}->extourne($data);

                                //var_dump($response); die;

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                        $reverse['response'] = $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "verify") {
                                $core_banking = strtolower($this->core_banking);

                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_prepayments_instructions_cbs($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "validateDeclaration") 
                {
                        $data = array();
                        $data['Status_2'] = 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->get("user_id");
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                        $pid =  $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        if ($pid) echo $id;
                        else echo "E002";
                } 
                elseif ($obj == "validateNote") 
                {
                        $data = array();
                        $data['Status_2'] = 1;
                        $data['Logirefid_4'] = $_POST['Logirefid_4'];
                        $data['Checkerid_10'] = $this->session->get("user_id");
                        $data['Validation_36 '] = gmdate('Y-m-d H:i:s');
                        $pid =  $this->encaissementModel->update_payment_tresor_by_ref($data, $data['Logirefid_4']);
                        if ($pid) echo $id;
                        else echo "E002";
                } 
                elseif ($obj == "validateBulletin") 
                {
                        $bl_data['Status_2'] = '3';
                        $bl = $this->integrationModel->update_bulletin($bl_data, $id);

                        if ($bl) echo $bl;
                        else echo "E002";
                } 
                elseif ($obj == "validate_prepayment") 
                {
                        $bl_data['Status_2'] = '3';
                        $bl =  $this->prepaymentsModel->update_prepayement($bl_data, $id);

                        if ($bl) echo $bl;
                        else echo "E002";
                } 
                else if ($obj == "delete") 
                {
                        $RecetteTYPES = $this->logirefModel->get_dropdown("type_recette");
                        $rType = $RecetteTYPES[$arg];
                        $pid = 0;

                        if ($rType == 'TRESOR' || $rType == 'RFTRESD') {
                                $pid = $this->encaissementModel->delete_paiement_tresor($id);
                        } elseif ($rType == 'PROPRES' || $rType == 'RFPROPD') {
                                $pid = $this->encaissementModel->delete_paiement_propre($id);
                        }
                        if ($pid > 0) {
                                $this->comptabilisationModel->delete_instructions_dgi($id);
                        }
                        #Return
                        echo $pid;
                        die;
                } 
                elseif ($obj == "regularisation") 
                {
                        if ($param == 'DGDA') {
                                $lines = $this->integrationModel->get_instructions_dgda_by_id($id);
                                $action = $arg;

                                if (!empty($lines)) {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = $this->session->get('account_id');

                                        $data['Paiementid_4'] = $lines->Paiementid_4;
                                        $data['Agence_6'] = $lines->Agence_6;
                                        $data['Guichet_7'] = $lines->Guichet_7;
                                        $data['Operation_8'] = $lines->Operation_8;
                                        $data['Compte_9'] = $lines->Compte_9;
                                        $data['Montant_10'] = $lines->Montant_10;
                                        $data['Devise_11'] = $lines->Devise_11;
                                        $data['Libelle_12'] = $lines->Libelle_12;
                                        $data['Compte_13'] = $lines->Compte_13;
                                        $data['Reference_14'] = $lines->Reference_14;
                                        $data['Mode_15'] = $lines->Mode_15;
                                        $data['Makerid_16'] = $lines->Makerid_16;
                                        $data['Checkerid_17'] = $lines->Checkerid_17;
                                        $data['Validation_18'] = $lines->Validation_18;
                                        $data['Integration_20'] = gmdate('Y-m-d H:i:s');
                                        if ($arg == 'reverse') $data['Action_21'] = 'Extourne';
                                        else $data['Action_21'] = 'Regularisation';

                                        $this->integrationModel->save_regularisations($data, NULL);
                                }
                        } elseif ($param == 'DGDA_prepay') {
                                $lines = $this->integrationModel->get_instructions_dgda_prepayment_by_id($id);
                                $action = $arg;

                                if (!empty($lines)) {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = $this->session->get('account_id');

                                        $data['Paiementid_4'] = $lines->Paiementid_4;
                                        $data['Agence_6'] = $lines->Agence_6;
                                        $data['Guichet_7'] = $lines->Guichet_7;
                                        $data['Operation_8'] = $lines->Operation_8;
                                        $data['Compte_9'] = $lines->Compte_9;
                                        $data['Montant_10'] = $lines->Montant_10;
                                        $data['Devise_11'] = $lines->Devise_11;
                                        $data['Libelle_12'] = $lines->Libelle_12;
                                        $data['Compte_13'] = $lines->Compte_13;
                                        $data['Reference_14'] = $lines->Reference_14;
                                        $data['Mode_15'] = $lines->Mode_15;
                                        $data['Makerid_16'] = $lines->Makerid_16;
                                        $data['Checkerid_17'] = $lines->Checkerid_17;
                                        $data['Validation_18'] = $lines->Validation_18;
                                        $data['Integration_20'] = gmdate('Y-m-d H:i:s');
                                        if ($arg == 'reverse') $data['Action_21'] = 'Extourne';
                                        else $data['Action_21'] = 'Regularisation';

                                        $this->integrationModel->save_regularisations($data, NULL);
                                }
                        } elseif ($param == 'DGI') {
                                $lines = $this->integrationModel->get_instructions_dgi_by_id($id);
                                $action = $arg;

                                if (!empty($lines)) {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = $this->session->get('account_id');

                                        $data['Paiementid_4'] = $lines->Paiementid_4;
                                        $data['Agence_6'] = $lines->Agence_6;
                                        $data['Guichet_7'] = $lines->Guichet_7;
                                        $data['Operation_8'] = $lines->Operation_8;
                                        $data['Compte_9'] = $lines->Compte_9;
                                        $data['Montant_10'] = $lines->Montant_10;
                                        $data['Devise_11'] = $lines->Devise_11;
                                        $data['Libelle_12'] = $lines->Libelle_12;
                                        $data['Compte_13'] = $lines->Compte_13;
                                        $data['Reference_14'] = $lines->Reference_14;
                                        $data['Mode_15'] = $lines->Mode_15;
                                        $data['Makerid_16'] = $lines->Makerid_16;
                                        $data['Checkerid_17'] = $lines->Checkerid_17;
                                        $data['Validation_18'] = $lines->Validation_18;
                                        $data['Integration_20'] = gmdate('Y-m-d H:i:s');
                                        if ($arg == 'reverse') $data['Action_21'] = 'Extourne';
                                        else $data['Action_21'] = 'Regularisation';

                                        $this->integrationModel->save_regularisations($data, NULL);
                                }
                        } elseif ($param == 'DGRAD') {
                                $lines = $this->integrationModel->get_instructions_dgrad_by_id($id);
                                $action = $arg;

                                if (!empty($lines)) {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = $this->session->get('account_id');

                                        $data['Paiementid_4'] = $lines->Paiementid_4;
                                        $data['Agence_6'] = $lines->Agence_6;
                                        $data['Guichet_7'] = $lines->Guichet_7;
                                        $data['Operation_8'] = $lines->Operation_8;
                                        $data['Compte_9'] = $lines->Compte_9;
                                        $data['Montant_10'] = $lines->Montant_10;
                                        $data['Devise_11'] = $lines->Devise_11;
                                        $data['Libelle_12'] = $lines->Libelle_12;
                                        $data['Compte_13'] = $lines->Compte_13;
                                        $data['Reference_14'] = $lines->Reference_14;
                                        $data['Mode_15'] = $lines->Mode_15;
                                        $data['Makerid_16'] = $lines->Makerid_16;
                                        $data['Checkerid_17'] = $lines->Checkerid_17;
                                        $data['Validation_18'] = $lines->Validation_18;
                                        $data['Integration_20'] = gmdate('Y-m-d H:i:s');
                                        if ($arg == 'reverse') $data['Action_21'] = 'Extourne';
                                        else $data['Action_21'] = 'Regularisation';

                                        $this->integrationModel->save_regularisations($data, NULL);
                                }
                        }
                }
                elseif($obj=="regularize_invoice")
                {
                        $data = $_POST;
                        $code = '';
                        $validation = array();
                        $errors = array();

                        $factureid = isset($_POST['factureid']) ? $_POST['factureid'] : "";

                        $facture = $this->seguceModel->get_invoice_by_id($factureid);

                        if(!empty($facture))
                        {
                                #Is this a validation? Yes if it's a validator or the supervisor
                                        if ($this->session->get('Logiref_role') == 3 || $this->session->get('Logiref_role') == 2) {
                                                # Priority of transactions to send to the API set to 1.
                                                $data['Priority'] = "";
                                                $data['Status_2'] = 5;

                                                $data['Seguce_53'] = $facture->Id_0;
                                                $data['Beneficaire_15'] = 'SEGUCE';
                                                $data["Designation_14"] = $facture->Debiteur_25;
                                                $data['Account_3'] = $this->session->userdata['account_id'];

                                                $data_to_send["ID"] = $facture->Factureid_5;
                                                $data_to_send["BankActorCode"] = $facture->Bank_4;
                                                $data_to_send["Date"] = $facture->Date_1;
                                                $data_to_send["InternalReference"] = $facture->Reference_7;
                                                $data_to_send["DebtorActorName"] = $facture->Debiteur_25;
                                                $data_to_send["CreditorActorName"] = $facture->Creditaire_26;
                                                $data_to_send["NetAmount"] = $facture->Montant_11;
                                                $data_to_send["Currency"] = $facture->Devise_12;
                                                $data_to_send["AccountNumber"] = $facture->Account_15;
                                                $data_to_send["AccountOwner"] = $facture->Debiteur_25;
                                                $data_to_send["PaymentMethod"] = '7';
                                                $data_to_send["TransactionReference"] = $facture->Reference_7;
                                                $data_to_send["TransactionDate"] = $facture->Date_1;
                                                $data_to_send["ContractType"] =$facture->Contracttype_46;
                                                $data_to_send["Status"] = "Issued";

                                                if($facture->Status_2==6)
                                                {
                                                        $response = $this->curl(base_url('services/seguce/settleInvoice'),'POST',json_encode($data_to_send));
                                                        $return = json_decode($response,true);

                                                        if(isset($return['code']) && $return['code']=='200')
                                                        {
                                                                $code = 200;
                                                                $id = $facture->Id_0;
                                                                
                                                                $facture_data['Status_2'] = '3';
                                                                $this->seguceModel->update_invoice($facture_data, $id);
                                                        }
                                                        else
                                                        {
                                                                $code = 302;
                                                                $errors[$facture->Id_0] = $code;
                                                        }    
                                                }
                                                elseif($facture->Status_2==5)
                                                {
                                                        #Invocation of the api transfer
                                                        @set_time_limit(300);
                                                        $core_banking = strtolower($this->core_banking);

                                                        $return = $this->{$core_banking}->regularize_seguce_invoice($data);

                                                        $instructions = $this->seguceModel->get_instructions_invoice($facture->Id_0);

                                                        $validation['response'] = $return['response'];
                                                        $validation['instructions'] = $instructions;
                                                        
                                                        if (isset($return['response']) && $return['response'] == "200") 
                                                        {

                                                                $facture_data['Status_2'] = 6;
                                                                $this->seguceModel->update_invoice($facture_data, $factureid);

                                                                $response = $this->curl(base_url('services/seguce/settleInvoice'),'POST',json_encode($data_to_send));
                                                                $return = json_decode($response,true);

                                                                if(isset($return['code']) && $return['code']=='200')
                                                                {
                                                                        $code = 200;
                                                                        $id = $facture->Id_0;
                                                                          
                                                                        $facture_data['Status_2'] = '3';
                                                                        $this->seguceModel->update_invoice($facture_data, $id);
                                                                }
                                                                else
                                                                {
                                                                        $code = 302;
                                                                        $errors[$facture->Id_0] = $code;
                                                                }  
                                                        }
                                                        elseif (isset($return['response']) && $return['response'] == "300") 
                                                        {
                                                                $code = 300;
                                                                $id = $facture->Id_0;

                                                                $data_to_validate['Status_2'] = 1;
                                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];


                                                                # Update the paiement related to the bulletin

                                                                $facture_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice($facture_data, $id);

                                                                $errors[$facture->Id_0] = $code;
                                                        } elseif (isset($return['response']) && $return['response'] == "404") {
                                                                $code = 404;
                                                                $id = $facture->Id_0;

                                                                $data_to_validate['Status_2'] = 1;
                                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                                # Update the paiement related to the bulletin
                                                                


                                                                $facture_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice($facture_data, $id);

                                                                $errors[$facture->Id_0] = $code;
                                                        } elseif (isset($return['response']) && $return['response'] == "411") {
                                                                $code = 411;
                                                                $id = $facture->Id_0;

                                                                $data_to_validate['Status_2'] = 1;
                                                                $data_to_validate['Validation_36'] = gmdate('Y-m-d H:i:s');
                                                                $data_to_validate['Checkerid_10'] = $this->session->userdata['user_id'];

                                                                # Update the paiement related to the bulletin

                                                                $facture_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice($facture_data, $id);

                                                                $errors[$facture->Id_0] = $code;
                                                        } elseif (isset($return['response']) && $return['response'] == "405") {
                                                                # Aucune ecriture trouvE
                                                                $code = 405;
                                                                $id = $facture_update = $facture->Id_0;

                                                                $facture_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice($facture_data, $id);

                                                                $errors[$facture->Id_0] = $code;
                                                        } elseif ($return == false || $return == NULL) {
                                                                $code = 202;
                                                                $id = $facture->Id_0;

                                                                $facture_data['Status_2'] = '5';
                                                                $this->seguceModel->update_invoice($facture_data, $id);

                                                                $errors[$facture->Id_0] = $code;
                                                        }


                                                }
                                }
                        }
                        
                        
                        if (!empty($errors)) 
                        {
                                $validation['errors'] = true;
                                $validation['error_code'] = $code;
                        } 
                        else 
                        {
                                $validation['errors'] = false;
                                $validation['error_code'] = $code;
                        }

                        $result = json_encode($validation);

                        echo $result;
                }
                elseif ($obj == "provision")
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Reference_17'] = $reference = $_POST['reference'];
                        $data['Paiementid_4'] = $_POST['paiementid'];

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing")
                        {
                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->regularize($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == 200) {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instruction_provision($reference);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }

                                echo json_encode($reverse);
                                die;
                        }
                        elseif ($_POST['action'] == "reverse")
                        {
                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->extourne_provision($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['cancel'] = false;
                                $reverse['delete'] = false;

                                if ($result['response'] == 200) {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all transactions have been reveraled with success
                                $instructions  = $this->comptabilisationModel->get_instruction_provision($_POST['paiementid']);

                                foreach ($instructions as $value) :
                                        $lines[] = $value->Status_2;
                                endforeach;

                                if (!in_array('2', $lines)) {
                                        $reverse['cancel'] = true;

                                        $data = array();
                                        $data['Status_2'] = 0;
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changes_6'] = $this->session->get("user_id");

                                        $pid =  $this->seguceModel->save_provision($data, $_POST['paiementid']);
                                }

                                echo json_encode($reverse);
                                die;
                        }
                        elseif ($_POST['action'] == "verify")
                        {
                                $core_banking = strtolower($this->core_banking);
                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == 200) {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                }
                elseif ($obj == "fees_licence") 
                {
                        $data = array();
                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Reference_17'] = $reference = $_POST['reference'];
                        $data['Paiementid_4'] = $_POST['paiementid'];

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing")
                        {
                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->regularize($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all integrations  are integrated with success
                                $instructions  = $this->comptabilisationModel->get_instruction_provision($reference);
                                foreach ($instructions as $value) :
                                        $succes[] = $value->Status_2;
                                endforeach;

                                if (!in_array('3', $succes) && !in_array('1', $succes) && !in_array('4', $succes)) {
                                        $reverse['validate'] = true;
                                }

                                echo json_encode($reverse);
                                die;
                        } 
                        elseif ($_POST['action'] == "reverse") 
                        {
                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->extourne_provision($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['cancel'] = false;
                                $reverse['delete'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }

                                // check if all transactions have been reveraled with success
                                $instructions  = $this->comptabilisationModel->get_instruction_provision($_POST['paiementid']);

                                foreach ($instructions as $value) :
                                        $lines[] = $value->Status_2;
                                endforeach;

                                if (!in_array('2', $lines)) {
                                        $reverse['cancel'] = true;

                                        $data = array();
                                        $data['Status_2'] = 0;
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changes_6'] = $this->session->get("user_id");

                                        $pid =  $this->seguceModel->save_provision($data, $_POST['paiementid']);
                                }

                                echo json_encode($reverse);
                                die;
                        } 
                        elseif ($_POST['action'] == "verify") 
                        {
                                $core_banking = strtolower($this->core_banking);
                                $result =  $this->{$core_banking}->check_event($data);

                                $succes = array();
                                $reverse = array();

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == '300') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                } elseif ($result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 4;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_provisions($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "invoice") 
                {
                        $data = array();
                        $data_updated = array();

                        if ((isset($_POST['compte']) && $_POST['compte'] != "") && (isset($_POST['devise']) && $_POST['devise'] != "")) {
                                $data_updated['Compte_9'] = $_POST['compte'];
                                $data_updated['Devise_11'] = $_POST['devise'];

                                $this->comptabilisationModel->update_instructions_cbs_occ($id, $data_updated);
                        }

                        $data['Id_0'] = $id;
                        $data['Account_3'] = $this->session->get('account_id');
                        $data['Paiementid_4'] = $_POST['paiementid'];
                        $data['Beneficaire_15'] = $_POST['regie'];
                        $data['Reference'] = $_POST['reference'];

                        // Forcage de l'ecriture
                        if ($_POST['action'] == "forcing") {
                                $data['batch_id'] = $_POST['paiementid'];
                                $data["Codeimport_28"] = $_POST['codeimport'];
                                $data['Priority'] = 1;

                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->regularize_invoice($data);
                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['validate'] = false;

                                if (isset($result['response']) && $result['response'] == "200") {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 3;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);
                                        $reverse['response'] = $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 5;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);
                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        } elseif ($_POST['action'] == "reverse") {
                                $core_banking = strtolower($this->core_banking);
                                $response =  $this->{$core_banking}->extourne_invoice_occ($data);

                                $result = json_decode($response, true);

                                $succes = array();
                                $reverse = array();
                                $reverse['cancel'] = false;
                                $reverse['delete'] = false;

                                if ($result['response'] == '200') {
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);

                                        $reverse['response'] = "E200";
                                } elseif ($result['response'] == 'DE-TUD-055' || $result['response'] == 'DE-TUD-099' || $result['response'] == 'ST-UPLD113' || $result['response'] == 'AC-IBLCYWOT' || $result['response'] == '305' || $result['response'] == '300' || $result['response'] == '411' || $result['response'] == '404' || $result['response'] == '405') {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                } else {
                                        $data = array();
                                        $data['Status_2'] = 2;
                                        $data['Checkerid_17'] = $this->session->get("user_id");
                                        $pid = $this->comptabilisationModel->update_instructions_cbs_occ($id, $data);

                                        $reverse['response'] = "E" . $result['response'];
                                }

                                echo json_encode($reverse);
                                die;
                        }
                } 
                elseif ($obj == "validate_provision")
                {
                        $data = array();
                        $data['Status_2'] = 2;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changes_6'] = $this->session->get("user_id");

                        $pid =  $this->seguceModel->save_provision($data, $id);

                        if ($pid) echo $id;
                        else echo "E002";
                }
                elseif ($obj == "cancel_provision")
                {
                        $data = array();
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changes_6'] = $this->session->get("user_id");

                        $pid =  $this->seguceModel->save_provision($data, $id);

                        if ($pid) echo $id;
                        else echo "E002";
                }
        }




        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "get_users") {
                        if ($data != "" && $data != NULL) {
                                $members = $this->usersModel->get_members($data);
                        } else {
                                $members = $this->usersModel->get_members();
                        }

                        $members = $this->usersModel->get_members();

                        return $members;
                }
                else if ($obj == "calculate_total")
                {
                        if (!is_array($data)) 
                        {
                                return 0;
                        }

                        return array_reduce($data, function ($carry, $row) {
                                return $carry + $row->MontantCIF_8;
                        }, 0);
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
