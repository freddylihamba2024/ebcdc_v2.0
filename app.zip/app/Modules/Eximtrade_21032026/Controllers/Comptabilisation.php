<?php

namespace Modules\Eximtrade\Controllers;

use App\Controllers\BaseController;
use Modules\Logiref\Models\LogirefModel;
use Modules\Eximtrade\Models\ComptabilisationModel;
use Modules\Eximtrade\Models\IntegrationModel;

class Comptabilisation extends BaseController {
        /*
         * Presentation:
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $data = array();
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'eximtrade';
        public $folder = 'comptabilisation';
        public $role;
        public $logirefModel;
        public $comptabilisationModel;
        public $integrationModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project
                 * Submodule or application is activities
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->comptabilisationModel = new ComptabilisationModel();
                $this->logirefModel = new LogirefModel();
                $this->integrationModel = new IntegrationModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'seguce';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises2;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata['user_id'];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        return redirect()->to(base_url($this->module));
                }

	}

	public function index()
	{
                $this->data['subview'] = '\Modules\Eximtrade\Views\container';
		echo view("layouts/layout_main", $this->data);
	}

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "get_details")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgi")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgi($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_comptabilisation', $this->data);
                }
                elseif($obj == "get_details_dgrad")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instructions_dgrad($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_comptabilisation', $this->data);
                }
	        elseif($obj == "get_details_provision")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instruction_provision($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_comptabilisation_provision', $this->data);
                }
                elseif($obj == "get_details_licence")
                {
                        /* Get data from DB Integration*/
                        $ref = $id;
                        $this->data['lines'] = $this->comptabilisationModel->get_instruction_licence($ref);

                        echo view('\Modules\Eximtrade\Views\\' . $this->folder.'\_comptabilisation_licence', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Eximtrade\Views\\'.$this->lang . '_denial', $this->data);
                }
	}

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
                elseif($obj == "OBJ ")
                {

                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */