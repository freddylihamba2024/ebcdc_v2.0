<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class ComptabilisationModel extends MY_Transaction {

        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        public $months = array
        (
                '00' => '',
                '01' => 'Janvier',
                '02' => 'Fevrier',
                '03' => 'Mars',
                '04' => 'Avril',
                '05' => 'Mai',
                '06' => 'Juin',
                '07' => 'Juillet',
                '08' => 'Aout',
                '09' => 'Septembre',
                '10' => 'Octobre',
                '11' => 'Novembre',
                '12' => 'Decembre'
        );
        
        public $services_codes = array
                (
                        '0100' => 'ADMINISTRATION CENTRALE',
                        '0200' => 'KIN OUEST', 
                        '0300' => 'KIN EST',
                        '0400' => 'KATANGA', 
                        '0500' => '', 
                        '0600' => '',
                        '0700' => '', 
                        '0800' => '', 
                        '0900' => '',
                        '1000' => '',
                );
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_dgda($bl) 
        {
                $st = " Paiementid_4 ='" . $bl . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_dgda')
                        ->select('logiref_cbs_instructions_dgda.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_dgda.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_prepayment_instructions($bl) 
        {
                $st = " Paiementid_4 ='" . $bl . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_prepayments_instructions')
                        ->select('logiref_cbs_prepayments_instructions.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_prepayments_instructions.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_dgi($id) 
        {
                $st = " Paiementid_4='" . $id . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_dgi')
                        ->select('logiref_cbs_instructions_dgi.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_dgi.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_dgrad($id) 
        {
                $st = " Paiementid_4='" . $id . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_dgrad')
                        ->select('logiref_cbs_instructions_dgrad.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_dgrad.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ($id) 
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 AND Montant_10 > 0";

                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_seguce($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                $regie = 'DGDA';

                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 

                $compte_dst = isset($comptes[$data['Typerecette_17']]) ? $comptes[$data['Typerecette_17']][$data['Devise_12']] : '00000000000000000000000';

                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                $monant = ($data['Notemontant_28'] * $data['Taux_41']);
                $libelle =  $data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];

                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_cgu,
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$monant, 
                                            'Devise_11'=>$data['Devise_12'],
                                            'Compte_13'=>$compte_dst
                                    );

                return $instruction;
        }

        public function get_instructions_seguice($id) 
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 AND Montant_10 > 0";

                $builder = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_seguce.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_seguice_by_priority($id,$priority=null) 
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 AND Montant_10 > 0 AND Priority_24='".$priority."'";

                $builder = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_seguce.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instruction_provision($id) 
        {
                $st = " Paiementid_4='" . $id . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_provision')
                        ->select(' logiref_cbs_instructions_provision.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_provision.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instruction_licence($id) 
        {
                $st = " Paiementid_4='" . $id . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_licence')
                        ->select('logiref_cbs_instructions_licence.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_licence.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instruction_invoices($id, $clt) 
        {
            $account = $this->session->userdata['account_id'];
            $st = "Status_2 != '0' AND Account_3 = '".$account."' AND Paiementid_4 = '".$id."' AND Codeimport_28 IN (".$clt.")";
            $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                    ->select('logiref_cbs_instructions_invoice_occ.*')
                    ->where($st)
                    ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                    ->limit(500)
                    ->get();
            return $builder->getResult();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Identification du scenario ou cas de comptabalisation
         * *************************************************************************************************************************SCETION 2
        */
        public function get_use_case($data)
        {
                ##################### Cas 2 ############################################
                //Ordre de paiement: devise compte client === devise recette en CDF === devise commission
                if($data['Devise_34']==$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }

                ##################### Cas 3 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise compte client === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_34']==$data['Devise_24'])
                {
                        return "case_2";
                }
                
                ##################### Cas 4 ############################################
                //Ordre de paiement: devise compte client <> devise recette en CDF
                //Mais  devise recette === devise commission
                elseif($data['Devise_34']!=$data['Devise_12'] && $data['Devise_12']==$data['Devise_24'])
                {
                        return "case_2";
                }
                elseif($data['Devise_34']==$data['Devise_12'] && $data['Devise_12']!=$data['Devise_24'])
                {
                        return "case_2";
                }
                else 
                {
                     return "case_0";
                }
        }
        
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Instruction de comptabilisation
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_instructions_case_1($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'];
                }
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'C', 
                                                'Compte_9'=>$compte_dst, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12']
                                            );
                        $instructions[] = $instruction;
                }
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_cfb, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                $instructions[] = $instruction;
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'C', 
                                        'Compte_9'=>$compte_tva, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24']
                                    );
                
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        ##################### Cas 2 ############################################
        //Ordre de paiement: compte client et recette a payer en CDF/ou en USD
        public function get_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                {
                        $data['Taux_41'] = $taux = $data['Taux_41'];
                }
                else 
                {
                        $taux = json_decode($this->session->get('Bank_rates'), true);
                        $data['Taux_41'] = $taux['Dollar_4'];
                }		
                
                if($data["Beneficaire_15"] != 'DGDA')
                {
                        $infos = json_decode($data["Notereference_30"], true);
                }
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'_'.$services.'_'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'_'.$services.'-'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                        }
                }
                elseif($regie=="DGDA")
                {
                        $libelle = $data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                }
                else
                {
                        if($data['Typerecette_17']=='27022470')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'_'.$data['Service_16'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                        }
                        else 
                        {
                                $libelle = $data['Beneficaire_15'].'_'.$data['Service_16'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
                        }
                        
                }
                
                # Montant de la note
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                {
                        $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_debit = $montant_credit = $data['Montant_11'];
                }
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode);
                        $instructions[] = $instruction;
                }
                else
                {
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                $instruction = array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$data['Compte_33'], 
                                                        'Libelle_12'=>$libelle, 
                                                        'Montant_10'=>$montant_debit, 
                                                        'Devise_11'=>$data['Devise_34'],
                                                        'Montant_25'=>$montant_credit, 
                                                        'Devise_26'=>$data['Devise_12'],
                                                        'Compte_13'=>$compte_dst
                                                    );
                                $instructions[] = $instruction;
                        }
                        else
                        {
                                $instruction = array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$data['Compte_33'], 
                                                        'Libelle_12'=>$libelle, 
                                                        'Montant_10'=>$montant_debit, 
                                                        'Devise_11'=>$data['Devise_34'],
                                                        'Montant_24'=>$montant_credit, 
                                                        'Devise_25'=>$data['Devise_12'],
                                                        'Compte_13'=>$compte_dst
                                                    );
                                $instructions[] = $instruction;
                        }
                }
                
                # Montant frais bancaire
                
                # Taux moyen à appliquer pour la commission
                $taux = json_decode($this->session->get('Bank_rates'), true);
                $taux = $taux['Dollar_4'];
                
                if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                {
                        $montant_debit_frais = $data['Commission_23'] / $taux;
                        
                        $montant_credit_frais = $data['Commission_23'];
                }
                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                {
                        $montant_debit_frais = $data['Commission_23'] * $taux;
                        
                        $montant_credit_frais = $data['Commission_23'];
                }
                else 
                {
                        $montant_debit_frais = $montant_credit_frais = $data['Commission_23'];
                }
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais_bancaire_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_frais, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_25'=>$montant_credit_frais, 
                                                'Devise_26'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                else 
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_frais, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_24'=>$montant_credit_frais, 
                                                'Devise_25'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                
                
                # Montant tva
                
		if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                {
                        $montant = $data['Commission_23']*0.16;
                        
                        $montant_debit_tva = $montant / $taux;
                        
                        $montant_credit_tva = $montant;
                }
                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                {
                        $montant = $data['Commission_23']*0.16;
                        
                        $montant_debit_tva = $montant * $taux;
                        
                        $montant_credit_tva = $montant;
                }
                else 
                {
                        $montant = $data['Commission_23']*0.16;
                        $montant_debit_tva  = $montant_credit_tva = $montant;
                }		
				
                if($data['Beneficaire_15'] != 'DGDA')
                {
                        if(!isset($infos["tva"]))
                        {
                                $montant_debit_tva  = $montant_credit_tva = 0;
                        }
                }
                else
                {
                        if(isset($data['tva']) && $data['tva'] == "")
                        {
                                $montant_debit_tva  = $montant_credit_tva = 0;
                        }
                }
                
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'TVA_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_tva, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_25'=>$montant_credit_tva, 
                                                'Devise_26'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_tva
                                            );
                        $instructions[] = $instruction;
                }
                else 
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_tva, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_24'=>$montant_credit_tva, 
                                                'Devise_25'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_tva
                                            );
                        $instructions[] = $instruction;
                }
                
                # Montant frais bcc
                $montant_credit_bcc = $montant_debit_bcc = 0;
                
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        $montant = $data['Montant_11']*0.0005;
                    
                        $montant_debit_bcc = $montant / $data['Taux_41'];
                        
                        $montant_credit_bcc = $montant;
						
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                                {
                                        $montant_credit_bcc = $data['frais_bcc'];

                                        $montant_debit_bcc = $data['frais_bcc'] / $data['Taux_41'];
                                }
                                else
                                {
                                        if(isset($_SESSION['frais_bcc']))
                                        {
                                                $montant_credit_bcc = $this->session->get('frais_bcc');

                                                $montant_debit_bcc = $this->session->get('frais_bcc') / $data['Taux_41'];
                                        }
                                }
                        }
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                {
                        $montant_debit_bcc = $montant_credit_bcc = 0;
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant = $data['Montant_11']*0.0005;
                        $montant_debit_bcc = $montant_credit_bcc = $montant;
						
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                                {
                                        $montant_credit_bcc = $montant_debit_bcc = $data['frais_bcc'];
                                }
                                else
                                {
                                        if(isset($_SESSION['frais_bcc']))
                                        {
                                                $montant_credit_bcc = $montant_debit_bcc = $this->session->get('frais_bcc');
                                        }
                                }
                        }

                        if($data['Devise_12'] == 'USD')
                        {
                                $montant_debit_bcc = $montant_credit_bcc = 0;
                        }
                }
				
                
                # Operation 4: crediter le compte frais bcc
                $compte_cfb = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais_BCC_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                
                if($data['Beneficaire_15'] == 'DGDA')
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_bcc, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_25'=>$montant_credit_bcc, 
                                                'Devise_26'=>'CDF',
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$montant_debit_bcc, 
                                                'Devise_11'=>$data['Devise_34'],
                                                'Montant_24'=>$montant_credit_bcc, 
                                                'Devise_25'=>'CDF',
                                                'Compte_13'=>$compte_cfb
                                            );
                        $instructions[] = $instruction;
                }
                
                return $instructions;
        }
        
        public function get_prepayment_instructions_case_2($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                {
                        $data['Taux_41'] = $taux = $data['Taux_41'];
                }
                else 
                {
                        $taux = json_decode($this->session->get('Bank_rates'), true);
                        $data['Taux_41'] = $taux['Dollar_4'];
                }
                
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                $compte_commision = (isset($data['Comptec']) && $data['Comptec'] > 0)? $data['Comptec'] : $data['Compte_33'];
                $devise_compte = (isset($data['Devisec']) && $data['Devisec'] !="")? $data['Devisec'] : $data['Devise_34'];
                $date_emission = strftime('%d/%m/%Y',strtotime($data['Notedate_27']));
                $date_emission = str_replace("/", "", $date_emission);

                $libelle = $date_emission.'-'.$data['Noteid_26'].'-'.$data['Designation_14'];
                
                
                # Montant de la note
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                {
                        $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_debit = $montant_credit = $data['Montant_11'];
                }
               
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_27'=>$montant_credit, 
                                        'Devise_26'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                $instructions[] = $instruction;
                
                
                # Montant frais bancaire
                if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                {
                        $montant_debit_frais = $data['Commission_23'] / $data['Taux_41'];
                        
                        $montant_credit_frais = $data['Commission_23'];
                }
                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                {
                        $montant_debit_frais = $data['Commission_23'] * $data['Taux_41'];
                        
                        $montant_credit_frais = $data['Commission_23'];
                }
                else 
                {
                        $montant_debit_frais = $montant_credit_frais = $data['Commission_23'];;
                }
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais_bancaire_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit_frais, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_27'=>$montant_credit_frais, 
                                        'Devise_26'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                # Montant tva
		if($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='USD')
                {
                        $montant = $data['Commission_23']*0.16;
                        
                        $montant_debit_tva = $montant / $data['Taux_41'];
                        
                        $montant_credit_tva = $montant;
                }
                elseif($data['Devise_34'] != $data['Devise_24'] && $data['Devise_34'] =='CDF')
                {
                        $montant = $data['Commission_23']*0.16;
                        
                        $montant_debit_tva = $montant * $data['Taux_41'];
                        
                        $montant_credit_tva = $montant;
                }
                else 
                {
                        $montant = $data['Commission_23']*0.16;
                        $montant_debit_tva  = $montant_credit_tva = $montant;
                }		
				
                
                if(!isset($infos["tva"]))
                {
                        $montant_debit_tva  = $montant_credit_tva = 0;
                }
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                $compte_tva = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'TVA_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit_tva, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_27'=>$montant_credit_tva, 
                                        'Devise_26'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                
                
                return $instructions;
        }
        
        
        public function get_instructions_frais_bcc_dgda($data, $comptes, $compte_debit, $devise_compte)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                
                if(isset($data['Taux_41']) && $data['Taux_41'] > 0)
                {
                        $data['Taux_41'] = $taux = $data['Taux_41'];
                }
                else 
                {
                        $taux = json_decode($this->session->get('Bank_rates'), true);
                        $data['Taux_41'] = $taux['Dollar_4'];
                }
                
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $devise_compte)
                {
                        if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                        {
                                $montant_credit = $data['frais_bcc'];
                                $montant_debit = $data['frais_bcc']/$data['Taux_41'];
                        }
                        else
                        {
                                $montant_credit = $montant_debit = 0;
                        }
                        
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34'] || $data['Devise_12'] == 'USD' && $data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_credit = $montant_debit = 0;
                }
                elseif($data['Devise_12'] == $devise_compte) 
                {
                        if(isset($data['frais_bcc']) && $data['frais_bcc'] !="")
                        {
                                $montant_credit = $montant_debit = $data['frais_bcc'];
                        }
                        else
                        {
                                $montant_credit = $montant_debit = 0;
                        }
                }
				
                
                # Operation 4: crediter le compte frais bcc
                $compte_cfb = isset($comptes[$bank_code]['FBC']['CDF']) ? $comptes[$bank_code]['FBC']['CDF'] : '000000000000000000000000'; 
                
                if(isset($data['Sydonia_49']) && $data['Sydonia_49'] != 0)
                {
                        $libelle = 'Frais BCC Compensation '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                }
                else
                {
                        $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                }
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_debit, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$devise_compte,
                                        'Montant_27'=>$montant_credit, 
                                        'Devise_26'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        ##################### Cas 3 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_3($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_cdt = 'CPU' : $compte_cdt = 'CCV';
                $compte_dst = isset($comptes[$bank_code][$compte_cdt][$data['Devise_34']]) ? $comptes[$bank_code][$compte_cdt][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = $data['Montant_11'] / $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                }
                
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_cdt, 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_dst
                                );
                $instructions[] = $instruction;
                
                
                
                # Operation 2: debiter soit le compte position en USD ou soit le compte contr-valeur en CDF
                # pour crediter soit le compte passage en USD ou soit le compte guichet unique
                
                //Compter a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compter a crediter
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;;
                }
				
				# Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
						if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_dbt, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
				
				
                # Operation 3: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                # Operation 4: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                
                $instructions[] = $instruction;
                
                
                # Operation 5: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Montant_11']*0.005), 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        ##################### Cas 4 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_4($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
				
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                //Compte a crediter
                ($data['Devise_34']=="USD") ? $compte_cdt = 'CPU' : $compte_cdt = 'CCV';
                $compte_dst = isset($comptes[$bank_code][$compte_cdt][$data['Devise_34']]) ? $comptes[$bank_code][$compte_cdt][$data['Devise_34']] : '00000000000000000000000'; 
                
                //Montant a crediter: la contre-valeur
                ($data['Devise_34']=="USD") ? $montant_cdt = ($data['Montant_11'] + $data['Commission_23'] + ($data['Commission_23'] * 0.16))/ $data['Taux_41'] : $montant_cdt = $data['Montant_11'] * $data['Taux_41'];
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
                }
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_cdt, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 2: debiter soit le compte position en USD ou soit le compte contr-valeur en CDF
                # pour crediter soit le compte passage en USD ou soit le compte guichet unique
                
                //Compte a debiter
                ($data['Devise_34']=="USD") ? $compte_src = 'CCV' : $compte_src = 'CPU';
                $compte_dbt = isset($comptes[$bank_code][$compte_src][$data['Devise_12']]) ? $comptes[$bank_code][$compte_src][$data['Devise_12']] : '00000000000000000000000'; 
                
                //Compte a crediter
                ($regie=="DGDA") ? $compte_cdt= 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
                }
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$compte_dbt, 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
                
                # Operation 3: crediter le compte commission de la banque
                # Devise compte === devise commission
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_24']]) ? $comptes[$bank_code]['CFB'][$data['Devise_24']] : '000000000000000000000000'; 
                
                
                $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;

                # Operation 5: crediter le compte TVA de la banque
                # Devise compte === devise commission
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_dbt, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_tva
                                    );
				
                $instructions[] = $instruction;
                
                # Operation 6: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Montant_11']*0.005), 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
				
                return $instructions;
        }
        
        
        ##################### Cas 5 ############################################
        //Ordre de paiement: compte client et recette a payer en des devises differentes 
        public function get_instructions_case_5($data, $comptes,$regie, $comptes_recettes_dgi = NULL, $services = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
				
				
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                
                ($regie=="DGDA") ? $compte_cdt = 'CGU' : $compte_cdt = 'CPT';
                $compte_dst = isset($comptes[$regie][$compte_cdt][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$data['Devise_12']] : '00000000000000000000000'; 
                
                if($regie=="DGI")
                {
                        if($data['Typerecette_17']=='TVA')
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Typerecette_17']][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                        else 
                        {
                                $compte_dst = isset($comptes[$regie][$compte_cdt][$services][$data['Devise_12']]) ? $comptes[$regie][$compte_cdt][$services][$data['Devise_12']] : $compte_dst;
                                $libelle = $data['Beneficaire_15'].'-'.$services.'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.$data['Designation_14'].'-'.$periode;
                        }
                }
                else
                {
                        $libelle = $data['Beneficaire_15'].'-'.$data['Service_16'].'-'.$data['Typerecette_17'].'-'.$data['Noteid_26'].'-'.'-'.$data['Designation_14'].'-'.$periode;
                }
                
                # Dans le cas de la DGI quand la recette se trouve etre la TVA, TVF, TVN et TVO
                # Crediter le compte DGI TVA
                if($data['Beneficaire_15'] == 'DGI' && $comptes_recettes_dgi != NULL)
                {
                        if($data['Devise_34'] != $data['Devise_12']) $compte_debit = $compte_dbt; else $compte_debit = NULL;
							
                        $instruction = $this->get_instructions_dgi_tva($data, $comptes_recettes_dgi, $services, $periode, $compte_debit);
                        $instructions[] = $instruction;
                }
                else
                {
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['Montant_11'], 
                                                'Devise_11'=>$data['Devise_12'],
                                                'Compte_13'=>$compte_dst
                                            );
                        $instructions[] = $instruction;
                }
                
                
                //Compte position a crediter pour la position de change des frais bancaires et la TVA.
                $compte_cpu = 'CPU';
                $compte_dst = isset($comptes[$bank_code][$compte_cpu]['USD']) ? $comptes[$bank_code][$compte_cpu]['USD'] : '00000000000000000000000'; 
                
                $compte_ccv = 'CCV';
                $compte_src = isset($comptes[$bank_code][$compte_ccv]['CDF']) ? $comptes[$bank_code][$compte_ccv]['CDF'] : '00000000000000000000000'; 
                
                //Montant de la commission a crediter, l'equivalence en dollars.
                $montant_commission = $data['Commission_23'] / $data['Taux_41'];
                
                # Operation 2: crediter le compte CPU de la banque pour la position de change des frais bancaires
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_commission, 
                                        'Devise_11'=>'USD',
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 3 : Debiter le compte contre-valeur pour crediter le compte frais bancaires 
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 
                $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_src, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$data['Commission_23'], 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                //Montant de la tva a crediter, l'equivalence en dollars.
                $montant_tva = $data['Commission_23']*0.16;
                
                $montant_tva = $montant_tva / $data['Taux_41'];
                
                # Operation 4: crediter le compte CPU de la banque pour la position de change de la TVA
                
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_tva, 
                                        'Devise_11'=>'USD',
                                        'Compte_13'=>$compte_dst
                                    );
                $instructions[] = $instruction;
                
                # Operation 5: Debiter le compte contre-valeur pour crediter le compte TVA
                
                $compte_tva = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_src, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Commission_23']*0.16), 
                                        'Devise_11'=>'CDF',
                                        'Compte_13'=>$compte_tva
                                    );
                $instructions[] = $instruction;
                
                # Operation 6: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                $libelle = 'Frais BCC '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>($data['Montant_11']*0.005), 
                                        'Devise_11'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_cfb
                                    );
                $instructions[] = $instruction;
                
                return $instructions;
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Cles de repartition
         * *************************************************************************************************************************SCETION 2
        */
        
        //DGI Cotisation - IPR 
        public function get_instructions_gu_dgi($data, $comptes,$regie, $service_types = NULL, $periode = NULL)
        {
                $instructions = array();
                $bank_code = 'Tmb';
                
                
                
                $infos = json_decode($data['Notereference_30'], true);
				
				# Montant de la note
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        $montant_debit_onem = $infos['QuotasONEM'] / $data['Taux_41'];
                        
                        $montant_credit_onem = $infos['QuotasONEM'];
						
                        $montant_debit_cnss = $infos['QuotasINSS'] / $data['Taux_41'];
                        
                        $montant_credit_cnss = $infos['QuotasINSS'];
						
                        $montant_debit_inpp = $infos['QuotasINPP'] / $data['Taux_41'];
                        
                        $montant_credit_inpp = $infos['QuotasINPP'];
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                {
                        $montant_debit_onem = $infos['QuotasONEM'] * $data['Taux_41'];
                        
                        $montant_credit_onem = $infos['QuotasONEM'];
						
                        $montant_debit_cnss = $infos['QuotasINSS'] * $data['Taux_41'];
                        
                        $montant_credit_cnss = $infos['QuotasINSS'];
						
                        $montant_debit_inpp = $infos['QuotasINPP'] * $data['Taux_41'];
                        
                        $montant_credit_inpp = $infos['QuotasINPP'];
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_debit_onem = $montant_credit_onem = $infos['QuotasONEM'];

                        $montant_debit_cnss = $montant_credit_cnss = $infos['QuotasINSS'];

                        $montant_debit_inpp = $montant_credit_inpp = $infos['QuotasINPP'];
                }
                
                $compte_ONEM = isset($comptes['ONEM']['CPI'][$data['Devise_12']]) ? $comptes['ONEM']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_CNSS = isset($comptes['CNSS']['CPI'][$data['Devise_12']]) ? $comptes['CNSS']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                $compte_INPP = isset($comptes['INPP']['CPI'][$data['Devise_12']]) ? $comptes['INPP']['CPI'][$data['Devise_12']] : '00000000000000000000000'; 
                
				
                $libelle = 'ONEM_'.$data['Typerecette_17'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit_onem, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_24'=>$montant_credit_onem, 
                                        'Devise_25'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_ONEM
                                    );
                $instructions[] = $instruction;
                
                
                
                $libelle = 'INPP_'.$data['Typerecette_17'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit_inpp, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_24'=>$montant_credit_inpp, 
                                        'Devise_25'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_INPP
                                    );
                $instructions[] = $instruction;

                $libelle = 'CNSS_'.$data['Typerecette_17'].'_'.$data['Designation_14'].'_'.$data['Nif_13'];
                $instruction = array(
                                        
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit_cnss, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_24'=>$montant_credit_cnss, 
                                        'Devise_25'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_CNSS
                                    );
                $instructions[] = $instruction;

                return $instructions;
        }
        
        //Guichet Unique en douane
        public function get_instructions_gu_dgda($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Tmb';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                
                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]['']))
                        {
                                $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][''];
                        }
                        else
                        {
                                $compte_dst = '00000000000000000000000';
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'PYT'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                $instruction = array(
                    'Operation_8'=>'V', 
                    'Compte_9'=>$compte_cgu,
                    'Libelle_12'=>$libelle, 
                    'Montant_10'=>$data['Montant_11'], 
                    'Devise_11'=>$data['Devise_12'],
                    'Montant_25'=>$data['Montant_11'], 
                    'Devise_26'=>$data['Devise_12'],
                    'Compte_13'=>$compte_dst
                );
                
                return $instruction;
        }
        
        public function get_instructions_gu_dgda_prepayment($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'Tmb';
                $regie = 'DGDA';
                
                # Operation 1: debiter le compte du client
                # pour crediter soit le compte position en USD ou soit le compte contr-valeur en CDF 
                
                if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']]))
                {
                        $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][$data['Service_16']];
                }
                elseif(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]))
                {
                        if(isset($comptes[$data['Typerecette_17']][$data['Devise_12']]['']))
                        {
                                $compte_dst = $comptes[$data['Typerecette_17']][$data['Devise_12']][''];
                        }
                        else
                        {
                                $compte_dst = '00000000000000000000000';
                        }
                }
                else 
                {
                        $compte_dst = $compte_sus;
                }
                
                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $libelle = 'PYT'.$data['Service_16'].' - '.$data['Noteid_26'].' - '.$data['Typerecette_17'].' - '.$data['Designation_14'].' - '.$data['Nif_13'];
                $instruction = array(
                    'Operation_8'=>'V', 
                    'Compte_9'=>$compte_cgu,
                    'Libelle_12'=>$libelle, 
                    'Montant_10'=>$data['Montant_11'], 
                    'Devise_11'=>$data['Devise_12'],
                    'Montant_27'=>$data['Montant_11'], 
                    'Devise_26'=>$data['Devise_12'],
                    'Compte_13'=>$compte_dst
                );
                
                return $instruction;
        }
        
        //Operation de virement du compte CPT Transitoire vers le compte TVA, TVF, TVN, TVO de la dounane
        public function get_instructions_dgi_tva($data, $comptes, $services = NULL, $periode = NULL, $compte_debit = NULL)
        {
                
                $compte_dst = isset($comptes[$data['Typerecette_17']][$data['Devise_12']]['']) ? $comptes[$data['Typerecette_17']][$data['Devise_12']['']] : '00000000000000000000000'; 
                
                $libelle = $data['Beneficaire_15'].'_'.$services.'-'.$data['Typerecette_17'].'_'.$data['Noteid_26'].'_'.$data['Designation_14'].'_'.$periode;
				
                # Montant de la note
                if($data['Devise_12'] == 'CDF' && $data['Devise_12'] != $data['Devise_34'])
                {
                        $montant_debit = $data['Montant_11'] / $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == 'USD' && $data['Devise_12'] != $data['Devise_34']) 
                {
                        $montant_debit = $data['Montant_11'] * $data['Taux_41'];
                        
                        $montant_credit = $data['Montant_11'];
                }
                elseif($data['Devise_12'] == $data['Devise_34']) 
                {
                        $montant_debit = $montant_credit = $data['Montant_11'];
                }
                
                if($compte_debit != NULL)
                {
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_debit, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_25'=>$montant_credit, 
                                        'Devise_26'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                                $instructions[] = $instruction;
                        }
                        else
                        {
                                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$compte_debit, 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_24'=>$montant_credit, 
                                        'Devise_25'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                                $instructions[] = $instruction;
                        }
                }
                else
                {
                        if($data['Beneficaire_15'] == 'DGDA')
                        {
                                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_25'=>$montant_credit, 
                                        'Devise_26'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                                $instructions[] = $instruction;
                        }
                        else
                        {
                                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=>$montant_debit, 
                                        'Devise_11'=>$data['Devise_34'],
                                        'Montant_24'=>$montant_credit, 
                                        'Devise_25'=>$data['Devise_12'],
                                        'Compte_13'=>$compte_dst
                                );
                                $instructions[] = $instruction;
                        }
                }       
                
                return $instruction;
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		($id >0) || $this->db->where('Id_0', $id);
		return $this->save($data, $id);
	}
        
        public function update_instructions($data, $id) 
        {
                $this->db->where("logiref_cbs_instructions.Reference_14 ='".$ids."')");
                return $this->db->update('logiref_cbs_instructions', $data);
        }
        
        public function save_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
								
                                # reference de la transaction
                                $reference = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
								
                                $data['Reference_14']= $reference;
                                $data['Priority_24']=$priority;
                                
                                $this->set_table('logiref_cbs_instructions_dgda', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgi($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                
                                # reference de la transaction
                                $reference = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                
                                $data['Reference_14']=$reference;
                                
                                $this->set_table('logiref_cbs_instructions_dgi', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }
        
        public function save_instructions_dgrad($pid, $paiement, $instructions, $logirefid)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                
                                # reference de la transaction
                                $reference = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                                
                                $data['Reference_14']=$reference;
                                
                                $this->set_table('logiref_cbs_instructions_dgrad', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }

        public function save_prepayments_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;
                                //Variable d'integration
                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                                $data['Agence_6']= $paiement['Agence_20'];
                                $data['Guichet_7']= $paiement['Guichet_21'];
                                $data['Mode_15']= $paiement['Mode_19'];
                                $data['Makerid_16']= $this->session->userdata['user_id'];
                                $data['Priority_24']= $priority;

                                # reference de la transaction
                                $reference = mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                                $data['Reference_14']= $reference; 

                                $this->set_table('logiref_cbs_prepayments_instructions', 'Id_0', 'Id_0 DESC');
                                $this->save($data, NULL);
                        }
                }
                return TRUE;
        }

        public function delete_instructions_dgi($id)
	{
		return $this->db->table('logiref_cbs_instructions_dgi')->where('Reference_14', $id)->delete();
	}

        public function delete_instructions_dgrad($id)
	{
		return $this->db->table('logiref_cbs_instructions_dgrad')->where('Reference_14', $id)->delete();
	}

        public function update_instructions_cbs_dgi($ids, $data)
        {
                return $this->db->table('logiref_cbs_instructions_dgi')->update($data,$ids);
        }

        public function update_instructions_cbs_dgrad($ids, $data)
        {
                return $this->db->table('logiref_cbs_instructions_dgrad')->update($data,$ids);
        }

        public function update_instructions_cbs_dgda($ids, $data)
        {
                return $this->db->table('logiref_cbs_instructions_dgda')->update($data,$ids);
        }

        public function update_prepayments_instructions_cbs($ids, $data)
        {
                return $this->db->table('logiref_cbs_prepayments_instructions')->update($data,$ids);
        }
        public function update_instructions_cbs_provisions($ids, $data)
        {
                return $this->db->table("logiref_cbs_instructions_provision")->update($data,$ids);
        }

        public function update_instructions_cbs_occ($ids, $data)
        {
                return $this->db->table('logiref_cbs_instructions_invoice_occ')->update($data,$ids);
        }
}