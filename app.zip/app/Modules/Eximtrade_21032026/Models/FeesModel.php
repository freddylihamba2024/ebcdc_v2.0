<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Main;

class FeesModel extends MY_Main {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	public $priorites = array(
                            '1' => 'Priorit&eacute;1',
                            '2' => 'Priorit&eacute;2',
                            '3' => 'Priorit&eacute;3',
                            '4' => 'Priorit&eacute;4',
                            '5' => 'Priorit&eacute;5',
                            '6' => 'Priorit&eacute;6',
                            '7' => 'Priorit&eacute;7',
                            '8' => 'Priorit&eacute;8',
                            '9' => 'Priorit&eacute;9',
                            '10' => 'Priorit&eacute;10'
            
                        );
        
        public $type_compte = array(
                                        ''=>'',
                                        '1' => 'Transitaire', 
                                        '2' => 'Client'
                                    );
        
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_regle_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Priorite_4 = '';
                        $obj->Beneficiaire_5 = '';
                        $obj->Service_6 = '';
                        $obj->Recette_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Value_9 = '';
                        $obj->Unite_10 = '';
                        $obj->Min_11 = '0';
                        $obj->Max_12 = '0';
                        $obj->Devise_13 = 'CDF';
                        $obj->Makerid_14 = '';
                        $obj->Checkerid_15 = '';
                        $obj->Validation_16 = '';
                        $obj->Compte_17 = '';
                        $obj->Devise_18 = '';
                        $obj->Type_19 = '';
                        
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_regles p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_exempt_customer_info($oid=NULL)
        {
                if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Designation_7='';
                        $obj->Montant_8='';
                        $obj->Agence_9='';
                        $obj->Infos_10='';
                        $obj->Codeimport_11='';
                        $obj->Validation_12 ='';

                        #Add more here
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_client_exonore', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_preferential_pricing_account($account, $currency)
        {
                $this->set_table('logiref_regles r', 'r.Id_0', 'r.Id_0 DESC');
                return $this->get_by(array('Compte_17' => $account, 'Devise_18'=>$currency, 'Type_19'=>'1'), TRUE);
        }
        public function get_pricing_account($account, $currency)
        {
                $this->set_table('logiref_regles r', 'r.Id_0', 'r.Id_0 DESC');
                return $this->get_by(array('Compte_17' => $account, 'Devise_18'=>$currency), TRUE);
        }
        
        public function get_regles($type=NULL)
        {
                if($type== "rgle")
                {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'"; 
                        $builder = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $st = "Status_2='1' AND ( Beneficiaire_5='0' OR Beneficiaire_5='" .$this->session->get('Logiref_regies'). "') AND Checkerid_15 !='0'"; 
                        $builder = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Date_1','DESC')
                                ->get();
                        return $builder->getResult();
                        
                }
        }
        
        public function get_bank_charges($regie, $service, $recette, $devise, $montant, $guichet, $compte = NULL, $compteDevise = NULL) 
        {
                $valeur = 0;
                $unite = 0;
                $ddmenu = array();
                $data = array();
                $account = $this->session->userdata['account_id'];
                
                if($compte !="" && $compteDevise !="")
                {
                        
                        $data = $this->get_bank_charges_by_compte($regie, $service, $recette, $devise, $montant, $guichet, $compte, $compteDevise);
                        
                        if(isset($data["Valeur"]) && $data["Valeur"] !="0") return $data;
                }
                
                $where = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "' ";
                $builder = $this->db->table('logiref_regles')
                        ->where($where)
                        ->orderBy('Priorite_4','DESC')
                        ->get();
                $data = $builder->getResultArray();
                
           
                $ddmenu = $this->get_charges_filter($data, $regie, $service, $recette, $devise, $montant, $guichet, $compte, $compteDevise);
               
                return $ddmenu;
                
        }
        
        public function get_bank_charges_by_compte($regie, $service, $recette, $devise, $montant, $guichet, $compte, $compteDevise) 
        {
                $valeur = 0;
                $unite = 0;
                $ddmenu = array();
                $data = array();
                $account = $this->session->userdata['account_id'];
                
                $where = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Compte_17 = '".$compte."' AND Devise_18 = '".$compteDevise."'";
                $builder = $this->db->table('logiref_regles')
                        ->where($where)
                        ->orderBy('Priorite_4','DESC')
                        ->get();
                
                $data = $builder->getResultArray();
                
                $ddmenu = $this->get_charges_filter($data, $regie, $service, $recette, $devise, $montant, $guichet, $compte, $compteDevise, $filter = 'all');
                
                return $ddmenu;
        }
        
        public function get_charges_filter($data, $regie, $service, $recette, $devise, $montant, $guichet, $compte = NULL, $compteDevise = NULL, $filter = NULL) 
        {
                $valeur = 0;
                $unite = 0;
                $ddmenu = array();

	
                
                foreach ($data as $row)
                {
                        # Retreive the account fees of client without taking the branch into account.
                        if($filter == 'all')
                        {
                                $guichet = $row['Guichet_8'];
                        }
                        #Priorit� 1
                        if($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']))
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;
                        }
                        #Priorit� 2
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] == 0 && $montant == 0))
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                                
                        }
                        #Priorit� 3
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                             
                                break;
                        } 
                        #Priorit� 4
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                 
                                break;
                        }
                        #Priorit� 5
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet)
                        {       
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                break;    
                        }
                        #Priorit� 6
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;  
                        }
                        #Priorit� 7
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && $row['Service_6'] == '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                        }
                        #Priorit� 8
                        elseif($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;
                        }
                        #Priorit� 9
                        elseif($row['Beneficiaire_5'] == $regie && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet && $row['Devise_13'] == $devise)
                        { 
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break;    
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] === '' && $row['Service_6'] === '' && $row['Service_6'] === '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
	
                              
                                break; 
                        }
                        #Priorit� 10
                        elseif(($row['Beneficiaire_5'] === 0 || $row['Beneficiaire_5'] ==='') &&  $row['Recette_7'] === '' && $row['Service_6'] === '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];

                                break; 
                        }
                        #Priorit� 10
                        elseif($row['Beneficiaire_5'] == $regie && $row['Recette_7'] === '' && $row['Service_6'] === '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break; 
                        }
                        #Priorit� 10
                        elseif(($row['Beneficiaire_5'] === 0 || $row['Beneficiaire_5'] ==='') && $row['Recette_7'] === '' && $row['Service_6'] === '' && $row['Min_11']==0 && $row['Max_12']==0 && $row['Guichet_8'] == $guichet)
                        {    
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                
                                break; 
                        }
                        
                }
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite);
                
                return $ddmenu;
        }
        public function customer_exempt_provision_by_clt($clt)
        {
            $account_id = $this->session->userdata['account_id'];
            
            $this->set_table('logiref_client_exonore I', 'I.Id_0', 'I.Id_0 DESC');
            return $this->get_by(array('Codeimport_11'=> $clt,'Account_3' =>$account_id), TRUE);
            
        }

        public function get_exempt_customers()
        {
                $account = $this->session->get('account_id');
                $st = " Account_3='" . $account . "' AND Status_2='1' ";
                $builder = $this->db->table('logiref_client_exonore')
                        ->select('logiref_client_exonore.*')
                        ->where($st)
                        ->orderBy('logiref_client_exonore.Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_exempt")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 ='1' AND Changer_6 >'0'";
                        $builder = $this->db->table('logiref_client_exonore')
                                ->where($where) 
                                ->orderBy('Id_0','ASC')
                                ->get();
                                
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Codeimport_11']] = $row['Codeimport_11'];
                        }
                        return $ddmenu;
                }
                elseif($item=="customer_account_exempt_provision")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 ='1' AND Changer_6 >'0'";
                        $builder= $this->db->table('logiref_client_exonore')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Codeimport_11']] = $row['Account_13'];
                        }
                        return $ddmenu;
                }
                elseif($item=="customer_account_currency_exempt_provision")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 ='1' AND Changer_6 >'0'";
                        $builder = $this->db->table('logiref_client_exonore')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Codeimport_11']] = $row['Currency_14'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id = $this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResult();
	}
        
        public function get_agence_regles()
        {
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_8='".$guichet."'";
                $builder = $this->db->table('logiref_regles')
                        ->select('logiref_regles.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_agence_regles_filtered($data)
        {
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_8='".$guichet."'"; 
                
                if( isset($data['regie'] )  &&  $data['regie'] !="" ) $st .=  " AND Beneficiaire_5 ='".$data['regie']."'";
                $builder = $this->db->table('logiref_regles')
                        ->select('logiref_regles.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_regle($data, $id)
        {
                $this->set_table('logiref_regles', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
}
