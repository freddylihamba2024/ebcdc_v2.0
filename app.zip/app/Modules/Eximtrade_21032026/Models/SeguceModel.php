<?php

namespace Modules\Eximtrade\Models;

use stdClass;
use App\Models\MY_Transaction;

class SeguceModel extends MY_Transaction {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';

        
        public $documents = array(
                    ''  => '',
                    '1' => 'POST DEDOUANEMENT', 
                    '2' => 'PRE DEDOUANEMENT',
                    '3' => 'DEDOUANEMENT', 
                    '4' => 'LOGISTIQUE', 
                );
        
        public $recettes = array(
                    ''  => '',
                    'CTC' => 'Frais TVA', 
                    'CPB' => 'Frais BIVAC',
                    'CPO' => 'Frais OCC', 
                );
        
        public $status_provisions =  array(
            '0' => 'Annul&eacute;e',
            '1' => 'Epuiss&eacute;',
            '2' => 'Utilis&eacute;',
            '3'=>'Utilis&eacute; partiellement'
        );
        
        public $status_validate =  array(
            '0' => 'Annul&eacute;e',
            '1' => 'A valider',
            '2' => 'Valid&eacute;',
            '3' => 'Epuiss&eacute;',
            '4' => 'Utilis&eacute; partiellement',
            '5' => 'A regulariser',
        );
        
        public $color_provisions = array(
            '0' => 'label-cancelled',
            '1' => 'label-ongoing',
            '2' => 'label-completed',
            '3' => 'label-cancelled',
            '4' => 'label-upcoming',
            '5' => 'label-cancelled',
        );

        public $status_invoices =  array(
            '3' => 'Non acquitt&eacute;',
            '4' => 'Acquitt&eacute;',
        );
        
        public $color_invoices  = array(
            '3' => 'label-cancelled',
            '4' => 'label-completed',
        );

        public $modes = array(
            '' => '',
            '1' => 'Carte bancaire',
            '2' => 'Credoc',
            '3' => 'Transfert/Virement',
            '4' => 'Encaisssement documentaire',
            '5' => 'Esp&egrave;ce',
            '6' => 'Ch&egrave;que bancaire',
            '7' => 'Autres'
        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_licence_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4 ='';
                        $obj->Licence_7='';
                        $obj->MontantCIF_8='';
                        $obj->Devise_9='';
                        $obj->Date_10='';
                        $obj->Compte_11='';
                        $obj->Devise_12='';
                        $obj->Taux_13='';
                        $obj->LicenceFees_14='';
                        $obj->Devise_15='';
                        $obj->ValidationFees_16='';
                        $obj->Devise_17='';
                        $obj->Codeimport_18='';
                        $obj->Reference_19='';
                        $obj->Compte_20='';
                        $obj->Devise_21='';
                        $obj->Designation_22='';
                        $obj->Nif_23='';
                        $obj->Agence_24='';
                        $obj->Guichet_25='';
                        $obj->CodeType_26='';
                        $obj->Numero_importexport_27='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_integration_licence', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}

        public function get_provision_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4 ='';
                        $obj->Licence_7='';
                        $obj->MontantCIF_8='';
                        $obj->Devise_9='';
                        $obj->Montantprov_10='';
                        $obj->Date_11='';
                        $obj->Compte_12='';
                        $obj->Devise_13='';
                        $obj->Taux_14='';
                        $obj->LicenceFees_15 ='';
                        $obj->Devise_16 ='';
                        $obj->ValidationFees_17 ='';
                        $obj->Devise_18 ='';
                        $obj->Codeimport_19 ='';
                        $obj->Reference_20  ='';
                        $obj->Compte_21 ='';
                        $obj->Devise_22 ='';
                        $obj->Designation_23 ='';
                        $obj->Nif_24 ='';
                        $obj->CodeAur_25 ='';
                        $obj->Typefacture_26  ='';
                        $obj->Agence_27  ='';
                        $obj->Guichet_28  ='';
                        $obj->AmountPartial_26  ='';
                        $obj->RoyaltyFees_30  ='';
                        $obj->Devise_31  ='';
                        $obj->SeguceFees_32  ='';
                        $obj->Devise_33  ='';
                        $obj->Reference_34 ='';
                        $obj->Commission_35 ='';
                        $obj->Devise_36 ='';
                        $obj->RateSeguce_37 ='';
                        $obj->CodeType_38 ='';
                        $obj->Numero_importexport_39 ='';
                        $obj->Merchandise_40  ='';
                        $obj->AmountPrefinance_41   ='';
                        $obj->Devise_42 ='';
                        $obj->Prefinance_43 ='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table(' logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_invoices_occ_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Bank_7='';
                        $obj->Licence_8='';
                        $obj->MontantCIF_9='';
                        $obj->Devise_10='';
                        $obj->Result_11='';
                        $obj->Codeimport_12 ='';
                        $obj->Designation_13 ='';
                        $obj->Numbordereau_14 ='';
                        $obj->Datebordereau_15 ='';
                        $obj->Compte_16 ='';
                        $obj->Devise_17 ='';
                        $obj->Regulid_18 ='';
                        $obj->Compte_19 ='';
                        $obj->Devise_20 ='';
                        $obj->Amountgap_21 ='';
                        $obj->Siglebank_22 ='';
                        $obj->BatchId_23 ='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table(' logiref_integration_invoice_occ', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}

        public function get_invoices_occ_issues_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Designation_7='';
                        $obj->CodeImport_8='';
                        $obj->Numbordereau_9='';
                        $obj->Result_10='';
                        $obj->Datebordereau_11='';
                        $obj->BatchId_12='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_integration_invoice_occ_issues ', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_invoices_occ_batchs_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4= $this->session->userdata['user_id'];
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Codebank_7='';
                        $obj->Siglebank_8='';
                        $obj->Numbordereau_9='';
                        $obj->Date_10='';
                        $obj->Licenses_11='';
                        $obj->Files_12='';
                        $obj->Date_13='';
                        $obj->Agence_14 ='';
                        $obj->Guichet_15 ='';
                        $obj->Reference_16 ='';

                        return $obj;
		}
                else
                {
                        $this->set_table('  logiref_integration_invoice_occ_batchs ', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_invoice_fees_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Frais_seguce_7='';
                        $obj->Devise_8='';
                        $obj->Frais_achat_9='';
                        $obj->Devise_10='';
                        $obj->Frais_validation_11='';
                        $obj->Devise_12 ='';
                        $obj->Frais_intervention_13 ='';
                        $obj->Devise_14 ='';
                        $obj->Tva_15 ='';
                        $obj->Devise_16='';

                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_invoice_fees', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item == "invoices_occ")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        
                        $builder = $this->db->table('logiref_integration_invoice_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = "";
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Licence_8'];
                        }
                        return $ddmenu;
                }
                elseif($item=="code_imports")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 ='1'";
                        $builder = $this->db->table('logiref_integration_invoice_occ')
                                 ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = "";
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Codeimport_12']] = $row['Codeimport_12'];
                        }
                        return $ddmenu;
                }
                elseif($item=="bordereau_number")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = "";
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Numbordereau_9']] = $row['Numbordereau_9'];
                        }
                        return $ddmenu;
                }
                elseif($item=="batch_reference")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="Status_2 !='0'";
                        $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = "";
                        foreach ($builder->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Reference_16'];
                        }
                        return $ddmenu;
                }
                elseif($item=="licence_number")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 >'0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Licence_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="licence_provision")
                {
                        $where = "(Account_3='".$account_id."')";
                        $where = " (Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();

                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Montantprov_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="licence_provision_extourne")
                {
                        $where = "(Account_3='".$account_id."')";
                        $where = " Status_2 ='3'";
                        $query = $this->db->get('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Montantprov_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_current_account")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Compte_21'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_current_account_currency")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();

                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Devise_22'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_account")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();

                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Compte_12'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_account_currency")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Licence_7']] = $row['Devise_13'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_account_by_clt")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Codeimport_19']] = $row['Compte_12'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_customer_account")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Codeimport_19']] = $row['Compte_21'];
                        }
                        return $ddmenu;
                }
                elseif($item=="provision_customer_account_currency")
                {
                        $where ="(Account_3='".$account_id."')";
                        $where ="(Status_2 ='2' OR Status_2 ='4') AND Montantprov_10 > '0'";
                        $builder = $this->db->table('logiref_integration_provision_occ')
                                ->where($where)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu = array();
                        
                        foreach ($builder->getResultArray() as $row) {
                                $ddmenu[$row['Codeimport_19']] = $row['Devise_22'];
                        }
                        return $ddmenu;
                }

        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
		$builder = $this->db->table('TABLE_NAME')
                        ->select('TABLE_NAME.*')
                        ->where("TABLE_NAME.Account_3 ='".$account_id."'")
                        ->orderBy('TABLE_NAME.COL_NAME','ASC')
                        ->get();
                return $builder->getResultArray();
	}
        
        public function get_invoice_fees($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
		$account_id=$this->session->userdata['account_id'];
                $builder = $this->db->table['logiref_invoice_fees']
                        ->select('logiref_invoice_fees.*')
                        ->where("logiref_invoice_fees.Account_3 ='".$account_id."'")
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResultArray();
	}
   
        public function  get_invoices_by_date()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = " Status_2 ='1' AND Account_3='".$account."' AND  Date_1 LIKE '%".gmdate('Y-m-d')."%'";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                return $builder->getResultArray();
        }
        
        public function  get_provision_by_licence_id($licence_id)
        {
                $this->set_table('logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Licence_7' => $licence_id), TRUE);
        }
        
        public function  get_licence_by_id($licence_id)
        {
                $this->set_table('logiref_integration_licence', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Licence_7' => $licence_id), TRUE);
        }

        public function  get_licence_by_ref($licence_ref)
        {
                $this->set_table('logiref_integration_licence', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Reference_19' => $licence_ref), TRUE);
        }

        public function  get_provision_by_ref($provision_ref)
        {
                $this->set_table('logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Reference_20' => $provision_ref), TRUE);
        }

        public function  get_provision_by_licence($licence_id)
        {
                $this->set_table('logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Licence_7' => $licence_id, 'Status_2' => '2'), TRUE);
        }
        
        public function  get_provision_by_declaration_id($declaration_id)
        {
                $this->set_table('logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('NumDeclaration_22' => $declaration_id), TRUE);
        }
        
        public function get_first_instructions($data, $comptes, $ref_provision = NULL, $type=NULL)
        {
                $instructions = array();
                $bank_code = ucfirst(strtolower($data['bank']));

                if($type == NULL)
                {
                      $type = array(); 
                }
                
                # Operation 1: crediter le compte de Passage tresor correspondant a la devise
                # Ou dans le cas de la DGDA, crediter le compte guichet unique 
                # Les operations de cambisme se feront en dehors de Logiref
                
                $compte_dst = isset($comptes[$bank_code]['CSG']['CDF']) ? $comptes[$bank_code]['CSG']['CDF'] : '00000000000000000000000'; 
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                if(isset($data['guice_rate']) && $data['guice_rate'] !="")
                {
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['total_invoice']/$data['guice_rate'];
                        }
                        else
                        {
                                $montant_debit = $data['total_invoice'];
                        }
                }
                else
                {
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['total_invoice']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_debit = $data['total_invoice'];
                        }
                }
                
                if(in_array("GUICE", $type) || in_array("GUICELOG", $type))
                {
                        $libelle = $data['Typerecette_17'].' '.$data['Designation_14'];

                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=> $data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=> $data['total_invoice'], 
                                                'Devise_11'=>'CDF',
                                                'Compte_13'=>$compte_dst,
                                                'Montant_26'=> $montant_debit,
                                                'Devise_27'=> $data['Devise_34'],
                                            );
                        $instructions[] = $instruction;
                      
                        # Operation 2: crediter le compte commission de la banque
                        # Toujours s'assurer d'avoir un compte commission pour chaque devise
                        
                        $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 

                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_cfb = $data['total_frais']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_cfb = $data['total_frais'];
                        }
                        
                        $libelle = 'Frais bancaire '.$data['Typerecette_17'].' '.$data['Designation_14'];
                        $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['total_frais'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb,
                                        'Montant_26'=> $montant_cfb,
                                        'Devise_27'=> $data['Devise_34'],
                                    );
                        $instructions[] = $instruction;
                        
                        # Operation 3: crediter le compte TVA de la banque
                        # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                        
                        $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 

                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_tva = $data['total_tva']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_tva = $data['total_tva'];
                        }
                        
                        $libelle = 'TVA '.$data['Typerecette_17'].' '.$data['Designation_14'];
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=> $data['total_tva'],  
                                                'Devise_11'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_tva,
                                                'Montant_26'=> $montant_tva,
                                                'Devise_27'=> $data['Devise_34'],
                                            );
                        $instructions[] = $instruction;
                }
                
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                
                if($data['total_acb'] != 0)
                {
                        # Operation 3 : credit du compte ACB correspondant a la devise
                        $compte_acb = isset($comptes[$bank_code]['ACB'][$data['Devise_12']]) ? $comptes[$bank_code]['ACB'][$data['Devise_12']] : '00000000000000000000000'; 

                        
                        $libelle = 'Frais ACB SEGUCE LOGIST TERR '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=>$data['total_acb'], 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Compte_13'=> $compte_acb,
                                                'Devise_27'=> $data['Devise_34']
                                            );
                        $instructions[] = $instruction;
                }
                
                
                $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                
                if(in_array("INVDIB", $type))
                {
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['total_frais']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_debit = $data['total_frais'];
                        }
                        
                        $libelle = 'Frais bancaire '.$data['Licence_7'].' '.$data['Designation_14'];
                        
                        $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=>$data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['total_frais'], 
                                        'Devise_11'=>$data['Devise_24'],
                                        'Compte_13'=>$compte_cfb,
                                        'Montant_26'=> $montant_debit,
                                        'Devise_27'=> $data['Devise_34']
                                    );
                        $instructions[] = $instruction;
                }
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                
                $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 

                if($data['Devise_34'] == 'USD')
                {
                        $montant_debit = $data['total_tva']/$taux['Dollar_4'];
                }
                else
                {
                        $montant_debit = $data['total_tva'];
                }

                if(in_array("INVDIB", $type))
                {
                        $libelle = 'TVA '.$data['Licence_7'].' '.$data['Designation_14'];

                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=> $data['total_tva'],  
                                                'Devise_11'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_tva,
                                                'Montant_26'=> $montant_debit,
                                                'Devise_27'=> $data['Devise_34']
                                            );
                        $instructions[] = $instruction;
                }

                return $instructions;
        }

        public function get_instruction_provision($data, $comptes, $ref_provision)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                ######################## Operation 1: debiter le compte du client et crÃƒÂ©diter le compte provision OCC ######################################
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                $compte_dst = isset($data['Compte_12']) ? $data['Compte_12'] : '000000000000000000000000'; 

                $montant_debit = $data['Montantprov_10'];

                if($data['Devise_22'] == 'CDF')
                {
                        $montant_debit = $data['Montantprov_10'] * $taux['Dollar_4'];
                }
                else
                {
                        $montant_debit = $data['Montantprov_10'];
                }


                $libelle = 'Provision OCC BIVAC '.$data['Licence'];

                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$data['Montantprov_10'], 
                                            'Devise_11'=>'USD',
                                            'Compte_13'=>$compte_dst,
                                            'Reference_14'=>$ref_provision,
                                            'Montant_24'=> $montant_debit,
                                            'Devise_25'=> $data['Devise_22'],
                                    );

                $instructions[] = $instruction;
                
                
                return $instructions;
        }
        
        
        public function get_first_instructions_single($data, $comptes, $type = NULL)
        {   
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: Debiter le compte du client pour crediter le compte suspens seguce
                
                $compte_dst = isset($comptes[$bank_code]['CSG'][$data['Devise_12']]) ? $comptes[$bank_code]['CSG'][$data['Devise_12']] : '00000000000000000000000'; 
                
                $taux = json_decode($_SESSION['Bank_rates'], true);
                
                
                if(isset($data['guice_rate']) && $data['guice_rate'] !="")
                {
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['Montant_11']/$data['guice_rate'];
                        }
                        else
                        {
                                $montant_debit = $data['Montant_11'];
                        }
                }
                else
                {
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['Montant_11']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_debit = $data['Montant_11'];
                        }
                }
                
                $libelle = $data['Typerecette_17'].' '.$data['Designation_14'];
                
                $instruction = array(
                                        'Operation_8'=>'V', 
                                        'Compte_9'=> $data['Compte_33'], 
                                        'Libelle_12'=>$libelle, 
                                        'Montant_10'=> $data['Montant_11'], 
                                        'Devise_11'=>"CDF",
                                        'Compte_13'=>$compte_dst,
                                        'Montant_26'=>$montant_debit,
                                        'Devise_27'=>$data['Devise_34'],
                                    );
                $instructions[] = $instruction;
                
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                
                if($type !="GUICE")
                {
                        if($data['frais_acb'] != 0)
                        {
                                # Operation 3 : credit du compte ACB correspondant a la devise
                                $compte_acb = isset($comptes[$bank_code]['ACB'][$data['Devise_12']]) ? $comptes[$bank_code]['ACB'][$data['Devise_12']] : '05101-10002226991-96'; 
                                
                                if($data['Devise_34'] == 'USD')
                                {
                                        $montant_debit = $data['frais_acb']/$taux['Dollar_4'];
                                }
                                else
                                {
                                        $montant_debit = $data['frais_acb'];
                                }


                                $libelle = 'Frais ACB SEGUCE LOGIST TERR '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                                $instruction = array(
                                                        'Operation_8'=>'V', 
                                                        'Compte_9'=>$data['Compte_33'], 
                                                        'Libelle_12'=>$libelle, 
                                                        'Montant_10'=>$data['frais_acb'], 
                                                        'Devise_11'=>$data['Devise_24'],
                                                        'Compte_13'=> $compte_acb,
                                                        'Montant_26'=>$montant_debit,
                                                        'Devise_27'=>$data['Devise_34']
                                                    );
                                $instructions[] = $instruction;
                        }

                        $compte_cfb = isset($comptes[$bank_code]['CFB'][$data['Devise_12']]) ? $comptes[$bank_code]['CFB'][$data['Devise_12']] : '000000000000000000000000'; 
                        
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['Commission_23']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_debit = $data['Commission_23'];
                        }
                        
                        $libelle = 'Frais bancaire '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=> $data['Commission_23'], 
                                                'Devise_11'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_cfb,
                                                'Montant_26'=>$montant_debit,
                                                'Devise_27'=>$data['Devise_34']
                                            );
                        $instructions[] = $instruction;


                        # Operation 3: crediter le compte TVA de la banque
                        # Toujours s'assurer d'avoir un compte TVA pour chaque devise

                        $compte_tva = isset($comptes[$bank_code]['TVA'][$data['Devise_24']]) ? $comptes[$bank_code]['TVA'][$data['Devise_24']] : '000000000000000000000000'; 
                        
                        if($data['Devise_34'] == 'USD')
                        {
                                $montant_debit = $data['frais_tva']/$taux['Dollar_4'];
                        }
                        else
                        {
                                $montant_debit = $data['frais_tva'];
                        }
                        
                        $libelle = 'TVA '.$data['Noteid_26'].' '.$data['Designation_14'].' '.$data['Nif_13'];
                        $instruction = array(
                                                'Operation_8'=>'V', 
                                                'Compte_9'=>$data['Compte_33'], 
                                                'Libelle_12'=>$libelle, 
                                                'Montant_10'=> $data['frais_tva'],  
                                                'Devise_11'=>$data['Devise_24'],
                                                'Compte_13'=>$compte_tva,
                                                'Montant_26'=>$montant_debit,
                                                'Devise_27'=>$data['Devise_34']
                                            );
                        $instructions[] = $instruction;
                
                }
                return $instructions;
        }
        
        public function get_instructions_seguce_debit_by_client($data, $comptes, $compte_provision = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $compte_dst = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                if($compte_provision == "" || $compte_provision == NULL) $compte_provision = "00000000000000000000000";
                
                $montant_credit = $montant_debit = $data['missing_amount'];
                
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['customer_account'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_provision,
                                    );

                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number_without_provision($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';

                # Operation 1: debiter le compte client
                # pour crediter le compte suspens provision

                $montant_credit = $montant_debit = $data['montant'];

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_client,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>"USD",
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );

                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number_without_provision1($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'Rawbank';

                # Operation 1: debiter le compte client
                # pour crediter le compte suspens provision

                $montant_credit = $montant_debit = $data['montant'];

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_client, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>"USD",
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );

                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';

                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 

                $taux = json_decode($this->session->get('Bank_rates'), true);

                if($compte_client == "") $compte_client = "00000000000000000000000";

                if ($data['customer_account_currency'] == "CDF")
                {
                        $montant_debit = round($data['montant'] * $taux['Dollar_4'], 2);
                        $montant_credit = $data['montant'];

                        $montant_prov = round($data['amount_provision'] * $taux['Dollar_4'], 2);

                }
                else
                {
                        $montant_credit = $montant_debit = $data['montant'];
                        $montant_prov = $data['amount_provision'] * $taux['Dollar_4'];
                }

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle = "Extourne - ".$data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_provision,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_prov,
                                            'Devise_11'=>$data['customer_account_currency'],
                                            'Montant_24'=>$montant_debit,
                                            'Devise_25'=>$data['account_provision_currency'],
                                            'Compte_13'=>$compte_client,
                                    );

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';

                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_client,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$data['montant'],
                                            'Devise_11'=>"USD",
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['customer_account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );

                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number1($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'Rawbank';

                # Operation 1: debiter le compte client
                # pour crediter le compte suspens provision

                $montant_credit = $montant_debit = $data['montant'];

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_client,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>"USD",
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );

                return $instruction;
        }


        public function get_instructions_seguce_debit_by_part_occ($data, $comptes, $compte_provision = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';

                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants

                $taux = json_decode($this->session->get('Bank_rates'), true);

                if ($data['account_currency'] == "CDF")
                {
                        $montant_debit = $data['amount_paid_occ'] * $taux['Dollar_4'];
                        $montant_credit = $data['amount_paid_occ'];
                }
                else
                {
                        $montant_credit = $montant_debit = $data['amount_paid_occ'];
                }
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                                
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['account_currency'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['customer_account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );
                
                return $instruction;
        }
        
        public function get_instructions_seguce_debit_by_licence_number_without_customers($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                if($compte_client == "") $compte_client = "00000000000000000000000";
                
                if(!isset($data['amount_provision']))
                {
                        $data['amount_provision'] = $data['montant'];
                }
                elseif(isset($data['amount_provision']) && $data['amount_provision'] == "")
                {
                        $data['amount_provision'] = $data['montant'];
                }
  
                $montant_credit = $montant_debit = $data['montant'];

                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>'USD',
                                            'Montant_24'=>$data['amount_provision'], 
                                            'Devise_25'=>$data['account_provision_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );
                
                
                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number_fb($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'TMB';

                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['COB']['CDF']) ? $comptes[$bank_code]['COB']['CDF'] : '000000000000000000000000'; 
                
                $montant_debit_com = round($data['amount_comm'] * $taux['Dollar_4'], 2);
                $montant_credit_com =  $data['amount_comm'];
                
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $libelle = "Frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision , 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit_com, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit_com, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_cfb,
                                    );
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                
                $compte_tva = isset($comptes[$bank_code]['TOB']['CDF']) ? $comptes[$bank_code]['TOB']['CDF'] : '000000000000000000000000'; 
                
                $libelle = "TVA sur le frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;
                
         
                //$montant_tva = $data['amount_comm'] * 0.16;
                $montant_tva = $data['amount_tva'];

                $montant_debit = $montant_tva * $taux['Dollar_4'];
                $montant_credit =  $montant_tva;
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit , 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_tva,
                                    );
                
                return $instruction;
        }
        
        
        public function get_instructions_seguce_debit_by_licence_number_fb1($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'Rawbank';

                $taux = json_decode($_SESSION['Bank_rates'], true);

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';

                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['COB']['CDF']) ? $comptes[$bank_code]['COB']['CDF'] : '000000000000000000000000'; 

                $montant_debit_com = round($data['amount_comm'] * $taux['Dollar_4'], 2);
                $montant_credit_com =  $data['amount_comm'];


                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle = "Frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision , 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit_com, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit_com, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_cfb,
                                            'Type_26'=> "COM",
                                    );

                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise

                $compte_tva = isset($comptes[$bank_code]['TOB']['CDF']) ? $comptes[$bank_code]['TOB']['CDF'] : '000000000000000000000000'; 

                $libelle = "TVA sur le frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;


                //$montant_tva = $data['amount_comm'] * 0.16;
                $montant_tva = $data['amount_tva'];

                $montant_debit = $montant_tva * $taux['Dollar_4'];
                $montant_credit =  $montant_tva;

                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit , 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_tva,
                                            'Type_26'=> "TVA",
                                    );

                return $instruction;
        }

        public function get_instructions_seguce_debit_by_provision($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                
                $montant_credit = $montant_debit = $data['montant'];
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                $libelle = $data['licence'].' - '.$data['designation'].' - '.$data['code_import'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['customer_account_currency'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_suspens_provision,
                                    );
                
                return $instruction;
        }
                    
        
        public function get_instructions_seguce_debit_by_licence_number_regul($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';

                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $montant_credit = $montant_debit = $data['montant'];
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle =$data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_client, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );
                
                return $instruction;
        }

        public function get_instructions_seguce_debit_by_licence_number_regul1($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'Rawbank';

                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants

                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $montant_credit = $montant_debit = $data['montant'];

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle =$data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_client,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                    );

                return $instruction;
        }

        public function get_instructions_partial_seguce_debit_by_licence_number_regul($data, $comptes, $compte_provision = NULL, $compte_client = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                $montant_credit = $montant_debit = $data['montant'];
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle =$data['licence'].' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_client, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_suspens_provision,
                                            'Type_26'=>$data['type'],
                                    );
                
                return $instruction;
        }
        
        public function get_instructions_seguce_debit_bank_fees_by_licence_number($data, $comptes, $compte_provision = NULL)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                # Operation 1: debiter le compte client
                # pour crediter soit le compte frais bancaire 
                
                $result = json_decode($this->session->get('Bank_rates'), true);

                if(isset($result['Dollar_4']) && $result['Dollar_4'] !="")
                {
                        $taux = $result;
                }
                else
                {
                        $taux = 1;
                }
                
                $compte_dst = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '00000000000000000000000';
                
                if($data['account_currency'] == 'USD')
                {
                        $montant_debit = 10;
                        $montant_credit = 10 * $taux['Dollar_4'];
                }
                elseif($data['account_currency'] == 'CDF')
                {
                        $montant_debit = $montant_credit = 10 * $taux['Dollar_4'];
                }
                
                $libelle =  'Frais bancaire '.$data['licence'].' - '.$data['designation'].' - '.$data['code_import'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['customer_account'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>'CDF',
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['account_currency'],
                                            'Compte_13'=>$compte_dst,

                                    );
            
                # Operation 1: debiter le compte client
                # pour crediter soit le compte TVA 
                
                $compte_dst = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '00000000000000000000000';
                
                if($data['account_currency'] == 'USD')
                {
                        $montant_debit = 10 * 0.16;
                        $montant_credit = 10 * $taux['Dollar_4'] * 0.16;
                }
                elseif($data['account_currency'] == 'CDF')
                {
                        $montant_debit = $montant_credit = 10 * $taux['Dollar_4'] * 0.16;
                }
                
                $libelle =  'TVA sur le frais bancaire '.$data['licence'].' - '.$data['designation'].' - '.$data['code_import'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['customer_account'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>'CDF',
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=> $data['account_currency'],
                                            'Compte_13'=>$compte_dst,
                                    );
                
                return $instruction;
        }
        
        public function get_instructions_seguce_by_licence_number($data, $comptes, $compte_provision, $type)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                #var_dump($data['customer_exempts']); 
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $compte_dst = isset($comptes[$benificiary][$type][$data['devise']]) ? $comptes[$benificiary][$type][$data['devise']] : '00000000000000000000000';
                
                if($compte_provision == "" || $compte_provision == NULL) $compte_provision = "00000000000000000000000";
                
                if($type == 'CPO') $recette = " Part OCC";
                elseif($type == 'CPB') $recette = " Frais BIVAC";
                else $recette = "";
                
                $montant_credit = $montant_debit = $data['montant'];

                $data['designation'] = str_replace(' ', '_', $data['designation']);
                
                $libelle = "PMT_BORD_VOC/CAE_N°" .$data['num_bordereau'].'_'.$data['designation'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$compte_dst,
                                            'Type_26'=>$type,
                                            'Priority_27'=>1,
                                    );

                
                return $instruction;
        }
        
        
        public function get_instructions_seguce_by_licence_number1($data, $comptes, $compte_suspens_provision, $type)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                $benificiary = 'OCC';
                #var_dump($data['customer_exempts']);

                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants

                $data['devise'] = (isset($data['devise']) && $data['devise'] != "") ? $data['devise'] : "USD";

                $compte_dst = isset($comptes[$benificiary][$type][$data['devise']]) ? $comptes[$benificiary][$type][$data['devise']] : '00000000000000000000000';

                if($compte_suspens_provision == "" || $compte_suspens_provision == NULL) $compte_suspens_provision = "00000000000000000000000";

                if($type == 'CPO') $recette = " Part OCC";
                elseif($type == 'CPB') $recette = " Frais BIVAC";
                elseif($type == 'CTC') $recette = " Frais TVA controle";
                else $recette = "";


                $montant_credit = $montant_debit = $data['montant'];

                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];

                $libelle = $data['licence'].' - '.$recette.' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;

                $instruction = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$compte_suspens_provision,
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$compte_dst,
                                            'Type_26'=>$type
                                    );


                return $instruction;
        }


        public function get_instructions_seguce_by_licence_number_without_provision($data, $comptes, $type)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                #var_dump($data['customer_exempts']); 
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $taux = json_decode($this->session->get('Bank_rates'), true);

                $compte_client = isset($data['customer_account']) ? $data['customer_account'] : "00000000000000000000000";
                
                $compte_dst = isset($comptes[$benificiary][$type][$data['devise']]) ? $comptes[$benificiary][$type][$data['devise']] : '00000000000000000000000';
                
                if(isset($data['account_currency']) && $data['account_currency'] == 'CDF')
                {
                        $montant_debit =  $data['montant'] * $taux['Dollar_4'];
                        $montant_credit = $data['montant'];
                }
                elseif(isset($data['account_currency']) && $data['account_currency'] == 'EUR')
                {
                        $montant_debit = $data['montant'] * $taux['Dollar_4'];
                        $montant_debit = $montant_debit / $taux['Euro_5'];
                        
                        $montant_credit = $data['montant'];
                }
                elseif(isset($data['account_currency']) && $data['account_currency'] == 'USD')
                {
                        $montant_debit = $montant_credit = $data['montant'];
                }
                else
                {
                        $data['account_currency'] = 'USD';
                        $montant_debit = $montant_credit = $data['montant'];
                }
                
                if($type == 'CPO') $recette = " Part OCC";
                elseif($type == 'CPB') $recette = " Frais BIVAC";
                
                //$montant_credit = $montant_debit = $data['montant'];
                
                $libelle = "PMT_BORD_VOC/CAE_N°" .$data['num_bordereau'].'_'.$data['designation'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_client, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['account_currency'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$compte_dst,
                                            'Type_26'=>$type,
                                            'Priority_27'=>1,
                                    );

                
                return $instruction;
        }
        
        public function get_instructions_occ_tva_debit_by_customer($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                #var_dump($data['customer_exempts']); 
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $compte_src = isset($comptes[$benificiary]['CPO'][$data['devise']]) ? $comptes[$benificiary]['CPO'][$data['devise']] : '00000000000000000000000';
                $compte_dst = isset($comptes[$benificiary]['CTC'][$data['devise']]) ? $comptes[$benificiary]['CTC'][$data['devise']] : '00000000000000000000000';

                $montant_credit = $montant_debit = $data['montant'];
                
                $libelle = "TVA_PMT_BORD_VOC/CAE_N° " .$data['num_bordereau'].'_'.$data['designation'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_src, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$compte_dst,
                                            'Type_26'=>'CTC',
                                            'Priority_27'=>1,
                                    );
                
                return $instruction;
        }
        
        public function get_frais_bancaire_instructions_seguce_debit_by_licence_number($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'TMB';
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['COB']['CDF']) ? $comptes[$bank_code]['COB']['CDF'] : '000000000000000000000000'; 
                
                $montant_debit_com = round($data['montant_fb'] * $taux['Dollar_4'], 2);
                $montant_credit_com =  $data['montant_fb'];
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $type = (isset($data['type']) && $data['type'] != "") ? $data['type']: "";

                $libelle = "Frais_bancaire_OCC/BIVAC_".$data['num_bordereau'].'_'.$annee_bordereau;
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision , 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=> $montant_debit_com, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit_com, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_cfb,
                                            'Type_26'=>$type,
                                    );
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                
                $compte_tva = isset($comptes[$bank_code]['TOB']['CDF']) ? $comptes[$bank_code]['TOB']['CDF'] : '000000000000000000000000'; 
                
                $libelle = "TVA sur le frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;
                
         
                $montant_debit = round($data['montant_tva'] * $taux['Dollar_4'], 2);
                $montant_credit =  $data['montant_tva'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=> $montant_debit, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_tva,
                                            'Type_26'=>$type,
                                    );
                
                return $instruction;
        }

        public function get_frais_bancaire_instructions_seguce_debit_by_licence_number1($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'Rawbank';
                
                $taux = json_decode($_SESSION['Bank_rates'], true);
                
                $compte_suspens_provision = isset($comptes[$bank_code]['CSP']['USD']) ? $comptes[$bank_code]['CSP']['USD'] : '00000000000000000000000';
                
                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['COB']['CDF']) ? $comptes[$bank_code]['COB']['CDF'] : '000000000000000000000000'; 
                
                $montant_debit_com = round($data['montant_fb'] * $taux['Dollar_4'], 2);
                $montant_credit_com =  $data['montant_fb'];
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $type = (isset($data['type']) && $data['type'] != "") ? $data['type']: "COM";

                $libelle = "Frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision , 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=> $montant_debit_com, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit_com, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_cfb,
                                            'Type_26'=>$type,
                                    );
                
                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise
                
                $compte_tva = isset($comptes[$bank_code]['TOB']['CDF']) ? $comptes[$bank_code]['TOB']['CDF'] : '000000000000000000000000'; 
                
                $libelle = "TVA sur le frais bancaire - OCC/BIVAC - ".$data['num_bordereau'].' - '.$annee_bordereau;
             
                $montant_debit = round($data['montant_tva'] * $taux['Dollar_4'], 2);
                $montant_credit =  $data['montant_tva'];
                
                $type = (isset($data['type']) && $data['type'] != "") ? $data['type']: "TVA";
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_suspens_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=> $montant_debit, 
                                            'Devise_11'=>"CDF",
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>"USD",
                                            'Compte_13'=>$compte_tva,
                                            'Type_26'=>$type,
                                    );
                
                return $instruction;
        }

        public function get_instructions_occ_bivac_debit_bank_fees_by_customer($data, $comptes)
        {

                $instructions = array();
                $bank_code = 'TMB';

                $taux = json_decode($this->session->get('Bank_rates'), true);

                # Operation 2: crediter le compte commission de la banque
                # Toujours s'assurer d'avoir un compte commission pour chaque devise
                $compte_cfb = isset($comptes[$bank_code]['CFB']['CDF']) ? $comptes[$bank_code]['CFB']['CDF'] : '000000000000000000000000'; 

                if (isset($data['customer_account']) && $data['customer_account'] != "")
                {
                        $compte_client = $data['customer_account'];
                }
                else
                {
                        $compte_client = "00000000000000000000000";
                }

                if (isset($data['account_currency']) && $data['account_currency'] == 'CDF')
                {
                        $montant_debit_com = $montant_credit_com = round($data['montant'] * $taux['Dollar_4'], 2);
                }
                else
                {
                        $montant_debit_com = $data['montant'];
                        $montant_credit_com = round($data['montant']  * $taux['Dollar_4'], 2);
                }

                $libelle = "LIQ FRS BORD VOC/CAE N° ".$data['num_bordereau'].' - '.$data['designation'];

                $instruction[] = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$compte_client ,
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=> $montant_debit_com,
                                        'Devise_11'=>$data['account_currency'],
                                        'Montant_24'=>$montant_credit_com,
                                        'Devise_25'=>"CDF",
                                        'Compte_13'=>$compte_cfb,
                                        'Priority_27' => $data['Priority'],
                                        'Type_26'=>'COM'
                                );

                # Operation 3: crediter le compte TVA de la banque
                # Toujours s'assurer d'avoir un compte TVA pour chaque devise

                $compte_tva = isset($comptes[$bank_code]['TVA']['CDF']) ? $comptes[$bank_code]['TVA']['CDF'] : '000000000000000000000000'; 

                $montant_debit = $montant_credit = round($montant_credit_com * 0.16, 2);

                $instruction[] = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$compte_client,
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=> $montant_debit,
                                        'Devise_11'=>"CDF",
                                        'Montant_24'=>$montant_credit,
                                        'Devise_25'=>"CDF",
                                        'Compte_13'=>$compte_tva,
                                        'Priority_27' => $data['Priority'],
                                        'Type_26'=>'TVA'
                                );

                return $instruction;
        }

        public function get_partial_instructions_seguce_by_licence_number($data, $comptes, $compte_provision, $type)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                

                $compte_dst = isset($comptes[$benificiary][$type][$data['devise']]) ? $comptes[$benificiary][$type][$data['devise']] : '00000000000000000000000';
                
                if($compte_provision == "" || $compte_provision == NULL) $compte_provision = "00000000000000000000000";
                
                if($type == 'CPO') $recette = " Part OCC";
                elseif($type == 'CPB') $recette = " Frais BIVAC";
                elseif($type == 'CTC') $recette = " Frais TVA controle";
                else $recette = "";
                
                
                $montant_credit = $montant_debit = $data['montant'];
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $libelle =  $data['licence'].' - '.$recette.' - '.$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau'].' - '.$annee_bordereau;;
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['devise'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$compte_dst,
                                            'Type_26'=>$type
                                    );

                
                return $instruction;
        }
        
        public function get_instructions_invoice_regularization($data)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                $compte_provision = $data['compte_provision'];
                
                if($compte_provision == "" || $compte_provision == NULL) $compte_provision = "00000000000000000000000";
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                if($data['currency'] == 'CDF')
                {
                        $montant_debit =  $data['montant'] * $taux['Dollar_4'];
                        $montant_credit = $data['montant'];
                }
                elseif($data['currency'] == 'EUR')
                {
                        $montant_debit = $data['montant'] * $taux['Dollar_4'];
                        $montant_debit = $montant_debit / $taux['Euro_5'];
                        
                        $montant_credit = $data['montant'];
                }
                elseif($data['currency'] == 'USD')
                {
                        $montant_debit = $montant_credit = $data['montant'];
                }
                
                $date_bordereau = explode('-', $data['date_bordereau']);
                $annee_bordereau = $date_bordereau[0];
                
                $libelle =  "Extourne ".$data['designation'].' - '.$data['code_import']. ' - ' .$data['num_bordereau']. ' - ' .$annee_bordereau;
                
                $instructions = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=> $compte_provision, 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['currency'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['devise'],
                                            'Compte_13'=>$data['customer_account']
                                    );

                
                return $instructions;
        }
        
        
        public function get_instructions_provision_reverse_by_customer($data)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                $compte_provision = $data['compte_provision'];
                
                if($compte_provision == "" || $compte_provision == NULL) $compte_provision = "00000000000000000000000";
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
//                if($data['account_currency'] == 'CDF')
//                {
//                        $montant_debit =  $data['montant'] * $taux['Dollar_4'];
//                        $montant_credit = $data['montant'];
//                }
//                elseif($data['account_currency'] == 'EUR')
//                {
//                        $montant_debit = $data['montant'] * $taux['Dollar_4'];
//                        $montant_debit = $montant_debit / $taux['Euro_5'];
//                        
//                        $montant_credit = $data['montant'];
//                }
//                elseif($data['account_currency'] == 'USD')
//                {
//                        $montant_debit = $montant_credit = $data['montant'];
//                }
                
                $montant_debit = $montant_credit = $data['montant'];
                
                $libelle =  "SURPLUS_BORDEREAU_N°_".$data['num_bordereau']. "_" .$data['licence'];
                
                $instructions = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=> $compte_provision, 
                                            'Libelle_12'=> $libelle, 
                                            'Montant_10'=> $montant_debit, 
                                            'Devise_11'=> $data['devise'],
                                            'Montant_24'=> $montant_credit, 
                                            'Devise_25'=> $data['account_currency'],
                                            'Compte_13'=>$data['customer_account'],
                                            'Priority_27'=>1,
                                    );

                
                return $instructions;
        }
        
        public function get_instructions_provision_complement_by_customer($data, $compte_provision)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $benificiary = 'OCC';
                
                # Operation 1: debiter le compte provision
                # pour crediter soit le compte des intervenants 
                
                $taux = json_decode($this->session->get('Bank_rates'), true);
                
                if($data['account_currency'] == 'CDF')
                {
                        $montant_debit =  $data['montant'] * $taux['Dollar_4'];
                        $montant_credit = $data['montant'];
                }
                elseif($data['account_currency'] == 'EUR')
                {
                        $montant_debit = $data['montant'] * $taux['Dollar_4'];
                        $montant_debit = $montant_debit / $taux['Euro_5'];
                        
                        $montant_credit = $data['montant'];
                }
                elseif($data['account_currency'] == 'USD')
                {
                        $montant_debit = $montant_credit = $data['montant'];
                }
                else
                {
                        $montant_debit = $montant_credit = $data['montant'];
                }    
                

                
                
                $libelle =  "COMPLEMENT_BORD_N°".$data['num_bordereau'];
                
                $instructions = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=> $data['customer_account'], 
                                            'Libelle_12'=> $libelle, 
                                            'Montant_10'=> $montant_debit, 
                                            'Devise_11'=> $data['account_currency'],
                                            'Montant_24'=> $montant_credit, 
                                            'Devise_25'=> $data['devise'],
                                            'Compte_13'=> $compte_provision,
                                            'Priority_27'=>1,
                                    );

                
                return $instructions;
        }
        
        public function get_instructions_seguce($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = 'TMB';
                # Operation 1: debiter le compte suspens seguce
                # pour crediter le compte GUICE
                
                $montant = 0;
                $devise = 'CDF';

                $compte_sus = isset($comptes[$bank_code]['CSG'][$devise])? $comptes[$bank_code]['CSG'][$devise]:'';

                $compte_dst = isset($comptes['SEGUCE']['CSC'][$data['Devise_12']]) ? $comptes['SEGUCE']['CSC'][$data['Devise_12']] : '';

                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $monant = ($data['Notemontant_28'] * $data['Taux_41']);
                $libelle =  $data['Noteid_26'].' - '.$data['Typerecette_17'].'-'.$data['Designation_14'].' - '.$data['Nif_13'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_sus,
                                            'Libelle_12'=>$libelle,  
                                            'Montant_10'=>$data['Montant_11'], 
                                            'Devise_11'=>'CDF',
                                            'Compte_13'=>$compte_dst,
                                            'Montant_26'=> '',
                                            'Devise_27'=> 'CDF',
                                    );
                
                return $instruction;
        }
        public function get_instructions_seguce_invoice($data, $comptes, $compte_sus, $compte_cgu, $type)
        {
                $instructions = array();
                $bank_code = isset($data['bank'])?$data['bank']:"";
                # Operation 1: debiter le compte suspens seguce
                # pour crediter le compte GUICE
                
                $montant = 0;
                $devise = 'CDF';

                $compte_sus = isset($comptes[$bank_code]['CSG'][$devise])? $comptes[$bank_code]['CSG'][$devise]:'';

                $compte_dst = isset($comptes['SEGUCE']['CSC'][$data['Devise_12']]) ? $comptes['SEGUCE']['CSC'][$data['Devise_12']] : '';

                if($compte_dst == "") $compte_dst = '00000000000000000000000';
                
                $monant = ($data['Notemontant_28'] * $data['Taux_41']);
                $libelle =  $data['Noteid_26'].' - '.$data['Typerecette_17'].'-'.$data['Designation_14'].' - '.$data['Nif_13'];
                
                $instruction = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$compte_sus,
                                            'Libelle_12'=>$libelle,  
                                            'Montant_10'=>$data['Montant_11'], 
                                            'Devise_11'=>'CDF',
                                            'Compte_13'=>$compte_dst,
                                            'Montant_26'=> $data['Montant_11'],
                                            'Devise_27'=> 'CDF',
                                    );
                
                $instructions[]=$instruction;

                return $instructions;
        }
        public function get_instructions_provision($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $taux = array();
                
                $result = json_decode($this->session->get('Bank_rates'), true);
                
                if(isset($result['Dollar_4']) && $result['Dollar_4'] !="")
                {
                        $taux = $result;
                }
                else
                {
                        $taux = 1;
                }
                
                ######################### Operation 1: debiter le compte du client pour crediter le frais de seguce
                
                if ((isset($data['SeguceFees_32']) && $data['SeguceFees_32'] > 0) &&  $data['RateSeguce_37']  > 0)
                {
                        # Montant frais Seguce
                        if($data['Devise_22'] == $data['Devise_33'] &&  $data['Devise_22'] == 'CDF')
                        {
                                $montant_debit = $montant_credit = $data['SeguceFees_32'] * $data['RateSeguce_37'];
                        }
                        elseif($data['Devise_22'] == 'CDF' && $data['Devise_33'] == 'USD') 
                        {
                                $montant_debit = $data['SeguceFees_32'] * $data['RateSeguce_37'];
                                $montant_credit = $data['SeguceFees_32'];
                        }
                        elseif($data['Devise_22'] == 'USD') 
                        {
                                $montant_debit = $data['SeguceFees_32'];
                                $montant_credit = $data['SeguceFees_32'] * $data['RateSeguce_37'];
                        }
                        elseif($data['Devise_22'] == 'EUR') 
                        {
                                $montant = $data['SeguceFees_32'] * $data['RateSeguce_37'];
                                $montant_debit = $montant / $taux['Euro_5'];
                                $montant_credit = $montant;
                        }

                        $compte_dst = isset($comptes['TMB']['CSC']['CDF']) ? $comptes['TMB']['CSC']['CDF'] : '000000000000000000000000'; #####################################
                        $libelle = 'SEGUCE / ' .$data['Reference_34']. " / "  .$data['Licence'];

                        $instruction[] = array(
                                                    'Operation_8'=>'V', 
                                                    'Compte_9'=>$data['Compte_21'], 
                                                    'Libelle_12'=>$libelle, 
                                                    'Montant_10'=>$montant_debit, 
                                                    'Devise_11'=>$data['Devise_22'],
                                                    'Montant_24'=>$montant_credit, 
                                                    'Devise_25'=>'CDF',
                                                    'Compte_13'=>$compte_dst
                                            );
                }
                
                
                ######################## Operation 2: debiter le compte du client pour crediter le compte provision OCC ######################################
                          
                if (isset($data['Montantprov_10']) && $data['Montantprov_10'] > 0)
                {
                        # Montant de la provision OCC BIVAC
                        if($data['Devise_22'] == 'CDF')
                        {
                                $montant_debit = $data['Montantprov_10'] * $taux['Dollar_4'];

                                $montant_credit = $data['Montantprov_10'];
                        }
                        elseif($data['Devise_22'] == 'USD') 
                        {
                                $montant_debit = $montant_credit = $data['Montantprov_10'];
                        }
                        elseif($data['Devise_22'] == 'EUR')
                        {
                                $montant_debit = $data['Montantprov_10'] * $taux['Dollar_4'];
                                $montant_debit = $montant_debit / $taux['Euro_5']; 

                                $montant_credit = $data['Montantprov_10'];
                        }

                        $compte_dst = isset($comptes['TMB']['CPF']['USD']) ? $comptes['TMB']['CPF']['USD'] : '000000000000000000000000'; 
                        $libelle = 'PROV OCC BIVAC SVT '.$data['Licence'] . ' ' .strtoupper($data['Designation_23']);

                        $instruction[] = array(
                                                    'Operation_8'=>'V', 
                                                    'Compte_9'=>$data['Compte_21'], 
                                                    'Libelle_12'=>$libelle, 
                                                    'Montant_10'=>$montant_debit, 
                                                    'Devise_11'=>$data['Devise_22'],
                                                    'Montant_24'=>$montant_credit, 
                                                    'Devise_25'=>'USD',
                                                    'Compte_13'=>$compte_dst
                                            );
                }
                
                
                #########################  Operation 3: debiter le compte du client pour crediter le frais d'achat de licence #####################################
                
                # Montant frais de licence
                if($data['Devise_22'] == 'CDF') 
                {
                        $montant_debit = $montant_credit = $data['LicenceFees_15'] * $taux['Dollar_4'];
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_debit = $data['LicenceFees_15'];
                        $montant_credit = $data['LicenceFees_15'] * $taux['Dollar_4'];
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['LicenceFees_15'] * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf/$taux['Euro_5'];
                        
                        $montant_credit = $amount_converted_in_cdf;
                }
                
                
                $compte_dst = isset($comptes['TMB']['CFL']['CDF']) ? $comptes['TMB']['CFL']['CDF'] : '000000000000000000000000'; 
                $libelle = 'FRAIS ACHAT LICENCE '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>'CDF',
                                            'Compte_13'=>$compte_dst
                                    );
                
                #########################  Operation 4: debiter le compte du client pour crediter la tva sur d'achat de licence #####################################
                
                # TVA frais de licence
                if($data['Devise_22'] == 'CDF')
                {
                        $amount_converted_in_cdf = $data['LicenceFees_15'] * $taux['Dollar_4'];
                        $montant_debit = $montant_credit = $amount_converted_in_cdf * 0.16;
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_converted_in_cdf = $data['LicenceFees_15'] * $taux['Dollar_4'];
                        
                        $montant_debit = $data['LicenceFees_15'] * 0.16;
                        $montant_credit = $montant_converted_in_cdf * 0.16;
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['LicenceFees_15'] * $taux['Dollar_4'];
                        $montant_debit = ($amount_converted_in_cdf/$taux['Euro_5']) * 0.16;
                        
                        $montant_credit = $amount_converted_in_cdf * 0.16;
                }
                
                $compte_dst = isset($comptes['TMB']['CTA']['CDF']) ? $comptes['TMB']['CTA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'FRAIS TVA ACHAT LICENCE '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>'CDF',
                                            'Compte_13'=>$compte_dst
                                    );
                
                ######################### Operation 5: debiter le compte du client pour crediter le frais de validation
                
                # Montant frais de validation
                if($data['Devise_22'] == 'CDF')
                {
                        $montant_debit = $data['ValidationFees_17'] * $taux['Dollar_4'];
                        $montant_credit = $data['ValidationFees_17'];
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_debit = $montant_credit = $data['ValidationFees_17'];
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['ValidationFees_17'] * $taux['Dollar_4'];
                        
                        $montant_debit = $amount_converted_in_cdf/$taux['Euro_5'];
                        $montant_credit = $data['ValidationFees_17'];
                }
                
                $compte_dst = isset($comptes['TMB']['CFV']['USD']) ? $comptes['TMB']['CFV']['USD'] : '000000000000000000000000'; #####################################
                $libelle = 'FRAIS DE VALIDATION '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['Devise_18'],
                                            'Compte_13'=>$compte_dst
                                    );
                ######################### Operation 6: debiter le compte du client pour crediter la tva sur le frais de validation
                #
                # TVA frais de validation
                if($data['Devise_22'] == 'CDF')
                {
                        $amount_converted_in_cdf = $data['ValidationFees_17'] * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf * 0.16;
                        
                        $montant_credit = $data['ValidationFees_17'] * 0.16;
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_debit = $montant_credit = $data['ValidationFees_17'] * 0.16;
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['ValidationFees_17'] * $taux['Dollar_4'];
                        $montant_debit = ($amount_converted_in_cdf / $taux['Euro_5']) * 0.16;
                        
                        $montant_credit = $data['ValidationFees_17'] * 0.16;
                }
                
                $compte_dst = isset($comptes['TMB']['CTV']['USD']) ? $comptes['TMB']['CTV']['USD'] : '000000000000000000000000'; 
                $libelle = 'FRAIS TVA VALIDATION '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>'USD',
                                            'Compte_13'=>$compte_dst
                                    );
                
                
                ######################### Operation 7: debiter le compte du client pour crediter le frais de redevance
                
                if (isset($data['RoyaltyFees_30']) && $data['RoyaltyFees_30'] > 0)
                {
                        # Montant frais de redevance
                        if($data['Devise_22'] == $data['Devise_31'] &&  $data['Devise_22'] == 'CDF')
                        {
                                $montant_debit = $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == 'CDF' && $data['Devise_31'] == 'USD') 
                        {
                                $montant_debit = $data['RoyaltyFees_30'] * $taux['Dollar_4'];
                                $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == 'CDF' && $data['Devise_31'] == 'EUR') 
                        {
                                $montant_debit = $data['RoyaltyFees_30'] * $taux['Euro_5'];
                                $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == $data['Devise_31'] && $data['Devise_31'] == 'USD') 
                        {
                                $montant_debit = $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == 'USD' && $data['Devise_31'] == 'CDF') 
                        {
                                $montant_debit = $data['RoyaltyFees_30'] / $taux['Dollar_4'];
                                $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == 'EUR' && $data['Devise_31'] == 'CDF') 
                        {
                                $montant_debit = $data['RoyaltyFees_30'] / $taux['Euro_5'];
                                $montant_credit = $data['RoyaltyFees_30'];
                        }
                        elseif($data['Devise_22'] == 'EUR' && $data['Devise_31'] == 'USD') 
                        {
                                $montant_debit = $data['RoyaltyFees_30'] * $taux['Dollar_4'];

                                $montant_debit = $montant_debit / $taux['Euro_5'];

                                $montant_credit = $data['RoyaltyFees_30'];
                        }

                        $compte_dst = isset($comptes['TMB']['CFR']['USD']) ? $comptes['TMB']['CFR']['USD'] : '000000000000000000000000'; #####################################
                        $libelle = 'FRAIS DE REDEVANCE '.$data['Licence'];

                        $instruction[] = array(
                                                    'Operation_8'=>'V', 
                                                    'Compte_9'=>$data['Compte_21'], 
                                                    'Libelle_12'=>$libelle, 
                                                    'Montant_10'=>$montant_debit, 
                                                    'Devise_11'=>$data['Devise_22'],
                                                    'Montant_24'=>$montant_credit, 
                                                    'Devise_25'=>$data['Devise_31'],
                                                    'Compte_13'=>$compte_dst
                                            );
                }
                ######################### Operation 8: debiter le compte du client pour crediter le frais d'intervention seguce 
                
                # Montant frais d'intervention seguce
                if($data['Devise_22'] == 'CDF')
                {
                        $montant_debit =  $data['Commission_35'] * $taux['Dollar_4'];
                        $montant_credit = $data['Commission_35'];
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_debit =$montant_credit = $data['Commission_35'];
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['Commission_35'] * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf/$taux['Euro_5'];
                        $montant_credit = $data['Commission_35'];
                }
                
                $compte_dst = isset($comptes['TMB']['CCS']['USD']) ? $comptes['TMB']['CCS']['USD'] : '000000000000000000000000'; #####################################
                $libelle = 'FRAIS INTERVENTION SEGUCE '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['Devise_36'],
                                            'Compte_13'=>$compte_dst
                                    );
                ######################### Operation 9: debiter le compte du client pour crediter le frais d'intervention seguce 
                
                # Montant frais tva intervention seguce
                $amount_in_usd = $data['Commission_35'] * 0.16;
                $amount_in_usd = round($amount_in_usd, 2);
                
                if($data['Devise_22'] == 'CDF')
                {
                        $montant_debit = $amount_in_usd * $taux['Dollar_4'];
                        $montant_credit = $amount_in_usd;
                }
                elseif($data['Devise_22'] == 'USD') 
                {
                        $montant_debit = $montant_credit = $amount_in_usd;
                }
                elseif($data['Devise_22'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $amount_in_usd * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf / $taux['Euro_5'];
                        
                        $montant_credit = $amount_in_usd;
                }
                
                
                $compte_dst = isset($comptes['TMB']['CTF']['CDF']) ? $comptes['TMB']['CTF']['CDF'] : '000000000000000000000000'; #####################################
                $libelle = 'TVA SUR FRAIS INTERVENTION SEGUCE  '.$data['Licence'];
                
                $instruction[] = array(
                                            'Operation_8'=>'V', 
                                            'Compte_9'=>$data['Compte_21'], 
                                            'Libelle_12'=>$libelle, 
                                            'Montant_10'=>$montant_debit, 
                                            'Devise_11'=>$data['Devise_22'],
                                            'Montant_24'=>$montant_credit, 
                                            'Devise_25'=>$data['Devise_36'],
                                            'Compte_13'=>$compte_dst
                                    );
                
                return $instruction;
        }

        public function get_instructions_licence($data, $comptes)
        {
                $instructions = array();
                $bank_code = 'TMB';
                $taux = array();

                $result = json_decode($this->session->get('Bank_rates'), true);

                if(isset($result['Dollar_4']) && $result['Dollar_4'] !="")
                {
                        $taux = $result;
                }
                else
                {
                        $taux = 1;
                }


                #########################  Operation 1: debiter le compte du client pour crediter le frais d'achat de licence #####################################

                # Montant frais de licence
                if($data['Devise_21'] == 'CDF') 
                {
                        $montant_debit = $montant_credit = $data['LicenceFees_14'] * $taux['Dollar_4'];
                }
                elseif($data['Devise_21'] == 'USD') 
                {
                        $montant_debit = $data['LicenceFees_14'];
                        $montant_credit = $data['LicenceFees_14'] * $taux['Dollar_4'];
                }
                elseif($data['Devise_21'] == 'EUR') 
                {
                        $amount_converted_in_cdf = $data['LicenceFees_14'] * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf/$taux['Euro_5'];

                        $montant_credit = $amount_converted_in_cdf;
                }


                $compte_dst = isset($comptes['TMB']['CFL']['CDF']) ? $comptes['TMB']['CFL']['CDF'] : '000000000000000000000000'; 
                $libelle = 'FRAIS ACHAT LICENCE '.$data['Licence_7']." ".$data['Title_8'];

                $instruction[] = array(
                                        'Operation_8'=>'V',
                                        'Compte_9'=>$data['Compte_20'],
                                        'Libelle_12'=>$libelle,
                                        'Montant_10'=>$montant_debit,
                                        'Devise_11'=>$data['Devise_21'],
                                        'Montant_24'=>$montant_credit,
                                        'Devise_25'=>'CDF',
                                        'Compte_13'=>$compte_dst
                                );

                #########################  Operation 2: debiter le compte du client pour crediter la tva sur d'achat de licence #####################################

                # TVA frais de licence
                if($data['Devise_21'] == 'CDF')
                {
                        $amount_converted_in_cdf = $data['LicenceFees_14'] * $taux['Dollar_4'];
                        $montant_debit = $montant_credit = $amount_converted_in_cdf * 0.16;
                }
                elseif($data['Devise_21'] == 'USD')
                {
                        $montant_converted_in_cdf = $data['LicenceFees_14'] * $taux['Dollar_4'];

                        $montant_debit = $data['LicenceFees_14'] * 0.16;
                        $montant_credit = $montant_converted_in_cdf * 0.16;
                }
                elseif($data['Devise_21'] == 'EUR')
                {
                        $amount_converted_in_cdf = $data['LicenceFees_14'] * $taux['Dollar_4'];
                        $montant_debit = ($amount_converted_in_cdf/$taux['Euro_5']) * 0.16;

                        $montant_credit = $amount_converted_in_cdf * 0.16;
                }

                $compte_dst = isset($comptes['TMB']['CTA']['CDF']) ? $comptes['TMB']['CTA']['CDF'] : '000000000000000000000000'; 
                $libelle = 'FRAIS TVA ACHAT LICENCE '.$data['Licence_7']." ".$data['Title_8'];

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$data['Compte_20'],
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>$data['Devise_21'],
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>'CDF',
                                            'Compte_13'=>$compte_dst
                                    );

                ######################### Operation 3: debiter le compte du client pour crediter le frais de validation

                # Montant frais de validation
                if($data['Devise_21'] == 'CDF')
                {
                        $montant_debit = $data['ValidationFees_16'] * $taux['Dollar_4'];
                        $montant_credit = $data['ValidationFees_16'];
                }
                elseif($data['Devise_21'] == 'USD')
                {
                        $montant_debit = $montant_credit = $data['ValidationFees_16'];
                }
                elseif($data['Devise_21'] == 'EUR')
                {
                        $amount_converted_in_cdf = $data['ValidationFees_16'] * $taux['Dollar_4'];

                        $montant_debit = $amount_converted_in_cdf/$taux['Euro_5'];
                        $montant_credit = $data['ValidationFees_16'];
                }

                $compte_dst = isset($comptes['TMB']['CFV']['USD']) ? $comptes['TMB']['CFV']['USD'] : '000000000000000000000000'; #####################################
                $libelle = 'FRAIS DE VALIDATION '.$data['Licence_7']." ".$data['Title_8'];

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$data['Compte_20'],
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>$data['Devise_21'],
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>$data['Devise_17'],
                                            'Compte_13'=>$compte_dst
                                    );
                ######################### Operation 4: debiter le compte du client pour crediter la tva sur le frais de validation
                #
                # TVA frais de validation
                if($data['Devise_21'] == 'CDF')
                {
                        $amount_converted_in_cdf = $data['ValidationFees_16'] * $taux['Dollar_4'];
                        $montant_debit = $amount_converted_in_cdf * 0.16;

                        $montant_credit = $data['ValidationFees_16'] * 0.16;
                }
                elseif($data['Devise_21'] == 'USD')
                {
                        $montant_debit = $montant_credit = $data['ValidationFees_16'] * 0.16;
                }
                elseif($data['Devise_21'] == 'EUR')
                {
                        $amount_converted_in_cdf = $data['ValidationFees_16'] * $taux['Dollar_4'];
                        $montant_debit = ($amount_converted_in_cdf / $taux['Euro_5']) * 0.16;

                        $montant_credit = $data['ValidationFees_16'] * 0.16;
                }

                $compte_dst = isset($comptes['TMB']['CTV']['USD']) ? $comptes['TMB']['CTV']['USD'] : '000000000000000000000000';
                $libelle = 'FRAIS TVA VALIDATION '.$data['Licence_7']." ".$data['Title_8'];

                $instruction[] = array(
                                            'Operation_8'=>'V',
                                            'Compte_9'=>$data['Compte_20'],
                                            'Libelle_12'=>$libelle,
                                            'Montant_10'=>$montant_debit,
                                            'Devise_11'=>$data['Devise_21'],
                                            'Montant_24'=>$montant_credit,
                                            'Devise_25'=>'USD',
                                            'Compte_13'=>$compte_dst
                                    );

                return $instruction;
        }

        public function get_instruction_provision_by_ref($ref)
        {
                $this->set_table('logiref_cbs_instructions_provision I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Reference_14' => $ref), TRUE);
        }

        public function get_invoice_single()
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND Status_2='2' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoices($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND Status_2 = '1' ";

                #Filtre d'affichage
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";

                $this->db->query('SET SESSION sql_mode =
                        REPLACE(REPLACE(REPLACE(
                        @@sql_mode,
                        "ONLY_FULL_GROUP_BY,", ""),
                        ",ONLY_FULL_GROUP_BY", ""),
                        "ONLY_FULL_GROUP_BY", "")');
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                        ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();

                return $builder->getResult();
        }

        public function get_invoices_paid($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND Status_2 = '4'";

                #Filtre d'affichage
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";

                $this->db->query('SET SESSION sql_mode =
                        REPLACE(REPLACE(REPLACE(
                        @@sql_mode,
                        "ONLY_FULL_GROUP_BY,", ""),
                        ",ONLY_FULL_GROUP_BY", ""),
                        "ONLY_FULL_GROUP_BY", "")');
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                        ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();

                return $builder->getResult();
        }

        public function get_unvalidated_invoices_batch($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND Status_2 = '2' ";
                
                #Filtre d'affichage
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                $this->db->query('SET SESSION sql_mode =
                        REPLACE(REPLACE(REPLACE(
                        @@sql_mode,
                        "ONLY_FULL_GROUP_BY,", ""),
                        ",ONLY_FULL_GROUP_BY", ""),
                        "ONLY_FULL_GROUP_BY", "")');
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                        ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();

                return $builder->getResult();
        }

        public function get_unvalidated_invoices_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                $this->db->query('SET SESSION sql_mode =
                  REPLACE(REPLACE(REPLACE(
                  @@sql_mode,
                  "ONLY_FULL_GROUP_BY,", ""),
                  ",ONLY_FULL_GROUP_BY", ""),
                  "ONLY_FULL_GROUP_BY", "")');
                $st = " Account_3='" . $account . "' AND Status_2 = '5' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                         ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();

                return $builder->getResult();
        }

        public function get_unvalidated_invoices_occ_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='5' AND Account_3='".$account."'";
                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoices_by_reference_bfu($reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Refbfu_9 = '".$reference."' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoice_by_reference($reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 !='0' AND Account_3='".$account."' AND Reference_7 = '".$reference."' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }

        public function get_provisions()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2 !='0' AND Account_3='".$account."' AND Montantprov_10 >'0' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_frais_licence()
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2 !='0' AND Account_3='".$account."' AND Guichet_25='".$guichet."'";
                $builder = $this->db->table('logiref_integration_licence')
                        ->select('logiref_integration_licence.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_prelevement_frais_nvalidated()
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "Status_2 ='1' AND Account_3='".$account."'";

                #Filtre d'affichage
                if(isset($_POST['Categories']) && $_POST['Categories']!='') $st .= " AND CodeType_26='".$_POST['Categories']."'";
                if(isset($_POST['num_licence']) && $_POST['num_licence']!='') $st .= " AND Licence_7='".$_POST['num_licence']."'";
                if(isset($_POST['designation']) && $_POST['designation']!='') $st .= " AND Designation_22 LIKE '%".$_POST['designation']."%' ";

                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }

                $st .= " AND Guichet_25='".$guichet."'";

                $builder = $this->db->table('logiref_integration_licence')
                        ->select('logiref_integration_licence.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_prelevement_frais_validated()
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' ";

                #Filtre d'affichage
                if(isset($_POST['Categories']) && $_POST['Categories']!='') $st .= " AND CodeType_26='".$_POST['Categories']."'";
                if(isset($_POST['num_licence']) && $_POST['num_licence']!='') $st .= " AND Licence_7='".$_POST['num_licence']."'";
                if(isset($_POST['designation']) && $_POST['designation']!='') $st .= " AND Designation_22 LIKE '%".$_POST['designation']."%' ";

                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }

                $st .= " AND Guichet_25='".$guichet."'";

                $builder = $this->db->table('logiref_integration_licence')
                        ->select('logiref_integration_licence.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_frais_licence_filter()
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');

                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1'";
                #Filtre d'affichage
                if(isset($data['Categories']) && $data['Categories']!='') $st .= " AND CodeType_26='".$data['Categories']."'";
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";
                if(isset($data['designation']) && $data['designation']!='') $st .= " AND Designation_22 LIKE '%".$data['designation']."%' ";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }

                $builder = $this->db->table('logiref_integration_licence')
                        ->select('logiref_integration_licence.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_fees_licence_eb_nvalidated()
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Montantprov_10 = 0 AND CodeType_38 LIKE '%EB%' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_licence_eb_nvalidated_filter()
        {
                $data = $_POST;
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "Status_2 ='1' AND Account_3='".$account."' AND Montantprov_10 = 0 AND Guichet_28='".$guichet."' ";

                #Filtre d'affichage
                if(isset($data['Categories']) && $data['Categories']!='') $st .= " AND CodeType_38='".$data['Categories']."'";
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";
                if(isset($data['designation']) && $data['designation']!='') $st .= " AND Designation_23 LIKE '%".$data['designation']."%' ";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }

                #Run
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_fees_licence_eb_validated()
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');
                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' AND Montantprov_10 = 0 AND CodeType_38 LIKE '%EB%' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_licence_eb_validated_filter()
        {
                $data = $_POST;
                $account = $this->session->userdata['account_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' AND Montantprov_10 = 0 AND Guichet_28='".$guichet."' ";

                #Filtre d'affichage
                if(isset($data['Categories']) && $data['Categories']!='') $st .= " AND CodeType_38='".$data['Categories']."'";
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";
                if(isset($data['designation']) && $data['designation']!='') $st .= " AND Designation_23 LIKE '%".$data['designation']."%' ";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }

                #Run
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_provisions_nvalidated()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Montantprov_10 > '0' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_provisions_validated()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' AND Montantprov_10 >'0' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_provisions_validated_by_licence($licence)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' AND Licence_7='".$licence."' AND Guichet_28='".$guichet."' ";

                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_licence_validated_by_id($licence)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');

                $st = "(Status_2 ='2' OR Status_2 ='3' OR Status_2 ='4') AND Account_3='".$account."' AND Licence_7='".$licence."' AND Guichet_25='".$guichet."' ";

                $builder = $this->db->table('logiref_integration_licence')
                        ->select('logiref_integration_licence.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }

        public function get_provisions_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                $st = "Status_2 ='5' AND Account_3='".$account."' AND Montantprov_10 >'0' AND Guichet_28='".$guichet."' ";
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_provisions_nvalidated_filter()
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                
                #Query
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = '1' AND Montantprov_10 >'0' AND Guichet_28 = '".$guichet."'";
                #Filtre d'affichage
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";
                if(isset($data['designation']) && $data['designation']!='') $st .= " AND Designation_23 LIKE '%".$data['designation']."%' ";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_provisions_filter($status)
        {
                $data = $_POST;
                
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                
                if($status == 'regul') $st = "Status_2 = '5'";
                if($status == 'extourne') $st = "Status_2 = '2'";
                
                $st .= " AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_28 = '".$guichet."'";
                
                #Filtre d'affichage
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                
                #Query
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_provisions_validated_filter()
        {
                $data = $_POST;
                $user = $this->session->userdata['user_id'];
                $guichet = $this->session->get('Logiref_guichet');
                
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 != '1' AND Montantprov_10 >'0' AND Guichet_28 = '".$guichet."'";
                
                #Filtre d'affichage
                if(isset($data['num_licence']) && $data['num_licence']!='') $st .= " AND Licence_7='".$data['num_licence']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));
                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }
                
                #Query
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->select('logiref_integration_provision_occ.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_unvalidated_invoices_by_id($ids)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Status_2 ='2' AND Account_3='".$account."' AND Id_0 IN (".$ids.") ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_unvalidated_invoices_by_reference_bfu($reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='2' AND Account_3='".$account."' AND Refbfu_9 = '".$reference."' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_unvalidated_invoice_by_reference($reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='2' AND Account_3='".$account."' AND Reference_7 = '".$reference."' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_unvalidated_invoice_by_id($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Account_3='".$account."' AND Id_0 = '".$id."' ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }

        public function get_invoices_by_reference_bfu_to_regularize($reference)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='5' AND Account_3='".$account."' AND Refbfu_9 = '".$reference."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_invoices_occ_by_id_to_regularize($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='5' AND Account_3='".$account."' AND Id_0 = '".$id."' ";
                
                $builder = $this->db->get('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_invoices_to_regularize()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "(Status_2 ='5' OR Status_2='6') AND Account_3='".$account."'";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_treated_invoices_by_id($ids)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Id_0 IN (".$ids.") ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_treated_invoice_by_id($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 ='1' AND Account_3='".$account."' AND Id_0 ='".$id."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }

         public function get_treated_invoice_by_factureid($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $st = "Status_2 <> 0 AND Account_3='".$account."' AND Reference_7 ='".$id."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getRow();
        }
        
        public function get_invoices_filter($data) 
        {
                $user = $this->session->userdata['user_id'];
                
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 <> '3' ";
                
                #Filtre d'affichage
                if(isset($data['Reference_7']) && $data['Reference_7']!='') $st .= " AND Reference_7='".$data['Reference_7']."'";
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['Nif_10']) && $data['Nif_10']!='') $st .= " AND Nif_10='".$data['Nif_10']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_unvalidated_factures($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $this->db->query('SET SESSION sql_mode =
                    REPLACE(REPLACE(REPLACE(
                    @@sql_mode,
                    "ONLY_FULL_GROUP_BY,", ""),
                    ",ONLY_FULL_GROUP_BY", ""),
                    "ONLY_FULL_GROUP_BY", "")');
                $st = " Account_3='" . $account . "' AND Status_2 = '2' ";
                
                #Filtre d'affichage
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                
                #Filtre d'affichage
                if(isset($data['Reference_7']) && $data['Reference_7']!='') $st .= " AND Reference_7='".$data['Reference_7']."'";
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['Nif_10']) && $data['Nif_10']!='') $st .= " AND Nif_10='".$data['Nif_10']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*, Id_0, COUNT(Id_0) as total, Montant_11, SUM(Montant_11) as montant_total')
                        ->groupBy('logiref_integration_seguce.Refbfu_9')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();
                
                return $builder->getResult();
        }
        
        public function get_unvalidated_invoices($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Status_2 = '2' AND Account_3='".$account."'";
                
                #Filtre d'affichage
                if(isset($data['Reference_7']) && $data['Reference_7']!='') $st .= " AND Reference_7='".$data['Reference_7']."'";
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['Nif_10']) && $data['Nif_10']!='') $st .= " AND Nif_10='".$data['Nif_10']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_validated_invoices($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Status_2 >'2' AND Account_3='".$account."'";
                
                #Filtre d'affichage
                if(isset($data['Reference_7']) && $data['Reference_7']!='') $st .= " AND Reference_7='".$data['Reference_7']."'";
                if(isset($data['Refbfu_9']) && $data['Refbfu_9']!='') $st .= " AND Refbfu_9='".$data['Refbfu_9']."'";
                if(isset($data['Nif_10']) && $data['Nif_10']!='') $st .= " AND Nif_10='".$data['Nif_10']."'";

                if(isset($data['start']) && $data['start']!='') 
                {
                        $st .= " AND Datevaleur_13 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                }
                else
                {
                        $st .=" AND Datevaleur_13='".date("Y-m-d")."'";
                }
                
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_invoices_occ($data=Null)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];

                $st = "Status_2 ='1' AND Account_3='".$account."'";

                #Filtre d'affichage
                if(isset($data['Codeimport_12']) && $data['Codeimport_12']!='') $st .= " AND Codeimport_12='".$data['Codeimport_12']."'";
                if(isset($data['Numbordereau_14']) && $data['Numbordereau_14']!='') $st .= " AND Numbordereau_14='".$data['Numbordereau_14']."'";

                if(isset($data['start']) && $data['start']!='')
                {
                        $end = date('Y-m-d', strtotime($data['end']. ' +1 days'));

                        $st .= " AND Date_1 BETWEEN '".$data['start']."' AND '".$end."' ";
                }

                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->limit('500')
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoices_occ_by_code_import($batchId, $code_import)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];

                $st = "Status_2 ='1' AND Account_3='".$account."' AND Codeimport_12='".$code_import."' AND BatchId_23='".$batchId."'";

                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->limit('5')
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoices_occ_by_licence($batchId, $licence)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];

                $st = "Status_2 ='1' AND Account_3='".$account."' AND Licence_8='".$licence."' AND BatchId_23='".$batchId."'";

                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->limit('5')
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoices_occ_by_batch_id($batchId)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];

                $st = "(Status_2 ='1' OR Status_2 ='6') AND Account_3='".$account."' AND BatchId_23='".$batchId."'";

                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->limit('5')
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoice_occ_by_regul_id($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Account_3='".$account."' AND Regulid_18 = ".$id." ";
                
                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.Id_0')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_invoice_occ_issues($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Status_2 ='1' AND Account_3='".$account."'";
                
                $builder = $this->db->table('logiref_integration_invoice_occ_issues')
                        ->select('logiref_integration_invoice_occ_issues .*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        public function get_report_invoice_occ_issues($data=NULL)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Status_2 ='5' AND Account_3='".$account."'";
                
                $builder = $this->db->table('logiref_integration_invoice_occ_issues')
                        ->select('logiref_integration_invoice_occ_issues .*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        public function get_invoices_occ_regularized($id)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "Regulid_18 = ".$id." ";
                
                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        public function get_invoices_occ_validated($batchId)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                
                $st = "(Status_2 ='3' OR Status_2 ='6') AND Account_3='".$account."' AND BatchId_23='".$batchId."'";
                $builder = $this->db->table('logiref_integration_invoice_occ')
                        ->select('logiref_integration_invoice_occ.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        public function get_invoice_occ_by_id($id)
        {
                if($id !=NULL)
                {
                        $this->set_table('logiref_integration_invoice_occ I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }  
        public function get_invoice_occ_by_clt($licence, $clt)
        {
                if($clt !=NULL && $licence != NULL)
                {
                        $this->set_table('logiref_integration_invoice_occ I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Licence_8' => $licence, 'Codeimport_12' => $clt), TRUE);
                }
        }
        public function get_invoice_occ_by_batchid($batchId)
        {
                if($batchId !=NULL)
                {
                        $this->set_table('logiref_integration_invoice_occ I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('BatchId_23' => $batchId), TRUE);
                }
        }
        public function get_invoice_batch_by_numbordereau($ref_bordereau)
        {
               if($ref_bordereau !=NULL)
                {
                        $this->set_table('logiref_integration_invoice_occ_batchs I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Reference_16' => $ref_bordereau), TRUE);
                }
        }
        public function get_invoice_batch_by_id($id)
        {
               if($id !=NULL)
                {
                        $this->set_table('logiref_integration_invoice_occ_batchs I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }      
        public function get_provision_by_license_aur($license)
        {
                $this->set_table('logiref_integration_provision_occ  I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Licence_7' => $license), TRUE);
        }
        
        public function get_provision_by_clt($clt)
        {

                $this->set_table('logiref_integration_provision_occ  I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Codeimport_19' => $clt), TRUE);
        }
        
        public function get_invoicess_occ_batchs($data=NULL)
        {
                $user = $this->session->userdata['user_id'];
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2 = 1 OR Status_2 = 2)";

                $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                        ->select('logiref_integration_invoice_occ_batchs.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_validated_invoices_occ_batch($data=NULL) 
        {
                $user = $this->session->userdata['user_id'];

                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = 3"; 

                $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                        ->select('logiref_integration_invoice_occ_batchs.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_invoicess_occ_batch_regul($data=NULL) 
        {
                $user = $this->session->userdata['user_id'];
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2 = 4 OR Status_2 = 3) ";

                $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                        ->select('logiref_integration_invoice_occ_batchs.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_nvalidated_invoicess_occ_batchs($data=NULL)
        {
                $user = $this->session->userdata['user_id'];
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Status_2 = 1 ";
                $builder = $this->db->table('logiref_integration_invoice_occ_batchs')
                        ->select('logiref_integration_invoice_occ_batchs.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 1 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_batchs($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 !=0 AND Montant_10 > 0 AND Priority_27 = 1";

                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_by_batchid($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 1 AND Montant_10 > 0";

                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_by_clt($id, $clt) 
        {
                $st = " Paiementid_4 ='" . $id . "' AND Codeimport_28 ='" . $clt . "' AND Status_2 = 1 AND Montant_10 > 0";
                
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_by_batchid_validated($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 2 AND Montant_10 > 0";

                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_partial_invoices_occ($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 1 AND Montant_10 > 0 AND Priority_27 = 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_integrated($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2=2 AND Montant_10 > 0";

                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_regul_manual($id)
        {
                $st = " Paiementid_4 ='" . $id . "'  AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_regularized($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2<>0 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ_regul')
                        ->select('logiref_cbs_instructions_invoice_occ_regul.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ_regul.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_issues($licence_key)
        {
                $st = " Licencekey_27 ='" . $licence_key . "' AND Status_2 <> 0 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ_issues')
                        ->select('logiref_cbs_instructions_invoice_occ_issues.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ_issues.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_not_integrated($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 3 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_part_occ($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 = 2 AND Type_26 ='CPO' AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_frais_occ_bivac_not_integrated($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 != 2 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->select('logiref_cbs_instructions_invoice_occ.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_invoices_occ_regul($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 AND Montant_10 > 0";
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ_regul')
                        ->select('logiref_cbs_instructions_invoice_occ_regul.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_invoice_occ_regul.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }

        public function get_instructions_info_extourne_invoice_occ($id)
        {
                $this->set_table('logiref_cbs_instructions_invoice_occ  I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Paiementid_4' => $id, 'Status_2' => '2', 'Type_26' => 'EXT', 'Priority_27' => '1'), TRUE);
        }

        public function get_invoice_by_id($id)
        {
               if($id !=NULL)
                {
                        $this->set_table('logiref_integration_seguce I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_instructions_invoice($id)
        {
                $st = " Paiementid_4 ='" . $id . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_seguce.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_instructions_invoice_by_ref($ref) 
        {
                $st = " Reference_14 ='" . $ref . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_instructions_seguce')
                        ->select('logiref_cbs_instructions_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_instructions_seguce.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
        public function check_invoices()
        {
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                if(isset($_POST['Refbfu'])) $st .= " AND Refbfu_9 ='".$_POST['Refbfu']."'";
                if(isset($_POST['Ref']))   $st .= " AND Reference_7 ='".$_POST['Ref']."'";
                if(isset($_POST['Nif']))    $st .= " AND Nif_10 ='".$_POST['Nif']."'";
                
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }

        public function check_invoice()
        {
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";
                
                if(isset($_POST['invoice_id'])) $st .= " AND Reference_7 ='".$_POST['invoice_id']."'";
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_paid_invoices() 
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $account . "' AND (Status_2='3' OR Status_2='4') ";
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('logiref_integration_seguce.Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
         public function get_paid_invoices_filter() 
        {
                $account = $this->session->userdata['account_id'];
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND (Status_2='3' OR Status_2='4') ";
                
                #Filtre d'affichage
                
                if(isset($data['agence']) && $data['agence']!='') $st .= " AND Agence_14='".$data['agence']."'";
                if(isset($data['start']) && $data['start']!='') $st .= " AND Datevaleur_13 BETWEEN '".$data['start']."' AND '".$data['end']."' ";
                
                #Query
                $builder = $this->db->table('logiref_integration_seguce')
                        ->select('logiref_integration_seguce.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_instructions_invoice_occ_by_id($id)
        {
               if($id !=NULL)
                {
                        $this->set_table('logiref_cbs_instructions_invoice_occ I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_cbs_returns_provision($ref)
        {
                $this->set_table('logiref_cbs_returns_provision I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Reference_4' => $ref), TRUE);
        }

        public function get_cbs_returns_licence($ref)
        {
                $this->set_table('logiref_cbs_returns_licence I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Reference_4' => $ref), TRUE);
        }
       
        public function get_cbs_returns_invoices($ref) 
        {
                $st = " Paiementid_4 ='" . $ref . "' AND Status_2 <> 0 ";
                $builder = $this->db->table('logiref_cbs_returns_invoice')
                        ->select('logiref_cbs_returns_invoice.*')
                        ->where($st)
                        ->orderBy('logiref_cbs_returns_invoice.Id_0','ASC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
             
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_traitement($data, $id)
	{
		$this->set_table('logiref_seguce_traitements', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function update_traitement_by_lot($data, $ids) 
        {
                $builder = $this->db->table("logiref_seguce_traitements")
                        ->where("logiref_seguce_traitements.Lot_11 IN (".$ids.")")
                        ->update($data);
                return $builder;
        }
        
        public function save_invoice_occ($data, $id)
	{
		$this->set_table('logiref_integration_invoice_occ', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_invoice_occ_issues($data, $id)
	{
		$this->set_table('logiref_integration_invoice_occ_issues', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_invoice_occ_batchs($data, $id)
	{
		$this->set_table('logiref_integration_invoice_occ_batchs', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_provision($data, $id)
	{
		$this->set_table('logiref_integration_provision_occ', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}

        public function save_licence($data, $id)
	{
		$this->set_table('logiref_integration_licence', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_provision_batchs($data) 
        {
                $res = $this->db->insert_batch("logiref_integration_provision_occ", $data);
                
                if($res)
                {
                        return $this->db->insert_id();
                }
                else
                {
                        return FALSE;
                }
        }

        public function update_invoice_occ($data, $id)
        {
                $this->set_table('logiref_integration_invoice_occ', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
        }

        public function update_invoice_occ_issues($data, $id)
        {
                $this->set_table('logiref_integration_invoice_occ_issues', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
        }

        public function update_invoice_occ_batchs($data, $id)
        {
                $this->set_table('logiref_integration_invoice_occ_batchs', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
        }

        public function update_invoice($data, $ids)
        {
                $builder = $this->db->table("logiref_integration_seguce")
                        ->where("logiref_integration_seguce.Id_0 IN (".$ids.")")
                        ->update($data);
                return $builder;
        }

        public function update_instructions_partail_occ($data, $id)
        {
                $builder = $this->db->table("logiref_cbs_instructions_invoice_occ")
                        ->where("logiref_cbs_instructions_invoice_occ.Paiementid_4 ='".$id."' AND logiref_cbs_instructions_invoice_occ.Priority_27='0'")
                        ->update($data);
                return $builder;
        }

        public function update_instructions_frais_occ($data, $id)
        {
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->where("logiref_cbs_instructions_invoice_occ.Paiementid_4 ='".$id."' AND logiref_cbs_instructions_invoice_occ.Priority_27='1'")
                        ->update($data);
                return $builder;
        }

        public function update_instructions_fees($data, $id, $clt)
        {
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->where("logiref_cbs_instructions_invoice_occ.Paiementid_4 ='".$id."' AND logiref_cbs_instructions_invoice_occ.Priority_27='0' AND logiref_cbs_instructions_invoice_occ.Codeimport_28 ='".$clt."'")
                        ->update($data);
                return $builder;
        }

        public function update_instructions_occ($data, $id)
        {
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->where("logiref_cbs_instructions_invoice_occ.Paiementid_4 ='".$id."' AND logiref_cbs_instructions_invoice_occ.Priority_27='1'")
                        ->update($data);
                return $builder;
        }

        public function update_instructions_frais_boredereau_occ($data, $id, $type)
        {
                $builder = $this->db->table('logiref_cbs_instructions_invoice_occ')
                        ->where("logiref_cbs_instructions_invoice_occ.Paiementid_4 ='".$id."' AND logiref_cbs_instructions_invoice_occ.Montant_10 > 0 AND logiref_cbs_instructions_invoice_occ.Priority_27='1' AND logiref_cbs_instructions_invoice_occ.Type_26='".$type."'")
                        ->update($data);
                return $builder;
        }

        public function save_seguce_instructions($pid, $paiement, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                if(!empty($instructions))
                {
                        foreach($instructions as $instruction)
                        {
                                $data = array();
                                $data = $instruction;

                                $data['Id_0'] = '';
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']= $this->session->userdata['account_id'];
                                $data['Paiementid_4']= $pid;
                                $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD
                                $data['Agence_6']=$paiement['Agence_20'];
                                $data['Guichet_7']=$paiement['Guichet_21'];
                                $data['Mode_15']=$paiement['Mode_19'];
                                $data['Makerid_16']=$this->session->userdata['user_id'];
                                $data['Priority_24']=$priority;
                                if(!isset($data['Reference_14']))
                                {
                                        $data['Reference_14']=  $logirefid;
                                }
                                $this->set_table('logiref_cbs_instructions_seguce', 'Id_0', 'Id_0 DESC');
                                $this->saveData($data, NULL);
                        }
                }
                return TRUE;
        }

        public function save_instructions_provision($pid, $paiement, $instructions, $priority=NULL)
        {
                //Save instructions
                
                foreach($instructions as $instruction)
                {
                        $data = array();
                        $data = $instruction;
                        
                        //Variable d'integration

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Paiementid_4'] = $pid;
                        $data['Banqueid_5'] = $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6'] = $this->session->get('Logiref_agence');
                        $data['Guichet_7'] = $this->session->get('Logiref_guichet');
                        $data['Mode_15'] = 'OP';
                        $data['Makerid_16'] = $this->session->userdata['user_id'];
                        $data['Reference_14']=  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);
                        
                        $this->set_table('logiref_cbs_instructions_provision', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                
                return TRUE;
        }

        public function save_instructions_licence($lid, $paiement, $instructions, $priority=NULL)
        {
                foreach($instructions as $instruction)
                {
                        $data = array();
                        $data = $instruction;

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Paiementid_4'] = $lid;
                        $data['Banqueid_5'] = $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6'] = $this->session->get('Logiref_agence');
                        $data['Guichet_7'] = $this->session->get('Logiref_guichet');
                        $data['Mode_15'] = 'OP';
                        $data['Makerid_16'] = $this->session->userdata['user_id'];
                        $data['Reference_14']=  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999);

                        $this->set_table('logiref_cbs_instructions_licence', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }

                return TRUE;
        }

        public function save_instructions_invoice_occ($pid, $instructions, $logirefid=NULL, $priority=NULL, $clt=NULL)
        {
                //Save instructions
                foreach($instructions as $instruction)
                {
                        $data = array();
                        $data = $instruction;
                        //Variable d'integration

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6'] = $this->session->get('Logiref_agence');
                        $data['Guichet_7'] = $this->session->get('Logiref_guichet');
                        $data['Mode_15']= 'OP';
                        $data['Makerid_16']=$this->session->userdata['user_id'];
                        $data['Reference_14']=  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999); 
                        $data['Priority_27']= $priority;
                        $data['Codeimport_28']= $clt;

                        $this->set_table('logiref_cbs_instructions_invoice_occ', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                return TRUE;
        }

        public function save_instructions_invoice_occ_issues($pid, $instructions, $logirefid=NULL, $licencekey=NULL)
        {
                //Save instructions
                foreach($instructions as $instruction)
                {
                        $data = array();
                        $data = $instruction;
                        //Variable d'integration
                        
                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2'] = 1;
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Paiementid_4'] = $pid;
                        $data['Banqueid_5'] = $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6'] = $this->session->get('Logiref_agence');
                        $data['Guichet_7'] = $this->session->get('Logiref_guichet');
                        $data['Mode_15']= 'OP';
                        $data['Makerid_16']= $this->session->userdata['user_id'];
                        $data['Reference_14']=  mt_rand(1, 99).date('H').date('i').date('s').date('j').date('m').date('y').mt_rand(100, 999); 
                        $data['Licencekey_27']= $licencekey; 
                        $this->set_table('logiref_cbs_instructions_invoice_occ_issues', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                return TRUE;
        }
        public function save_instructions_invoice_occ_regul($pid, $instructions, $logirefid=NULL, $priority=NULL)
        {
                //Save instructions
                foreach($instructions as $instruction)
                {
                        $data = array();
                        $data = $instruction;
                        //Variable d'integration

                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']= $this->session->userdata['account_id'];
                        $data['Paiementid_4']= $pid;
                        $data['Banqueid_5']= $this->session->userdata['account_id']; //TBD 
                        $data['Agence_6']= $this->session->get('Logiref_agence');
                        $data['Guichet_7']= $this->session->get('Logiref_guichet');
                        $data['Mode_15']= 'OP';
                        $data['Makerid_16']= $this->session->userdata['user_id'];
                        $data['Reference_14']=  $logirefid; 
                        $this->set_table('logiref_cbs_instructions_invoice_occ_regul', 'Id_0', 'Id_0 DESC');
                        $this->saveData($data, NULL);
                }
                return TRUE;
        }
        public function save_invoicefees($data, $id)
	{
		$this->set_table('logiref_invoice_fees', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}

        public function update_provisions($data, $license) {
                $builder = $this->db->table('logiref_integration_provision_occ')
                        ->where("logiref_integration_provision_occ.Licence_7 ='".$license."'")
                        ->update($data);
                return $builder;
        }

        public function update_licence($data, $license) {
                $builder = $this->db->table('logiref_integration_licence')
                        ->where("logiref_integration_licence.Licence_7 ='".$license."'")
                        ->update($data);
                return $builder;
        }

        public function delete_instructions_provision($id)
	{
                $builder = $this->db->table('logiref_cbs_instructions_provision')
                        ->where("Paiementid_4 ='".$id."'")
                        ->delete();
		return $builder;
	}

        public function delete_instructions_licence($id)
	{
                $builder = $this->db->table('logiref_cbs_instructions_licence')
                        ->where("Paiementid_4 ='".$id."'")
                        ->delete();
		return $builder;
	}

        public function transform_invoice_data($data,$account=null)
        {
                $invoice_data=array();
                if(!empty($data))
                {
                        $results=json_encode($data);

                        $invoice_data = new stdClass();
                        $invoice_data->Date_1          = date('Y-m-d H:i:s');
                        $invoice_data->Status_2        = 1;
                        $invoice_data->Account_3       = !empty($account) ? $account : '';
                        $invoice_data->Bank_4          = $data['BankActorCode'] ?? '';
                        $invoice_data->Factureid_5     = $data['ID'] ?? '';
                        $invoice_data->Result_6        = $results;
                        $invoice_data->Reference_7     = $data['InternalReference'] ?? '';
                        $invoice_data->Description_8     = 'Guichet Unique Intégral - GUICE';
                        $invoice_data->Refbfu_9     = '';
                        $invoice_data->Nif_10      = '';
                        $invoice_data->Montant_11      = $data['NetAmount'] ?? '';
                        $invoice_data->Devise_12       = $data['Currency'] ?? '';
                        $invoice_data->Datevaleur_13       = date("Y-m-d");
                        $invoice_data->Agence_14       ='' ;
                        $invoice_data->Debiteur_25     = $data['DebtorActorName'] ?? '';
                        $invoice_data->Creditaire_26   = $data['CreditorActorName'] ?? '';
                        $invoice_data->Clientcode_45   = $data['ClientCode'] ?? '';
                        $invoice_data->Contracttype_46 = $data['ContractType'] ?? '';
                }
                return $invoice_data;
        }

}