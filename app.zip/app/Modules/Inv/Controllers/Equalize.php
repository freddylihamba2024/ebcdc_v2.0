<?php

namespace Modules\Inv\Controllers;

/** Compatibility entry point: the plate workflow is implemented by the Branch module. */
class Equalize extends \Modules\Branch\Controllers\TaxEqualize
{
}
