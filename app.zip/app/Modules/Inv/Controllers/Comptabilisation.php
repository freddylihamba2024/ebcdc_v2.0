<?php

namespace Modules\Inv\Controllers;

/** Compatibility entry point: the plate workflow is implemented by the Branch module. */
class Comptabilisation extends \Modules\Branch\Controllers\TaxComptabilisation
{
}
