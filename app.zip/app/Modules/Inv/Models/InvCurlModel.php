<?php

        namespace Modules\Inv\Models;

        use App\Controllers\BaseController;
        use Modules\Main\Models\MainModel;
        use App\Libraries\Authorization_Token;

        class InvCurlModel extends BaseController
        {
                private $authorization_token;
                private $baseURL;
                public $mainModel;

                public function __construct()
                {
                        parent::__construct();

                        $this->baseURL = base_url();
                        $this->mainModel = new MainModel();
                        $this->authorization_token = new Authorization_Token();
                }

                private function generateTokenFromSession()
                {
                        if (empty($_SESSION['userdata'])) {
                                return null;
                        }

                        return $this->authorization_token->generateToken([
                                'user_id'       => $_SESSION['userdata']['user_id'],
                                'account_id'    => $_SESSION['userdata']['account_id'],
                                'username'      => $_SESSION['userdata']['user_fname'].' '.$_SESSION['userdata']['user_sname'].' '.$_SESSION['userdata']['user_nname'],
                                'email'         => $_SESSION['userdata']['user_email'],
                                'group'         => $_SESSION['Logiref_groupe'] ?? null,
                                'role'          => $_SESSION['Logiref_role'] ?? null,
                                'guichet_id'    => $_SESSION['Logiref_guichet'] ?? null,
                                'agence_id'     => $_SESSION['Logiref_agence'] ?? null,
                                'privileges'    => $_SESSION['Logiref_privileges'] ?? [],
                        ]);
                }

                private function getToken()
                {
                        if (!empty($_SESSION['api_token']) && !empty($_SESSION['api_token_time'])) {

                                $expire = 3600;

                                if ((time() - $_SESSION['api_token_time']) < $expire) {
                                        return $_SESSION['api_token'];
                                }
                        }

                        $token = $this->generateTokenFromSession();

                        if ($token) {
                                $_SESSION['api_token'] = $token;
                                $_SESSION['api_token_time'] = time();
                        }

                        return $token;
                }

                private function getHeaders(): array
                {
                        $token = $this->getToken();

                        return [
                                'Content-Type: application/json',
                                'Token: ' . $token
                        ];
                }

                public function confirmPayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/confirm-payment', 'POST', $data, $this->getHeaders());
                }

                public function deletePayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/delete-payment', 'POST', $data, $this->getHeaders());
                }

                public function getUnequalized()
                {
                        return $this->curl($this->baseURL . 'api/inv/unequalized','GET',[],$this->getHeaders());
                }

                public function regularisationDgiImmatriculation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/regularisation-dgi-immatriculation','GET',$data,$this->getHeaders());
                }

                public function getDetailsImmatriculation($id)
                {
                        return $this->curl($this->baseURL . 'api/inv/details-immatriculation/' . $id,'GET',[],$this->getHeaders());
                }

                public function regularizePaymentImmatriculation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/regularize-payment-immatriculation','POST',$data,$this->getHeaders());
                }

                public function validateImmatriculation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/validate-immatriculation','POST',$data,$this->getHeaders());
                }

                public function schemaImmatriculation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/schema-immatriculation','POST',$data,$this->getHeaders());
                }

                public function attestation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/attestation','POST',$data,$this->getHeaders());
                }

                public function mail($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/mail', 'POST',$data,$this->getHeaders());
                }

                public function integrationSFTP($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/integration-sftp','POST',$data, $this->getHeaders());
                }

                public function getNvalidatedImmatriculation()
                {
                        return $this->curl($this->baseURL . 'api/inv/nvalidated-immatriculation','GET',[],$this->getHeaders());
                }

                public function getValidatedImmatriculation()
                {
                        return $this->curl($this->baseURL . 'api/inv/validated-immatriculation','GET',[],$this->getHeaders());
                }

                public function saveCbsJournalisation($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/save-cbs-journalisation','POST', $data, $this->getHeaders());
                }

                public function savePayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/save-payment', 'POST',$data,$this->getHeaders());
                }

                public function treatmentPayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/treatment-payment','POST',$data,$this->getHeaders());
                }

                public function updatePayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/update-payment','POST',$data,$this->getHeaders());
                }

                public function validatePayment($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/validate-payment','POST',$data,$this->getHeaders());
                }

                public function verificationNote($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/verification-note','POST',$data,$this->getHeaders());
                }

                public function get_accountname($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/accountname','POST',$data,$this->getHeaders());
                }

                public function get_customeraccounts($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/customeraccounts','POST',$data,$this->getHeaders());
                }

                public function get_accountinternal($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/accountinternal', 'POST', $data, $this->getHeaders());
                }

                public function get_accountname_internal($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/accountname_internal', 'POST', $data, $this->getHeaders());
                }

                public function get_account_balance($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/account_balance', 'POST', $data, $this->getHeaders());
                }

                public function get_account_exemption($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/account_exemption', 'POST', $data, $this->getHeaders());
                }

                public function instructions_immatric($data)
                {
                        return $this->curl($this->baseURL . 'api/inv/instructions-immatriculation', 'POST', $data, $this->getHeaders());
                }

                /**
                 * @param array|string $result
                 */
                public function respondApiResult($result)
                {
                        if (is_string($result)) {
                                $result = json_decode($result, true);
                        }

                        if (!isset($result['code'])) {
                                return $this->response->setJSON([
                                        'code' => 500,
                                        'message' => 'Une erreur interne est survenue'
                                ]);
                        }

                        return $this->response->setJSON($result);
                }
        }