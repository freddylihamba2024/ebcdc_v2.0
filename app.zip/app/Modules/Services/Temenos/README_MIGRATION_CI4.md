# Analyse de migration Temenos vers CodeIgniter 4

Date : 2026-09-14  
Périmètre : `app/Modules/Services/Temenos` de `logiref-v4.2.0`  
Statut : **analyse uniquement — aucun contrôleur ou modèle modifié**

## 1. Compréhension du dépôt

Le dossier contient deux générations de logique :

- `Controllers/` et `Models/` : code PHP/CodeIgniter 4 actuellement chargé par
  l’application.
- `Archiv/` : ancienne implémentation métier provenant de la version CodeIgniter 3,
  avec les classes historiques (`classes/temenos.inc`, `flexcube.inc`) et les
  endpoints procéduraux sous `endpoints/bank/tmb`.

L’archive n’est donc pas un simple dossier de sauvegarde de fichiers CI4 : elle contient
à la fois le métier historique, les appels HTTP Temenos/Flexcube, les requêtes PDO
directes et des scripts autonomes. Elle doit servir de référence fonctionnelle, mais
ne doit pas être copiée telle quelle dans CodeIgniter 4.

## 1 bis. Première tranche appliquée

La première tranche de migration a été appliquée sans modifier `BaseController.php`
ni `Temenos/Crdbbank` :

- Les contrôleurs `Branch` et `Eximtrade` qui utilisent déjà
  `$this->{$core_banking}` déclarent maintenant explicitement `Temenos` et
  l’instancient comme leurs autres services CBS lorsque la session contient
  `account_cbs = temenos`.
- `Services/Temenos/Controllers/Temenos.php` n’utilise plus de réponse de compte
  simulée et accepte maintenant une réponse de modèle sous forme de tableau ou de
  JSON.
- `Services/Temenos/Models/TemenosModel.php` centralise les appels HTTP JSON avec
  délais, vérification TLS configurable et URL/autorisation externalisables.
- Les méthodes de mise à jour des paiements utilisent la connexion CI4 configurée,
  et les contrats manquants/incompatibles (`update_payment_tresor`, prépaiement,
  Sydonia) ont été rendus compatibles avec les appels existants.
- Les journaux acceptent désormais tableaux et objets sans conversion implicite PHP.
- Les fonctions historiques restantes qui utilisaient `$this->pdoMySQL->prepare()`
  (`save_cbs_return_*`, `update_*_return` et mises à jour des instructions RBO/DGDA)
  utilisent maintenant la connexion CI4 et `Query Builder`. Aucun accès PDO direct
  ne subsiste dans `TemenosModel.php`.

Les fichiers `Branch` et `Eximtrade` conservent leur appel générique
`$this->{$core_banking}` ; seul le branchement explicite du service `temenos` a
été ajouté afin de ne pas perturber les autres CBS.

Variables d’environnement prévues : `TEMENOS_TOKEN_URL`, `TEMENOS_TRANSFER_URL`,
`TEMENOS_ACCOUNT_INFO_URL`, `TEMENOS_REVERSAL_URL`, `TEMENOS_STATUS_URL`,
`TEMENOS_AUTHORIZATION` ou `TEMENOS_API_USER`/`TEMENOS_API_PASSWORD`,
`TEMENOS_TOKEN_BODY`, `TEMENOS_TIMEOUT`, `TEMENOS_CONNECT_TIMEOUT` et
`TEMENOS_SSL_VERIFY`. Les valeurs historiques ne doivent être conservées qu’en
compatibilité temporaire et les secrets doivent être placés dans `.env`.

## 2. Fichiers CI4 actuellement présents

### Contrôleurs

- `Controllers/Temenos.php` : façade principale ; compte, virement, réservation,
  annulation, vérification, provisions, factures, paie et orchestration CBS.
- `Controllers/TemenosBulletins.php` : traitements des bulletins DGDA simples,
  batches et prépaiements.
- `Controllers/TemenosRegularize.php` : régularisation, extourne et vérification
  d’une écriture.
- `Controllers/TemenosGateway.php` : flux paie séparé.
- `Controllers/14102025Temenos.php` et `24102025Temenos.php` : doublons historiques
  de la classe `Temenos` (même namespace et même nom de classe). Ils ne doivent pas
  rester des classes autoloadables actives en production : risque de collision et de
  confusion sur la version réellement chargée.

### Modèles

- `Models/TemenosModel.php` : appels HTTP, accès aux instructions/retours CBS,
  mises à jour de statuts et journaux.
- `Models/TemenosGatewayModel.php` : accès aux instructions de paie.

Tous les fichiers CI4 passent actuellement `php -l`, mais cela ne vérifie ni les
signatures d’appel, ni les contrats de retour, ni la connexion au CBS.

## 3. Logique métier de référence dans `Archiv`

### 3.1 `Archiv/classes/temenos.inc`

La classe historique contient notamment :

- token Temenos ;
- transfert interne ;
- consultation de compte ;
- extourne ;
- vérification d’événement ;
- récupération des instructions DGI, DGRAD, DGDA, prépaiements, provisions et
  factures ;
- sauvegarde et mise à jour des retours CBS ;
- mise à jour des statuts d’instructions ;
- gestion de token et journalisation.

Elle utilise une connexion PDO autonome vers la base d’intégration configurée dans
`Archiv/classes/config.temenos.php`. En CI4, cette connexion doit être remplacée par
un groupe de base de données configuré dans `app/Config/Database.php` ou par le modèle
CI4 approprié, sans conserver les identifiants en clair dans le code.

### 3.2 Endpoints historiques

Les scripts `Archiv/endpoints/bank/tmb` encapsulent les cas métier suivants :

| Endpoint historique | Responsabilité |
|---|---|
| `reservation.php` | réservation/débit initial et codes E200/E301… |
| `virement.php` | transfert des instructions existantes |
| `regularize.php` | régularisation après échec |
| `extourne.php` | extourne d’un transfert |
| `check.event.php` / `verification.php` | recherche d’un événement Temenos |
| `account.info.php` | informations et solde d’un compte |
| fichiers `*.invoice.occ.php`, `*.provision.php` | variantes facture/provision |
| répertoires `simulation/` et `tmp/` | réponses simulées, essais et scripts temporaires |

Les dossiers `simulation/`, `tmp/`, les sauvegardes `*_bkp*` et les archives `.tar/.zip`
ne doivent pas être exposés comme endpoints de production.

## 4. Écarts critiques constatés dans le code CI4

### 4.1 Réponses simulées encore actives

Dans `Controllers/Temenos.php` :

- `account_info()` construit une réponse fictive (`Active`, `iKwook Express`, `XAF`,
  solde `1000000`) au lieu d’appeler `TemenosModel::account_info()`.
- `TemenosRegularize::verify_event()` construit toujours un XREF fictif
  (`123456789`) et n’appelle pas le CBS ; le commentaire indique explicitement une
  simulation.

Ces deux points doivent être supprimés ou protégés par une configuration de test
explicite avant toute mise en production. Sinon une écriture peut être considérée
comme intégrée alors qu’elle ne l’est pas.

### 4.2 Contrats de retour incohérents

- `Temenos::account_info()` renvoie un tableau PHP en cas de succès, alors que
  `handle_cbs_instruction()` fait `json_decode($account_info, true)`. Le contrat doit
  être uniformisé : soit toujours un tableau, soit toujours une chaîne JSON, mais pas
  les deux.
- Plusieurs méthodes renvoient tantôt `response`, tantôt `code`, `message`, `msg` ou
  `meesage` (faute présente dans `virement`). Une normalisation est nécessaire avant
  que les contrôleurs Branch interprètent les réponses.
- `TemenosRegularize::regularize_payment_treatment()` suppose que `$result['response']`
  existe toujours. Les erreurs de validation doivent retourner une structure complète.

### 4.3 Signatures incompatibles ou méthodes absentes

Dans `Temenos.php` :

- `update_payment_prepayment($data_to_update_bl, $data['Sydonia_49'])` est appelé avec
  deux paramètres, alors que `TemenosModel::update_payment_prepayment()` n’en accepte
  qu’un.
- `update_payment_sydonia($data['Sydonia_44'])` est appelé avec un seul paramètre,
  alors que le modèle attend `(array $data, $id)`.
- `update_payment_tresor()` est appelé pour DGI/DGRAD, mais aucune méthode de ce nom
  n’est définie dans `TemenosModel.php` ni dans les classes `Archiv` analysées.
- Certaines branches utilisent `$data_to_update` sans initialisation locale.

Ces erreurs doivent être corrigées par un contrat métier unique, pas par des valeurs
par défaut silencieuses.

### 4.4 Génération et persistance des références

Dans `handle_cbs_instruction()`, la référence de l’instruction est d’abord lue puis
écrasée par `generate_unique_reference()`. Il faut décider quel identifiant est :

1. la référence Logiref de traçabilité ;
2. la référence `sourceRef` envoyée à Temenos ;
3. le numéro d’événement retourné par Temenos.

Les trois valeurs doivent être conservées séparément dans `Result_6`/les tables CBS,
sans écraser la référence métier d’origine.

### 4.5 Sécurité et configuration

Les fichiers actuels et l’archive contiennent des URLs, utilisateurs, mots de passe et
en-têtes Basic codés en dur. `Archiv/classes/config.temenos.php` contient également
des identifiants PDO en clair. Avant migration :

- révoquer/rotater les secrets exposés ;
- déplacer URLs, credentials, timeout et vérification TLS dans `.env`/configuration ;
- réactiver la vérification TLS en production ;
- ne jamais journaliser les tokens, mots de passe ou payloads contenant des données
  sensibles sans masquage.

## 5. Architecture CI4 recommandée

### Couche modèle/service

`TemenosModel` devrait être limité à :

- transport HTTP Temenos (client dédié ou `CURLRequest`) ;
- accès aux tables d’intégration via Query Builder/Model CI4 ;
- sauvegarde des retours et statuts ;
- journalisation masquée.

Les décisions métier (quelle table, quel statut, quelle instruction) doivent rester
dans des services applicatifs dédiés, pas dans des scripts d’endpoint ni dans les vues.

### Couche contrôleur/service métier

`Temenos` doit rester une façade compatible avec les appels existants de Branch, mais
chaque opération devrait déléguer à un service cohérent :

- `TransferService` ;
- `ReservationService` ;
- `RegularizationService` ;
- `BulletinService` ;
- `PayrollService`.

`TemenosBulletins` et `TemenosRegularize` peuvent rester des façades spécialisées,
mais leurs signatures et formats de réponse doivent être partagés.

### Connexion à la base

Remplacer progressivement les requêtes PDO historiques par le Query Builder CI4 :

```php
$builder = $this->db->table('logiref_cbs_instructions_dgrad');
$row = $builder->where('Id_0', (int) $id)->get()->getResultArray();
```

Les noms de tables et colonnes doivent être centralisés dans des méthodes privées ou
des repositories, avec paramètres liés et validation des identifiants de table par
liste blanche.

## 6. Plan de mise à jour proposé

### Phase 0 — sécurisation et référence

1. Sauvegarder les versions actuelles et confirmer l’environnement Temenos cible
   (UAT, préproduction ou production).
2. Rotater les secrets exposés et les déplacer vers `.env`.
3. Décider le contrat JSON commun : `code`, `response`, `message`, `msg`, `id`,
   `transaction_id`, `details`.
4. Décider les statuts d’instructions : succès, attente, erreur technique,
   régularisation et extourne.

### Phase 1 — modèle et transport

1. Remplacer les appels simulés `account_info` et `verify_event` par les vrais appels,
   derrière une option de simulation explicitement activée uniquement en test.
2. Créer un client HTTP Temenos avec timeout, TLS, journalisation masquée et gestion
   des erreurs réseau/JSON.
3. Aligner les signatures de `update_payment_*` et ajouter les méthodes réellement
   nécessaires pour DGI/DGRAD.
4. Ajouter des tests unitaires pour le parsing des réponses Temenos et les codes
   historiques E200/E300/E301…

### Phase 2 — orchestration métier

1. Port­er la logique des endpoints `reservation.php`, `virement.php`, `regularize.php`
   et `extourne.php` dans les services CI4, sans recopier les `echo`/`die` procéduraux.
2. Conserver les mises à jour atomiques des instructions et des retours CBS.
3. Garantir l’idempotence : une nouvelle tentative ne doit pas créer une écriture
   doublon si un retour Temenos existe déjà.
4. Tester séparément DGI, DGRAD, DGDA, prépaiement, provision, facture et paie.

### Phase 3 — intégration avec Branch

1. Vérifier les appels depuis `TaxNotes`, `TaxDeclaration`, `TaxBulletin`,
   `TaxEqualize` et les contrôleurs de reversement.
2. Vérifier que les mises à jour de statuts utilisent la bonne table et le bon
   identifiant (`Id_0`, `Paiementid_4`, `Sydonia_44`, `Sydonia_49`, etc.).
3. Ne pas modifier les flux agence/en ligne tant que les tests de non-régression ne
   sont pas concluants.

## 7. Tests d’acceptation obligatoires

- consultation de compte valide, compte inexistant, réponse vide et timeout ;
- transfert à une ou plusieurs instructions, devises identiques/différentes ;
- réponse Temenos succès sans `linkedActivities`, réponse métier en erreur et JSON
  invalide ;
- réservation déjà faite, réservation partielle et reprise idempotente ;
- régularisation, vérification réelle d’événement et extourne ;
- DGI et DGRAD avec retours CBS existants et inexistants ;
- DGDA bulletin simple, batch, prépaiement et archivage déjà existant ;
- aucun token/secret présent dans les logs ;
- compatibilité des formats attendus par les vues et contrôleurs Branch.

## 8. Décisions à approuver avant toute modification

1. Environnement Temenos cible et endpoints autorisés.
2. Stratégie de secrets et groupe de base de données CI4 pour les intégrations.
3. Contrat unique de réponse et stratégie de compatibilité avec les contrôleurs
   existants.
4. Liste des flux à migrer en premier : DGI/DGRAD, DGDA, prépaiements, paie,
   provisions et factures.
5. Activation ou suppression définitive des simulations présentes dans le code CI4.
6. Politique d’idempotence et de reprise après timeout.

## 9. Portage CI4 réalisé

Le modèle `Models/TemenosModel.php` contient désormais les méthodes de persistance
et de recherche qui manquaient par rapport à `Archiv/classes/temenos.inc` : retours
provision/facture/licence, recherches d’instructions, mises à jour de références,
mise à jour groupée des statuts et gestion du token. Ces accès utilisent le Query
Builder CI4 et conservent les noms de tables/colonnes historiques.

Les façades `close()`, `add_lien_account()`, `inquiry_lien_account()`,
`release_lien_account()` et `exchange_rate()` sont également disponibles dans le
contrôleur. Les quatre endpoints lien/taux restent volontairement à `406`, comme
dans l’Archiv, car aucun contrat fournisseur n’est défini.

Les vues Branch/Eximtrade n’ont pas été modifiées. Les appels métier spécifiques
qui ne figurent pas dans l’Archiv (par exemple certaines opérations bulletin ou
DGRK) restent à valider séparément avec le contrat Temenos correspondant.
