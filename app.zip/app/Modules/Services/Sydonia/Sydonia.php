<?php 
namespace Modules\Services\Sydonia\Controllers;

use App\Controllers\BaseController;
use Modules\Services\Sydonia\Models\SydoniaModel;

class Sydonia extends BaseController {
        
        public $sydoniaModel;
        
        public function __construct()
	{
		parent::__construct();
		
                $this->sydoniaModel = new SydoniaModel();
                $bank = $this->sydoniaModel->banks;
                $account = isset($this->session->userdata['account_id'])?$this->session->userdata['account_id']:"";
                $this->bank = $bank[$account];
                $this->account = $account;
	}
        
        
        public function checkbl($data)
        {
                $account = $data['Account'];
                ///* Variables initialisation
                // * From application
                $usersydonia = $data['login'];
                $password = $data['password'];
                $amountToBePaid = $data['Amount'];

                $year = $data['Year'];
                $assessmentSerial = $data['Series'];
                $assessmentNumber = $data['Number'];
                $paymentMean = '10'; 
                $declarantCode = $data['Agent'];
                $checkReference = ''; 
                $amount = $data['Amount'];
                $officeCode = $data['Office'];
                $companyCode = ($data['Nif'] == "A0700230J")? "" : $data['Nif'];
                $account = $data['Account'];
                $bank = $data['Bank'];
                $bankAgence = '';
                $guichet ='';
                $user = $data['User'];

                $integration = '';
                $deletion = '';
                $deletor  = '';
                $results  = '';
                $return = '';
                $error  = '0';

                $return_description = array();
                $error_description = '';

                $error_code = array(
                                        '11' => 'Montant &agrave; payer incorrect',
                                        '13' =>'La d&eacute;claration est introuvable',
                                        '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                        '21' => 'Office Code not found',
                                        '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                                        '18' => 'Code banque non trouv&eacute;',
                                        '15' => 'Nif non reconnu;',
                                        '37' => 'Le nif et le d&eclarant ne peuvent pas manquer simultanement.'
                                    );
                /* Variables initialisation
                 * Daclaration info
                 */

                $declarationsToBePaid = array();
                $declaration = new \stdClass();
                $declaration->amountToBePaid = $amountToBePaid;
                $declaration->registrationYear = $year;
                $declaration->registrationSerial = "";
                $declaration->registrationNumber = "";
                $declaration->assessmentSerial = $assessmentSerial;
                $declaration->assessmentNumber = $assessmentNumber;
                $declarationsToBePaid[] = $declaration;
                //Means of payment info
                $meansOfPayment = [];
                $meanOfPayment = new \stdClass();
                $meanOfPayment->meanOfPayment = $paymentMean;
                $meanOfPayment->bankCode = $bank;
                $meanOfPayment->checkReference = $checkReference;
                $meanOfPayment->amount = $amount;
                $meansOfPayment[] = $meanOfPayment;
                unset($meanOfPayment);
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;
                if($declarantCode != "") $paymentInfo->declarantCode = $declarantCode; 
                if($companyCode != "")$paymentInfo->companyCode = $companyCode;
                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;

                /* Logiref Middleware CALL
                 * Payment
                 */
                
               /*----------------------------------------------
                * Save request logs
                * ---------------------------------------------
                */
                
                $log_request = var_export($checkPayment, true);
                $filename = $bank."_request_checkbl";
                $this->sydoniaModel->save_log($log_request, $filename);
                
                $identifiants = array(

                            'login' =>$usersydonia,
                            'password' => $password
                        );

                $client = $this->sydoniaModel->init_ws("checkbl",$identifiants);
//              
                if($client == 'E404' || $client == 'E405'  ||  $client == 'E406' || $client=='WSDL')
                {
                        
                        $return = $client;
                       
                }
                else
                {
                        try 
                        {
                            
                                /*
                                * --------------------------------------------
                                * Call SODONIA checkPayment service  
                                * --------------------------------------------
                                */
                            
                                $checked = $client->checkPayment($checkPayment);

                                /*
                                 * --------------------------------------------
                                 * Save response logs
                                 * --------------------------------------------
                                 */

                                $log_response = var_export($checked, true);
                                $filename = $bank."_response_checkbl";
                                $this->sydoniaModel->save_log($log_response, $filename);
                                
                              
                        }
                        catch (SoapFault $ex) 
                        { 
                      
                                /*
                                 * --------------------------------------------
                                 * Save exception logs
                                 * --------------------------------------------
                                 */
                                $script_exception = var_export($ex, true);
                                $filename = $bank."_exception_checkbl";
                                $this->sydoniaModel->save_log($script_exception, $filename);
                                $return = $ex->faultcode;
                        }
                        catch (\Exception $ex)
                        {
                                $return=$ex->getMessage();
                        }                      
                        
                        if(isset($checked->checkDeclarationPaymentResult))
                        {
                                if(isset($checked->checkDeclarationPaymentResult->errorCode)) $error = $checked->checkDeclarationPaymentResult->errorCode;
                                if(isset($checked->checkDeclarationPaymentResult->errorDescription)) $error_description = $checked->checkDeclarationPaymentResult->errorDescription;
                                if(isset($checked->checkDeclarationPaymentResult->functionalError)) $error_description = $checked->checkDeclarationPaymentResult->functionalError;
                                if(isset($checked->checkDeclarationPaymentResult->result)) $rescode = $checked->checkDeclarationPaymentResult->result;
                                
                                # Successful attempt - must be saved in log files
                                if(isset($checked->checkDeclarationPaymentResult->result) && $rescode == "OK")
                                {
                                        $return =  $rescode;
                                } 
                                # The declaration was already paid  - must be saved in log files
                                elseif(isset($error_code[$error]) && $rescode == "E")
                                {
                                        $return = "E".$error;
                                }
                                # Unknown error - must be saved in log files
                                else
                                {    
                                        $return = "E003";
                                        $results = json_encode($checked->checkDeclarationPaymentResult);
                                        $integration = '';
                                        $printing = '';
                                        $pdf  = '';
                                        $reference ='';
                                        $status='';
                                        $rid = $this->sydoniaModel->save_paiement_errors($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode,$bank, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference);        
                                }
                        }
                        else
                        {
                            
                                $return="E000";
                                $error_description="Le bulletin n'est pas trouvé";
                        }

                       
                }
                
                if($return == 'WSDL')
                {

                        // Probleme de connexion ou problème disponibilité de SYDONIA
                        $return = 'E404';
                        $error_description="Problème de connexion ou problème de disponibilité de SYDONIA";
                }
                else if($return == 'Unauthorized')
                {
                        // Problème d'authorisation , mot de passe ou login incorrect
                        $return = 'E405';
                        $error_description="Problème d'authorisation , mot de passe ou login incorrect";
                }
                else
                {
                        // Autre exception à consulter dans le log fichier : _exception
                        $return = 'E406';
                        $error_description="Problème d'authorisation , mot de passe ou login incorrect";
                }
                $return_description['code'] = $return;
                $return_description['message'] = $error_description;

                return json_encode($return_description);
                       
        }
        
        public function checkbl_batch($data)
        {
                
                $usersydonia = $data['login'];
                $password = $data['password'];
                
                $officeCode = $data['Office'];
                $declarantCode = $data['Agent'];
                $companyCode = $data['Nif'];
                $designation = isset($data['designation'])? $data['designation'] : "TEST";
                $bankCode = $data['Bank'];
                $bankagence = $data['guichet'];
                $Amounts = $data['amounts'];
                $Years = $data['years'];
                $Series = $data['serials']; 
                $mode = $data['mode'];
                $user = $data['User'];
                
                if($mode == '7')  $paymentMean = '50'; else $paymentMean = '10';

                $amounts = 0;

                //$dateL = $data['DateL'];
                $ids = array();
                $error_code = array(
                                        '11' => 'Montant &agrave; payer incorrect',
                                        '4' => 'Empty office code',
                                        '13'=>'La d&eacute;claration est introuvable',
                                        '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                        '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                                        '21' => 'Code bureau non  trouv&eacute;',
                                        '18'=>'Code banque non trouv&eacute;',
                                        '15' => 'Code copagnie erron&eacute;'
                                    );
                
                
                /* Variables initialisation
                 * Daclaration info
                */
                $declarationsToBePaid = array();
                $meansOfPayment = [];

                for($i = 1; $i <= count($Series); $i++):

                    $Amount = str_replace(' ','',$Amounts[$i]);
                    $Amount = str_replace(',','.',$Amount);
                    $declaration = new \stdClass();
                    $declaration->amountToBePaid = $Amount;
                    $declaration->registrationYear = $Years[$i];
                    $declaration->registrationSerial = "";
                    $declaration->registrationNumber = "";
                    $declaration->assessmentSerial = substr($Series[$i],0,1);
                    $declaration->assessmentNumber = substr($Series[$i],1);
                    $declarationsToBePaid[] = $declaration;
                    
                    unset($declaration);
                    
                    $meanOfPayment = new \stdClass();
                    $meanOfPayment->meanOfPayment = $paymentMean;
                    $meanOfPayment->bankCode = $bankCode;
                    $meanOfPayment->checkReference = '';
                    $meanOfPayment->amount = $Amount;
                    $meansOfPayment[] = $meanOfPayment;

                    unset($meanOfPayment);
                    $amounts += $Amount;
                endfor;
                
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;
                if($declarantCode !="") $paymentInfo->declarantCode = $declarantCode;
                if($companyCode !=="A0700230J" && $companyCode !="")$paymentInfo->companyCode = $companyCode;
                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                $paymentInfo->paymentDate = date("d-m-Y");
                $paymentInfo->refund = false;

                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;
                
                
                $return_description = array();
                $error_description = '';
                /* Logiref Middleware CALL
                 * Payment
                 */
                
               /*----------------------------------------------
                * Save request logs
                * ---------------------------------------------
                */
                
                $log_request = var_export($checkPayment, true);
                $filename = $bankCode."_request_checkbl_batch";
                $this->sydoniaModel->save_log($log_request, $filename);
                
                if($usersydonia != "" && $password != "")
                {
                        $identifiants = array(
                            'login' =>$usersydonia,
                            'password' => $password
                        );

                        $client = $this->sydoniaModel->init_ws("checkbl", $identifiants);

                        if($client == "E404"):

                            $return = $client;

                        else:

                            try
                            {
                            
                                   /*
                                    * -----------------------------------------------------
                                    * Save request log
                                    * -----------------------------------------------------
                                    */

                                   $log_request = var_export($checkPayment, true);
                                   $filename = $bankCode."_request_checkbl_batch";
                                   $this->sydoniaModel->save_log($log_request, $filename);


                                   /*
                                    * -----------------------------------------------------
                                    * Make paiement confirmation in SYDONIA
                                    * -----------------------------------------------------
                                    */
                                   
                                   $checked = $client->checkPayment($checkPayment);
                                   
                                   /*
                                    * -----------------------------------------------------
                                    * Save reponse logs
                                    * -----------------------------------------------------
                                    */

                                   $log_response = var_export($checked, true);
                                   $filename = $bankCode."_response_checkbl_batch";
                                   $this->sydoniaModel->save_log($log_response, $filename);

                            } 
                            catch (SoapFault $ex) 
                            {
                                   /*
                                    * ------------------------------------------------------
                                    * Save Exception logs
                                    * ------------------------------------------------------
                                    */

                                    $script_exception = var_export($ex, true);
                                    $filename = $bankCode."_exception_checkbl_batch";
                                    $this->sydoniaModel->save_log($script_exception, $filename);
                                    $return = $ex->faultcode;

                            }
                            catch (\Exception $ex)
                            {
                                    $return=$ex->getMessage();
                            }   

                            if(isset($checked->checkDeclarationPaymentResult))
                            {

                                    if(isset($checked->checkDeclarationPaymentResult->errorCode)) $error = $checked->checkDeclarationPaymentResult->errorCode;
                                    if(isset($checked->checkDeclarationPaymentResult->result)) $rescode = $checked->checkDeclarationPaymentResult->result;
                                    if(isset($checked->checkDeclarationPaymentResult->errorDescription)) $error_description = $checked->checkDeclarationPaymentResult->errorDescription;
                                    if(isset($checked->checkDeclarationPaymentResult->functionalError)) $error_description = $checked->checkDeclarationPaymentResult->functionalError;

                                    if(isset($checked->checkDeclarationPaymentResult->result) && $rescode == "OK"):

                                        $return =  $rescode;

                                    elseif(isset($error_code[$error]) && $rescode == "E"):

                                            $return = "E".$error;

                                    else:
                                            $return = "E003";
                                            $results = json_encode($checked->checkDeclarationPaymentResult);
                                            $integration =date("Y-m-d");
                                            $printing = date("Y-m-d");
                                            $pdf  = '';
                                            $year='';
                                            $amount = $amounts;
                                            $assessmentNumber = '';
                                            $assessmentSerial='';
                                            $rid = $this->sydoniaModel->save_paiement_errors($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode,$bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf);        
                                    endif;
                            }
                            else
                            {
                                
                                    if($return == 'WSDL')
                                    {
                                            // Probleme de connexion ou problème disponibilité de SYDONIA
                                            $return = 'E444';
                                    }
                                    else if($return == 'HTTP')
                                    {
                                            // Problème d'authorisation , mot de passe ou login incorrect
                                            $return = 'E405';
                                    }
                                    else
                                    {
                                            // Autre exception à consulter dans le log fichier : _exception
                                            $return = 'E406';
                                    }
                            }

                        endif;
                }
                else
                {
                        $return  = "E000";
                }
                
                if($return == 'WSDL')
                {

                        // Probleme de connexion ou problème disponibilité de SYDONIA
                        $return = 'E404';
                        $error_description="Problème de connexion ou problème de disponibilité de SYDONIA";
                }
                else if($return == 'Unauthorized')
                {
                        // Problème d'authorisation , mot de passe ou login incorrect
                        $return = 'E405';
                        $error_description="Problème d'authorisation , mot de passe ou login incorrect";
                }
                else
                {
                        // Autre exception à consulter dans le log fichier : _exception
                        $return = 'E406';
                        $error_description="Problème d'authorisation , mot de passe ou login incorrect";
                }
                $return_description['code'] = $return;
                $return_description['message'] = $error_description;

                return json_encode($return_description);
        }
        
        
        public function comptant($data)
        {
                $usersydonia = $data['login'];
                $password = $data['password'];
                $amountToBePaid = $data['Amount'];
                $year = $data['Year'];
                $assessmentSerial = $data['Series'];
                $assessmentNumber = $data['Number']; 
                $declarantCode = $data['Agent'];
                $checkReference = $data['ReferenceOp']; 
                $amount = $data['Amount'];
                $officeCode = $data['Office'];
                $companyCode = $data['Nif'];
                $account = $data['Account'];
                $dateL = $data['DateL'];
                $bank = $data['Bank'];
                $user = $data['User'];

                $designation = $data['designation'];
                $compte_guichet_unique = $data['Compte_guichet'];
                $commission = $data['Commission'];
                $devise_commission = $data['Devise_commission'];
                $total_amount = $data['Total_amount'];
                $mode = $data['Mode'];
                if($mode == '7' || $mode == '8')  $paymentMean = '50'; else $paymentMean = '10';
                $taux = isset($data['Taux']) ? $data['Taux'] : "";
                $agence = isset($data['Agence']) ? $data['Agence'] : "";
                $compte_client = isset($data['bank_account']) ? $data['bank_account'] : "";
                $devise_compte_client = isset($data['Devise_account']) ? $data['Devise_account'] : "";
                $account_name = $data['account_name'];

                $paiementid = isset($data['Paiementid'])? $data['Paiementid'] :"";
                $guichet ='';
                $bankAgence = '';

                $taxesgroup = ''; 
                $integration = '';
                $deletion = '';
                $deletor  = '';
                $results  = '';
                $error  = '0';
                $lot = (isset($data['lot']))?$data['lot']:'';

                $return_description = array();
                $error_description = '';

                $error_code = array(
                                       '11' => 'Montant &agrave; payer incorrect',
                                       '13'=>'La d&eacute;claration est introuvable',
                                       '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                       '22' => 'Aucun bulletin de liquidation  trouv&eacute;'
                                   );

                /* Variables initialisation
                * Daclaration info
                */
                $declarationsToBePaid = array();
                $declaration = new \stdClass();
                $declaration->amountToBePaid = $amountToBePaid;
                $declaration->registrationYear = $year;
                $declaration->registrationSerial = "";
                $declaration->registrationNumber = "";
                $declaration->assessmentSerial = $assessmentSerial;
                $declaration->assessmentNumber = $assessmentNumber;
                $declarationsToBePaid[] = $declaration;
                //Means of payment info
                $meansOfPayment = [];
                $meanOfPayment = new \stdClass();
                $meanOfPayment->meanOfPayment = $paymentMean;
                $meanOfPayment->bankCode = $bank;
                $meanOfPayment->checkReference = $checkReference;
                $meanOfPayment->amount = $amount;
                $meansOfPayment[] = $meanOfPayment;
                unset($meanOfPayment);
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;
                if($declarantCode !="") $paymentInfo->declarantCode = $declarantCode;
                if($companyCode !=="A0700230J" && $companyCode !="")$paymentInfo->companyCode = $companyCode;
                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                $paymentInfo->paymentDate = date("d-m-Y");
                $paymentInfo->refund = false;
                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;
               /* Webservice CALL
                * Payment
                */

               /*
                * -----------------------------------------------------
                * Save request log
                * -----------------------------------------------------
                */

                $log_request = var_export($checkPayment, true);
                $filename = $bank."_request_comptant";
                $this->sydoniaModel->save_log($log_request, $filename);


                /*
                * --------------------------------------------
                * Call SYDONIA declarationPayment service  
                * --------------------------------------------
                */
                
                $identifiants = array(
            
                            'login' =>$usersydonia,
                            'password' => $password
                        );
                
                //$client = $this->sydoniaModel->init_ws("comptant", $identifiants);
                $client = '4444';

                
                if($client == 'E404')
                {
                        $return = $client;
                }
                else
                {
                        try
                        {
                                /*
                                 * -----------------------------------------------------
                                 * Make paiement confirmation in SYDONIA
                                 * -----------------------------------------------------
                                 */
                                
                                $return = new \stdClass();
            
                                $return->declarationPaymentResult = new \stdClass();
                                $return->declarationPaymentResult->result = 'OK';
                                $return->declarationPaymentResult->errorCode = '0';
                                $return->declarationPaymentResult->errorDescription = 'Payment executed successfully';
                                $return->declarationPaymentResult->receiptSerial = 'Q';
                                $return->declarationPaymentResult->receiptNumber = '303';
                                $return->declarationPaymentResult->receiptDate = '15/09/2021';
                                $return->declarationPaymentResult->totalAmount = '30402464';

                                $return->declarationPaymentResult->declarationsPaid= array();

                                $return->declarationPaymentResult->declarationsPaid= new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->registrationYear = '2021';
                                $return->declarationPaymentResult->declarationsPaid->registrationSerial = '';
                                $return->declarationPaymentResult->declarationsPaid->registrationNumber = '0';
                                $return->declarationPaymentResult->declarationsPaid->assessmentSerial = 'L';
                                $return->declarationPaymentResult->declarationsPaid->assessmentNumber = '876';
                                $return->declarationPaymentResult->declarationsPaid->amountToBePaid = '546700';

                                $i = 0;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid = array();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'RET';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '76900';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Retribution DGDA/Partenaires';

                                $i = 1;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'RAN';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '9700';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Retenue ANAPI 4% de 5%TPI';

                                $i = 2;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'TPI';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '3240';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Taxe Promotion de l\'Industrie';

                                $i = 3;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'AT1';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'DGRAD Fonds Propres 17.5% des AT';

                                $i = 4;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'TVA';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '67900';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'DGDA Fonds Propres 7.5% des AT';

                                $i = 5;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'DDI';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '546900';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Droit de Douanes à l\'Import';
                                
                                $i = 6;

                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'CSO';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '98706';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Comité de Suivi OGEFREM DGDA';
                                
                                $i = 7;
                                
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'AT4';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '867900';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Commerce Extérieur 10% des AT';
                                
                                $i = 8;
                                
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeCode = 'AT2';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeAmount = '65690';
                                $return->declarationPaymentResult->declarationsPaid->taxesPaid[$i]->taxeDescription = 'Commerce Extérieur 10% des AT';

                                $checked = $return;
                               
                                //$checked = $client->declarationPayment($checkPayment);
                                
                                /*
                                 * -----------------------------------------------------
                                 * Save reponse logs
                                 * -----------------------------------------------------
                                 */

                                $log_response = var_export($checked, true);
                                $filename = $bank."_response";
                                $this->sydoniaModel->save_log($log_response, $filename);

                        }
                        catch (SoapFault $ex)
                        {
                               /*
                                * ------------------------------------------------------
                                * Save Exception logs
                                * ------------------------------------------------------
                                */

                                $script_exception = var_export($ex, true);
                                $filename = $bank."_exception";
                                $this->sydoniaModel->save_log($script_exception, $filename);
                                $return = $ex->faultcode;
                        }
                        if(isset($checked->declarationPaymentResult))
                        {
                                if(isset($checked->declarationPaymentResult->errorCode)) $error = $checked->declarationPaymentResult->errorCode;
                                if(isset($checked->declarationPaymentResult->errorDescription)) $error_description = $checked->declarationPaymentResult->errorDescription;
                                if(isset($checked->declarationPaymentResult->functionalError)) $error_description = $checked->declarationPaymentResult->functionalError;
                                if(isset($checked->declarationPaymentResult->result)) $rescode = $checked->declarationPaymentResult->result;
                                
                                # Successful attempt - must be saved in log files
                                if(isset($checked->declarationPaymentResult->result) && $rescode == "OK")
                                {
                                        $checked->declarationPaymentResult->DateLi = $dateL;
                                        $results = json_encode($checked->declarationPaymentResult);
                                        $integration = date("Y-m-d h:s");
                                        $printing = date("Y-m-d h:s");
                                        $pdf  = '';
                                        $error  = '0';
                                        $reference = '';
                                        $Bl_24 = '';
                                        $Moyen = $paymentMean;
                                        $Quittance ='';
                                        $Beneficiare ='DGDA';
                                        $Type = '';
                                        $date_array = explode("/",$checked->declarationPaymentResult->receiptDate);

                                        $Receiptid = $date_array[2].' '.$checked->declarationPaymentResult->receiptSerial.' '.$checked->declarationPaymentResult->receiptNumber;
                                        $Paymentid = '';
                                        $Receiptdate = json_encode($date_array);

                                        unset($client);
                                        
                                        # Data construction
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $account;
                                        $data['Type_4'] = $paymentMean;
                                        $data['Year_5'] = $year;
                                        $data['Office_6'] = $officeCode;
                                        $data['Serie_7'] = $assessmentSerial;
                                        $data['Number_8'] = $assessmentNumber;
                                        $data['Nif_9'] = $companyCode;
                                        $data['Agent_10'] = $declarantCode;
                                        $data['Bank_11'] = $bank;
                                        $data['Amount_12'] = $amount;
                                        $data['Results_13'] = $results;
                                        $data['Error_14'] = $error;
                                        $data['User_15'] = $user;
                                        $data['Integration_16'] = $integration;
                                        $data['Printing_17'] = $printing;
                                        $data['Pdfcontent_18'] = $pdf;
                                        $data['Reference_19'] = $reference;
                                        $data['Lot_22'] = $lot;
                                        $data['Account_24'] = $compte_guichet_unique;
                                        $data['Amount_25'] = $total_amount;
                                        $data['Commission_26'] = $commission;
                                        $data['Devise_27'] = $devise_commission;
                                        $data['Account_28'] = $compte_client;
                                        $data['Devise_29'] = $devise_compte_client;
                                        $data['Mode_30'] = $mode;
                                        $data['Taux_31'] = $taux;
                                        $data['Designation_23'] = $designation;
                                        $data['Agence_32'] = $agence;
                                        $data['Accountholder_33'] = $account_name;
                                        
                                        $rid = $this->sydoniaModel->update_paiement($data, $paiementid); 

                                        if($rid == true) $rid = $paiementid;

                                        if($rid == 0 || $rid==FALSE)
                                        {
                                                $return = "E002"; 
                                        }
                                        else 
                                        {
                                                $return = $rid;
                                        }
                                } 
                                # The declaration was already paid  - must be saved in log files
                                elseif(isset($error_code[$error]) && $rescode == "E")
                                {
                                        $return = "E".$error;
                                        $results = json_encode($checked->declarationPaymentResult);
                                        #$reference = $checked->declarationPaymentResult->assessmentSerial.''.$checked->declarationPaymentResult->assessmentNumber;
                                        $integration = '';
                                        $printing = date("Y-m-d");
                                        $pdf  = '';
                                        
                                        # Data construction
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $account;
                                        $data['Type_4'] = $paymentMean;
                                        $data['Year_5'] = $year;
                                        $data['Office_6'] = $officeCode;
                                        $data['Serie_7'] = $assessmentSerial;
                                        $data['Number_8'] = $assessmentNumber;
                                        $data['Nif_9'] = $companyCode;
                                        $data['Agent_10'] = $declarantCode;
                                        $data['Bank_11'] = $bank;
                                        $data['Amount_12'] = $amount;
                                        $data['Results_13'] = $results;
                                        $data['Error_14'] = $error;
                                        $data['User_15'] = $user;
                                        $data['Integration_16'] = $integration;
                                        $data['Printing_17'] = $printing;
                                        $data['Pdfcontent_18'] = $pdf;
                                        
                                        $rid = $this->sydoniaModel->save_paiement_errors($data, NULL);
                                }
                                # Unknown error - must be saved in log files
                                else
                                {    
                                        $return = "E003";
                                        $results = json_encode($checked->declarationPaymentResult);
                                        $integration = '';
                                        $printing = '';
                                        $pdf  = '';
                                        
                                        # Data construction
                                        $data = array();
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $account;
                                        $data['Type_4'] = $paymentMean;
                                        $data['Year_5'] = $year;
                                        $data['Office_6'] = $officeCode;
                                        $data['Serie_7'] = $assessmentSerial;
                                        $data['Number_8'] = $assessmentNumber;
                                        $data['Nif_9'] = $companyCode;
                                        $data['Agent_10'] = $declarantCode;
                                        $data['Bank_11'] = $bank;
                                        $data['Amount_12'] = $amount;
                                        $data['Results_13'] = $results;
                                        $data['Error_14'] = $error;
                                        $data['User_15'] = $user;
                                        $data['Integration_16'] = $integration;
                                        $data['Printing_17'] = $printing;
                                        $data['Pdfcontent_18'] = $pdf;
                                        
                                        $rid = $this->sydoniaModel->save_paiement_errors($data, NULL);
                                }
                        }
                        else
                        {
                                if($return == 'WSDL')
                                {
                                        // Probleme de connexion ou problème disponibilité de SYDONIA
                                        $return = 'E444';
                                }
                                else if($return == 'HTTP')
                                {
                                        // Problème d'authorisation , mot de passe ou login incorrect
                                        $return = 'E405';
                                }
                                else
                                {
                                        // Autre exception à consulter dans le log fichier : _exception
                                        $return = 'E406';
                                }
                        }
                        
                }
				
                if($rescode == "OK")
                {
                        $return_description['id'] = $return;
                        $return_description['code'] = $rescode;
                        $return_description['message'] = $error_description;
                }
                else
                {
                        $return_description['id'] = "";
                        $return_description['code'] = $return;
                        $return_description['message'] = $error_description;
                }

                return json_encode($return_description);
        }
        public function comptant_batch($data)
        {
                $account = $data['Account'];
                $usersydonia = $data['login'];
                $password = $data['password'];
                $lot = $checkReference = $data['refOp'];
                $Logirefid = $data['logirefid'];
                $officeCode = $data['Office'];
                $declarantCode = $data['Agent'];
                $companyCode = $data['Nif'];
                $designation = $data['designation'];
                $bankCode = $data['Bank'];
                $bankagence = $data['guichet'];
                
                $Amounts = $data['amounts'];
                $Years = $data['years'];
                $Series = $data['serials']; 
                $cCompte = (isset($data['account']))? $data['account']:'';
                $cDevise = (isset($data['cdevise']))? $data['cdevise']:'';
                
                $mode = $data['mode'];
                $user = $data['User'];
                if($mode == '7')  $paymentMean = '50'; else $paymentMean = '10';
                $amounts = 0;
                $taux = $data['taux'];
                $coms = $data['Commission'];
                
                $cGuichet = $data['cGuichet'];
                
                $totals = $data['amounts'];
                
                $devise_commision = $data['devise_commision'];
                $frais_bcc = isset($data['frais_bcc']) ? $data['frais_bcc']: '0';
                $account_name = $data['account_name'];
                
                //$dateL = $data['DateL'];
                $ids = array();
                $error_code = array(
                                        '11' => 'Montant &agrave; payer incorrect',
                                        '4' => 'Empty office code',
                                        '13'=>'La d&eacute;claration est introuvable',
                                        '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                        '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                                        '21' => 'Code bureau non  trouv&eacute;',
                                        '18'=>'Code banque non trouv&eacute;',
                                        '15' => 'Code copagnie erron&eacute;'
                                    );

                /* Variables initialisation
                 * Daclaration info
                */
                $declarationsToBePaid = array();
                $meansOfPayment = [];
                
                for($i = 1; $i <= count($Series); $i++):

                    $Amount = str_replace(' ','',$Amounts[$i]);
                    $Amount = str_replace(',','.',$Amount);
                    $declaration = new \stdClass();
                    $declaration->amountToBePaid = intval($Amount);
                    $declaration->registrationYear = $Years[$i];
                    $declaration->registrationSerial = "";
                    $declaration->registrationNumber = "";
                    $declaration->assessmentSerial = substr($Series[$i],0,1);
                    $declaration->assessmentNumber = substr($Series[$i],1);
                    $declarationsToBePaid[] = $declaration;
                    unset($declaration);

                    $meanOfPayment = new \stdClass();
                    $meanOfPayment->meanOfPayment = $paymentMean;
                    $meanOfPayment->bankCode = $bankCode;
                    $meanOfPayment->checkReference = $checkReference;
                    $meanOfPayment->amount = $Amount;
                    $meansOfPayment[] = $meanOfPayment;
                    unset($meanOfPayment);
                    
                    $amounts += $Amount;
                endfor;

                
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;

                if($declarantCode !="") $paymentInfo->declarantCode = $declarantCode;
                if($companyCode !=="A0700230J" && $companyCode !="")$paymentInfo->companyCode = $companyCode;

                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                $paymentInfo->paymentDate = date("d-m-Y");
                $paymentInfo->refund = false;
                
                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;

                /* Webservice CALL
                 * Payment
                */
                $checked = "E444";
                if($usersydonia != "" && $password != "")
                {
                        $identifiants = array(
                            'login' =>$usersydonia,
                            'password' => $password
                        );
                        
                        //$client = $this->sydoniaModel->init_ws("comptant", $identifiants);
                        
                        $client = '333';
                        if($client == "E404"):

                            $return = $client;

                        else:

                            try
                            {
                                $return = new \stdClass();
                                
                                $return->declarationPaymentResult = new \stdClass();
                                $return->declarationPaymentResult->result = 'OK';
                                $return->declarationPaymentResult->errorCode = '0';
                                $return->declarationPaymentResult->errorDescription = 'Payment executed successfully';
                                $return->declarationPaymentResult->receiptSerial = 'Q';
                                $return->declarationPaymentResult->receiptNumber = '303';
                                $return->declarationPaymentResult->receiptDate = '15/09/2021';
                                $return->declarationPaymentResult->totalAmount = '7560702.0';

                                $return->declarationPaymentResult->declarationsPaid= array();

                                $j = 0;
                                $return->declarationPaymentResult->declarationsPaid[$j]= new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationYear = '2021';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationSerial = '';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationNumber = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentSerial = 'L';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentNumber = '357';
                                $return->declarationPaymentResult->declarationsPaid[$j]->amountToBePaid = '2520234.0';

                                $i = 0;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = array();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RET';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '12893';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retribution DGDA/Partenaires';

                                $i = 1;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RAN';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '219';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retenue ANAPI 4% de 5%TPI';

                                $i = 2;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'TPI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '101149';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Taxe Promotion de l\'Industrie';

                                $i = 3;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT1';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGRAD Fonds Propres 17.5% des AT';

                                $i = 4;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT2';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGDA Fonds Propres 7.5% des AT';

                                $i = 5;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'DDI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '499750';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Droit de Douanes à l\'Import';

                                ##################################### 2 ###################

                                $j = 1;
                                $return->declarationPaymentResult->declarationsPaid[$j]= new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationYear = '2021';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationSerial = '';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationNumber = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentSerial = 'L';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentNumber = '358';
                                $return->declarationPaymentResult->declarationsPaid[$j]->amountToBePaid = '2520234.0';

                                $i = 0;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = array();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RET';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '12893';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retribution DGDA/Partenaires';

                                $i = 1;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RAN';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '219';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retenue ANAPI 4% de 5%TPI';

                                $i = 2;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'TPI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '101149';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Taxe Promotion de l\'Industrie';

                                $i = 3;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT1';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGRAD Fonds Propres 17.5% des AT';

                                $i = 4;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT2';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGDA Fonds Propres 7.5% des AT';

                                $i = 5;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'DDI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '499750';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Droit de Douanes à l\'Import';

                                ##################################### 3 ###################

                                $j = 2;
                                $return->declarationPaymentResult->declarationsPaid[$j]= new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationYear = '2021';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationSerial = '';
                                $return->declarationPaymentResult->declarationsPaid[$j]->registrationNumber = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentSerial = 'L';
                                $return->declarationPaymentResult->declarationsPaid[$j]->assessmentNumber = '359';
                                $return->declarationPaymentResult->declarationsPaid[$j]->amountToBePaid = '2520234.0';

                                $i = 0;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid = array();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RET';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '12893';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retribution DGDA/Partenaires';

                                $i = 1;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'RAN';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '219';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Retenue ANAPI 4% de 5%TPI';

                                $i = 2;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'TPI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '101149';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Taxe Promotion de l\'Industrie';

                                $i = 3;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT1';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGRAD Fonds Propres 17.5% des AT';

                                $i = 4;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'AT2';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '0';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'DGDA Fonds Propres 7.5% des AT';

                                $i = 5;

                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i] = new \stdClass();
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeCode = 'DDI';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeAmount = '499750';
                                $return->declarationPaymentResult->declarationsPaid[$j]->taxesPaid[$i]->taxeDescription = 'Droit de Douanes à l\'Import';
//
//                            
//                                /*
//                                * -----------------------------------------------------
//                                * Save request log
//                                * -----------------------------------------------------
//                                */
//
                                $log_request = var_export($checkPayment, true);
                                $filename = $bankCode."_request_comptant_batch";
                                $this->sydoniaModel->save_log($log_request, $filename);
//                                
//                                /*
//                                * -----------------------------------------------------
//                                * Make paiement confirmation in SYDONIA
//                                * -----------------------------------------------------
//                                */
//                                
                                $checked = $return;
//                                $checked = $client->declarationPayment($checkPayment);
                                
                                /*
                                * -----------------------------------------------------
                                * Save reponse logs
                                * -----------------------------------------------------
                                */

                                $log_response = var_export($checked, true);
                                $filename = $bankCode."_response_comptant_batch";
                                $this->sydoniaModel->save_log($log_response, $filename);
                        
                                
                                if(isset($checked->declarationPaymentResult->errorCode)) $error = $checked->declarationPaymentResult->errorCode;
                                if(isset($checked->declarationPaymentResult->result)) $rescode = $checked->declarationPaymentResult->result;

                                # Successful attempt - must be saved in log files
                                if(isset($checked->declarationPaymentResult->result) && $rescode == "OK"):

                                    $integration = date("Y-m-d h:s");
                                    $printing = date("Y-m-d h:s");
                                    $pdf  = '';
                                    if($rescode == "OK"):
                                        $error  = '0';
                                    else:
                                        $error =  "E".$error;
                                    endif;

                                    $Bl_24 = '';
                                    $Moyen = $paymentMean;
                                    $Quittance ='';
                                    $Beneficiare ='DGDA';
                                    $Type = '';
                                    $year='';
                                    $assessmentSerial='';
                                    $assessmentNumber='';
                                    $guichet ='';
                                    $date_array = explode("/",$checked->declarationPaymentResult->receiptDate);
                                    $Receiptid = $date_array[2].' '.$checked->declarationPaymentResult->receiptSerial.' '.$checked->declarationPaymentResult->receiptNumber;
                                    $Receiptdate = $date_array[0].'/'.$date_array[1].'/'.$date_array[2];
                                    $Paymentid = '';
                                    $reference = $Logirefid; 

                                    $bulletins = $checked->declarationPaymentResult->declarationsPaid;

                                    if(is_array($bulletins) && count($bulletins) > 1):

                                            foreach($bulletins as $bulletin)
                                            {
                                                    $commission = $coms;

                                                    $devisecom = $devise_commision; 
                                                    $assessmentSerial = $bulletin->assessmentSerial;
                                                    $assessmentNumber = $bulletin->assessmentNumber;
                                                    $total =  $amount = $bulletin->amountToBePaid;

                                                    //Quittance du batch
                                                    $result = new \stdClass();
                                                    $result->result = $checked->declarationPaymentResult->result;
                                                    $result->errorCode = $checked->declarationPaymentResult->errorCode;
                                                    $result->errorDescription = $checked->declarationPaymentResult->errorDescription;
                                                    $result->receiptDate = $Receiptdate;
                                                    $result->receiptSerial = $checked->declarationPaymentResult->receiptSerial;
                                                    $result->receiptNumber = $checked->declarationPaymentResult->receiptNumber;
                                                    $result->totalAmount = $bulletin->amountToBePaid;
                                                    $result->declarationsPaid = $bulletin;
                                                    $result->declarationPaymentResult = new \stdClass();
                                                    $result->declarationPaymentResult->DateLi = date("Y-m-d");

                                                    $results = json_encode($result);

                                                    $year = $bulletin->registrationYear;

                                                    # Data to insert 
                                                    $data_insert = [];

                                                    $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                    $data_insert['Status_2'] = 1;
                                                    $data_insert['Account_3'] = $account;
                                                    $data_insert['Type_4'] = $paymentMean;
                                                    $data_insert['Year_5'] = $year;
                                                    $data_insert["Office_6"] = $officeCode;
                                                    $data_insert["Serie_7"] = $assessmentSerial;
                                                    $data_insert["Number_8"] = $assessmentNumber;
                                                    $data_insert["Nif_9"] = $companyCode;
                                                    $data_insert["Agent_10"] = $declarantCode;
                                                    $data_insert["Bank_11"] = $bankCode;
                                                    $data_insert["Amount_12"] = $amount;
                                                    $data_insert["Results_13"] = $results;
                                                    $data_insert["Error_14"] = $error;
                                                    $data_insert["User_15"] = $user;
                                                    $data_insert["Integration_16"] = $integration;
                                                    $data_insert["Printing_17"] = $printing;
                                                    $data_insert["Pdfcontent_18"] = $pdf;
                                                    $data_insert["Reference_19"] = $reference;
                                                    $data_insert["Lot_22"] = 'batch';
                                                    $data_insert["Account_24"] = $cGuichet;
                                                    $data_insert["Amount_25"] = $total;
                                                    $data_insert["Commission_26"] = $commission;
                                                    $data_insert["Devise_27"] = $devisecom;
                                                    $data_insert["Account_28"] = $cCompte;
                                                    $data_insert["Devise_29"] = $cDevise;
                                                    $data_insert["Mode_30"] = $mode;
                                                    $data_insert["Taux_31"] = $taux;
                                                    $data_insert["Designation_23"] = $designation;
                                                    $data_insert["Agence_32"] = $bankagence;
                                                    $data_insert["Accountholder_33"] = $account_name;
                                                    $data_insert["Logirefid_34"] = $Logirefid;
                                                    
                                                    # The unique key of the payment
                                                    $montant =  intval($amount);
                                                    $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;
                                                    
                                                    $data_insert["Paiementkey_42"] = $paiement_key;
                                                    
                                                    // Save BL in database
                                                    $rid = $this->sydoniaModel->save_paiement_batch($data_insert, NULL); 

                                                    if($rid != 0 || $rid != FALSE)
                                                    {
                                                            $ids[] = $rid;
                                                    }
                                                    else
                                                    {
                                                            $return = "E002"; 
                                                            $log_request = var_export($checkPayment, true);
                                                            $filename = $bankCode."_request";
                                                            $this->sydoniaModel->save_log($log_request, $filename);

                                                            $log_response = var_export($checked, true);
                                                            $filename = $bankCode."_response";
                                                            $this->sydoniaModel->save_log($log_response, $filename);
                                                    }

                                            }

                                            $return = implode(",",$ids);

                                    elseif(is_object($bulletins) && $bulletins != NULL):

                                            $devisecom = $devise_commision; 
                                            $assessmentSerial = $bulletins->assessmentSerial;
                                            $assessmentNumber = $bulletins->assessmentNumber;
                                            $total = $amount = $bulletins->amountToBePaid;
                                            $commission = $coms;

                                            //Quittance du batch
                                            $result = new \stdClass();
                                            $result->result = $checked->declarationPaymentResult->result;
                                            $result->errorCode = $checked->declarationPaymentResult->errorCode;
                                            $result->errorDescription = $checked->declarationPaymentResult->errorDescription;
                                            $result->receiptDate = $Receiptdate;
                                            $result->receiptSerial = $checked->declarationPaymentResult->receiptSerial;
                                            $result->receiptNumber = $checked->declarationPaymentResult->receiptNumber;
                                            $result->totalAmount = $bulletins->amountToBePaid;
                                            $result->declarationsPaid = $bulletins;

                                            $results = json_encode($result);
                                            $year = $bulletins->registrationYear;

                                            # Data to insert 
                                            $data_insert = [];
                                            $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                            $data_insert['Status_2'] = 1;
                                            $data_insert['Account_3'] = $account;
                                            $data_insert['Type_4'] = $paymentMean;
                                            $data_insert['Year_5'] = $year;
                                            $data_insert["Office_6"] = $officeCode;
                                            $data_insert["Serie_7"] = $assessmentSerial;
                                            $data_insert["Number_8"] = $assessmentNumber;
                                            $data_insert["Nif_9"] = $companyCode;
                                            $data_insert["Agent_10"] = $declarantCode;
                                            $data_insert["Bank_11"] = $bankCode;
                                            $data_insert["Amount_12"] = $amount;
                                            $data_insert["Results_13"] = $results;
                                            $data_insert["Error_14"] = $error;
                                            $data_insert["User_15"] = $user;
                                            $data_insert["Integration_16"] = $integration;
                                            $data_insert["Printing_17"] = $printing;
                                            $data_insert["Pdfcontent_18"] = $pdf;
                                            $data_insert["Reference_19"] = $reference;
                                            $data_insert["Lot_22"] = 'batch';
                                            $data_insert["Account_24"] = $cGuichet;
                                            $data_insert["Amount_25"] = $total;
                                            $data_insert["Commission_26"] = $commission;
                                            $data_insert["Devise_27"] = $devisecom;
                                            $data_insert["Account_28"] = $cCompte;
                                            $data_insert["Devise_29"] = $cDevise;
                                            $data_insert["Mode_30"] = $mode;
                                            $data_insert["Taux_31"] = $taux;
                                            $data_insert["Designation_23"] = $designation;
                                            $data_insert["Agence_32"] = $bankagence;
                                            $data_insert["Accountholder_33"] = $account_name;
                                            $data_insert["Logirefid_34"] = $Logirefid;
                                            
                                            # The unique key of the payment
                                            $montant =  intval($amount);
                                            $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;
                                            
                                            $data_insert["Paiementkey_42"] = $paiement_key;
                                            
                                            $bir = $this->sydoniaModel->save_paiement_batch($data_insert, NULL);

                                            if($bir != 0 || $bir != FALSE)
                                            {
                                                    $return = $bir;
                                            }
                                            else
                                            {
                                                    $return = "E002";
                                                    $log_request = var_export($checkPayment, true);
                                                    $filename = $bankCode."_request";
                                                    $this->sydoniaModel->save_log($log_request, $filename);

                                                    $log_response = var_export($checked, true);
                                                    $filename = $bankCode."_response";
                                                    $this->sydoniaModel->save_log($log_response, $filename);
                                            }

                                    else:

                                        $return = "E501";

                                    endif;
                                    unset($client);

                                elseif(isset($error_code[$error]) && $rescode == "E"):

                                        $return = "E".$error;
                                        $results = json_encode($checked->declarationPaymentResult);
                                        #$reference = $checked->declarationPaymentResult->assessmentSerial.''.$checked->declarationPaymentResult->assessmentNumber;
                                        $integration = date("Y-m-d");
                                        $printing = date("Y-m-d");
                                        $pdf  = '';
                                        $year='';
                                        $amount = $amounts;
                                        $assessmentNumber = '';
                                        $assessmentSerial='';
                                        
                                        $data_errors = [];
                                        $data_errors['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_errors['Status_2'] = 1;
                                        $data_errors['Account_3'] = $account;
                                        $data_errors['Type_4'] = $paymentMean;
                                        $data_errors['Year_5'] = $year;
                                        $data_errors['Office_6'] = $officeCode;
                                        $data_errors['Serie_7'] = $assessmentSerial;
                                        $data_errors['Number_8'] = $assessmentNumber;
                                        $data_errors['Nif_9'] = $companyCode;
                                        $data_errors['Agent_10'] = $declarantCode;
                                        $data_errors['Bank_11'] = $bankCode;
                                        $data_errors['Amount_12'] = $amount;
                                        $data_errors['Results_13'] = $results;
                                        $data_errors['Error_14'] = $error;
                                        $data_errors['User_15'] = $user;
                                        $data_errors['Integration_16'] = $integration;
                                        $data_errors['Printing_17'] = $printing;
                                        $data_errors['Pdfcontent_18'] = $pdf;

                                        $rid = $this->sydoniaModel->save_paiement_errors($data_errors, NULL);        
                                else:
                                        $return = "E003";
                                        $results = json_encode($checked->declarationPaymentResult);
                                        $integration =date("Y-m-d");
                                        $printing = date("Y-m-d");
                                        $pdf  = '';
                                        $year='';
                                        $amount = $amounts;
                                        $assessmentNumber = '';
                                        $assessmentSerial='';
                                        
                                        $data_errors = [];
                                        $data_errors['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_errors['Status_2'] = 1;
                                        $data_errors['Account_3'] = $account;
                                        $data_errors['Type_4'] = $paymentMean;
                                        $data_errors['Year_5'] = $year;
                                        $data_errors['Office_6'] = $officeCode;
                                        $data_errors['Serie_7'] = $assessmentSerial;
                                        $data_errors['Number_8'] = $assessmentNumber;
                                        $data_errors['Nif_9'] = $companyCode;
                                        $data_errors['Agent_10'] = $declarantCode;
                                        $data_errors['Bank_11'] = $bankCode;
                                        $data_errors['Amount_12'] = $amount;
                                        $data_errors['Results_13'] = $results;
                                        $data_errors['Error_14'] = $error;
                                        $data_errors['User_15'] = $user;
                                        $data_errors['Integration_16'] = $integration;
                                        $data_errors['Printing_17'] = $printing;
                                        $data_errors['Pdfcontent_18'] = $pdf;
                                        
                                        $rid = $this->sydoniaModel->save_paiement_errors($data_errors, NULL);          
                                endif;
                            } 
                            catch (Exception $ex) 
                            {

                                    $return  = "E444";
                            }


                        endif;
                }
                else
                {
                        $return  = "E000";
                }

                //Return
                return $return;

                //Save logs
                $log_request = var_export($checkPayment, true);
                $filename = $bankCode."_request";
                $this->sydoniaModel->save_log($log_request, $filename);

                $log_response = var_export($checked, true);
                $filename = $bankCode."_response";
                $this->sydoniaModel->save_log($log_response, $filename);
        }
        public function quittance($data)
        {
                $data = $data;
                
                ini_set('default_socket_timeout', 5000);

                $usersydonia = $data['login'];
                $password = $data['password'];
                $code_bank = $data['code_bank'];

                $ReceiptSerial = $data['ReceiptSerial'];
                $ReceiptNumber = $data['ReceiptNumber'];
                $ReceiptDate = $data['ReceiptDate'];
                $paiementid = $data['Paiementid'];
                $officeCode = $data['Office'];
               

                $identifiants = array(
                    'login' =>$usersydonia,
                    'password' => $password
                );
                $client = $this->sydoniaModel->init_ws("quittance", $identifiants);
                
                if($client == 'E404')
                {
                        $return = $client;
                }
                else
                {
                        $integration = date("Y-m-d h:s");
                        $printing = date("Y-m-d h:s");
                        $pdf  = '';
                        $error  = '0';
                        /* PDF - Quittance */
                        #$client = $this->sydoniaModel->init_ws("quittance");
                        $receiptInfo = new \stdClass();
                        $receiptInfo->officeCode = $officeCode;
                        $receiptInfo->receiptSerial = $ReceiptSerial;
                        $receiptInfo->receiptNumber = $ReceiptNumber;
                        $date_original = $ReceiptDate;
                        $date_array = explode("/", $date_original);
                        $dateReceipt = $date_array[0]."-".$date_array[1]."-".$date_array[2];
                        $date_original =  date("c", strtotime('+1 hour', strtotime($dateReceipt)));
                        $receiptInfo->receiptDate = $date_original;
                        
                        $path = "./drive/sydonia/quittances";
                
                        if (is_dir($path)==false)
                        {
                                mkdir($path,0777,true);
                        }
                        
                        $zipFileName = $path."/Q_".date('Y_m_d')."_BL".$officeCode."_".$receiptInfo->receiptNumber.".gzip";
                        
                        $pdf = "quittances/Q_".date('Y_m_d')."_BL".$officeCode."_".$receiptInfo->receiptNumber.".pdf";
                        //PDF parameters  

                        $params = new \stdClass();
                        $params->receiptInfo = $receiptInfo;
                        
                        /*----------------------------------------------
                        * Save request logs
                        * ---------------------------------------------
                        */


                        $log_request = var_export($params, true);
                        $filename = $code_bank."_request_quittance";
                        $this->sydoniaModel->save_log($log_request, $filename);
                        
                        try
                        {
                                /*
                                * --------------------------------------------
                                * Call SYDONIA getPDFReceipt service  
                                * --------------------------------------------
                                */
                            
                                $response = $client->getPDFReceipt($params);
                                
                                $pdfResult = $response->getPDFReceiptResult->result;
                                
                                if(isset($pdfResult) && $pdfResult == "OK")
                                {
                                        $stream = $response->getPDFReceiptResult->pdfFile;
                                        $file = fopen($zipFileName, "w");
                                        fwrite($file, $stream);
                                        fclose($file);
                                        // Raising this value may increase performance
                                        $buffer_size = 4096; // read 4kb at a time
                                        $out_file_name = str_replace('.gzip', '.pdf', $zipFileName);
                                        
                                        // Open our files (in binary mode)
                                        $file = gzopen($zipFileName, 'rb');
                                        $out_file = fopen($out_file_name, 'wb'); 
                                        // Keep repeating until the end of the input file
                                        while (!gzeof($file)) 
                                        {
                                            // Read buffer-size bytes
                                            // Both fwrite and gzread and binary-safe
                                            fwrite($out_file, gzread($file, $buffer_size));
                                        }
                                        // Files are done, close files
                                        fclose($out_file);
                                        gzclose($file);
                                        !unlink($zipFileName);
                                        
                                        #Data construct
                                        $data = array();
                                        $data['Pdfcontent_18'] = $pdf;

                                        #update quittance
                                        $rid = $this->sydoniaModel->update_paiement_quittance($data, $paiementid);
                                        
                                        if($rid == 0 || $rid==FALSE)
                                        {
                                                $return = "E002"; 
                                        }
                                        else 
                                        {
                                                $return = $paiementid;
                                        }
                                }
                                elseif(isset($response->getPDFReceiptResult->errorDescription))
                                {
                                        # save the result into logs
                                        $log_request = var_export($response, true);
                                        $filename = $code_bank."_response_quittance";
                                        $this->sydoniaModel->save_log($log_request, $filename);
                                        
                                        
                                        $message = $response->getPDFReceiptResult->errorDescription;
                                        $return = "E001";
                                }
                                else
                                {
                                        # save the result into logs
                                        $log_request = var_export($response, true);
                                        $filename = $code_bank."_response_quittance";
                                        $this->sydoniaModel->save_log($log_request, $filename);
                                        
                                        $return = "E001";
                                }
                        } 
                        catch (Exception $e)
                        {
                                $return = 'E000';
                        }

                }
                        
                return $return;
        }
        public function checktest()
        {
                set_time_limit(250);
               
                ///* Variables initialisation
                // * From application
                $usersydonia = 'yaganet';
                $password = '123';
                $amountToBePaid = '10863789';

                $year = '2022';
                $assessmentSerial = 'L';
                $assessmentNumber = '27';
                $paymentMean = '10'; 
                $declarantCode = '000136';
                $checkReference = 'tt4575'; 
                $amount = '10863789';
                $officeCode = '501B';
                $companyCode = 'A0815158L';
                $account = '44';
                $bank = '1101';
                $bankAgence = '';
                $guichet ='';

                $integration = '';
                $deletion = '';
                $deletor  = '';
                $results  = '';
                $error  = '0';

                $return_description = array();
                $error_description = '';

                $error_code = array(
                                        '11' => 'Montant &agrave; payer incorrect',
                                        '13' =>'La d&eacute;claration est introuvable',
                                        '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                        '21' => 'Office Code not found',
                                        '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                                        '18' => 'Code banque non trouv&eacute;',
                                        '15' => 'Nif non reconnu;',
                                        '37' => 'Le nif et le d&eclarant ne peuvent pas manquer simultanement.'
                                    );
                /* Variables initialisation
                 * Daclaration info
                */

                $declarationsToBePaid = array();
                $declaration = new \stdClass();
                $declaration->amountToBePaid = $amountToBePaid;
                $declaration->registrationYear = $year;
                $declaration->registrationSerial = "";
                $declaration->registrationNumber = "";
                $declaration->assessmentSerial = $assessmentSerial;
                $declaration->assessmentNumber = $assessmentNumber;
                $declarationsToBePaid[] = $declaration;
                //Means of payment info
                $meansOfPayment = [];
                $meanOfPayment = new \stdClass();
                $meanOfPayment->meanOfPayment = $paymentMean;
                $meanOfPayment->bankCode = $bank;
                $meanOfPayment->checkReference = $checkReference;
                $meanOfPayment->amount = $amount;
                $meansOfPayment[] = $meanOfPayment;
                unset($meanOfPayment);
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;
                if($declarantCode != "") $paymentInfo->declarantCode = $declarantCode; 
                if($companyCode != "")$paymentInfo->companyCode = $companyCode;
                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;

                /* Logiref Middleware CALL
                 * Payment
                 */

                /*----------------------------------------------
                * Save request logs
                * ---------------------------------------------
                */

                $log_request = var_export($checkPayment, true);
                $filename = $bank."_request_checkbl";
                $this->sydoniaModel->save_log($log_request, $filename);

                /*
                * --------------------------------------------
                * Call SYDONIA checkPayment service  
                * --------------------------------------------
                */

                $data = array();
                $data['credentials'] = array('login' => $usersydonia, 'password'=> $password);
                $data['declaration'] = $checkPayment;
                $data['account'] = "44";

                $checked = $this->sydoniaModel->checkbl($data);
                //var_dump($checked->content->checkDeclarationPaymentResult);
                die;
        }
        public function testcomptant()
        {
                set_time_limit(250);
               
                ///* Variables initialisation
                // * From application
                $usersydonia = 'yaganet';
                $password = '123';
                $amountToBePaid = '10863789';

                $year = '2022';
                $assessmentSerial = 'L';
                $assessmentNumber = '27';
                $paymentMean = '10'; 
                $declarantCode = '000136';
                $checkReference = 'tt4575'; 
                $amount = '10863789';
                $officeCode = '501B';
                $companyCode = 'A0815158L';
                $account = '44';
                $bank = '1101';
                $bankAgence = '';
                $guichet ='';

                $integration = '';
                $deletion = '';
                $deletor  = '';
                $results  = '';
                $error  = '0';

                $return_description = array();
                $error_description = '';

                $error_code = array(
                                        '11' => 'Montant &agrave; payer incorrect',
                                        '13' =>'La d&eacute;claration est introuvable',
                                        '34' => 'Ce bulletin de liquidation a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;',
                                        '21' => 'Office Code not found',
                                        '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                                        '18' => 'Code banque non trouv&eacute;',
                                        '15' => 'Nif non reconnu;',
                                        '37' => 'Le nif et le d&eclarant ne peuvent pas manquer simultanement.'
                                    );
                /* Variables initialisation
                 * Daclaration info
                */

                $declarationsToBePaid = array();
                $declaration = new \stdClass();
                $declaration->amountToBePaid = $amountToBePaid;
                $declaration->registrationYear = $year;
                $declaration->registrationSerial = "";
                $declaration->registrationNumber = "";
                $declaration->assessmentSerial = $assessmentSerial;
                $declaration->assessmentNumber = $assessmentNumber;
                $declarationsToBePaid[] = $declaration;
                //Means of payment info
                $meansOfPayment = [];
                $meanOfPayment = new \stdClass();
                $meanOfPayment->meanOfPayment = $paymentMean;
                $meanOfPayment->bankCode = $bank;
                $meanOfPayment->checkReference = $checkReference;
                $meanOfPayment->amount = $amount;
                $meansOfPayment[] = $meanOfPayment;
                unset($meanOfPayment);
                //Payement info
                $paymentInfo = new \stdClass();
                $paymentInfo->officeCode = $officeCode;
                if($declarantCode != "") $paymentInfo->declarantCode = $declarantCode; 
                if($companyCode != "")$paymentInfo->companyCode = $companyCode;
                $paymentInfo->declarationsToBePaid = $declarationsToBePaid;
                $paymentInfo->meansOfPayment = $meansOfPayment;
                //Check info
                $checkPayment = new \stdClass();
                $checkPayment->paymentInfo = $paymentInfo;

                /* Logiref Middleware CALL
                 * Payment
                 */

                /*----------------------------------------------
                * Save request logs
                * ---------------------------------------------
                */

                $log_request = var_export($checkPayment, true);
                $filename = $bank."_request_comptant";
                $this->sydoniaModel->save_log($log_request, $filename);

                /*
                * --------------------------------------------
                * Call SYDONIA checkPayment service  
                * --------------------------------------------
                */

                $data = array();
                $data['credentials'] = array('login' => $usersydonia, 'password'=> $password);
                $data['declaration'] = $checkPayment;
                $data['account'] = "44";


                $checked = $this->sydoniaModel->comptant($data);


                $log_response = var_export($checked, true);
                $filename = $bank."_response_comptant";
                $this->sydoniaModel->save_log($log_response, $filename);
                
                var_dump($checked->content->declarationPaymentResult);
                die;
        }
        public function testquittance()
        {

                $usersydonia = 'yaganet';
                $password = '123';
                $code_bank = '5101';

                $ReceiptSerial = 'Q';
                $ReceiptNumber ='19';
                $ReceiptDate = '18/04/2022';
                $Paiementid = '5';
                $officeCode = '201B';


                $integration = date("Y-m-d h:s");
                $printing = date("Y-m-d h:s");
                $pdf  = '';
                $error  = '0';
                /* PDF - Quittance */
                #$client = $this->sydoniaModel->init_ws("quittance");
                $receiptInfo = new \stdClass();
                $receiptInfo->officeCode = $officeCode;
                $receiptInfo->receiptSerial = $ReceiptSerial;
                $receiptInfo->receiptNumber = $ReceiptNumber;
                $date_original = $ReceiptDate;
                $date_array = explode("/", $date_original);
                $dateReceipt = $date_array[0]."-".$date_array[1]."-".$date_array[2];
                $date_original =  date("c", strtotime('+1 hour', strtotime($dateReceipt)));
                $receiptInfo->receiptDate = $date_original;
                
             

                $params = new \stdClass();
                $params->receiptInfo = $receiptInfo;


               /*----------------------------------------------
                * Save request logs
                * ---------------------------------------------
                */


                $log_request = var_export($params, true);
                $filename = $code_bank."_request_quittance";
                $this->sydoniaModel->save_log($log_request, $filename);

                /*
                * --------------------------------------------
                * Call SYDONIA getPDFReceipt service  
                * --------------------------------------------
                */

                $data = array();
                $data['credentials'] = array('login' => $usersydonia, 'password'=> $password);
                $data['params'] = $params;
                $data['account'] = "44";

                $response = $this->sydoniaModel->quittance($data);


                /*
                 * --------------------------------------------
                 * Save response logs
                 * --------------------------------------------
                 */

                $log_response = var_export($response, true);
                $filename = $code_bank."_response_quittance";
                $this->sydoniaModel->save_log($log_response, $filename);
               
                //var_dump($response); die;
                if(isset($response->content))
                {
                    $file = $response->content;
                    #update quittance
                    $decode_file = base64_decode($file->stream);


                    $savedir = "./drive/quittances";
                    $filepath = "/Q_".date('Y_m_d')."_BL".$officeCode."_".$receiptInfo->receiptNumber.".pdf";

                    if (is_dir($savedir)==false)
                    {
                            mkdir($savedir,0777,true);
                    }

                    //$output_file = "./drive/quittances/".$ref.".jpg";
                    $output_file = $savedir.$filepath;

                    $file = fopen($output_file, "w");

                    fwrite($file, $decode_file);

                    fclose($file);

                    $pdf = 'http://192.168.210.42/tax.dev.api.rawbankonline.com/drive/quittances/'.$filepath;
                    $rid = $this->sydoniaModel->update_paiement_quittance($pdf, $Paiementid);  
                    if($rid == 0 || $rid==FALSE)
                    {
                            $return = "E002"; 
                    }
                    else 
                    {
                            $return = $rid;
                    }
                }
                else
                {
                        $return = $response->apicode;
                }

                echo $return;
        }
        public function prepaymentslist($data)
        {
                $codeBank = $data["bank"]; 
                $account = $data['Account'];
                $usersydonia = $data['login'];
                $password = $data["password"];
                
                $office = $data['Office'];
                $agence = $data['Agence'];

                $user = $data['User'];
                $bureau = $office;

                $serLiq = '';
                $numLiq = '';
                $datLiq = '';
                $serQuit = '';
                $numQuit = '';
                $datQuit = '';

                $nbrQuittances = ''; #$data['nbrQuittances'];

                $array_datedebut = explode("-", $data['dateDebut']);
                $array_datefin  = explode("-", $data['dateFin']);
                $dateDebut =  $array_datedebut[2].'/'.$array_datedebut[1].'/'.$array_datedebut[0];
                $dateFin = $array_datefin[2].'/'.$array_datefin[1].'/'.$array_datefin[0];
                $ids = array();

                $lot = '';

                $error_code = array(
                    '36'=>'Mot de passe incorrect',
                    '37'=>'Date debut incorrecte',
                    '38'=>'Date fin incorrecte',
                    '39'=>'Aucune quittance disponible',
                    '43'=>'Code Banque non autoris? pour vous',
                );

                /* Variables initialisation
                 * inputInfo
                */
                $prepaymentList = new \stdClass();
                $inputInfo = new \stdClass();
                
                $inputInfo->motDePasse = 'nWd0QEBAMjAxOERnZoNAOTk5OTl0V0hqQECAdk';
                $inputInfo->bureau = $bureau;
                $inputInfo->serLiq = '';
                $inputInfo->numLiq = '';
                $inputInfo->datLiq = '';
                $inputInfo->serQuit = '';
                $inputInfo->numQuit = '';
                $inputInfo->datQuit = '';
                $inputInfo->codeBank = $codeBank;
                $inputInfo->nbrQuittances = $nbrQuittances;
                $inputInfo->dateDebut = $dateDebut;
                $inputInfo->dateFin = $dateFin;
                $prepaymentList->inputInfo = $inputInfo;

                /* Webservice CALL
                 * Prepayment
                */
                
                $checked = "E000";
                if($usersydonia != "" && $password != "")
                {
                    $identifiants = array(

                                    'login' =>$usersydonia,
                                    'password' => $password
                                );

                    $client = $this->sydoniaModel->init_ws("prepaymentList",$identifiants);

                    if($client == "E404" || $client == "E405"  || $client == "E406"):

                            $return = $client;

                    else:

                            /*----------------------------------------------
                            * Save request logs
                            * ---------------------------------------------
                            */

                           $log_request = var_export($prepaymentList, true);
                           $filename = $codeBank."_request_prepayments";
                           $this->sydoniaModel->save_log($log_request, $filename);

                            try
                            {
                                    /*
                                     * --------------------------------------------
                                     * Call SYDONIA prepaymentsList service 
                                     * --------------------------------------------
                                     */

                                    $checked = $client->prepaymentList($prepaymentList);

                                    /*
                                     * --------------------------------------------
                                     * Save response logs
                                     * --------------------------------------------
                                     */

                                    $log_response = var_export($checked, true);
                                    $filename = $codeBank."_response_prepayments";
                                    $this->sydoniaModel->save_log($log_response, $filename);

                            } 
                            catch (SoapFault $ex)
                            {
                                   /*
                                    * --------------------------------------------
                                    * Save exception logs
                                    * --------------------------------------------
                                    */

                                    $script_exception = var_export($ex, true);
                                    $filename = $codeBank."_exception_prepayments";
                                    $this->sydoniaModel->save_log($script_exception, $filename);
                                    $return = $ex->faultcode;
                            }

                            if(isset($checked->prepaymentListResult))
                            {
                                    if(isset($checked->prepaymentListResult->codResult)) $codResult = $checked->prepaymentListResult->codResult;

                                    if(isset($checked->prepaymentListResult) && $codResult == "40")
                                    {

                                            $prepayments = $checked->prepaymentListResult->prepayGenInfo;

                                            if(is_array($prepayments) && count($prepayments) > 1):

                                                foreach($prepayments as $payment)
                                                {
                                                        $Amount = 0;
                                                        $infosQuittance = new \stdClass();
                                                        $infosQuittance->serQuit = $payment->serQuit;
                                                        $infosQuittance->numQuit = $payment->numQuit;
                                                        $infosQuittance->datQuit = $payment->datQuit;
                                                        $Quittance = json_encode($infosQuittance);
                                                        $TaxesInfo = json_encode($payment->prepayTaxeInfo);
                                                        $Taxes = $payment->prepayTaxeInfo;
                                                        if(is_array($Taxes)):
                                                                foreach($Taxes as $taxe)
                                                                {
                                                                    $Amount = ($Amount + $taxe->mntTaxe);
                                                                }
                                                        else:
                                                                $Amount =  $Taxes->mntTaxe;
                                                        endif;

                                                        $pid = $this->sydoniaModel->checkprepayment($account,$office, $payment->serieLiq, $payment->numLiq, $payment->datLiq, $Amount);
                                                        //$pid = true;

                                                        if($pid)
                                                        {
                                                                # Data to insert 
                                                                $data_insert = array();
                                                                $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $data_insert['Status_2'] = 1;
                                                                $data_insert['Account_3'] = $account;
                                                                $data_insert['Creator_4'] = $user;
                                                                $data_insert["MessageKey_7"] = $payment->messageKey;
                                                                $data_insert["Office_8"] = $payment->codBureau;
                                                                $data_insert["Serial_9"] = $payment->serieLiq;
                                                                $data_insert["Number_10"] = $payment->numLiq;
                                                                $data_insert["DateL_11"] = $payment->datLiq;
                                                                $data_insert["Quittance_12"] = $Quittance;
                                                                $data_insert["CodeBank_13"] = $payment->codeBank;
                                                                $data_insert["AccountRef_14"] = $payment->refCompte;
                                                                $data_insert["Nif_15"] = $payment->nif;
                                                                $data_insert["Declarant_16"] = $payment->codeDeclarant;
                                                                $data_insert["TaxesInfo_17"] = $TaxesInfo;
                                                                $data_insert["Amount_18"] = $Amount;
                                                                $data_insert["Agence_30"] = $agence;
                                                
                                                                $rid = $this->sydoniaModel->save_prepayments($data_insert, NULL);
                                                                
                                                                $ids[] = $rid;
                                                        }

                                                }

                                                if(isset($ids) && count($ids) > 0)
                                                {
                                                        $return = implode(",",$ids);
                                                }
                                                else
                                                {
                                                        $return = "E502";
                                                }


                                            elseif(is_object($prepayments) && $prepayments != NULL):

                                                    $Amount = 0;
                                                    $infosQuittance = new \stdClass();
                                                    $infosQuittance->serQuit = $prepayments->serQuit;
                                                    $infosQuittance->numQuit = $prepayments->numQuit;
                                                    $infosQuittance->datQuit = $prepayments->datQuit;
                                                    $Quittance = json_encode($infosQuittance);
                                                    $TaxesInfo = json_encode($prepayments->prepayTaxeInfo);
                                                    $Taxes = $prepayments->prepayTaxeInfo;
                                                    
                                                    if(is_array($Taxes)):
                                                        foreach($Taxes as $taxe)
                                                        {
                                                            $Amount = ($Amount + $taxe->mntTaxe);
                                                        }
                                                    else:
                                                            $Amount =  $Taxes->mntTaxe;
                                                    endif;

                                                    $pid = $this->sydoniaModel->checkprepayment($account,$office, $prepayments->serieLiq, $prepayments->numLiq, $prepayments->datLiq, $Amount);
                                                    
                                                    if($pid)
                                                    {
                                                            //$rid = $this->sydoniaModel->save_prepayments($account,$user,$agence,$prepayments->messageKey,$prepayments->codBureau,$prepayments->serieLiq,$prepayments->numLiq,$prepayments->datLiq,$Quittance,$prepayments->codeBank,$prepayments->refCompte,$prepayments->nif,$prepayments->codeDeclarant,$TaxesInfo,$Amount);
                                                               
                                                                # Data to insert 
                                                                $data_insert = array();
                                                                $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $data_insert['Status_2'] = 1;
                                                                $data_insert['Account_3'] = $account;
                                                                $data_insert['Creator_4'] = $user;
                                                                $data_insert["MessageKey_7"] = $payment->messageKey;
                                                                $data_insert["Office_8"] = $payment->codBureau;
                                                                $data_insert["Serial_9"] = $payment->serieLiq;
                                                                $data_insert["Number_10"] = $payment->numLiq;
                                                                $data_insert["DateL_11"] = $payment->datLiq;
                                                                $data_insert["Quittance_12"] = $Quittance;
                                                                $data_insert["CodeBank_13"] = $payment->codeBank;
                                                                $data_insert["AccountRef_14"] = $payment->refCompte;
                                                                $data_insert["Nif_15"] = $payment->nif;
                                                                $data_insert["Declarant_16"] = $payment->codeDeclarant;
                                                                $data_insert["TaxesInfo_17"] = $TaxesInfo;
                                                                $data_insert["Amount_18"] = $Amount;
                                                                $data_insert["Agence_30"] = $agence;
                                                
                                                                $rid = $this->sydoniaModel->save_prepayments($data_insert, NULL);
                                                                
                                                    }

                                                    if(isset($rid) && $rid > 0)
                                                    {
                                                            $return = $rid;
                                                    }
                                                    else
                                                    {
                                                            $return = "E502";
                                                    }

                                            else:
                                                    $return = "E501";
                                            endif;

                                    }
                                    else if(isset($error_code[$codResult]))
                                    {
                                            $return = "E".$codResult;
                                    }
                                    else
                                    {
                                            $return = "E514";
                                    }
                            }
                            else
                            {
                                    if($return == 'WSDL')
                                    {
                                            // Probleme de connexion ou problème disponibilité de SYDONIA
                                            $return = 'E404';
                                    }
                                    else if($return == 'HTTP')
                                    {
                                            // Problème d'authorisation , mot de passe ou login incorrect
                                            $return = 'E405';
                                    }
                                    else
                                    {
                                            // Autre exception à consulter dans le log fichier : _exception
                                            $return = 'E406';
                                    }
                            }

                    endif;
                }
                else
                {
                        $return = "E000";
                }
            
                //Return
                return $return;
        }
        
        public function extract_bl($data)
        {
                /* 
                 * -----------------------------------------------------------------------------
                 * Variables initialisation
                 * From application
                 * -----------------------------------------------------------------------------
                 * 
                 */

                $account = $data['Account'];
                $usersydonia = $data['login'];
                $password = $data['password'];
                $bankCode = $data['guichet'];
                $bankagence = $data['Agence'];
                $cGuichet = $data['cGuichet'];
                $officeCode = $data['Office'];
                $user = $data['User'];
                $companyCode = $data['Nif'];
                $taux = $data['taux'];
                $designation = $data['designation'];
                $Logirefid = $data['Logirefid'];
                $lot = $data['Logirefid'];
                $mode = '5';

                $qserie = $data['qserie'];
                $qnumber = $data['qnumber'];

                $array_datedebut = explode("-", $data['dateDebut']);
                $array_datefin  = explode("-", $data['dateFin']);
                $dateDebut =  $array_datedebut[2].'/'.$array_datedebut[1].'/'.$array_datedebut[0];
                $dateFin = $array_datefin[2].'/'.$array_datefin[1].'/'.$array_datefin[0];
                $ids = array();
                $error_code = array(

                    '42'=>'Code Banque non autoris? pour vous',
                    '44'=>'Aucune quiitance trouv&acute;e',
                    '13' =>'Server Exception'
                );


                $InputInfo  = new \stdClass();
                $InputInfo->banque = $bankCode; 
                $InputInfo->bureau = $officeCode;
                $InputInfo->dateDebutQuittance = $dateDebut; 
                $InputInfo->dateFinQuittance  = $dateFin;
                $InputInfo->serieQuittance = $qserie; 
                $InputInfo->numeroQuittance  = $qnumber;
                $InputInfo->company  = $companyCode;

                $getPaymentList = new \stdClass();
                $getPaymentList->inputInfo = $InputInfo;

                $checked = "E444";

                /*
                 * -----------------------------------------------------------------------------
                 * Check the permission
                 * -----------------------------------------------------------------------------
                 */

                if($usersydonia != "" && $password != "")
                {
                        $identifiants = array(
                            'login' =>$usersydonia,
                            'password' => $password
                        );
                        
                        $client = $this->sydoniaModel->init_ws("paymentsList", $identifiants);
                   
                        if($client == 'E404' || $client == 'E405'  ||  $client == 'E406'):

                            $return = $client;

                        else:

                            /*
                             * ---------------------------------------------------------------------------------------
                             * Save request Logs
                             * ---------------------------------------------------------------------------------------
                             */

                            $log_request = var_export($getPaymentList, true);
                            $filename = $bankCode."_request_paymentsList";
                            $this->sydoniaModel->save_log($log_request, $filename);
                            
                            try
                            {
                                   /*
                                    * ---------------------------------------------------------------------------------------
                                    *  Call GetPaymentList 
                                    * ---------------------------------------------------------------------------------------
                                    */

                                   $checked = $client->getPaymentList($getPaymentList);
                                   
                                   /*
                                    * ----------------------------------------------------------------------------------------
                                    * Save response logs
                                    * ----------------------------------------------------------------------------------------
                                    */

                                   $log_response = var_export($checked, true);
                                   $filename = $bankCode."_response_paymentsList";
                                   $this->sydoniaModel->save_log($log_response, $filename);
                            }
                            catch(SoapFault $ex)
                            {
                                   /*
                                    * --------------------------------------------
                                    * Save exception logs
                                    * --------------------------------------------
                                    */

                                   $script_exception = var_export($ex, true);
                                   $filename = $bank."_exception_paymentsList";
                                   $this->sydoniaModel->save_log($script_exception, $filename);
                                   $return = $ex->faultcode;
                            }

                            if(isset($checked->paymentListResult))
                            {
                                   /*
                                    * ----------------------------------------------------------------------------------------
                                    * Save operation
                                    * ----------------------------------------------------------------------------------------
                                    */
                                    if(isset($checked->paymentListResult->codResult)) $codResult = $checked->paymentListResult->codResult;
                                    if(isset($checked->paymentListResult->errorCode)) $errorCode = $checked->paymentListResult->errorCode;

                                    if(isset($checked->paymentListResult->declarationPaymentListResult) && $codResult === 0  && $errorCode === 0)
                                    {
                                        $receiptes = $checked->paymentListResult->declarationPaymentListResult;
   
                                        if(is_array($receiptes) && count($receiptes) > 1):

                                           foreach($receiptes as $receipte)
                                           {
                                                    if(isset($receipte->declarationsPaid))
                                                    {
                                                            $declarations = $receipte->declarationsPaid;

                                                            if(is_array($declarations) && count($declarations) > 1)
                                                            {
                                                                    foreach($declarations as $declaration)
                                                                    {
                                                                            $results = new \stdClass();
                                                                            $results->DateLi = date("Y-m-d");
                                                                            $results->receiptDate = $receipte->receiptDate;
                                                                            $results->receiptSerial = $receipte->receiptSerial;
                                                                            $results->receiptNumber = $receipte->receiptNumber;

                                                                            $results->declarationsPaid = $declaration;
                                                                            $results = json_encode($results);
                                                                       
                                                                            $integration = date("Y-m-d h:s");
                                                                            $printing = date("Y-m-d h:s");
                                                                            $pdf  = '';
                                                                            $error  = '0';
                                                                            $commission = 0;
                                                                            $devisecom = 'CDF';
                                                                            $reference = '';
                                                                            $Bl_24 = '';
                                                                            $Moyen = '7';
                                                                            $Quittance ='';
                                                                            $Beneficiare ='DGDA';
                                                                            $cDevise =  'CDF';
                                                                            $cCompte = '';
                                                                            $account_name = '';
                                                                            $Type = '';

                                                                            $assessmentSerial = $declaration->assessmentSerial;
                                                                            $assessmentNumber = $declaration->assessmentNumber;
                                                                            $year = $declaration->registrationYear;

                                                                            $paymentMean ='';
                                                                            $declarantCode='';


                                                                            $total = $amount = $declaration->amountToBePaid;
                                                                            unset($client);
                                                                            $montant =  intval($amount);

                                                                            $pid = $this->sydoniaModel->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$montant, $year);
                                                                       
                                                                            if($pid)
                                                                            {
                                                                                    # The unique key of the payment
                                                                                    $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;
                                                                                    
                                                                                    # Data to insert 
                                                                                    $data_insert = [];

                                                                                    $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                    $data_insert['Status_2'] = 1;
                                                                                    $data_insert['Account_3'] = $account;
                                                                                    $data_insert['Type_4'] = $paymentMean;
                                                                                    $data_insert['Year_5'] = $year;
                                                                                    $data_insert["Office_6"] = $officeCode;
                                                                                    $data_insert["Serie_7"] = $assessmentSerial;
                                                                                    $data_insert["Number_8"] = $assessmentNumber;
                                                                                    $data_insert["Nif_9"] = $companyCode;
                                                                                    $data_insert["Agent_10"] = $declarantCode;
                                                                                    $data_insert["Bank_11"] = $bankCode;
                                                                                    $data_insert["Amount_12"] = $amount;
                                                                                    $data_insert["Results_13"] = $results;
                                                                                    $data_insert["Error_14"] = $error;
                                                                                    $data_insert["User_15"] = $user;
                                                                                    $data_insert["Integration_16"] = $integration;
                                                                                    $data_insert["Printing_17"] = $printing;
                                                                                    $data_insert["Pdfcontent_18"] = $pdf;
                                                                                    $data_insert["Reference_19"] = $reference;
                                                                                    $data_insert["Lot_22"] = $lot;
                                                                                    $data_insert["Account_24"] = $cGuichet;
                                                                                    $data_insert["Amount_25"] = $total;
                                                                                    $data_insert["Commission_26"] = $commission;
                                                                                    $data_insert["Devise_27"] = $devisecom;
                                                                                    $data_insert["Account_28"] = $cCompte;
                                                                                    $data_insert["Devise_29"] = $cDevise;
                                                                                    $data_insert["Mode_30"] = $mode;
                                                                                    $data_insert["Taux_31"] = $taux;
                                                                                    $data_insert["Designation_23"] = $designation;
                                                                                    $data_insert["Agence_32"] = $bankagence;
                                                                                    $data_insert["Accountholder_33"] = $account_name;
                                                                                    $data_insert["Logirefid_34"] = $Logirefid;
                                                                                    $data_insert["Paiementkey_42"] = $paiement_key;

                                                                                    $rid = $this->sydoniaModel->save_paiement($data_insert, NULL);

                                                                                    if($rid != 0 || $rid != FALSE)
                                                                                    {
                                                                                            $ids[] = $rid;
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                            $return = "E002"; 
                                                                                    }
                                                                            }

                                                                    }
                                                            }
                                                            elseif(is_object($declarations) && $declarations != NULL)
                                                            {

                                                                    $results = new \stdClass();
                                                                    $results->DateLi = date("Y-m-d");
                                                                    $results->receiptDate = $receipte->receiptDate;
                                                                    $results->receiptSerial = $receipte->receiptSerial;
                                                                    $results->receiptNumber = $receipte->receiptNumber;

                                                                    $results->declarationsPaid = $declarations;
                                                                    $results = json_encode($results);
                                                                    
                               
                                                                    $integration = date("Y-m-d h:s");
                                                                    $printing = date("Y-m-d h:s");
                                                                    $pdf  = '';
                                                                    $error  = '0';
                                                                    $commission = 0;
                                                                    $devisecom = 'CDF';
                                                                    $reference = '';
                                                                    $Bl_24 = '';
                                                                    $Moyen = '7';
                                                                    $Quittance ='';
                                                                    $Beneficiare ='DGDA';
                                                                    $cDevise =  'CDF';
                                                                    $cCompte = '';
                                                                    $account_name = '';
                                                                    $Type = '';

                                                                    $assessmentSerial = $declarations->assessmentSerial;
                                                                    $assessmentNumber = $declarations->assessmentNumber;
                                                                    $year = $declarations->registrationYear;

                                                                    $paymentMean ='';
                                                                    $declarantCode='';


                                                                    $total = $amount = $declarations->amountToBePaid;
                                                                    unset($client);
                                                                    $montant =  intval($amount);

                                                                    $pid = $this->sydoniaModel->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$montant, $year);
                                                                    if($pid)
                                                                    {   
                                                                            # The unique key of the payment
                                                                            $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;

                                                                            # Data to insert 
                                                                            $data_insert = [];

                                                                            $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                            $data_insert['Status_2'] = 1;
                                                                            $data_insert['Account_3'] = $account;
                                                                            $data_insert['Type_4'] = $paymentMean;
                                                                            $data_insert['Year_5'] = $year;
                                                                            $data_insert["Office_6"] = $officeCode;
                                                                            $data_insert["Serie_7"] = $assessmentSerial;
                                                                            $data_insert["Number_8"] = $assessmentNumber;
                                                                            $data_insert["Nif_9"] = $companyCode;
                                                                            $data_insert["Agent_10"] = $declarantCode;
                                                                            $data_insert["Bank_11"] = $bankCode;
                                                                            $data_insert["Amount_12"] = $amount;
                                                                            $data_insert["Results_13"] = $results;
                                                                            $data_insert["Error_14"] = $error;
                                                                            $data_insert["User_15"] = $user;
                                                                            $data_insert["Integration_16"] = $integration;
                                                                            $data_insert["Printing_17"] = $printing;
                                                                            $data_insert["Pdfcontent_18"] = $pdf;
                                                                            $data_insert["Reference_19"] = $reference;
                                                                            $data_insert["Lot_22"] = $lot;
                                                                            $data_insert["Account_24"] = $cGuichet;
                                                                            $data_insert["Amount_25"] = $total;
                                                                            $data_insert["Commission_26"] = $commission;
                                                                            $data_insert["Devise_27"] = $devisecom;
                                                                            $data_insert["Account_28"] = $cCompte;
                                                                            $data_insert["Devise_29"] = $cDevise;
                                                                            $data_insert["Mode_30"] = $mode;
                                                                            $data_insert["Taux_31"] = $taux;
                                                                            $data_insert["Designation_23"] = $designation;
                                                                            $data_insert["Agence_32"] = $bankagence;
                                                                            $data_insert["Accountholder_33"] = $account_name;
                                                                            $data_insert["Logirefid_34"] = $Logirefid;
                                                                            $data_insert["Paiementkey_42"] = $paiement_key;

                                                                            //$rid = $this->sydoniaModel->save_paiement($account, $paymentMean, $year, $officeCode, $assessmentSerial, $assessmentNumber, $companyCode, $declarantCode, $bankCode, $amount, $results, $error, $user, $integration, $printing, $pdf, $reference, $lot, $cGuichet, $total, $commission, $devisecom, $cCompte, $cDevise, $mode, $taux, $designation, $bankagence, $account_name, $Logirefid, $paiement_key);
                                                                            $rid = $this->sydoniaModel->save_paiement($data_insert, NULL);
                                                                            
                                                                            if($rid != 0 || $rid != FALSE)
                                                                            {
                                                                                    $ids[] = $rid;
                                                                            }
                                                                            else
                                                                            {
                                                                                    $return = "E002"; 
                                                                            }
                                                                    }
                                                                    else
                                                                    {

                                                                    }
                                                            }
                                                    }
                                                    else
                                                    {
                                                            $return = "E502";
                                                    }
                                            }

                                            if(isset($ids) && count($ids) > 0)
                                            {
                                                    $return = implode(",",$ids);
                                            }
                                            elseif($receiptes !=NULL)
                                            {

                                                    $return = "E502";

                                            }
                                            else
                                            {
                                                    $return = "E501";
                                            }

                                        elseif(is_object($receiptes) && $receiptes != NULL):

                                                if(isset($receiptes->declarationsPaid))
                                                {
                                                        $declarations = $receiptes->declarationsPaid;

                                                        if(is_array($declarations) && count($declarations) > 1)
                                                        {
                                                                foreach($declarations as $declaration)
                                                                {
                                                                        $results = new \stdClass();
                                                                        $results->DateLi = date("Y-m-d");
                                                                        $results->receiptDate = $receiptes->receiptDate;
                                                                        $results->receiptSerial = $receiptes->receiptSerial;
                                                                        $results->receiptNumber = $receiptes->receiptNumber;

                                                                        $results->declarationsPaid = $declaration;
                                                                        $results = json_encode($results);
                                                                        $integration = date("Y-m-d h:s");
                                                                        $printing = date("Y-m-d h:s");
                                                                        $pdf  = '';
                                                                        $error  = '0';
                                                                        $commission = 0;
                                                                        $devisecom = 'CDF';
                                                                        $reference = '';
                                                                        $Bl_24 = '';
                                                                        $Moyen = '7';
                                                                        $Quittance ='';
                                                                        $Beneficiare ='DGDA';
                                                                        $cDevise =  'CDF';
                                                                        $cCompte = '';
                                                                        $account_name = '';
                                                                        $Type = '';

                                                                        $assessmentSerial = $declaration->assessmentSerial;
                                                                        $assessmentNumber = $declaration->assessmentNumber;
                                                                        $year = $declaration->registrationYear;

                                                                        $paymentMean ='10';
                                                                        $declarantCode='';


                                                                        $total = $amount = $declaration->amountToBePaid;
                                                                        unset($client);

                                                                        $montant =  intval($amount);

                                                                        $pid = $this->sydoniaModel->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$montant, $year);

                                                                        if($pid)
                                                                        {
                                                                                # The unique key of the payment
                                                                                $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;
                                                                                
                                                                                # Data to insert 
                                                                                $data_insert = [];

                                                                                $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                                $data_insert['Status_2'] = 1;
                                                                                $data_insert['Account_3'] = $account;
                                                                                $data_insert['Type_4'] = $paymentMean;
                                                                                $data_insert['Year_5'] = $year;
                                                                                $data_insert["Office_6"] = $officeCode;
                                                                                $data_insert["Serie_7"] = $assessmentSerial;
                                                                                $data_insert["Number_8"] = $assessmentNumber;
                                                                                $data_insert["Nif_9"] = $companyCode;
                                                                                $data_insert["Agent_10"] = $declarantCode;
                                                                                $data_insert["Bank_11"] = $bankCode;
                                                                                $data_insert["Amount_12"] = $amount;
                                                                                $data_insert["Results_13"] = $results;
                                                                                $data_insert["Error_14"] = $error;
                                                                                $data_insert["User_15"] = $user;
                                                                                $data_insert["Integration_16"] = $integration;
                                                                                $data_insert["Printing_17"] = $printing;
                                                                                $data_insert["Pdfcontent_18"] = $pdf;
                                                                                $data_insert["Reference_19"] = $reference;
                                                                                $data_insert["Lot_22"] = $lot;
                                                                                $data_insert["Account_24"] = $cGuichet;
                                                                                $data_insert["Amount_25"] = $total;
                                                                                $data_insert["Commission_26"] = $commission;
                                                                                $data_insert["Devise_27"] = $devisecom;
                                                                                $data_insert["Account_28"] = $cCompte;
                                                                                $data_insert["Devise_29"] = $cDevise;
                                                                                $data_insert["Mode_30"] = $mode;
                                                                                $data_insert["Taux_31"] = $taux;
                                                                                $data_insert["Designation_23"] = $designation;
                                                                                $data_insert["Agence_32"] = $bankagence;
                                                                                $data_insert["Accountholder_33"] = $account_name;
                                                                                $data_insert["Logirefid_34"] = $Logirefid;
                                                                                $data_insert["Paiementkey_42"] = $paiement_key;
                                                                                
                                                                                
                                                                                $rid = $this->sydoniaModel->save_paiement($data_insert, NULL);

                                                                                if($rid != 0 || $rid != FALSE)
                                                                                {
                                                                                        $ids[] = $rid;
                                                                                }
                                                                                else
                                                                                {
                                                                                        $return = "E002"; 
                                                                                }
                                                                        }


                                                                }
                                                        }
                                                        elseif(is_object($declarations) && $declarations != NULL)
                                                        {
                                                                $results = new \stdClass();
                                                                $results->DateLi = date("Y-m-d");
                                                                $results->receiptDate = $receiptes->receiptDate;
                                                                $results->receiptSerial = $receiptes->receiptSerial;
                                                                $results->receiptNumber = $receiptes->receiptNumber;
    
                                                                $results->declarationsPaid = $declarations;
                                                                $results = json_encode($results);
                                                                $integration = date("Y-m-d h:s");
                                                                $printing = date("Y-m-d h:s");
                                                                $pdf  = '';
                                                                $error  = '0';
                                                                $commission = 0;
                                                                $devisecom = 'CDF';
                                                                $reference = '';
                                                                $Bl_24 = '';
                                                                $Moyen = '7';
                                                                $Quittance ='';
                                                                $Beneficiare ='DGDA';
                                                                $cDevise =  'CDF';
                                                                $cCompte = '';
                                                                $account_name = '';
                                                                $Type = '';

                                                                $assessmentSerial = $declarations->assessmentSerial;
                                                                $assessmentNumber = $declarations->assessmentNumber;
                                                                $year = $declarations->registrationYear;

                                                                $paymentMean ='';
                                                                $declarantCode='';
   
                                                                $total = $amount = $declarations->amountToBePaid;
                                                                unset($client);
                                                                $montant =  intval($amount);

                                                                $pid = $this->sydoniaModel->checkpayment($officeCode, $assessmentSerial, $assessmentNumber,$montant, $year);
                                                        
                                                                if($pid)
                                                                {
                                                                        # The unique key of the payment
                                                                        $paiement_key = $year.$officeCode.$assessmentSerial.$assessmentNumber.$companyCode.$bankCode.$montant;

                                                                        # Data to insert 
                                                                        $data_insert = [];

                                                                        $data_insert['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                        $data_insert['Status_2'] = 1;
                                                                        $data_insert['Account_3'] = $account;
                                                                        $data_insert['Type_4'] = $paymentMean;
                                                                        $data_insert['Year_5'] = $year;
                                                                        $data_insert["Office_6"] = $officeCode;
                                                                        $data_insert["Serie_7"] = $assessmentSerial;
                                                                        $data_insert["Number_8"] = $assessmentNumber;
                                                                        $data_insert["Nif_9"] = $companyCode;
                                                                        $data_insert["Agent_10"] = $declarantCode;
                                                                        $data_insert["Bank_11"] = $bankCode;
                                                                        $data_insert["Amount_12"] = $amount;
                                                                        $data_insert["Results_13"] = $results;
                                                                        $data_insert["Error_14"] = $error;
                                                                        $data_insert["User_15"] = $user;
                                                                        $data_insert["Integration_16"] = $integration;
                                                                        $data_insert["Printing_17"] = $printing;
                                                                        $data_insert["Pdfcontent_18"] = $pdf;
                                                                        $data_insert["Reference_19"] = $reference;
                                                                        $data_insert["Lot_22"] = $lot;
                                                                        $data_insert["Account_24"] = $cGuichet;
                                                                        $data_insert["Amount_25"] = $total;
                                                                        $data_insert["Commission_26"] = $commission;
                                                                        $data_insert["Devise_27"] = $devisecom;
                                                                        $data_insert["Account_28"] = $cCompte;
                                                                        $data_insert["Devise_29"] = $cDevise;
                                                                        $data_insert["Mode_30"] = $mode;
                                                                        $data_insert["Taux_31"] = $taux;
                                                                        $data_insert["Designation_23"] = $designation;
                                                                        $data_insert["Agence_32"] = $bankagence;
                                                                        $data_insert["Accountholder_33"] = $account_name;
                                                                        $data_insert["Logirefid_34"] = $Logirefid;
                                                                        $data_insert["Paiementkey_42"] = $paiement_key;
                                                                        
                                                                        $rid = $this->sydoniaModel->save_paiement($data_insert, NULL);

                                                                        if($rid != 0 || $rid != FALSE)
                                                                        {
                                                                                $ids[] = $rid;
                                                                        }
                                                                        else
                                                                        {
                                                                                $return = "E002"; 
                                                                        }
                                                                }
                                                                else
                                                                {

                                                                }
                                                        }
                                                }
                                                else
                                                {

                                                }

                                                if(isset($ids) && count($ids) > 0)
                                                {
                                                        $return = implode(",",$ids);
                                                }
                                                elseif($receiptes !=NULL)
                                                {
                                                        $return = "E502";
                                                }
                                                else
                                                {
                                                        $return = "E501";
                                                }

                                        else:
                                                $return = "E501";
                                        endif;

                                    }
                                    else if(isset($error_code[$errorCode]))
                                    {
                                            $return = "E".$errorCode;
                                    }
                                    else
                                    {
                                            $return = "E514";
                                    }
                            }
                            else
                            {
                                    if($return == 'WSDL')
                                    {
                                            // Probleme de connexion ou problème disponibilité de SYDONIA
                                            $return = 'E404';
                                    }
                                    else if($return == 'HTTP')
                                    {
                                            // Problème d'authorisation , mot de passe ou login incorrect
                                            $return = 'E405';
                                    }
                                    else
                                    {
                                            // Autre exception à consulter dans le log fichier : _exception
                                            $return = 'E406';
                                    } 
                            }
                            
                        endif;
                }
                else
                {
                        $return  = "E000";
                }

                /*
                 * -----------------------------------------------------------------------------------------------------
                 *  Send return
                 * -----------------------------------------------------------------------------------------------------
                 */

                return $return;

        }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
