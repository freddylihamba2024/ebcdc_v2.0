<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\SurveyModel;


class QleadsSurvey extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 10.11.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $surveyModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->surveyModel = new SurveyModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = '';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']=='')
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Qleads\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']=='')
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "survey")
                {
                        $this->data['survey'] = $this->surveyModel->get_survey_info();
                        echo view('\Modules\Qleads\Views\tokens\_token', $this->data);
                }
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "survey")
                {
                        $data = $_POST;
                        
                        if($data['Tokentype_8']=='0' || $data['Category_9']==''  || $data['Name_10']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL || $id = "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $cid = $this->tokenModel->save_survey($data, $id); 
                        
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! sondage enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                
        }
}

/* End of file   */
/* Location: /  */