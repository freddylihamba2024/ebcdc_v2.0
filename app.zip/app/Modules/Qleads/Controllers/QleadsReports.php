<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\TokensModel;
use Modules\Qleads\Models\InquiriesModel;
use Modules\Qleads\Models\ReportsModel;
use Modules\Qleads\Models\AppointmentModel;
use Modules\Qleads\Models\DashboardModel;
use Modules\Main\Models\MainModel;

use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\UserQleadModel;
use Modules\Admin\Models\QleadUsersModel;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\QleadEquipmentModel;
use Modules\Admin\Models\QleadAdsModel;
use Modules\Logiref\Models\LogirefModel;

class QleadsReports extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','menus_director','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $tokenModel;
        public $inquiriesModel;
        public $reportsModel;
        public $dashboardModel;
        public $mainModel;
        public $branchModel;
        public $userQleadModel;
        public $appointmentModel;
        public $usersQleadsModal;
        public $categorieModal;
        public $queueModal;
        public $adsModal;
        public $equipmentModal;
        public $logirefModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->inquiriesModel = new InquiriesModel();
                $this->tokenModel = new TokensModel();
                $this->reportsModel = new ReportsModel();
                $this->appointmentModel = new AppointmentModel();
                $this->dashboardModel = new DashboardModel();
                $this->mainModel = new MainModel();
                $this->branchModel = new BranchModel();
                $this->userQleadModel = new UserQleadModel();
                $this->usersQleadsModal = new QleadUsersModel();
                $this->categorieModal = new QleadCategoryModel();
                $this->queueModal = new QleadQueueModel();
                $this->equipmentModal = new QleadEquipmentModel();
                $this->adsModal = new QleadAdsModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'qleadsreports';
                $this->data['function'] = '';
                $this->data['role'] = '';
                $this->data['sidebar'] = "";
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
                
	} 
	           
	public function index()
	{
		$this->data['subview'] = '\Modules\Qleads\Views\container';

                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                $this->data['sidebar'] = '';
                $this->index();
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "tokens")
                {
                        $this->data['token'] = $this->tokenModel->get_tokens();
                        echo view('\Modules\Qleads\Views\tokens\tokens', $this->data);
                }
                elseif($obj == "inquiries")
                
                {
                        $this->data['status'] = $this->inquiriesModel->inquiry_status;
                        $this->data['categories'] = $this->inquiriesModel->get_dropdown('token_category');
                        $this->data['tokens'] = $this->tokenModel->get_dropdown('token');
                        $this->data['inquiries'] = $this->inquiriesModel->get_inquiries();
                        echo view('\Modules\Qleads\Views\inquiries\inquiries', $this->data);
                }
                elseif($obj == "surveys")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        
                        echo view('\Modules\Qleads\Views\reports\_surveys', $this->data);
                }
                elseif($obj == "feedback")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        
                        echo view('\Modules\Qleads\Views\reports\_feedback', $this->data);
                }
                elseif($obj == "performance")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance();
                        
                        echo view('\Modules\Qleads\Views\reports\_performance', $this->data);
                }
                elseif($obj == "satisfaction")
                {
                        $surveys= $this->reportsModel->get_surveys();
                        $this->data['surveys'] = $surveys;
                        echo view('\Modules\Qleads\Views\reports\satisfaction', $this->data);
                }
                elseif($obj == "satisfaction_supervisor")
                {
                        $surveys= $this->reportsModel->get_surveys();
                        $this->data['surveys'] = $surveys;
                        echo view('\Modules\Qleads\Views\reports\satisfaction_supervisor', $this->data);
                }
                elseif($obj == "satisfaction_director")
                {
                        $surveys= $this->reportsModel->get_surveys();
                        $this->data['surveys'] = $surveys;
                        echo view('\Modules\Qleads\Views\reports\_satisfaction5', $this->data);
                }
                
                elseif($obj == "active_queues")
                {
                    $this->data['queues'] = $this->reportsModel->get_queues();
                    $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                    $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                    if($_SESSION['Qleads_role']==5)
                    {
                        
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                    }
                    else
                    {
                        
                        echo view('\Modules\Qleads\Views\reports\_queuing', $this->data);
                    }
                        
                }
                elseif($obj == "my_queues")
                {
                        $this->data['queues'] = $this->reportsModel->get_queues();
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['role'] = $_SESSION['Qleads_role'];
                        echo view('\Modules\Qleads\Views\reports\_queues', $this->data);
                        
                }
                elseif($obj == "my_queues_supervisor")
                {
                        $this->data['queues'] = $this->reportsModel->get_queues();
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['role'] = $_SESSION['Qleads_role'];
                        echo view('\Modules\Qleads\Views\reports\_queues_supervisor', $this->data);
                        
                }
                elseif($obj == "queue_supervisor")
                {
                        $queu = $this->reportsModel->get_queu();

                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['queu'] = $queu; 
                        $this->data['category'] = $this->tokenModel->get_dropdown("category");
                        echo view('\Modules\Qleads\Views\reports\queue_supervisor', $this->data);
                }
                elseif($obj == "performance_supervisor")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("subcategory");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance();
                        echo view('\Modules\Qleads\Views\reports\performance_supervisor', $this->data);
                }
                elseif($obj == "filter_performance_sup")
                {
                        $data = $_POST;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("subcategory");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance_filter($data);
                        
                        echo view('\Modules\Qleads\Views\reports\_filter_performance_sup', $this->data);
                }
                elseif($obj == "inquirie")
                {
                        $inquiries= $this->reportsModel->get_inquirie();
                        $this->data['inquiries'] = $inquiries;
                        echo view('\Modules\Qleads\Views\reports\inquirie', $this->data);
                        
                }
                elseif($obj == "inquirie_supervisor")
                {
                        $inquiries= $this->reportsModel->get_inquirie_by_branchid();
                        $this->data['inquiries'] = $inquiries;

                        echo view('\Modules\Qleads\Views\reports\inquirie_supervisor', $this->data);
                }
                elseif($obj == "users")
                {
                        
                        $this->data['habilitations'] = $this->reportsModel->get_users();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown("profiles_array");
                        $this->data['studies_level'] = $this->userQleadModel->studies_level; 
                        $this->data['status_marital'] = array(0=>"Célibataire", 1=>"Mari(é)");
                        $this->data['status_parental'] = array(0=>"Non", 1=>"Oui"); 
                        $this->data['gender'] = array(0=>"Femme", 1=>"Homme"); 

                        echo view('\Modules\Qleads\Views\reports\users', $this->data);
                }
                elseif($obj == "usersprofiles")
                {
                        
                        $this->data['habilitations'] = $this->reportsModel->get_users();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown("profiles_array");
                        $this->data['studies_level'] = $this->userQleadModel->studies_level; 
                        $this->data['status_marital'] = array(0=>"Célibataire", 1=>"Mari(é)");
                        $this->data['status_parental'] = array(0=>"Non", 1=>"Oui"); 
                        $this->data['gender'] = array(0=>"Femme", 1=>"Homme"); 

                        echo view('\Modules\Qleads\Views\reports\_usersprofiles', $this->data);
                }
                elseif($obj == "borne_screen")
                {
                        $this->data['categorie'] = $this->tokenModel->get_dropdown('category');
                        $this->data['users_code'] = $this->reportsModel->get_dropdown('users_code');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown("users");
                        $this->data['devices'] = $this->reportsModel->get_devices();
                        echo view('\Modules\Qleads\Views\reports\borne_screen', $this->data);
                }
                elseif($obj == "menus_director") 
                {
                        $this->data['alerts'] = array();
                        
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance();
                       
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "suivis") 
                {
                        $this->data['alerts'] = array();
                        
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance();
                       
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "menus_supervisor") 
                {
                        $this->data['alerts'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance();
                       
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "filter_rendement") 
                {
                        #var_dump("tres");die;
                        $data = $_POST;
                        $this->data['alerts'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['performances'] = $this->reportsModel->get_performance_filter($data);
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "visites") 
                {
                        $this->data['alerts'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['queuing'] = $this->reportsModel->get_queuing();
                        $this->data['horaires'] = array(0=>"", 1=>"6h à 10h" , 2=>"10h à 12h"  , 3=>"13h à 15h");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "filter_visites") 
                {
                        $this->data['alerts'] = array();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['queuing'] = $this->reportsModel->get_reports_filter_queuing($_POST);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "produit_service")
                {
                        $this->data['categorie'] = $this->tokenModel->get_dropdown('category');
                        $this->data['users_code'] = $this->reportsModel->get_dropdown('users_code');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown("users");
                        $this->data['produits'] = $this->reportsModel->get_token_guichet();
                        $this->data['tranches'] = array(0=>"", 1=>"6h à 10h" , 2=>"10h à 12h"  , 3=>"13h à 15h");
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "filter_produit_service")
                {
                        $this->data['categorie'] = $this->tokenModel->get_dropdown('category');
                        $this->data['users_code'] = $this->reportsModel->get_dropdown('users_code');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModel->get_dropdown("users");
                        $this->data['produits'] = $this->reportsModel->get_reports_filter_produit_service($_POST);
                        echo view('\Modules\Qleads\Views\reports\_filter_produit_service', $this->data);
                }
                elseif($obj == "clients_feedback")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['surveys'] = $this->reportsModel->get_surveys();
                        #var_dump($this->data['surveys']);die;    
                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "filter_clientsfeedback")
                {
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['surveys'] = $surveys;
                        $surveys= $this->reportsModel->get_surveys_filter($_POST);

                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "appointements")
                {
                        $data_users = array();
                        $total_appointment= "";
                        
                        $users_qleads = $this->usersQleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        $this->data['users'] = $data_users;
                        $this->data['alerts'] = array();
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['type_customer'] = $this->appointmentModel->type_customer;
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['appointments'] = $this->appointmentModel->get_appointments();

                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "appointements_teller")
                {
                        $data_users = array();
                        $total_appointment= "";
                        
                        $users_qleads = $this->usersQleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        $this->data['users'] = $data_users;
                        $this->data['alerts'] = array();
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['type_customer'] = $this->appointmentModel->type_customer;
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['appointments'] = $this->appointmentModel->get_appointments();

                        echo view('\Modules\Qleads\Views\reports\_'.$obj, $this->data);
                }
                elseif($obj == "filter_appointements")
                {
                        
                        $data = $_POST;

                        $data_users = array();
                        
                        $users_qleads = $this->usersQleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        $this->data['users'] = $data_users;
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['type_customer'] = $this->appointmentModel->type_customer;
                        $this->data['appointments'] = $this->appointmentModel->get_appointments_filter($data);
                       
                        echo view('\Modules\Qleads\Views\reports\_filter_appointements', $this->data);
                }
                elseif($obj == "queues")
                {
                        $param = $id;
                        
                        $this->data['queues'] = $this->reportsModel->get_queues();
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['status'] = $this->queueModal->stauts;

                        if (isset($param) && $param!=""):
                                echo view('\Modules\Qleads\Views\reports\_param_queues', $this->data);
                        else:
                                echo view('\Modules\Qleads\Views\reports\_queues', $this->data);
                        endif;
                }
                elseif($obj == "filter_queues")
                {
                        $param = $id;
                        
                        $this->data['queues'] = $this->reportsModel->get_filter_queues($_POST);
                        $this->data['categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['status'] = $this->queueModal->stauts;

                        if (isset($param) && $param!=""):
                                echo view('\Modules\Qleads\Views\reports\_param_filterqueues', $this->data);
                        else:
                                echo view('\Modules\Qleads\Views\reports\_filter_queues', $this->data);
                        endif;
                }
                elseif($obj == "ads")
                {
                        $param = $id;
                        
                        $this->data['ads'] = $this->reportsModel->get_ads();
                        $this->data['priorites'] = $this->adsModal->priorites;
                        $this->data['types'] = $this->adsModal->types;
                        $this->data['devices'] = $this->equipmentModal->get_dropdown("equipments");
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        $this->data['status'] = $this->reportsModel->stauts;
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Qleads\Views\reports\_param_ads', $this->data);
                        else:
                                echo view('\Modules\Qleads\Views\reports\_ads', $this->data);
                        endif;
                }
                elseif($obj == "filter_ads")
                {
                        $param = $id;
                        
                        $this->data['ads'] = $this->reportsModel->get_filter_ads($_POST);
                        $this->data['priorites'] = $this->adsModal->priorites;
                        $this->data['types'] = $this->adsModal->types;
                        $this->data['devices'] = $this->equipmentModal->get_dropdown("equipments");
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        $this->data['status'] = $this->reportsModel->stauts;
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Qleads\Views\reports\_param_filterads', $this->data);
                        else:
                                echo view('\Modules\Qleads\Views\reports\_filter_ads', $this->data);
                        endif;
                }
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                
        }
}

/* End of file   */
/* Location: /  */