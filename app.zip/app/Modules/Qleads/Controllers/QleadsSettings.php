<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\QleadAdsModel;
use Modules\Admin\Models\QleadEquipmentModel;
use Modules\Admin\Models\UserQleadModel;
use Modules\Logiref\Models\LogirefModel;


class QleadsSettings extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = 'queues';
        public $mainModel;
        public $categorieModal;
        public $queueModal;
        public $branchModel;
        public $logirefModel;
        public $adsModal;
        public $equipmentModal;
        public $usersqleadsModal;
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->categorieModal = new QleadCategoryModel();
                $this->queueModal = new QleadQueueModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->adsModal = new QleadAdsModel();
                $this->equipmentModal = new QleadEquipmentModel();
                $this->usersqleadsModal = new UserQleadModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'qleadsqueue';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                //$this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['sidebar'] = "";
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
		$this->data['subview'] = '\Modules\Qleads\Views\container';

                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                $this->data['sidebar'] = '';
                $this->index();
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "queue")
                {
                        $branchid = $_SESSION['Branchid'];

                        $queue = $this->queueModal->get_queue_info($id);
                        
                        #$branchid = $queue->Branchid_7;
                        $type_queue = $queue->Vip_15;
                        
                        $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                        if (!empty($queues))
                        {
                                foreach ($queues as $row)
                                {
                                        if ($id != $row->Id_0):
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        endif;
                                }
                                
                                #Codes guichet 
                                $code = implode(',', $codes);
                                $teller_codes = explode(',', $code);

                                $tellers = $this->queueModal->tellers;

                                foreach ($teller_codes as $row):
                                        unset($tellers[$row]);
                                endforeach;

                                #Categories 
                                $categorie = implode(',', $categories);
                                $categories = explode(',', $categorie);

                                $sub_categories = $this->categorieModal->get_dropdown('categories');

                                foreach ($categories as $categorie):
                                        unset($sub_categories[$categorie]);
                                endforeach;

                        }
                        else
                        {
                                $tellers = $this->queueModal->tellers;
                                $sub_categories = $this->categorieModal->get_dropdown('categories');
                        }
                        
                        $data_users = array();
                        
                        $users_qleads = $this->usersqleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        
                        $this->data['users'] = $data_users;
                        $this->data['tellers'] = $tellers;
                        $this->data['subcategory'] = $sub_categories;
                        $this->data['queue'] = $queue;
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['sequences'] = $this->queueModal->sequences;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['branchid'] = $branchid;
                        
                        echo view('\Modules\Qleads\Views\settings\_queue', $this->data);
                }
                elseif($obj == "categorie")
                {
                        $branchid = $_SESSION['Branchid'];
                        
                        $this->data['branchid'] = $branchid;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('category');
                        $this->data['types'] = $this->categorieModal->types;
                        $this->data['categorie'] = $this->categorieModal->get_categorie_info($id);
                        echo view('\Modules\Qleads\Views\settings\_categorie', $this->data);
                }
                elseif($obj == "ad")
                {
                        $branchid = $_SESSION['Branchid'];
                        $regions =  $this->branchModel->get_dropdown("regions");
                        
                        $this->data['regionid'] = isset($regions[$branchid]) ? $regions[$branchid] : "";
                        $this->data['branchid'] = $branchid;
                        $this->data['ad'] = $this->adsModal->get_ads_info($id);
                        $this->data['priorites'] = $this->adsModal->priorites;
                        $this->data['types'] = $this->adsModal->types;
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        $this->data['guichets'] =  $this->branchModel->get_dropdown("guichets");
                        $this->data['devices'] = $this->equipmentModal->get_dropdown("equipment_branch", $branchid);

                        echo view('\Modules\Qleads\Views\settings\_ad', $this->data);
                        
                }
                elseif($obj == 'dropdowns')
                {
                        $param = $id;
                        
                        if ($param == "queue")
                        {    
                                $codes = [];
                                $categories = [];
                                
                                $branchid = $_POST['branchid'];
                                $type_queue = $_POST['type_queue'];

                                $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                                if (!empty($queues))
                                {
                                        foreach ($queues as $row)
                                        {
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        }

                                        //codes guichet 
                                        $code = implode(',', $codes);
                                        $teller_codes = explode(',', $code);

                                        $tellers = $this->queueModal->tellers;

                                        foreach ($teller_codes as $row)
                                        {
                                                unset($tellers[$row]);
                                        }
                                        
                                        //categories 
                                        $categorie = implode(',', $categories);
                                        $categories = explode(',', $categorie);

                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                        
                                        foreach ($categories as $categorie)
                                        {
                                                unset($sub_categories[$categorie]);
                                        }
                                       
                                }
                                else
                                {
                                        $tellers = $this->queueModal->tellers;
                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                }   

                                $guichet_dropdown = form_dropdown('Tellerslist_9[]', $tellers, '', ' id="guichet"  class="select2_teller form-control  dropdow-width"  multiple="multiple" id="select2" required="required"');
                                $categories_dropdown = form_dropdown('Categorieslist_8[]', $sub_categories, '', ' class="select2_category select2 form-control  dropdow-width" multiple="multiple" id="categorie"  required="required"');

                                $result["guichets"] = $guichet_dropdown;
                                $result["categories"] = $categories_dropdown;

                                return json_encode($result);
                        }    
                        elseif($param=="guichets")
                        {
                                $data_guichets = array();
                                
                                $guichets = $_POST['guichets'];
                                
                                $data_guichets[''] = "";
                                foreach ($guichets as $value):
                                        $data_guichets[$value] = $value;
                                endforeach; 
                                
                                $guichet_dropdown = form_dropdown('Tellercode_10', $data_guichets, '', ' id="guichet_user" class="form-control  dropdow-width" required="required"');
                                
                                $result["guichets"] = $guichet_dropdown;
                                
                                return json_encode($result);
                        }  
                }
                #Default
                if($obj == "deny")
                {
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $data = $_POST;
                
                if($obj == "queue")
                {
                        $data_users = array();
                        
                        if($data['Branchid_7']=='' || $data['Categorieslist_8']=='' || $data['Tellerslist_9']=='' || $data['Sequence_10']=='' || $data['Opening_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $data['Categorieslist_8'] = array_filter($data['Categorieslist_8']);
                        $data['Categorieslist_8'] = implode(",", $data['Categorieslist_8']);

                        $data['Tellerslist_9'] = array_filter($data['Tellerslist_9']);
                        $data['Tellerslist_9'] = implode(",", $data['Tellerslist_9']);
                        
                        $data_users['Userid_7'] =$data['Userid_7'];
                        $data_users['Tellercode_10']=$data['Tellercode_10'];
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                $data['Makerid_13']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                $data['Checkerid_14']=$this->session->userdata['user_id'];

                        }
                        
                        unset($data['Userid_7']);
                        unset($data['Tellercode_10']);
                      
                        #Database
                        $cid = $this->queueModal->save_queue($data, $id);  
                        
                        if ($cid):
                                $data_users['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_users['Changer_6 '] = $this->session->userdata['user_id'];
                                $data_users['Queueid_11 '] = $cid;

                                $qid = $this->usersqleadsModal->update_users($data_users, $data_users['Userid_7']);
                        endif;
                        
                        
                        if($qid): 
                                echo '<div class="alert alert-success">Bravo! la file d\'attente est enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "categorie")
                {
                        if($data['Object_7']=='' || $data['Title_8']=='' || $data['Description_9']=='' || $data['Maxtime_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $cid = $this->categorieModal->save_categorie($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! catégorie enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "ads")
                {

                        #var_dump($data); die;
                        if($data['Type_10']=='' || $data['Branchid_7']=='' || $data['Device_9']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        #File attachment
                        if(isset($_FILES["Contentmedia"]["name"]) && $_FILES["Contentmedia"]["name"] !=""):

                                $account_id = $this->session->userdata['account_id'];
                                $ref = date('H').date('i').date('s').date('m').date('j').date('Y');
                                $target_dir = "./drive/qleads/".$account_id."/ads/".date('Y-m').'/'.$ref;

                                if(is_dir($target_dir)== false)
                                {
                                        mkdir($target_dir, 0777, true);
                                }

                                $target_file = $target_dir.basename($_FILES['Contentmedia']['name']);
                                $target_file = str_replace(" ", "", $target_file);

                                if(move_uploaded_file($_FILES['Contentmedia']["tmp_name"], $target_file)):
                                        $data['Content_11'] = $target_file;
                                endif;

                        elseif (isset($data['Contenttext']) && $data['Contenttext'] !=""):
                                $data['Content_11'] = $data['Contenttext'];
                        elseif (isset($data['ContentOnline']) && $data['ContentOnline']!=""):
                                $data['Content_11'] = $data['ContentOnline'];
                        endif;
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                
                                if(isset($_FILES["Contentmedia"]["name"]) && $_FILES["Contentmedia"]["name"] !=""):
                                    
                                        $ad = $this->adsModal->get_ads_info($id);
                                        $file_name = $ad->Content_11;
                                        
                                        unlink(FCPATH . ''. $file_name);
                                endif;
                                
                                unset($data['File_name']);
                        }

                        unset($data['Contenttext']);
                        unset($data['ContentOnline']);

                        #Database
                        $cid = $this->adsModal->save_ads($data, $id);  
                        
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! les données sont enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_queue")
                {
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $cid = $this->queueModal->delete_queue($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">File d\'attente est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_categorie")
                {
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $cid = $this->categorieModal->delete_categorie($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Catégorie est supprim&eacute;e avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_ads")
                {
                        
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                        
                        $cid = $this->adsModal->delete_ads($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">L\'element est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
       
        }
}

/* End of file   */
/* Location: /  */