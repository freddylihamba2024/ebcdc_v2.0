<?php 
namespace Modules\Qleads\Controllers;


use App\Controllers\BaseController;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\UserQleadModel;
use Modules\Qleads\Models\AppointmentModel;
use Modules\Admin\Models\BranchModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Qleads\Models\CustomerModel;
use Modules\Qleads\Models\TokensModel;
use Modules\Admin\Models\QleadUsersModel;


class QleadsQueue extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = 'queues';
        public $appointmentModel;
        public $categorieModal;
        public $queueModal;
        public $usersqleadsModal;
        public $qleadusersModal;
        public $mainModel;
        public $customerModel;
        public $tokenModel;
        public $branchModel;
        public $logirefModel;
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->categorieModal = new QleadCategoryModel();
                $this->queueModal = new QleadQueueModel();
                $this->qleadusersModal = new QleadUsersModel();
                $this->usersqleadsModal = new UserQleadModel();
                $this->mainModel = new MainModel();
                $this->customerModel = new CustomerModel();
                $this->tokenModel = new TokensModel();
                $this->appointmentModel = new AppointmentModel();  
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'qleadsqueue';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                //$this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['sidebar'] = "";
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
		$this->data['subview'] = '\Modules\Qleads\Views\container';

                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                $this->data['sidebar'] = '';
                $this->index();
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "queues")
                {
                        $param = $id;
                        
                        $this->data['queues'] = $this->queueModal->get_queues();
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\queues\_queues', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\queues\queues', $this->data);
                        endif;

                }
                elseif($obj == "queue")
                {
                        $branchid = $_SESSION['Branchid'];

                        $queue = $this->queueModal->get_queue_info($id);
                        
                        #$branchid = $queue->Branchid_7;
                        $type_queue = $queue->Vip_15;
                        
                        $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                        if (!empty($queues))
                        {
                                foreach ($queues as $row)
                                {
                                        if ($id != $row->Id_0):
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        endif;
                                }
                                
                                #Codes guichet 
                                $code = implode(',', $codes);
                                $teller_codes = explode(',', $code);

                                $tellers = $this->queueModal->tellers;

                                foreach ($teller_codes as $row):
                                        unset($tellers[$row]);
                                endforeach;

                                #Categories 
                                $categorie = implode(',', $categories);
                                $categories = explode(',', $categorie);

                                $sub_categories = $this->categorieModal->get_dropdown('categories');

                                foreach ($categories as $categorie):
                                        unset($sub_categories[$categorie]);
                                endforeach;

                        }
                        else
                        {
                                $tellers = $this->queueModal->tellers;
                                $sub_categories = $this->categorieModal->get_dropdown('categories');
                        }
                        
                        $data_users = array();
                        
                        $users_qleads = $this->usersqleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        
                        $this->data['users'] = $data_users;
                        $this->data['tellers'] = $tellers;
                        $this->data['subcategory'] = $sub_categories;
                        $this->data['queue'] = $queue;
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['sequences'] = $this->queueModal->sequences;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['branchid'] = $branchid;
                        
                        echo view('\Modules\Qleads\Views\queues\_queue', $this->data);
                }
                elseif($obj == "toggle_queue")
                {
                        $branchid = $_SESSION['Branchid'];
                        
                        $this->data['token'] = $token =  $this->tokenModel->get_token_info($id);
                        
                        $queuing =  $this->queueModal->get_queuing_by_id($token->Queueid_23);

                        $current_queueid = $queuing->Queueid_7;
                        $queue =  $this->queueModal->get_queue_info($current_queueid);
                        $current_type = $queue->Vip_15;

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        $queues = $this->queueModal->get_queues_by_branch($branchid);
                        foreach ($queues as $row):
                                if (!($row->Id_0 == $current_queueid && $current_type == $row->Vip_15)):
                                        $ddmenu[$row->Id_0 ] = "File ".$row->Id_0 ;
                                endif;
                        endforeach;
                       
                        $this->data['queues'] = $ddmenu;
                        $this->data['categories'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['priorites'] = $this->queueModal->priorites;
                        $this->data['current_type'] = $current_type;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['branchid'] = $branchid;
                        $this->data['queuing'] = $queuing;

                        
                        echo view('\Modules\Qleads\Views\queues\_toggle_queue', $this->data);
                }
                elseif($obj == 'dropdowns')
                {
                        $param = $id;
                        
                        if ($param == "queue")
                        {    
                                $codes = [];
                                $categories = [];
                                
                                $branchid = $_POST['branchid'];
                                $type_queue = $_POST['type_queue'];

                                $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                                if (!empty($queues))
                                {
                                        foreach ($queues as $row)
                                        {
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        }

                                        //codes guichet 
                                        $code = implode(',', $codes);
                                        $teller_codes = explode(',', $code);

                                        $tellers = $this->queueModal->tellers;

                                        foreach ($teller_codes as $row)
                                        {
                                                unset($tellers[$row]);
                                        }
                                        
                                        //categories 
                                        $categorie = implode(',', $categories);
                                        $categories = explode(',', $categorie);

                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                        
                                        foreach ($categories as $categorie)
                                        {
                                                unset($sub_categories[$categorie]);
                                        }
                                       
                                }
                                else
                                {
                                        $tellers = $this->queueModal->tellers;
                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                }   

                                $guichet_dropdown = form_dropdown('Tellerslist_9[]', $tellers, '', ' id="guichet"  class="select2_teller form-control  dropdow-width"  multiple="multiple" id="select2" required="required"');
                                $categories_dropdown = form_dropdown('Categorieslist_8[]', $sub_categories, '', ' class="select2_category select2 form-control  dropdow-width" multiple="multiple" id="categorie"  required="required"');

                                $result["guichets"] = $guichet_dropdown;
                                $result["categories"] = $categories_dropdown;

                                return json_encode($result);
                        }    
                        elseif($param=="guichets")
                        {
                                $data_guichets = array();
                                
                                $guichets = $_POST['guichets'];
                                
                                $data_guichets[''] = "";
                                foreach ($guichets as $value):
                                        $data_guichets[$value] = $value;
                                endforeach; 
                                
                                $guichet_dropdown = form_dropdown('Tellercode_10', $data_guichets, '', ' id="guichet_user" class="form-control  dropdow-width" required="required"');
                                
                                $result["guichets"] = $guichet_dropdown;
                                
                                return json_encode($result);
                        }  
                        elseif($param=="toggle_queue")
                        {
                                $data_users = array();
                                
                                $branchid = $_SESSION['Branchid'];
                                $queueid = $_POST['queueid'];
                                
                                $users_queue =  $this->queueModal->get_dropdown("user_queue",$branchid);
                                $users_qleads = $this->qleadusersModal->get_users_by_branchid();
                                $users_main = $this->mainModel->get_dropdown("users");

                                $data_users[''] = '';
                                foreach ($users_qleads as $user):
                                        $data_users[$user->Userid_7] = $users_main[$user->Userid_7];
                                endforeach;

                                if ($_SESSION['Qleads_role'] == '3'):
                                        $user_id = $this->session->userdata['user_id'];
                                        unset($data_users[$user_id]);
                                endif;
                                
                                $users[''] = '';
                                foreach ($users_queue[$queueid] as $value):
                                        $values[$value] = $value;
                                        $users[$value] = $data_users[$value];
                                endforeach;

                                $users_dropdown = form_dropdown('Userid[]', $users, $values, ' id="user" class="select2  form-control dropdow-width" multiple="multiple" disabled required="required"');

                                $result["users"] = $users_dropdown;
                                
                                return json_encode($result);
                        }
                }
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $data = $_POST;
                
                if($obj == "queue")
                {
                        $data_users = array();
                        
                        if($data['Branchid_7']=='' || $data['Categorieslist_8']=='' || $data['Tellerslist_9']=='' || $data['Sequence_10']=='' || $data['Opening_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $data['Categorieslist_8'] = array_filter($data['Categorieslist_8']);
                        $data['Categorieslist_8'] = implode(",", $data['Categorieslist_8']);

                        $data['Tellerslist_9'] = array_filter($data['Tellerslist_9']);
                        $data['Tellerslist_9'] = implode(",", $data['Tellerslist_9']);
                        
                        $data_users['Userid_7'] =$data['Userid_7'];
                        $data_users['Tellercode_10']=$data['Tellercode_10'];
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                $data['Makerid_13']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                $data['Checkerid_14']=$this->session->userdata['user_id'];

                        }
                        
                        unset($data['Userid_7']);
                        unset($data['Tellercode_10']);
                      
                        #Database
                        $cid = $this->queueModal->save_queue($data, $id);  
                        
                        if ($cid):
                                $data_users['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_users['Changer_6 '] = $this->session->userdata['user_id'];
                                $data_users['Queueid_11 '] = $cid;

                                $qid = $this->usersqleadsModal->update_users($data_users, $data_users['Userid_7']);
                        endif;
                        
                        
                        if($qid): 
                                echo '<div class="alert alert-success">Bravo! la file d\'attente est enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "toggle_queue")
                {
                        if($data['Queue']=='' || $data['Priority_25']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $item = 1;
                        $index = 0;
                        
                        $queuingid = $data['Queuingid'];
                        $queueid = $data['Queueid'];
                        $branchid = $data['Branchid'];
                        $current_token = $data['Token'];
                        $tokenid = $data['Tokenid'];

                        # File d'attente courante
                        $current_queueing  =  $this->queueModal->get_queuing_by_id($queuingid);
                        
                        if(isset($current_queueing->Tokenlist_15) || !empty($current_queueing->Tokenlist_15)):
                                $current_tokenslist = json_decode($current_queueing->Tokenlist_15, true);
                        else:
                                $current_tokenslist = array();
                        endif;
               
                        $token_removed_queue = array();
                        foreach ($current_tokenslist  as $key => $tokenslist):
                                $token_codes = $tokenslist["queue"].$tokenslist["token"];

                                if ($token_codes == $current_token):
                                        $index = $key;
                                        $token_removed_queue = $tokenslist;
                                endif;
                        endforeach;
                                                
                        # Remove the element at the specified index
                        array_splice($current_tokenslist, $index, 1);
                        
                        $data_current_queuing['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data_current_queuing['Changer_6 '] = $this->session->userdata['user_id'];
                        
                        $data_current_queuing['Totalpeople_8'] = $current_queueing->Totalpeople_8 - 1;
                        $data_current_queuing['Tokenlist_15'] = json_encode($current_tokenslist, JSON_PRETTY_PRINT);
                        
                        $data_current_queuing['Tokenremove_21'] = substr($current_token, 1);
                        
                        $cid = $this->queueModal->update_queuing($data_current_queuing, $queuingid);
                        
                        if ($cid):
                                                        
                                #File d'attente basculée
                                $toggle_queue = $this->queueModal->get_queuing_by_queueid($data['Queue'],$branchid);
                        
                                $data_token['Priority_25'] = $data['Priority_25'];
                                $data_token['Queueid_23'] = $toggle_queue->Id_0;

                                $this->queueModal->update_token($data_token, $tokenid);

                                $data_toggle_queuing['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_toggle_queuing['Changer_6 '] = $this->session->userdata['user_id'];
                                $data_toggle_queuing['Totalpeople_8'] = $toggle_queue->Totalpeople_8 + 1;

                                $toggle_tokenlist = $toggle_queue->Tokenlist_15;

                                #$lasttoken2 = intval($toggle_queue->Lasttoken_14);
                                #$result_lasttoken2 = $lasttoken2 + $item;
                                #$formatted_result2 = sprintf('%04d', $result_lasttoken2);

                                #$data_toggle_queuing['Lasttoken_14'] =  $formatted_result2;
                                
                                $token_removed_queue['queueid'] = $data['Queue'];
                                $token_removed_queue['toggle'] = $data['Priority_25'];

                                $toggle_tokenlist = json_decode($toggle_tokenlist, true);

                                if (isset($data['Priority_25']) && $data['Priority_25']=="P1"):
                                        # Add the removed element at the beginning of the new array
                                        array_unshift($toggle_tokenlist, $token_removed_queue);
                                endif;
                                
                                if (isset($data['Priority_25']) && $data['Priority_25']=="P0"):
                                        # Add the removed element at the end of the new array
                                        $toggle_tokenlist[] = $token_removed_queue;
                                endif;

                                $data_toggle_queuing['Tokenlist_15'] = json_encode($toggle_tokenlist, JSON_PRETTY_PRINT);
                                $data_toggle_queuing['Tokentoggle_20'] = substr($current_token, 1);

                                $qid = $this->queueModal->update_queuing($data_toggle_queuing, $toggle_queue->Id_0);
                            
                        endif;
                        
                        if($qid): 
                                echo '<div class="alert alert-success">Bravo! le client est basculé à une autre file d\'attente avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_queue")
                {
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $cid = $this->queueModal->delete_queue($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">File d\'attente est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
       
        }
}

/* End of file   */
/* Location: /  */