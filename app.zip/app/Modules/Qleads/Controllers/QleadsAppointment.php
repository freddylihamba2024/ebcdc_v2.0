<?php 
namespace Modules\Qleads\Controllers;


use App\Controllers\BaseController;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\QleadUsersModel;
use Modules\Qleads\Models\AppointmentModel;
use Modules\Admin\Models\BranchModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Qleads\Models\CustomerModel;
use Modules\Qleads\Models\TokensModel;

class QleadsAppointment extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('appointments','','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = 'appointments';
        public $appointmentModel;
        public $categorieModal;
        public $queueModal;
        public $usersQleadsModal;
        public $mainModel;
        public $customerModel;
        public $branchModel;
        public $logirefModel;
        public $tokensModel;
        

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->categorieModal = new QleadCategoryModel();
                $this->queueModal = new QleadQueueModel();
                $this->usersQleadsModal = new QleadUsersModel();
                $this->mainModel = new MainModel();
                $this->customerModel = new CustomerModel();
                $this->appointmentModel = new AppointmentModel();  
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->tokensModel = new TokensModel();

                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'qleadsappointment';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                //$this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['sidebar'] = "";
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
		$this->data['subview'] = '\Modules\Qleads\Views\container';

                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                $this->data['sidebar'] = '';
                $this->index();
	}
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "appointment")
                {         
                        $data_users = array();
                        
                        $users_qleads = $this->usersQleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;

                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        
                        $this->data['users'] = $data_users;
                        $this->data['type_customer'] = $this->queueModal->type_queues;
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('sub_categories');
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['appointment'] = $this->appointmentModel->get_appointment_info($id); 
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
 
                        echo view('\Modules\Qleads\Views\appointments\_appointment', $this->data);
                        
                } 
                elseif($obj == "appointment_operator")
                {         
                        $this->data['token'] = $token = $this->tokensModel->get_token_info($id);

                        $this->data['type_customer'] = $this->queueModal->type_queues;
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('sub_categories');
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['villes'] = $this->branchModel->get_dropdown("villes");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
 
                        echo view('\Modules\Qleads\Views\appointments\_appointment_operator', $this->data);
                        
                }
                elseif($obj == "appointments")
                {
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['appointments'] = $this->appointmentModel->get_appointement();
                        echo view('\Modules\Qleads\Views\appointments\appointments', $this->data);
                }
                elseif($obj == "appointments_teller")
                {

                        $this->data['appointments'] = $this->appointmentModel->get_appointement_teller();
                       
                        echo view('\Modules\Qleads\Views\appointments\appointments_teller', $this->data);
                        var_dump("semiaaaaaaa");die;
                }
                elseif($obj == "preview_appoint")
                {
                        $data_users = array();
                        
                        $users_qleads = $this->usersQleadsModal->get_users_by_branchid();
                        $users = $this->mainModel->get_dropdown("users");
                        
                        $data_users[''] = '';
                        foreach ($users_qleads as $user):
                                $data_users[$user->Userid_7] = $users[$user->Userid_7];
                        endforeach;
                       
                        if ($_SESSION['Qleads_role'] == '3'):
                                $user_id = $this->session->userdata['user_id'];
                                unset($data_users[$user_id]);
                        endif;
                        
                        $this->data['users'] = $data_users;
                        $this->data['type_customer'] = $this->queueModal->type_queues;
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('sub_categories');
                        $this->data['status'] = $this->appointmentModel->status;
                        $this->data['appointement'] = $this->appointmentModel->get_appointment_info($id);  

                        $this->data('preview_appoint', $id);
                        
                        echo view('\Modules\Qleads\Views\appointments\_preview_appoint', $this->data);

                        
                }   
                elseif($obj == 'dropdowns')
                {
                        $ville = $id;
                        $guichets =  $this->branchModel->get_dropdown("guichets", "ville", $ville);

                        $guichets = !empty($guichets) ? $guichets : [];

                        echo form_dropdown('Branchid_7', $guichets, "", ' id="guichet" class="form-control" required="required"');
                }

             
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $data = $_POST;

                if($obj == "appointment")
                 {
                        if($data['Category_9']=='' || $data['Cellphone_12']==''|| $data['Email_13']==''|| $data['Customerdate_14']==''|| $data['Customertime_15']==''|| $data['Branchid_7']==''|| $data['Town_25']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        $data['Name_10'] = $data['Firstname']. " ". $data['Lastname'];
                        //$data['Cellphone_12'] = "0".$data['Cellphone_12'];

                        if($id==NULL || $id == "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];

                                if ($data['Status_2']==4):
                                        $data['Appointmentcode_16']= $this->data("code_confirmation");
                                endif;

                                $data['Supervisorid_21']= $this->session->userdata['user_id'];
                        }

                        unset($data['Firstname']);
                        unset($data['Lastname']);

                        #Database
                        $cid = $this->appointmentModel->save_appointment($data, $id); 

                        if($cid)
                        { 
                                $smsid = '';

                                if($data['Status_2']==4)
                                { 
                                        $message = "Bonjour Cher Client, votre RDV a été confirmé pour ".$data['Tellerdate_18']." à ".$data['Tellertime_19'].". Présentez-vous au moins 15 munites avant le RDV (Code de confirmation: ".$data['Appointmentcode_16'].").";
                                        $phone = $data['Cellphone_12'];

                                        $smsid = $this->appointmentModel->send_sms($phone, $message);
                                } 
                                elseif($data['Status_2']==3)
                                { 
                                        $message = "Bonjour Cher Client, votre RDV du ".$data['Tellerdate_18']." à ".$data['Tellertime_19']." a été annulé. Votre gestionnaire vous contactera dès possible pour d'autre disposition. Merci.";
                                        $phone = $data['Cellphone_12'];

                                        $smsid = $this->appointmentModel->send_sms($phone, $message);
                                } 

                                echo '<div class="alert alert-success text-white">Bravo! demande enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        }else { 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        }
                 }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj=='code_confirmation')
                {
                        $alphab = "ABCDEFJHIJKLMNOPQRSTUVWXYZ";
                        $letters = str_shuffle($alphab);
                        $letter = substr(str_shuffle($letters), 0, 3);
                        $code_confirm = date('H').$letter.date('j').date('m'); 
                        return $code_confirm;
                }
                elseif($obj== "vipcustomer_exist")
                {
                        $returns = array();
                        
                        $phone = trim($_POST['cellphone']);
                                   
                        $result = $this->customerModel->get_vipcustomers_by_phone($phone);
                        
                        if (!empty($result))
                        {
                                $returns['customer'] =  1;
                                $returns['firstname'] =  $result[0]->Firstname_7; 
                                $returns['lastname'] = $result[0]->Lastname_8;
                                $returns['email'] =  $result[0]->Email_11;

                        }
                        else
                        {
                                $returns['customer'] =  0;
                        }
                        
                        $return = json_encode($returns);
                        
                        echo $return;
                }
                elseif($obj== "categories_vip")
                {
                        $return = array();
                        
                        $categorie = trim($_POST['categorie']);
                       
                        #$sub_categories = $this->categorieModal->get_dropdown('sub_categories');
                        $categories = $this->appointmentModel->get_dropdown('categories_vip');
                        
                        if (isset($categories[$categorie]) && $categories[$categorie] != "")
                        {
                                $return['customer'] =  1;
                        }
                        else
                        {
                                $return['customer'] =  0;
                        }   
                        
                        echo json_encode($return);
                }
                elseif($obj== "preview_appoint")
                {
                        $id = $data;

                        $data_appoint['Status_2'] = '7';
                        $data_appoint['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data_appoint['Changer_6 '] = $this->session->userdata['user_id'];
                        #Database
                        $cid = $this->appointmentModel->save_appointment($data_appoint, $id);
                }

                
                
        }
}

/* End of file   */
/* Location: /  */