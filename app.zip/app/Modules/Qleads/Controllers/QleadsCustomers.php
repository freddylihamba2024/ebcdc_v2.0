<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\CustomerModel;

class QleadsCustomers extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 10.11.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $customerModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                
                $this->customerModel = new CustomerModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = '';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']=='')
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Qleads\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']=='')
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "vip_customer")
                {
                       
                        $this->data['vip_customer'] = $this->customerModel->get_customer_info($id);  
                        echo view('\Modules\Qleads\Views\customers\_vip_customer', $this->data);
                }
                elseif($obj == "queue_vip")
                {
                        $this->data['vip_customers'] = $this->customerModel->get_vip_customers();
                        echo view('\Modules\Qleads\Views\customers\queue_vip', $this->data);
                }
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $data = $_POST;
                        
                if($data['Firstname_7']=='' || $data['Lastname_8']==''  || $data['Cellphone_9']=='0'|| $data['Cellphone_10']=='0'|| $data['Email_11']==''):
                        echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        die;
                endif;
                
                $data['Cellphone_9'] = '0'.trim($data['Cellphone_9']);
                $data['Cellphone_10'] = '0'.trim($data['Cellphone_10']);

                if($id==NULL || $id == "")
                {
                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                        $data['Status_2']=1;
                        $data['Account_3']=$this->session->userdata['account_id'];
                        $data['Creator_4']=$this->session->userdata['user_id'];
                }
                else
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                }
                #Database
                $cid = $this->customerModel->save_vip_customers($data, $id); 
                        
                if($cid): 
                        echo '<div class="alert alert-success text-white">Bravo! demande enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                else: 
                        echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                endif;

               
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                
        }
}

/* End of file   */
/* Location: /  */