<?php 

namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\TokensModel;
use Modules\Admin\Models\BranchModel;
use Modules\Main\Models\MainModel;



class QleadsImpression extends BaseController {
        /*
         * Presentation: gestion des impression(production des documents PDF)
         * Last update:
         * By Glodi on the 20.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $tokenModel;
        public $mainModel;
        public $branchModel;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->tokenModel = new TokensModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = '';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Qleads_role'];
                $this->data['sidebar'] = '';
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = ''; 
                
                #var_dump($this->data['userid']);die;
	} 
	
	public function index()
	{
                if($_SESSION['Qleads_role']=='')
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Qleads\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Qleads_role']=='')
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "print_form001")
                {
                        $categoryid = $id;
                        $tokenid = $arg;
                        
                        $province = $_SESSION["Logiref_province"];
                       
                        $user_id = $this->session->userdata['user_id'];	
                        $users = $this->mainModel->get_dropdown('users_array');

                        $this->data['user'] = $users[$user_id];
                        $this->data['eform'] = $eform = $this->tokenModel->get_eform_by_branch($tokenid, $categoryid);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['token'] = $this->tokenModel->get_token_info($tokenid);
                        $this->data['type_compte'] = $this->tokenModel->type_compte;
                        $this->data['devise_compte'] = $this->tokenModel->devise_compte;
                        $this->data['sex'] = [''=>'', 'M'=>'Mr.', 'F'=>'Mme.'];

                        
                        if(isset($eform[0]->Formdata_11) && $eform[0]->Formdata_11 !="")
                        {
                                $infos = json_decode($eform[0]->Formdata_11, true);

                                if(is_string($infos))
                                {
                                        $infos = json_decode($infos);
                                }
                        }
                        else
                        {
                                $infos = array();
                        }
                        
                        $montant_total = isset($infos->montant_total) ? $infos->montant_total : "0";
                        $devise = isset($infos->devise) ? $infos->devise : "";
                        
                        $this->data['number_letter'] = $this->data('number_letter',$montant_total, $infos->devise);
                        
                        $html =  view('\Modules\Qleads\Views\impression\_print_form001', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        	
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        $imagePath = base_url('ikwook_files/logos/rawbank.png');

                        $numero = rand(0, 99).date('H').date('i').date('s');
                        
                        // Définir le contenu du header avec l'image
                        $header = '<div style="text-align: left;"><img src="' . $imagePath . '" style="width: 200px; margin-top:-20px;"></div>';
                        $header .= '<div style="text-align: right; margin-top:-50px;">'.ucfirst(strtolower($province)).' , le '.  date("d/m/Y").'</div>';

                        $this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        $this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        
                        $this->mpdf->SetHTMLHeader($header);
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                if($obj == "print_form005")
                {
                        $categoryid = $id;
                        $tokenid = $arg;
                        
                        $province = $_SESSION["Logiref_province"];
                       
                        $user_id = $this->session->userdata['user_id'];	
                        $users = $this->mainModel->get_dropdown('users_array');

                        $this->data['user'] = $users[$user_id];
                        $this->data['eform'] = $eform = $this->tokenModel->get_eform_by_branch($tokenid, $categoryid);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['token'] = $this->tokenModel->get_token_info($tokenid);
                        $this->data['type_compte'] = $this->tokenModel->type_compte;
                        
                        if(isset($eform[0]->Formdata_11) && $eform[0]->Formdata_11 !="")
                        {
                                $infos = json_decode($eform[0]->Formdata_11, true);

                                if(is_string($infos))
                                {
                                        $infos = json_decode($infos);
                                }
                        }
                        else
                        {
                                $infos = array();
                        }
                        
                        $montant_total = isset($infos->montant_total) ? $infos->montant_total : "0";
                        $devise = isset($infos->devise) ? $infos->devise : "";
                        
                        $this->data['number_letter'] = $this->data('number_letter',$montant_total, $infos->devise);

                        $html =  view('\Modules\Qleads\Views\impression\_print_form005', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        	
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        $imagePath = base_url('ikwook_files/logos/rawbank.png');

                        $numero = rand(0, 99).date('H').date('i').date('s');
                        
                        // Définir le contenu du header avec l'image
                        $header = '<div style="text-align: left;"><img src="' . $imagePath . '" style="width: 200px; margin-top:-20px;"></div>';
                        $header .= '<div style="text-align: right; margin-top:-50px;">'.ucfirst(strtolower($province)).' , le '.  date("d/m/Y").'</div>';

                        $this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        $this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        
                        $this->mpdf->SetHTMLHeader($header);
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                elseif($obj == "print_form006")
                {
                        $categoryid = $id;
                        $tokenid = $arg;
                       
                        $user_id = $this->session->userdata['user_id'];	
                        $users = $this->mainModel->get_dropdown('users_array');

                        $this->data['user'] = $users[$user_id];
                        $this->data['province'] = $_SESSION["Logiref_province"];
                        $this->data['eform'] = $eform = $this->tokenModel->get_eform_by_branch($tokenid, $categoryid);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        
                        if(isset($eform[0]->Formdata_11) && $eform[0]->Formdata_11 !="")
                        {
                                $infos = json_decode($eform[0]->Formdata_11, true);

                                if(is_string($infos))
                                {
                                        $infos = json_decode($infos);
                                }
                        }
                        else
                        {
                                $infos = array();
                        }
                        
                        $montant_total = isset($infos->montant_total) ? $infos->montant_total : "0";
                        $devise = isset($infos->devise) ? $infos->devise : "";
                        
                        $this->data['number_letter'] = $this->data('number_letter',$montant_total, $infos->devise);
                        
                        $html =  view('\Modules\Qleads\Views\impression\_print_form006', $this->data);
                        
                        $account_id = $this->session->userdata['account_id'];
                        	
                        $pdfFilePath = "./drive/logiref/".$account_id."/".$id."_".$user_id."_".time().".pdf";
                        
                        $imagePath = base_url('ikwook_files/logos/rawbank.png');

                        $numero = rand(0, 99).date('H').date('i').date('s');
                        
                        // Définir le contenu du header avec l'image
                        $header = '<div style="text-align: left;">N°'.$numero.'</div>';
                        $header .= '<div style="text-align: center;"><img src="' . $imagePath . '" style="width: 200px; margin-top:-20px;"></div>';
                        
                        $this->mpdf->showWatermarkImage = true; // Afficher l'image en arrière-plan
                        $this->mpdf->watermarkImageAlpha = 0.3; // Transparence de l'image (valeur entre 0 et 1)
                        // Extend margins left and right
                        
                        $this->mpdf->SetHTMLHeader($header);
                        
                        //actually, you can pass mPDF parameter on this load() function
                        $this->mpdf->WriteHTML('', 1);
                        $this->mpdf->WriteHTML($html, 2);

                        //offer it to user via browser download! (The PDF won't be saved on your server HDD)
                        //I: standard output  D: Download  F: Save on HDD  S: output as string
                        $this->mpdf->Output($pdfFilePath, 'I');
                        exit;
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->load->view($this->lang . '_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
               if($obj == "number_letter")
               {
                   $value = $this->number_letter->converter($data, $arg);
                   
                   return $value;
               }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */