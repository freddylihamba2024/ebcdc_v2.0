<?php

        namespace Modules\Qleads\Controllers;

        use App\Controllers\BaseController;

        use Modules\Qleads\Models\DashboardModel;
        use Modules\Qleads\Models\TokensModel;
        use Modules\Qleads\Models\ReportsModel;
        use Modules\Main\Models\MainModel;
        use Modules\Admin\Models\BranchModel;
        use Modules\Admin\Models\QleadQueueModel;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Admin\Models\QleadUsersModel;

        class QleadsDashboard extends BaseController {
                /*
                * Presentation: 
                * Last update:
                * By Glodi on the 14.10.2023
                * *  *************************************************************************************************************************SECTION 1
                */
                public $menus = array('overview','qdash','');
                public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
                public $restrictions = 0; //1 = no access or limited access
                public $lang = 'fr';
                public $module = 'qleads';
                public $folder = 'dashboards';
                public $dashboardModel;
                public $tokensModel;
                public $reportsModel;
                public $mainModel;
                public $branchModel;
                public $queueModal;
                public $logirefModel;
                public $qleadUsersModel;


                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is qleads 
                        * function will be set within display function
                        * PS: A modifier au besoin!!
                        */

                        $this->dashboardModel = new DashboardModel();
                        $this->tokensModel = new TokensModel();
                        $this->reportsModel = new ReportsModel();
                        $this->mainModel = new mainModel();
                        $this->branchModel = new BranchModel();
                        $this->queueModal = new QleadQueueModel();
                        $this->logirefModel = new LogirefModel();
                        $this->qleadUsersModel = new QleadUsersModel();

                        if (!isset($_SESSION['Queueid']) || !isset($_SESSION['Tellercode']))
                        {
                                $this->dashboardModel->init_data();
                        }

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'qleadsdashboard';
                        $this->data['function'] = '';
                        $this->data['role'] = '';
                        $this->data['sidebar'] = '';
                        $this->data['lang'] = $this->lang;
                        $this->data['layout_type'] = '';
                }


                public function index()
                {
                        $this->data['subview'] = '\Modules\Qleads\Views\container';

                        echo view('layouts/layout_main', $this->data);
                }


                /*
                * Manages sidebar menu 
                * Must match de third section of the URL
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 2
                */
                public function set($needle)
                {

                        if (in_array($needle, $this->menus)) 
                        {
                                if($needle == "overview"){

                                        if (isset($_SESSION['dashboard']) && $_SESSION['dashboard'] != '' && $_SESSION['dashboard'] != 'main') {

                                                if(isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                                                {
                                                        return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                                }
                                                else
                                                {
                                                        $this->data['sidebar'] = '';
                                                        $this->data['subview'] = '\Modules\Qleads\Views\container';

                                                        echo view('layouts/layout_main', $this->data);
                                                }
                                        }

                                }
                                else{
                                        $this->data['sidebar'] = '';
                                        $this->index();
                                }
                        }

                }

                /*
                * Manages all the views
                * View calls are made here
                * * PS: A personnaliser !!
                * *  *************************************************************************************************************************SECTION 3
                */
                public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {

                        if($obj == "qdash")
                        {

                                if($_SESSION['Qleads_role']==1)
                                {
                                        $this->data['queuing'] = $queuing = $this->dashboardModel->get_queuing();

                                        if(isset($queuing[0]->Tokenlist_15) || !empty($queuing[0]->Tokenlist_15))
                                        {
                                                $tokens = json_decode($queuing[0]->Tokenlist_15, true);
                                        }
                                        else
                                        {
                                                $tokens = [];
                                        }

                                        $this->data['tokens_treated'] = $tokens_treated = $this->tokensModel->get_token_treated();


                                        $this->data['tokens'] = $tokens;

                                        # Verify if there is a token suscetible to be displayed
                                        $loop = true;

                                        foreach ($tokens as $token)
                                        {
                                                if(!empty($tokens_treated))
                                                {
                                                        if(isset($tokens_treated[$queuing[0]->Id_0][$token['token']][$token['queue'] ]))
                                                        {
                                                                $loop= false;
                                                        }
                                                        else
                                                        {
                                                                $loop = true;
                                                                break;
                                                        }
                                                }
                                        }

                                        $this->data['token_to_display'] = $loop;

                                        $this->data['appointment_confirm'] = $this->dashboardModel->get_appointement_confirmed();
                                        $this->data['appointment_recent'] = $this->dashboardModel->get_recent_appointement_confirmed();

                                        $this->data['case_treated'] = $this->dashboardModel->get_counts_cases_treated();
                                        $this->data['appointment'] = $this->dashboardModel->get_counts_number_appointments();
                                        $this->data['tellers'] = $this->dashboardModel->get_survey_average_by_tellerrate();
                                        // $this->data['satisfieds'] = $this->dashboardModel->get_survey_average_by_satisfaction();
                                        $this->data['category'] = $this->tokensModel->get_dropdown("category");
                                        $this->data['subcategory'] = $this->tokensModel->get_dropdown("subcategory");


                                        echo view('\Modules\Qleads\Views\dashboards\qdash_operator', $this->data);
                                }
                                elseif($_SESSION['Qleads_role']==2)
                                {
                                        echo view('\Modules\Qleads\Views\dashboards\qdash', $this->data);
                                }
                                elseif($_SESSION['Qleads_role']==3)
                                {
                                        $branchid = $_SESSION['Branchid'];

                                        $this->data['appointments'] = $this->dashboardModel->get_appointement();
                                        $this->data['recent_appointments'] = $this->dashboardModel->get_recent_appointement();
                                        $this->data['appointment'] = $this->dashboardModel->get_counts_number_appointments();

                                        #$this->data['case_treated'] = $this->dashboardModel->get_counts_cases_treated();
                                        $this->data['case_treated'] = $this->tokensModel->get_count_cases_treated();

                                        $this->data['survey'] = $this->dashboardModel->get_survey_by_agency();
                                        $this->data['queues'] = $this->dashboardModel->get_queuing_sum_by_people();
                                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                                        $this->data['tellers'] = $this->dashboardModel->get_survey_average_by_tellerrate();
                                        //$this->data['satisfieds'] = $this->dashboardModel->get_survey_average_by_satisfaction();
                                        
                                        
                                        $this->data['sequences'] = $this->queueModal->get_dropdown('sequence', $branchid);
                                
                                        $this->data['queueid'] = $this->queueModal->get_dropdown('queueid', $branchid);
                                        
                                        $queuings = $this->tokensModel->get_queuings();

                                        $total_people = 0;
                                        $total_people_today = 0;
                                        $total_people_month = 0;
                                        $total_people_year = 0;
                                        $total_served = 0;
                                        $total_served_today = 0;
                                        $total_served_month = 0;
                                        $total_served_year = 0;
                                        $total_branch = 0;
                                        $branches = array();
                                        $total_queue = 0;
                                        $queues = array();
                                        $total_users = 3;
                                        $queues = array();

                                        foreach($queuings as $row)
                                        {
                                                $total_people += $row->Totalpeople_8;
                                                $total_served += $row->Served_10;

                                                if($row->Opening_11 == gmdate('Y-m-d'))
                                                {
                                                        $total_people_today += $row->Totalpeople_8;
                                                        $total_served_today += $row->Served_10;
                                                        $total_queue ++;
                                                } 

                                                if (str_contains($row->Opening_11, gmdate('Y-m-')))
                                                {
                                                        $total_people_month += $row->Totalpeople_8;
                                                        $total_served_month += $row->Served_10;
                                                } 

                                                if (str_contains($row->Opening_11, gmdate('Y')))
                                                {
                                                        $total_people_year += $row->Totalpeople_8;
                                                        $total_served_year += $row->Served_10;
                                                } 

                                                //Situation des agences
                                                if(!isset($branches[$row->Branchid_16]))
                                                {
                                                        //Nombre des agences
                                                        $total_branch++;
                                                        //Personne en attente
                                                        if($row->Opening_11 == gmdate('Y-m-d'))
                                                        {
                                                                if(!isset($branches[$row->Branchid_16]['total'])) $branches[$row->Branchid_16]['total'] = 0;
                                                                if(!isset($branches[$row->Branchid_16]['served'])) $branches[$row->Branchid_16]['served'] = 0;
                                                                $branches[$row->Branchid_16]['total'] += $row->Totalpeople_8;
                                                                $branches[$row->Branchid_16]['served'] += $row->Served_10;
                                                        }
                                                }  

                                        }

                                        if ($total_people_today > $total_served_today):
                                        $total_waiting = $total_people_today - $total_served_today;
                                        else:
                                                $total_waiting = 0;
                                        endif;

                                        $appointments= $this->dashboardModel->count_appointment_by_type();
                                        $appointment_vip = 0;
                                        $appointment_standard = 0;
                                        if(!empty($appointments)):
                                                foreach($appointments as $val):
                                                        if($val->type == 1) $appointment_vip = $val->total;
                                                        if($val->type == 0) $appointment_standard = $val->total;
                                                endforeach;
                                        endif;

                                        $tokenlist = array();
                                        $queuing = $this->dashboardModel->get_queuing();
                                        foreach ($queuing as $lines):
                                                if(isset($lines->Tokenlist_15) || !empty($lines->Tokenlist_15)):
                                                        $tokenlist[$lines->Id_0] = json_decode($lines->Tokenlist_15, true);
                                                else:
                                                        $tokenlist = [];
                                                endif;
                                        endforeach;

                                        $token_notreated = $this->tokensModel->get_token_notreated();
                                        $this->data['tokenslist'] = $tokenlist;  
                                        $this->data['token_notreated'] = !empty($token_notreated) ? $token_notreated : []; 
                                        $this->data['tokens'] = $this->dashboardModel->get_current_tokens();    
                                        $this->data['token_by_category'] = $this->dashboardModel->count_token_by_category(); 

                                        $this->data['appointment_standard'] = $appointment_standard;
                                        $this->data['appointment_vip'] = $appointment_vip;
                                        $this->data['appointment_by_category'] = $this->dashboardModel->count_appointment_by_category(); 

                                        $this->data['categories'] = $this->tokensModel->get_dropdown("category");

                                        $this->data['total_people'] = $total_people;
                                        $this->data['total_people_today'] = $total_people_today;
                                        $this->data['total_people_month'] = $total_people_month;
                                        $this->data['total_people_year'] = $total_people_year;

                                        $this->data['total_served_month'] = $total_served_month;
                                        $this->data['total_served_today'] = $total_served_today;
                                        $this->data['total_waiting'] =  $total_waiting;

                                        $this->data['total_queue'] =  $total_queue ;
                                        $this->data['total_users'] =  $total_users ;

                                        echo view('\Modules\Qleads\Views\dashboards\qdash_supervisor', $this->data);
                                }
                                elseif($_SESSION['Qleads_role']==5)
                                {

                                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                                        $this->data['latitude'] = $this->logirefModel->get_dropdown("latitude");
                                        $this->data['file'] = $this->logirefModel->get_dropdown("file");
                                        $this->data['longitude'] = $this->logirefModel->get_dropdown("longitude");
                                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                        $this->data['survey'] = $this->dashboardModel->get_survey_by_agency();
                                        $queuing= $this->dashboardModel->get_queuing();

                                        $total_people = 0;
                                        $total_people_today = 0;
                                        $total_people_month = 0;
                                        $total_served = 0;
                                        $total_served_today = 0;
                                        $total_served_month = 0;
                                        $total_branch = 0;
                                        $branches = array();
                                        $total_queue = 0;
                                        $queues = array();
                                        $total_users = 3;
                                        $queues = array();

                                        foreach($queuing as $row)
                                        {
                                                $total_people += $row->Totalpeople_8;
                                                $total_served += $row->Served_10;

                                                if($row->Opening_11 == gmdate('Y-m-d'))
                                                {
                                                        $total_people_today += $row->Totalpeople_8;
                                                        $total_served_today += $row->Served_10;
                                                        $total_queue ++;
                                                } 

                                                if (str_contains($row->Opening_11, gmdate('Y-m-')))
                                                {
                                                        $total_people_month += $row->Totalpeople_8;
                                                        $total_served_month += $row->Served_10;
                                                } 

                                                //Situation des agences
                                                if(!isset($branches[$row->Branchid_16]))
                                                {
                                                        //Nombre des agences
                                                        $total_branch++;
                                                        //Personne en attente
                                                        if($row->Opening_11 == gmdate('Y-m-d'))
                                                        {
                                                                if(!isset($branches[$row->Branchid_16]['total'])) $branches[$row->Branchid_16]['total'] = 0;
                                                                if(!isset($branches[$row->Branchid_16]['served'])) $branches[$row->Branchid_16]['served'] = 0;
                                                                $branches[$row->Branchid_16]['total'] += $row->Totalpeople_8;
                                                                $branches[$row->Branchid_16]['served'] += $row->Served_10;
                                                        }
                                                }  

                                        }

                                        $appointments= $this->dashboardModel->count_appointment_by_type();
                                        $appointment_vip = 0;
                                        $appointment_standard = 0;
                                        if(!empty($appointments)):
                                                foreach($appointments as $val):
                                                        if($val->type == 1) $appointment_vip = $val->total;
                                                        if($val->type == 0) $appointment_standard = $val->total;
                                                endforeach;
                                        endif;

                                        $case_treated = $this->dashboardModel->get_case_treated();
                                        // $satisfied= $this->dashboardModel->get_satisfied();

                                        $this->data['tokens'] = $this->dashboardModel->get_current_tokens();
                                        $this->data['token_by_category'] = $this->dashboardModel->count_token_by_category();
                                        $this->data['appointment_by_category'] = $this->dashboardModel->count_appointment_by_category();
                                        $this->data['categories'] = $this->tokensModel->get_dropdown("category");

                                        $this->data['appointment_standard'] = $appointment_standard;
                                        $this->data['appointment_vip'] = $appointment_vip;
                                        $this->data['case_treated'] = !empty($case_treated) ? count($case_treated): "0";
                                        //$this->data['satisfied'] = !empty($satisfied) ? count($satisfied): "0";
                                        $this->data['total_people'] = $total_people;
                                        $this->data['total_people_today'] = $total_people_today;

                                        $this->data['total_people_month'] = $total_people_month;
                                        $this->data['total_served_month'] = $total_served_month;
                                        $this->data['total_waiting'] =  !empty($this->data['tokens']) ? count($this->data['tokens']): "0";
                                        $this->data['total_served_today'] = $this->data['total_people_today']-$this->data['total_waiting'];

                                        $this->data['total_branch'] =  $total_branch;
                                        $this->data['total_queue'] =  $total_queue ;
                                        $this->data['total_users'] =  $total_users ;

                                        $this->data['branches_infos'] =  $branches;
                                        $this->data['queuing'] = (!empty($queuing))? $queuing : []; 

                                        $this->data['surveys'] = $this->reportsModel->get_surveys();


                                        echo view('\Modules\Qleads\Views\dashboards\qdash', $this->data);
                                }
                                else
                                {
                                        echo view('\Modules\Qleads\Views\dashboards\qdash_operator', $this->data);
                                }
                        }
                        elseif($obj == "overview")
                        {
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['agences'] = $this->branchModel->get_dropdown('agences');
                                $this->data['guichet'] = isset($this->data['guichets'][$this->session->get('Logiref_guichet')])?$this->data['guichets'][$this->session->get('Logiref_guichet')]:"";
                                $this->data['agence']= isset($this->data['agences'][$this->session->get('Logiref_agence')])?$this->data['agences'][$this->session->get('Logiref_agence')]:"";
                                $region = $this->logirefModel->get_region_info($this->session->get('Logiref_region'));
                                $this->data['region'] = (!is_null($region))?$region->Nom_7:'';
                                $this->data['role_user'] = (!empty($_SESSION['roles_banks']))?$_SESSION['roles_banks'][$this->session->get('Logiref_role')]:"";

                                $this->data['paiement_cdf'] = $paiement_cdf = array();//$this->encaissementModel->get_stats("paiement_situation_cdf");
                                $this->data['paiement_usd'] = $paiement_usd = array();//$this->encaissementModel->get_stats("paiement_situation_usd");
                                $this->data['paiement_regie'] = array();//$this->encaissementModel->get_stats("paiement_situation_regie");
                                $this->data['paiement'] = array();//$this->encaissementModel->get_stats("paiement");
                                $this->data['pie_situation_cdf'] = array();//$this->data("pie-chart_operator", $paiement_cdf, "paiement_situation_cdf");
                                $this->data['pie_situation_usd'] = array();//$this->data("pie-chart_operator", $paiement_usd, "paiement_situation_usd");
                                $this->data['right_side']= $id;
                                $this->data['beneficiaires'] = array();//$this->logirefModel->get_dropdown("services", $service=NULL);
                                $this->data['encaissements'] = array();//$this->encaissementModel->get_paiements('penalities');
                                $this->data['guichets'] = array();//$this->encaissementModel->get_dropdown("guichets");

                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                                echo view('\Modules\Main\Views\overview', $this->data);
                        }
                        elseif($obj == "menus") 
                        {
                                $this->data['alerts'] = array();
                                $this->data['surveys'] = $this->reportsModel->get_surveys();
                                echo view('\Modules\Qleads\Views\dashboards\_'.$obj, $this->data);
                        }
                        elseif($obj == "menus_supervisor") 
                        {
                                $this->data['alerts'] = array();
                                $this->data['surveys'] = $this->reportsModel->get_surveys();
                                echo view('\Modules\Qleads\Views\dashboards\_'.$obj, $this->data);
                        }
                        elseif($obj == "menus_director") 
                        {

                                $this->data['alerts'] = array();

                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets","force");
                                $this->data['categories'] = $this->tokensModel->get_dropdown("category");
                                $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                                $this->data['performances'] = $this->reportsModel->get_performance();

                                $this->data['surveys'] = $this->reportsModel->get_surveys();
                                echo view('\Modules\Qleads\Views\dashboards\_'.$obj, $this->data);
                        }

                        #Default
                        if($obj == "deny")
                        {
                                $this->data['denied'] = TRUE;
                                echo view('\Modules\Branch\Views\fr_denial', $this->data);
                        }
                }


                /*
                * Manages all database updates
                * Calls to model's saving methos are made here
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 4
                */
                public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "OBJ ")
                        {

                        }
                }

                /*
                * Manages additional data manipuations
                * Arguments could of any type, arrays or strings
                * PS: A modifier uniquement si c'est necessaire!!
                * *  *************************************************************************************************************************SECTION 5
                */
                public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
                {
                        if($obj == "send_sms")
                        {
                                $token_notreated = $this->tokensModel->get_token_notreated();
                                $message = isset($_GET['Message']) ? $_GET['Message'] : "";
                                
                                $smsid = "";
                                $counter = 0;
                                
                                foreach ($token_notreated as $key => $token):
                                        $counter = $counter +1;
                                        $phone = $token->Cellphone_12;
                                        $smsid = $this->dashboardModel->send_sms($phone, $message);
                                endforeach;
                                
                                if ($counter == count($token_notreated) && $smsid !=""):
                                        $response['code'] = 'E200';
                                        echo json_encode($response);
                                else:
                                        $response['code'] = 'E000';
                                        echo json_encode($response);
                                endif;
                        }
                }
        }

        /* End of file   */
        /* Location: /  */