<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\InquiriesModel;
use Modules\Qleads\Models\TokensModel;

class QleadsInquiries extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 10.11.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $inquiriesModel;
        public $tokenModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->inquiriesModel = new InquiriesModel();
                $this->tokenModel = new TokensModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = '';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = $this->sidebars->logiref_rawbank($_SESSION['Logiref_role']);
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = '';
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']=='')
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Qleads\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']=='')
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "inquiries")
                {
                        $this->data['inquiry'] = $this->inquiriesModel->get_inquiry_info($id);
                        $this->data['status'] = $this->inquiriesModel->inquiry_status;
                        $this->data['token'] = $this->tokenModel->get_dropdown("token");
                        $this->data['categories'] = $this->inquiriesModel->get_dropdown("category");
                        
                        echo view('\Modules\Qleads\Views\inquiries\_inquiries', $this->data);
                }
                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "inquiry")
                {
                        $data = $_POST;
                        
                        if($data['Tokenid_7']=='0' || $data['Categoryid_9']==''  || $data['Name_10']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL || $id == "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        
                        #File attachment
                        if(isset($_FILES["Avmfile_20"]["name"]) && $_FILES["Avmfile_20"]["name"] !="")
                        {
                                $ref = $this->session->userdata['account_id']."_".date('H').date('i').date('s').date('m').date('j').date('Y');
                                $target_dir = './drive/qleads/'.$this->session->userdata['account_id']."/".$ref;
                                
                                if(is_dir($target_dir)== false)
                                {
                                        mkdir($target_dir, 0777, true);
                                }
                                
                                $target_file = $target_dir.basename($_FILES['Avmfile_20']['name']);
                                $target_file = str_replace(" ", "", $target_file);
                                
                                if(move_uploaded_file($_FILES['Avmfile_20']["tmp_name"], $target_file))
                                {
                                        $data['Avmfile_20'] = $target_file;
                                }
                        }
                        
                        #Database
                        $cid = $this->inquiriesModel->save_inquiries($data, $id); 
                        
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! demande enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                
        }
}

/* End of file   */
/* Location: /  */