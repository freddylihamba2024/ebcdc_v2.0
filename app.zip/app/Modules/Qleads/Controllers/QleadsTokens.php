<?php 
namespace Modules\Qleads\Controllers;

use App\Controllers\BaseController;
use Modules\Qleads\Models\TokensModel;
use Modules\Admin\Models\BranchModel;
use Modules\Main\Models\MainModel;
use Modules\Qleads\Models\ReportsModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Qleads\Models\AppointmentModel;


class QleadsTokens extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('','','');
        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'qleads';
        public $folder = '';
        public $tokenModel;
        public $mainModel;
        public $queueModal;
        public $categorieModal;
        public $appointmentModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is qleads 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                
                $this->tokenModel = new TokensModel();
                $this->branchModel = new BranchModel();
                $this->mainModel = new MainModel();
                $this->reportsModel = new ReportsModel();
                $this->queueModal = new QleadQueueModel();
                $this->categorieModal = new QleadCategoryModel();
                $this->appointmentModel = new AppointmentModel(); 
                
                $this->data['module'] = $this->module;
                $this->data['application'] = '';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Qleads_role'];
                $this->data['sidebar'] = '';
                $this->data['lang'] = $this->lang;
                $this->data['layout_type'] = ''; 
	} 
	
        
	public function index()
	{
                if($_SESSION['Qleads_role']=='')
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Qleads\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Qleads_role']=='')
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "token")
                {   
                        $index = $arg;
                       
                        $this->data['token'] = $token = $this->tokenModel->get_token_info($id);
                        #$this->data['eform'] = $eform = $this->tokenModel->get_eform_by_tokenid($id);
                        $this->data['eform'] = $eform = $this->tokenModel->get_eform_by_branch($id, $token->Category_9);

                        $this->data['token_type'] = $this->tokenModel->get_dropdown("token_type");
                        $this->data['token_categories'] = $this->tokenModel->get_dropdown("category");
                        $this->data['eform_categories'] = $this->tokenModel->get_dropdown("category_eforms");
                       
                        $this->data['status'] = $this->tokenModel->status;
                        $this->data['index'] = $index;

                        echo view('\Modules\Qleads\Views\tokens\_token', $this->data);
                }
                elseif($obj == "token_toggle")
                {
                        $branchid = $_SESSION['Branchid'];
                        
                        $this->data['token'] = $token =  $this->tokenModel->get_token_info($id);
                        
                        $queuing =  $this->tokenModel->get_queuing_by_id($token->Queueid_23);

                        $current_queueid = $queuing->Queueid_7;
                        $queue =  $this->queueModal->get_queue_info($current_queueid);
                        $current_type = $queue->Vip_15;

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        $queues = $this->tokenModel->get_queue_by_branch($branchid);
                        foreach ($queues as $row):
                                if (!($row->Id_0 == $current_queueid && $current_type == $row->Vip_15)):
                                        $ddmenu[$row->Id_0 ] = "File ".$row->Id_0 ;
                                endif;
                        endforeach;
                       
                        $this->data['queues'] = $ddmenu;
                        $this->data['categories'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['priorites'] = $this->tokenModel->priorites;
                        $this->data['current_type'] = $current_type;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['branchid'] = $branchid;
                        $this->data['queuing'] = $queuing;

                        
                        echo view('\Modules\Qleads\Views\tokens\_token_toggle', $this->data);
                }
                elseif($obj == "token_qrcode")
                {
                        $token = $this->tokenModel->get_token_info($id);
                        $userid= $this->session->userdata['user_id'];
                        
                        $link = 'http://34.72.60.38/v2/frontend/survey?userid='.$userid.'&tokenid='.$token->Id_0.'&branchid='.$token->Branchid_22.''.'&bankid='.$token->Account_3.''.'&categoryid='.$token->Category_9.'';
                        
                        // Créer un QR Code
                        $qrCode = $this->qrCodeBuilder
                            ->data($link)
                            ->encoding($this->qrCodeEncoding)
                            ->size(256)
                            ->margin(10)
                            ->build();
                        $qrCodeImageString = '';

                        $image = $qrCode->getImage();
                        if ($image instanceof \GdImage) 
                        {
                                ob_start();
                                imagepng($image);
                                $qrCodeImageString = ob_get_clean();
                        }
                        
                        // Encodage en base64 si la chaîne de caractères de l'image est disponible
                        $qrCodeHtml = '<img src="data:image/png;base64,' . base64_encode($qrCodeImageString) . '" alt="QR Code">';
                        $this->data['qrcode'] = $qrCodeHtml;
                        $this->data['link'] = $link;
                        
                        echo view('\Modules\Qleads\Views\tokens\__token', $this->data);
                }

                #Default
                if($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "token")
                {
                        $data = $_POST;
                        $token = $this->tokenModel->get_token_info($id);
                        $userid= $this->session->userdata['user_id'];
                        
                        
                        if( $data['Category_9'] ==''  || $data['Name_10']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $data_token['Status_2'] = isset($data['Status_2']) && $data['Status_2'] !="" ? $data['Status_2'] : "";
                        $data_token['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data_token['Changer_6'] = $this->session->userdata['user_id'];
                        
                        $data_token['Category_9'] = isset($data['Category_9']) && $data['Category_9'] !="" ? $data['Category_9'] : "";
                        $data_token['Name_10'] = isset($data['Name_10']) && $data['Name_10'] !="" ? $data['Name_10'] : "";
                        $data_token['Description_11'] = isset($data['Description_11']) && $data['Description_11'] !="" ? $data['Description_11'] : "";
                        $data_token['Cellphone_12'] = isset($data['Cellphone_12']) && $data['Cellphone_12'] !="" ? $data['Cellphone_12'] : "";

                        $token = $this->tokenModel->get_token_info($id);
                        
                        $data['Startingtime_14'] = $data_token['Startingtime_14'] = $token->Startingtime_14;
                        $data['Endingtime_15'] = $data_token['Endingtime_15'] =  gmdate('H:i:s');
                        
                        $tellertime = $this->data("get_difference_in_minutes", $data['Startingtime_14'], $data['Endingtime_15']);
                        
                        $data['Tellertime_19'] = $data_token['Tellertime_19'] = $tellertime;
                        
                        # Get the user performance
                        $userid = $this->session->userdata['user_id'];
                        $performance = $this->tokenModel->get_performace_by_user($userid);
                        
                        if(!empty($performance))
                        {
                                $performanceid = $performance[0]->Id_0;
                                
                                # Construct data
                                $data_performance = array();
                                
                                $category_time = $this->tokenModel->get_dropdown('category_max_time');
                                $category_max_time = $category_time[$data['Category_9']];

                                $data_performance['Workload_9'] = $performance[0]->Workload_9 + $tellertime;
                                $data_performance['People_10'] = $performance[0]->People_10 + 1;
                                
                                $extra_time = $tellertime - $category_max_time;

                                if($extra_time < 0)
                                {
                                        $extra_time = 0;
                                }
                                
                                $data_performance['Extratime_11'] = $performance[0]->Extratime_11 + $extra_time;
  

                                # Update user performance
                                $this->tokenModel->save_performances($data_performance, $performanceid);
                        }
                        else
                        {
                                # Construct data
                                $data_performance = array();
                                
                                $category_time = $this->tokenModel->get_dropdown('category_max_time');
                                $category_max_time = $category_time[$data['Category_9']];
                                
                                $data_performance['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data_performance['Status_2'] = '1';
                                $data_performance['Account_3'] = $this->session->userdata['account_id'];
                                $data_performance['Userid_7'] = $this->session->userdata['user_id'];
                                $data_performance['Branchid_8'] = $_SESSION['Branchid'];
                                $data_performance['Workload_9'] = $tellertime;
                                $data_performance['People_10'] = 1;
                                
                                $extra_time = $tellertime - $category_max_time;
                                
                                if($extra_time < 0)
                                {
                                        $extra_time = 0;
                                }
                                
                                $data_performance['Extratime_11'] = $extra_time;
                                $data_performance['Gender_14'] = isset($_SESSION['Gender']) ? $_SESSION['Gender'] : 0;
                                
                                # Get the user age
                                if(isset($_SESSION['Birthyear']))
                                {
                                        $current_year = date('Y');
                                        $birthday = $_SESSION['Birthyear'];
                                        $age = $current_year - $birthday;
                                }
                                else
                                {
                                        $age = 0;
                                }
                                
                                $data_performance['Gender_14'] = isset($_SESSION['Gender']) ? $_SESSION['Gender'] : 0;
                                $data_performance['Education_15'] = isset($_SESSION['Education']) ? $_SESSION['Education'] : 0;
                                $data_performance['Tellerage_16'] = $age;
                                $data_performance['Married_17'] = isset($_SESSION['Married']) ? $_SESSION['Married'] : 0;
                                $data_performance['Parent_18'] = isset($_SESSION['Parent']) ? $_SESSION['Parent'] : 0;
                            
                                # create user performance
                                $this->tokenModel->save_performances($data_performance, NULL);
                        }
                        
                        #Database
                        $cid = $this->tokenModel->save_token($data_token, $id); 
                     
                        if($cid)
                        {
                                # Update the queuing info to increment the number of people served
                                $queueid = isset($_SESSION['Queueid']) ? $_SESSION['Queueid'] : "";
                                $branchid = isset($_SESSION['Branchid']) ? $_SESSION['Branchid'] : "";
                                $bankid = $this->session->userdata["account_id"];
                                
                                $queuing = $this->tokenModel->get_queue_details($bankid, $branchid, $queueid);
                                
                                if(isset($queuing[0]->Id_0))
                                {
                                        $data_queuing = array();
                                        
                                        $index = $data['index'];
                                        $sequence = $_SESSION['Sequence'];
                                        
                                        $token_list = json_decode($queuing[0]->Tokenlist_15, true);
                                        #$token_list[$index]["queue"]= $sequence;
                                        
                                        if ($data['Status_2'] == 4):
                                                $token_list[$index]['pending'] = "1";
                                        else:
                                                if (isset($token_list[$index]['pending']) && $token_list[$index]['pending'] == '1'):
                                                        unset($token_list[$index]['pending']);
                                                endif;
                                                
                                                $token_list[$index]["queue"]= $sequence;
                                        endif;
     
                                        $data_queuing["Tokenlist_15"] = json_encode($token_list);

                                        $data_queuing['Served_10'] = $queuing[0]->Served_10 + 1;
                                        
                                        if($queuing[0]->Tokentoggle_20 !=""):
                                                $data_queuing['Tokentoggle_20'] = "";
                                        endif;

                                        $qid = $this->tokenModel->save_queuing($data_queuing, $queuing[0]->Id_0);
                                }
                                
                                $result['id'] = $cid;

                                $smsid = '';
                               

                                if($data['Status_2']==3 ||$data['Status_2']==4 ||$data['Status_2']==5 ||$data['Status_2']==6 ||$data['Status_2']==7)
                                { 
                                        $link = 'http://34.72.60.38/v2/frontend/survey?userid='.$userid.'&tokenid='.$token->Id_0.'&branchid='.$token->Branchid_22.''.'&bankid='.$token->Account_3.''.'&categoryid='.$token->Category_9.'';
                                        $message = "Bonjour Cher Client, veillez remplire le formulaire de sondage,cliquez sur le lien suivant: ". $link ;
                                        $phone = $data['Cellphone_12'];
                                        $smsid = $this->appointmentModel->send_sms($phone, $message);
                                } 
                               

                                $result['msg'] =  '<div class="alert aSuccess text-white">Bravo! ticket enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                
                        }
                        else
                        {
                                $result['id'] = 0;
                                $result['msg'] = '<div class="alert aDanger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        }
                        
                        echo json_encode($result);
                }
                elseif($obj == "token_toggle")
                {
                        $data = $_POST;
                        
                        if($data['Queue']=='' || $data['Priority_25']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $item = 1;
                        $index = 0;
                        
                        $queuingid = $data['Queuingid'];
                        $queueid = $data['Queueid'];
                        $branchid = $data['Branchid'];
                        $current_token = $data['Token'];
                        $tokenid = $data['Tokenid'];

                        # File d'attente courante
                        $current_queueing  =  $this->tokenModel->get_queuing_by_id($queuingid);
                        
                        if(isset($current_queueing->Tokenlist_15) || !empty($current_queueing->Tokenlist_15)):
                                $current_tokenslist = json_decode($current_queueing->Tokenlist_15, true);
                        else:
                                $current_tokenslist = array();
                        endif;
               
                        $token_removed_queue = array();
                        foreach ($current_tokenslist  as $key => $tokenslist):
                                $token_codes = $tokenslist["queue"].$tokenslist["token"];

                                if ($token_codes == $current_token):
                                        $index = $key;
                                        $token_removed_queue = $tokenslist;
                                endif;
                        endforeach;
                        
                        # Remove the element at the specified index
                        array_splice($current_tokenslist, $index, 1);
                        
                        $data_current_queuing['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data_current_queuing['Changer_6 '] = $this->session->userdata['user_id'];
                        
                        $data_current_queuing['Totalpeople_8'] = $current_queueing->Totalpeople_8 - 1;
                        $data_current_queuing['Tokenlist_15'] = json_encode($current_tokenslist, JSON_PRETTY_PRINT);
                        
                        $data_current_queuing['Tokenremove_21'] = substr($current_token, 1);
                        
                        $cid = $this->tokenModel->update_queuing($data_current_queuing, $queuingid);
                        
                        if ($cid):
                                                        
                                #File d'attente basculée
                                $toggle_queue = $this->tokenModel->get_queuing_by_queue($data['Queue'],$branchid);
                        
                                $data_token['Priority_25'] = $data['Priority_25'];
                                $data_token['Queueid_23'] = $toggle_queue->Id_0;

                                $this->tokenModel->update_token($data_token, $tokenid);

                                $data_toggle_queuing['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data_toggle_queuing['Changer_6 '] = $this->session->userdata['user_id'];
                                $data_toggle_queuing['Totalpeople_8'] = $toggle_queue->Totalpeople_8 + 1;

                                $toggle_tokenlist = $toggle_queue->Tokenlist_15;

                                #$lasttoken2 = intval($toggle_queue->Lasttoken_14);
                                #$result_lasttoken2 = $lasttoken2 + $item;
                                #$formatted_result2 = sprintf('%04d', $result_lasttoken2);

                                #$data_toggle_queuing['Lasttoken_14'] =  $formatted_result2;
                                
                                $token_removed_queue['queueid'] = $data['Queue'];
                                $token_removed_queue['toggle'] = $data['Priority_25'];

                                $toggle_tokenlist = json_decode($toggle_tokenlist, true);

                                if (isset($data['Priority_25']) && $data['Priority_25']=="P1"):
                                        # Add the removed element at the beginning of the new array
                                        array_unshift($toggle_tokenlist, $token_removed_queue);
                                
                                        $data_toggle_queuing['Tokentoggle_20'] = substr($current_token, 1);
                                endif;
                                
                                if (isset($data['Priority_25']) && $data['Priority_25']=="P0"):
                                        # Add the removed element at the end of the new array
                                        $toggle_tokenlist[] = $token_removed_queue;
                                endif;

                                $data_toggle_queuing['Tokenlist_15'] = json_encode($toggle_tokenlist, JSON_PRETTY_PRINT);
                                #$data_toggle_queuing['Tokentoggle_20'] = substr($current_token, 1);

                                $qid = $this->tokenModel->update_queuing($data_toggle_queuing, $toggle_queue->Id_0);
                            
                        endif;
                        
                        if($qid): 
                                echo '<div class="alert alert-success">Bravo! le client est basculé à une autre file d\'attente avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "queuing")
                {
                        if (isset($arg['next_token'])) $data['Nexttoken_14']= $arg['next_token'];
                        if (isset($arg['current_token'])) $data['Currenttoken_19']= $arg['current_token'];
                        if (isset($arg['token_list'])) $data['Tokenlist_15']= $arg["token_list"];
                        
                        $data['Changes_5']=gmdate('Y-m-d H:i:s');

                        $qid = $this->tokenModel->save_queuing($data, $id); 
                        
                        return $qid;
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj== 'next_token')
                {
                        if (isset($data) && $data != NULL):
                                # Token en attente
                                $token_pending = $data;
                        endif;

                        # Get the teller branch informations
                        $queueid = isset($_SESSION['Queueid']) ? $_SESSION['Queueid'] : "";
                        $branchid = isset($_SESSION['Branchid']) ? $_SESSION['Branchid'] : "";
                        $bankid = $this->session->userdata["account_id"];
 
                        $queuing = $this->tokenModel->get_queue_details($bankid, $branchid, $queueid);
                        
                        if(!empty($queuing) && $queuing[0]->Tokenlist_15 != "")
                        {     
                                # Vérifier s'il existe un jeton bascule sur une file d'attente
                                if ($queuing[0]->Tokentoggle_20 != "")
                                {
                                        # Get the current token
                                        $token_value = $queuing[0]->Tokentoggle_20;
                                        $tokens_info = $this->tokenModel->get_token_by_queuing_info($token_value, $branchid, $bankid, $queuing[0]->Id_0);

                                        $item = '';
                                        foreach ($tokens_info as $key => $lines):
                                                if ($lines->Priority_25 != NULL):
                                                    $item = $key;
                                                endif;
                                        endforeach;


                                        $token_info[] = $tokens_info[$item];
                                }
                                # Vérifier s'il existe un jeton supprime sur une file d'attente
                                elseif ($queuing[0]->Tokenremove_21 != "")
                                {
                                        $token_next = $queuing[0]->Nexttoken_14;
                                        $token_remove = $queuing[0]->Tokenremove_21;

                                        if ($token_next == $token_remove)
                                        {    
                                                $tokenslist = json_decode($queuing[0]->Tokenlist_15, true);

                                                $tokenremove = intval($token_remove);

                                                $tokennext = $tokenremove + 1;
                                                $tokennext = sprintf('%04d', $tokennext);

                                                $token_value = $tokennext;
                                        }
                                        else
                                        {
                                                $token_value = $queuing[0]->Nexttoken_14;
                                        }

                                        $tokens_info = $this->tokenModel->get_token_by_queuing_info($token_value, $branchid, $bankid, $queuing[0]->Id_0);

                                        $token_info = $tokens_info;
                                }
                                else
                                {
                                        if (isset($token_pending) && $token_pending != NULL):
                                               $token_value = $token_pending; 
                                        else:
                                               $token_value = $queuing[0]->Nexttoken_14;
                                        endif;

                                        $token_info = $this->tokenModel->get_token_by_queuing_info($token_value, $branchid, $bankid, $queuing[0]->Id_0);

                                        if (count($token_info) > 1)
                                        {
                                                $iKey = '';
                                                
                                                # Token toggle with priority 0 (to end of queue)
                                                foreach ($token_info as $key => $row):
                                                        if ($row->Priority_25 !="" && $row->Priority_25 == "P0"):
                                                                $iKey = $key;
                                                        endif;
                                                endforeach;

                                                if ($iKey !="" && $iKey >= 0):
                                                        unset($token_info[$iKey]);
                                                        
                                                        # Re-index the table
                                                        $token_info = array_values($token_info);
                                                endif;
                                        }
                                }
                                
                                # Verify if there is a token not finalised by the user
                                if(count($token_info) > 1 || isset($token_info[0]->Status_2) && $token_info[0]->Status_2 == 2)
                                {
                                        $token_list = json_decode($queuing[0]->Tokenlist_15, true);
                                        $token_value = $queuing[0]->Currenttoken_19;
                                        
                                        # Get the index of the current token in tokenlist
                                        $index = $this->data("token_index", $token_list, $token_value);
                                                        
                                        foreach($token_info as $row):
                                                if($row->Userid_21 != 0):
                                                        # Return the tokenid
                                                        //echo $row->Id_0; 
                                                
                                                        $return['id'] = $row->Id_0; 
                                                        $return['index'] = $index;

                                                        echo json_encode($return);
                                                        die;
                                                endif;
                                        endforeach;
                                }
                                elseif(!empty($token_info))
                                {
                                        $idata = array();
                                        
                                        # Get the teller code of the current user
                                        $users = $this->reportsModel->get_dropdown("users_code");
                                        $user = $this->session->userdata['user_id'];
                                        $teller_code = isset($users[$user]) ? $users[$user] : "";
                                        
                                        # Get the token to be called in token_list
                                        $token_list = json_decode($queuing[0]->Tokenlist_15, true);

                                        if ($queuing[0]->Tokentoggle_20 !="" && $token_info[0]->Priority_25 !='')
                                        {
                                                $data_to_update = array();

                                                if ($token_info[0]->Priority_25 =='P1'):
                                                        # Get the index of the current token in tokenlist
                                                        $index =  $idata['index'] = 0;

                                                        $token_list[$index]["queue"]= $teller_code;
                                                endif;
                                                
                                                $data_to_update["token_list"] = json_encode($token_list);

                                                # Update the queuing with the next token value, the current token, tokenlist
                                                $this->save("queuing", $queuing[0]->Id_0, $data_to_update);
                                        }
                                        else
                                        {    
                                                # Toggle token to end of queue
                                                $token_priority = "";
                                                if (isset($token_info[0]->Priority_25) && $token_info[0]->Priority_25 =='P0'):
                                                        $token_priority = $token_info[0]->Priority_25;
                                                endif;
                                                
                                                $tokencurrent = $queuing[0]->Currenttoken_19;
                                                $tokenlast = $queuing[0]->Lasttoken_14;
                                                
                                                if ($token_priority !="" && $token_priority = 'P0' && $tokencurrent == $tokenlast)
                                                {
                                                        if (count($token_list) > intval($tokenlast)):
                                                                $index = $idata['index'] = intval($tokenlast);
                                                                $token_list[$index]["queue"]= $teller_code;
                                                        endif;
                                                        
                                                       $next_token = count($token_list);
                                                       $next_token = sprintf('%04d', $next_token);
                                                        
                                                        $data_to_update["next_token"] = $next_token;
                                                        $data_to_update["token_list"] = json_encode($token_list);

                                                        # Update the queuing with the next token value, the current token, tokenlist
                                                        $this->save("queuing", $queuing[0]->Id_0, $data_to_update);
                                                }
                                                elseif (isset($token_pending) && $token_pending != NULL)
                                                {
                                                        $index = '';
                                                        foreach ($token_list as $pKey => $list)
                                                        {
                                                                if (isset($list["pending"]) && $list["pending"] == "1"):
                                                                        $index = $pKey;
                                                                endif;
                                                        }
                                                        $idata['index'] = $index;
                                                        
                                                        $token_list[$index]["queue"]= $teller_code;

                                                        $data_to_update["token_list"] = json_encode($token_list);

                                                        # Update the queuing with the next token value, the current token, tokenlist
                                                        $this->save("queuing", $queuing[0]->Id_0, $data_to_update);
                                                }
                                                else
                                                {
                                            
                                                        # Get the index of the current token in tokenlist
                                                        $index = $this->data("token_index", $token_list, $token_value);
                                         
                                                        # Test whether there is an other token in list or not
                                                        # In order to modify the value of the next_token
                                                        if(isset($token_list[$index + 1]))
                                                        {
                                                                if (isset($token_list[$index]['toggle']) && $token_list[$index]['toggle'] == 'P1')
                                                                {
                                                                        $toggle = $token_list[$index]['token'];

                                                                        $nexttoken = $item = intval($toggle);
                                                                        $nexttoken = $nexttoken + 1;

                                                                        $next_token = sprintf('%04d', $nexttoken);
                                                                        $current_token = $toggle;

                                                                        $token_list[$item]["queue"]= $teller_code; 
                                                                }
                                                                else
                                                                {
                                                                        $next_token = $token_list[$index + 1]['token'];
                                                                        $current_token = $token_list[$index]['token'];

                                                                        $token_list[$index]["queue"]= $teller_code; 
                                                                }

                                                                $data_to_update = array();

                                                                $data_to_update["next_token"] = $next_token;
                                                                $data_to_update["current_token"] = $current_token;
                                                                $data_to_update["token_list"] = json_encode($token_list);

                                                                # Update the queuing with the next token value, the current token, tokenlist
                                                                $this->save("queuing", $queuing[0]->Id_0, $data_to_update);
                                                                
                                                                
                                                        }
                                                        elseif(isset($token_list[$index]))
                                                        {
                                                                # In case there are no more tokens in the array
                                                                # Already increment the value of nexttoken
                                                                # Based on the current token
                                                                $new_val = '';
                                                                $current_token = $token_list[$index]['token'];

                                                                $new_val = intval($current_token);
                                                                $new_val = $new_val + 1;
                                                                $next_token = sprintf('%04d', $new_val);

                                                                $token_list[$index]["queue"]= $teller_code;

                                                                $data_to_update = array();

                                                                $data_to_update["next_token"] = $next_token;
                                                                $data_to_update["current_token"] = $current_token;
                                                                $data_to_update["token_list"] = json_encode($token_list);

                                                                # Update the queuing with the next token value 
                                                                $this->save("queuing", $queuing[0]->Id_0, $data_to_update);
                                                        }
                                                        
                                                        $idata['index'] = $index;
                                                }
                                        }

                                        # Update informations of the token
                                        $data_token = array();
                                        
                                        $data_token['Startingtime_14'] = gmdate('H:i:s');
                                        $data_token['Userid_21'] = $this->session->userdata["user_id"];
                                        $data_token['Status_2'] = '2';
                                        
                                        $this->tokenModel->save_token($data_token, $token_info[0]->Id_0);
                                        
                                        # Return the tokenid
                                        $return['id'] = $token_info[0]->Id_0;
                                        $return['index'] = $idata['index'];
                                       
                                        echo json_encode($return);


                                        #echo $token_info[0]->Id_0;
                                }
                                else 
                                {
                                        # No token found
                                        echo '404'; die;
                                }
                        }
                        else
                        {
                                # No token found
                                echo '404'; die;
                        }
                }
                elseif($obj== 'token_index')
                {
                        $token_value = $arg;
                        $tokenlist = $data;
                        
                        $users = $this->reportsModel->get_dropdown("users_code");
                        $user = $this->session->userdata['user_id'];
                        $teller_code = isset($users[$user]) ? $users[$user] : "";
                       
                        # Find the index of the current token in tokenlist
                        foreach ($tokenlist as $index => $token) 
                        {
                                if(isset($token["toggle"]) && $token["toggle"] = "P1")
                                {
                                        //$index = $index + 1;
                                        
                                        if (in_array($token_value, $token, true)) 
                                        {
                                                return $index;
                                        }
                                }
                                elseif(isset($token["toggle"]) && $token["toggle"] = "P0")
                                {
                                        //$index = $index + 1;
                                        
                                        if (in_array($token_value, $token, true)) 
                                        {
                                                return $index;
                                        }
                                }
                                else
                                {   
                                        if (in_array($token_value, $token, true)) 
                                        {
                                                return $index;
                                        }
                                }
                        }
                     
                        return false;
                }
                elseif($obj== 'get_difference_in_minutes')
                {
                        $startingTime = $data;
                        $endingTime = $arg;
                        
                        
                        # Get the difference of minutes between starting_time and ending_time
                        $endingTime = strtotime($endingTime);
                        $startingTime = strtotime($startingTime);
                        
                        $differenceInSeconds = $endingTime - $startingTime;
                        
                        // Convert the difference in hour:minutes:seconds
                        $hours = floor($differenceInSeconds / 3600);
                        $minutes = floor(($differenceInSeconds % 3600) / 60);
                        $seconds = $differenceInSeconds % 60;
                        
                        $hour_in_minutes = 0;

                        if($hours > 0)
                        {
                                $hour_in_minutes = $hours * 60;
                        }
                        
                        $minutes = $minutes + $hour_in_minutes;
                        
                        return $minutes;
                }
        }
}

/* End of file   */
/* Location: /  */