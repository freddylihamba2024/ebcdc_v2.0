<?php

namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class SurveyModel extends MY_Qleads {
	
        /* Presentation: 
         * Last update
         * By Alvin  on the 23.11.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        
	protected $table            = 'qleads_surveys'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;

        protected $allowedFields    = [];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
        
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_survey_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Userid_7='';
                        $obj->Tokenid_8='';
                        $obj->Branchid_9='';
                        $obj->Comments_10='';
                        $obj->Bankrate_11='';
                        $obj->Branchrate_12='';
                        $obj->Tellerrate_13='';
                        $obj->Satisfaction_14='';
                        $obj->Servicesrate_15='';
                        $obj->Productsrate_16='';
                        $obj->Referal_17='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_surveys', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="")
                {
                        
                }
                
                elseif($item=="")
                {
                        
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
      
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_survey($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_form_survey($bankid=NULL, $categoryid=NULL)
        {
                $st = "Status_2='1' AND Account_3='".$bankid."' AND Category_8='".$categoryid."'";   
                
                $query = $this->db->table('qleads_formsurveys as items')
                        ->select('items.Id_0, items.Form_7, items.Category_8, items.Name_9')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                        
                return $query->getResult();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_survey($data, $id)
	{
                $this->set_table('qleads_surveys', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function save_objects_name($data, $id)
	{
                $this->set_table('qleads_tokens', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
}
