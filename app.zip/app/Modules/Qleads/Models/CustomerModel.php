<?php

namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class CustomerModel extends MY_Qleads {
        
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_customer_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Firstname_7='';
                        $obj->Lastname_8='';
                        $obj->Cellphone_9='';
                        $obj->Cellphone_10='';
                        $obj->Email_11='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_vipcustomers', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
               
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_vip_customers($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('qleads_vipcustomers')
                        ->select('qleads_vipcustomers.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_vipcustomers_by_phone($phone = NULL)
        {
                if($phone == NULL)
                {
                        $phone = trim($phone);
                        $phone = $phone*1;
                }
                
                $st = " Cellphone_9 LIKE '%" . $phone . "%' OR Cellphone_10 LIKE '%" . $phone . "%'";
                $query = $this->db->table('qleads_vipcustomers as items')
                        ->select('items.Id_0, items.Firstname_7, items.Lastname_8, items.Cellphone_9, items.Cellphone_10, items.Email_11')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
               
	}
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_vip_customers($data, $id)
	{
                $this->set_table('qleads_vipcustomers', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
       
}