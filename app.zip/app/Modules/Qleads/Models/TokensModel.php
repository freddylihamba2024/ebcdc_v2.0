<?php

namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class TokensModel extends MY_Qleads {
        
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	
        protected $table = '';
        protected $primaryKey = 'Id_0';
        protected $allowedFields = ['Status_2'];
        
        
        public $status = array(
            
                ''=>"",
                '3'=>"Prise en charge termin&eacute;e (r&eacute;solue)",
                '4'=>"Mise en attente",
                '5'=>"Prise en charge en cours (le client doit revenir)",
                '6'=>"Prise en charge en cours (le client ne doit plus revenir)",
                '7'=>"Aucune solution trouv&eacute;e",
                '8'=>"Client absent"
        );
        
        public $priorites = array(
                '' => '',
                'P0' => 'Priorit&eacute; (0)',
                'P1' => 'Priorit&eacute; (1)'
        );
        
        public $type_compte = array(''=>'', '1'=>'Courant', '2'=>'Epargne');
        public $devise_compte = array(''=>'', 'CDF'=>'CDF', 'USD'=>'USD');
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_token_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Token_7='';
                        $obj->Tokentype_8='';
                        $obj->Category_9='';
                        $obj->Name_10='';
                        $obj->Description_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Startingtime_14='';
                        $obj->Endingtime_15='';
                        $obj->Appointmentdate_16= gmdate('Y-m-d');
                        $obj->Appointmenttime_17='';
                        $obj->Appointmentteller_18='';
                        $obj->Tellercomment_20='';
                        $obj->Tellercomment_20='';
                        $obj->Branchid_22 = '';
                        $obj->Queueid_23 = '';
                        $obj->Clientid_24 = '';
                        $obj->Priority_25 = '';
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_tokens', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="category")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Title_8'];
                        }
                        
                        return $ddmenu;
                }
                elseif($item=="subcategory")
                {
                        //$st = " Status_2!='0' AND Object_7 = 'Request' AND Categoryid_10 != '0' ";
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";

                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                if ($row['Categoryid_10'] == 0):
                                        $ddmenu[$row['Id_0']] = $row['Title_8'];
                                else:
                                       $ddmenu[$row['Categoryid_10']] = $row['Title_8'];
                                endif;
                                
                                //$ddmenu[$row['Categoryid_10']] = $row['Eform_12'];

                        }
                        
                        return $ddmenu;
                }
                if($item=="category_max_time")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Maxtime_11'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="category_max_time")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Maxtime_11'];
                        }
                        
                        return $ddmenu;
                }
                elseif($item=="category_eforms")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Eform_12'];
                        }
                        
                        return $ddmenu;
                }
                elseif($item=="subcategory_eforms")
                {
                        //$st = " Status_2!='0' AND Object_7 = 'Request' AND Categoryid_10 != '0' ";
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";

                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                if ($row['Categoryid_10'] == 0):
                                        $ddmenu[$row['Id_0']] = $row['Eform_12'];
                                else:
                                       $ddmenu[$row['Categoryid_10']] = $row['Eform_12'];
                                endif;
                                
                                //$ddmenu[$row['Categoryid_10']] = $row['Eform_12'];

                        }
                        
                        return $ddmenu;
                }
                elseif($item=="token")
                {
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                        $query = $this->db->table('qleads_tokens')
                                ->select('qleads_tokens.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_10'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
      
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_tokens($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_token_by_queuing_info($token, $branchid, $bankid, $queuingid)
	{
                $user_id = $this->session->userdata['user_id'];
                $date = gmdate('Y-m-d');
                        
                $st = "((Status_2='1' OR Status_2='4') AND Token_7='" .$token. "' AND Branchid_22='" . $branchid . "' AND Account_3='" . $bankid . "' AND Queueid_23 = '".$queuingid."') OR (Status_2 = '2' AND Userid_21='" . $user_id . "' AND Date_1 LIKE '%" . $date . "%') ";
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }

        public function get_token_treated()
        {
                $user_id = $this->session->userdata['user_id'];
                $tellercode = $_SESSION["Tellercode"];
                $sequence = $_SESSION['Sequence'];
                $branchid = $_SESSION['Branchid'];
                $date = gmdate('Y-m-d');
                        
                $st = " Status_2 > '2' AND Status_2 != '4' AND Branchid_22='" . $branchid . "' AND Date_1 LIKE '%" . $date . "%' ";
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                $result = $query->getResult();
                $token_treated = array();
                
                if(!empty($result))
                {
                        foreach($result as $row)
                        {
                                $token_treated[$row->Queueid_23][$row->Token_7][$sequence] = $row; 
                        }
                }
                
                return $token_treated;
        }
        
        public function get_token_notreated($queueid = NULL)
        {
                $userid = $this->session->userdata['user_id'];
                $accountid = $this->session->userdata['account_id'];
                $branchid = $_SESSION['Branchid'];
                $date = gmdate('Y-m-d');
                        
                $st = " (Status_2 = '1' OR Status_2 = '2') AND Account_3='" . $accountid . "' AND Date_1 LIKE '%" . $date . "%' ";

                if ($_SESSION['Qleads_role'] == "1"):
                        $st .= " AND  Userid_21='".$userid."' AND  Branchid_22='".$branchid."' ";
                elseif ($_SESSION['Qleads_role'] == "3"):
                        $st .= " AND  Branchid_22='".$branchid."' ";
                endif;
                
                if ($queueid != null):
                        $st .= " AND  Queueid_23='".$queueid."' ";
                endif;
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Token_7', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_queuings()
	{
                $accountid = $this->session->userdata['account_id'];
                $queueid = $_SESSION['Queueid'];
                $branchid = $_SESSION['Branchid'];
                
                if ($_SESSION['Qleads_role'] == "1"):
                        $st = "Status_2='1' AND Account_3='" . $accountid . "' AND Queueid_7='" . $queueid . "'AND Branchid_16='" . $branchid . "'";
                elseif ($_SESSION['Qleads_role'] == "3"):
                        $st = "Status_2='1' AND Account_3='" . $accountid . "' AND Branchid_16='" . $branchid . "'";
                elseif ($_SESSION['Qleads_role'] == "5"):
                        $st = "Status_2='1' AND Account_3='" . $accountid . "'";
                else:
                        $st = "Status_2='1' AND Account_3='" . $accountid . "' AND Branchid_16='" . $branchid . "'";
                endif;

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}

      
        public function get_count_cases_treated($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if ($role == "3" ) $st = "Status_2='3' AND Account_3='" . $account_id . "'AND Branchid_22='" . $branch_id . "'";
                if ($role == "1" ) $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "'";

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC');

                return $query->countAllResults();
	}
        
        public function get_eform_by_tokenid($tokenid)
        {
                $this->set_table('qleads_eforms', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Tokenid_7' => $tokenid), TRUE);
        }
        
        public function get_eform_by_branch($tokenid, $categoryid)
	{
                $bankid = $this->session->userdata['account_id'];
                $branchid = $_SESSION['Branchid'];
 
                $st = "Status_2='1' AND Account_3='".$bankid."' AND Tokenid_7 ='".$tokenid."' AND Categoryid_10='".$categoryid."' AND Branchid_9 ='".$branchid."' ";
                
                $query = $this->db->table('qleads_eforms as eforms')
                        ->select('eforms.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function get_performace_by_user($userid)
	{
                $today = gmdate('Y-m-d');
                $bankid = $this->session->userdata['account_id'];
                $branchid = $_SESSION['Branchid'];
                
                $st = "Date_1 LIKE '%".$today."%' AND Account_3='" . $bankid . "' AND Userid_7='".$userid."' AND Branchid_8 ='".$branchid."' ";
                
                $query = $this->db->table('qleads_performances as performances')
                        ->select('performances.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function get_queuing_by_id($id)
        {
                $this->set_table('qleads_queuing I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }
        
        public function get_queuing_by_queue($queueid, $branchid)
        {
                $this->set_table('qleads_queuing I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Queueid_7' => $queueid, 'Opening_11' => gmdate('Y-m-d'), 'Branchid_16' => $branchid), TRUE);
        }
        
        public function get_queue_by_branch($branche_id)
        {
                $st = "Status_2 ='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Branchid_7 ='" . $branche_id . "'";
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_token($data, $id)
	{
                $this->set_table('qleads_tokens', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        /*
         * Endpoint
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_device($type, $code)
	{
                $this->set_table('qleads_devices', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array(
                                        'Type_7' => $type,
                                        'Code_8' => $code,
                                ), 
                                TRUE
                );
	}
        
        public function get_categories($type, $id)
	{
                $st = "Object_7='" .$type. "' AND Account_3='" . $id . "'";
                
                $query = $this->db->table('qleads_categories as item')
                        ->select('item.Id_0,item.Title_8,item.Categoryid_10,item.Maxtime_11,item.Eform_12')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function get_category_details($type, $bankid, $categoryid)
	{
                $st = "Id_0='" .$categoryid. "' AND Object_7='" .$type. "' AND Account_3='" . $bankid . "'";
                
                $query = $this->db->table('qleads_categories as item')
                        ->select('item.Id_0,item.Title_8,item.Categoryid_10,item.Maxtime_11,item.Eform_12')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function get_queues($bankid, $banchid, $categoryid, $vip)
        {
                
                $st = "Branchid_7='" . $banchid . "' AND Account_3='" . $bankid . "'";
                if($vip == 1) 
                        $st .= " AND Vip_15='" . $vip . "'";
                else
                        $st .= " AND Categorieslist_8 LIKE '%" .$categoryid. "%'";
                        
                $query = $this->db->table('qleads_queues as items')
                        ->select('items.Id_0, items.Tellerslist_9, items.Sequence_10, items.Opening_11, items.Served_12, items.Categorieslist_8, items.Branchid_7')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                        
                return $query->getResult();
               
	}

        public function get_queue_info($id)
        {
                $this->set_table('qleads_queues', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }
        
        public function get_vipcustomers_by_phone($phone = NULL)
        {
                if($phone != NULL)
                {
                        $phone = trim($phone);
                        $phone = $phone*1;
                }
                
                $st = " Cellphone_9 LIKE '%" . $phone . "%' OR Cellphone_10 LIKE '%" . $phone . "%'";
                $query = $this->db->table('qleads_vipcustomers as items')
                        ->select('items.Id_0, items.Firstname_7, items.Lastname_8, items.Cellphone_9, items.Cellphone_10, items.Email_11')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
               
	} 
        
        public function get_queue_details($bankid, $banchid, $queueid)
        {
                $today = gmdate('Y-m-d');
                  
                $st = "Opening_11='" .$today. "' AND Queueid_7='" .$queueid. "' AND Branchid_16='" . $banchid . "' AND Account_3='" . $bankid . "'";
                
                $query = $this->db->table('qleads_queuing as queue')
                        ->select('queue.Id_0, queue.Totalpeople_8, queue.Totalteller_9, queue.Served_10, queue.Opening_11, queue.Totaltime_12, queue.Workload_13, queue.Nexttoken_14, queue.Lasttoken_14, queue.Tokenlist_15, queue.Currenttoken_19, queue.Tokentoggle_20, queue.Tokenremove_21')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	} 
        
        public function save_queuing($data, $id)
	{
                $this->set_table('qleads_queuing', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function save_eform($data, $id)
	{
                $this->set_table('qleads_eforms', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function save_performances($data, $id)
	{
                $this->set_table('qleads_performances', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function save_log_vipcustomers($data, $id)
	{
                $this->set_table('qleads_log_vipcustomers', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function update_token_untreated()
        {
                $today = date('Y-m-d');

                $this->setTable('qleads_tokens')
                     ->set('Status_2', 4)
                     ->where('Status_2', 1)
                     ->where("DATE_FORMAT(Date_1, '%Y-%m-%d') <>", $today)
                     ->update();
        }
        
        public function update_token($data, $id) 
        {
                $this->set_table('qleads_tokens ', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function update_queuing($data, $id) 
        {
                $this->set_table('qleads_queuing', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
}