<?php

namespace Modules\Qleads\Models;
use App\Models\MY_Qleads;
use Illuminate\Support\Facades\DB;
use stdClass;

class DashboardModel extends MY_Qleads {
	
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	public function __construct()
	{
		parent::__construct();
                
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        
        public function get_survey_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Categoryid_9=gmdate('Y-m-d H:i:s');
                        $obj->Tokenid_7='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Name_10='';
                        $obj->Description_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Bankaccount_14='';
                        $obj->Currency_15='';
                        $obj->Progress_18='';
                        $obj->Deadline_19='';
                        $obj->Avmfile_20='';
                        $obj->Avmstatus_21='';
                        
                        $obj->Confirmation_22='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_inquiries', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="inquiry_status")
                {
                        $st = " Status_2!='0' AND Object_7 = 'inquiry_status' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ttile_8'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="token_category")
                {
                        $st = " Status_2!='0' AND Object_7 = 'token_category' ";
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ttile_8'];
                        }
                        return $ddmenu;
                }

                elseif($item=="user")
                {
                        $st = " Status_2!='0' AND Object_7 = 'token_category' ";
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ttile_8'];
                        }
                        return $ddmenu;
                }
              

        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        
        public function get_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('TABLE')
                        ->select('TABLE.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function init_data() 
        {
                $this->_table_name = '';
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "'";

                $query = $this->db->table('qleads_users')
                                ->select('qleads_users.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->limit(1)
                                ->get();
               
               $users =  $query->getResult(); 
               
                if (!empty($users))
                {
                        $_SESSION['Queueid'] = $queueid = $users[0]->Queueid_11;
                        $_SESSION['Tellercode'] = $users[0]->Tellercode_10;
                        $_SESSION['Gender'] = $users[0]->Gender_14;
                        $_SESSION['Education'] = $users[0]->Education_15;
                        $_SESSION['Birthyear'] = $users[0]->Birthyear_16;
                        $_SESSION['Married'] = $users[0]->Married_17;
                        $_SESSION['Parent'] = $users[0]->Parent_18;
                        $_SESSION['Branchid'] = $users[0]->Branchid_9;
                        $_SESSION['Qleads_role'] = $users[0]->Authorization_8;
                        
                        if ($queueid > 0):
                                $this->set_table('qleads_queues  I', 'I.Id_0', 'I.Id_0 DESC');
                                $queue = $this->get_by(array('Id_0' => $queueid), TRUE);

                                $_SESSION['Sequence'] = $queue->Sequence_10;
                        endif;
                }


                return true;
        }

         /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */



        public function get_queuing()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $queue_id = $_SESSION['Queueid'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if ($role == "1")
                {
                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Queueid_7='" . $queue_id . "'AND Branchid_16='" . $branch_id . "' AND Opening_11 LIKE '%". $date. "%'";
                }
                elseif ($role == "3")
                {
                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Branchid_16='" . $branch_id . "' AND Opening_11 LIKE '%". $date. "%'";
                }
                elseif ($role == "5")
                {
                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Opening_11 LIKE '%". $date. "%'";
                       
                }
                else
                {
                        $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Branchid_16='" . $branch_id . "' AND Opening_11 LIKE '%". $date. "%'";
                }

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}

        
        public function get_queuing_by_day()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
               
                 
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Opening_11 LIKE '%". $date. "%'";
                
               

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}

      

        
        
        public function get_queuing_sum_by_people()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $queue_id = $_SESSION['Queueid'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];

                if ($role == "1") $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Queueid_7='" . $queue_id . "'AND Branchid_16='" . $branch_id . "' AND Opening_11 LIKE '%". $date. "%'";
                if ($role == "3") $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Branchid_16='" . $branch_id . "' AND Opening_11 LIKE '%". $date. "%'";

                $query = $this->db->table('qleads_queuing')
                                    ->select('Totalpeople_8, SUM(Totalpeople_8) as total_people, Served_10, SUM(Served_10) as total_surved') 
                                    // Ajoutez SUM() pour chaque champ que vous souhaitez sommer
                                    ->where($st)
                                    ->groupBy('Totalpeople_8, Served_10')
                                    ->get();
                
                return $query->getResult();
	}

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

      

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_case_treated($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if(isset($_SESSION['Qleads_role']) && $role == "5")
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "'";
                }
                elseif(isset($_SESSION['Qleads_role']) && $role == "3")
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                elseif(isset($_SESSION['Qleads_role']) && $role == "1")
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                else
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Date_1 LIKE '%". $date. "%'";

                }
                
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
	}
        
        public function get_counts_cases_treated($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if ($role == "3" ) $st = "Status_2='3' AND Account_3='" . $account_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                if ($role == "1" ) $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC');

                return $query->countAllResults();
	}
        
        public function get_counts_number_appointments($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];

                if ($role == "3")  $st = "Appointmentteller_18='1' AND Account_3='" . $account_id . "' AND Branchid_22='" . $branch_id . "'";
                if ($role == "1")  $st = "Appointmentteller_18='1' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "'";

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC');
                
                return $query->countAllResults();
	}
        
        public function get_appointement()
	{
                $account_id = $this->session->userdata['account_id'];
                #$branch_id = $_SESSION['Branchid'];
                $st = "Account_3='" . $account_id . "' AND  Status_2='1' AND Date_1 LIKE '%" . gmdate('Y-m-d') . "%' ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}

        public function get_appointement_confirmed()
	{
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                $st = "Account_3='" . $account_id . "' AND  Status_2='4' AND Branchid_7='" . $branch_id . "' AND Changes_5 LIKE '%" . gmdate('Y-m-d') . "%' ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        
        
        public function get_recent_appointement()
	{
                $account_id = $this->session->userdata['account_id'];
                
                $st = "Account_3='" . $account_id . "' AND  Status_2='1' AND Date_1 LIKE '%" . gmdate('Y-m-d') . "%'  ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->limit('3')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_recent_appointement_confirmed()
	{
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                $st = "Account_3='" . $account_id . "' AND  Status_2='4' AND Branchid_7='" . $branch_id . "'  AND Changes_5 LIKE '%" . gmdate('Y-m-d') . "%' ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->limit('3')
                        ->get();
                
                return $query->getResult();
	}
      

         /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_appointment($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if(isset($_SESSION['Qleads_role']) && $role == "3")
                {
                        $st = "Appointmentteller_18='1' AND Account_3='" . $account_id . "' AND Branchid_22='" . $branch_id . "'";
                }
                elseif(isset($_SESSION['Qleads_role']) && $role == "1")
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                else
                {
                        $st = "Appointmentteller_18='1' AND Account_3='" . $account_id . "'";
                }

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_tokens($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if(isset($_SESSION['Qleads_role']) && $role == "3")
                {
                        $st = "Appointmentteller_18='1' AND Account_3='" . $account_id . "' AND Branchid_22='" . $branch_id . "'";
                }
                elseif(isset($_SESSION['Qleads_role']) && $role == "1")
                {
                        $st = "Status_2='3' AND Account_3='" . $account_id . "' AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                else
                {
                        $st = "Status_2='1' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' AND Account_3='" . $account_id . "'";
                }

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_current_tokens($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                $st = "Status_2='1' AND Date_1 LIKE '%".gmdate('Y-m-d')."%' AND Account_3='" . $account_id . "'";
                
                if(isset($_SESSION['Qleads_role']) && $role == "3")
                {
                        $st .= " AND Branchid_22='" . $branch_id . "'";
                }
                if(isset($_SESSION['Qleads_role']) && $role == "1")
                {
                        $st .= " AND Userid_21='" . $user_id . "'AND Branchid_22='" . $branch_id . "'";
                }

                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->limit(6)
                        ->get();
                
                return $query->getResult();
	}


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!
         *  *************************************************************************************************************************SECTION 4
        */

        // public function get_satisfied($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	// {
        //         $date = gmdate('Y-m-d');
        //         $account_id = $this->session->userdata['account_id'];
        //         $user_id = $this->session->userdata['user_id'];
        //         $branch_id = $_SESSION['Branchid'];
        //         $role = $_SESSION['Qleads_role'];
                
        //         if(isset($_SESSION['Qleads_role']) && $role == "3")
        //         {
        //                 $st = " Account_3='" . $account_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
        //         }
        //         elseif(isset($_SESSION['Qleads_role']) && $role == "1")
        //         {
        //                 $st = " Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
        //         }
        //         else
        //         {
        //                 $st = " Account_3='" . $account_id . "' AND Date_1 LIKE '%". $date. "%'";
        //         }
                
        //         $query = $this->db->table('qleads_surveys')
        //                 ->selectAvg('qleads_surveys.Satisfaction_14')
        //                 ->where($st)
        //                 ->get();
                
        //         return $query->getResult();
	// }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_survey_average_by_satisfaction($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if ($role == "3") $st = " Account_3='" . $account_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                if ($role == "1") $st = " Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";

                $query = $this->db->table('qleads_surveys')
                        ->selectAvg('qleads_surveys.Satisfaction_14')
                        ->where($st)
                        ->get();
                
                return $query->getResult();
	}

        public function get_survey_average_by_tellerrate($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $role = $_SESSION['Qleads_role'];
                
                if ($role == "3") $st = " Account_3='" . $account_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                if ($role == "1") $st = " Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";

                $query = $this->db->table('qleads_surveys')
                        ->selectAvg('qleads_surveys.Tellerrate_13')
                        ->where($st)
                        ->get();
                
                return $query->getResult();
	}

        public function get_survey_by_agency($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == "5")
                {
                        $st = " Account_3='" . $account_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                else
                {
                        $st = " Account_3='" . $account_id . "' AND Branchid_9='" . $branch_id . "' AND Date_1 LIKE '%". $date. "%'";
                }
                
                $query = $this->db->table('qleads_surveys')
                        ->select('qleads_surveys.*')
                        ->where($st)
                        ->get();
                return $query->getResult();
	}


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function count_token_by_category()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                
                $st = " Account_3='" . $account_id . "'";
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] < 5)
                {
                        $st .= " AND Branchid_22='" . $branch_id . "'";
                }
                
                $query = $this->db->table('qleads_tokens')
                        ->select('COUNT(qleads_tokens.Id_0) as total, qleads_tokens.Category_9 as category')
                        ->where($st)
                        ->groupBy('qleads_tokens.Category_9')
                        ->orderBy('total DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function count_appointment_by_category()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                
                $st = " Account_3='" . $account_id . "'";
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] < 5)
                {
                        $st .= " AND Branchid_7='" . $branch_id . "'";
                }
                
                $query = $this->db->table('qleads_appointments')
                        ->select('COUNT(qleads_appointments.Id_0) as total, qleads_appointments.Category_9 as category')
                        ->where($st)
                        ->groupBy('qleads_appointments.Category_9')
                        ->orderBy('total DESC')
                        ->get();
                return $query->getResult();
	}
        
        public function count_appointment_by_type()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                
                $st = " Account_3='" . $account_id . "' AND Status_2 = '4'";
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] < 5)
                {
                       $st .= " AND  Branchid_7='".$branch_id."' ";

                }
                
                $query = $this->db->table('qleads_appointments')
                        ->select('COUNT(qleads_appointments.Id_0) as total, qleads_appointments.Type_8 as type')
                        ->where($st)
                        ->groupBy('qleads_appointments.Type_8')
                        ->orderBy('total DESC')
                        ->get();
                return $query->getResult();
	}
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function send_sms($phone, $message)
	{
                $phone = str_replace(' ', '', $phone);
                $phone = str_replace('+243', '', $phone);
                $phone = str_replace('00243', '', $phone);//Not good practice
                
                $data = array();
                
                $data['phone'] = '+243'.$phone;
                $data['message'] = $message;
                
                #### url du web service
                $url = 'http://34.72.60.38/v2/api/twilio/scripts/sendsms.php';
                
                $curl = curl_init();

                curl_setopt_array($curl, array(
                      CURLOPT_URL => $url,
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => '',
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 0,
                      CURLOPT_FOLLOWLOCATION => true,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => 'POST',
                      CURLOPT_POSTFIELDS =>$data
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                
                return trim($response);
	}
        
         /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */


        
        public function save_objects_name($data, $id)
	{
                $this->set_table('TABLE', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}

         /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function get_agency_maps($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
               
                $query = $this->db->table('location_agency')
                        ->select('location_agency.*')
                        ->get();
                return $query->getResult();
	}





}
