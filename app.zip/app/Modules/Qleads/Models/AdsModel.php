<?php
namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class AdsModel extends MY_Qleads {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_ads'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Branchid_7', 'Region_8', 'Device_9', 'Type_10', 'Content_11', 'Source_12', 'Startdate_13', 'Enddate_14', 'Frenquency_15'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;

        public function __construct()
        {
                parent::__construct();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_ads_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Branchid_7 = '';
                        $obj->Region_8 = '';
                        $obj->Device_9 = '';
                        $obj->Type_10 = '';
                        $obj->Content_11 = '';
                        $obj->Source_12 = '';
                        $obj->Startdate_13 = '';
                        $obj->Enddate_14 = '';
                        $obj->Frenquency_15 = '';
                        $obj->Priority_16 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('qleads_ads g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                

        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_ads($bankid, $banchid, $deviceid)
        {
                $today = gmdate('Y-m-d');
                $st = "Status_2='1' AND Account_3='".$bankid."' AND Branchid_7='".$banchid."' AND Device_9='".$deviceid."' AND '" . $today . "' BETWEEN Startdate_13 AND Enddate_14";   
                
                $query = $this->db->table('qleads_ads as items')
                        ->select('items.Id_0, items.Branchid_7, items.Region_8, items.Device_9, items.Type_10, items.Content_11, items.Startdate_13, items.Enddate_14, items.Frenquency_15, items.Priority_16')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                        
                return $query->getResult();
	}
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_objects_name($data, $id)
	{
                $this->set_table('qleads_ads', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
}