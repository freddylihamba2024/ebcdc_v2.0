<?php

namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class AppointmentModel extends MY_Qleads {
        
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_appointments'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;

        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Branchid_7', 'Type_8', 'Category_9', 'Name_10', 'Description_11', 'Cellphone_12', 'Email_13', 'Customerdate_14', 'Customertime_15', 'Appointmentcode_16', 'Tellerid_17',  'Tellerdate_18', 'Tellertime_19', 'Tellercomment_20', 'Supervisorid_21', 'Instructions_22', 'Confirmation_23', 'Clientid_24'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;


        public $type_customer = array(
                ''=> '', 
                '0' => 'Ordinaire',
                '1' => 'VIP'
            );
            
            public $status = array(
                   ''=>"",
                   '0'=>"Annulé",
                   '1'=>"Activé",
                   '2'=>"Accepté",
                   '3'=>"Rejeté",
                   '4'=>"Confirmé",
                   '5'=>"Complet",
                   '6'=>"Reporté",       
            );
    
        
	public function __construct()
	{
		parent::__construct();
	}
        

       
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_appointment_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Branchid_7='';
                        $obj->Type_8='';
                        $obj->Category_9='';
                        $obj->Name_10='';
                        $obj->Description_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Customerdate_14='';
                        $obj->Customertime_15='';
                        $obj->Appointmentcode_16='';
                        $obj->Tellerid_17='';
                        $obj->Tellerdate_18='';
                        $obj->Tellertime_19='';
                        $obj->Tellercomment_20='';
                        $obj->Supervisorid_21='';
                        $obj->Instructions_22='';
                        $obj->Confirmation_23='';
                        $obj->Clientid_24='';
                        $obj->Town_25='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_appointments', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
 
        
        public function get_appointment_info_by_code($appointmentCode=NULL)
	{
		if($appointmentCode==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Branchid_7='';
                        $obj->Type_8='';
                        $obj->Category_9='';
                        $obj->Name_10='';
                        $obj->Description_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Customerdate_14='';
                        $obj->Customertime_15='';
                        $obj->Appointmentcode_16='';
                        $obj->Tellerid_17='';
                        $obj->Tellerdate_18='';
                        $obj->Tellertime_19='';
                        $obj->Tellercomment_20='';
                        $obj->Supervisorid_21='';
                        $obj->Instructions_22='';
                        $obj->Confirmation_23='';
                        $obj->Clientid_24='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_appointments', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Appointmentcode_16' => $appointmentCode, 'Status_2' => 2), TRUE);
		}
	}

        public function get_qlead_user($userID)
	{
		$this->set_table('qleads_users', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Userid_7' => $userID, 'Status_2' => 1), TRUE);
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="categories_vip")
                {   
                        $st = "Status_2 > '0' AND Vip_15 = '1'";
                        $query = $this->db->table('qleads_queues')
                                            ->where($st)
                                            ->orderBy('Categorieslist_8')
                                            ->get();

                        foreach ($query->getResultArray() as $row) 
                        {
                                $categories[] =  $row['Categorieslist_8'];
                        }
                
                        $categorie = implode(',', $categories);
                        $categories = explode(',', $categorie);
                        
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($categories as $row)
                        {
                                $ddmenu[$row] = $row;
                        }
                        
                        return $ddmenu;
                }
        }

        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_appointments($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                $user_id = $this->session->userdata['user_id'];

                $st = "Account_3='" . $account_id . "'";

                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == 3)
                {
                        $st .= " AND Branchid_7='" . $branch_id . "'";
                }
                elseif (isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == 1)
                {
                        $st .= " AND Tellerid_17='".$user_id."'AND Branchid_7='" . $branch_id . "'";
                }

                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}


        public function get_appointments_filter($data)
        {
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                $user_id = $this->session->userdata['user_id'];

                $st = "(Account_3='" . $account_id . "')";

                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == 3)
                {
                        $st .= " AND Branchid_7='" . $branch_id . "'";
                }
                elseif (isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == 1)
                {
                        $st .= " AND Tellerid_17='".$user_id."'AND Branchid_7='" . $branch_id . "'";
                }

                # Filtre d'affichage
                if(isset($data['status']) && $data['status']!='') $st .= " AND Status_2 ='".$data['status']."'";
                if(isset($data['users']) && $data['users']!='') $st .= " AND Tellerid_17 ='".$data['users']."'";

                if(isset($data['start']) && $data['start']!='') 
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('qleads_appointments')
                                ->select('qleads_appointments.*')
                                ->where($st)
                                ->get();

                return $query->getResult();


        }
        public function get_appointments_by_phone($phone)
	{
                $st = "Cellphone_12='".$phone."'";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}

        public function count_appointment_by_category()
	{
                $date = gmdate('Y-m-d');
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                
                $st = " Account_3='" . $account_id . "'";
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] < 5)
                {
                        $st .= " AND Branchid_7='" . $branch_id . "'";
                }
                
                $query = $this->db->table('qleads_appointments')
                        ->select('COUNT(qleads_appointments.Id_0) as total, qleads_appointments.Category_9 as category')
                        ->where($st)
                        ->groupBy('qleads_appointments.Category_9')
                        ->orderBy('total DESC')
                        ->get();
                return $query->getResult();
	}


        public function get_appointement($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                

                $st = "Account_3='" . $account_id  . "' AND  Status_2='1' AND Date_1 LIKE '%" . gmdate('Y-m-d') . "%'  ";
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] < 5)
                
                {
                        $st .= " AND  Branchid_7='".$branch_id."' ";
                        

                }
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}

        public function get_appointement_confirmed()
	{
                $account_id = $this->session->userdata['account_id'];
                $branch_id = $_SESSION['Branchid'];
                $st = "Account_3='" . $account_id . "' AND  Status_2='4' AND Branchid_7='" . $branch_id . "' AND Changes_5 LIKE '%" . gmdate('Y-m-d') . "%' ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}


        public function get_appointement_teller($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $user_id = $this->session->userdata['user_id'];
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND  Tellerid_17='" . $user_id . "' ";
                
                $query = $this->db->table('qleads_appointments')
                        ->select('qleads_appointments.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        

         /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function send_sms($phone, $message)
	{
                $phone = str_replace(' ', '', $phone);
                $phone = str_replace('+243', '', $phone);
                $phone = str_replace('00243', '', $phone);//Not good practice
                
                $data = array();
                
                $data['phone'] = '+243'.$phone;
                $data['message'] = $message;
                
                #### url du web service
                $url = 'http://34.72.60.38/v2/api/twilio/scripts/sendsms.php';
                
                $curl = curl_init();

                curl_setopt_array($curl, array(
                      CURLOPT_URL => $url,
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => '',
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 0,
                      CURLOPT_FOLLOWLOCATION => true,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => 'POST',
                      CURLOPT_POSTFIELDS =>$data
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                
                return trim($response);
	}

         
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_appointment($data, $id)
	{
                $this->set_table('qleads_appointments', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        
}