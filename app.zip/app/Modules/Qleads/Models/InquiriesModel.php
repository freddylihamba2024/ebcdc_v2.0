<?php

    namespace Modules\Qleads\Models;

    use App\Models\MY_Qleads;
    use stdClass;

    class InquiriesModel extends MY_Qleads {
	
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
        public $inquiry_status = array(
            ''=>'',
            '1'=>'Success',
            '2' => 'Failed',
            '3' => 'Pending',
            '4' => 'Reached'
        );
        
	public function __construct()
	{
		parent::__construct();
                
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        public function get_inquiry_info($id=NULL)
	{
		if($id==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Categoryid_9=gmdate('Y-m-d H:i:s');
                        $obj->Tokenid_7='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Name_10='';
                        $obj->Description_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Bankaccount_14='';
                        $obj->Currency_15='';
                        $obj->Progress_18='';
                        $obj->Deadline_19='';
                        $obj->Avmfile_20='';
                        $obj->Avmstatus_21='';
                        $obj->Confirmation_22='';
                        
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('qleads_inquiries', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="status")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Status' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="category")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
      
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_tokens($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}


        public function get_inquiries($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('qleads_inquiries')
                        ->select('qleads_inquiries.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_inquiries($data, $id)
	{
                $this->set_table('qleads_inquiries', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function save_objects_name($data, $id)
	{
                $this->set_table('TABLE', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}                
      
}

