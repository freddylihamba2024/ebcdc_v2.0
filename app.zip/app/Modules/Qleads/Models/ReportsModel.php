<?php

namespace Modules\Qleads\Models;

use App\Models\MY_Qleads;
use stdClass;

class ReportsModel extends MY_Qleads {
	
        /* Presentation: 
         * Last update
         * By Glodi  on the 10.11.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $stauts = array(''=> '', '1' => 'Actif', '2' => 'Non actif');
        
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
    
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="inquiry_status")
                {
                        $st = " Status_2!='0' AND Object_7 = 'inquiry_status' ";
                        
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ttile_8'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="token_category")
                {
                        $st = " Status_2!='0' AND Object_7 = 'token_category' ";
                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ttile_8'];
                        }
                        return $ddmenu;
                }
                elseif($item=="users_code")
                {
                        $st = " Status_2!='0' ";
                        $query = $this->db->table('qleads_users')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Userid_7']] = $row['Tellercode_10'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_surveys($status=NULL, $today=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == "3")
                {
                        $st = "Account_3='" . $account_id . "' AND Branchid_9='" . $branch_id . "'";
                }
                elseif(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == "1")
                {
                        $st = "Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "'AND Branchid_9='" . $branch_id . "'";
                }
                else
                {
                        $st = "Account_3='" . $account_id . "'";
                }
                
                if($today!=NULL)
                {
                        $st .= "Account_3='" . $account_id . "' AND Date_1='Like%" . $today . "%'";
                }
                

                $query = $this->db->table('qleads_surveys')
                        ->select('qleads_surveys.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_surveys_filter($data)
        {
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "')";

                # Filtre d'affichage
                if(isset($data['guichet']) && $data['guichet']!='') $st .= " AND Branchid_9  ='".$data['guichet']."'";
                if(isset($data['categories']) && $data['categories']!='') $st .= " AND Branchid_8 ='".$data['categories']."'";

                if(isset($data['start']) && $data['start']!='') 
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('qleads_surveys')
                                ->select('qleads_surveys.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_performance($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                $st = "Account_3='" . $account_id . "' ";
                
                #Restriction
                if($_SESSION['Logiref_role']==1) $st .= " AND Userid_7='".$user_id."'AND Branchid_8='" . $branch_id . "'";
                if($_SESSION['Logiref_role']==2 || $_SESSION['Logiref_role']==3) $st .= " AND Branchid_8='".$branch_id ."'";
                
                $query = $this->db->table('qleads_performances')
                        ->select('qleads_performances.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_performance_filter($data)
        {
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "')";

                # Filtre d'affichage
                if(isset($data['guichet']) && $data['guichet']!='') $st .= " AND Branchid_8 ='".$data['guichet']."'";
                if(isset($data['user']) && $data['user']!='') $st .= " AND Userid_7 ='".$data['user']."'";

                if(isset($data['start']) && $data['start']!='') 
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('qleads_performances')
                                ->select('qleads_performances.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }
        
       

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION
        */

        public function get_queuing()
	{
                $queue_id = $_SESSION['Queueid'];
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];

                $st = "Account_3='" . $account_id . "' ";
                
                #Restriction
                if($_SESSION['Logiref_role']==1)  $st = "Account_3='" . $account_id . "'AND Queueid_7='" . $queue_id . "' AND Branchid_16='" . $branch_id . "'";
                if($_SESSION['Logiref_role']==2 || $_SESSION['Logiref_role']==3)  $st = "Account_3='" . $account_id ."' AND Branchid_16='" . $branch_id . "'";

               

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_reports_filter_queuing($data)
	{
                $queue_id = $_SESSION['Queueid'];
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];

                $st = "Account_3='" . $account_id . "' ";
                
                # Filtre d'affichage
                if(isset($data['guichet']) && $data['guichet']!='') $st .= " AND Branchid_16 ='".$data['guichet']."'";
                if(isset($data['horaires']) && $data['horaires']!='') $st .= " AND Workload_13 ='".$data['horaires']."'";

                if(isset($data['start']) && $data['start']!='') 
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));

                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }
               

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_visites()
	{
                $queue_id = $_SESSION['Queueid'];
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                
                #Restriction
                if($_SESSION['Logiref_role']==1)  $st = "Account_3='" . $account_id . "' AND Queueid_7='" . $queue_id . "' AND Branchid_16='" . $branch_id . "'";
                if($_SESSION['Logiref_role']==3)  $st = "Account_3='" . $account_id ."' AND Branchid_16='" . $branch_id . "'";

               

                $query = $this->db->table('qleads_queuing')
                        ->select('qleads_queuing.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_ads()
        {
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                
                if($_SESSION['Qleads_role']==3):
                        $st = "Account_3='" . $account_id . "' AND Branchid_7 ='" . $branch_id ."' AND Status_2 != '0' ";
                else:
                        $st = "Account_3='" . $account_id . "' AND Status_2 != '0' ";
                endif;
                
                $query = $this->db->table('qleads_ads')
                        ->select('qleads_ads.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_filter_ads($data)
	{
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                
                if($_SESSION['Qleads_role']==3):
                        $st = "Account_3='" . $account_id . "' AND Branchid_7 ='" . $branch_id ."' AND Status_2 != '0' ";
                else:
                        $st = "Account_3='" . $account_id . "' AND Status_2 != '0' ";
                endif;
                
                #Filtre d'affichage
                if(isset($data['Status_2']) && $data['Status_2']!='') $st .= " AND Status_2='".$data['Status_2']."'";
                if(isset($data['Type_10']) && $data['Type_10']!='') $st .= " AND Type_10='".$data['Type_10']."'";
                if((isset($data['Start']) && $data['Start']!='') && (isset($data['End']) && $data['End']!='')) $st .= " AND Date_1 BETWEEN '".$data['Start']."' AND '".$data['End']."' ";
                
                $query = $this->db->table('qleads_ads')
                        ->select('qleads_ads.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
	}

        public function get_queues()
	{
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                if($_SESSION['Qleads_role']==3):
                        $st = "Account_3='" . $account_id . "' AND Branchid_7 ='" . $branch_id ."' AND Status_2 != '0' ";
                else:
                        $st = "Account_3='" . $account_id . "' AND Status_2 != '0' ";
                endif;
                
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_filter_queues($data)
	{
                $branch_id = $_SESSION['Branchid']; 
                $account_id = $this->session->userdata['account_id'];
                
                if($_SESSION['Qleads_role']==3):
                        $st = "Account_3='" . $account_id . "' AND Branchid_7 ='" . $branch_id ."'";
                else:
                        $st = "Account_3='" . $account_id . "' AND Status_2 != '0' ";
                endif;
                
                #Filtre d'affichage
                if(isset($data['Status_2']) && $data['Status_2']!='') $st .= " AND Status_2='".$data['Status_2']."'";
                if(isset($data['Vip_15']) && $data['Vip_15']!='') $st .= " AND Vip_15='".$data['Vip_15']."'";
                if((isset($data['Start']) && $data['Start']!='') && (isset($data['End']) && $data['End']!='')) $st .= " AND Date_1 BETWEEN '".$data['Start']."' AND '".$data['End']."' ";
                
                
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
      
        public function get_inquirie()
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid']; 
                
                $st = "Account_3='" . $account_id . "'AND  Userid_8='" . $user_id . "'";
                
             #Restriction
                if($_SESSION['Logiref_role']==1) $st .= " AND Userid_8='".$user_id."'";
                if($_SESSION['Logiref_role']==3) $st .= " AND Branchid_23='".$branch_id ."'";

                $query = $this->db->table('qleads_inquiries')
                        ->select('qleads_inquiries.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        public function get_inquirie_by_branchid()
	{
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid']; 
                $st = "Account_3='" . $account_id . "'AND Branchid_23='" . $branch_id . "'";

                $query = $this->db->table('qleads_inquiries')
                        ->select('qleads_inquiries.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
	}


        public function get_users($type=NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $branch_id = $_SESSION['Branchid'];
                
                
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == "3")
                {
                        $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Branchid_9='" . $branch_id . "'";
                }
                else
                {
                        $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                }
                
                $query = $this->db->table('qleads_users')
                        ->select('qleads_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }




         
         
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('TABLE')
                        ->select('TABLE.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
	}
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
        
        public function save_objects_name($data, $id)
	{
                $this->set_table('TABLE', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	
        public function get_token_guichet()
	{
                $branch_id = $_SESSION['Branchid'];
                
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Userid_21 != '0'";
                if(isset($_SESSION['Qleads_role']) && $_SESSION['Qleads_role'] == "3")
                {
                        $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Branchid_22='" . $branch_id . "'";
                }
                else
                {
                        $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                }
                $query = $this->db->table('qleads_tokens')
                        ->select('qleads_tokens.*')
                        ->where($st)
                        ->get();

                return $query->getResult();
                
	}
        public function get_reports_filter_produit_service($data)
        {
                $st = "Status_2 > '0' AND (Account_3='" . $this->session->userdata['account_id'] . "')";

                # Filtre d'affichage
                if(isset($data['guichet']) && $data['guichet']!='') $st .= " AND Branchid_22 ='".$data['guichet']."'";
                if(isset($data['categories']) && $data['categories']!='') $st .= " AND Category_9 ='".$data['categories']."' ";

                if(isset($data['start']) && $data['start']!='') 
                {
                    $formattedStartDate = date('Y-m-d', strtotime($data['start']));
                    $formattedEndDate = date('Y-m-d', strtotime($data['end']));
                    $st .= " AND (Date_1 BETWEEN '".$formattedStartDate." 00:00:00' AND '".$formattedEndDate." 23:59:59') ";
                    $st .= " OR (DATE_FORMAT(Date_1, '%Y-%m-%d') LIKE '%".$formattedStartDate."%')";
                }

                $query = $this->db->table('qleads_tokens')
                                ->select('qleads_tokens.*')
                                ->where($st)
                                ->get();

                return $query->getResult();
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	
        public function get_devices()
	{
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') ";
                $query = $this->db->table('qleads_devices')
                        ->select('qleads_devices.*')
                        ->where($st)
                        ->get();

                return $query->getResult();
	}
        
        
        
}
