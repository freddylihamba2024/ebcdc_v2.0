<?php

namespace Modules\Admin\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\CurlModel;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\AccountModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\StakeholderModel;

class Accounts extends BaseController
{
        /*
         * Presentation: 
         * Last update:
         * By Alvin on the 28.08.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('comptes', 'prepayments', 'dashboard', 'tarification_accounts');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'accounts';
        public $data = [];
        public $mainModal;
        public $accountModel;
        public $logirefModel;
        public $branchModel;
        public $userModel;
        public $stakeholderModel;
        public $curlModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModal = new MainModel();
                $this->accountModel = new AccountModel();
                $this->logirefModel = new LogirefModel();
                $this->branchModel = new BranchModel();
                $this->userModel = new UserModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->curlModel = new CurlModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'accounts';
                $this->data['function'] = '';
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['deny'] = false;
                
                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {   
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect('main/signin', 'refresh');
                }
        }


        public function index()
        {
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
                // $this->data['subview'] = 'container';
                // $this->load->view("_layout_" . $this->module, $this->data);
        }


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }

        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "comptes")
                {
                       
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['agences'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                            
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");     
                                #var_dump($this->data['guichets']);die;  
                                $this->data['comptes'] = $this->accountModel->get_comptes("cptes"); 
                                $this->data['lastestComptes'] = $this->accountModel->get_latest_validated_accounts();
                               
                        } else {
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL"); 
                                $this->data['comptes'] = $this->accountModel->get_comptes();
                              
                        }
                        echo view('\Modules\Admin\Views\accounts\comptes', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/comptes', $this->data);
                } 
                elseif ($obj == "filter") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['comptes'] = $this->accountModel->get_filtered_accounts($_POST);
                        echo view('\Modules\Admin\Views\accounts\_comptes', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_comptes', $this->data);
                } 
                elseif ($obj == "compte") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Compte");
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['service_types'] =$this->accountModel->type_service;
                        $this->data['services'] = $this->logirefModel->get_dropdown("services");
                        $this->data['services_direction'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['banque'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        unset($this->data['beneficiaires']['BKC']);
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['compte'] = $this->accountModel->get_compte_info($id);
                        $this->data['banques'] = $this->accountModel->get_dropdown("beneficiaire");
                        #var_dump($this->data['beneficiaire']);die;
                        echo view('\Modules\Admin\Views\accounts\_compte', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_compte', $this->data);
                } 
                elseif ($obj == "prepayments")
                {
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['comptes'] = $this->accountModel->get_prepaid_comptes();
                        $this->data['sidebar'] = '';
                        echo view('\Modules\Admin\Views\accounts\prepayments', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/prepayments', $this->data);
                } 
                elseif ($obj == "prepayment") 
                {
                        $this->data['from'] = $arg;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['compte'] = $this->accountModel->get_prepaid_compte_info($id);
                        echo view('\Modules\Admin\Views\accounts\_prepayment', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_prepayment', $this->data);
                } 
                elseif($obj == "tarification_accounts")
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['agences'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['title'] = ($_SESSION['Logiref_role'] == "2") ? 'hidden' : "";
                        $this->data['tarifications'] = $this->accountModel->get_client_exoneres();
                        $this->data['lastestComptes'] = $this->accountModel->get_latest_validated_accounts();
                        
                        echo view('\Modules\Admin\Views\accounts\tarification_accounts', $this->data);
                }
                elseif($obj == "tarification_account") 
                {
                        #$this->data['from'] = $arg;
                        $this->data['tarification'] = $this->accountModel->get_clientexonere_info($id);
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        
                        echo view('\Modules\Admin\Views\accounts\_tarification_account', $this->data);
                }
                elseif($obj == "filterTarif")
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['agences'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['tarifications'] = $this->accountModel->get_filtered_tarifications($_POST);

                        echo view('\Modules\Admin\Views\accounts\_tarification_accounts', $this->data);
                }
                elseif ($obj == "dashboard")
                {
                        echo view('\Modules\Admin\Views\accounts\dashboard', $this->data);
                }
                #Default
                elseif ($obj == "deny") 
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                        // $this->load->view($this->lang . '_denial', $this->data);
                }
        }




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "compte") 
                {
                        #Save compte
                        # Validate compte form

                        if ($_POST['Compte_6'] == '0' || $_POST['Compte_6'] == ''  || $_POST['Devise_8'] == ''  || (($_POST['Beneficiaires1'] ?? '') == '' && ($_POST['Beneficiaires2'] ?? '') == '' && ($_POST['Beneficiaires3'] ?? '') == '')  || $_POST['Type_4'] == '') 
                        {
                                echo '<div class="w-100 alert alert-danger">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        }

                        if ($_SESSION['Logiref_role'] == 1) 
                        {
                                $data['Type_4'] = $_POST['Type_4'];
                        
                                if ($data['Type_4'] === "CPI" || $data['Type_4'] === "CPB" || $data['Type_4'] === "CPO" || $data['Type_4'] === "CFC" || $data['Type_4'] === "CTC") 
                                {
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires1'];
                                }
                                elseif ($data['Type_4'] === "CPT" || $data['Type_4'] === "CGU" || $data['Type_4'] === "CSC" || $data['Type_4'] === "MAD" || $data['Type_4'] === "CTG") 
                                {
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires3'];
                                }
                                else 
                                {
                                        
                                        $data['Beneficiaires_5'] = $_POST['Beneficiaires2'];
                                }

                                // Read only the fields belonging to the selected beneficiary.
                                $regieFields = in_array($data['Type_4'], ['CPT', 'CGU', 'CSC', 'MAD', 'CTG'], true);
                                $suffix = $regieFields ? (['DGI' => '1', 'DGRAD' => '2', 'DGDA' => '3'][$data['Beneficiaires_5']] ?? '') : '';
                                $service = $_POST[$suffix !== '' ? 'service_dir' . $suffix : 'service'] ?? '';
                                $recette = $_POST[$suffix !== '' ? 'recette' . $suffix : 'recette'] ?? '';
                                $category = $regieFields && $data['Beneficiaires_5'] === 'DGI' ? ($_POST['category'] ?? '') : '';

                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') 
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Makerid_9'] = $this->session->userdata['user_id'];
                                        
                                        $devise = $this->request->getPost("Devise_8");
                                        $type = $this->request->getPost("Type_4");
                                        $agence = $this->request->getPost("agence");
                                        $compte = $this->request->getPost("Compte_6");
                                        
                                        $beneficiaire = $data['Beneficiaires_5'];

                                        
                                        if ($agence == "" || $agence == '0') 
                                        {
                                                echo '<div class="w-100 alert alert-warning">Vous devez s&eacute;l&eacute;ctionner une agence !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;

                                        }

                                        $comptes = $this->accountModel->get_comptes_by_parameters($compte, $devise, $type, $beneficiaire, $agence, $recette, $service);

                                        if (!empty($comptes)) 
                                        {
                                                echo '<div class="w-100 alert alert-danger">D&eacute;sol&eacute;, il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                }
                                else
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Makerid_9'] = $this->session->userdata['user_id'];
                                }
                                
                                $data['Nivellement_20'] = !empty($_POST['nivellement']) ? 1 : 0;
                                $data['Bank_21'] = $_POST['banque'] ?? '';
                                
                                #Optional keys
                                $data['Compte_6'] = $_POST['Compte_6'];
                                
                                #Devise par defaut
                                if ($data['Type_4'] == 'CPU') $data['Devise_8'] = 'USD';
                                elseif ($data['Type_4'] == 'TVA') $data['Devise_8'] = 'CDF';
                                #elseif($data['Type_4']=='CFB') $data['Devise_8']= 'CDF';
                                elseif ($data['Type_4'] == 'CCV') $data['Devise_8'] = 'CDF';
                                else $data['Devise_8'] = $_POST['Devise_8'];
                                #Validation section

                                if (isset($_POST['agence'])) 
                                {
                                        $data['Agence_12'] = $_POST['agence'];
                                }
                                
                                $data['Recette_13'] = $recette;
                                $data['Category_22'] = $category;
                                $data['Serviceid_16'] = $service;
                                $data['Nif_17'] = $_POST['nif'] ?? '';
                                $data['Comptesydonia_18'] = $_POST['comptesydonia'] ?? '';
                                $data['Numimportateur_23'] = $_POST['clt'] ?? '';

                                $data['Agenceid_15'] = $_POST['Agenceid_15'];

                                //$data['Validation_10'] = '0000-00-00';
                                $data['Checkerid_11']=0;
                        }
                        else
                        {
                                $data['Validation_10'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11'] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $cid = $this->accountModel->save_compte($data, $id);
                        #var_dump($cid);die;
                        
                        if ($cid) :
                                echo '<div class="w-100 alert alert-success">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                } 
                elseif ($obj == 'prepayment')
                {
                        # Save compte
                        # Validate compte form 
                        #var_dump($_POST); die;
                        if ($_POST['Accountnumber'] == '0' || $_POST['Accountnumber'] == ''  || $_POST['Devise'] == ''  || ($_POST['Refsydonia'] == '0' && $_POST['Refsydonia'] == '')) :
                                echo '<div class="w-100 alert alert-danger">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        endif;
                        if ($id == '0' || $id == '') :
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Makerid_11'] = $this->session->userdata['user_id'];
                        endif;
                        if ($_SESSION['Logiref_role'] == 1) :

                                $data['Devise_10'] = $devise = $this->request->getPost("Devise");
                                $data['Nifimportateur_7'] = $this->request->getPost("Nifimportateur");
                                $data['Refsydonia_9'] = $accountSydonia = $this->request->getPost("Refsydonia");
                                $accountcbs = $data['Accountnumber_8'] = $this->request->getPost("Accountnumber");

                                $count_number = $this->accountModel->tcheck_prepaid_account($accountcbs, $devise);

                                if (!empty($count_number)) {
                                        echo '<div class="w-100 alert alert-danger">D&eacute;sol&eacute; il existe  d&eacute;j&agrave; un compte avec les informations que vous avez renseign&eacute;es !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        die;
                                }

                                $data['Validation_13'] = '0000-00-00';
                                $data['Checkerid_12'] = 0;
                        else :

                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                $data['Validation_13'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_12'] = $this->session->userdata['user_id'];
                        endif;
                        #Database
                        $cid = $this->accountModel->save_prepaid_accounts($data, $id);
                        if ($cid) :
                                echo '<div class="w-100 alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                 else if($obj == "tarification_account")
                {
                        $data = array();

                        if($_SESSION['Logiref_role']==1):
                                if(isset($_POST['Beneficiaires3']) && $_POST['Beneficiaires3'] !="") 
                                        $data['Beneficiaires_7'] = $_POST['Beneficiaires3'] ?? "";

                                $data['Date_1']    = date('Y-m-d H:i:s');
                                $data['Status_2']  = '1';
                                $data['Account_3'] = $this->session->userdata['account_id'];

                                $infos = isset($_POST['Infos']) ? $_POST['Infos'] : NULL;
                                $data['Infos_14'] = json_encode($infos);

                                $data['Devise_10'] = $_POST["Devise_10"] ?? "";
                                $data['Agence_12'] = $_POST['agence'] ?? "";
                                $data['Compte_8']  = $_POST['Compte_8'] ?? "";

                                if (isset($_POST['amount']))
                                {
                                        $data['Montant_11'] = str_replace(' ','',$_POST['amount']);
                                        $data['Montant_11'] = str_replace(',','.',$data['Montant_11']);
                                }
                                else
                                {
                                        $data['Montant_11'] = NULL;
                                }

                                if (isset($_POST['Compte_8'])) 
                                    $aCmpt = explode("-", trim($_POST['Compte_8']));
                                else
                                    $aCmpt = []; // ou null selon votre logique


                                #Optional keys
                                if(count($aCmpt) > 2)
                                {
                                    if(isset($aCmpt[0])) $data['Agenceid_9'] = trim($aCmpt[0]);
                                    if(isset($aCmpt[1])) $data['Compte_8'] = str_replace('-','',$_POST['Compte_8']);
                                    if(isset($aCmpt[2])) $data['Clef_15'] = trim($aCmpt[2]);
                                }
                                else
                                {
                                        if (($_SESSION['userdata']['account_id'] ?? '') != 36)
                                        {
                                                if(isset($aCmpt[0])) $data['Agenceid_9'] = trim($aCmpt[0]);
                                                if(isset($aCmpt[1])) $data['Compte_8'] = str_replace('-','',$_POST['Compte_8']);
                                        }
                                }

                                $data['Validation_13']  ='0000-00-00';
                                $data['Changer_6']      = 0;
                                $data['Creator_4']      = $this->session->userdata['user_id'];
                        else:
                                $data['Validation_13']  = gmdate('Y-m-d H:i:s');
                                $data['Changer_6']      = $this->session->userdata['user_id'];
                        endif;

                        #Database
                        $cid = $this->accountModel->save_tarification_account($data, $id);    
                        if($cid): 
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif ($obj == "OBJ ")
                {

                }
        }


        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "get_users")
                {
                        $members = $this->userModel->get_members();
                        $type = $this->session->userdata['user_type'];
                        if (empty($members) && $type == 200) {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Role_4'] = 3;
                                $data['Province_5'] = 0;
                                $data['Ville_6'] = 0;
                                $data['Agence_7'] = 0;
                                $data['Guichet_8'] = 0;
                                $data['Privileges_10'] = 0;
                                $data['Regies_11'] = '';
                                $data['Code_12'] = 0;
                                $data['Userid_13'] = $this->session->userdata['user_id'];
                                $cid = $this->userModel->save_users($data, NULL);
                                if ($cid) $members = $this->userModel->get_members();
                        }
                        return $members;
                }
                elseif ($obj == "get_accountname")
                {

                        $data = array();
                        $data['Compte_33'] = $_POST['compte'];
                        $data['Devise_34'] = $_POST['devise'];
                        $data['agence'] = $_SESSION['Guichet_code'];
                        $return = $this->curlModel->call_bank_account_info($data);
                        // var_dump($return); die;
                        if ($return == '404' || $return == '406' || $return == '405')
                        {
                                echo $return;
                        }
                        else
                        {
                                $response = json_decode($return, true);
                                if (isset($response['ACCTNAME']) && $response['ACCTNAME'] != "")
                                {
                                        echo $response['ACCTNAME'];
                                }
                                else
                                {
                                        echo '406';
                                }
                        }
                }
                elseif ($obj == "get_account_balance")
                {
                        if (isset($_POST['montant']) && isset($_POST['commission']) && isset($_POST['compte']) && isset($_POST['devise'])) {
                                $amount = str_replace(' ', '', $_POST['montant']);
                                $amount = str_replace(',', '.', $amount);

                                $commission = str_replace(' ', '', $_POST['commission']);
                                $commission = str_replace(',', '.', $commission);

                                $tva = $commission * 0.16;

                                $amount_to_pay = $amount + $tva + $commission;

                                $data = array();

                                $data['bank_account'] = $_POST['compte'];
                                $data['devise_account'] = $_POST['devise'];
                                $data['amount'] = $amount_to_pay;

                                $return = $this->curlModel->call_bank_checkbalance($data);

                                if ($return == 200 || $return == 300)
                                {
                                        echo $return;
                                }
                                else
                                {
                                        echo '411';
                                        die;
                                }
                        }
                        else
                        {
                                echo '405';
                                die;
                        }
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */