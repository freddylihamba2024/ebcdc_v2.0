<?php

namespace Modules\Admin\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\RatesModel;
use Modules\Admin\Models\BranchModel;
use Modules\Logiref\Models\TaxesModel;
use Modules\Admin\Models\SettingsModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\IntegrationModel;
use Modules\Admin\Models\StakeholderModel;

class Settings extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('privileges', 'taxes', 'services', 'provinces', 'agences', 'villes', 'comptes', 'beneficiaries', 'guichets', 'regles', 'privileges', 'penalites', 'souscriptions', 'prospects', 'taux', 'recettes', 'regions', 'integrations', 'sydonia', 'isys', 'rtgs', 'cbs', 'settings', 'prepayments', 'settings_regies', 'settings_bcc', 'ipaddress', 'functionnalities');

        public $group = ''; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $roles = '5';
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'settings';

        /**Models */
        public $mainModel;
        public $logirefModel;
        public $feesModel;
        public $branchModel;
        public $integrationModel;
        public $rateModel;
        public $userModel;
        public $stakeholderModel;
        public $taxeModel;
        public $settingModel;

        public $role;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                */
                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->feesModel = new FeesModel();
                $this->branchModel = new BranchModel();
                $this->integrationModel = new IntegrationModel();
                $this->rateModel = new RatesModel();
                $this->userModel = new UserModel();
                $this->stakeholderModel = new StakeholderModel();
                $this->taxeModel = new TaxesModel();
                $this->settingModel = new SettingsModel();

                $this->lang = 'fr';
                $user_roles = $this->session->userdata['user_roles'];

                $this->data['module'] = $this->module;
                $this->data['application'] = 'settings';
                $this->data['function'] = '';
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $this->data['deny'] = false;

                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] != "200") {
                        #$this->display('deny');
                }

                //Exchange rate
                if (!isset($_SESSION['Exchange_rates'])) {
                        $this->data("set_exchange_rates");
                }

                //Group
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect('logiref', 'refresh');
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * List: 
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                $fullscreen_items = array('agences', 'penalites', 'souscriptions');

                if (in_array($needle, $this->menus) && in_array($needle, $fullscreen_items)) {
                        $this->data['sidebar'] = '';
                        $this->index();
                } elseif (in_array($needle, $this->menus)) {
                        $this->index();
                }
        }


        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "integrations")
                {
                        echo view('\Modules\Admin\Views\settings\integrations', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/integrations', $this->data);
                }
                elseif ($obj == "ipaddress")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        $this->data['list'] = $this->logirefModel->get_ipaddress();

                        echo view('\Modules\Admin\Views\settings\ipaddress', $this->data);
                }
                elseif ($obj == "settings")
                {
                        $this->data['view'] = $id;
                        $this->data['controller'] = $arg;
                        echo view('\Modules\Admin\Views\settings\settings', $this->data);
                }
                elseif ($obj == "filter_sydonia") 
                {
                        $this->data['status'] = $this->integrationModel->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integrationModel->filter_logs_sydonia($_POST);
                        echo view('\Modules\Admin\Views\settings\logs_sydonia', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/logs_sydonia', $this->data);
                }
                elseif ($obj == "filter_isys") 
                {
                        $this->data['status'] = $this->integrationModel->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integrationModel->filter_logs_isys($_POST);
                        echo view('\Modules\Admin\Views\settings\logs_isys', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/logs_isys', $this->data);
                }
                elseif ($obj == "filter_rtgs") 
                {
                        $this->data['status'] = $this->integrationModel->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integrationModel->filter_logs_rtgs($_POST);
                        echo view('\Modules\Admin\Views\settings\logs_rtgs', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/logs_rtgs', $this->data);
                }
                elseif ($obj == "filter_cbs") 
                {
                        $this->data['status'] = $this->integrationModel->sydonia_error_code;
                        $logs = $this->data['logs'] = $this->integrationModel->filter_logs_cbs($_POST);
                        echo view('\Modules\Admin\Views\settings\logs_cbs', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/logs_cbs', $this->data);
                } 
                elseif ($obj == "recettes") {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Recette");
                        $this->data['recettes'] = $this->logirefModel->get_taxes_codes("");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        echo view('\Modules\Admin\Views\settings\recettes', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/recettes', $this->data);
                } 
                elseif ($obj == "recette") 
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Recette");
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("beneficiaries");
                        $this->data['recette'] = $this->logirefModel->get_recette_info($id);
                        $this->data['from'] = $arg;
                        echo view('\Modules\Admin\Views\settings\_recette', $this->data);
                        // $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_recette', $this->data);
                }
                elseif ($obj == "services")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['services'] = $this->logirefModel->get_services(NULL);
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['sidebar'] = '';
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Admin\Views\settings\services', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/services', $this->data);
                }
                elseif ($obj == "service")
                {
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['service'] = $this->logirefModel->get_service_info($id);
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("regies");
                        echo view('\Modules\Admin\Views\settings\_service', $this->data);
                        // $this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/_service', $this->data);
                }
                elseif($obj == "regions")
                {

                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['regions'] = $this->logirefModel->get_regions();
                         $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Admin\Views\settings\regions', $this->data);
                }
                elseif($obj == "region")
                {
                        #var_dump("Youpiii");die;
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['region'] = $this->logirefModel->get_region_info($id);
                         $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Admin\Views\settings\_region', $this->data);
                }
                elseif ($obj == "rtgs") 
                {

                        $this->data['logs'] = $this->integrationModel->get_rtgs_logs();
                        echo view('\Modules\Admin\Views\settings\rtgs', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/rtgs', $this->data);
                } 
                elseif ($obj == "cbs") 
                {
                        $this->data['logs'] = $this->integrationModel->get_cbs_logs();
                        echo view('\Modules\Admin\Views\settings\cbs', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/settings/cbs', $this->data);
                } 
                elseif ($obj == "souscriptions")
                {
                        $this->data['souscriptions'] = $this->taxeModel->get_souscriptions();
                        #var_dump($this->data['souscriptions']);die;
                        $this->data['prospects'] = $this->taxeModel->get_prospects();
                        $this->data['categorie'] = $this->taxeModel->get_dropdown("categories", "prospect");
                        echo view('\Modules\Admin\Views\settings\cbs', $this->data);
                        // $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/souscriptions', $this->data);
                } 
                elseif ($obj == "souscription") 
                {
                        $this->data['souscriptions'] = $this->taxeModel->get_souscriptions();
                        #var_dump($this->data['souscriptions']);die;
                        $this->data['prospects'] = $this->taxeModel->get_prospects();
                        $this->data['categorie'] = $this->taxeModel->get_dropdown("categories", "prospect");
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/_souscription', $this->data);
                }
                #Recuperation de l'id de la declaration
                elseif ($obj == "declaration")
                {
                        $declare = $id;
                        $this->data['categorie'] = $this->taxeModel->get_dropdown("categories");
                        $this->data['lines'] = $this->taxeModel->get_declarations($declare);
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/_declarations', $this->data);
                } 
                elseif ($obj == "prospects")
                {
                        $this->data['prospects'] = $this->taxeModel->get_prospects();
                        $this->data['categorie'] = $this->taxeModel->get_dropdown("categories");
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/prospects', $this->data);
                } 
                elseif ($obj == "prospect") 
                {
                        $this->data['prospects'] = $this->taxeModel->get_prospects();
                        $this->data['categorie'] = $this->taxeModel->get_dropdown("categories");
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/_prospect', $this->data);
                }
                elseif ($obj == "agences") 
                {
                        $this->data['agences'] = $this->logirefModel->get_agences("");
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/agences', $this->data);
                } 
                elseif ($obj == "provinces") 
                {
                        $this->data['provinces'] = $this->logirefModel->get_referentiel("PROVINCE");
                        $this->data['sidebar'] = '';
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/provinces', $this->data);
                }
                elseif ($obj == "villes")
                {
                        $this->data['villes'] = $this->logirefModel->get_referentiel("VILLE");
                        $this->data['provinces'] = $this->logirefModel->get_referentiel("PROVINCE");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        echo view('\Modules\Admin\Views\settings\villes', $this->data);
                }
                elseif ($obj == "province_villes")
                {
                        $villes = $this->logirefModel->get_dropdown("provinces_villes", $id);
                        if(!empty($villes))
                        {
                                $response=['code'=>200, 'data'=>$villes];
                        }
                        else
                        {
                                $response=['code'=>404, 'data'=>$villes];
                        }
                        // $this->data['provinces'] = $this->logirefModel->get_referentiel("PROVINCE");
                        return $this->response->setJSON($response);
                }
                elseif ($obj == 'referentiel')
                {

                        $this->data['referentiels'] = $this->logirefModel->referentiel;
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("provinces");
                        $this->data['referentiel'] = $this->logirefModel->get_parameter_info($id);

                        $this->data['from'] = $arg;
                        echo view('\Modules\Admin\Views\settings\_referentiel', $this->data);
                        //$this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_referentiel', $this->data);
                } 
                elseif ($obj == "integrations")
                {
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Beneficiaire");

                        $this->data['beneficiairie'] = $this->settingModel->get_beneficiarie_info($id);
                        $this->data['beneficiaries'] = $this->settingModel->get_beneficiaries();
                        $this->data['beneficiaires'] = $this->logirefModel->get_dropdown("beneficiaries");

                        $this->load->view($this->module . '/' . $this->group . '/settings/integrations', $this->data);
                } 
                elseif ($obj == "taux") 
                {
                        $this->data("default_values_new_taux");
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/_taux', $this->data);
                }
                elseif ($obj == "charges") 
                {
                        $data = array();
                        $data = $_POST;
                        #$data['montant'] = filter_var($data['montant'], FILTER_SANITIZE_NUMBER_INT);
                        $valeurs = $this->feesModel->get_bank_charges($data['regie'], $data['service'], NULL, $data['devise'], $data['montant'], $data['guichet']);
                        if ($valeurs['Valeur'] != 0 && $valeurs['Unite'] == '%') {
                                $com['com'] = ($data['Montant_11'] * $valeurs['Valeur']) / 100;
                                $com['devise'] = $data['Devise_12'];
                        } elseif ($valeurs['Valeur'] != '' && $valeurs['Unite'] != '') {
                                $com['com'] = $valeurs['Valeur'];
                                $com['devise'] = $valeurs['Unite'];
                        }

                        if (!empty($com) && $com['com'] != 0) {
                                $data['commission'] = $com['com'];
                                $data['devise'] = $com['devise'];
                        } else {
                                $data['commission'] = $data['montant'] * 0;
                                $data['devise'] = $data['devise'];
                        }

                        if ($data['devise'] == 'CDF') $data['devise'] = 1;
                        else if ($data['devise'] == 'USD') {
                                $data['devise'] = 2;
                        } else if ($data['devise'] == 'EUR') {
                                $data['devise'] = 3;
                        } else if ($data['devise'] == 'ZAF') {
                                $data['devise'] = 4;
                        } else {
                                $data['devise'] = 1;
                        }
                        $ar = array($data['commission'], $data['devise']);
                        echo json_encode($ar);
                } 
                elseif ($obj == "transactions") 
                {
                        $titre = trim($_POST['titre']);
                        $regie = trim($_POST['regie']);
                        $service = trim($_POST['service']);
                        $titreJSON = $this->logirefModel->get_titre_info($titre, $regie, $service);
                        if (!empty($titreJSON)) {
                                echo '<div class="alert alert-danger  ">Avertissement: numero BL incorrect</div>';
                        }
                } 
                elseif ($obj == "dropdowns") 
                {
                        $what = $arg;
                        $var1 = $param;
                        $error = '';
                        if ($what == "services") {
                                $services_dropdown = $this->logirefModel->get_dropdown("services", $id, $province = NULL, true);
                                $Service_6 = $var1;
                                echo form_dropdown('service', $services_dropdown, $Service_6, 'class="form-control" id="service" required="required" ');
                        } elseif ($what == "guichets") {
                                $guichets_dropdown = $this->settingModel->get_dropdown("guichets", $id);
                                $Guichet_8 = $var1;
                                echo form_dropdown('guichet', $guichets_dropdown, $Guichet_8, 'class="form-control" id="guichet"');
                        } elseif ($what == "recettes") {
                                $recettes_dropdown = $this->logirefModel->get_dropdown('recettes', $id);
                                $Recette_7 = $var1;
                                echo form_dropdown('recette', $recettes_dropdown, $Recette_7, 'class="form-control" id="recette" required="required" ');
                        } elseif ($what == "services-o") {
                                $beneficiaires = $this->logirefModel->getBeneficiaresDropdown();
                                $Service_16 = $var1;
                                echo form_dropdown('Service_14', $beneficiaires[$id], $Service_16, 'class="form-control"  id="service" ');
                        } elseif ($what == "recettes-o") {
                                $recettes = $this->logirefModel->getRecettesDropdown();
                                $Typerecette_17 = $var1;
                                echo form_dropdown('Typerecette_15', $recettes[$id], $Typerecette_17, 'class="form-control" id="recette" ');
                        }
                        return $error;
                } 
                elseif ($obj == "sydonia") 
                {
                        $this->data['status'] = $this->integrationModel->sydonia_error_code;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['logs'] = $this->integrationModel->get_sydonia_logs();
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/sydonia', $this->data);
                } 
                elseif ($obj == "isys") 
                {
                        $this->data['logs'] = $this->integrationModel->get_isys_logs();
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/isys', $this->data);
                }
                #Dashboard
                elseif ($obj == "dashboard")
                {
                        if ($_SESSION['Exchange_rates'] == 0 || $_SESSION['Exchange_rates'] == 1) {
                                $this->data("default_values_new_taux");
                                $this->load->view('logiref/' . $this->group . '/' . $this->lang . '/_taux', $this->data);
                        } else {
                                $this->data("default_values_new_taux");
                                $this->load->view($this->module . '/' . $this->group . '/' . $this->lang . '/dashboard', $this->data);
                        }
                } 
                elseif ($obj == "settings_regies")
                {
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/' . $obj, $this->data);
                } 
                elseif ($obj == "settings_bcc") 
                {
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/' . $obj, $this->data);
                } 
                elseif ($obj == "isys_account") 
                {
                        $this->data['identifiants'] = $this->integrationModel->get_isys_account_info();
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_isys', $this->data);
                } 
                elseif ($obj == "sydonia_account")
                {
                        $this->data['identifiants'] = $this->integrationModel->get_sydonia_account_info();
                        $this->load->view($this->module . '/' . $this->group . '/' . $this->folder . '/_sydonia', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }



        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                # New payment
                # When type paiement is Comptant

                if ($obj == "taxe") 
                {
                        $data = $_POST;
                        if ($data['Type_4'] == '0' || $data['Type_4'] == '' || $data['Beneficiare_5'] == '' || $data['Recette_6'] == '' || $data['Code_7'] == '') :
                                echo '<div class="alert aDanger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        endif;

                        if ($_SESSION['Logiref_role'] == 1) :
                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') :
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = '0';
                                        $data['Makerid_8'] = $this->session->userdata['user_id'];
                                else :
                                        $data['Makerid_8'] = $this->session->userdata['user_id'];
                                endif;
                                $data['Validation_9'] = '0000-00-00';
                                $data['Checkerid_10'] = 0;
                        else :
                                $data['Validation_9'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_10'] = $this->session->userdata['user_id'];
                        endif;

                        $tid = $this->logirefModel->save_taxe($data, $id); // Enregistre les donnees dans la
                        if ($tid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "service")
                {
                        $data = $_POST;
                        if ($data['Direction_4'] == '0' || $data['Direction_4'] == '' || $data['Service_5'] == '' || $data['Description_6'] == '' || $data['Code_7'] == '' || $data['Province_8'] == '' || $data['Province_8'] == 'Type_9') :
                                echo '<div class="alert aDanger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        endif;

                        if ($_SESSION['Logiref_role'] == 1) :
                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') :
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = '0';
                                        $data['Makerid_10'] = $this->session->userdata['user_id'];
                                else :
                                        $data['Makerid_10'] = $this->session->userdata['user_id'];
                                endif;
                                $data['Validation_11'] = '0000-00-00';
                                $data['Checkerid_12'] = 0;
                        else :
                                $data['Validation_11'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_12'] = $this->session->userdata['user_id'];
                        endif;

                        $sid = $this->logirefModel->save_service($data, $id); // Enregistre les donnees dans la bd
                        if ($sid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "parametre")
                {
                        $data = $_POST;

                        #var_dump($_POST);die;
                        if ($data['Category_3'] == '0' || $data['Category_3'] == '' || $data['Option_4'] == '') :
                                echo '<div class="alert aDanger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        endif;

                        if ($_SESSION['Logiref_role'] == 1) :
                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') :
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = '0';

                                        $data['Code_5'] = '00000';
                                        $data['Makerid_6'] = $this->session->userdata['user_id'];
                                else :
                                        $data['Makerid_6'] = $this->session->userdata['user_id'];
                                endif;
                                $data['Validation_7'] = '0000-00-00';
                                $data['Checkerid_8'] = 0;
                        else :
                                $data['Validation_7'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_8'] = $this->session->userdata['user_id'];
                        endif;

                        $sid = $this->logirefModel->save_parametre($data, $id); // Enregistre les donnees dans la bdv
                        //var_dump($sid);die;
                        if ($sid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "penalite")
                {
                        $fields = array(
                                'Priorite_4' => 'priorite',
                                'Service_6' => 'service',
                                'Recette_7' => 'recette',
                                'Value_9' => 'value',
                                'Unite_10' => 'unite',
                                'Min_11' => 'min',
                                'Max_12' => 'max',
                                'Devise_13' => 'devise',
                        );
                        foreach ($fields as $field => $value) {
                                $data[$field] = $this->request->getPost($value); //On assigne les valeurs de input aux champs de la DB
                        }

                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $data['Makerid_14'] = $this->session->userdata['user_id'];
                        $data['Beneficiaire_5'] = $_SESSION['Logiref_regies'];

                        if ($_SESSION['Logiref_role'] == 1) :
                                $data['Validation_16'] = '0000-00-00';
                                $data['Checkerid_15'] = 0;
                        else :
                                $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_15'] = $this->session->userdata['user_id'];
                        endif;

                        $rid = $this->settingModel->save_penalite($data, $id); // Enregistre les donnees dans la bd
                        if ($rid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "account_isys")
                {

                        if (isset($_POST['identifiant']) && $_POST['password']) {
                                $fields = array(

                                        'Login_7' => 'identifiant',
                                        'Password_8' => 'password',
                                );
                                foreach ($fields as $field => $value) {
                                        $data[$field] = $this->request->getPost($value);
                                }

                                if (isset($id) && $id != "") :
                                        $data['Changes_5'] = date('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                else :
                                        $data['Date_1'] = date('Y-m-d H:i:s');
                                        $data['Status_2'] = '1';
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                endif;
                                $cid = $this->integrationModel->save_isys_account($data, $id);
                        }

                        if ($cid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "account_sydonia")
                {

                        if (isset($_POST['code']))
                        {
                                $fields = array(

                                        'Bank_7' => 'code',
                                        'Login_8' => 'login',
                                        'Password_9' => 'password',

                                );
                                foreach ($fields as $field => $value) {
                                        $data[$field] = $this->request->getPost($value);
                                }

                                if (isset($id) && $id != "") :
                                        $data['Changes_5'] = date('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                else :
                                        $data['Date_1'] = date('Y-m-d H:i:s');
                                        $data['Status_2'] = '1';
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                endif;
                                $cid = $this->integrationModel->save_sydonia_account($data, $id);
                        }

                        if ($cid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                #Enregistrement automatique  des donnees de la table prospect dans la table client et souscription
                elseif ($obj == "prospect") 
                {
                        $info = $this->taxeModel->get_prospect_info($id);
                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] = '2';
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $datas['Creator_4'] = $this->session->userdata['user_id'];
                        $data['Denomination_7'] = $info->Denomination_7;
                        $data['Email_10'] = $info->Email_10;
                        $data['Siege_social_11'] = $info->Siege_social_11;
                        $data['Site_exploitation_12'] = $info->Site_exploitation_12;
                        $data['Idnat_13'] = $info->Idnat_13;
                        $data['Rccm_14'] = $info->Rccm_14;
                        $data['Idfiscal_15'] = $info->Idfiscal_15;
                        #var_dump($info);die;
                        $lid = $this->taxeModel->save_client($data, NULL); // Enregistre les donnees dans la bd
                        if ($lid > 0) {
                                $password = '123456';
                                $datas['Date_1'] = date('Y-m-d H:i:s');
                                $datas['Status_2'] = '2';
                                $datas['Account_3'] = $this->session->userdata['account_id'];
                                $datas['Creator_4'] = $this->session->userdata['user_id'];
                                $datas['Code_8'] =  $this->mainModel->generate_hash($password);
                                $datas['Clientid_9'] = $lid;
                                $datas['Starting_10'] = gmdate('Y-m-d');
                                $datas['Authorities_17'] = $this->session->userdata['account_id'];

                                #Tableau de l'encodage json
                                $validations = array(
                                        'DGI' => '0',
                                        'DGDA' => '0',
                                        'DGRAD' => '0',
                                        'Date' => '0'
                                );
                                $datas['Validation_18'] = json_encode($validations);
                                $datas['Status_2'] = '1';

                                $sid = $this->taxeModel->save_souscription($datas, NULL);

                                $datas = array();
                                $datas['Status_2'] = '2';
                                $datas['Validation_21'] = date('Y-m-d H:i:s');
                                $this->taxeModel->save_prospects($datas, $id);

                                if ($sid) :
                                        echo '<div class="alert aSuccess text-white">Bravo! prospect valid&eacute;; avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                else :
                                        echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                endif;
                        } else {
                                echo '<div class="alert aDanger text-white">Errreur: l\'enregistrement n\'a pas abouti..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                elseif ($obj == "souscription")
                {
                        $line = $this->taxeModel->get_souscription_info($id);
                        $date = date('Y-m-d H:i:s');

                        $content = json_decode($line->Validation_18, true);

                        $content[$_SESSION['Logiref_regies']] = 1;
                        $content['Date'] = $date;
                        $validations = $content;

                        $datas['Validation_18'] = json_encode($validations);

                        $vid = $this->taxeModel->save_souscription($datas, $id);
                        if ($vid) :
                                echo '<div class="alert aSuccess text-white">Bravo! souscription valid&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: la validation n\'a pas abouti.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "region")
                {
                    #var_dump($_POST);die;

                        $data = $_POST;

                        if ($data['Nom_7'] == '' || $data['Comment_9'] == '') :
                                echo '<div class="alert aDanger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        endif;

                        if ($_SESSION['Logiref_role'] == 1) :

                                if($id==NULL || $id == 0)
                                {
                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']=1;
                                        $data['Account_3']=0;
                                        $data['Creator_4']=$this->session->userdata['user_id'];
                                }
                                else
                                {
                                        $data['Changes_5'] = '0000-00-00';
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                }
                        else :
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                        endif;


                        $tid = $this->logirefModel->save_region($data, $id); // Enregistre les donnees dans la 
                        if ($tid) :
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                elseif ($obj == "delete")
                {
                        $object = $this->request->getGet('object');

                        if ($object == 'ipadress')
                        {
                                $data['Date_1'] = date('Y-m-d H:i:s');
                                $data['Status_2'] = '0';
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $return = $this->logirefModel->get_ipaddress_by_id($id);

                                $id = $this->logirefModel->save_ipaddress($data, $id);

                                if (isset($return->Sessionid_8) && $return->Sessionid_8 != "") {
                                        unset($return->Sessionid_8);
                                }
                        }
                }
        }





        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * List:
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                # User priviligies
                # Set or retrieve current user privelegies
                ################################################################################
                if ($obj == "get_users") 
                {
                        $members = $this->userModel->get_members();
                        $type = $this->session->userdata['user_type'];
                        if (empty($members) && $type == 200) {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Role_4'] = 3;
                                $data['Province_5'] = 0;
                                $data['Ville_6'] = 0;
                                $data['Agence_7'] = 0;
                                $data['Guichet_8'] = 0;
                                $data['Privileges_10'] = 0;
                                $data['Regies_11'] = '';
                                $data['Code_12'] = 0;
                                $data['Userid_13'] = $this->session->userdata['user_id'];
                                $cid = $this->userModel->save_users($data, NULL);
                                if ($cid) $members = $this->userModel->get_members();
                        }
                        return $members;
                }

                # Exchnage rates
                # Set or retrieve current / active exchanges rates
                ################################################################################
                elseif ($obj == "set_exchange_rates") 
                {
                        $this->rateModel->get_exchange_rates();
                } 
                elseif ($obj == "default_values_new_taux") 
                {
                        if (isset($_SESSION['Bank_rates_not_validated']) && $_SESSION['Bank_rates_not_validated'] !== 0) {
                                $bank = json_decode($_SESSION['Bank_rates_not_validated'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['id'] = $bank['Id_0'];
                                $this->data['msg'] =  '<div class="alert aDanger text-white">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['bank'] = $bank;
                        } elseif (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0) {
                                $this->data['msg'] =  '<div class="alert aSuccess text-white">Les taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bank_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                if ($bank['Checkerid_11'] == 0) :
                                        $this->data['id'] = $bank['Id_0'];
                                else :
                                        $this->data['id'] = '';
                                        $this->data['reset'] = 1;
                                endif;

                                $this->data['bank'] = $bank;
                        } elseif (isset($_SESSION['Bcc_rates']) && $_SESSION['Bcc_rates'] !== 0) {
                                $this->data['msg'] =  '<div class="alert aDanger text-white">Les taux affich&eacute;s sont de la BCC! Veuillez publier vos taux. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $bank = json_decode($_SESSION['Bcc_rates'], true);
                                $this->data['usd'] = $bank['Dollar_4'];
                                $this->data['eur'] = $bank['Euro_5'];
                                $this->data['rand'] = $bank['Rand_6'];
                                $this->data['pound'] = $bank['Pound_7'];
                                $this->data['bank'] = $bank;
                                $this->data['id'] = '';
                        } else {
                                $this->data['msg'] =  '<div class="alert aWarning text-white">Les taux de la BCC ne sont pas encore disponibles!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                                $this->data['usd'] = 0.0;
                                $this->data['eur'] = 0.0;
                                $this->data['rand'] = 0.0;
                                $this->data['pound'] = 0.0;
                                $this->data['id'] = '';
                        }

                        $this->data['action'] = '...';

                        if (isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 0) {
                                unset($_SESSION['Exchange_rates']);
                        }

                        $this->data['is_checker'] = 0;

                        if ($_SESSION['Logiref_role'] == 3 && isset($_SESSION['Exchange_rates'])) {
                                $this->data['action'] = 'Confirmer';
                                $this->data['is_checker'] = 1;
                                $this->data['msg'] =  '<div class="alert aDanger text-white">En attente de validation!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif ($_SESSION['Logiref_role'] == 4 && isset($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] == 1) {
                                $this->data['action'] = 'Modifier';
                                $this->data['msg'] =  '<div class="alert aWarning text-white">Veuillez contacter votre superviseur pour valider ces taux du jour. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>';
                        } elseif ($_SESSION['Logiref_role'] == 4) {
                                if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== '0')

                                        $this->data['action'] = 'Modifier';
                                else
                                        $this->data['action'] = 'Publier';
                        }
                } elseif ($obj == "get_customer_exempt") {
                        $response = array();

                        $code_import = $_POST['code_import'];

                        //$result = $this->accountModel->get_customer_exempt_by_clt($code_import);
                        $result = $this->feesModel->get_exempt_customers_by_clt($code_import);

                        if (isset($result->Infos_10)) {
                                $infos = json_decode($result->Infos_10, true);
                                $response['provision'] = (isset($infos['provision']) && $infos['provision'] != "") ? '1' : '0';
                                $response['tva'] = (isset($infos['tva']) && $infos['tva'] != "") ? '1' : '0';
                        } else {
                                $response['provision'] = null;
                                $response['tva'] = null;
                        }

                        $return = json_encode($response);

                        echo $return;
                        die;
                }

                # Purpose
                # Description
                ################################################################################
                elseif ($obj == "priority") {
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
