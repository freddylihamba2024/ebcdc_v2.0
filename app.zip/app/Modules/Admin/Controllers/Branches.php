<?php
namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Eximtrade\Models\SeguceModel;

class Branches extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('guichets','provision_batch','');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'branches';
        public $role;
        public $seguceModel;
        

        /** Models */
        public $mainModal;
        public $branchModel;
        public $logirefModel;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModal = new MainModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->seguceModel = new SeguceModel();
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'branches';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['deny'] = false;
                
                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {   
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }

                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "guichets")
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['guichets'] = $this->branchModel->get_guichets("Guichet");
                            
                        }
                        else
                        {
                            $this->data['guichets'] = $this->branchModel->get_guichets();

                        }
                        
                        $this->data['sidebar'] = '';
                        echo view('\Modules\Admin\Views\branches\guichets', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/guichets', $this->data);
                }
                elseif ($obj == "provision_batch") {
                        $this->data['step'] = 0;
                        $this->data['invoices'] = $this->seguceModel->get_invoices();
                        echo view('\Modules\Eximtrade\Views\seguce\_provision_batch_start', $this->data);
                }
                elseif($obj == "guichet") 
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['guichets'] = $this->branchModel->get_dropdown('guichets');
                        $this->data['guichet'] = $this->branchModel->get_guichet_info($id);
                        $this->data['from'] = $arg;
                        
                        #var_dump($this->data['guichet']);die;
                        echo view('\Modules\Admin\Views\branches\_guichet', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_guichet', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "guichet")
                {
                        $data=$_POST;
                        
                        if($data['Nom_4']==''  || $data['Code_10']==''  || $data['Province_6']==''  || $data['Agence_5']=='' || $data['Region_14']=='' || $data['Ville_7']==''):
                                echo '<div class="alert aDanger text-white">Erreur! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;

                        $agence=$this->branchModel->get_agence_by_id($data['Agence_5']);
                   
                        if(empty($agence)):
                                echo '<div class="alert aDanger text-white">Erreur! L\'agence BCC s&eacute;lectionn&eacute;e est invalide. Veuillez v&eacute;rifier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;

                        $data['Agence_5']=$agence['Id_0'];

                        // if($data['Agence_5']!=$data['Ville_7']):
                        //         echo '<div class="alert aDanger text-white">Erreur! L\'agence BCC doit se situer dans la ville s&eacute;lectionn&eacute;e. Veuillez v&eacute;rifier.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        //         die;
                        // endif;
                       
                        if($id==NULL || $id == "")
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Makerid_13']=$this->session->userdata['user_id'];
                                
                                // checks if the code entered has already been used 
                                $guichet = $this->branchModel->get_code_exists($data['Code_10']);
                                if(!empty($guichet))
                                {
                                        echo '<div class="alert aDanger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une agance bancaire cr&eacute;&eacute;&eacute; avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        die;
                                }
                        }
                        else
                        {
                                $branche = $this->branchModel->get_guichet_info($data['Id_0']);
                                if($branche->Code_10 !== $data['Code_10'])
                                {
                                        //checks if the code entered has already been used 
                                        $guichet = $this->branchModel->get_code_exists($data['Code_10']);
                                        if(!empty($guichet))
                                        {
                                                echo '<div class="alert aDanger">D&eacute;sol&eacute; il y a d&eacute;j&agrave; une agance bancaire cr&eacute;&eacute;&eacute; avec ce code !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                die;
                                        }
                                }
                        }
                        
                        if(isset($data['Options']))
                        {
                                $data['Options_13'] = json_encode($data['Options']);
                                unset($data['Options']);
                        }
                        
                        if($_SESSION['Logiref_role']==1):
                                //$data['Validation_12']='0000-00-00';
                                //$data['Checkerid_11']=0;
                                $data['Validation_12']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11']=$this->session->userdata['user_id'];
                        else:
                                $data = array();
                                $data['Validation_12']=gmdate('Y-m-d H:i:s');
                                $data['Checkerid_11']=$this->session->userdata['user_id'];
                        endif;    
                       
                        #var_dump($data); die;

                        #Database
                        $cid = $this->branchModel->save_branche($data, $id);    
                        if($cid): 
                                echo '<div class="alert aSuccess text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert aDanger text-white">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */