<?php

        namespace Modules\Admin\Controllers;

        use App\Controllers\BaseController;
        use Modules\Admin\Models\BranchModel;
        use Modules\Admin\Models\SubscriptionsModel;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Main\Models\MainModel;

        class Subscriptions extends BaseController
        {
                public $menus = array('subscriptions');
                public $roles = '5';
                public $group = 'banks';
                public $lang = 'fr';
                public $module = 'admin';
                public $folder = 'subscriptions';
                public $logirefModel;
                public $branchModel;
                public $mainModel;
                public $subscriptionsModel;
                public $role;

                public function __construct()
                {
                        parent::__construct();

                        $this->logirefModel = new LogirefModel();
                        $this->branchModel = new BranchModel();
                        $this->mainModel = new MainModel();
                        $this->subscriptionsModel = new SubscriptionsModel();

                        $this->data['module'] = $this->module;
                        $this->data['application'] = 'subscriptions';
                        $this->data['function'] = '';
                        $this->data['role'] = $_SESSION['Logiref_role'];
                        $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                        $this->data['lang'] = $this->lang;
                        $this->data['group'] = $this->group;
                        $this->data['documents'] = $this->logirefModel->documents;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['modes'] = $this->logirefModel->modes;
                        $this->data['moyens'] = $this->logirefModel->moyens;
                        $this->data['infos'] = $this->logirefModel->infos;
                        $this->data['currency'] = $this->session->userdata['account_currency'];
                        $this->data['fullname'] = $this->session->userdata['user_fname'];
                        $this->data['userid'] = $this->session->userdata['user_id'];
                        $this->data['i'] = 0;

                        if ($_SESSION['Logiref_role'] == 1) {
                                $this->data['sidebar'] = $this->sidebars->admin_logiref();
                        }
                        elseif ($_SESSION['Logiref_role'] == 2) {
                                $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                        }
                        else {
                                $this->data['sidebar'] = '';
                                $this->data['deny'] = true;
                        }

                        if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                                $this->group = $_SESSION['Logiref_groupe'];
                                $this->role = $_SESSION['Logiref_role'];
                        }
                        else {
                                redirect($this->module, 'refresh');
                        }
                }

                public function index()
                {
                        if ($_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->data['subview'] = '\Modules\Admin\Views\container';
                        echo view('layouts/layout_main', $this->data);
                }

                public function set($needle)
                {
                        if (in_array($needle, $this->menus)) {
                                $this->index();
                        }
                }

                public function display($obj = null, $id = null, $arg = null, $param = null)
                {
                        if ($obj == 'subscriptions')
                        {
                                $this->data['subscriptions'] = $this->subscriptionsModel->get_subscriptions();
                                $this->data['users_count'] = $this->subscriptionsModel->get_counts($this->subscriptionsModel::TABLE_USERS);
                                $this->data['accounts_count'] = $this->subscriptionsModel->get_counts($this->subscriptionsModel::TABLE_ACCOUNTS);
                                $this->data['types'] = $this->subscriptionsModel->subscriptionTypes;
                                $this->data['statuses'] = $this->subscriptionsModel->statuses;

                                echo view('\Modules\Admin\Views\subscriptions\subscriptions', $this->data);
                        }
                        elseif ($obj == 'subscription')
                        {
                                $this->data['subscription'] = $subscription = $this->subscriptionsModel->get_subscription_info($id);
                                $this->data['taxable_event'] = $taxable_event = $this->subscriptionsModel->decode_taxable_event($subscription->Taxable_Event_12 ?? "");
                                $this->data['services'] = $this->subscriptionsModel->get_services();
                                $this->data['recettes'] = $this->subscriptionsModel->get_recettes();
                                $this->data['types'] = $this->subscriptionsModel->subscriptionTypes;
                                $this->data['selectedServices'] = $this->subscriptionsModel->extract_codes($taxable_event['services'] ?? []);
                                $this->data['selectedRecettes'] = $this->subscriptionsModel->extract_codes($taxable_event['recettes'] ?? []);

                                echo view('\Modules\Admin\Views\subscriptions\_subscription', $this->data);
                        }
                        elseif ($obj == 'users')
                        {
                                $this->data['subscription'] = $this->subscriptionsModel->get_subscription_info($id);
                                $this->data['users'] = $this->subscriptionsModel->get_users($id);

                                echo view('\Modules\Admin\Views\subscriptions\users', $this->data);
                        }
                        elseif ($obj == 'user')
                        {
                                $this->data['subscription'] = $this->subscriptionsModel->get_subscription_info($id);
                                $this->data['user'] = $this->subscriptionsModel->get_user_info($arg, $id);
                                $this->data['profileTypes'] = $this->subscriptionsModel->profileTypes;

                                echo view('\Modules\Admin\Views\subscriptions\_user', $this->data);
                        }
                        elseif ($obj == 'accounts' || $obj == 'ribs')
                        {
                                $this->data['subscription'] = $this->subscriptionsModel->get_subscription_info($id);
                                $this->data['accounts'] = $this->subscriptionsModel->get_accounts($id);

                                echo view('\Modules\Admin\Views\subscriptions\ribs', $this->data);
                        }
                        elseif ($obj == 'account' || $obj == 'rib')
                        {
                                $this->data['subscription'] = $this->subscriptionsModel->get_subscription_info($id);
                                $this->data['account'] = $this->subscriptionsModel->get_account_info($arg, $id);

                                echo view('\Modules\Admin\Views\subscriptions\_rib', $this->data);
                        }
                        elseif ($obj == 'overview')
                        {
                                $payload = $this->subscriptionsModel->get_payload($id);

                                if (empty($payload)) {
                                        echo '<div class="alert aWarning text-white">Souscription introuvable.</div>';
                                        return;
                                }

                                $this->data = array_merge($this->data, $payload);

                                echo view('\Modules\Admin\Views\subscriptions\_overview', $this->data);
                        }
                        elseif ($obj == 'deny')
                        {
                                $this->data['denied'] = true;
                                echo view('\Modules\Admin\Views\fr_denial', $this->data);
                        }
                }

                public function save($obj = null, $id = null, $arg = null, $param = null)
                {
                        if ($obj == 'subscription') 
                        {
                                $data = $this->request->getPost();

                                if (empty($data['Customer_name_7'])) {
                                        echo $this->alert('aDanger', 'Veuillez renseigner le nom du client.');
                                        return;
                                }

                                $serviceIds = $this->request->getPost('services') ?: array();
                                $recetteIds = $this->request->getPost('recettes') ?: array();

                                unset($data['services'], $data['recettes'], $data['Subscription_type']);
                                $data['Taxable_Event_12'] = $this->subscriptionsModel->build_taxable_event((array) $serviceIds, (array) $recetteIds);
                                $data['Customer_code_8'] = $this->subscriptionsModel->generate_customer_code();
                                $data['Is_active_21'] = isset($data['Is_active_21']) ? 1 : 0;
                                $data['Is_authorized_22'] = isset($data['Is_authorized_22']) ? 1 : 0;

                                if (empty($id)) {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        $id = null;
                                }
                                else {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }

                                $saved = $this->subscriptionsModel->save_subscription($data, $id);

                                echo $saved ? $this->alert('aSuccess', 'Souscription enregistree avec succes.', $saved) : $this->alert('danger', 'L enregistrement a echoue.');
                        }
                        elseif ($obj == 'user') 
                        {
                                $data = $this->request->getPost();
                                if (empty($data['Customer_id_7']) || empty($data['Fullname_12'])) {
                                        echo $this->alert('aDanger', 'Veuillez renseigner la souscription et le nom complet.');
                                        return;
                                }

                                $data['Customer_login_9'] = $this->subscriptionsModel->generate_customer_login($data['Customer_id_7']);
                                $data['Authorized_19'] = isset($data['Authorized_19']) ? 1 : 0;
                                $this->stamp($data, $id);
                                $saved = $this->subscriptionsModel->save_user($data, $id ?: null);

                                echo $saved ? $this->alert('aSuccess', 'Utilisateur enregistre avec succes.', $saved) : $this->alert('danger', 'L enregistrement a echoue.');
                        }
                        elseif ($obj == 'account' || $obj == 'rib')
                        {
                                $data = $this->request->getPost();
                                if (empty($data['Customer_id_7']) || empty($data['Account_number_9'])) {
                                        echo $this->alert('aDanger', 'Veuillez renseigner la souscription et le numero de compte.');
                                        return;
                                }

                                $data['Is_primary_account_20'] = isset($data['Is_primary_account_20']) ? 1 : 0;
                                $this->stamp($data, $id);
                                $saved = $this->subscriptionsModel->save_account($data, $id ?: null);

                                echo $saved ? $this->alert('aSuccess', 'Compte enregistre avec succes.', $saved) : $this->alert('danger', 'L enregistrement a echoue.');
                        }
                        elseif ($obj == 'delete')
                        {
                                $table = null;
                                if ($arg == 'subscription')
                                {
                                        $table = $this->subscriptionsModel::TABLE_SUBSCRIPTIONS;
                                }
                                elseif ($arg == 'user') 
                                {
                                        $table = $this->subscriptionsModel::TABLE_USERS;
                                } 
                                elseif ($arg == 'account' || $arg == 'rib')
                                {
                                        $table = $this->subscriptionsModel::TABLE_ACCOUNTS;
                                }

                                echo ($table && $this->subscriptionsModel->soft_delete($table, $id)) ? '1' : '0';
                        }
                }

                public function api($id = null)
                {
                        if ($id == null) 
                        {
                                $data = array(
                                        'subscriptions' => $this->subscriptionsModel->get_subscriptions(),
                                );
                        }
                        else {
                                $data = $this->subscriptionsModel->get_payload($id);
                                if (empty($data)) {
                                        return $this->response->setStatusCode(404)->setJSON(array('status' => false, 'message' => 'Souscription introuvable'));
                                }
                        }

                        return $this->response->setJSON(array('status' => true, 'data' => $data));
                }

                private function stamp(array &$data, $id = null)
                {
                        if (empty($id))
                        {
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                        } 
                        else {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                        }
                }

                private function alert($type, $message, $id = null)
                {
                        $attr = $id ? ' data-id="' . $id . '"' : '';
                        return '<div class="alert ' . $type . ' text-white"' . $attr . '>' . $message . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                }
        }