<?php
namespace Modules\Admin\Controllers;
use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\CaisseModel;
use Modules\Admin\Models\EncaissementModel;
use Modules\Admin\Models\PartnersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;

class Partners extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('partners');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'partners';

        public $logirefModel;
        public $branchModel;
        public $mainModal;
        public $caisseModal;
        public $rateModal;
        public $counterModal;
        public $partnerModal;
        public $encaissementModal;
        public $role;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->mainModal = new MainModel();
                $this->branchModel = new BranchModel();
                $this->caisseModal = new CaisseModel();
                $this->logirefModel = new LogirefModel();
                $this->partnerModal = new PartnersModel();
                $this->encaissementModal = new EncaissementModel();
                
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'partners';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_etoll();
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "partners")
                {
                        $this->data['partners'] =$this->partnerModal->get_partners();
                        echo view('\Modules\Admin\Views\sbbos\partners\partners', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/partners', $this->data);
                }
                elseif($obj == "partner") 
                {
                        $this->data['partner'] = $this->partnerModal->get_partner_info($id);
                        echo view('\Modules\Admin\Views\sbbos\partners\_partner', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_partner', $this->data);
                }
                elseif($obj == "_partners") 
                {
                        $this->data['partners'] =$this->partnerModal->get_partners();
                        echo view('\Modules\Admin\Views\sbbos\partners\_partners', $this->data);
                        // $this->load->view($this->module.'/'.$this->group. '/'.$this->folder.'/_partners', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "partner")
                {
                        $data = $_POST;
                       
                        if($data['Name_7']=='' || $data['Phone_11']=='' || $data['Email_12']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir le nom du partenaire s\'il vous pla&icirc;t ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        $data['Name_7'] = isset($_POST['Name_7']) ? $_POST['Name_7'] : "";
                        $data['Phone_11'] = isset($_POST['Phone_11']) ? $_POST['Phone_11'] : "";
                        $data['Email_12'] = isset($_POST['Email_12']) ? $_POST['Email_12'] : "";
                        $data['Description_8'] = isset($_POST['Description_8']) ? $_POST['Description_8'] : "";
                        if(isset($_POST['Adresse_9']))$data['Adresse_9'] = $_POST['Adresse_9'];
                        if(isset($_POST['Nif_10']))$data['Nif_10'] = $_POST['Nif_10'];
                        
                        #Database
                        $cid = $this->partnerModal->save_partners($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! partenaire enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '0'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->partnerModal->save_partners($data, $id);    
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Partenaire supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Erreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "activate")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '1'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->partnerModal->save_partners($data, $id); 
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Partenaire activ&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'activation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
