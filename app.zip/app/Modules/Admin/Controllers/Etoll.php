<?php

namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;
use Modules\Etoll\Models\BranchesModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\EtollPosModel;
use Modules\Admin\Models\EtollCountersModel;
use Modules\Admin\Models\EtollUsersModel;
use Modules\Etoll\Models\UsersModel;
use Modules\Etoll\Models\IntegrationModel;
use Modules\Etoll\Models\CountersModel;
use Modules\Etoll\Models\CaissesModel;
use Modules\Etoll\Models\PartnersModel;
use Modules\Etoll\Models\PosModel;

class Etoll extends BaseController
{
        /*
         * Presentation: 
         * Last update:
         * By Alvin on the 28.08.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('dashboard', 'logs_operations', 'logs_integrations');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'dashboard';
        public $data = [];
        public $mainModel;
        public $accountModel;
        public $logirefModel;
        public $branchModel;
        public $userModel;
        public $stakeholderModel;
        public $curlModel;
        public $userEtollModel;
        public $posEtollModel;
        public $countersEtollModel;
        public $usersModel;
        public $integrationModel;
        public $countersModel;
        public $caissesModel;
        public $partnersModel;
        public $posModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->branchModel = new BranchesModel();
                $this->logirefModel = new LogirefModel();
                $this->mainModel = new MainModel();
                $this->userModel = new UserModel();
                $this->userEtollModel = new EtollUsersModel();
                $this->posEtollModel = new EtollPosModel();
                $this->countersEtollModel = new EtollCountersModel();
                $this->usersModel = new UsersModel();
                $this->integrationModel = new IntegrationModel();
                $this->countersModel = new CountersModel();
                $this->caissesModel = new CaissesModel();
                $this->partnersModel = new PartnersModel();
                $this->posModel = new PosModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'etoll';
                $this->data['function'] = '';
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_logiref();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) 
                {
                        //$this->data("set_privilegies");
                } 
                elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") 
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } 
                elseif ($this->session->userdata['user_type'] == "400") 
                {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) 
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } 
                else {
                        return redirect()->to(base_url('main/signin'));
                }
        }

        public function index()
        {
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_main', $this->data);
        }

        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) 
                {
                        $this->index();
                }
        }
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "logs_operations") 
                {
                        echo view('\Modules\Admin\Views\sbbos\logs\logs_operations', $this->data);
                } 
                elseif ($obj == "logs_integrations") 
                {
                        echo view('\Modules\Admin\Views\sbbos\logs\logs_integrations', $this->data);
                }
                elseif ($obj == "_privilege_etoll") 
                {
                        /*$this->data['statut'] = $this->userEtollModel->status;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets_toll");
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        $this->data['from'] = $arg;
                        $members = $this->userModel->get_dropdown("users");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];
                        foreach ($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['profile'] = $profile = $this->userModel->get_profile_info($id);
                        $this->data['user'] = $user = $this->userEtollModel->get_user_by_profile_id($profile->Id_0);
                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['roles'] = $this->userEtollModel->role;
                        } else {
                                $this->data['fonctions'] = $this->userEtollModel->fonction;
                                $this->data['fonctions'][1] = "";
                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        $this->data['pos'] = $this->posEtollModel->get_dropdown("pos",$user->Guichet_8);
                        $this->data['counters'] = $this->countersEtollModel->get_dropdown("guichets");*/

                        $this->data['statut'] = $this->usersModel->status;
                        $this->data['products'] = $this->usersModel->products;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences_main");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets_main");
                        $this->data['guichets_toll'] = $this->branchModel->get_dropdown("guichets_toll");
                        $this->data['counters'] = $this->countersModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services",NULL,NULL,true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        
                        $this->data['sales_points'] = $this->branchModel->get_dropdown("guichets_events");
                        $this->data['beneficiaires'] = $this->partnersModel->get_dropdown('partners');
                        
                        $this->data['from'] = $arg;
                        
			$this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        
                        $this->data['noms'] = $this->data['users'];
                        
                        $members = $this->usersModel->get_dropdown("users");
                        foreach($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        
                        $this->data['user'] = $user = $this->userEtollModel->get_user_by_profile_id($id);
                        
                        $this->data['caisses'] = $this->caissesModel->get_dropdown("caisses");
                        
                        $this->data['pos'] = $this->posModel->get_dropdown("pos", $user->Guichet_8);
                        $pos_members = $this->usersModel->get_dropdown("pos");
                        
                        if (isset($id) && $id > 0)
                        {
                                foreach($pos_members as $key=>$val) 
                                {
                                        if(isset($user->Id_0) && $user->Id_0 !="")
                                        {
                                                if($key != $user->Id_0)
                                                {
                                                        if (array_key_exists($val, $this->data['pos']))
                                                        {
                                                                unset($this->data['pos'][$val]);
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                if (array_key_exists($val, $this->data['pos']))
                                                {
                                                        unset($this->data['pos'][$val]);
                                                }
                                        }
                                } 
                        }
                        else
                        {
                                foreach($pos_members as $val) unset($this->data['pos'][$val]);
                        }
                        
                        if($_SESSION['Logiref_groupe']== 'banks')
                        {
                            $this->data['roles'] = $this->usersModel->role;
                        }
                        else
                        {
                            $this->data['fonctions'] = $this->usersModel->fonction;
                            $this->data['fonctions'][1] ="";

                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';

                        echo view('\Modules\Admin\Views\users\_privilege_etoll', $this->data);
                }
                #Default
                elseif ($obj == "deny") 
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                        // $this->load->view($this->lang . '_denial', $this->data);
                }
        }


        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if($obj == "user_etoll")
                {
                        if($_POST['userid']=='0' || $_POST['role']=='' || $_POST['ville']==''):
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                                die;
                        else:
                                if ($id == NULL):
                                        if(isset($_POST['pos']) && $_POST['pos'] !="")
                                        {
                                                $pos_exist = $this->usersModel->get_pos_by_imei($_POST['pos']);

                                                if (!empty($pos_exist)):
                                                        echo '<div class="alert alert-warning">Avertissement! D&eacute;sol&eacute; ce POS est déjà affect&eacute; à un autre utilisateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>';
                                                        die;
                                                endif;
                                        }
                                endif;

                                if($_POST['Id_0']=='0' || $_POST['Id_0']==''):

                                        $data['Date_1']=gmdate('Y-m-d H:i:s');
                                        $data['Status_2']= 2;
                                        $data['Statusvalidate_19']= 2;
                                        $data['Account_3']= $this->session->userdata['account_id'];
                                        $data['Maker_14']= $this->session->userdata['user_id'];

                                endif;


                                if($_SESSION['Logiref_role']==1)
                                {
                                        $data['Role_4']=$_POST['role'];
                                        $data['Checker_15']= $this->session->userdata['user_id'];
                                        $data['Validation_16']= gmdate('Y-m-d H:i:s');

                                        $data['Province_5']=$_POST['province'];
                                        $data['Ville_6']= $_POST['ville'];
                                        $data['Agence_7']= isset($_POST['agence'])? $_POST['agence']: "0";
                                        if($_SESSION['Logiref_groupe']== 'banks')
                                        {
                                            $data['Guichet_8']= (isset($_POST['guichet']) && $_POST['guichet'] !="") ? $_POST['guichet']: "0";
                                            $data['Regies_11']='';
                                        }
                                        else
                                        {
                                            $data['Service_10']=$_POST['service'];
                                            $data['Regies_11']=$_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9']=$_SESSION['Logiref_groupe'];
                                        $data['Code_12']=$_POST['code'];
                                        $data['Userid_13']=$_POST['userid'];

                                        $data['Partner_21']= (isset($_POST['partner']) && $_POST['partner'] !="") ? $_POST['partner'] : "0";
                                        $data['Type_23']= $_POST['Type'];

                                        $data['Pos_22']= (isset($_POST['pos']) && $_POST['pos'] !="") ? $_POST['pos'] : "0";


                                        if(isset($_POST['guichet']) && $_POST['guichet'] !="")
                                        {
                                                $caisse = $this->caissesModel->get_caisse_by_branchid($_POST['guichet']);

                                                $data['Caisse_20']= isset($caisse->Id_0) ? $caisse->Id_0 : 0;
                                        }

                                        $Module_11 = "etoll";
                                        $relation = $this->mainModel->get_relation_infos($_POST['userid']);
                                        if($relation->Module_11 != "" && $relation->Module_11 != "etoll")
                                        {
                                                if(in_array($relation->Module_11,array("elicense","eximtrade","qleads","etoll","logiref","Main","Pay"))){
                                                        $Module_11 = json_encode(array($relation->Module_11,"etoll"));
                                                }
                                                else{
                                                        $array = json_decode($relation->Module_11);
                                                        if(!in_array("etoll",$array)){
                                                                array_push($array,"etoll");
                                                        }
                                                        $Module_11 = json_encode($array);
                                                }
                                        }

                                        if($_POST['role'] == '1' || $_POST['role'] == '2')
                                        {
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $rdata['Module_11'] = $Module_11;
                                                $userid = $_POST['userid'];
                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if($id != "" || $id !='0')
                                        {
                                            if($_POST['role'] != '1' && $_POST['role'] != '2'):

                                                    $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                    $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                    $rdata['Type_10'] = '300';
                                                    $rdata['Module_11'] = $Module_11;
                                                    $userid = $_POST['userid'];
                                                    $relationid = $this->mainModel->update_relation($rdata, $userid);

                                            endif;
                                        }
                                        $data['Checker_15'] = 0;
                                        $data['Validation_16'] = '0000-00-00';
                                        $data['Option_26'] = (!empty($_POST["Option_26"]))?json_encode($_POST["Option_26"]):Null;

                                }
                                else {
                                        $data['Checker_15'] = $this->session->userdata['user_id'];
                                        $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                        if ($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] != '0') {
                                                $data['Status_2'] = 1;
                                                $data['Statusvalidate_19'] = $_POST['statusvalidate'];
                                        }
                                }

                                #Database
                                $cid = $this->usersModel->save_users($data, $id);

			endif;
                        if($cid):
                                echo '<div class="alert alert-success">Coolio! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button></div>'; 
                        endif;
                }
        }

}

/* End of file welcome.php  */
/* Location: /project/activities  */