<?php
namespace Modules\Admin\Controllers;
use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\EventsModel;
use Modules\Admin\Models\PartnersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;

class Events extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('events');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'events';
        public $logirefModel;
        public $branchModel;
        public $mainModel;
        public $eventModel;
        public $partnerModel;
        
        public $role;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->partnerModel = new PartnersModel();
                $this->eventModel = new EventsModel();
                
                
                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'events';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_etoll();
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "events")
                {
                        $this->data['events'] = $this->eventModel->get_events();
                        $this->data['status'] = $this->eventModel->status;
                        $this->data['status_color'] = $this->eventModel->status_color;
                        $this->data['type_event'] = $this->eventModel->type;
                        echo view('\Modules\Admin\Views\sbbos\events\events', $this->data);
                }
                elseif($obj == "event") 
                {
                        $this->data['event'] = $this->eventModel->get_event_info($id);
                        $this->data['type_event'] = $this->eventModel->type;
                        $this->data['partners'] = $this->partnerModel->get_dropdown("partners");
                        echo view('\Modules\Admin\Views\sbbos\events\_event', $this->data);
                }
                elseif($obj == "_events") 
                {
                        $this->data['events'] = $this->eventModel->get_events();
                        $this->data['status'] = $this->eventModel->status;
                        $this->data['status_color'] = $this->eventModel->status_color;
                        $this->data['type_event'] = $this->eventModel->type;
                        echo view('\Modules\Admin\Views\sbbos\events\_events', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "event")
                {
                        if($_POST['Name_7']=='0' || $_POST['Type_8']==''  || $_POST['Location_9']=='' || $_POST['Start_10']=='' || $_POST['Time_12']=='' || $_POST['End_11']=='' || $_POST['Time_13']=='' || $_POST['Start_16']=='' || $_POST['Time_18']=='' || $_POST['End_17']=='' || $_POST['Time_19']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        $infos = array();
                        
                        $data['Name_7']= $_POST['Name_7'];
                        $data['Type_8']= $_POST['Type_8'];
                        $data['Location_9']= $_POST['Location_9'];
                        $data['Start_10']= $_POST['Start_10'];
                        $data['End_11']= $_POST['End_11'];
                        $data['Time_12']= $_POST['Time_12'];
                        $data['Time_13']= $_POST['Time_13'];
                        $data['Start_16']= $_POST['Start_16'];
                        $data['End_17']= $_POST['End_17'];
                        $data['Time_18']= $_POST['Time_18'];
                        $data['Time_19']= $_POST['Time_19'];
                        $data['Description_15']= $_POST['Description_15'];

                        $infos['partner'] = isset($_POST['Partners_14']) ? $_POST['Partners_14'] : "";
                        $infos['quota_bank'] = isset($_POST['quota_bank']) ? $_POST['quota_bank'] : "";
                        $infos['quota_partner'] = isset($_POST['quota_partner']) ? $_POST['quota_partner'] : "";
                                
                        $data['Partners_14']= json_encode($infos);
                        
                        #Database
                        $cid = $this->eventModel->save_events($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! &eacute;v&egrave;nement enregistr&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '0'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->eventModel->save_events($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Ev&egrave;nement annul&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'annulation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "activate")
                {
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6 '] = $this->session->userdata['user_id'];
                        $data['Status_2'] = '1'; 
                        
                        $data['Account_3'] = $this->session->userdata['account_id'];
                        $id = $this->eventModel->save_events($data, $id);
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Ev&egrave;nement activ&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'activation n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */
