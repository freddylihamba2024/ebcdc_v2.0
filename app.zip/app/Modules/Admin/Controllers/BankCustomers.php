<?php

namespace Modules\Admin\Controllers;

use App\Libraries\Mail;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\ImageModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\ManageModel;
use Modules\Admin\Models\UserQleadModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\IntegrationModel;
use Modules\Admin\Models\BankCustomersModel;
use Modules\Admin\Models\AuthorizationsModel;

class BankCustomers extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('profile', 'site', 'group', 'user', 'invitation', 'account', 'page', 'change', 'users', 'unblocking', 'password', 'customers');
        public $menus_excepted = array('profile', 'password');
        public $roles = '';
        public $lang = 'fr';
        public $group = 'users';
        public $module = 'admin';
        public $folder = 'bankcustomers';
        public $mail;
        public $session;
        public $mainModel;
        public $manageModel;
        public $imageModel;
        public $branchModel;
        public $logirefModel;
        public $userModel;
        public $userQleadModel;
        public $integrationModel;
        public $queueModel;
        public $authorizationsModel;
        public $bankCustomersModel;

        public function __construct()
        {
                parent::__construct();
                /*
                * Module is project 
                * Submodule or application is activities 
                * function will be set within display function
                */

                $this->mainModel = new MainModel();
                $this->manageModel = new ManageModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->userModel = new UserModel();
                $this->userQleadModel = new UserQleadModel();
                $this->integrationModel = new IntegrationModel();
                $this->queueModel = new QleadQueueModel();
                $this->imageModel = new ImageModel();
                $this->mail = new Mail();
                $this->authorizationsModel = new AuthorizationsModel();
                $this->bankCustomersModel = new BankCustomersModel();

                $this->lang = 'fr';

                $this->data['module'] = 'admin';
                $this->data['application'] = 'bankcustomers';
                $this->data['function'] = '';
                $this->data['layout_type'] = 'layout-top-nav';
                $this->data['lang'] = $this->lang;

                $segment_view = $this->uri->getSegment(4);

                $this->data['deny'] = false;

                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                elseif(!in_array($segment_view, $this->menus_excepted))
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                /**
                 * Check if the user was granted to this
                 * The administrateur has to activate/deactivate user
                 * $_SESSION['Grant_Education'] 
                 */
                if ($this->session->userdata['account_id'] == '1') {
                        $this->group = 'main';
                } elseif ($this->session->userdata['user_type'] == '200') {
                        $this->group = 'admin';
                } else {
                        $this->group = 'user';
                }

                /*
                    * Profile picture or logo
                    * fileToUpload
                    */
                if (isset($_FILES['fileToUpload']['name'])) {
                        if ($_FILES['fileToUpload']['name'] != "") $this->imageModel = new ImageModel();
                }

        }


        public function index()
        {
                // add_meta_title('iKwook Project');
                // $this->data['subview'] = 'main/container';
                // $this->load->view('_layout_main', $this->data);

                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }

        public function change()
        {
                add_meta_title('iKwook Cloud');
                $this->data['subview'] = '\Modules\Admin\Views\container'; //'main/user/'.$this->lang.'/main';
                echo view('layouts/layout_admin', $this->data);
        }

        public function dashboard($schedule = NULL)
        {
                add_meta_title('iKwook Project');
                $this->data['categories'] = $this->mainModel->account_categories[$this->lang];
                $this->data['countries'] = $this->mainModel->get_dropdown('country');
                $this->data['business'] = $this->session->userdata['user_business'];
                $this->data['members'] = array();
                $this->data['users'] = $this->mainModel->get_users();
                $this->data['groups'] = $this->mainModel->get_groups();
                $this->data['sites'] = $this->mainModel->get_sites();
                $this->data['visitors'] = $this->mainModel->get_users('', '', '', '400');
                $this->data['status'] = $this->manageModel->status['fr'];
                $this->data['color'] = $this->manageModel->color_status;


                $dedicated_applications = $this->data['app_dedicated'] = $this->mainModel->standard_applications[$this->lang];
                $myapps = explode(',', $this->session->userdata['account_myapps']);

                $module = '';
                foreach ($dedicated_applications as $dashbord => $applications) :
                        foreach ($myapps as $app) :
                                if (key_exists($app, $applications)) {
                                        $module[$dashbord][$app] = $app;
                                }
                        endforeach;
                endforeach;
                $this->data['MyApps'] = $module;
                $this->data['dashboards'] = $this->mainModel->user_dashboard[$this->lang];
                $this->data['applications'] = $this->mainModel->ikwook_applications;

                if ($this->session->userdata['account_category'] == 303) {
                        redirect('pay/hotleads/', 'refresh');
                } else {
                        $this->data['subview'] = 'main/' . $this->group . '/' . $this->lang . '/dashboard';
                }
                echo view('layouts/layout_admin', $this->data);
        }

        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * List: 
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                    if ((isset($_SESSION['Logiref_role']) && ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 5)) || $needle == 'password') 
                    {
                            $this->data['sidebar'] = '';
                    }
                    $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == 'customers')
                {
                        $param = $id;
                        
                        $customers = $this->bankCustomersModel->get_customers();
                        $users= $this->bankCustomersModel->get_dropdown("users");
                        $users_customers = $this->bankCustomersModel->get_dropdown("customers_users");

                        $grouped = ['CORPORATE' => [], 'RETAIL' => []];
                        $user_links = [];

                        foreach ($users_customers as $user_id => $customer_id) 
                        {
                                if ($customer_id && isset($users[$user_id])) 
                                {
                                        $user_links[$customer_id][$user_id] = $users[$user_id];
                                }
                        }

                        foreach ($customers as $row) 
                        {
                                $type = $row->Type_7 == '2' ? 'CORPORATE' : 'RETAIL';
                                $accounts = json_decode($row->Accounts_14 ?? '{}', true);

                                $grouped[$type][] = [
                                        'customers' => $row,
                                        'accounts' => $accounts,
                                        'users' => $user_links[$row->Id_0] ?? [],
                                ];
                        }

                        $this->data['grouped'] = $grouped;
                        $this->data['types'] = ['CORPORATE', 'RETAIL'];
                        $this->data['environnement'] = $this->mainModel->environnement;
                        $this->data['modules'] = $this->mainModel->get_dropdown("users_module");

                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\bankcustomers\customers_2', $this->data);
                        else:

                                echo view('\Modules\Admin\Views\bankcustomers\customers', $this->data);
                        endif;
                }
                elseif ($obj == 'customer')
                {
                        if ($id == 'pager') 
                        {
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                                $this->data['customer'] = $this->bankCustomersModel->get_customer_info();
                                $this->data['user'] = $this->bankCustomersModel->get_user_info();
                        } 
                        else 
                        {
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                                $this->data['customer'] = $this->bankCustomersModel->get_customer_info($id);
                                $this->data['user'] = $this->bankCustomersModel->get_user_info($id);
                        }

                        $this->data['types'] = $this->bankCustomersModel->type_customers;
                        $this->data['countries'] = $this->bankCustomersModel->countries;
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');

                        echo view('\Modules\Admin\Views\bankcustomers\_customer', $this->data);
                }
                elseif ($obj == "privilege_start")
                {
                        $customer = $this->bankCustomersModel->get_customer_info($id);
                        $customer_id = ($arg =="existing_user") ? $customer->Id_0 : NULL;

                        $this->data['statut'] = $this->userModel->status;
                        $this->data['customer'] = $customer;
                        $this->data['user'] = $user = $this->bankCustomersModel->get_user_by_customer_id($customer_id);
                        $this->data['step'] = 1;

                        echo view('\Modules\Admin\Views\bankcustomers\_privilege_start', $this->data);
                }
                elseif ($obj == "privilege_step_1")
                {
                        $info_accounts = [];
                        $accounts =[];

                        if ($id == NULL)
                        {
                                $return = $this->save("users");

                                if ((int) $return > 0)
                                {
                                        $uid = $return;
                                        $customer_id = isset($_POST['Customerid_7']) ? $_POST['Customerid_7'] : "";


                                        $user = $this->bankCustomersModel->get_user_info($uid);
                                }
                                else
                                {
                                        echo $return;
                                        die;
                                }
                        }
                        else
                        {
                                $uid = $id;
                                $user = $this->bankCustomersModel->get_user_info($uid);

                                $customer_id = isset($user->Customerid_7) ? $user->Customerid_7 : "";

                        }

                        $customer = $this->bankCustomersModel->get_customer_info($customer_id);

                        if (isset($customer->Accounts_14) && $customer->Accounts_14 != "") 
                        {
                                $info_accounts = json_decode($customer->Accounts_14, true);

                                if (isset($info_accounts['account']) && is_array($info_accounts['account'])) 
                                {
                                        foreach ($info_accounts['account'] as $index => $account_number) 
                                        {
                                                $currency = $info_accounts['currency'][$index] ?? '';
                                                $accounts[$account_number] = $account_number . ' ' . $currency;
                                        }
                                }
                        }
                       
                        $userid = isset($user->Userid_8) && $user->Userid_8!= "" ? $user->Userid_8 : "";
                        $pid = $userid != "" ? $userid : "";
                        $profile = $this->bankCustomersModel->get_profile_info($pid);

                        $this->data['profile'] = $profile;
                        $this->data['step'] = 2;
                        $this->data['user'] = $user; 
                        $this->data['accounts'] = $accounts;
                        $this->data['customer'] = $customer;
                        $this->data['statut'] = $this->bankCustomersModel->status;
                        $this->data['roles'] = $this->bankCustomersModel->role;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");

                        $this->data['from'] = $arg;

                        echo view('\Modules\Admin\Views\bankcustomers\_privilege_step_1', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
                return true;
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                $msg = array('en' => '', 'fr' => '');
                /**
                 * Site or branch/Group/User
                 * @save new record and updating existing onces if @ID is not NULL
                 */
                if ($obj == 'users') 
                {
                        if(isset($_POST['Customerid_7']) && $_POST['Customerid_7'] == "")
                        {
                                echo 'E404'; 
                                die;
                        }

                        if (isset($_POST['Customerid_7']) && $_POST['Customerid_7'] != "" && isset($_POST['Firstname_9']) && $_POST['Lastname_10'] != "" && isset($_POST['Email_15']) && isset($_POST['Cellphone_17'])) 
                        {
                                if ($id == NULL)
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                } 
                                else 
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                
                                $data['Customerid_7'] = isset($_POST['Customerid_7']) ? $_POST['Customerid_7'] : "";
                                $data['Firstname_9'] = isset($_POST['Firstname_9']) ? $_POST['Firstname_9'] : "";
                                $data['Lastname_10'] = isset($_POST['Lastname_10']) ? $_POST['Lastname_10'] : "";
                                $data['Middlename_11'] = isset($_POST['Middlename_11']) ? $_POST['Middlename_11'] : "";
                                $data['Gender_12'] = isset($_POST['Gender_12']) ? $_POST['Gender_12'] : "";
                                $data['Birthday_13'] = isset($_POST['Birthday_13']) ? $_POST['Birthday_13'] : "";
                                $data['Nationality_14'] = isset($_POST['Nationality_14']) ? $_POST['Nationality_14'] : "";
                                $data['Email_15'] = isset($_POST['Email_15']) ? $_POST['Email_15'] : "";
                                $data['Cellphone_16'] = isset($_POST['Cellphone_16']) ? $_POST['Cellphone_16'] : "";
                                $data['Cellphone_17'] = isset($_POST['Cellphone_17']) ? $_POST['Cellphone_17'] : "";
                                $data['State_18'] = isset($_POST['State_18']) ? $_POST['State_18'] : "";
                                $data['City_19'] = isset($_POST['City_19']) ? $_POST['City_19'] : "";
                                $data['Address_20'] = isset($_POST['Address_20']) ? $_POST['Address_20'] : "";
                                $data['Document_21'] = isset($_POST['Document_21']) ? $_POST['Document_21'] : "";
                                $data['Documentnumber_22'] = isset($_POST['Documentnumber_22']) ? $_POST['Documentnumber_22'] : "";
                                $data['Documentstart_23'] = isset($_POST['Documentstart_23']) ? $_POST['Documentstart_23'] : "";
                                $data['Documentend_24'] = isset($_POST['Documentend_24']) ? $_POST['Documentend_24'] : "";

                                $uid = $this->bankCustomersModel->save_users($data, $id);

                                if ($uid) 
                                {
                                        return $uid;
                                }
                        } 
                        else 
                        {
                                echo "E402";
                                die;
                        }
                } 
                elseif ($obj == 'customers')
                {
                        $validate = FALSE;
                        $bank_id = trim($_POST['Cif_8'] ?? '');
                        $return = $this->bankCustomersModel->check_if_customer_exist($bank_id);

                        if (!empty($return)) 
                        {

                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible"> ' . $bank_id . ', Avertissement! cet identifiant bancaire (CIF) est associ&eacute; &agrave; un autre client!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! ' . $bank_id . ', this identifiant bancaire (CIF) is associated with an existing customer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } 
                        else 
                        {

                                if ($id == NULL && isset($_POST['Cif_8']) && $_POST['Cif_8'] != "" && isset($_POST['Type_7']) && $_POST['Type_7'] != "")
                                {
                                        $accounts = !empty($_POST['Infos']) ? $_POST['Infos'] : [];   

                                        $data_customer['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data_customer['Status_2'] = 1;
                                        $data_customer['Account_3'] = $this->session->userdata['account_id'];
                                        $data_customer['Creator_4'] = $this->session->userdata['user_id'];
                                        $data_customer['Type_7'] = $_POST['Type_7'];
                                        $data_customer['Cif_8'] = $_POST['Cif_8'];

                                        if (isset($_POST['corporate']) && $_POST['corporate']!="")
                                        {
                                                $data_customer['Company_9'] = $_POST['Company_9'];
                                                $data_customer['City_10'] = $_POST['City_10'];
                                                $data_customer['Country_11'] = $_POST['Country_11'];
                                                $data_customer['Corporateid_12'] = $_POST['Corporateid_12'];
                                                $data_customer['Address_13'] = $_POST['Address_13'];
                                        }

                                        if (isset($_POST['retail']) && $_POST['retail']!= "")
                                        {
                                                $data_customer['City_10'] = isset($_POST['City_19']) ? $_POST['City_19']:"";
                                                $data_customer['Address_13'] = isset($_POST['Address_20']) ? $_POST['Address_20'] : "";
                                        }

                                        $data_customer['Accounts_14'] = json_encode($accounts);
                                        $data_customer['Language_15'] = isset($_POST['Language_15']) ? $_POST['Language_15']:"";

                                        $validate = TRUE;
                                } 
                                else 
                                {
                                        $data_customer['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data_customer['Changer_6'] = $this->session->userdata['user_id'];
                                        
                                        $validate = TRUE;
                                }

                                if ($validate === TRUE) 
                                {
                                        #Saving
                                        $cid = $this->bankCustomersModel->save_customers($data_customer, $id);
                                        
                                        if ($cid)
                                        {
                                                #Relation Data 
                                                $data_user = array();

                                                if (isset($_POST['retail']) && $_POST['retail']!= "")
                                                {

                                                        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : "";

                                                        if ($user_id == "") 
                                                        {
                                                                $data_user['Date_1'] = gmdate('Y-m-d H:i:s');
                                                                $data_user['Status_2'] = 1;
                                                                $data_user['Account_3'] = $this->session->userdata['account_id'];
                                                                $data_user['Creator_4'] = $this->session->userdata['user_id'];
                                                                $data_user['Customerid_7'] = $cid;

                                                                $user_id = NULL;
                                                        }
                                                        else
                                                        {
                                                                $data_user['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                                $data_user['Changer_6'] = $this->session->userdata['user_id'];
                                                        }

                                                        $data_user['Firstname_9'] = isset($_POST['Firstname_9']) ? $_POST['Firstname_9'] : "";
                                                        $data_user['Lastname_10'] = isset($_POST['Lastname_10']) ? $_POST['Lastname_10'] : "";
                                                        $data_user['Middlename_11'] = isset($_POST['Middlename_11']) ? $_POST['Middlename_11'] : "";
                                                        $data_user['Gender_12'] = isset($_POST['Gender_12']) ? $_POST['Gender_12'] : "";
                                                        $data_user['Birthday_13'] = isset($_POST['Birthday_13']) ? $_POST['Birthday_13'] : "";
                                                        $data_user['Nationality_14'] = isset($_POST['Nationality_14']) ? $_POST['Nationality_14'] : "";
                                                        $data_user['Email_15'] = isset($_POST['Email_15']) ? $_POST['Email_15'] : "";
                                                        $data_user['Cellphone_16'] = isset($_POST['Cellphone_16']) ? $_POST['Cellphone_16'] : "";
                                                        $data_user['Cellphone_17'] = isset($_POST['Cellphone_17']) ? $_POST['Cellphone_17'] : "";
                                                        $data_user['State_18'] = isset($_POST['State_18']) ? $_POST['State_18'] : "";
                                                        $data_user['City_19'] = isset($_POST['City_19']) ? $_POST['City_19'] : "";
                                                        $data_user['Address_20'] = isset($_POST['Address_20']) ? $_POST['Address_20'] : "";
                                                        $data_user['Document_21'] = isset($_POST['Document_21']) ? $_POST['Document_21'] : "";
                                                        $data_user['Documentnumber_22'] = isset($_POST['Documentnumber_22']) ? $_POST['Documentnumber_22'] : "";
                                                        $data_user['Documentstart_23'] = isset($_POST['Documentstart_23']) ? $_POST['Documentstart_23'] : "";
                                                        $data_user['Documentend_24'] = isset($_POST['Documentend_24']) ? $_POST['Documentend_24'] : "";

                                                        $rid = $this->bankCustomersModel->save_users($data_user, $user_id);
                                                }
                                        }

                                        if ($cid)
                                        {
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Bien!....enregistr&eacute;s avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Great!...saved successfully.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else
                                        {
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">ERROR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">ERREUR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } 
                                else 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications non enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }

                        echo $msg[$this->lang];
                } 
                elseif ($obj == "profile")
                {
                        if ($_POST['Login_13'] == '0' || $_POST['Role_8'] == '' || $_POST['Account_10'] == '') 
                        {
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        }
                        else 
                        {
                                $pid = ($_POST['Id_0']) ?? "";

                                if ($pid == '0' || $pid == '' || $pid == NULL)
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 2;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        $data['Customerid_7'] = ($_POST['Customerid_7']) ?? "";
                                        $data['Login_13'] = $login = ($_POST['Login_13']) ?? "";

                                        $password = $this->mainModel->get_new_password();
                                        $generate_password = $this->mainModel->generate_hash($password);

                                        $data['Password_14'] = $generate_password ;
                                        $data['Lastlogin_18'] = $generate_password;
                                }
                                else
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }

                                if ($_SESSION['Logiref_role'] == 1) 
                                {
                                        $limit_amount = isset($_POST['Limitamount_12']) && $_POST['Limitamount_12']!="" ? $_POST['Limitamount_12'] : "0";
                                        $limit_amount = str_replace(' ','',$limit_amount);
                                        $limit_amount = str_replace(',','.',$limit_amount);

                                        $data['Account_10'] = array_filter($_POST['Account_10']);
                                        $data['Account_10'] = implode(",", $_POST['Account_10']);

                                        $data['Role_8'] = ($_POST['Role_8']) ?? "";
                                        $data['Branchid_9'] = ($_POST['Branchid_9']) ??"";
                                        $data['Limitamount_12'] = $limit_amount;
                                        $data['Validationlevel_17'] = ($_POST['Validationlevel_17'])??"";
                                        $data['Accessstart_15'] = ($_POST['Accessstart_15'])??"";
                                        $data['Accessend_16'] = ($_POST['Accessend_16']) ??"";
                                } 

                                #Database
                                $cid = $this->bankCustomersModel->save_profile_users($data,$id);
                                
                                # Confirmation mail
                                if($pid == '' || $id==NULL)
                                {
                                        $udata = array();
                                        $uid = ($_POST['uid']) ?? '';

                                        $udata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $udata['Changer_6'] = $this->session->userdata['user_id'];
                                        $udata['Userid_8'] = $cid;

                                        $this->bankCustomersModel->save_users($udata, $uid);

                                        $rdata = array();

                                        $rdata['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $rdata['Status_2'] = 1;
                                        $rdata['Account_3'] = $this->session->userdata['account_id'];
                                        $rdata['Creator_4'] = $this->session->userdata['user_id'];
                                        $rdata['User_7'] = $cid;
                                        $rdata['Group_8'] = isset($_SESSION['Logiref_groupe']) ? $_SESSION['Logiref_groupe'] : "";
                                        $rdata['Type_10'] = ($_POST['Role_8'] == '1' || $_POST['Role_8'] == '2') ? '200':'300';
                                        $rdata['Module_11'] = "branchless";

                                        $this->mainModel->save_relation($rdata, NULL);

                                        $mail = (isset($_POST['Email_15']) && $_POST['Email_15']!="")  ? $_POST['Email_15'] : "";
                                        
                                        if ($mail != "") 
                                        {
                                                $this->mail->mail_bank_profile_confirmation($_POST['Names'], $login, $password, $mail);
                                        }
                                }
                        }

                        if ($cid) 
                        {
                                echo '<div class="alert aSuccess text-white">Bien!....enregistr&eacute;s avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        else
                        {
                                echo '<div class="alert aDanger text-white alert-dismissible">Avertissement! Enregistrement non enregistr&eacute;...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }

                return true;
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if ($obj == "generate_login") 
                {
                        $return = [];

                        try {
                                $attempts = 0;
                                # sécurité pour éviter boucle infinie
                                $max_attempts = 100; 

                                do {
                                        $code = '';
                                        for ($i = 0; $i < 10; $i++) 
                                        {
                                                $code .= mt_rand(0, 9);
                                        }

                                        $exists = $this->bankCustomersModel->get_relation_by_login($code);
                                        $attempts++;

                                } while (!empty($exists) && $attempts < $max_attempts);

                                if (!empty($code) && empty($exists)) 
                                {
                                        $return['code'] = '200';
                                        $return['login'] = $code;
                                } 
                                else 
                                {
                                        # Erreur si trop de tentatives
                                        $return['code'] = '500';
                                        $return['message'] = 'Impossible de générer un code login unique après plusieurs tentatives.';
                                }

                        } catch (\Throwable $e) {
                                $return['code'] = '500';
                                $return['message'] = 'Erreur serveur : ' . $e->getMessage();
                        }

                        return json_encode($return);
                }
                elseif ($obj == "_generate_login") 
                {
                        $return = [];

                        do {
                                $code = '';
                                for ($i = 0; $i < 10; $i++) 
                                {
                                        $code .= mt_rand(0, 9);
                                }

                                $exists = $this->bankCustomersModel->get_relation_by_code($code);

                        } while (!empty($exists));

                        if (!empty($code)) 
                        {
                                $return['code'] = "200";
                                $return['pcode'] = $code;
                        } 
                        else 
                        {
                                $return['code'] = '405';
                        }

                        return json_encode($return);
                }

        }

        public function activate($obj = NULL, $id = NULL, $status = NULL)
        {
                /**
                 * User
                 * Changing status to 1
                 */
                if ($obj == 'user') {
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $gid = $this->mainModel->save_profile($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                return true;
        }
        public function desactivate($data = NULL)
        {
                if (isset($data) || $data != "") {
                        $user = $this->mainModel->get_profile_by_email($data);

                        if (isset($user->Id_0) && $user->Id_0 != "") {
                                $data_to_save['Status_2'] = '2';
                                $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');


                                $this->userModel->update_users($data_to_save, $user->Id_0);
                        }
                }
        }
        public function reinitialize($obj = NULL, $id = NULL, $email = NULL)
        {
                /**
                 * User
                 * Changing status to 1
                 */
                if ($obj == 'password') {
                        if ($id == NULL && $email != NULL) {
                                $profile = $this->mainModel->get_profile_by_email($email);
                                if (isset($profile->Id_0)) $id = $profile->Id_0;
                        } elseif (isset($_POST['username']) && $_POST['username'] != NULL) {
                                $profile = $this->mainModel->get_profile_by_email($_POST['username']);
                                if (isset($profile->Id_0)) $id = $profile->Id_0;
                        } else {
                                $profile = $this->mainModel->get_profile_by_id($id);
                        }

                        if ($id != NULL) {
                                $password = $this->mainModel->get_new_password();
                                $encrypted = $this->mainModel->generate_hash($password);

                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                $data['Encryption_8'] = $encrypted;
                                $data['Statutdefaultpwd_31'] = 0;

                                $rid = $this->mainModel->save_profile($data, $id);

                                if ($this->lang == 'fr' && $rid) {
                                        $mid = $this->mail->mail_reset_password_by_admin($profile->Firstname_9, $profile->Identifier_7, $password, $this->lang);
                                        if ($mid):
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Mot de passe reinitialis&eacute;e avec succ&egrave;s!<br/>Nous vous avons envoy&eacute; le mot de passe temporaire par email.</p>';
                                        else:
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Mot de passe reinitialis&eacute;e avec succ&egrave;s, mais le mail n\'a pas pu être envoyé !<br/>Nous vous avons envoy&eacute; le mot de passe temporaire par email.</p>';
                                        endif;
                                } elseif ($this->lang != '' && $rid) {
                                        $mid = $this->mail->mail_reset_password_by_admin($profile->Firstname_9, $profile->Identifier_7, $password, $this->lang);
                                        if ($mid):
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Password changed successfully!<br/>We have sent you an email with your new password.</p>';
                                        else:
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Password changed successfully!<br/>We have sent you an email with your new password, but the email could not be sent!</p>';
                                        endif;
                                }
                        }
                }

                return true;
        }
        public function delete($obj = NULL, $id = NULL)
        {
                /**
                 * Site or branch/Group/User
                 * @Changing status to 0 to delete - can still be accessible for data related
                 */
                $data['Status_2'] = 0;
                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                $data['Changer_6'] = $this->session->userdata['user_id'];

                if ($obj == 'site') {
                        $assigned_user = $this->mainModel->check_site_user($id);

                        if ($assigned_user) {
                                $gid = $this->mainModel->save_site($data, $id);

                                if ($this->lang == 'fr' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Site supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } elseif ($this->lang != '' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Branch deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                if ($this->lang == 'fr') {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un site qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } else {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete this branch that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                } elseif ($obj == 'group') {
                        $assigned_user = $this->mainModel->check_group_user($id);

                        if ($assigned_user) {
                                $gid = $this->mainModel->save_group($data, $id);

                                if ($this->lang == 'fr' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Groupe supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } elseif ($this->lang != '' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Group deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                if ($this->lang == 'fr') {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un groupe qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } else {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete a group that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                } elseif ($obj == 'user') {
                        $gid = $this->mainModel->save_profile($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                } elseif ($obj == 'visitor') {
                        $gid = $this->mainModel->save_relation($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }

                return true;
        }

}