<?php

namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\AccountModel;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\BranchModel;

class Logiref extends BaseController
{
        /*
         * Presentation: 
         * Last update:
         * By Alvin on the 28.08.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('dashboard', 'functionnalities', '');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'dashboard';
        public $data = [];
        public $mainModal;
        public $accountModel;
        public $logirefModel;
        public $branchModel;
        public $feesModel;
        public $userModel;
        public $stakeholderModel;
        public $curlModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModal = new MainModel();
                $this->userModel = new UserModel();
                $this->accountModel = new AccountModel();
                $this->branchModel = new BranchModel();
                $this->feesModel = new FeesModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'logiref';
                $this->data['function'] = '';
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_logiref();

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        //$this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect('main/signin', 'refresh');
                }
        }


        public function index()
        {
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) 
                {
                        $this->data['sidebar'] = '';
                }
                
                
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }

        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }

        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                /*if ($obj == "dashboard") {
                    $this->data["count_users"] = count($this->userModel->get_members_array());
                    $this->data["count_compte_bancaire"] = $this->accountModel->get_count_comptes();
                    $this->data["count_frais_bancaire"] = count($this->feesModel->get_regles("rgle"));
                    $this->data["count_agence"] = count($this->branchModel->get_guichets("Guichet"));
                    $this->data["agences"] = $this->branchModel->get_guichets("Guichet");
                    foreach($this->data["agences"] as $value){
                        $value->Users_inactif = count($this->userModel->get_users_inactif($value->Id_0));
                        $value->Users_actif = count($this->userModel->get_users_actif($value->Id_0));
                        $value->Count_compte = count($this->accountModel->get_compte_parametrer($value->Id_0));
                    }
                    echo view('\Modules\Admin\Views\logiref\dashboard\dashboard', $this->data);
                }
                else*/if($obj == "functionnalities")
                {
                        $this->data['functionnalities'] = [];
                        echo view('\Modules\Admin\Views\logiref\functionnalities', $this->data);
                }
                elseif($obj == "functionnality")
                {
                        $this->data['functionnalities'] = [];
                        echo view('\Modules\Admin\Views\logiref\_functionnality', $this->data);
                }
                #Default
                elseif ($obj == "deny") {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                }
        }




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                
        }

}

/* End of file welcome.php  */
/* Location: /project/activities  */