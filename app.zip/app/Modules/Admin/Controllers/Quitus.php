<?php

namespace Modules\Admin\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\ImageModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\ManageModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\IntegrationModel;

class Quitus extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('profile', 'site', 'group', 'user');
        public $menus_excepted = array('profile', 'password');
        public $roles = '';
        public $lang = 'fr';
        public $group = 'users';
        public $module = 'admin';
        public $folder = 'users';
        public $session;
        public $mainModel;
        public $manageModel;
        public $imageModel;
        public $branchModel;
        public $logirefModel;
        public $userModel;
        public $integrationModel;

        public function __construct()
        {
                parent::__construct();
                /*
                    * Module is project
                    * Submodule or application is activities
                    * function will be set within display function
                    */

                $this->mainModel = new MainModel();
                $this->manageModel = new ManageModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->userModel = new UserModel();
                $this->integrationModel = new IntegrationModel();
                $this->imageModel = new ImageModel();

                $this->lang = 'fr';

                $this->data['module'] = 'admin';
                $this->data['application'] = 'Quitus';
                $this->data['function'] = '';
                $this->data['layout_type'] = 'layout-top-nav';
                $this->data['lang'] = $this->lang;

                $segment_view = $this->uri->getSegment(4);

                $this->data['deny'] = false;

                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                elseif(!in_array($segment_view, $this->menus_excepted))
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                /**
                 * Check if the user was granted to this
                 * The administrateur has to activate/deactivate user
                 * $_SESSION['Grant_Education']
                 */
                if ($this->session->userdata['account_id'] == '1')
                {
                        $this->group = 'main';

                }
                elseif ($this->session->userdata['user_type'] == '200')
                {
                        $this->group = 'admin';
                }
                else
                {
                        $this->group = 'user';
                }

                /*
                    * Profile picture or logo
                    * fileToUpload
                    */
                if (isset($_FILES['fileToUpload']['name'])) {
                        if ($_FILES['fileToUpload']['name'] != "") $this->imageModel = new ImageModel();
                }
        }


        public function index()
        {
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }

        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * List:
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                    if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4)
                    {
                       $this->data['sidebar'] = '';
                    }
                    $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                #Gestion privilege Seguce
                if ($obj == "_privilege_quitus")
                {
                        $this->data['statut'] = $this->userModel->status;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        $this->data['from'] = $arg;
                        $members = $this->userModel->get_dropdown("users");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];
                        foreach ($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['profile'] = $profile = $this->userModel->get_profile_info($id);
                        $this->data['user'] = $this->userModel->get_user_by_profile_id($profile->Id_0);

                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['roles'] = $this->userModel->role;
                        }
                        else {
                                $this->data['fonctions'] = $this->userModel->fonction;
                                $this->data['fonctions'][1] = "";
                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        echo view('\Modules\Admin\Views\\'.$this->folder.'\_privilege_quitus', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
                return true;
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                $msg = array('en' => '', 'fr' => '');
                /**
                 * Site or branch/Group/User
                 * @save new record and updating existing onces if @ID is not NULL
                 */
                if ($obj == "user_quitus")
                {
                        if ($_POST['userid'] == '0' || $_POST['role'] == '' || $_POST['ville'] == '') {
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        } else {
                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') :

                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = '1';
                                        $data['Statusvalidate_19'] = '1';
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Maker_14'] = $this->session->userdata['user_id'];

                                endif;

                                if ($_SESSION['Logiref_role'] == 1) {
                                        $data['Role_4'] = $_POST['role'];
                                        $data['Province_5'] = $_POST['province'];
                                        $data['Ville_6'] = $_POST['ville'];
                                        $data['Agence_7'] = $_POST['agence'];
                                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                                $data['Guichet_8'] = $_POST['guichet'];
                                                $data['Regies_11'] = '';
                                        }
                                        else {
                                                $data['Service_10'] = $_POST['service'];
                                                $data['Regies_11'] = $_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9'] = $_SESSION['Logiref_groupe'];
                                        $data['Code_12'] = $_POST['code'];
                                        $data['Userid_13'] = $_POST['userid'];

                                        $Module_11 = "quitusfiscal";
                                        $relation = $this->mainModel->get_relation_infos($_POST['userid']);
                                        if($relation->Module_11 != "" && $relation->Module_11 != "quitusfiscal")
                                        {
                                                if(in_array($relation->Module_11,array("elicense","eximtrade","qleads","etoll","logiref","Main","Pay","quitusfiscal"))){
                                                        $Module_11 = json_encode(array($relation->Module_11,"quitusfiscal"));
                                                }
                                                else{
                                                        $array = json_decode($relation->Module_11);
                                                        if(!in_array("quitusfiscal",$array)){
                                                            array_push($array,"quitusfiscal");
                                                        }
                                                        $Module_11 = json_encode($array);
                                                }
                                        }

                                        if ($_POST['role'] == '1' || $_POST['role'] == '2') {
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $rdata['Module_11'] = $Module_11;
                                                $userid = $_POST['userid'];
                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if ($id != "" || $id != '0') {
                                                if ($_POST['role'] != '1' && $_POST['role'] != '2') :

                                                        $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                        $rdata['Type_10'] = '300';
                                                        $rdata['Module_11'] = $Module_11;
                                                        $userid = $_POST['userid'];
                                                        $relationid = $this->mainModel->update_relation($rdata, $userid);
                                                endif;
                                        }

                                        $data['Checker_15'] = 0;
                                        $data['Validation_16'] = '0000-00-00';
                                        if ($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] != '0') {
                                                $data['Status_2'] = $_POST['statusvalidate'];
                                        }
                                }
                                else {
                                        $data['Checker_15'] = $this->session->userdata['user_id'];
                                        $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                        if ($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] != '0') {
                                                $data['Status_2'] = $_POST['statusvalidate'];
                                        }
                                }

                                #Database
                                $cid = $this->userModel->save_users($data,$id);
                        }

                        if ($cid) :
                                echo '<div class="alert alert-success">Super! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                return true;
        }

}