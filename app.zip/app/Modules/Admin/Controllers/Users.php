<?php

namespace Modules\Admin\Controllers;

use App\Libraries\Mail;
use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\UserModel;
use Modules\Admin\Models\ImageModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\ManageModel;
use Modules\Admin\Models\UserQleadModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\IntegrationModel;
use Modules\Admin\Models\AuthorizationsModel;

class Users extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('profile', 'site', 'group', 'user', 'invitation', 'account', 'page', 'change', 'users', 'unblocking', 'password');
        public $menus_excepted = array('profile', 'password');
        public $roles = '';
        public $lang = 'fr';
        public $group = 'users';
        public $module = 'admin';
        public $folder = 'users';
        public $mail;
        public $session;
        public $mainModel;
        public $manageModel;
        public $imageModel;
        public $branchModel;
        public $logirefModel;
        public $userModel;
        public $userQleadModel;
        public $integrationModel;
        public $queueModel;
        public $authorizationsModel;

        public function __construct()
        {
                parent::__construct();
                /*
                * Module is project 
                * Submodule or application is activities 
                * function will be set within display function
                */

                $this->mainModel = new MainModel();
                $this->manageModel = new ManageModel();
                $this->branchModel = new BranchModel();
                $this->logirefModel = new LogirefModel();
                $this->userModel = new UserModel();
                $this->userQleadModel = new UserQleadModel();
                $this->integrationModel = new IntegrationModel();
                $this->queueModel = new QleadQueueModel();
                $this->imageModel = new ImageModel();
                $this->mail = new Mail();
                $this->authorizationsModel = new AuthorizationsModel();

                $this->lang = 'fr';

                $this->data['module'] = 'admin';
                $this->data['application'] = 'users';
                $this->data['function'] = '';
                $this->data['layout_type'] = 'layout-top-nav';
                $this->data['lang'] = $this->lang;

                $segment_view = $this->uri->getSegment(4);

                $this->data['deny'] = false;

                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                elseif(!in_array($segment_view, $this->menus_excepted))
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                /**
                 * Check if the user was granted to this
                 * The administrateur has to activate/deactivate user
                 * $_SESSION['Grant_Education'] 
                 */
                if ($this->session->userdata['account_id'] == '1') {
                        $this->group = 'main';
                } elseif ($this->session->userdata['user_type'] == '200') {
                        $this->group = 'admin';
                } else {
                        $this->group = 'user';
                }

                /*
                    * Profile picture or logo
                    * fileToUpload
                    */
                if (isset($_FILES['fileToUpload']['name'])) {
                        if ($_FILES['fileToUpload']['name'] != "") $this->imageModel = new ImageModel();
                }

        }


        public function index()
        {
                // add_meta_title('iKwook Project');
                // $this->data['subview'] = 'main/container';
                // $this->load->view('_layout_main', $this->data);

                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }

        public function change()
        {
                add_meta_title('iKwook Cloud');
                $this->data['subview'] = '\Modules\Admin\Views\container'; //'main/user/'.$this->lang.'/main';
                echo view('layouts/layout_admin', $this->data);
        }

        public function dashboard($schedule = NULL)
        {
                add_meta_title('iKwook Project');
                $this->data['categories'] = $this->mainModel->account_categories[$this->lang];
                $this->data['countries'] = $this->mainModel->get_dropdown('country');
                $this->data['business'] = $this->session->userdata['user_business'];
                $this->data['members'] = array();
                $this->data['users'] = $this->mainModel->get_users();
                $this->data['groups'] = $this->mainModel->get_groups();
                $this->data['sites'] = $this->mainModel->get_sites();
                $this->data['visitors'] = $this->mainModel->get_users('', '', '', '400');
                $this->data['status'] = $this->manageModel->status['fr'];
                $this->data['color'] = $this->manageModel->color_status;


                $dedicated_applications = $this->data['app_dedicated'] = $this->mainModel->standard_applications[$this->lang];
                $myapps = explode(',', $this->session->userdata['account_myapps']);

                $module = '';
                foreach ($dedicated_applications as $dashbord => $applications) :
                        foreach ($myapps as $app) :
                                if (key_exists($app, $applications)) {
                                        $module[$dashbord][$app] = $app;
                                }
                        endforeach;
                endforeach;
                $this->data['MyApps'] = $module;
                $this->data['dashboards'] = $this->mainModel->user_dashboard[$this->lang];
                $this->data['applications'] = $this->mainModel->ikwook_applications;

                if ($this->session->userdata['account_category'] == 303) {
                        redirect('pay/hotleads/', 'refresh');
                } else {
                        $this->data['subview'] = 'main/' . $this->group . '/' . $this->lang . '/dashboard';
                }
                echo view('layouts/layout_admin', $this->data);
        }

        public function change_guichet()
        {
                if (!$this->can_switch_guichet()) {
                        return redirect()->to(base_url('main/denied'));
                }

                $this->data['title'] = 'Changer de guichet';

                $guichets = $this->branchModel->get_guichets('Guichet');
                $current_guichet = $_SESSION['Logiref_guichet'] ?? '';
                $current_guichet_label = 'Aucun guichet actif';

                foreach ($guichets as $guichet) {
                        if ((string) $current_guichet === (string) $guichet->Id_0) {
                                $current_guichet_label = $guichet->Nom_4;
                                break;
                        }
                }

                $this->data['sidebar'] = '';
                $this->data['subview'] = '\Modules\Admin\Views\users\change_guichet';
                $this->data['guichets'] = $guichets;
                $this->data['current_guichet'] = $current_guichet;
                $this->data['current_guichet_label'] = $current_guichet_label;

                echo view('layouts/layout_admin', $this->data);
        }

        public function switch_guichet()
        {
                if (!$this->can_switch_guichet()) {
                        if ($this->request->isAJAX()) {
                                return $this->response->setJSON([
                                        'status' => 'error',
                                        'message' => 'Accès refusé.',
                                ]);
                        }

                        return redirect()->to(base_url('main/denied'));
                }

                $guichet_id = trim((string) $this->request->getPost('guichet_id'));

                if ($guichet_id === '') {
                        if ($this->request->isAJAX()) {
                                return $this->response->setJSON([
                                        'status' => 'error',
                                        'message' => 'Veuillez sélectionner un guichet.',
                                ]);
                        }

                        session()->setFlashdata('error', 'Veuillez sélectionner un guichet.');
                        return redirect()->to(base_url('admin/users/change-guichet'));
                }

                $guichet = $this->get_authorized_guichet_by_id((int) $guichet_id);

                if ($guichet === null) {
                        if ($this->request->isAJAX()) {
                                return $this->response->setJSON([
                                        'status' => 'error',
                                        'message' => 'Le guichet sélectionné est invalide ou inaccessible.',
                                ]);
                        }

                        session()->setFlashdata('error', 'Le guichet sélectionné est invalide ou inaccessible.');
                        return redirect()->to(base_url('admin/users/change-guichet'));
                }

                $this->session->set('pending_switch_guichet_id', (int) $guichet->Id_0);
                $this->session->set('pending_switch_guichet_label', $guichet->Nom_4);

                if ($this->request->isAJAX()) {
                        return $this->response->setJSON([
                                'status' => 'success',
                                'message' => 'Guichet sélectionné. Veuillez confirmer votre mot de passe pour finaliser la reconnexion.',
                                'redirect_url' => base_url('admin/users/confirm-guichet'),
                        ]);
                }

                return redirect()->to(base_url('admin/users/confirm-guichet'));
        }

        public function confirm_guichet()
        {
                if (!$this->can_switch_guichet()) {
                        return redirect()->to(base_url('main/denied'));
                }

                $pending_guichet_id = (int) ($this->session->get('pending_switch_guichet_id') ?? 0);
                $pending_guichet = $this->get_authorized_guichet_by_id($pending_guichet_id);

                if ($pending_guichet === null) {
                        session()->setFlashdata('error', 'Veuillez d\'abord sélectionner un guichet valide.');
                        return redirect()->to(base_url('admin/users/change-guichet'));
                }

                $this->data['title'] = 'Confirmation de reconnexion';
                $this->data['sidebar'] = '';
                $this->data['subview'] = '\Modules\Admin\Views\users\confirm_guichet';
                $this->data['pending_guichet_id'] = $pending_guichet->Id_0;
                $this->data['pending_guichet_label'] = $pending_guichet->Nom_4;
                $this->data['user_identifier'] = $this->session->userdata['user_username'] ?? '';

                echo view('layouts/layout_admin', $this->data);
        }

        public function reconnect_guichet()
        {
                if (!$this->can_switch_guichet()) {
                        if ($this->request->isAJAX()) {
                                return $this->response->setJSON([
                                        'status' => 'error',
                                        'message' => 'Accès refusé.',
                                ]);
                        }

                        return redirect()->to(base_url('main/denied'));
                }

                $pending_guichet_id = (int) ($this->session->get('pending_switch_guichet_id') ?? 0);
                $pending_guichet = $this->get_authorized_guichet_by_id($pending_guichet_id);

                if ($pending_guichet === null) {
                        if ($this->request->isAJAX()) {
                                return $this->response->setJSON([
                                        'status' => 'error',
                                        'message' => 'Aucun guichet en attente de confirmation.',
                                ]);
                        }

                        session()->setFlashdata('error', 'Aucun guichet en attente de confirmation.');
                        return redirect()->to(base_url('admin/users/change-guichet'));
                }

                $passcode = (string) ($this->request->getPost('passcode') ?? '');

                if ($passcode === '') {
                        return $this->response->setJSON([
                                'status' => 'error',
                                'message' => 'Veuillez saisir votre mot de passe.',
                        ]);
                }

                $profile = $this->mainModel->get_profile_infos($this->session->userdata['user_id'] ?? 0);

                if (empty($profile) || empty($profile->Id_0)) {
                        return $this->response->setJSON([
                                'status' => 'error',
                                'message' => 'Impossible de retrouver le profil utilisateur.',
                        ]);
                }

                $password_valid = $this->mainModel->verifyLogin($profile->Identifier_7, $passcode);

                if (!$password_valid) {
                        return $this->response->setJSON([
                                'status' => 'error',
                                'message' => 'Mot de passe incorrect.',
                        ]);
                }

                $connected_user = $this->get_connected_logiref_user();

                if ($connected_user === null) {
                        return $this->response->setJSON([
                                'status' => 'error',
                                'message' => 'Impossible de retrouver le profil Logiref de l\'utilisateur connecté.',
                        ]);
                }

                $switch_saved = $this->update_connected_user_guichet($connected_user, $pending_guichet);

                if (!$switch_saved) {
                        return $this->response->setJSON([
                                'status' => 'error',
                                'message' => 'Le changement de guichet n\'a pas pu être enregistré.',
                        ]);
                }

                $this->refresh_connected_user_session();
                $this->clear_pending_guichet_switch();

                return $this->response->setJSON([
                        'status' => 'success',
                        'message' => 'Reconnexion effectuée avec succès sur le nouveau guichet.',
                        'redirect_url' => base_url('branch/taxdashboards/set/etax'),
                ]);
        }

        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * List: 
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                    if ((isset($_SESSION['Logiref_role']) && ($_SESSION['Logiref_role'] == 4 || $_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 5)) || $needle == 'password') 
                    {
                            $this->data['sidebar'] = '';
                    }
                    $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == 'users')
                {
                        $param = $id;
                        $this->data['environnement'] = $this->mainModel->environnement;
                        $this->data['users'] = $this->mainModel->get_users();
                        $this->data['modules'] = $this->mainModel->get_dropdown("users_module");
                        $this->data['allmoduleUser'] = isset($_SESSION['userdata']['modules']) ? json_decode($_SESSION['userdata']['modules'], true) : '';

                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\users\users_2', $this->data);
                        else:

                                echo view('\Modules\Admin\Views\users\users', $this->data);
                        endif;
                }
                elseif ($obj == 'users_filter')
                {
                        $module = $id;

                        $this->data['environnement'] = $this->mainModel->environnement;
                        $this->data['users'] = $this->mainModel->get_users_by_modules($module);
                        $this->data['modules'] = $this->mainModel->get_dropdown("users_module");
                        $this->data['module'] = $module;
                        $this->data['allmoduleUser'] = isset($_SESSION['userdata']['modules']) ? json_decode($_SESSION['userdata']['modules'], true) : '';

                        echo view('\Modules\Admin\Views\users\_users_filter', $this->data);
                }
                elseif ($obj == 'user')
                {
                        $myapps = $this->session->userdata['account_myapps'];
                        $myrestrict = $this->session->userdata['account_restrict'];
                        $dedicated_applications = $this->data['app_dedicated'] = $this->mainModel->dedicated_applications[$this->lang];

                        $myapps = explode(',', $myapps);
                        $myrestrict = explode(',', $myrestrict);

                        $myapps = array_merge($myapps, $myrestrict);

                        if ($id != 'pager') $relation = $this->mainModel->get_relation_infos($id);

                        $apps = '';

                        if (isset($relation->Applications_14)) {
                                $apps = $relation->Applications_14;
                        }

                        if ($id != "" && $id != 'pager' && $apps != "") {
                                $relation = $this->mainModel->get_relation_infos($id);

                                $myapps = explode(',', $apps);
                        }

                        $dmenu = array();
                        $i = 0;

                        foreach ($dedicated_applications as $dashboard => $applications) :
                                foreach ($myapps as $app) :
                                        if (key_exists($app, $applications)) {
                                                if ($i == 0) {
                                                        $dmenu[''][''] = '';
                                                }
                                                $dmenu[$dashboard][$app] = $app;
                                                $i++;
                                        }
                                endforeach;
                        endforeach;

                        if ($id == 'pager') {
                                $this->data['dedicated_applications'] = $this->mainModel->standard_applications[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModel->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModel->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModel->get_profile_infos();
                                $this->data['relation'] = $this->mainModel->get_relation_infos();
                        } else {
                                $this->data['dedicated_applications'] = $this->mainModel->standard_applications[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModel->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModel->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModel->get_profile_infos($id);
                                $this->data['relation'] = $this->mainModel->get_relation_infos($id);
                        }
                        $this->data['dashboards'] = $this->mainModel->user_dashboard[$this->lang];

                        $this->data['applications'] = $dmenu;

                        echo view('\Modules\Admin\Views\users\_user', $this->data);
                }
                elseif ($obj == 'account')
                {
                        $account_id = $this->session->userdata['account_id'];
                        $this->data['dashboards'] = $this->mainModel->user_dashboard[$this->lang];
                        $this->data['account'] = $this->mainModel->get_account_infos($account_id);
                        $this->data['countries'] = $this->mainModel->get_dropdown("country");
                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\_' . $obj, $this->data);
                }
                elseif ($obj == 'profile')
                {
                        $dedicated_applications = $this->data['app_dedicated'] = $this->mainModel->standard_applications[$this->lang];
                        $dmenu = array();
                        if ($this->session->userdata['user_type'] == '200') {
                                $myapps = $this->session->userdata['account_myapps'];
                                $myapps = explode(',', $myapps);

                                foreach ($dedicated_applications as $dashboard => $applications) :
                                        foreach ($myapps as $app) :
                                                if (key_exists($app, $applications)) {
                                                        $dmenu[$dashboard][] = $app;
                                                }
                                        endforeach;
                                endforeach;
                        } elseif ($this->session->userdata['user_type'] == '300') {
                                $myapps = $this->session->userdata['user_apps'];
                                $myapps = explode(',', $myapps);
                                $i = 0;

                                foreach ($dedicated_applications as $dashboard => $applications) :
                                        foreach ($myapps as $app) :
                                                if (key_exists($app, $applications)) {
                                                        if ($i == 0) {
                                                                $dmenu[''][''] = '';
                                                        }
                                                        $dmenu[$dashboard][$app] = $app;
                                                        $i++;
                                                }
                                        endforeach;
                                endforeach;
                        }

                        if (empty($dmenu)) {
                                $applications = $this->mainModel->standard_applications[$this->lang];
                        }
                        $profile_id = $this->session->userdata['user_id'];
                        $this->data['applications'] = $dmenu;
                        $this->data['dmenu'] = !empty($dmenu) ? $dmenu : $applications;
                        $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                        $this->data['dashboards'] = $this->mainModel->user_dashboard[$this->lang];
                        $this->data['groups'] = $this->mainModel->get_dropdown('groups');
                        $this->data['sites'] = $this->mainModel->get_dropdown('sites');
                        $this->data['profile'] = $this->mainModel->get_profile_infos($profile_id);
                        $this->data['relation'] = $this->mainModel->get_relation_infos($profile_id);

                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\' . $obj, $this->data);
                }
                elseif ($obj == 'password')
                {
                        // Utilisateurs external auth — mot de passe géré par l'annuaire/gateway
                        $funcs    = json_decode($this->session->userdata['options'] ?? '{}', true) ?: [];
                        $userType = $this->session->userdata['user_type'] ?? '';
                        $isExternalAuth = !empty($funcs['ALL']['ext_auth']['enabled'])
                                          && !in_array($userType, ['100', '200']);

                        if ($isExternalAuth) {
                                return redirect()->to(base_url('main/overview'));
                        }

                        $profile_id = $this->session->userdata['user_id'];
                        $this->data['profile'] = $this->mainModel->get_profile_infos($profile_id);
                        $this->data['relation'] = $this->mainModel->get_relation_infos($profile_id);

                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\_' . $obj, $this->data);
                }
                elseif ($obj == 'change')
                {
                        $this->data['accounts'] = $this->mainModel->get_all_accounts();
                        $this->data['roles'] = $this->mainModel->user_role[$this->lang];
                        $this->data['boxed'] = 'layout-boxed';
                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\_' . $obj, $this->data);
                }
                elseif ($obj == "unblocking")
                {
                        $_SESSION['location'] = $obj;
                        $this->data['title'] = "Les comptes  bloqu&eacutes";
                        $this->data['inactifs'] = $this->manageModel->get_profil_by_status("inactive");
                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\' . $obj, $this->data);
                }

                #Gestion privilege
                elseif ($obj == "privileges")
                {
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        $this->data['statut'] = $this->userModel->status;
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        $this->data['statutColor'] = $this->userModel->state_Color;
                        $this->data['groups'] = $this->logirefModel->get_groups();
                        $this->data['isys'] = $this->integrationModel->get_isys_account_info();
                        $this->data['sydonia'] = $this->integrationModel->get_sydonia_account_info();
                        $this->data['members'] = $this->userModel->get_dropdown("users");
                        $users['0'] = 'Member';
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['roles'] = $this->userModel->role;
                        } else {
                                $this->data['fonctions'] = $this->userModel->fonction;
                        }
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        echo view('\Modules\Admin\Views\users\privileges', $this->data);
                }
                elseif ($obj == "_privilege")
                {

                        $this->data['statut'] = $this->userModel->status;
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter", 'PROVINCE');
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter", 'VILLE');
                        $this->data['from'] = $arg;
                        $members = $this->userModel->get_dropdown("users");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];
                        foreach ($members as $val) unset($this->data['users'][$val]);
                        $this->data['users'][''] = '';
                        $this->data['profile'] = $profile = $this->userModel->get_profile_info($id);
                        $this->data['user'] = $user = $this->userModel->get_user_by_profile_id($profile->Id_0);

                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['roles'] = $this->userModel->role;
                        }
                        else {
                                $this->data['fonctions'] = $this->userModel->fonction;
                                $this->data['fonctions'][1] = "";
                        }
                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';
                        $bankid = $this->session->userdata['account_id'];
                        $auth = $this->authorizationsModel->get_authorisations_by_bankid($bankid);

                        if($auth->Id_0 !='')
                        {
                                $auth_functionnalities = json_decode($auth->Functionnalities_9, true);
                                $auth_bank_functionnalities = isset($auth_functionnalities['Bank']) ? $auth_functionnalities['Bank'] : array();
                        }
                        else
                        {
                                $auth_bank_functionnalities = array();
                        }
                        $this->data["Options"] = (!empty($user->Option_22) && !is_null($user->Option_22))?json_decode($user->Option_22):array();
                        $this->data['functionnalities'] = $auth_bank_functionnalities;
                        echo view('\Modules\Admin\Views\users\_privilege', $this->data);
                }

                #Gestion privilege QLead _privilege_qlead
                elseif ($obj == "_privilege_qlead")
                {
                        $this->data['tellers'] = $this->userQleadModel->tellers;
                        $this->data['statut'] = $this->userQleadModel->status;
                        $this->data['studies_level'] = $this->userQleadModel->studies_level;
                        $this->data['status_marital'] = $this->userQleadModel->status_marital;
                        $this->data['status_parental'] = $this->userQleadModel->status_parental;
                        $this->data['gender'] = $this->userQleadModel->gender;
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['from'] = $arg;

                        $members = $this->userQleadModel->get_dropdown("users");

                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['noms'] = $this->data['users'];

                        foreach ($members as $val) unset($this->data['users'][$val]);

                        $this->data['users'][''] = '';
                        $this->data['profile'] = $profile = $this->mainModel->get_profile_infos($id);
                        $this->data['user'] = $user = $this->userQleadModel->get_user_by_profile_id($profile->Id_0);

                        $branchid = $user->Branchid_9;
                        $this->data['queues'] = $this->queueModel->get_dropdown("queue_agence", $branchid);

                        if ($_SESSION['Logiref_groupe'] == 'banks')
                        {
                                $this->data['roles'] = $this->userQleadModel->authorization;
                                $this->data['logiref_roles'] = $this->userQleadModel->role;
                        }
                        else
                        {
                                $this->data['fonctions'] = $this->userQleadModel->fonction;
                                $this->data['fonctions'][1] = "";
                        }

                        unset($this->data['groups'][1]);
                        $this->data['groups'][''] = '';

                        echo view('\Modules\Admin\Views\users\_privilege_qlead', $this->data);
                }

                #Dashboard
                elseif ($obj == "dashboard")
                {
                        echo view('\Modules\Admin\Views\admin\\' . $this->lang . '\\' . $obj, $this->data);
                }

                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
                return true;
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                $msg = array('en' => '', 'fr' => '');
                /**
                 * Site or branch/Group/User
                 * @save new record and updating existing onces if @ID is not NULL
                 */
                if ($obj == 'site') 
                {
                        if (isset($_POST['Name_7']) && $_POST['Name_7'] != "" && isset($_POST['Description_8'])) {
                                if ($id == NULL) {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                } else {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                $data['Name_7'] = $_POST['Name_7'];
                                $data['Description_8'] = $_POST['Description_8'];

                                $sid = $this->mainModel->save_site($data, $id);

                                if ($sid) {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Branche saved successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        echo $msg[$this->lang];
                } 
                elseif ($obj == 'group') 
                {
                        if (isset($_POST['Name_7']) && $_POST['Name_7'] != "" && isset($_POST['Description_8'])) {
                                if ($id == NULL) {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                } else {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                $data['Name_7'] = $_POST['Name_7'];
                                $data['Description_8'] = $_POST['Description_8'];

                                $sid = $this->mainModel->save_group($data, $id);

                                if ($sid) {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Group saved successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        echo $msg[$this->lang];
                }
                elseif ($obj == 'user')
                {
                        $validate = FALSE;
                        $email = trim($_POST['Email_13'] ?? '');
                        $result = $email !== '' ? $this->mainModel->check_if_user_exist($email) : [];

                        if (count($result) > 0) {

                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible"> ' . $email . ', Avertissement! cette adresse est associ&eacute; &agrave; un autre compte!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! ' . $email . ', this email is associated with an existing account.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } else {

                                if ($id == NULL && isset($_POST['Cellphone_12']) && $_POST['Cellphone_12'] != "" && isset($_POST['Email_13']) && $_POST['Email_13'] != "") {
                                        $password = $this->mainModel->get_new_password();

                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                        $data['Identifier_7'] = $username = $this->request->getPost('Email_13');
                                        $data['Encryption_8'] = $this->mainModel->generate_hash($password);
                                        $data['Cellphone_12'] = $this->request->getPost('Cellphone_12');
                                        $data['Email_13'] = $this->request->getPost('Email_13');
                                        $validate = TRUE;
                                } else {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                        $validate = TRUE;
                                }

                                if ($validate === TRUE) {
                                        //Profile Data 
                                        $fields = array(
                                                'Firstname_9' => 'Firstname_9',
                                                'Lastname_10' => 'Lastname_10',
                                                'Middlename_11' => 'Middlename_11',
                                                'Language_14' => 'Language_14',
                                                'Lastname_10' => 'Lastname_10',
                                                'Birthday_17' => 'Birthday_17',
                                                'Position_18' => 'Position_18',
                                                'Gender_15' => 'Gender_15'
                                        );

                                        foreach ($fields as $field => $value) {
                                                $data[$field] = $this->request->getPost($value);
                                        }

                                        //Upload image
                                        if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) {
                                                // array of valid extensions
                                                $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                                // get extension of the uploaded file
                                                $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
                                                // check if file Extension is on the list of allowed ones
                                                if (in_array($fileExtension, $validExtensions)) {
                                                        $newNamePrefix = time() . '_';
                                                        // resizing to 200x200
                                                        $newImage = $this->imageModel->resample(200, 200);
                                                        // saving file to uploads folder
                                                        $target_file = "./ikwook_files/profiles/" . $newNamePrefix . $_FILES['fileToUpload']['name'];
                                                        $this->imageModel->saveImage($target_file);
                                                        $data['Profile_16'] = $target_file;
                                                        $_SESSION['user_profile'] =  $target_file;
                                                } else {
                                                        $uploadError = true;
                                                }
                                        }
                                        
                                        #Saving
                                        $user_id = $this->mainModel->save_profile($data, $id);
                                        
                                        if ($user_id)
                                        {
                                                #Relation Data 
                                                $data = array();
                                                $relation_id = $this->request->getPost('relation_id');

                                                if ($relation_id == "") 
                                                {
                                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                                        $data['Status_2'] = 1;
                                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                                        $data['User_7'] = $user_id;
                                                        $relation_id = NULL;
                                                }
                                                else
                                                {
                                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                                }
                                                
                                                if (isset($_POST['application']) && $_POST['application']) {
                                                        $application = implode(',', $_POST['application']);
                                                        $data['Applications_14'] = $application;
                                                }
                                                
                                                $fields = array(
                                                        'Branch_9' => 'Branch_9',
                                                        'Group_8' => 'Group_8',
                                                        'Type_10' => 'Type_10',

                                                );

                                                foreach ($fields as $field => $value) 
                                                {
                                                        $data[$field] = $this->request->getPost($value);
                                                }

                                                if (isset($_POST['Module_11']) && $_POST['Module_11'] != '') 
                                                {
                                                        $data['Module_11'] = $_POST['Module_11'];
                                                }
                                                
                                                $rid = $this->mainModel->save_relation($data, $relation_id);
                                                
                                                # Confirmation mail
                                                if($id==NULL )
                                                {
                                                        $this->mail->mail_profile_confirmation($_POST['Firstname_9'], $username, $password, $this->session->userdata['user_fname']);
                                                }
                                        }

                                        if (isset($uploadError)) 
                                        {
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de t&eacute;l&eacute;chargement</strong> Les extensions acceptable sont JPG, JPEG, GIF ou PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        elseif ($user_id) 
                                        {
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Bien!....enregistr&eacute;s avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Great!...saved successfully.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        else 
                                        {
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">ERROR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">ERREUR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } 
                                else 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications non enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }

                        echo $msg[$this->lang];
                } 
                elseif ($obj == "visitor") 
                {
                        if (isset($_POST['User_7']) && $_POST['User_7'] > 0 && $_POST['Branch_9'] != "" && $_POST['Group_8'] != "" && $_POST['Type_10'] != "") {
                                if ($id == NULL) {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                } else {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }

                                $fields = array(
                                        'Branch_9' => 'Branch_9',
                                        'Group_8' => 'Group_8',
                                        'Type_10' => 'Type_10',
                                        'Module_11' => 'Module_11',
                                        'User_7' => 'User_7'
                                );

                                foreach ($fields as $field => $value) {
                                        $data[$field] = $this->request->getPost($value);
                                }

                                $rid = $this->mainModel->save_relation($data, $id);

                                if ($rid && $id == NULL) {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Invitation sent successfully<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } elseif ($id > 0 && $rid) {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Modifications enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Changes saved successfully<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        echo $msg[$this->lang];
                } 
                elseif ($obj == 'account') 
                {
                        $fields = array(
                                'Business_7'    => 'Business_7',
                                'Email_16'      => 'Email_16',
                                'Telephone_15'  => 'Telephone_15',
                                'Address_21'    => 'Address_21',
                                'Address_22'    => 'Address_22',
                                'City_20'       => 'City_20',
                                'State_19'      => 'State_19',
                                'City_20'       => 'City_20',
                                'Country_12'    => 'Country_12',
                                'Postal_23'     => 'Postal_23',
                                'Website_18'    => 'Website_18',
                                'Currency_13'   => 'Currency_13',
                                'Description_9' => 'Description_9',
                                'Dashboard_14'  => 'Dashboard_14',
                                'Pageid_24'     => 'Pageid_24'
                        );

                        foreach ($fields as $field => $value) {
                                $data[$field] = $this->request->getPost($value);
                        }

                        //Validation
                        if (count($data)) {
                                if ($data['Currency_13'] != "" && $data['Country_12'] != "") {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];

                                        //var_dump($_FILES['fileToUpload']); die;

                                        //Upload image
                                        if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) {
                                                #Root director
                                                $fileprefix = date('Ymdhs') . "_";
                                                $filename = "./ikwook_files/logos/" . $this->session->userdata['account_id'] . '/' . $fileprefix . $_FILES['fileToUpload']['name'];
                                                #array of valid extensions
                                                $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                                #get extension of the uploaded file
                                                $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
                                                #check if file Extension is on the list of allowed ones
                                                if (in_array($fileExtension, $validExtensions)) {
                                                        # Save
                                                        #resizing to 200x200  saving file to uploads folder
                                                        $newImage = $this->imageModel->resample(200, 200, false);
                                                        $this->imageModel->saveImage($filename);
                                                        #Db
                                                        $data['Logo_17'] = $filename;
                                                        $_SESSION['account_logo'] = $filename;
                                                } else if ($fileExtension != "") {
                                                        $uploadError = true;
                                                }
                                        }

                                        #Saving
                                        $pid = $this->session->userdata['account_id'];
                                        $success = $this->mainModel->save_account($data, $pid);

                                        if (isset($uploadError)) {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de t&eacute;l&eacute;chargement d\'image !</strong> Extensions exig&eacute;e:  JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        elseif (isset($arg) && $success && $arg == 'complete') {
                                                if (isset($_POST['Country_12']) && $_POST['Country_12'] != "") $_SESSION['account_country'] = $_POST['Country_12'];

                                                $settings = $this->mainModel->get_dashboard();
                                                $dashboard = $settings['dashboard'];
                                                if (!isset($_SESSION['dashboard'])) $_SESSION['dashboard'] = $dashboard;
                                                echo view('\Modules\Admin\Views\users\_complete3', $this->data);

                                        } 
                                        elseif ($success) 
                                        {
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Information enregistrees avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Changes saved successfully!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        else {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">An error has occurred, please check again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Erreur 303A, veuillez reessayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } else {
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }

                                //New account
                                if (isset($arg) && $arg == 'complete' && isset($msg[$this->lang])) {
                                        $this->data['msg'] = $msg[$this->lang];
                                } elseif (isset($msg[$this->lang])) {
                                        echo $msg[$this->lang];
                                }
                        }
                } 
                elseif ($obj == 'profile') 
                {
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];

                        $error['en'] = "";
                        $error['fr'] = "";

                        $fields = array(
                                'Firstname_9' => 'Firstname_9',
                                'Middlename_11' => 'Middlename_11',
                                'Cellphone_12' => 'Cellphone_12',
                                'Language_14' => 'Language_14',
                                'Lastname_10' => 'Lastname_10',
                                'Birthday_17' => 'Birthday_17',
                                'Position_18' => 'Position_18',
                                'Email_13' => 'Email_13',
                                'Gender_15' => 'Gender_15'
                        );

                        foreach ($fields as $field => $value) {
                                $data[$field] = $this->request->getPost($value);
                        }

                        //Validation
                        if (count($data) && $error['en'] == "" || $error['fr'] == "") 
                        {
                                if ($data['Cellphone_12'] != "") 
                                {
                                        $profile = $this->mainModel->get_profile_by_id($user_id);

                                        $error_match_lastpassword = false;
                                        $uploadError = false;
                                        $lastpassword = array();
                                        $i = 0;

                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];

                                        //Upload image
                                        if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) 
                                        {
                                                // array of valid extensions
                                                $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                                // get extension of the uploaded file
                                                $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");

                                                // check if file Extension is on the list of allowed ones
                                                if (in_array($fileExtension, $validExtensions))
                                                {
                                                        $newNamePrefix = time() . '_';

                                                        // resizing to 200x200
                                                        $newImage = $this->imageModel->resample(200, 200);
                                                        // saving file to uploads folder
                                                        $target_file = "./ikwook_files/profiles/" . $newNamePrefix . $_FILES['fileToUpload']['name'];

                                                        $this->imageModel->saveImage($target_file);
                                                        $data['Profile_16'] = $target_file;
                                                        $_SESSION['user_profile'] =  $target_file;
                                                }
                                                else
                                                {
                                                        $uploadError = true;
                                                }
                                        }

                                        if($uploadError == false)
                                        {
                                                #Saving
                                                $pid = $this->session->userdata['user_id'];
                                                $success = $this->mainModel->save_profile($data, $pid);
                                        }

                                        if ($success > 0 && isset($_POST['relation_id'])) 
                                        {
                                                if (isset($_POST['Module_11'])) $data_relation['Module_11'] = $_POST['Module_11'];
                                                else $data_relation['Module_11'] = 'logiref';
                                                $relation_id = $_POST['relation_id'];
                                                $this->mainModel->save_relation($data_relation, $relation_id);
                                        }

                                        if ($uploadError) 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de telechargement d\'image !</strong> Les extensions acceptable sont JPG, JPEG, GIF ou PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        elseif ($success && isset($arg) && $arg == 'complete') 
                                        {
                                                $_SESSION['user_lang'] = $this->mainModel->languages[$data['Language_14']];
                                                $this->data['account'] = $this->mainModel->get_account_infos($this->session->userdata['account_id']);
                                                $this->data['countries'] = $this->mainModel->get_dropdown("country");
                                        } 
                                        elseif ($success) 
                                        {
                                                $_SESSION['user_lang'] = $this->mainModel->languages[$data['Language_14']];
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Okay! Information enregistr&eacute;e avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Coolio! Information saved successfully!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        } 
                                        else 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Une erreur se produite, veuillez essayer encore!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">An error has occurred, please check again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } 
                                else 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Veuillez renseigner un numero de telephone..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }

                        //New account?user
                        if (isset($arg) && $arg == 'complete' && isset($msg[$this->lang]))
                        {
                                $this->data['msg'] = $msg[$this->lang];
                        }
                        elseif (isset($msg[$this->lang])) 
                        {
                                echo $msg[$this->lang];
                        }
                }
                elseif ($obj == "password")
                {
                        $error_match_lastpassword = false;
                        $lastpassword = array();
                        $i = 0;
                        $error['en'] = "";
                        $error['fr'] = "";


                        if(isset($_POST['password1']) && isset($_POST['password2']) && isset($_POST['password3']) && isset($_POST['password4']))
                        {
                                $user_id = $this->session->userdata['user_id'];
                                $password = $_POST['password3'];

                                if (strlen($password) < 8)
                                {
                                        $error['en'] = "Password too short !";
                                        $error['fr'] = "le mot de passe est tr&egrave;s court !";
                                }
                                if (strlen($password) > 20)
                                {
                                        $error['en'] = "Password too long !";
                                        $error['fr'] = "le mot de passe est tr&egrave;s long !";
                                }
                                if (!preg_match("#[0-9]+#", $password))
                                {
                                        $error['en'] = "Password must include at least one number !";
                                        $error['fr'] = "Le mot de passe doit contenir au moins un chiffre !";
                                }
                                if (!preg_match("#[a-z]+#", $password))
                                {
                                        $error['en'] = "Password must include at least one lowercase letter !";
                                        $error['fr'] = "Le mot de passe doit contenir au moins une lettre miniscule !";
                                }
                                if (!preg_match("#[A-Z]+#", $password))
                                {
                                        $error['en'] = "Password must include at least one capital letter !";
                                        $error['fr'] = "Le mot de passe doit contenir au moins une lettre majiscule !";
                                }
                                if (!preg_match("#\W+#", $password)) 
                                {
                                        $error['en'] = "Password must include at least one symbol !";
                                        $error['fr'] = "Le mot de passe doit contenir au moins un caract&egrave;re sp&eacute;cial !";
                                }
                                if ($error['en'] != "" || $error['fr'] != "") 
                                {
                                        $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">' . $error['en'] . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">' . $error['fr'] . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }

                                if ($error['fr'] == "" && $error['en'] == "") 
                                {
                                        if (isset($_POST['password1']) && $_POST['password1'] != "" && isset($_POST['password3']) && $_POST['password3'] != "") 
                                        {
                                                $user_info = $this->mainModel->get_profile_infos($user_id);

                                                $matches = $this->mainModel->verify($_POST['password1'], $user_info->Encryption_8);

                                                if ($matches) 
                                                {
                                                        if (!isset($_POST['password2']) || $_POST['password2'] != $_POST['password1']) 
                                                        {
                                                                $error_password_confirm1 = true;
                                                        }
                                                        if (isset($_POST['password4']) && $_POST['password4'] == $_POST['password3']) 
                                                        {
                                                                $new_password = $this->mainModel->generate_hash($_POST['password3']);
                                                                $data['Encryption_8'] = $new_password;
                                                        } 
                                                        else 
                                                        {
                                                                $error_password_confirm2 = true;
                                                        }
                                                } 
                                                else 
                                                {
                                                        $error_password = true;
                                                }
                                        }
                                }

                                if ($error['en'] == "" && $error['fr'] == "") 
                                {
                                        $profile = $this->mainModel->get_profile_by_id($user_id);

                                        if (isset($profile->Lastpassword_24) && $profile->Lastpassword_24 != "") 
                                        {
                                                $lastpassword = json_decode($profile->Lastpassword_24, true);

                                                for ($i = 0; $i <= 5; $i++) 
                                                {
                                                        if (isset($lastpassword[$i])) 
                                                        {
                                                                $matches = $this->mainModel->verify($_POST['password4'], $lastpassword[$i]);

                                                                if ($matches) 
                                                                {
                                                                        $error_match_lastpassword = true;
                                                                }
                                                        }
                                                }

                                                if (!$error_match_lastpassword) 
                                                {
                                                        if (count($lastpassword) == 6) 
                                                        {
                                                                for ($i = 0; $i <= 5; $i++) 
                                                                {
                                                                        if ($i < 5) 
                                                                        {
                                                                                $lastpassword[$i] =  $lastpassword[$i + 1];
                                                                        } 
                                                                        else 
                                                                        {
                                                                                $hashedpassword = $this->mainModel->generate_hash($_POST['password4']);
                                                                                $lastpassword[$i] = $hashedpassword;
                                                                        }
                                                                }
                                                        } 
                                                        else 
                                                        {
                                                                $hashedpassword = $this->mainModel->generate_hash($_POST['password4']);
                                                                array_push($lastpassword, $hashedpassword);
                                                        }

                                                        $data['Lastpassword_24'] = json_encode($lastpassword);
                                                }
                                        } 
                                        else 
                                        {

                                                $hashedpassword = $this->mainModel->generate_hash($_POST['password4']);
                                                $lastpassword[$i] = $hashedpassword;

                                                $data['Lastpassword_24'] = json_encode($lastpassword);

                                        }

                                        if (!$error_match_lastpassword)
                                        {
                                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                                $data['Statutdefaultpwd_31'] = 1;

                                                #Saving
                                                $pid = $this->session->userdata['user_id'];
                                                $success = $this->mainModel->save_profile($data, $pid);
                                        }
                                }

                                if($error['en'] != "" || $error['fr'] != "")
                                {
                                        echo $msg[$this->lang]; die;
                                }
                                elseif (isset($error_password)) 
                                {
                                        $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The password entered does not match the current password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le mot de passe entr&eacute; ne correspond pas au mot de passe actuel, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif (isset($error_password_confirm1)) 
                                {
                                        $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The current password entered does not match the confirmed password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le mot de passe actuel entr&eacute; ne correspond pas au mot de passe confirm&eacute;, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif (isset($error_password_confirm2))
                                {
                                        $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The new password entered does not match the confirmed password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le nouveau mot de passe entr&eacute; ne correspond pas au mot de passe confirm&eacute;, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif ($error_match_lastpassword) 
                                {
                                        $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The password must be different from the last 6 password you saved for this account !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le nouveau mot de passe doit &ecirc;tre diff&eacute;rent de 6 derniers mots de passe que que vous avez enregistr&eacute; pour ce compte, veuillez taper un mot de passe qui soit diff&eacute;rent de vos 6 derniers mot de passe s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                elseif ($success) 
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Okay! Information enregistr&eacute;e avec succ&egrave;s !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Coolio! Information saved successfully!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                else 
                                {
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Une erreur se produite, veuillez essayer encore!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">An error has occurred, please check again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }

                                echo $msg[$this->lang];
                        }
                        else
                        {
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Veuillez remplir tous les champs pour la modification du mot de passe s\'il vous plaît !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Please kindly fill in all field in order to change your password !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                echo $msg[$this->lang];
                        }
                }
                elseif ($obj == "user_logiref")
                {
                        if ($_POST['userid'] == '0' || $_POST['role'] == '' || $_POST['ville'] == '') {
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        }
                        else {
                                $Module_11 = "logiref";
                                $relation = $this->mainModel->get_relation_infos($_POST['userid']);
                                if($relation->Module_11 != "" && $relation->Module_11 != "logiref")
                                {
                                        if(in_array($relation->Module_11,array("elicense","eximtrade","qleads","etoll","logiref","Main","Pay"))){
                                                $Module_11 = json_encode(array($relation->Module_11,"logiref"));
                                        }
                                        else{
                                                $array = json_decode($relation->Module_11);
                                                if(!in_array("logiref",$array)){
                                                       array_push($array,"logiref");
                                                }
                                                $Module_11 = json_encode($array);
                                        }
                                }

                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') :

                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 2;
                                        $data['Statusvalidate_19'] = 2;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Maker_14'] = $this->session->userdata['user_id'];

                                endif;

                                if ($_SESSION['Logiref_role'] == 1) {
                                        $data['Role_4'] = $_POST['role'];
                                        $data['Province_5'] = $_POST['province'];
                                        $data['Ville_6'] = $_POST['ville'];
                                        $data['Agence_7'] = $_POST['agence'];
                                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                                $data['Guichet_8'] = $_POST['guichet'];
                                                $data['Regies_11'] = '';
                                        } else {
                                                $data['Service_10'] = $_POST['service'];
                                                $data['Regies_11'] = $_SESSION['Logiref_regies'];
                                        }
                                        $data['Groupe_9'] = $_SESSION['Logiref_groupe'];
                                        $data['Code_12'] = $_POST['code'];
                                        $data['Userid_13'] = $_POST['userid'];


                                        if ($_POST['role'] == '1' || $_POST['role'] == '2') {
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $rdata['Module_11'] = $Module_11;
                                                $userid = $_POST['userid'];
                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if ($id != "" || $id != '0') {
                                                if ($_POST['role'] != '1' && $_POST['role'] != '2') :

                                                        $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                        $rdata['Type_10'] = '300';
                                                        $rdata['Module_11'] = $Module_11;
                                                        $userid = $_POST['userid'];
                                                        $relationid = $this->mainModel->update_relation($rdata, $userid);

                                                endif;
                                        }

                                        $data['Checker_15'] = 0;
                                        $data['Validation_16'] = '0000-00-00';
                                        $data['Option_22'] = (!empty($_POST["Option_22"]))?json_encode($_POST["Option_22"]):Null;

                                } else {
                                        $data['Checker_15'] = $this->session->userdata['user_id'];
                                        $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                        if ($_POST['statusvalidate'] != "" && $_POST['statusvalidate'] != '0') {
                                                $data['Status_2'] = 1;
                                                $data['Statusvalidate_19'] = 1;
                                        }
                                }

                                #Database
                                $cid = $this->userModel->save_users($data,$id);
                        }

                        if ($cid) :
                                echo '<div class="alert alert-success">Super! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                elseif ($obj == "user_qlead") 
                {
                        if ($_POST['Userid_7'] == '0' || $_POST['Authorization_8'] == '' || $_POST['Branchid_9'] == '') 
                        {
                                echo '<div class="alert alert-danger">Avertissement! Vous devez selectionner les valeurs obligatoires.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                die;
                        } 
                        else 
                        {
                                //Do logiq here
                                if ($_POST['Id_0'] == '0' || $_POST['Id_0'] == '') 
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = '2';
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Makerid_12'] = $this->session->userdata['user_id'];
                                }

                                if ($_SESSION['Logiref_role'] == 1) 
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = '1';
                                        $data['Account_3'] = $this->session->userdata['account_id'];

                                        $data['Userid_7'] = $_POST['Userid_7'];
                                        $data['Authorization_8'] = $_POST['Authorization_8'];
                                        $data['Branchid_9'] = $_POST['Branchid_9'];
                                        $data['Tellercode_10'] = $_POST['Tellercode_10'];
                                        $data['Queueid_11'] = $_POST['Queueid_11'];
                                        $data['Makerid_12'] = $this->session->userdata['user_id'];
                                        $data['Gender_14'] = $_POST['Gender_14'];
                                        $data['Education_15'] = $_POST['Education_15'];
                                        
                                        $_POST['Birthyear_16'] = explode('-', $_POST['Birthyear_16']);
                                        $data['Birthyear_16'] = $_POST['Birthyear_16'][0];
                                        
                                        $data['Married_17'] = $_POST['Married_17'];
                                        $data['Parent_18'] = $_POST['Parent_18'];

                                        $Module_11 = "qleads";
                                        $relation = $this->mainModel->get_relation_infos($_POST['userid']);
                                        if($relation->Module_11 != "" && $relation->Module_11 != "qleads")
                                        {
                                                if(in_array($relation->Module_11,array("elicense","eximtrade","qleads","etoll","logiref","Main","Pay"))){
                                                        $Module_11 = json_encode(array($relation->Module_11,"qleads"));
                                                }
                                                else{
                                                        $array = json_decode($relation->Module_11);
                                                        if(!in_array("qleads",$array)){
                                                                array_push($array,"qleads"); 
                                                        }
                                                        $Module_11 = json_encode($array);
                                                }
                                        }
                                        
                                        if ($_POST['Authorization_8'] > '5') 
                                        {
                                                $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                $rdata['Type_10'] = '200';
                                                $rdata['Module_11'] = $Module_11;

                                                $userid = $_POST['Userid_7'];

                                                $relationid = $this->mainModel->update_relation($rdata, $userid);
                                        }

                                        if ($id != "" && $id != '0') 
                                        {
                                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                                        
                                                if ($_POST['Authorization_8'] < '5') 
                                                {
                                                        $rdata['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                        $rdata['Changer_6'] = $this->session->userdata['user_id'];
                                                        $rdata['Type_10'] = '300';
                                                        $rdata['Module_11'] = $Module_11;

                                                        $userid = $_POST['Userid_7'];

                                                        $relationid = $this->mainModel->update_relation($rdata, $userid);
                                                }
                                        }
                                        
                                        $data['Checkerid_13'] = 0;
                                } 
                                else 
                                {
                                        $data['Checkerid_13'] = $this->session->userdata['user_id'];

                                }
                                
                                $cid = $this->userQleadModel->save_users($data, $id);
                                
                        }
                        
                        if ($cid) :
                                echo '<div class="alert alert-success">Super! Changement effectu&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }

                return true;
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj== "verify_tellercode_queue")
                {

                        $user  = $this->userQleadModel->get_usercode_by_userid($_POST);
                        $queues = $this->queueModel->get_dropdown("queue_agence", $_POST['branchid']);

                        if (!empty($user))
                        {
                                $return['tellercode'] = FALSE;
                        }
                        else
                        {
                                $result = $this->userQleadModel->get_usercode_by_agence($_POST);

                                $return['tellercode'] = (!empty($result)) ? TRUE : FALSE;

                        }

                        if (!empty($queues))
                        {
                                if (isset($user->Queueid_11) && $user->Queueid_11!=""):
                                        $file_dropdown = form_dropdown('Queueid_11', $queues, $user->Queueid_11, ' id="queue" class="form-control" required="required');
                                else:
                                        $file_dropdown = form_dropdown('Queueid_11', $queues, "", ' id="queue" class="form-control" required="required');
                                endif;
                        } 
                        else
                        {
                                $file_dropdown = form_dropdown('Queueid_11', [''=>''], "", ' id="queue" class="form-control" required="required');

                        }

                        $return["queue"] = $file_dropdown;

                        echo json_encode($return);
                        die;
                }

        }

        public function activate($obj = NULL, $id = NULL, $status = NULL)
        {
                /**
                 * User
                 * Changing status to 1
                 */
                if ($obj == 'user') {
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $gid = $this->mainModel->save_profile($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                return true;
        }
        public function desactivate($data = NULL)
        {
                if (isset($data) || $data != "") {
                        $user = $this->mainModel->get_profile_by_email($data);

                        if (isset($user->Id_0) && $user->Id_0 != "") {
                                $data_to_save['Status_2'] = '2';
                                $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');


                                $this->userModel->update_users($data_to_save, $user->Id_0);
                        }
                }
        }
        public function reinitialize($obj = NULL, $id = NULL, $email = NULL)
        {
                /**
                 * User
                 * Changing status to 1
                 */
                if ($obj == 'password') {
                        if ($id == NULL && $email != NULL) {
                                $profile = $this->mainModel->get_profile_by_email($email);
                                if (isset($profile->Id_0)) $id = $profile->Id_0;
                        } elseif (isset($_POST['username']) && $_POST['username'] != NULL) {
                                $profile = $this->mainModel->get_profile_by_email($_POST['username']);
                                if (isset($profile->Id_0)) $id = $profile->Id_0;
                        } else {
                                $profile = $this->mainModel->get_profile_by_id($id);
                        }

                        if ($id != NULL) {
                                $password = $this->mainModel->get_new_password();
                                $encrypted = $this->mainModel->generate_hash($password);

                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                $data['Encryption_8'] = $encrypted;
                                $data['Statutdefaultpwd_31'] = 0;

                                $rid = $this->mainModel->save_profile($data, $id);

                                if ($this->lang == 'fr' && $rid) {
                                        $mid = $this->mail->mail_reset_password_by_admin($profile->Firstname_9, $profile->Identifier_7, $password, $this->lang);
                                        if ($mid):
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Mot de passe reinitialis&eacute;e avec succ&egrave;s!<br/>Nous vous avons envoy&eacute; le mot de passe temporaire par email.</p>';
                                        else:
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Mot de passe reinitialis&eacute;e avec succ&egrave;s, mais le mail n\'a pas pu être envoyé !<br/>Nous vous avons envoy&eacute; le mot de passe temporaire par email.</p>';
                                        endif;
                                } elseif ($this->lang != '' && $rid) {
                                        $mid = $this->mail->mail_reset_password_by_admin($profile->Firstname_9, $profile->Identifier_7, $password, $this->lang);
                                        if ($mid):
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Password changed successfully!<br/>We have sent you an email with your new password.</p>';
                                        else:
                                                echo '<br/><p class="text-center text-green"><i class="fa fa-fw fa-check-circle-o text-green mystyle4 text-center"></i><br/>Password changed successfully!<br/>We have sent you an email with your new password, but the email could not be sent!</p>';
                                        endif;
                                }
                        }
                }

                return true;
        }
        public function delete($obj = NULL, $id = NULL)
        {
                /**
                 * Site or branch/Group/User
                 * @Changing status to 0 to delete - can still be accessible for data related
                 */
                $data['Status_2'] = 0;
                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                $data['Changer_6'] = $this->session->userdata['user_id'];

                if ($obj == 'site') {
                        $assigned_user = $this->mainModel->check_site_user($id);

                        if ($assigned_user) {
                                $gid = $this->mainModel->save_site($data, $id);

                                if ($this->lang == 'fr' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Site supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } elseif ($this->lang != '' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Branch deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                if ($this->lang == 'fr') {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un site qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } else {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete this branch that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                } elseif ($obj == 'group') {
                        $assigned_user = $this->mainModel->check_group_user($id);

                        if ($assigned_user) {
                                $gid = $this->mainModel->save_group($data, $id);

                                if ($this->lang == 'fr' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Groupe supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } elseif ($this->lang != '' && $gid) {
                                        echo '<div class="alert alert-success alert-dismissible">Group deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        } else {
                                if ($this->lang == 'fr') {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un groupe qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } else {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete a group that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                } elseif ($obj == 'user') {
                        $gid = $this->mainModel->save_profile($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                } elseif ($obj == 'visitor') {
                        $gid = $this->mainModel->save_relation($data, $id);

                        if ($this->lang == 'fr' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } elseif ($this->lang != '' && $gid) {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }

                return true;
        }

        private function can_switch_guichet(): bool
        {
                return isset($_SESSION['Logiref_role']) && (int) $_SESSION['Logiref_role'] === 7;
        }

        private function get_authorized_guichet_by_id(int $guichet_id)
        {
                if ($guichet_id <= 0) {
                        return null;
                }

                $guichet = $this->branchModel->get_guichet_info($guichet_id);

                if (
                        empty($guichet) ||
                        (int) ($guichet->Status_2 ?? 0) !== 1 ||
                        (string) ($guichet->Account_3 ?? '') !== (string) $this->session->userdata['account_id']
                ) {
                        return null;
                }

                return $guichet;
        }

        private function get_connected_logiref_user()
        {
                $user_id = $this->session->userdata['user_id'] ?? 0;

                if (empty($user_id)) {
                        return null;
                }

                $logiref_user = $this->userModel->get_user_by_profile_id($user_id);

                if (empty($logiref_user) || empty($logiref_user->Id_0)) {
                        return null;
                }

                return $logiref_user;
        }

        private function update_connected_user_guichet($connected_user, $guichet): bool
        {
                $data = [
                        'Guichet_8' => $guichet->Id_0,
                        'Agence_7' => $guichet->Agence_5,
                ];

                return (bool) $this->userModel->save_users($data, $connected_user->Id_0);
        }

        private function refresh_connected_user_session(): void
        {
                $user_id = $this->session->userdata['user_id'] ?? 0;

                if (empty($user_id)) {
                        return;
                }

                $profile = $this->mainModel->get_profile_infos($user_id);

                if (empty($profile) || empty($profile->Id_0)) {
                        return;
                }

                $this->mainModel->init_sessions($profile);
                $this->logirefModel->get_privilegies();

                $userdata = $this->session->get('userdata');
                if (is_array($userdata)) {
                        $_SESSION['userdata'] = $userdata;
                }
        }

        private function clear_pending_guichet_switch(): void
        {
                $this->session->remove('pending_switch_guichet_id');
                $this->session->remove('pending_switch_guichet_label');
        }

}
