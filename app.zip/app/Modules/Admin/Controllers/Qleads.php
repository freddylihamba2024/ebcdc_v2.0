<?php 
namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\QleadCategoryModel;
use Modules\Admin\Models\QleadQueueModel;
use Modules\Admin\Models\QleadEquipmentModel;
use Modules\Admin\Models\QleadAdsModel;
use Modules\Admin\Models\QleadSurveyModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\QleadUsersModel;


class Qleads extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('dashboard','categories','queues','users', 'equipments', 'ads', 'localizations','surveys');

        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'qleads';
        public $group = 'banks';
        public $logirefModel;
        public $mainModal;
        public $categorieModal;
        public $queueModal;
        public $userModal;
        public $equipmentModal;
        public $adsModal;
        public $surveyModal;
        public $branchModel;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->mainModal = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->branchModel = new BranchModel();
                $this->categorieModal = new QleadCategoryModel();
                $this->queueModal = new QleadQueueModel();
                $this->userModal = new QleadUsersModel();
                $this->equipmentModal = new QleadEquipmentModel();
                $this->adsModal = new QleadAdsModel();
                $this->surveyModal = new QleadSurveyModel();

                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'qleads';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_qleads();
                
               
	} 
	
        
	public function index()
	{
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) 
                {
                        $this->data['sidebar'] = '';
                }
               
		$this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) 
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                
                if ($obj == "dashboard") 
                {
                        echo view('\Modules\Admin\Views\qleads\dashboard\dashboard', $this->data);
                }
                elseif($obj == "categories")
                {
                        $param = $id;
                        
                        $this->data['categories'] = $this->categorieModal->get_categories();
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['types'] = $this->categorieModal->types;
                        $this->data['category'] = $this->categorieModal->get_dropdown('category');
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('sub_categories');

                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\categories\_categories', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\categories\categories', $this->data);
                        endif;
                        
                }
                elseif($obj == "categories_filter")
                {
                        $this->data['categories'] = $this->categorieModal->get_subcategorie_by_categorie($id);
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['types'] = $this->categorieModal->types;
                        $this->data['category'] = $this->categorieModal->get_dropdown('category');
                        $this->data['categoryid'] = $id;

                        echo view('\Modules\Admin\Views\qleads\categories\_categories_filter', $this->data);
                }
                elseif($obj == "_categorie")
                {
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('category');
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['types'] = $this->categorieModal->types;
                        $this->data['categorie'] = $this->categorieModal->get_categorie_info($id);
                        echo view('\Modules\Admin\Views\qleads\categories\_categorie', $this->data);
                }
                elseif($obj == "queues")
                {
                        $param = $id;
                        
                        $this->data['queues'] = $this->queueModal->get_queues();
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['subcategory'] = $this->categorieModal->get_dropdown('categories');
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\queues\_queues', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\queues\queues', $this->data);
                        endif;

                }
                elseif($obj == "_queue")
                {
                        $queue = $this->queueModal->get_queue_info($id);
                        
                        $branchid = $queue->Branchid_7;
                        $type_queue = $queue->Vip_15;
                        
                        $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                        if (!empty($queues))
                        {
                                foreach ($queues as $row)
                                {
                                        if ($id != $row->Id_0):
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        endif;
                                }
                                
                                #Codes guichet 
                                $code = implode(',', $codes);
                                $teller_codes = explode(',', $code);

                                $tellers = $this->queueModal->tellers;

                                foreach ($teller_codes as $row):
                                        unset($tellers[$row]);
                                endforeach;

                                #Categories 
                                $categorie = implode(',', $categories);
                                $categories = explode(',', $categorie);

                                $sub_categories = $this->categorieModal->get_dropdown('categories');

                                foreach ($categories as $categorie):
                                        unset($sub_categories[$categorie]);
                                endforeach;

                        }
                        else
                        {
                                $tellers = $this->queueModal->tellers;
                                $sub_categories = $this->categorieModal->get_dropdown('categories');
                        }
                        
                        $this->data['tellers'] = $tellers;
                        $this->data['subcategory'] = $sub_categories;
                        $this->data['queue'] = $queue;
                        $this->data['type_queues'] = $this->queueModal->type_queues;
                        $this->data['sequences'] = $this->queueModal->sequences;
                        $this->data['guichets'] = $guichets =$this->branchModel->get_dropdown("guichets");
                        
                        echo view('\Modules\Admin\Views\qleads\queues\_queue', $this->data);
                }
                elseif($obj == "equipments")
                {
                        $param = $id;
                        $this->data['equipments'] = $this->equipmentModal->get_equipments();
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['queues'] = $this->queueModal->get_dropdown('queue');
                        $this->data['types'] = $this->equipmentModal->type_devices;
                        $this->data['users'] = $this->mainModal->get_dropdown('users_array');
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\equipments\_equipments', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\equipments\equipments', $this->data);
                        endif;

                }
                elseif($obj == "_equipment")
                {
                        $this->data['equipment'] = $this->equipmentModal->get_equipment_info($id);
                        $this->data['types'] = $this->equipmentModal->type_devices;
                        $this->data['queues'] = $this->queueModal->get_dropdown('queue');
                        
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");

                        echo view('\Modules\Admin\Views\qleads\equipments\_equipment', $this->data);
                }
                elseif($obj == "ads")
                {
                        $param = $id;
                        
                        $this->data['ads'] = $this->adsModal->get_ads();
                        $this->data['priorites'] = $this->adsModal->priorites;
                        $this->data['types'] = $this->adsModal->types;
                        $this->data['devices'] = $this->equipmentModal->get_dropdown("equipments");
                        $this->data['guichets'] = $guichets =  $this->branchModel->get_dropdown("guichets");
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\ads\_ads', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\ads\ads', $this->data);
                        endif;
                }         
                elseif($obj == "ad")
                {
                        $this->data['ad'] = $this->adsModal->get_ads_info($id);
                        $this->data['priorites'] = $this->adsModal->priorites;
                        $this->data['types'] = $this->adsModal->types;
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        $this->data['guichets'] =  $this->branchModel->get_dropdown("guichets");
                        
                        if (isset($id) && $id!=""):
                                $branchid = $this->data['ad']->Branchid_7;
                                $this->data['devices'] = $this->equipmentModal->get_dropdown("equipment_branch", $branchid);
                        endif;

                        echo view('\Modules\Admin\Views\qleads\ads\_ad', $this->data);
                        
                }
                elseif($obj == "localizations")
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_branches_by_localization();
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");
                        
                        echo view('\Modules\Admin\Views\qleads\branchs\localizations', $this->data);
                        
                }
                elseif($obj == "localization") 
                {
                        $localized_branches = $this->branchModel->get_branches_by_localization();
                        $guichet = $this->branchModel->get_guichet_info($id);
                        $guichets = $this->branchModel->get_dropdown('guichets','regions', $guichet->Region_14);

                        if (isset($id) && $id > 0):
                                foreach ($localized_branches as $row):
                                        if ($guichet->Id_0 != $row->Id_0):
                                            unset($guichets[$row->Id_0]);
                                        endif;
                                endforeach;
                        endif;
                    
                        $this->data['guichet'] = $guichet;
                        $this->data['guichets'] = $guichets;
                        $this->data['regions'] = $this->logirefModel->get_dropdown("regions");

                        echo view('\Modules\Admin\Views\qleads\branchs\_localization', $this->data);
                }
                elseif($obj == "surveys")
                {
                        $param = $id;
                        
                        $this->data['surveys'] = $this->surveyModal->get_survey();
                        $this->data['categories'] = $this->categorieModal->get_dropdown('sub_categories');
                                          
                        if (isset($param) && $param!=""):
                                echo view('\Modules\Admin\Views\qleads\survey\_surveys', $this->data);
                        else:
                                echo view('\Modules\Admin\Views\qleads\survey\surveys', $this->data);
                        endif;
                }  
                elseif($obj == "survey")
                {
                        $categories = $categorie= $this->categorieModal->get_dropdown('sub_categories');
                        $surveys = $this->surveyModal->get_survey();
                        $survey = $this->surveyModal->get_survey_info($id);
                        
                        foreach ($surveys as $row):
                                if (isset($categories[$row->Category_8])):
                                       unset($categories[$row->Category_8]);
                                endif;
                        endforeach;
                        
                        if ($id != "" && isset($categorie[$survey->Category_8])):
                                $categories[$survey->Category_8] = $categorie[$survey->Category_8];
                        endif;
                        
                        $this->data['survey'] = $survey;
                        $this->data['types'] = $this->surveyModal->types;
                        $this->data['categories'] = $categories;
                        $this->data['survey'] = $this->surveyModal->get_survey_info($id);
                       echo view('\Modules\Admin\Views\qleads\survey\_survey', $this->data);
                }
                elseif($obj== "verify_equipment_exist")
                {
                        $code_equipment = $_POST['code_device'];

                        $result = $this->equipmentModal->get_equipment_by_device($code_equipment);

                        if (!empty($result))
                        {
                                $return['device'] = TRUE;
                        }  
                        else
                        {
                                $return['device'] = FALSE;

                        }
                        
                        $return = json_encode($return);
                        
                        echo $return;
                        die;
                }
                elseif($obj == "users")
                {
                        
                        $this->data['habilitations'] = $this->userModal->get_users();
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['users'] = $this->mainModal->get_dropdown("profiles_array");
                        echo view('\Modules\Admin\Views\qleads\users\users', $this->data);
                }
                elseif($obj == "_user")
                {
                        echo view('\Modules\Admin\Views\qleads\users\_user', $this->data);
                }
                elseif($obj == 'dropdowns')
                {
                        $param = $id;
                        
                        if ($param == "queue")
                        {    
                                $codes = [];
                                $categories = [];
                                
                                $branchid = $_POST['branchid'];
                                $type_queue = $_POST['type_queue'];

                                $queues = $this->queueModal->get_type_queues_by_branch($branchid, $type_queue);
                                
                                if (!empty($queues))
                                {
                                        foreach ($queues as $row)
                                        {
                                                $codes[] = $row->Tellerslist_9;
                                                $categories[] = $row->Categorieslist_8;
                                        }

                                        //codes guichet 
                                        $code = implode(',', $codes);
                                        $teller_codes = explode(',', $code);

                                        $tellers = $this->queueModal->tellers;

                                        foreach ($teller_codes as $row)
                                        {
                                                unset($tellers[$row]);
                                        }
                                        
                                        //categories 
                                        $categorie = implode(',', $categories);
                                        $categories = explode(',', $categorie);

                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                        
                                        foreach ($categories as $categorie)
                                        {
                                                unset($sub_categories[$categorie]);
                                        }
                                       
                                }
                                else
                                {
                                        $tellers = $this->queueModal->tellers;
                                        $sub_categories = $this->categorieModal->get_dropdown('categories');
                                }   

                                $guichet_dropdown = form_dropdown('Tellerslist_9[]', $tellers, '', ' id="guichet"  class="select2_teller form-control"  multiple="multiple" id="select2" required="required"');
                                $categories_dropdown = form_dropdown('Categorieslist_8[]', $sub_categories, '', ' class="select2_category select2 form-control" multiple="multiple" id="categorie"  required="required"');

                                $result["guichets"] = $guichet_dropdown;
                                $result["categories"] = $categories_dropdown;

                                return json_encode($result);
                        }
                        elseif($arg == "equipment")
                        {
                                $queue_agences = $this->queueModal->get_dropdown('queue_agence', $id); 
                                $queues = !empty($queue_agences) ? $queue_agences : [];

                                echo form_dropdown('Queueid_11', $queues, '', ' id="guichet" class="form-control"  required="required"');
                        }
                        elseif($arg == "equipment_branch")
                        {
                                $equipment_branch = $this->equipmentModal->get_dropdown("equipment_branch", $id);
                                $equipments = !empty($equipment_branch) ? $equipment_branch : [];

                                echo form_dropdown('Device_9',$equipments, '' , ' id="device" class="form-control"  required="required"');
                        }
                        elseif($arg == "guichets")
                        {
                                $branches = $this->branchModel->get_branches_by_localization();
                                //$guichets = $this->branchModel->get_dropdown('guichets','force'); 
                                $guichets = $this->branchModel->get_dropdown('guichets','regions', $id); 

                                if (!empty($branches)):
                                        foreach ($branches as $row):
                                                if (isset($guichets[$row->Id_0])) unset($guichets[$row->Id_0]);
                                        endforeach;
                                endif;
                                
                                $guichets = !empty($guichets) ? $guichets : [];
                                
                                echo form_dropdown('Branchid', $guichets, "", ' class="form-control"  required="required"');
                        }

                            
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                }
                    
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $data = $_POST;
                if($obj == "categorie")
                {
                        if($data['Object_7']=='' || $data['Title_8']=='' || $data['Description_9']=='' || $data['Maxtime_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        #Database
                        $cid = $this->categorieModal->save_categorie($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! catégorie enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "queue")
                {
                        if($data['Branchid_7']=='' || $data['Categorieslist_8']=='' || $data['Tellerslist_9']=='' || $data['Sequence_10']=='' || $data['Opening_11']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        $data['Categorieslist_8'] = array_filter($data['Categorieslist_8']);
                        $data['Categorieslist_8'] = implode(",", $data['Categorieslist_8']);

                        $data['Tellerslist_9'] = array_filter($data['Tellerslist_9']);
                        $data['Tellerslist_9'] = implode(",", $data['Tellerslist_9']);
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                $data['Makerid_13']=$this->session->userdata['user_id'];

                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                $data['Checkerid_14']=$this->session->userdata['user_id'];

                        }
                        
                        #Database
                        $cid = $this->queueModal->save_queue($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! la file d\'attente est enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "equipment")
                {
                        if($data['Type_7']=='' || $data['Code_8']=='' || $data['Branchid_9']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];

                                $data['Makerid_12']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                $data['Checkerid_13']=$this->session->userdata['user_id'];

                        }
                        
                        #Database
                        $cid = $this->equipmentModal->save_equipment($data, $id);  
                        
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! l\'equipement est enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "ads")
                {

                        if($data['Type_10']=='' || $data['Branchid_7']=='' || $data['Device_9']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;
                        
                        #File attachment
                        if(isset($_FILES["Contentmedia"]["name"]) && $_FILES["Contentmedia"]["name"] !=""):

                                $account_id = $this->session->userdata['account_id'];
                                $ref = date('H').date('i').date('s').date('m').date('j').date('Y');
                                $target_dir = "./drive/qleads/".$account_id."/ads/".date('Y-m').'/'.$ref;

                                if(is_dir($target_dir)== false)
                                {
                                        mkdir($target_dir, 0777, true);
                                }

                                $target_file = $target_dir.basename($_FILES['Contentmedia']['name']);
                                $target_file = str_replace(" ", "", $target_file);

                                if(move_uploaded_file($_FILES['Contentmedia']["tmp_name"], $target_file)):
                                        $data['Content_11'] = $target_file;
                                endif;

                        elseif (isset($data['Contenttext']) && $data['Contenttext'] !=""):
                                $data['Content_11'] = $data['Contenttext'];
                        elseif (isset($data['ContentOnline']) && $data['ContentOnline']!=""):
                                $data['Content_11'] = $data['ContentOnline'];
                        endif;
                        
                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                                
                                if(isset($_FILES["Contentmedia"]["name"]) && $_FILES["Contentmedia"]["name"] !=""):
                                    
                                        $ad = $this->adsModal->get_ads_info($id);
                                        $file_name = $ad->Content_11;
                                        
                                        # Delete the old video 
                                        unlink(FCPATH . ''. $file_name);
                                endif;
                                
                                unset($data['File_name']);
                        }

                        unset($data['Contenttext']);
                        unset($data['ContentOnline']);

                        #Database
                        $cid = $this->adsModal->save_ads($data, $id);  
                        
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! les données sont enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "survey")
                {
                        if($data['Name_9']=='' || $data['Category_8']==''):
                                echo '<div class="alert alert-danger">Veuillez remplir tous les champs obligatoires svp <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;

                        $input = array();
                        $output = array();
                        
                        $input['Question'] = ($data["Question"]);
                        $input['Types'] = ($data["Types"]);
                        $input['Options'] = ($data["Values"]);
                        
                        foreach ($input["Question"] as $index => $question) 
                        {
                                $type = $input["Types"][$index];
                                $options = null;

                                # Check if options exist
                                if ($type == "select" || $type == "checkbox"):
                                        $options = explode(",", $input["Options"][$index]);
                                endif;

                                $output[] = array(
                                    "question" => $question,
                                    "types" => $type,
                                    "options" => $options
                                );
                        }
                        
                        $output = json_encode($output);
                        
                        $data['Form_7'] = $output;

                        if($id==NULL || $id == 0)
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6 '] = $this->session->userdata['user_id'];
                        }
                        
                        unset($data["Question"]);
                        unset($data["Types"]);
                        unset($data["Values"]);

                        #Database
                        $cid = $this->surveyModal->save_survey($data, $id);    
                        if($cid): 
                                echo '<div class="alert alert-success">Bravo! la file d\'attente est enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "localization")
                {
                        $data = $_POST;
                        $id = isset($data['Branchid']) && $data['Branchid'] !="" ? $data['Branchid'] : "";
                        
                        if($data['Region_14']=='' || $data['Branchid']=='' || $data['Latitude_15']==''  || $data['Longitude_16']==''):
                                echo '<div class="alert alert-danger text-white">Veuillez remplir tous les champs s\'il vous pla&icirc;t! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                                die;
                        endif;

                        #File attachment
                        if(isset($_FILES["Files_17"]["name"]) && $_FILES["Files_17"]["name"] !="")
                        {
                                $account_id = $this->session->userdata['account_id'];
                                $ref = date('H').date('i').date('s').date('m').date('j').date('Y');
                                $target_dir = "./drive/qleads/".$account_id."/branch/".date('Y-m').'/'.$ref;
                                
                                if(is_dir($target_dir)== false):
                                        mkdir($target_dir, 0777, true);
                                endif;
                                
                                $target_file = $target_dir.basename($_FILES['Files_17']['name']);
                                $target_file = str_replace(" ", "", $target_file);
                                
                                if(move_uploaded_file($_FILES['Files_17']["tmp_name"], $target_file)):
                                        $data['Files_17'] = $target_file;
                                endif;
                        }
                        
                        if ((isset($data['File_name']) && $data['File_name'] !="") || (isset($data['Files']) && $data['Files']!=""))
                        {
                                $data['Files_17'] = $data['Files'];
                                 
                                unset($data['Files']);
                                unset($data['File_name']);
                        }
                        
                        unset($data['Branchid']);
                        
                        #Database
                        $cid = $this->branchModel->save_branche($data, $id); 
                        
                        if($cid): 
                                echo '<div class="alert alert-success text-white">Bravo! demande enregistr&eacute;e avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: l\'enregistrement n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_categorie")
                {
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $cid = $this->categorieModal->delete_categorie($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Catégorie est supprim&eacute;e avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_queue")
                {
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $cid = $this->queueModal->delete_queue($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">File d\'attente est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_equipment")
                {
                        
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                        
                        $cid = $this->equipmentModal->delete_equipment($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">Equipement est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_ads")
                {
                        
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                        
                        $cid = $this->adsModal->delete_ads($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">L\'element est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "delete_survey")
                {
                        
                        $data['Status_2'] = 0;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                        
                        $cid = $this->surveyModal->save_survey($data, $id);  
                        
                        if($id): 
                                echo '<div class="alert alert-success text-white">L\'element est supprim&eacute; avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Errreur: la suppression n\'a pas abouti, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                
        }
        
        
        public function activate($obj = NULL, $id = NULL, $status = NULL)
        {
                /**
                 * User
                 * Changing status to 1
                 */
                if ($obj == 'equipement') 
                {
                        $data = array();
                        
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                     
                        #Database
                        $cid = $this->equipmentModal->save_equipment($data, $id);  

                        if ($this->lang == 'fr' && $cid): 
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        elseif ($this->lang != '' && $cid) :
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == 'categories') 
                {
                        $data = array();
                        
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                     
                        #Database
                        $cid = $this->categorieModal->save_categorie($data, $id);   

                        if ($this->lang == 'fr' && $cid): 
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        elseif ($this->lang != '' && $cid) :
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == 'queue') 
                {
                        $data = array();
                        
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                     
                        #Database
                        $cid = $this->queueModal->save_queue($data, $id);   

                        if ($this->lang == 'fr' && $cid): 
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        elseif ($this->lang != '' && $cid) :
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == 'ads') 
                {
                        $data = array();
                        
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                     
                        #Database
                        $cid = $this->adsModal->save_ads($data, $id);   

                        if ($this->lang == 'fr' && $cid): 
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        elseif ($this->lang != '' && $cid) :
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == 'survey') 
                {
                        $data = array();
                        
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];
                     
                        #Database
                        $cid = $this->surveyModal->save_survey($data, $id);   

                        if ($this->lang == 'fr' && $cid): 
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        elseif ($this->lang != '' && $cid) :
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                else 
                {
                    
                }
                return true;
        }
}

/* End of file   */
/* Location: /  */