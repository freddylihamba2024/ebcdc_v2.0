<?php
namespace Modules\Admin\Controllers;
use App\Controllers\BaseController;
use Modules\Admin\Models\BranchModel;
use Modules\Admin\Models\CaisseModel;
use Modules\Admin\Models\CashbookModel;
use Modules\Admin\Models\PartnersModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Main\Models\MainModel;

class Cashbooks extends BaseController {
        /*
         * Presentation: Gestion des comptes bancaires et autres comptes (prepaiements, ..)
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('cashbooks');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'cashbooks';
        public $role = '';

        public $logirefModel;
        public $branchModel;
        public $mainModel;
        public $caisseModel;
        public $partnerModel;
        public $cashbookModel;

        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModel = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->caisseModel = new CaisseModel();
                $this->branchModel = new BranchModel();
                $this->partnerModel = new PartnersModel();
                $this->cashbookModel = new CashbookModel();


                
                $this->data['module'] = $this->module;
                $this->data['application'] = 'cashbooks';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['sidebar'] = 'bank';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_etoll();
                
                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if(!isset($_SESSION['Logiref_privileges']))
                {
                        
                        $this->data("set_privilegies");
                }
                elseif(isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges']!="")
                {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                }
                elseif($this->session->userdata['user_type'] == "400")
                {
                        #$this->display('deny');
                }
                
                //Group - A garder si uniquement c'est necessaire !!
                if(isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role']))
                {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                }
                else
                {
                        redirect($this->module,'refresh');
                }
               
	} 
	
        
	public function index()
	{
                if($_SESSION['Logiref_role']==4)
                {
                        $this->data['sidebar'] = '';
                }
		$this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_main', $this->data);
	}
        
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if($_SESSION['Logiref_role']==4)
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj == "cashbook")
                {
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['cashbook'] = $this->cashbookModel->get_cashbook_info($id);
                        $this->data['from'] = $arg;
                        $this->data['beneficiaires'] = $this->partnerModel->get_dropdown('partners');
                        echo view('\Modules\Admin\Views\sbbos\cashbooks\_cashbook', $this->data);
                }
                elseif($obj == "cashbooks") 
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['provinces'] = $this->logirefModel->get_dropdown("parameter",'PROVINCE');
                        
                        $this->data['villes'] = $this->logirefModel->get_dropdown("parameter",'VILLE');
                        $this->data['guichet'] = $this->branchModel->get_guichet_info($id);
                        $this->data['from'] = $arg;
                        echo view('\Modules\Admin\Views\sbbos\counters\_guichet', $this->data);
                }
                elseif($obj == "caisses")
                {
                        $this->data['caisses'] = [];
                        echo view('\Modules\Admin\Views\sbbos\counters\caisses', $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        echo view('\Modules\Admin\Views\fr_denial', $this->data);
                }
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "cashbook")
                {
                        $data = $_POST;
                        
                        if($id =='0' || $id =='')
                        {
                                $data['Date_1']=gmdate('Y-m-d H:i:s');
                                $data['Status_2']=1;
                                $data['Account_3']=$this->session->userdata['account_id'];
                                $data['Creator_4']=$this->session->userdata['user_id'];
                                
                                $data['Quantity_14'] = $data['End_8'] - $data['Beginning_7'] + 1;
                        }
                        else
                        {
                                $data['Changes_5']=gmdate('Y-m-d H:i:s');
                                $data['Changer_6']=$this->session->userdata['user_id'];
                                
                                $data['Quantity_14'] = $data['End_8'] - $data['Beginning_7'] + 1 ;
                        }
                        
                        $cashbook =  $this->cashbookModel->save_cashbook($data, $id);    

                        if($cashbook): 
                                echo '<div class="alert alert-success text-white">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        else: 
                                echo '<div class="alert alert-danger text-white">Erreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; 
                        endif;
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        
        
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */