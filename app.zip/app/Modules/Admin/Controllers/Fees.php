<?php

namespace Modules\Admin\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\FeesModel;
use Modules\Admin\Models\BranchModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\StakeholderModel;

class Fees extends BaseController
{
        /*
         * Presentation: gestion des commissions et autres frais bancaires
         * Last update:
         * By Papin on the 25.12.2020
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('regles', '', '');
        public $roles = '5';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'fees';
        public $mainModal;
        public $logirefModel;
        public $feesModel;
        public $branchModel;
        public $stakeholderModel;
        public $role;
        public $options;
        public $functionalities;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->mainModal = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->feesModel = new FeesModel();
                $this->branchModel = new BranchModel();
                $this->stakeholderModel = new StakeholderModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'fees';
                $this->data['function'] = '';
                $this->data['role'] = $_SESSION['Logiref_role'];
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['documents'] = $this->logirefModel->documents;
                $this->data['devises'] = $this->logirefModel->devises;
                $this->data['modes'] = $this->logirefModel->modes;
                $this->data['moyens'] = $this->logirefModel->moyens;
                $this->data['infos'] = $this->logirefModel->infos;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['bank'] = $this->bank = $this->session->userdata["account_pageid"];
                $this->data['core_banking'] = $this->core_banking = $this->session->userdata["account_cbs"];
                $this->data['functionalities'] = $this->functionalities = json_decode($_SESSION['userdata']['options'], true);

                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['deny'] = false;
                
                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {   
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                
                # Retrieve options configured based on the bank connected
                if (isset($_SESSION['userdata']['options'])) 
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                } 
                else 
                {
                        $this->data['options'] = $this->options = array();
                }

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect($this->module, 'refresh');
                }
        }


        public function index()
        {
                if ($_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
        }


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        if ($_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }


        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "default") 
                {
                        $data = array();
                        
                        $data = $_POST;
                        
                        $ar = $this->data('get_commission', $data);
                    
                        echo json_encode($ar);
                } 
                if ($obj == "correspondent_fees") 
                {
                        $data = array();
                        
                        $data = $_POST;
                        $ar = $this->data('get_correspondent_fees', $data);

                        echo json_encode($ar);
                }
                elseif ($obj == "impression_fees") 
                {
                        $data = array();
                        
                        $data = $_POST;
                        $ar = $this->data('get_impression_fees', $data);

                        echo json_encode($ar);
                }
                elseif ($obj == "regles") 
                {
                        $this->data['agences'] = $this->branchModel->get_dropdown("agences");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets", NULL, "ALL");
                        $this->data['title'] = isset($id) ? 'hidden' : "";
                        $this->data['from'] = $id;
                        if ($_SESSION['Logiref_groupe'] == 'banks') {
                                $this->data['regles'] = $this->feesModel->get_regles("rgle");
                        } else {
                                #var_dump('tres'); die;
                                $this->data['regles'] = $this->feesModel->get_regles();
                        }
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);
                        
                        echo view('\Modules\Admin\Views\fees\regles', $this->data);
                } 
                elseif ($obj == "regle") 
                {
                        $this->data['beneficiaires'] = $this->stakeholderModel->get_dropdown("beneficiaries", "RGF");
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", NULL, NULL, true);

                        $this->data['from'] = $arg;
                        #var_dump($this->data['from']);die;

                        $this->data['recettes'] = $this->logirefModel->get_dropdown("recettes");
                        $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                        $this->data['types'] = $this->logirefModel->get_dropdown("types", "Regle");
                        $this->data['type_compte'] = $this->feesModel->type_compte;
                        $this->data['type_fees'] = $this->feesModel->type_fees;
                        $this->data['devises'] = $this->logirefModel->devises;
                        $this->data['priorite'] = $this->feesModel->priorites;
                        $this->data['regle'] = $this->feesModel->get_regle_info($id);
                        
                        echo view('\Modules\Admin\Views\fees\_regle', $this->data);
                } 
                elseif ($obj == "OBJ ") 
                {
                        
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }




        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "regle")
                {
                        $fields = array(
                                'Priorite_4' => 'priorite',
                                'Value_9' => 'value',
                                'Unite_10' => 'unite',
                                'Min_11' => 'min',
                                'Max_12' => 'max',
                                'Devise_13' => 'devise',
                        );

                        foreach ($fields as $field => $value)
                        {
                                $data[$field] = $this->request->getPost($value); //On assigne les valeurs de input aux champs de la DB
                        }

                        $data['Value_9'] = str_replace(' ', '', $data['Value_9']);
                        $data['Min_11'] = str_replace(' ', '', $data['Min_11']);
                        $data['Max_12'] = str_replace(' ', '', $data['Max_12']);

                        $data['Value_9'] = str_replace(' ,', '.', $data['Value_9']);
                        $data['Min_11'] = str_replace(',', '.', $data['Min_11']);
                        $data['Max_12'] = str_replace(',', '.', $data['Max_12']);
                        $data['Date_1'] = date('Y-m-d H:i:s');
                        $data['Status_2'] = '1';
                        $data['Account_3'] = $this->session->userdata['account_id'];

                        if (isset($this->options['ALL']['correspondent-bank-charges-for-dgrad-usd']))
                        {
                                if(isset($_POST['type'])) $data['Type_23'] = $_POST['type'];
                        }

                        $data['Service_6'] = (isset($_POST['service']) && $_POST['service'] != "") ? $this->request->getPost('service') : '';
                        $data['Guichet_8'] = (isset($_POST['guichet']) && $_POST['guichet'] != "") ? $this->request->getPost('guichet') : '';
                        $data['Recette_7'] = (isset($_POST['recette']) && $_POST['recette'] != "") ? $this->request->getPost('recette') : '';


                        if (isset($_POST['compte'])  && $_POST['compte'] != "")
                        {
                                $data['Compte_20'] = $_POST['compte'];
                        }
                        else
                        {
                                $data['Compte_20'] = "";
                        }

                        $data['Devise_21'] = (isset($_POST['compteDevise'])  && $_POST['compteDevise'] != "") ? $_POST['compteDevise'] : '';
                        $data['Mode_22'] = (isset($_POST['mode'])  && $_POST['mode'] != "") ? $_POST['mode'] : '';
                        $data['Type_23'] = (isset($_POST['type'])  && $_POST['type'] != "") ? $_POST['type'] : '';
                        $data['Beneficiaire_5'] = (isset($_POST['beneficiaire']) && $_POST['beneficiaire'] != "") ? $_POST['beneficiaire'] : '';

                        $data['Makerid_14'] = $this->session->userdata['user_id'];

                        if ($_SESSION['Logiref_role'] == 1) :
                                $data['Validation_16'] = '0000-00-00';
                                $data['Checkerid_15'] = 0;
                        else :
                                $data['Validation_16'] = gmdate('Y-m-d H:i:s');
                                $data['Checkerid_15'] = $this->session->userdata['user_id'];
                        endif;

                        $rid = $this->feesModel->save_regle($data, $id); // Enregistre les donnees dans la bd

                        if ($rid) :
                                echo '<div class="w-100 alert alert-success">Bravo! Informations enregistr&eacute;es avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        else :
                                echo '<div class="w-100 alert alert-danger">Errreur: veuillez renseigner des informations..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        endif;
                }
                elseif ($obj == "OBJ ")
                {

                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
        {
                if ($obj == "get_commission")
                {
                        $cdata = $data;

                        $montant1 = str_replace(' ', '', $cdata['montant']);

                        $montant2 = str_replace(',', '.', $montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];

                        $rules = $this->feesModel->get_bank_charges($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);

                        $rules_with_account = $this->feesModel->get_customer_charges($cdata['regie'],$cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['compte']);
                        $rules_with_mode = $this->feesModel->get_charges_by_paiement_method($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet'], $cdata['mode']);

                        if($rules_with_account['fees_found'] == true)
                        {
                                $rules = $rules_with_account;
                        }

                        if($rules_with_mode['fees_found'] == true)
                        {
                                $rules = $rules_with_mode;
                        }

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%')
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                $com['devise'] = $cdata['devise'];
                        }
                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }
                        if (!empty($com) && $com['com'] != 0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        }
                        else {
                                $cdata['commission'] = $cdata['montant'] * 0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        //                      //Montant total
                        if (isset($this->options['ALL']['client-exchange-rate-override']) && isset($cdata['taux']) && $cdata['taux'] !== "") 
                        {
                                $taux['Dollar_4'] = $cdata['taux'];
                        } 
                        else 
                        {
                                if (isset($_SESSION['Bank_rates'])) $taux = json_decode($_SESSION['Bank_rates'], true);
                                else $taux['Dollar_4'] = 1;
                        }

                        if ($cdata['devise'] == $oDeivise && $oDeivise == 'CDF')
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        }
                        else if ($cdata['devise'] == $oDeivise && $oDeivise == 'USD')
                        {
                                if($cdata['regie']=="DGI" && in_array($cdata['recette'],['IMMATRIC','CHANGEMENT','MUTATION','DUPLIC DEMI','DUPLIC','IMMATRIC PERS','CERTIF','CHANGEMENT AD']))
                                {
                                        $cdata['commission']=$rules['Valeur'];

                                        $commission=$rules['Valeur'];

                                        $cdata['devise']=$cdata['devise'];

                                        $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                                }
                                else
                                {
                                        # Convert amount to cdf to get the total in cdf
                                        $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                        # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                        $cdata['commission'] = $cdata['commission'];
                                        $cdata['devise'] = $cdata['devise'];

                                        $cdata['commission'] = $commission = $cdata['commission'] * $taux['Dollar_4'];
                                        $cdata['devise'] = 'CDF';

                                        $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);

                                }

                        }
                        else if ($cdata['devise'] == 'USD' && $oDeivise == 'CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $commission = $cdata['commission'] * $taux['Dollar_4'];
                                $cdata['devise'] = 'CDF';

                                $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                        }
                        else if ($cdata['devise'] == 'CDF' && $oDeivise == 'USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        }
                        else
                        {
                                $cdata['total'] = 0;
                        }

                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total'], $rules['fees_found']);

                        return $ar;
                        exit;

                }
                if ($obj == "get_correspondent_fees")
                {
                        $cdata = $data;
                        
                        $montant1 = str_replace(' ', '', $cdata['montant']);
                        
                        $montant2 = str_replace(',', '.', $montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];
                        
                        $rules = $this->feesModel->get_correspondent_fees($cdata['regie'], $cdata['service'], $cdata['recette'], $cdata['devise'], $cdata['montant'], $cdata['guichet']);
                        
                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                $com['devise'] = $cdata['devise'];
                        } 
                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }
                        if (!empty($com) && $com['com'] != 0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        } else {
                                $cdata['commission'] = $cdata['montant'] * 0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        //                      //Montant total
                        if (isset($_SESSION['Bank_rates'])) :
                                $taux = json_decode($_SESSION['Bank_rates'], true);
                        else :
                                $taux['Dollar_4']  = 1;
                        endif;

                        if ($cdata['devise'] == $oDeivise && $oDeivise == 'CDF') 
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        } 
                        else if ($cdata['devise'] == $oDeivise && $oDeivise == 'USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission'];
                                $cdata['devise'] = $cdata['devise'];

                                $commission = $cdata['commission'] * $taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                        } 
                        else if ($cdata['devise'] == 'USD' && $oDeivise == 'CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $commission = $cdata['commission'] * $taux['Dollar_4'];
                                $cdata['devise'] = 'CDF';

                                $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                                
                        } 
                        else if ($cdata['devise'] == 'CDF' && $oDeivise == 'USD') 
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        } 
                        else 
                        {
                                $cdata['total'] = 0;
                        }

                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total'], $rules['fees_found']);
                        return $ar;
                        exit;
                } 
                elseif ($obj == "get_impression_fees")
                {
                        $cdata = $data;
                        
                        $montant1 = str_replace(' ', '', $cdata['montant']);
                        
                        $montant2 = str_replace(',', '.', $montant1);
                        $cdata['montant'] = $montant2;
                        $oDeivise = $cdata['devise'];

                        $type =  $cdata['print_type'];

                        $rules = $this->feesModel->get_charges_for_printed_payment($type);

                        if ($rules['Valeur'] != 0 && $rules['Unite'] == '%') 
                        {
                                $com['com'] = ($cdata['montant'] * $rules['Valeur']) / 100;
                                $com['devise'] = $cdata['devise'];
                        } 
                        elseif ($rules['Valeur'] != '' && $rules['Unite'] != '') 
                        {
                                $com['com'] = $rules['Valeur'];
                                $com['devise'] = $rules['Unite'];
                        }

                        if (!empty($com) && $com['com'] != 0)
                        {
                                $cdata['commission'] = $com['com'];
                                $cdata['devise'] = $com['devise'];
                        } 
                        else 
                        {
                                $cdata['commission'] = $cdata['montant'] * 0;
                                $cdata['devise'] = $cdata['devise'];
                        }

                        if (isset($this->options['ALL']['client-exchange-rate-override']) && isset($cdata['taux']) && $cdata['taux'] !== "") 
                        {
                                $taux['Dollar_4'] = $cdata['taux'];
                        } 
                        else 
                        {
                                if (isset($_SESSION['Bank_rates'])) $taux = json_decode($_SESSION['Bank_rates'], true);
                                else $taux['Dollar_4'] = 1;
                        }

                        if ($cdata['devise'] == $oDeivise && $oDeivise == 'CDF') 
                        {
                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        } 
                        else if ($cdata['devise'] == $oDeivise && $oDeivise == 'USD')
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $cdata['commission'];
                                $cdata['devise'] = $cdata['devise'];

                                $commission = $cdata['commission'] * $taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                        } 
                        else if ($cdata['devise'] == 'USD' && $oDeivise == 'CDF')
                        {
                                # Convert commission to cdf. the commission has to be in cdf no matter what the case is.
                                $cdata['commission'] = $commission = $cdata['commission'] * $taux['Dollar_4'];
                                $cdata['devise'] = 'CDF';

                                $cdata['total'] = $cdata['montant'] + $commission + ($commission * 0.16);
                                
                        } 
                        else if ($cdata['devise'] == 'CDF' && $oDeivise == 'USD') 
                        {
                                # Convert amount to cdf to get the total in cdf
                                $cdata['montant'] = $cdata['montant'] * $taux['Dollar_4'];

                                $cdata['total'] = $cdata['montant'] + $cdata['commission'] + ($cdata['commission'] * 0.16);
                        } 
                        else 
                        {
                                $cdata['total'] = 0;
                        }

                        $ar = array($cdata['commission'], $cdata['devise'], $cdata['total']);
                        return $ar;
                        exit;
                } 
                elseif ($obj == "OBJ ") 
                {
                    
                } 
                elseif ($obj == "OBJ ") 
                {
                    
                }
        }
}
