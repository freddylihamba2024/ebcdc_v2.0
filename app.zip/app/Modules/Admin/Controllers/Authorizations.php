<?php 
namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use App\Libraries\ExternalAuthFactory;
use Modules\Admin\Models\AuthorizationsModel;
use Modules\Main\Models\MainModel;



class Authorizations extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By Glodi on the 14.10.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('dashboard','authorizations','functionnalities','logs_integrations', 'logs_operations');

        public $roles = ''; //Manager ou Directeur=5,Advisor ou teleconseiller=4,Supervisor==3,Checker==2, Maker==1 
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'authorizations';
        public $group = 'banks';
        public $logirefModel;
        public $authorizationsModel;
        public $mainModel;


        public function __construct()
	{
		parent::__construct();
                /*
                 * Module is branch
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */

                $this->authorizationsModel = new AuthorizationsModel();
                $this->mainModel = new MainModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'authorizations';
                $this->data['function'] = '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['usertype'] = $this->session->userdata["user_type"];
                $this->data['i'] = 0;

                $user_roles = $this->session->userdata['user_roles'];
                $this->data['sidebar'] = $this->sidebars->admin_auth();
	}


	public function index()
	{
                /*if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) 
                {
                        $this->data['sidebar'] = '';
                }*/

		$this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
	}


        /*
         * Manages sidebar menu
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) 
                        {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
	}


        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{

                if ($obj == "dashboard")
                {
                        echo view('\Modules\Admin\Views\monitoring\dashboard\dashboard', $this->data);
                }
                elseif($obj == "authorizations")
                {
                        $this->data['banques'] = $this->authorizationsModel->get_bank_account_with_authorizations();
                        $this->data['accounts'] = $this->authorizationsModel->get_dropdown('accounts');
                        $this->data['core_banking'] = $this->authorizationsModel->core_banking;
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Admin\Views\authorizations\authorizations', $this->data);
                }
                elseif($obj == "functionnalities")
                {
                        $this->data['functionnalities'] = $this->authorizationsModel->get_dropdown("functionnalities_of_bank");
                        $this->data['users'] = $this->mainModel->get_dropdown('users_array');

                        echo view('\Modules\Admin\Views\authorizations\functionnalities', $this->data);
                }
                elseif($obj == "authorization")
                {
                        $this->data['options'] = $this->authorizationsModel->get_dropdown('modules');
                        $this->data['accounts'] = $this->authorizationsModel->get_dropdown('accounts');
                        $this->data['modules'] = $this->authorizationsModel->get_dropdown('modules');
                        $this->data['banques'] = $this->authorizationsModel->get_dropdown('banques');
                        $this->data['functionnalities'] = $this->authorizationsModel->get_dropdown('functionnalities');
                        $this->data['regies_financieres'] = $this->authorizationsModel->get_dropdown('functionnalities_by_beneficiaries');
                        $this->data['auth'] = $this->authorizationsModel->get_authorization_info($id);
                        $this->data['ext_auth_config'] = ($id && isset($this->data['auth']->Bankid_7))
                                ? $this->authorizationsModel->get_ext_auth_config($this->data['auth']->Bankid_7)
                                : null;

                        echo view('\Modules\Admin\Views\authorizations\_authorization', $this->data);
                }
                elseif($obj == "functionnalitie")
                {
                        $this->data['functionnalitie'] = $this->authorizationsModel->get_option_info($id);
                        echo view('\Modules\Admin\Views\authorizations\_functionnalitie', $this->data);
                }
                elseif($obj == "logs_operations")
                {
                        echo view('\Modules\Admin\Views\authorizations\logs_operations', $this->data);
                }
                elseif ($obj == "logs_integrations")
                {
                        echo view('\Modules\Admin\Views\authorizations\logs_integrations', $this->data);
                }
	}



        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "authorization")
                {
                        $engine = \App\Libraries\BankDatabaseRouter::engine();
                        if (!in_array($engine, ['mysql', 'oracle'], true)) {
                                return $this->response->setStatusCode(422)->setBody('SGBD invalide.');
                        }
                        $postedFunctions = $this->request->getPost('functionnalities') ?? [];
                        if (!is_array($postedFunctions) || (isset($postedFunctions['ALL']) && !is_array($postedFunctions['ALL']))) {
                                return $this->response->setStatusCode(422)->setBody('Options invalides.');
                        }
                        $postedFunctions = \App\Libraries\OracleBankOptions::apply(
                                $engine, $postedFunctions, $this->authorizationsModel->get_oracle_options()
                        );
                        $_POST['functionnalities'] = $postedFunctions;
                        if($id == NULL)
                        {
                                $auth_exist = $this->authorizationsModel->get_authorisations_by_bankid($_POST['compte_utilisateur']);

                                if(isset($auth_exist->Id_0) && $auth_exist->Id_0 > 0)
                                {
                                        $msg = '<div class="w-100 alert alert-danger">D&eacute;sol&eacute; les habilitations existent d&eacute;j&agrave; pour la banque s&eacute;l&eacute;ctionn&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';

                                        echo $msg; die;
                                }
                                else
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];

                                        $data['Bankid_7'] = $_POST['compte_utilisateur'];
                                        if(isset($_POST['modules']) && $_POST['modules'] != '') $data['Modules_8'] = json_encode($_POST['modules']);
                                        if(isset($_POST['functionnalities']) && $_POST['functionnalities'] != '') $data['Functionnalities_9'] = json_encode($_POST['functionnalities']);
                                }
                        }
                        else
                        {
                                $functionnalities = array();

                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];

                                $data['Bankid_7'] = $_POST['compte_utilisateur'];

                                if(isset($_POST['modules']) && !empty($_POST['modules']))
                                {
                                        $data['Modules_8'] = json_encode($_POST['modules'], true);
                                }
                                else
                                {
                                        $data['Modules_8'] = '';
                                }

                                if(isset($_POST['functionnalities']) && !empty($_POST['functionnalities']))
                                {
                                        $data['Functionnalities_9'] = json_encode($_POST['functionnalities']);
                                }
                                else
                                {
                                        $data['Functionnalities_9'] = '';
                                }
                        }

                        $return = $this->authorizationsModel->save_auth($data, $id);

                        $bankid = (string) ($data['Bankid_7'] ?? '');

                        if ($bankid !== '') {
                                try {
                                        $this->authorizationsModel->save_ext_auth_config($bankid, [
                                                'enabled'                   => !empty($this->request->getPost('ext_auth_enable')),
                                                'driver'                    => trim((string) ($this->request->getPost('ext_auth_driver') ?? '')),
                                                'ldap_server'               => trim((string) ($this->request->getPost('ldap_server') ?? '')),
                                                'ldap_port'                 => trim((string) ($this->request->getPost('ldap_port') ?? '')),
                                                'ldap_basedn'               => trim((string) ($this->request->getPost('ldap_basedn') ?? '')),
                                                'ldap_username_format'      => trim((string) ($this->request->getPost('ldap_username_format') ?? 'upn')),
                                                'ldap_tls_cacert'           => trim((string) ($this->request->getPost('ldap_tls_cacert') ?? '')),
                                                'gateway_base_url'          => trim((string) ($this->request->getPost('gateway_base_url') ?? '')),
                                                'gateway_appid'             => trim((string) ($this->request->getPost('gateway_appid') ?? '')),
                                                'gateway_appkey'            => trim((string) ($this->request->getPost('gateway_appkey') ?? '')),
                                                'gateway_country_id'        => trim((string) ($this->request->getPost('gateway_country_id') ?? '')),
                                                'gateway_validate_endpoint' => trim((string) ($this->request->getPost('gateway_validate_endpoint') ?? '/api/v1/user/validate-user')),
                                                'gateway_userinfo_endpoint' => trim((string) ($this->request->getPost('gateway_userinfo_endpoint') ?? '/api/v1/user/get-user-details')),
                                                'gateway_timeout'           => trim((string) ($this->request->getPost('gateway_timeout') ?? '10')),
                                                'gateway_ssl_verify'        => !empty($this->request->getPost('gateway_ssl_verify')),
                                        ]);
                                } catch (\Throwable $e) {
                                        echo '<div class="w-100 alert alert-danger">' . htmlspecialchars($e->getMessage()) . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        return;
                                }
                        }

                        if($return > 0)
                        {
                                if($id > 0)
                                {
                                        $msg = '<div class="w-100 alert alert-success">Bravo! paramétrage modifi&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $msg = '<div class="w-100 alert alert-success">Bravo! paramétrage enregistré avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg = '<div class="w-100 alert alert-danger">Désolé! l\'enregistrement des paramétrages faits n\'a pas abouti, veuillez réessayer !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        echo $msg;
                }
                elseif($obj == "functionnalitie")
                {
                        $Id_0 = $this->request->getPost("Id_0");
                        $data["Object_7"] = $this->request->getPost("Object_7");
                        $data["Values_8"] = $this->request->getPost("Values_8");
                        $data["Beneficiaire_9"] = $this->request->getPost("Beneficiaire_9");
                        $data["Description_10"] = $this->request->getPost("Description_10");
                        if($Id_0 == ""){
                                $data["Date_1"] = gmdate("Y-m-d H:i:s");
                                $data["Status_2"] = 1;
                                $data["Creator_4"] = $this->session->userdata['user_id'];
                        }
                        else{
                                $data["Changes_5"] = gmdate("Y-m-d H:i:s");
                                $data["Changer_6"] = $this->session->userdata['user_id'];
                        }
                        $return = $this->authorizationsModel->save_option($data, $id);

                        if($return > 0)
                        {
                                if($id != "")
                                {
                                        $msg = '<div class="w-100 alert alert-success">Bravo! fonctionnalité modifi&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        $msg = '<div class="w-100 alert alert-success">Bravo! fonctionnalité enregistré avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg = '<div class="w-100 alert alert-danger">Désolé! l\'enregistrement de fonctionnalité n\'a pas abouti, veuillez réessayer !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }

                        echo $msg;
                }
                elseif ($obj == 'ext_auth_config')
                {
                        $bankid = (string) $id;
                        try {
                                $this->authorizationsModel->save_ext_auth_config($bankid, [
                                        'enabled'                   => !empty($this->request->getPost('ext_auth_enable')),
                                        'driver'                    => trim((string) ($this->request->getPost('ext_auth_driver') ?? '')),
                                        'ldap_server'               => trim((string) ($this->request->getPost('ldap_server') ?? '')),
                                        'ldap_port'                 => trim((string) ($this->request->getPost('ldap_port') ?? '')),
                                        'ldap_basedn'               => trim((string) ($this->request->getPost('ldap_basedn') ?? '')),
                                        'ldap_username_format'      => trim((string) ($this->request->getPost('ldap_username_format') ?? 'upn')),
                                        'ldap_tls_cacert'           => trim((string) ($this->request->getPost('ldap_tls_cacert') ?? '')),
                                        'gateway_base_url'          => trim((string) ($this->request->getPost('gateway_base_url') ?? '')),
                                        'gateway_appid'             => trim((string) ($this->request->getPost('gateway_appid') ?? '')),
                                        'gateway_appkey'            => trim((string) ($this->request->getPost('gateway_appkey') ?? '')),
                                        'gateway_country_id'        => trim((string) ($this->request->getPost('gateway_country_id') ?? '')),
                                        'gateway_validate_endpoint' => trim((string) ($this->request->getPost('gateway_validate_endpoint') ?? '/api/v1/user/validate-user')),
                                        'gateway_userinfo_endpoint' => trim((string) ($this->request->getPost('gateway_userinfo_endpoint') ?? '/api/v1/user/get-user-details')),
                                        'gateway_timeout'           => trim((string) ($this->request->getPost('gateway_timeout') ?? '10')),
                                        'gateway_ssl_verify'        => !empty($this->request->getPost('gateway_ssl_verify')),
                                ]);
                                echo '<div class="w-100 alert alert-success">Configuration d\'authentification externe enregistr&eacute;e.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        } catch (\Throwable $e) {
                                echo '<div class="w-100 alert alert-danger">' . htmlspecialchars($e->getMessage()) . '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
        }

        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if ($obj === 'test_ext_auth')
                {
                        $driver = strtolower(trim((string) ($this->request->getPost('ext_auth_driver') ?? '')));
                        $config = [
                                'driver'                    => $driver,
                                'ldap_server'               => trim((string) ($this->request->getPost('ldap_server') ?? '')),
                                'ldap_port'                 => (int) ($this->request->getPost('ldap_port') ?? 389),
                                'ldap_basedn'               => trim((string) ($this->request->getPost('ldap_basedn') ?? '')),
                                'ldap_username_format'      => trim((string) ($this->request->getPost('ldap_username_format') ?? 'upn')),
                                'ldap_tls_cacert'           => trim((string) ($this->request->getPost('ldap_tls_cacert') ?? '')),
                                'gateway_base_url'          => trim((string) ($this->request->getPost('gateway_base_url') ?? '')),
                                'gateway_appid'             => trim((string) ($this->request->getPost('gateway_appid') ?? '')),
                                'gateway_appkey'            => trim((string) ($this->request->getPost('gateway_appkey') ?? '')),
                                'gateway_country_id'        => trim((string) ($this->request->getPost('gateway_country_id') ?? '')),
                                'gateway_validate_endpoint' => trim((string) ($this->request->getPost('gateway_validate_endpoint') ?? '/api/v1/user/validate-user')),
                                'gateway_timeout'           => (int) ($this->request->getPost('gateway_timeout') ?? 10),
                                'gateway_ssl_verify'        => !empty($this->request->getPost('gateway_ssl_verify')),
                        ];

                        header('Content-Type: application/json');

                        try {
                                $provider = ExternalAuthFactory::create($driver, $config);
                                $ok = $provider->testConnection();

                                echo json_encode([
                                        'success' => $ok,
                                        'message' => $ok
                                                ? 'Connectivité validée.'
                                                : ('Échec du test: ' . ($provider->getLastError() ?? 'erreur inconnue')),
                                ]);
                        } catch (\Throwable $e) {
                                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
                        }
                        exit;
                }
        }
}

/* End of file   */
/* Location: /  */