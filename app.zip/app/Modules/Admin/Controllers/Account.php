<?php
namespace Modules\Admin\Controllers;

use Modules\Main\Models\MainModel;
use App\Controllers\BaseController;
use Modules\Admin\Models\ImageModel;
use Modules\Admin\Models\ManageModel;

class Account extends BaseController {
        /*
         * Presentation: 
         * Last update:
         * By:
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('profile','site','group','user','invitation','account','page','change','users', 'unblocking');
        public $roles = '';
        public $lang = 'fr';
        public $group = 'user';
        public $module = 'admin';
        public $folder = 'account';
        public $mainModal;
        public $manageModal;
        public $imageModel;

        public function __construct()
	{
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                */
                $this->mainModal = new MainModel();
                $this->manageModal = new ManageModel();

                $this->lang = 'fr';

                $this->data['module'] = 'admin';
                $this->data['application'] = 'account';
                $this->data['function'] = '';
                $this->data['sidebar'] = '';
                $this->data['layout_type'] = 'layout-top-nav';
                $this->data['lang'] = $this->lang;
                $this->data['deny'] = false;
                
                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {   
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }
                
                /**
                 * Check if the user was granted to this
                 * The administrateur has to activate/deactivate user
                 * $_SESSION['Grant_Education'] 
                */
                if($this->session->userdata['account_id']=='1')
                {
                        $this->group = 'main'; 
                }
                elseif($this->session->userdata['user_type']=='200')
                {
                        $this->group = 'admin'; 
                }
                else
                {
                        $this->group = 'user';
                }
                
                /*
                 * Profile picture or logo
                 * fileToUpload
                */
                if (isset($_FILES['fileToUpload']['name'])) 
                {
                        if ($_FILES['fileToUpload']['name'] != "") $this->imageModel = new ImageModel();
                }
	} 
	
        
        public function index()
	{
            	// add_meta_title('iKwook Project');
                // $this->data['subview'] = 'main/container';
                // $this->load->view('_layout_main', $this->data);
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
	}
        
        public function change()
	{
            	add_meta_title('iKwook Cloud');
                $this->data['subview'] = '\Modules\Admin\Views\container'; //'main/user/'.$this->lang.'/main';
                echo view('layouts/layout_admin', $this->data);
	}
        
        public function dashboard($schedule=NULL)
	{
            	add_meta_title('iKwook Project');
                $this->data['categories'] = $this->mainModal->account_categories[$this->lang];
                $this->data['countries'] = $this->mainModal->get_dropdown('country');
                $this->data['business'] = $this->session->userdata['user_business'];
                $this->data['members'] = array();
                $this->data['users'] = $this->mainModal->get_users();
                $this->data['groups'] = $this->mainModal->get_groups();
                $this->data['sites'] = $this->mainModal->get_sites();
                $this->data['visitors'] = $this->mainModal->get_users('','','','400');
                $this->data['status'] = $this->manageModal->status['fr'];
                $this->data['color'] = $this->manageModal->color_status;
                
                
                $dedicated_applications = $this->data['app_dedicated'] = $this->mainModal->standard_applications[$this->lang];
                $myapps = explode(',',$this->session->userdata['account_myapps']); 

                $module = '';
                foreach($dedicated_applications as $dashbord => $applications):
                    foreach($myapps as $app):
                        if(key_exists($app, $applications))
                        {
                                $module[$dashbord][$app] = $app;
                        }
                    endforeach;
                endforeach;
                $this->data['MyApps'] = $module;
                $this->data['dashboards'] = $this->mainModal->user_dashboard[$this->lang];
                $this->data['applications'] = $this->mainModal->ikwook_applications;
                
                if($this->session->userdata['account_category'] == 303)
                {
                        redirect('pay/hotleads/', 'refresh');
                }
                else
                {
                        $this->data['subview'] = 'main/'.$this->group.'/'.$this->lang.'/dashboard';
                }
                echo view('layouts/layout_admin', $this->data);
	}
        
        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * List: 
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
	{
                if(in_array($needle, $this->menus))
                {
                        $this->index();
                }
	}
        
        
        
        
        
        /*
         * Manages all the views
         * View calls are made here
         * List:
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
	{
                if($obj=='page')
                {
                        $this->data['account'] = $this->session->userdata['account_id'];
                        $this->data['page'] = $this->session->userdata['account_pageid'];
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                }
                elseif($obj=='sites')
                {
                        $this->data['sites'] = $this->mainModal->get_sites();
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/'.$obj, $this->data);
                }
                elseif($obj=='site')
                {
                        if($id=='pager')
                        {
                                $this->data['site'] = $this->mainModal->get_site_infos();
                                $this->data['id'] = $id;
                                echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                                // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        }
                        else 
                        {
                                $this->data['site'] = $this->mainModal->get_site_infos($id);
                                $this->data['id'] = $id;
                                echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                                // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        }
                }
                elseif($obj=='groups')
                {
                        $this->data['groups'] = $this->mainModal->get_groups();
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/'.$obj, $this->data);
                }
                elseif($obj=='group')
                {
                        if($id=='pager')
                        {
                                $this->data['group'] = $this->mainModal->get_group_infos();
                                $this->data['id'] = $id;
                                echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                                // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        }
                        else 
                        {
                                $this->data['group'] = $this->mainModal->get_group_infos($id);
                                $this->data['id'] = $id;
                                echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                                // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        }
                }
                elseif($obj=='find')
                {
                        $email = $_POST['visitor'];
                        $profile = $this->mainModal->get_profile_by_email($email);
                        if(isset($profile->Id_0) && $profile->Id_0>0)
                        {
                                echo $profile->Id_0;
                        }    
                        else
                        {
                                echo 0;
                        }
                }
                elseif($obj=='invite')
                {
                        $email = $_POST['visitor'];
                        //$email = $this->send_mail();
                        if(isset($email) && $email != FALSE)
                        {
                                echo 1; //Email sent successfully
                        }    
                        else
                        {
                                echo 0; //Email not sent successfully
                        }
                }
                elseif($obj=='visitors')
                {
                        $this->data['users'] = $this->mainModal->get_users('','','','400');
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/'.$obj, $this->data);
                }
                elseif($obj=='visitor')
                {
                        if($id=='pager')
                        {
                                $this->data['dashboard'] = $this->mainModal->user_dashboard[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModal->get_profile_infos();
                                $this->data['relation'] = $this->mainModal->get_relation_infos();
                        }
                        else 
                        {
                                $this->data['dashboard'] = $this->mainModal->user_dashboard[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModal->get_profile_infos($id);
                                $this->data['relation'] = $this->mainModal->get_relation_infos($id);
                        }
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                }
                elseif($obj=='invitation')
                {
                        $this->data['dashboard'] = $this->mainModal->user_dashboard[$this->lang];
                        $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                        $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                        $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                        $this->data['relation'] = $this->mainModal->get_relation_infos($id);
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                }
                elseif($obj=='users')
                {
                        $this->data['users'] = $this->mainModal->get_users();
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/'.$obj, $this->data);
                }
                elseif($obj=='user')
                {
                        $myapps = $this->session->userdata['account_myapps'];
                        $myrestrict = $this->session->userdata['account_restrict'];
                        
                        
                        
                        $dedicated_applications = $this->data['app_dedicated'] = $this->mainModal->standard_applications[$this->lang];

                        $myapps = explode(',', $myapps);
                        $myrestrict = explode(',', $myrestrict);
                        
                        $myapps = array_merge($myapps, $myrestrict);
                        
                        
                        if($id !='pager') $relation = $this->mainModal->get_relation_infos($id);
                        
                        $apps = '';
                        
                        if(isset($relation->Applications_14))
                        {
                                $apps = $relation->Applications_14;
                        }
                        
                        if($id !="" && $id!='pager' && $apps !="")
                        {
                                    $relation = $this->mainModal->get_relation_infos($id);
                                    
                                    $myapps = explode(',', $apps);
                        }
                        
                        $dmenu = array();
                        $i=0;
                        
                        foreach($dedicated_applications as $dashboard => $applications):
                            foreach($myapps as $app):
                                if(key_exists($app, $applications))
                                {
                                        if($i==0)
                                        {
                                                $dmenu[''][''] = '';
                                        }
                                        $dmenu[$dashboard][$app] = $app;
                                        $i++;
                                }
                            endforeach;
                        endforeach;
                        
                        
                        if($id=='pager')
                        {
                                $this->data['dedicated_applications'] = $this->mainModal->standard_applications[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModal->get_profile_infos();
                                $this->data['relation'] = $this->mainModal->get_relation_infos();
                                
                        }
                        else 
                        {
                                $this->data['dedicated_applications'] = $this->mainModal->standard_applications[$this->lang];
                                $this->data['id'] = $id;
                                $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                                $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                                $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                                $this->data['profile'] = $this->mainModal->get_profile_infos($id);
                                $this->data['relation'] = $this->mainModal->get_relation_infos($id);
                        }
                        
                        $this->data['dashboards'] = $this->mainModal->user_dashboard[$this->lang];
                        $this->data['applications'] = $dmenu;
                        
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                        
                }
                elseif($obj=='account')
                {
                        $account_id = $this->session->userdata['account_id'];
                        $this->data['dashboards'] = $this->mainModal->user_dashboard[$this->lang];
                        $this->data['account'] = $this->mainModal->get_account_infos($account_id);
                        $this->data['countries'] = $this->mainModal->get_dropdown("country");
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                }
                elseif($obj=='profile')
                {
                        $dedicated_applications = $this->data['app_dedicated'] = $this->mainModal->standard_applications[$this->lang];
                       
                        $dmenu = array();
 
                        if($this->session->userdata['user_type']=='200')
                        {
                                
                                $myapps = $this->session->userdata['account_myapps'];
                                $myapps = explode(',', $myapps);
                                
                                foreach($dedicated_applications as $dashboard => $applications):
                                    foreach($myapps as $app):
                                        if(key_exists($app, $applications))
                                        {
                                                $dmenu[$dashboard][] = $app;
                                        }
                                    endforeach;
                                endforeach;

                        }
                        elseif($this->session->userdata['user_type']=='300')
                        {
                                $myapps = $this->session->userdata['user_apps'];
                                $myapps = explode(',', $myapps);
                                $i=0;
                                
                                foreach($dedicated_applications as $dashboard => $applications):
                                    foreach($myapps as $app):
                                        if(key_exists($app, $applications))
                                        {
                                                if($i==0)
                                                {
                                                        $dmenu[''][''] = '';
                                                }
                                                $dmenu[$dashboard][$app] = $app;
                                                $i++;
                                        }
                                    endforeach;
                                endforeach;
                        }

                        
                        if(empty($dmenu))
                        {
                                $applications = $this->mainModal->standard_applications[$this->lang];
                        }
                        $profile_id = $this->session->userdata['user_id'];
                        $this->data['applications'] = $dmenu;
                        $this->data['dmenu'] = !empty($dmenu) ? $dmenu : $applications;
                        $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                        $this->data['dashboards'] = $this->mainModal->user_dashboard[$this->lang];
                        $this->data['groups'] = $this->mainModal->get_dropdown('groups');
                        $this->data['sites'] = $this->mainModal->get_dropdown('sites');
                        $this->data['profile'] = $this->mainModal->get_profile_infos($profile_id);
                        $this->data['relation'] = $this->mainModal->get_relation_infos($profile_id);
                        
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/'.$obj, $this->data);
                }
                elseif($obj=='change')
                {
                        $this->data['accounts'] = $this->mainModal->get_all_accounts();
                        $this->data['roles'] = $this->mainModal->user_role[$this->lang];
                        $this->data['boxed'] = 'layout-boxed';
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_'.$obj, $this->data);
                        // $this->load->view('admin/'.$this->lang.'/_'.$obj, $this->data);
                }
                elseif($obj == "unblocking")
                {
                        $_SESSION['location'] = $obj;
                        $this->data['title'] = "Les comptes  bloqu&eacutes";
                        $this->data['inactifs'] = $this->manageModal->get_profil_by_status("inactive");
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        //$this->load->view($this->module.'/'.$this->group.'/'.$this->folder.'/unblocking', $this->data);
                }
                #Dashboard
                elseif($obj == "dashboard") 
                {
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\'.$obj, $this->data);
                        // $this->load->view('finance/budget/'. $this->lang. '/'.$obj, $this->data);
                }
                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
                return true;
	}
        
        
        
        
        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * List:
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj=NULL, $id=NULL, $arg=NULL, $param=NULL)
        {
                $msg = array('en'=>'','fr'=>'');
		/**
                 * Site or branch/Group/User
                 * @save new record and updating existing onces if @ID is not NULL
                */
                if($obj=='site')
                {
                        if(isset($_POST['Name_7']) && $_POST['Name_7']!="" && isset($_POST['Description_8']))
                        {
                                if($id==NULL)
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                }
                                else
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                $data['Name_7'] = $_POST['Name_7'];
                                $data['Description_8'] = $_POST['Description_8'];
                                
                                $sid = $this->mainModal->save_site($data, $id);
                                
                                if($sid)
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Branche saved successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        
                        echo $msg[$this->lang];
                }
                elseif($obj=='group')
                {
                        if(isset($_POST['Name_7']) && $_POST['Name_7']!="" && isset($_POST['Description_8']))
                        {
                                if($id==NULL)
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                }
                                else
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                $data['Name_7'] = $_POST['Name_7'];
                                $data['Description_8'] = $_POST['Description_8'];
                                
                                $sid = $this->mainModal->save_group($data, $id);
                                
                                if($sid)
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Group saved successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        
                        echo $msg[$this->lang];
                }
                elseif($obj=='user')
                {
                        $validate = FALSE;
                        
                        if($id==NULL && isset($_POST['Cellphone_12']) && $_POST['Cellphone_12']!="" && isset($_POST['Email_13']) && $_POST['Email_13']!="")
                        {
                                $password = $this->mainModal->get_new_password();
                                
                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                $data['Status_2'] = 1;
                                $data['Account_3'] = $this->session->userdata['account_id'];
                                $data['Creator_4'] = $this->session->userdata['user_id'];
                                $data['Identifier_7'] = $username = $this->request->getPost('Email_13');
                                $data['Encryption_8'] = $this->mainModal->generate_hash($password);
                                $data['Cellphone_12'] = $this->request->getPost('Cellphone_12');
                                $data['Email_13'] = $this->request->getPost('Email_13');
                                $validate = TRUE;
                        }
                        else
                        {
                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                $validate = TRUE;
                        }
                        
                        if($validate === TRUE)
                        {
                                //Profile Data 
                                $fields = array(
                                        'Firstname_9' => 'Firstname_9',
                                        'Lastname_10' => 'Lastname_10',
                                        'Middlename_11' => 'Middlename_11',
                                        'Language_14' => 'Language_14',
                                        'Lastname_10' => 'Lastname_10',
                                        'Birthday_17' => 'Birthday_17',
                                        'Position_18' => 'Position_18',
                                        'Gender_15' => 'Gender_15'
                                );

                                foreach ($fields as $field => $value)
                                {
                                        $data[$field] = $this->request->getPost($value);
                                }
                                
                                //Upload image
                                if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) 
                                {
                                        // array of valid extensions
                                        $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                        // get extension of the uploaded file
                                        $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
                                        // check if file Extension is on the list of allowed ones
                                        if (in_array($fileExtension, $validExtensions))
                                        {
                                                $newNamePrefix = time() . '_';
                                                // resizing to 200x200
                                                $newImage = $this->imageModel->resample(200, 200);
                                                // saving file to uploads folder
                                                $target_file = "./ikwook_files/profiles/" . $newNamePrefix . $_FILES['fileToUpload']['name'];
                                                $this->imageModel->saveImage($target_file);
                                                $data['Profile_16'] = $target_file;
                                                $_SESSION['user_profile'] =  $target_file;
                                        } 
                                        else
                                        {
                                                $uploadError = true;
                                        }
                                }
                                
                                #Saving
                                $user_id = $this->mainModal->save_profile($data, $id);
                                
                                if($user_id)
                                {
                                        //Relation Data 
                                        $data = array();
                                        $relation_id = $this->request->getPost('relation_id');

                                        if($relation_id=="")
                                        {
                                                $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                                $data['Status_2'] = 1;
                                                $data['Account_3'] = $this->session->userdata['account_id'];
                                                $data['Creator_4'] = $this->session->userdata['user_id'];
                                                $data['User_7'] = $user_id;
                                                $relation_id = NULL;
                                        }
                                        else
                                        {
                                                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                                $data['Changer_6'] = $this->session->userdata['user_id'];
                                        }
                                        if(isset($_POST['application']) && $_POST['application'])
                                        {
                                                $application = implode(',', $_POST['application']);
                                                $data['Applications_14']= $application;
                                        }
                                        $fields = array(
                                                'Branch_9' => 'Branch_9',
                                                'Group_8' => 'Group_8',
                                                'Type_10' => 'Type_10',
                                                
                                        );

                                        foreach ($fields as $field => $value)
                                        {
                                                $data[$field] = $this->request->getPost($value);
                                        }

                                        $rid = $this->mainModal->save_relation($data, $relation_id);
                                        
                                        if(isset($_POST['Module_11']) && $_POST['Module_11']!='')
                                        {
                                                $data['Module_11'] = $_POST['Module_11'];
                                        }
                                        
                                        //Confirmation mail
                                        if($id==NULL )
                                        {
                                                $this->mail->mail_profile_confirmation($_POST['Firstname_9'], $username, $password, $this->session->userdata['user_fname']);
                                        }
                                }

                                if (isset($uploadError)) 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de t&eacute;l&eacute;chargement</strong> Les extensions acceptable sont JPG, JPEG, GIF ou PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif ($user_id) 
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Bien!....enregistr&eacute;s avec succ&egrave;s.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Great!...saved successfully.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                } 
                                else 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">ERROR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">ERREUR: U1200..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications non enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        
                        echo $msg[$this->lang];
                }
                elseif($obj == "visitor")            
                {
                        if(isset($_POST['User_7']) && $_POST['User_7']>0 && $_POST['Branch_9']!="" && $_POST['Group_8']!="" && $_POST['Type_10']!="")
                        {
                                if($id==NULL)
                                {
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Status_2'] = 1;
                                        $data['Account_3'] = $this->session->userdata['account_id'];
                                        $data['Creator_4'] = $this->session->userdata['user_id'];
                                }
                                else
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                }
                                
                                $fields = array(
                                        'Branch_9' => 'Branch_9',
                                        'Group_8' => 'Group_8',
                                        'Type_10' => 'Type_10',
                                        'Module_11' => 'Module_11',
                                        'User_7' => 'User_7'
                                );

                                foreach ($fields as $field => $value)
                                {
                                        $data[$field] = $this->request->getPost($value);
                                }

                                $rid = $this->mainModal->save_relation($data, $id);
                                
                                if($rid && $id==NULL)
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Informations enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Invitation sent successfully<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($id>0 && $rid)
                                {
                                        $msg['fr'] = '<div class="alert alert-success alert-dismissible">Modifications enregistr&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-success alert-dismissible">Changes saved successfully<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Avertissement! Modifications pas enregistr&eacute;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Warning! Changes could not be saved..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        
                        echo $msg[$this->lang];
                }
                elseif($obj == 'account')
                {
                        $fields = array(
                                'Business_7'    => 'Business_7',
                                'Email_16'      => 'Email_16',
                                'Telephone_15'  => 'Telephone_15',
                                'Address_21'    => 'Address_21',
                                'Address_22'    => 'Address_22',
                                'City_20'       => 'City_20',
                                'State_19'      => 'State_19',
                                'City_20'       => 'City_20',
                                'Country_12'    => 'Country_12',
                                'Postal_23'     => 'Postal_23',
                                'Website_18'    => 'Website_18',
                                'Currency_13'   => 'Currency_13',
                                'Description_9' => 'Description_9',
                                'Dashboard_14'  => 'Dashboard_14',
                                'Pageid_24'     => 'Pageid_24'
                        );
                        
                        foreach ($fields as $field => $value)
                        {
                                $data[$field] = $this->request->getPost($value);
                        }
                        
                        //Validation
                        if (count($data)) 
                        {
                                if ($data['Currency_13'] != "" && $data['Country_12'] != "") 
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];
                                        
                                        //var_dump($_FILES['fileToUpload']); die;

                                        //Upload image
                                        if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) 
                                        {
                                                #Root director
                                                $fileprefix = date('Ymdhs') . "_";
                                                $filename = "./ikwook_files/logos/" . $this->session->userdata['account_id'] . '/' . $fileprefix . $_FILES['fileToUpload']['name'];
                                                #array of valid extensions
                                                $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                                #get extension of the uploaded file
                                                $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
                                                #check if file Extension is on the list of allowed ones
                                                if (in_array($fileExtension, $validExtensions)) 
                                                {
                                                    # Save
                                                    #resizing to 200x200  saving file to uploads folder
                                                    $newImage = $this->imageModel->resample(200, 200, false);
                                                    $this->imageModel->saveImage($filename);
                                                    #Db
                                                    $data['Logo_17'] = $filename;
                                                    $_SESSION['account_logo'] = $filename;
                                                } 
                                                else if ($fileExtension != "") 
                                                {
                                                    $uploadError = true;
                                                }
                                        }

                                        #Saving
                                        $pid = $this->session->userdata['account_id'];
                                        $success = $this->mainModal->save_account($data, $pid);

                                        if (isset($uploadError)) 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de t&eacute;l&eacute;chargement d\'image !</strong> Extensions exig&eacute;e:  JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif (isset($arg) && $success && $arg=='complete') 
                                        {
                                                if(isset($_POST['Country_12']) && $_POST['Country_12'] !="") $_SESSION['account_country'] = $_POST['Country_12'];
                                                
                                                $settings = $this->mainModal->get_dashboard();
                                                $dashboard = $settings['dashboard'];
                                                if(!isset($_SESSION['dashboard'])) $_SESSION['dashboard'] = $dashboard;
                                                
                                                echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_complete3', $this->data);
                                                // $this->load->view('main/user/'.$this->lang.'/_complete3', $this->data);
                                        } 
                                        elseif ($success)  
                                        {
                                                //$_SESSION['user_lang'] = $this->mainModal->languages[$data['Language_14']];
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Information enregistrees avec succes!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Changes saved successfully!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">An error has occurred, please check again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Erreur 303A, veuillez reessayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } 
                                else 
                                {
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                
                                //New account
                                if(isset($arg) && $arg=='complete' && isset($msg[$this->lang]))
                                {
                                        $this->data['msg'] = $msg[$this->lang];
                                }
                                elseif(isset($msg[$this->lang]))
                                {
                                        echo $msg[$this->lang];
                                }
                        }
                }
                elseif($obj == 'profile')
                {
                        $account_id = $this->session->userdata['account_id'];
                        $user_id = $this->session->userdata['user_id'];
                        
                        $msg['fr'] = "";
                        
                        $fields = array(
                                'Firstname_9' => 'Firstname_9',
                                'Middlename_11' => 'Middlename_11',
                                'Cellphone_12' => 'Cellphone_12',
                                'Language_14' => 'Language_14',
                                'Lastname_10' => 'Lastname_10',
                                'Birthday_17' => 'Birthday_17',
                                'Position_18' => 'Position_18',
                                'Email_13' => 'Email_13',
                                'Gender_15' => 'Gender_15'
                        );
                        
                        foreach ($fields as $field => $value)
                        {
                                $data[$field] = $this->request->getPost($value);
                        }
                        
                        $password = strval($this->request->getPost('password3'));

                        if( strlen($password) < 8 ) 
                        {
                                $msg['fr'] = "Password too short!";
                        }

                        elseif( strlen($password) > 20 ) 
                        {
                                $msg['fr'] = "Password too long!";
                        }

                        elseif( strlen($password) < 8 ) {
                                $msg['fr'] = "Password too short!";
                        }

                        elseif( !preg_match("#[0-9]+#", $password) ) 
                        {
                                $msg['fr'] = "Password must include at least one number !";
                        }

                        elseif( !preg_match("#[a-z]+#", $password) ) 
                        {
                                $msg['fr'] = "Password must include at least one letter !";
                        }

                        elseif( !preg_match("#[A-Z]+#", $password) ) 
                        {
                                $msg['fr'] = "Password must include at least one CAPS !";
                        }

                        elseif( !preg_match("#\W+#", $password) ) 
                        {
                                $msg['fr'] = "Password must include at least one symbol !";
                        }
                        
                        if($msg['fr'] != "")
                        {
                                $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">"'.$msg['fr'].'"<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        
                        if($msg['fr'] == "")
                        {
                                if(isset($_POST['password1']) && $_POST['password1'] !="" && isset($_POST['password3']) && $_POST['password3'] !="")
                                {
                                        $user_info = $this->mainModal->get_profile_infos($user_id);

                                        $matches = $this->mainModal->verify($_POST['password1'], $user_info->Encryption_8);
                                        if($matches)
                                        {
                                                if(!isset($_POST['password2']) || $_POST['password2'] != $_POST['password1'])
                                                {
                                                        $error_password_confirm1 = true;
                                                }
                                                if(isset($_POST['password4']) && $_POST['password4'] == $_POST['password3'])
                                                {
                                                        $new_password = $this->mainModal->generate_hash($_POST['password3']);
                                                        $data['Encryption_8']= $new_password;
                                                }
                                                else
                                                {
                                                        $error_password_confirm2 = true;
                                                }
                                        }
                                        else
                                        {
                                                $error_password = true;
                                        }
                                }
                        }
                        //Validation
                        if(count($data) && $msg['fr'] == "") 
                        {
                                if ($data['Language_14'] != "") 
                                {
                                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                                        $data['Changer_6'] = $this->session->userdata['user_id'];

                                        //Upload image
                                        if (isset($_FILES['fileToUpload']) && !$_FILES['fileToUpload']['error']) 
                                        {
                                                // array of valid extensions
                                                $validExtensions = array('.jpg', '.jpeg', '.gif', '.png', '.JPG', '.JPEG', '.GIF', '.PNG');
                                                // get extension of the uploaded file
                                                $fileExtension = strrchr($_FILES['fileToUpload']['name'], ".");
                                                // check if file Extension is on the list of allowed ones
                                                if (in_array($fileExtension, $validExtensions)) 
                                                {
                                                        $newNamePrefix = time() . '_';
                                                        // resizing to 200x200
                                                        $newImage = $this->imageModel->resample(200, 200);
                                                        // saving file to uploads folder
                                                        $target_file = "./ikwook_files/profiles/" . $newNamePrefix . $_FILES['fileToUpload']['name'];
                                                        $this->imageModel->saveImage($target_file);
                                                        $data['Profile_16'] = $target_file;
                                                        $_SESSION['user_profile'] =  $target_file;
                                                } 
                                                else
                                                {
                                                        $uploadError = true;
                                                }
                                        }

                                        #Saving
                                        $pid = $this->session->userdata['user_id'];
                                        $success = $this->mainModal->save_profile($data, $pid);
                                        
                                        if($success > 0 && isset($_POST['relation_id']))
                                        {
                                                if(isset($_POST['Module_11'])) $data_relation['Module_11'] = $_POST['Module_11']; else $data_relation['Module_11'] = 'Pay';
                                                $relation_id = $_POST['relation_id'];
                                                $this->mainModal->save_relation($data_relation, $relation_id);
                                        }

                                        if (isset($uploadError)) 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Error uploading image !</strong> Extension must one of JPG, JPEG, GIF or PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible" role="alert"><strong>Erreur de telechargement d\'image !</strong> Les extensions acceptable sont JPG, JPEG, GIF ou PNG.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif (isset($error_password)) 
                                        {
                                                $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The password entered does not match the current password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le mot de passe entr&eacute; ne correspond pas au mot de passe actuel, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif (isset($error_password_confirm1)) 
                                        {
                                                $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The current password entered does not match the confirmed password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le mot de passe actuel entr&eacute; ne correspond pas au mot de passe confirm&eacute;, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif (isset($error_password_confirm2)) 
                                        {
                                                $msg['en'] = '<div class="alert alert-warning alert-dismissible" role="alert">The new password entered does not match the confirmed password, Please try again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-warning alert-dismissible" role="alert">Le nouveau mot de passe entr&eacute; ne correspond pas au mot de passe confirm&eacute;, veuillez r&eacute;ssayer s\'il vous plait!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        elseif ($success && isset($arg) && $arg=='complete') 
                                        {
                                                $_SESSION['user_lang'] = $this->mainModal->languages[$data['Language_14']];
                                                $this->data['account'] = $this->mainModal->get_account_infos($this->session->userdata['account_id']);
                                                $this->data['countries'] = $this->mainModal->get_dropdown("country");
                                        } 
                                        elseif ($success) 
                                        {
                                                $_SESSION['user_lang'] = $this->mainModal->languages[$data['Language_14']];
                                                $msg['fr'] = '<div class="alert alert-success alert-dismissible">Okay! Information enregistree avec succes<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['en'] = '<div class="alert alert-success alert-dismissible">Coolio! Information saved successfully!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                        else 
                                        {
                                                $msg['en'] = '<div class="alert alert-danger alert-dismissible">Une erreur se produite, veuillez essayer encore!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                                $msg['fr'] = '<div class="alert alert-danger alert-dismissible">An error has occurred, please check again!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        }
                                } 
                                else 
                                {
                                        $msg['fr'] = '<div class="alert alert-danger alert-dismissible">Veuillez renseigner un numero de telephone..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                        $msg['en'] = '<div class="alert alert-danger alert-dismissible">Please enter the phone number!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        
                        //New account?user
                        if(isset($arg) && $arg=='complete' && isset($msg[$this->lang]))
                        {
                                $this->data['msg'] = $msg[$this->lang];
                        }
                        elseif(isset($msg[$this->lang]))
                        {
                                echo $msg[$this->lang];
                        }
                }
                
                return true;
        }
        
        public function activate($obj=NULL, $id=NULL, $status=NULL)
	{
		/**
                 * User
                 * Changing status to 1
                */
                if($obj=='user')
                {
                        $data['Status_2'] = $status;
                        $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                        $data['Changer_6'] = $this->session->userdata['user_id'];

                        $gid = $this->mainModal->save_profile($data, $id);

                        if($this->lang=='fr' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">Changements effectu&eacute;es avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($this->lang!='' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">Changes done successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                else 
                {
                        
                }
                return true;
	}
        
        
        
        public function delete($obj=NULL, $id=NULL)
	{
		/**
                 * Site or branch/Group/User
                 * @Changing status to 0 to delete - can still be accessible for data related
                */
                $data['Status_2'] = 0;
                $data['Changes_5'] = gmdate('Y-m-d H:i:s');
                $data['Changer_6'] = $this->session->userdata['user_id'];
                
                if($obj=='site')
                {
                        $assigned_user=$this->mainModal->check_site_user($id);
                        
                        if($assigned_user)
                        {
                                $gid = $this->mainModal->save_site($data, $id);
                                        
                                if($this->lang=='fr' && $gid)
                                {
                                        echo '<div class="alert alert-success alert-dismissible">Site supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($this->lang!='' && $gid)
                                {
                                        echo '<div class="alert alert-success alert-dismissible">Branch deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                if($this->lang=='fr')
                                {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un site qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete this branch that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                }
                elseif($obj=='group')
                {
                        $assigned_user=$this->mainModal->check_group_user($id);
                        
                        if($assigned_user)
                        {
                                $gid = $this->mainModal->save_group($data, $id);
                                        
                                if($this->lang=='fr' && $gid)
                                {
                                        echo '<div class="alert alert-success alert-dismissible">Groupe supprim&eacute; avec succ&egrave;s!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                elseif($this->lang!='' && $gid)
                                {
                                        echo '<div class="alert alert-success alert-dismissible">Group deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                        else
                        {
                                if($this->lang=='fr')
                                {
                                        echo '<div class="alert alert-danger alert-dismissible">Vous ne pouvez pas supprimer un groupe qui contient des utilisateurs!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                                else
                                {
                                        echo '<div class="alert alert-danger alert-dismissible">You cannot delete a group that has active users..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                                }
                        }
                }
                elseif($obj=='user')
                {
                        $gid = $this->mainModal->save_profile($data, $id);

                        if($this->lang=='fr' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($this->lang!='' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                elseif($obj=='visitor')
                {
                        $gid = $this->mainModal->save_relation($data, $id);

                        if($this->lang=='fr' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">Utilisateur supprim&eacute; avec succ&egrave;s..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                        elseif($this->lang!='' && $gid)
                        {
                                echo '<div class="alert alert-success alert-dismissible">User deleted successfully..<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                        }
                }
                
                return true;
	}
        
        public function complete($step = null, $token = null) 
        {
                if($step == null && $token == null)
                {
                        $this->index();
                }
                elseif($step == 'step1')
                {
                        $this->data['profile'] = $this->mainModal->get_profile_infos($this->session->userdata['user_id']);
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_complete1', $this->data);
                        // $this->load->view('main/user/'.$this->lang.'/_complete1', $this->data);
                }
                elseif($step == 'step2')
                {
                        //Profile Data 
                        $this->save('profile', NULL, 'complete');
                        echo view('\Modules\Admin\Views\admin\\'.$this->lang.'\\_complete2', $this->data);
                        // $this->load->view('main/user/'.$this->lang.'/_complete2', $this->data);
                }
                elseif($step == 'step3')
                {
                        
                        $this->save('account', NULL, 'complete');
                }
        }
        
        /*
         * Manages additional data manipuations
         * Arguments could of any type, arrays or strings
         * List:
         * *  *************************************************************************************************************************SECTION 5
        */
        public function data($obj=NULL, $data=NULL, $arg=NULL, $param=NULL)
        {
                if($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
                elseif($obj == "OBJ ")
                {
                    
                }
        }
        
        /**
         * Dashboard Pie chart
         * Male vs Female candidats
        */ 
        public function get_piechart ($total=NULL){
                if((isset($total[0]) && $total[0]!=NULL))
                {
                        if($this->lang=='fr')
                        {
                                $data = '
                                            {value:'.$total[0]->Women_15.',label:"Femmes",color:"#099000",highlight:"#099012"},
                                            {value:'.($total[0]->Students_11-$total[0]->Women_15).',label:"Hommes",color:"#f56954",highlight:"#f569dd"}
                                        ';
                        }else {
                                $data = '
                                            {value:'.$total[0]->Women_15.',label:"Women",color:"#099000",highlight:"#099012"},
                                            {value:'.($total[0]->Students_11-$total[0]->Women_15).',label:"Men",color:"#f56954",highlight:"#f569dd"}
                                        ';
                        }
                }
                else 
                {
                        $data = '
                                {value:50,label:"% Femmes/Women",color:"#ddd",highlight:"#ddd"},
                                {value:50,label:"% Hommes/Men",color:"#ddd",highlight:"#ddd"}
                            ';
                }
                return $data;
        }
}

/* End of file welcome.php  */
/* Location: /project/activities  */


?>
