<?php

namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Main\Models\MainModel;
use Modules\Branch\Models\IntegrationModel;
use Modules\Logiref\Models\LogirefModel;
use Modules\Admin\Models\BranchModel;

class Admin extends BaseController
{
        /*
         * Presentation:
         * Last update:
         * By Alvin on the 28.08.2023
         * *  *************************************************************************************************************************SECTION 1
        */
        public $menus = array('sftp','logs_integrations', 'logs_operations','operations_dgda');
        public $roles = '5';
        public $role = '';
        public $group = 'banks'; //Banks, Regies, Clients
        public $tva = 0.16;
        public $restrictions = 0; //1 = no access or limited access
        public $lang = 'fr';
        public $module = 'admin';
        public $folder = 'admin';
        public $data = [];
        public $options;
        public $mainModal;
        public $accountModel;
        public $logirefModel;
        public $branchModel;
        public $userModel;
        public $stakeholderModel;
        public $curlModel;
        public $integrationModel;

        public function __construct()
        {
                parent::__construct();
                /*
                 * Module is project 
                 * Submodule or application is activities 
                 * function will be set within display function
                 * PS: A modifier au besoin!!
                */
                $this->integrationModel = new IntegrationModel();
                $this->mainModal = new MainModel();
                $this->logirefModel = new LogirefModel();
                $this->branchModel = new BranchModel();

                $this->data['module'] = $this->module;
                $this->data['application'] = 'admin';
                $this->data['function'] = '';
                $this->data['role'] = isset($_SESSION['Logiref_role']) ? $_SESSION['Logiref_role'] : '';
                $this->data['layout_type'] = 'wysihtml5-supported fixed pace-done';
                $this->data['lang'] = $this->lang;
                $this->data['group'] = $this->group;
                $this->data['currency'] = $this->session->userdata['account_currency'];
                $this->data['fullname'] = $this->session->userdata['user_fname'];
                $this->data['userid'] = $this->session->userdata["user_id"];
                $this->data['i'] = 0;
                $user_roles = $this->session->userdata['user_roles'];
                $this->data['deny'] = false;

                if($_SESSION['Logiref_role'] == 1)
                {
                        $this->data['sidebar'] = $this->sidebars->admin_logiref();
                }
                elseif($_SESSION['Logiref_role'] == 2)
                {
                        $this->data['sidebar'] = $this->sidebars->logiref_etax($_SESSION['Logiref_role']);
                }
                else
                {
                        $this->data['sidebar'] = '';
                        $this->data['deny'] = true;
                }

                if (isset($_SESSION['userdata']['options']))
                {
                        $this->data['options'] = $this->options = json_decode($_SESSION['userdata']['options'], true);
                }
                else
                {
                        $this->data['options'] = $this->options = array();
                }

                /*
                 * Control user access to this module
                 * If string is empty, then access denied
                 * A garder si uniquement c'est necessaire !!
                */
                if (!isset($_SESSION['Logiref_privileges'])) {
                        // $this->data("set_privilegies");
                } elseif (isset($user_roles['Logiref_privileges']) && $user_roles['Logiref_privileges'] != "") {
                        $this->roles = json_decode($user_roles['Logiref_privileges'], true);
                } elseif ($this->session->userdata['user_type'] == "400") {
                        #$this->display('deny');
                }

                //Group - A garder si uniquement c'est necessaire !!
                if (isset($_SESSION['Logiref_groupe']) && isset($_SESSION['Logiref_role'])) {
                        $this->group = $_SESSION['Logiref_groupe'];
                        $this->role = $_SESSION['Logiref_role'];
                } else {
                        redirect('main/signin', 'refresh');
                }
        }


        public function index()
        {
                if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                        $this->data['sidebar'] = '';
                }
                $this->data['subview'] = '\Modules\Admin\Views\container';
                echo view('layouts/layout_admin', $this->data);
                // $this->data['subview'] = 'container';
                // $this->load->view("_layout_" . $this->module, $this->data);
        }


        /*
         * Manages sidebar menu 
         * Must match de third section of the URL
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 2
        */
        public function set($needle)
        {
                if (in_array($needle, $this->menus)) {
                        if (isset($_SESSION['Logiref_role']) && $_SESSION['Logiref_role'] == 4) {
                                $this->data['sidebar'] = '';
                        }
                        $this->index();
                }
        }

        /*
         * Manages all the views
         * View calls are made here
         * * PS: A personnaliser !!
         * *  *************************************************************************************************************************SECTION 3
        */
        public function display($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                $this->_checkAuthorization();

                if ($obj == "logs_operations") {
                        echo view('\Modules\Admin\Views\admin\logs_operations', $this->data);
                }
                elseif ($obj == "logs_integrations") {
                        echo view('\Modules\Admin\Views\admin\logs_integrations', $this->data);
                }
                elseif ($obj == "sftp") {
                        $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province=NULL, true);
                        $this->data['integrations'] = $this->integrationModel->get_integrations_sftp();
                        echo view('\Modules\Admin\Views\admin\sftp', $this->data);
                }
                elseif ($obj == "operations_dgda")
                {
                        if(isset($this->options['ALL']['DGDA_payment_deletion_by_admin_user']))
                        {
                                $this->data['bulletins'] = $this->integrationModel->get_initiated_bls();
                                $this->data['guichets'] = $this->branchModel->get_dropdown("guichets");
                                $this->data['services'] = $this->logirefModel->get_dropdown("services", 'DGDA', $province = NULL, true);
                                $this->data['users'] = $this->mainModal->get_dropdown('users_array');

                                echo view('\Modules\Admin\Views\admin\\' .$obj, $this->data);
                        }
                        else
                        {
                                $this->data['denied'] = TRUE;
                                $this->data['country'] = $this->session->userdata['account_country'];
                                echo view('\Modules\Branch\Views\fr_denial', $this->data);
                        }
                }

                #Default
                elseif($obj == "deny")
                {
                        $this->data['denied'] = TRUE;
                        $this->data['country'] = $this->session->userdata['account_country'];
                        echo view('\Modules\Branch\Views\fr_denial', $this->data);
                }
        }

        /*
         * Manages all database updates
         * Calls to model's saving methos are made here
         * PS: A modifier uniquement si c'est necessaire!!
         * *  *************************************************************************************************************************SECTION 4
        */
        public function save($obj = NULL, $id = NULL, $arg = NULL, $param = NULL)
        {
                $this->_checkAuthorization();

                if($obj =="initialiasebl")
                {
                        $data = array(
                                'Status_2' => 0,
                                'Paiementkey_42' => $this->session->userdata["user_id"]
                        );

                        $this->integrationModel->delete_bls($data, $id, true);
                }
        }

}

/* End of file welcome.php  */
/* Location: /project/activities  */