<?php
namespace Modules\Admin\Models;

use App\Models\MY_Transaction;
use stdClass;

class IntegrationModel extends MY_Transaction
{

        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';
        public $options;

        public $ackmessages =  array(
                'OK' => 'Cl&ocirc;turer la transaction',
                'KO' => 'Paiement non valid&eacute;',
                '' => ''
        );

        public $bl_status = array(
                '1' => 'Nouveau',
                '2' => 'Ordre de paiement',
                '3' => 'Pay&eacute;',
                '' => ''
        );

        public $prepayments_status = array(
                '1' => 'Non valid&eacute;',
                '2' => 'Paiement valid&eacute;',
                '3' => 'Transaction cl&ocirc;r&eacute;e',
                '4' => 'Paiement non cl&ocirc;tur&eacute;'
        );

        public $declarations_status = array(
                '1' => 'Non valid&eacute;',
                '2' => 'D&eacute;claration valid&eacute;',
                '3' => 'Transaction cl&ocirc;r&eacute;e',
                '4' => 'Paiement non cl&ocirc;tur&eacute;'
        );

        public $prepayments_status_color = array(
                '1' => 'label-upcoming',
                '2' => 'label-ongoing',
                '3' => 'label-completed',
                '4' => 'label-muted'
        );

        public $declarations_status_color = array(
                '1' => 'label-upcoming',
                '2' => 'label-ongoing',
                '3' => 'label-completed',
                '4' => 'label-muted'
        );

        public $note_status = array(
                '1' => 'Nouveau',
                '2' => 'Ordre de paiement',
                '3' => 'Pay&eacute;',
                '' => ''
        );

        public $di_status = array(
                '1' => 'Nouveau',
                '2' => 'Ordre de paiement',
                '3' => 'Confirm&eacute;',
                '4' => 'Pay&eacute;',
                '' => ''
        );

        public $bl_statuscolor = array(
                '1' => 'label-upcoming',
                '2' => 'label-completed',
                '3' => 'label-ongoing'
        );

        public $note_statuscolor = array(
                '1' => 'label-upcoming',
                '2' => 'label-completed',
                '3' => 'label-ongoing'
        );

        public $di_statuscolor = array(
                '1' => 'label-muted',
                '2' => 'label-upcoming',
                '3' => 'label-completed',
                '4' => 'label-ongoing'
        );

        public $sydonia_error_code = array(
                '11' => 'Montant &agrave; payer incorrect',
                '13' => 'D&eacute;claration est introuvable',
                '34' => 'Bulletin de liquidation d&eacute;j&agrave; pay&eacute;',
                '22' => 'Aucun bulletin de liquidation  trouv&eacute;',
                'Ok' => 'Bulltin confirm&eacute;',
                '0' => 'Bulltin confirm&eacute;',
                '' => ''
        );

        public $sydonia_error_message = array(

                'en' => array(
                        "1" => 'daybook',
                        "2" => 'server',
                        "3" => 'modified by a post-entry operation',
                        "4" => 'the document is already used',
                ),
                'fr' => array(
                        "1" => 'Le journal de caisse pour ce bureau n\'est pas ouvert.',
                        "2" => 'SYDONIA ne réponds pas, veuillez refaire l\'operation s\'il vous pla&icirc;t',
                        "3" => 'Ce bulletin de liquidation a &eacute;t&eacute; modifi&eacute; par une op&eacute;ration post-entr&eacute;e',
                        "4" => 'Ce bulletin est déjà en cours de traitement par vous m&ecirc;me, vous aviez déjà commenc&eacute; le traitement de ce bulletin dans SYDONIA World.'
                )
        );


        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */

        public function get_integration_isys_info($id = NULL)
        {

                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Logirefid_4 = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')) . $this->session->userdata['account_id'] . $this->session->userdata['user_id'];
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Description_6 = '';
                        $obj->Makerid_7 = '';

                        $obj->Montant_8 = '0';
                        $obj->Devise_9 = '';
                        $obj->Beneficaire_10 = '';
                        $obj->Service_11 = '';
                        $obj->Typerecette_12 = '';
                        $obj->Journee_13 = gmdate('Y-m-d H:i:s');
                        $obj->Designation_14 = '';
                        $obj->Agence_15 = $_SESSION['Logiref_agence'];
                        $obj->Contrevaleur_16 = ''; // Tjrs en CDF

                        $obj->Reference_isys_17 = '';
                        $obj->Retourids_18 = '';
                        $obj->Retourdetails_19 = '';

                        $obj->Taux_20 = '';
                        $obj->Devise_21 = '';
                        $obj->Nombrepaiement_22 = '';

                        return $obj;
                } else {
                        $this->set_table('logiref_integration_isys I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_bulletin_info($number = NULL)
        {
                if ($number == NULL) {
                        $bulletin = new stdClass;
                        $bulletin->Id_0 = '';
                        $bulletin->Date_1 = '';
                        $bulletin->Status_2 = '';
                        $bulletin->Account_3 = '';
                        $bulletin->Designation_27 = '';
                        $bulletin->Commission_28 = '';
                        $bulletin->Datepaiement_29 = '';
                        return $bulletin;
                } else {
                        $this->set_table('logiref_bulletins b', 'b.Id_0', 'b.Id_0 DESC');
                        return $this->get_by(array('Declaration_12' => $number), TRUE);
                }
        }

        public function get_note_info($id = NULL)
        {
                if ($id == NULL) {
                        $note = new stdClass;
                        $note->Id_0 = '';
                        $note->Date_1 = '';
                        $note->Status_2 = '';
                        $note->Account_3 = '';
                        $note->Nifclient_7 = '';
                        $note->Reference_8 = '';
                        $note->Service_9 = '';
                        $note->Amount_10 = '';
                        $note->Typerecette_12 = '';
                        $note->Devise_17 = '';
                        $note->Datepaiement_18 = '';
                        $note->Document_path_19 = '';
                        $note->Banque_20 = '';
                        $note->Notedate_21 = '';
                        $note->Notemontant_22 = '';
                        $note->Notedevise_23 = '';
                        $note->Mode_24 = '';
                        $note->Ref_titre_25 = '';
                        $note->Notereference_26 = '';
                        return $note;
                } else {
                        $this->set_table('logiref_notes n', 'n.Id_0', 'n.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_integration_cbs_info($id = NULL)
        {

                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Logirefid_4 = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')) . $this->session->userdata['account_id'] . $this->session->userdata['user_id'];
                        $obj->Nombrepaiement_7 = ''; //Core Banking ID
                        $obj->Montant_8 = '';
                        $obj->Devise_9 = '';
                        $obj->Beneficiaire_0 = '';
                        $obj->Agence_10 = $_SESSION['Logiref_agence'];
                        $obj->Contrevaleur_11 = '';

                        $obj->Retourids_13 = '';
                        $obj->Retourdetails_14 = '';
                        $obj->Retourcbs_15 = '';

                        return $obj;
                } else {
                        $this->set_table('logiref_integration_cbs p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_logiref_integration_sftp_info($Id_0 = NULL)
        {
                if ($Id_0 == NULL) {
                        $sftp = new stdClass();
                        $sftp->Id_0 = '';
                        $sftp->Date_1 = '';
                        $sftp->Status_2 = '';
                        $sftp->Account_3 = '';
                        $sftp->Creator_4 = '';
                        $sftp->Changes_5 = '';
                        $sftp->Changer_6 = '';
                        $sftp->Office_7 = '';
                        $sftp->Amount_8 = '';
                        $sftp->Commission_9 = '';
                        $sftp->Account_10 = '';
                        $sftp->Paymentid_11 = '';
                        $sftp->Path_12 = '';
                        $sftp->Agence_13 = '';
                        $sftp->Nbtotal_14 = '';
                        $sftp->Date_15 = '';
                        $sftp->Nif_16 = '';
                        $sftp->Serial_17 = '';
                        $sftp->Number_18 = '';
                        $sftp->Type_19 = '';
                        return $sftp;
                } else {
                        $this->set_table('logiref_integration_sftp d', 'd.Id_0', 'd.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $Id_0), TRUE);
                }
        }

        public function  get_declaration_info($did = NULL)
        {
                if ($did == NULL) {
                        $declaration = new stdClass();
                        $declaration->Id_0 = '';
                        $declaration->Date_1 = '';
                        $declaration->Status_2 = '';
                        $declaration->Account_3 = '';
                        $declaration->Creator_4 = '';
                        $declaration->Changes_5 = '';
                        $declaration->Changer_6 = '';
                        $declaration->Subscriber_7 = '';
                        $declaration->Category_8 = '';
                        $declaration->Information_9 = '';
                        $declaration->Amount_10 = '';
                        $declaration->Currency_11 = '';
                        $declaration->Period_12 = '';
                        $declaration->Deadline_13 = '';
                        $declaration->Reference_14 = '';
                        $declaration->Province_15 = '';
                        $declaration->Content_16 = '';
                        $declaration->Nif_17 = '';
                        $declaration->Nature_18 = '';
                        $declaration->Paiementid_19 = '';
                        $declaration->Banque_20 = '';
                        return $declaration;
                } else {
                        $this->set_table('logiref_declarations  d', 'd.Id_0', 'd.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $did), TRUE);
                }
        }

        public function get_reversement_info($id = NULL)
        {

                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Logirefid_4 = mktime(date('H'), date('i'), date('s'), date('m'), date('j'), date('Y')) . $this->session->userdata['account_id'] . $this->session->userdata['user_id'];
                        $obj->Banqueid_5 = ''; //Core Banking ID
                        $obj->Description_6 = '';
                        $obj->Makerid_7 = '';
                        $obj->Montant_8 = '';
                        $obj->Devise_9 = '';

                        $obj->Beneficiaire_10 = '';
                        $obj->Service_11 = '';
                        $obj->Typerecette_12 = '';
                        $obj->Journee_13 = gmdate('Y-m-d H:i:s');
                        $obj->Designation_14 = '';
                        $obj->Agence_15 = $_SESSION['Logiref_agence'];

                        $obj->Contrevaleur_16 = '';
                        $obj->Reference_isys_17 = '';
                        $obj->Retourids_18 = '';
                        $obj->Retourdetails_19 = ''; // Tjrs en CDF

                        $obj->Taux_20 = '';
                        $obj->Nombrepaiement_22 = '';
                        $obj->Paiementids_23 = '';

                        return $obj;
                } else {
                        $this->set_table('logiref_integration_isys s', 's.Id_0', 's.Id_0 DESC');
                        return $this->get_by(array('s.Id_0' => $id), TRUE);
                }
        }

        public function get_log_brancless_info($id = NULL)
        {
                $this->set_table('logiref_log_branchless_retrieves b', 'b.Id_0', 'b.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }

        public function get_log_brancless_by_bl($bl_id = NULL)
        {
                $this->set_table('logiref_log_branchless_retrieves b', 'b.Id_0', 'b.Id_0 DESC');
                return $this->get_by(array('Paiementid_11' => $bl_id), TRUE);
        }

        public function  get_isys_account_info()
        {
                $this->_table_name = '';
                $bank = $this->session->userdata['account_id'];
                $this->set_table('logiref_isys_accounts c', 'c.Id_0', 'c.Id_0 DESC');
                $account = $this->get_by(array('Account_3' => $bank), TRUE);

                if (empty($account)) {

                        return NULL;
                } else {
                        return $account;
                }
        }

        public function  get_sydonia_account_info()
        {
                $this->_table_name = '';
                $bank = $this->session->userdata['account_id'];
                $this->set_table('logiref_sydonia_accounts c', 'c.Id_0', 'c.Id_0 DESC');
                $account = $this->get_by(array('Account_3' => $bank), TRUE);

                if (empty($account)) {
                        return NULL;
                } else {
                        return $account;
                }
        }



        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 3
        */

        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !='0'";
                $query = $this->db->table('TABLE_NAME')
                                ->select('TABLE_NAME.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}

        public function get_all_instructions_dgi($day)
        {
                $agence = $_SESSION['Logiref_guichet'];

                $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
                $query = $this->db->table('logiref_cbs_instructions_dgi')
                                ->select('logiref_cbs_instructions_dgi.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                return $query->getResult();
        }

        public function get_all_instructions_dgrad($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
                $query = $this->db->table('logiref_cbs_instructions_dgrad')
                                ->select('logiref_cbs_instructions_dgrad.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                return $query->getResult();
        }

        public function get_regularisations($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_cbs_regularisations.*', 'logiref_cbs_regularisations.Id_0 ASC');
                $this->db->from('logiref_cbs_regularisations');
                $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_regularisations.Id_0 DESC');
                return $this->get_all();
        }

        public function get_cbs_returns_dgi_dgrad_array($encaissements)
        {
                //Get IDs
                $ids = array();
                $stop = array();
                foreach ($encaissements as $id => $line) {
                        if (!isset($stop[$line->Paiementid_4])) {
                                $stop[$line->Paiementid_4] = 0;
                                $ids[] = $line->Paiementid_4;
                        }
                }
                if (!empty($ids)) $ids_list = implode("','", $ids);

                //
                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                if (isset($ids_list)) $st .= " AND Paiementid_4 IN ('" . $ids_list . "')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_cbs_returns');
                $ddmenu = array();
                foreach ($query->result_array() as $row) {
                        $returns_ids = json_decode($row['Result_6'], true);
                        $ddmenu[$row['Paiementid_4']] = $returns_ids;
                }
                return $ddmenu;
        }
        public function  get_instructions_dgda_by_id($id)
        {
                $this->_table_name = '';
                $this->set_table('logiref_cbs_instructions_dgda d', 'd.Id_0', 'd.Id_0 DESC');
                $lines = $this->get_by(array('Id_0' => $id), TRUE);

                return $lines;
        }
        public function get_all_instructions_dgda($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Guichet_7 ='" . $agence . "' AND Status_2 <> 0 AND Date_1 LIKE '%" . $day . "%'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                return $this->get_all();
        }
        public function get_sucess_instructions_dgda($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Guichet_7 ='" . $agence . "' AND Status_2='2' AND Date_1 LIKE '%" . $day . "%'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 ASC');
                return $this->get_all();
        }

        public function get_failed_instructions_dgda($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Guichet_7 ='" . $agence . "' AND Status_2 = 3 AND Date_1 LIKE '%" . $day . "%'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 DESC');
                return $this->get_all();
        }

        public function get_unknown_status_instructions_dgda($day)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_cbs_instructions_dgda.*', 'logiref_cbs_instructions_dgda.Id_0 ASC');
                $this->db->from('logiref_cbs_instructions_dgda');
                $st = " Guichet_7 ='" . $agence . "' AND Status_2 = 4 AND Date_1 LIKE '%" . $day . "%'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_cbs_instructions_dgda.Id_0 DESC');
                return $this->get_all();
        }

        public function get_cbs_returns_dgda_array($encaissements)
        {
                //Get IDs
                $ids = array();
                $stop = array();
                foreach ($encaissements as $id => $line) {
                        if (!isset($stop[$line->Paiementid_4])) {
                                $stop[$line->Paiementid_4] = 0;
                                $ids[] = $line->Paiementid_4;
                        }
                }
                if (!empty($ids)) $ids_list = implode("','", $ids);

                //
                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                if (isset($ids_list)) $st .= " AND Sydonia_5 IN ('" . $ids_list . "')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $query = $this->db->get('logiref_cbs_returns');
                $ddmenu = array();
                foreach ($query->result_array() as $row) {
                        $returns_ids = json_decode($row['Result_6'], true);
                        $ddmenu[$row['Sydonia_5']] = $returns_ids;
                }
                return $ddmenu;
        }



        public function get_declarations($bank = NULL, $type = NULL)
        {
                if ($type == "banque") {
                        #var_dump("tres");die;
                        $this->_table_name = '';
                        $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                        $this->db->from('logiref_declarations');
                        $st = "Status_2 != '0' AND  Banque_20 ='" . $bank . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } elseif ($bank == "ordre") {
                        $this->_table_name = '';
                        $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                        $this->db->from('logiref_declarations');
                        $st = "Status_2 == '1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } elseif (isset($bank)) {
                        #var_dump("tres");die;
                        $this->_table_name = '';
                        $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                        $this->db->from('logiref_declarations');
                        $st = "Status_2 <> '1' AND Changer_6 ='" . $bank . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } elseif ($type == "tous") {
                        $this->_table_name = '';
                        $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                        $this->db->from('logiref_declarations');
                        $st = "Status_2!='0'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } else {
                        $this->_table_name = '';
                        $this->db->select('logiref_declarations.*', 'logiref_declarations.Id_0 ');
                        $this->db->from('logiref_declarations');
                        $st = "Status_2!='0' AND Status_2!='4' OR Account_3='" . $this->session->userdata['account_id'] . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                }
        }

        public function get_declarations_content($dis = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->db->select('logiref_declarations.Id_0, logiref_declarations.Content_16');
                $this->db->from('education_categories');
                $this->db->where("logiref_declarations.Account_3 ='" . $account_id . "'");
                $this->db->where("logiref_declarations.Status_2 = 1");
                $this->db->distinct();
                if ($dis != NULL) $this->db->where("logiref_declarations.Id_0 IN ('" . $dis . "')");
                $this->db->order_by('logiref_declarations.Id_0');
                $results = $this->get_all();
                return $results;
        }

        public function get_last_declarations()
        {
                $this->_table_name = '';
                $this->db->select('Id_0', 'logiref_declarations.Id_0 DESC');
                $this->db->from('logiref_declarations');
                $this->db->order_by('Id_0 DESC');
                $this->db->limit(1);
                return $this->db->get()->result();
        }

        public function get_declaration_by_ref($id = NULL)
        {
                //Fonction a ecrire apres integration avec la DGI
                //Ou apres integration du Internet banking
                return false;
        }

        public function get_unvalidated_bls()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                if ($role != 4) $this->db->where("logiref_integration_sydonia.Status_2 = '2'");
                if ($role == 4) $this->db->where("(Status_2 = '1' OR Status_2 = '2') ");
                //if($role ==4)$this->db->where("logiref_integration_sydonia.Customercode_35 = ''"); 
                $this->db->order_by('Date_1 DESC');
                $this->db->limit(500);
                return $this->get_all();
        }


        public function get_unvalidated_bls_to_regulate()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                if ($role > 2) $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                $this->db->where("logiref_integration_sydonia.Status_2 = '5'");
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_bulletin_to_integrate($statut = NULL)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                $this->db->where("logiref_integration_sydonia.Status_2 = '7'");
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_unvalidated_to_export()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                if ($role == 4) $this->db->where("Status_2 = '2'");
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_validated_bls($type = NULL)
        {
                $account = $this->session->userdata['account_id'];
                $role = $_SESSION['Logiref_role'];
                $user = $this->session->userdata['user_id'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Status_2 = '3' AND logiref_integration_sydonia.Account_3 ='" . $account . "'");
                if ($role == 4) $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                if ($role == 3) $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                if ($type == 'penalities') $this->db->where("(Status_2 = '3' OR Status_2 = '2') AND DATEDIFF('" . gmdate('Y-m-d H:i:s') . "', Date_1) >= 1");
                $this->db->order_by('Date_1 DESC');
                $this->db->limit(500);
                return $this->get_all();
        }

        public function get_reports_bls($type = NULL)
        {
                $account = $this->session->userdata['account_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Status_2 > 1 AND logiref_integration_sydonia.Account_3 ='" . $account . "'");
                if ($role == 4) $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");
                if ($role == 3) $this->db->where("logiref_integration_sydonia.Agence_32 ='" . $_SESSION['Logiref_guichet'] . "'");

                $this->db->order_by('Date_1 DESC');
                $this->db->limit('500');
                return $this->get_all();
        }

        public function get_reports_filter($type = NULL)
        {
                $this->_table_name = '';
                $user = $this->session->userdata['user_id'];
                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                #Filtre d'affichage
                if (isset($_POST['operator']) && $_POST['operator'] != '') $st .= " AND User_15 ='" . $_POST['operator'] . "'";
                if (isset($_POST['start']) && $_POST['start'] != '') $st .= " AND Integration_16 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

                #Restriction
                if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 4) $st .= " AND Agence_32='" . $_SESSION['Logiref_guichet'] . "'";

                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_reports_filter_dgda($data)
        {
                $this->_table_name = '';
                $user = $this->session->userdata['user_id'];
                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' ";

                #Filtre d'affichage
                if (isset($data['guichet']) && $data['guichet'] != '') $st .= " AND Agence_32='" . $data['guichet'] . "'";
                if (isset($data['start']) && $data['start'] != '') $st .= " AND Integration_16 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "' ";

                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }
        public function  get_bulletins($data = NULL)
        {
                $this->_table_name = '';
                $this->db->select('Date_1, Year_5, Office_6, Serie_7, Number_8, Nif_9, Agent_10, User_15, Agence_32, Amount_12', 'logiref_integration_sydonia.Id_0 ASC');
                $this->db->from('logiref_integration_sydonia');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                #Filtre d'affichage
                if (isset($data['agence']) && $data['agence'] != '') $st .= "AND Agence_32 ='" . $data['agence'] . "'";
                if (isset($data['start']) && isset($data['end']) && ($data['start'] != '' && $data['end'] != '')) $st .= "AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }


        public function  get_notes($type = NULL, $nif = NULL, $bank = NULL)
        {
                if ($type == "tous") {
                        $this->_table_name = '';
                        $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                        $this->db->from('logiref_notes');
                        $st = "Status_2!='0' AND Nifclient_7='" . $nif . "'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } elseif ($type == "banque") {
                        $this->_table_name = '';
                        $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                        $this->db->from('logiref_notes');
                        $st = "Status_2 != '0' AND  Banque_20 ='" . $bank . "' ";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                } else {
                        $this->_table_name = '';
                        $this->db->select('logiref_notes.*', 'logiref_notes.Id_0 ');
                        $this->db->from('logiref_notes');
                        $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                        //$st = "Status_2!='0'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Id_0 DESC');
                        return $this->get_all();
                }
        }


        public function  get_all_bulletins($nif = NULL)
        {
                $this->_table_name = '';
                $this->db->select('logiref_bulletins.*', 'logiref_bulletins.Id_0 ASC');
                $this->db->from('logiref_bulletins');
                #var_dump($nif); die;
                $st = "Status_2!='0' AND Nifimportateur_10='" . $nif . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }

        public function  get_logs_branchless()
        {
                $agence = $_SESSION['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_log_branchless_retrieves.*', 'logiref_log_branchless_retrieves.Id_0 ASC');
                $this->db->from('logiref_log_branchless_retrieves');
                $st = "Status_2='1' AND Agence_14 = '" . $agence . "' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }

        public function  get_bulletins_by_lot($lot)
        {
                $account = $this->session->userdata['account_id'];
                $this->db->select('logiref_integration_sydonia.*');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                $this->db->where("logiref_integration_sydonia.Id_0 IN ($lot)");
                $this->db->order_by('logiref_integration_sydonia.Id_0', 'logiref_integration_sydonia.Id_0 DESC');
                return $this->get_all();
        }

        public function get_integrations_cbs($type = NULL)
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_integration_cbs.*', 'logiref_integration_cbs.Id_0 DESC');
                $this->db->from('logiref_integration_cbs');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_integrations_isys($type = NULL)
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_integration_isys.*', 'logiref_integration_isys.Id_0 DESC');
                $this->db->from('logiref_integration_isys');
                $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                $this->db->limit('500');
                return $this->get_all();
        }

        public function get_integrations_rtgs($type = NULL)
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_integration_rtgs.*', 'logiref_integration_rtgs.Id_0 DESC');
                $this->db->from('logiref_integration_rtgs');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_instructions($ref)
        {
                $this->_table_name = '';
                $this->db->select('logiref_integrations.*', 'logiref_integrations.Id_0 ASC');
                $this->db->from('logiref_integrations');
                $st = " Reference_14='" . $ref . "' AND Status_2 <> 0 ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_integrations.Id_0 ASC');
                $this->db->limit('500');
                return $this->get_all();
        }
        public function  get_provisions_occ()
        {
                $account = $this->session->userdata['account_id'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_provision_occ.*', 'logiref_integration_provision_occ.Id_0 ASC');
                $this->db->from('logiref_integration_provision_occ');
                $st = "Status_2!='0' AND Account_3='" . $account . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }

        public function get_cbs_returns_seguce_array()
        {

                $this->db->select('logiref_seguice_cbs_returns.*', 'logiref_seguice_cbs_returns.Id_0 ASC');
                $this->db->from('logiref_seguice_cbs_returns');
                $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                $this->db->limit('500');
                $query = $this->get_all();

                $ddmenu = array();
                foreach ($query as $row) {

                        $returns_event = json_decode($row->Result_6, true);
                        $ddmenu[$row->Seguice_5] = $returns_event;
                }

                return $ddmenu;
        }

        public function get_cbs_returns_seguice($id)
        {
                $this->set_table('logiref_seguice_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Seguice_5' => $id), TRUE);
        }
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_paiement_sydonia($id = NULL)
        {
                if ($id != NULL) {
                        $this->set_table('logiref_integration_sydonia I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_prepaiement_sydonia($id = NULL)
        {
                if ($id != NULL) {
                        $this->set_table('logiref_sydonia_prepayments I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_bulletin_by_ref($ref = NULL)
        {
                if ($ref != NULL) {
                        $this->set_table('logiref_bulletin I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Reference_19' => $ref), TRUE);
                }
        }

        public function get_cbs_returns($id)
        {
                $this->set_table('logiref_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Paiementid_4' => $id), TRUE);
        }

        public function get_cbs_returns_dgda($id)
        {
                $this->set_table('logiref_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_5' => $id), TRUE);
        }

        public function get_bulletin_confirmed($ref = NULL)
        {
                $this->_table_name = '';
                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');
                $st = " (Status_2= 1 OR Status_2 = 2) AND Error_14 !=0";

                if (isset($_POST['Office']) && $_POST['Office'] != '')  $st .= " AND Office_6='" . $_POST['Office'] . "'";
                if (isset($_POST['Year']) && $_POST['Year'] != '')  $st .= " AND Year_5='" . $_POST['Year'] . "'";
                if (isset($_POST['Bank']) && $_POST['Bank'] != '') $st .= " AND Bank_11='" . $_POST['Bank'] . "'";
                if (isset($_POST['Nif']) && $_POST['Nif'] != '') $st .= " AND Nif_9='" . $_POST['Nif'] . "'";
                if (isset($_POST['Agent']) && $_POST['Agent'] != '') $st .= " AND Agent_10='" . $_POST['Agent'] . "'";
                if (isset($_POST['Series']) && $_POST['Series'] != '') $st .= " AND Serie_7='" . $_POST['Series'] . "'";
                if (isset($_POST['Amount']) && $_POST['Amount'] != '') $st .= " AND Amount_12='" . $_POST['Amount'] . "'";
                #Run

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 ASC');
                $this->db->limit(1);
                return $this->get_all();
        }

        public function  get_clients_by_nif($nif = NULL)
        {
                if ($nif != NULL) {
                        $this->set_table('logiref_nifs N', 'N.Id_0', 'N.Id_0 DESC');
                        return $this->get_by(array('Nif_4' => $nif), TRUE);
                }
        }

        public function get_paiement_sydonia_by_ref($ref = NULL)
        {
                if ($ref != NULL) {
                        $this->set_table('logiref_integration_sydonia I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $ref), TRUE);
                }
        }


        public function get_token_isys()
        {
                $date = gmdate('Y-m-d');
                $this->set_table('logiref_integration_tokens I', 'I.Id_0', 'I.Id_0 DESC');
                $result = $this->get_by(array('Account_3' => $this->session->userdata['account_id'], 'Date_9' => $date), TRUE);

                $message = "";

                if (!empty($result)) {
                        $_SESSION['token_isys'] = $result->Token_8;
                        $_SESSION['token_time'] = $result->Time_10;

                        $token_time = $_SESSION['token_time'];
                        $current_time = gmdate('H:i:s');

                        $token_time_1 = strtotime($token_time);
                        $token_time_2 = strtotime($current_time);

                        $diff = $token_time_2 - $token_time_1;

                        $hour = floor(date('H:i:s', $diff));

                        if ($hour > 3) {
                                $message = "expired";
                        }
                } else {
                        $message = "expired";
                        $_SESSION['token_isys'] = '';
                        $_SESSION['token_time'] = '';
                }


                return $message;
        }

        public function get_sydonia_logs()
        {
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 ASC');
                $this->db->from('logiref_integration_sydonia');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }

        public function get_isys_logs()
        {
                $this->_table_name = '';
                $this->db->select('logiref_integration_isys.*', 'logiref_integration_isys.Id_0 ASC');
                $this->db->from('logiref_integration_isys');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }

        public function get_rtgs_logs()
        {
                $this->_table_name = '';
                $this->db->select('logiref_integration_rtgs.*', 'logiref_integration_rtgs.Id_0 ASC');
                $this->db->from('logiref_integration_rtgs');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }

        public function get_cbs_logs()
        {
                $this->_table_name = '';
                $this->db->select('logiref_integration_cbs.*', 'logiref_integration_cbs.Id_0 ASC');
                $this->db->from('logiref_integration_cbs');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }


        public function filter_logs_sydonia($data)
        {
                $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
                if (!empty($data)) {
                        if (isset($data['Error_14']) && !empty($data['Error_14'])) {
                                $st0 .= " AND Error_14 ='" . $data['Error_14'] . "'";
                        }

                        if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                                $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                        }

                        $this->db->select('logiref_integration_sydonia.*');
                        $this->db->from('logiref_integration_sydonia');
                        $this->db->where($st0, NULL, FALSE);
                        $this->db->order_by('logiref_integration_sydonia.Id_0', 'logiref_integration_sydonia.Id_0 DESC');
                        return $this->get_all();
                }
        }

        public function retrieve_bulletin_by_log_info()
        {
                $this->_table_name = '';

                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                if (isset($_POST['Office'])) $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
                if (isset($_POST['Year']))   $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
                if (isset($_POST['Nif']))    $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
                if (isset($_POST['Series'])) $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
                if (isset($_POST['Number'])) $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
                if (isset($_POST['Amount'])) $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";
                if (isset($_POST['Bank'])) $st .= " AND Bank_11 ='" . $_POST['Bank'] . "'";
                if (isset($_POST['Agent'])) $st .= " AND Agent_10 ='" . $_POST['Agent'] . "'";

                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function filter_logs_isys($data)
        {
                $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
                if (!empty($data)) {
                        if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                                $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                        }

                        if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                                $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                        }

                        $this->db->select('logiref_integration_isys.*');
                        $this->db->from('logiref_integration_isys');
                        $this->db->where($st0, NULL, FALSE);
                        $this->db->order_by('logiref_integration_isys.Id_0', 'logiref_integration_sydonia.Id_0 DESC');
                        return $this->get_all();
                }
        }

        public function filter_logs_rtgs($data)
        {
                $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
                if (!empty($data)) {
                        if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                                $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                        }

                        if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                                $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                        }

                        $this->db->select('logiref_integration_rtgs.*');
                        $this->db->from('logiref_integration_rtgs');
                        $this->db->where($st0, NULL, FALSE);
                        $this->db->order_by('logiref_integration_rtgs.Id_0', 'logiref_integration_rtgs.Id_0 DESC');
                        return $this->get_all();
                }
        }

        public function filter_logs_cbs($data)
        {
                $st0 = "Account_3 ='" . $this->session->userdata['account_id'] . "'";
                if (!empty($data)) {
                        if (isset($data['Status_2']) && !empty($data['Status_2'])) {
                                $st0 .= " AND Status_2 ='" . $data['Status_2'] . "'";
                        }

                        if ((isset($data['start']) && !empty($data['start'])) && (isset($data['end']) && !empty($data['end']))) {
                                $st0 .= " AND (Date_1 BETWEEN '" . $data['start'] . "' AND '" . $data['end'] . "')";
                        }

                        $this->db->select('logiref_integration_cbs.*');
                        $this->db->from('logiref_integration_cbs');
                        $this->db->where($st0, NULL, FALSE);
                        $this->db->order_by('logiref_integration_cbs.Id_0', 'logiref_integration_cbs.Id_0 DESC');
                        return $this->get_all();
                }
        }

        public function get_initiated_bls()
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $role = $_SESSION['Logiref_role'];
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Account_3 ='" . $account . "'");
                $this->db->where("logiref_integration_sydonia.Customercode_35 = ''");
                //$this->db->where("logiref_integration_sydonia.Date_1 LIKE '%".gmdate('Y-m-d')."%' ");
                $this->db->where("logiref_integration_sydonia.Status_2 = '0'");
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function  get_prepayments_by_lot($ids)
        {
                $account = $this->session->userdata['account_id'];
                $this->_table_name = '';
                $this->db->select('logiref_sydonia_prepayments.*', 'logiref_sydonia_prepayments.Id_0 ASC');
                $this->db->from('logiref_sydonia_prepayments');
                $st = "Status_2!='0' AND Account_3='" . $account . "' AND Id_0 IN (" . $ids . ")";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }

        public function  get_declarations_by_lot($lot)
        {
                $account = $this->session->userdata['account_id'];

                $this->db->select('logiref_sydonia_declarations.*');
                $this->db->from('logiref_sydonia_declarations');
                $this->db->where("logiref_sydonia_declarations.Status_2 > 0 AND logiref_sydonia_declarations.Account_3 ='" . $account . "'AND logiref_sydonia_declarations.Lot_18 =" . $lot . " ");
                $this->db->distinct();
                $this->db->order_by('logiref_sydonia_declarations.Id_0', 'logiref_sydonia_declarations.Id_0 DESC');
                return $this->get_all();
        }

        public function  get_douane_declarations()
        {
                $account = $this->session->userdata['account_id'];

                $this->db->select('logiref_sydonia_declarations.*');
                $this->db->from('logiref_sydonia_declarations');
                $this->db->where("logiref_sydonia_declarations.Status_2 > 0 AND logiref_sydonia_declarations.Account_3 ='" . $account . "' ");
                $this->db->distinct();
                $this->db->order_by('logiref_sydonia_declarations.Id_0', 'logiref_sydonia_declarations.Id_0 DESC');
                return $this->get_all();
        }

        public function get_declaration_detail($id = NULL)
        {
                $this->set_table('logiref_sydonia_declarations s', 's.Id_0', 's.Id_0 DESC');
                return $this->get_by(array('s.Id_0' => $id), TRUE);
        }

        public function get_prepayments()
        {
                $account = $this->session->userdata['account_id'];
                $this->db->select('logiref_sydonia_prepayments.*');
                $this->db->from('logiref_sydonia_prepayments');
                $this->db->where("logiref_sydonia_prepayments.Status_2 > 0 AND logiref_sydonia_prepayments.Account_3 ='" . $account . "' ");
                $this->db->order_by('Id_0', 'Id_0 ASC');
                return $this->get_all();
        }

        public function get_paiement_logirad($id = NULL)
        {
                if ($id != NULL) {
                        $this->set_table('logiref_integration_logirad I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_filter_gu_paiements($data)
        {
                $this->_table_name = '';
                $user = $this->session->userdata['user_id'];
                $guichet = $_SESSION['Logiref_guichet'];

                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_32='" . $guichet . "'  AND Status_2 IN (3,4)";

                #Filtre d'affichage

                if (isset($data['Office']) && $data['Office'] != '') $st .= " AND Office_6='" . $data['Office'] . "'";
                if ((isset($data['start']) && $data['start'] != '') && (isset($data['end']) && $data['end'] != '')) $st .= " AND Date_1 BETWEEN '" . $_POST['start'] . "' AND '" . $_POST['end'] . "' ";

                #Run
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_reports_gu_paiements($type = NULL)
        {
                $account = $this->session->userdata['account_id'];
                $guichet = $_SESSION['Logiref_guichet'];

                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Date_1 DESC');
                $this->db->from('logiref_integration_sydonia');
                $this->db->where("logiref_integration_sydonia.Status_2 IN (3,4) AND logiref_integration_sydonia.Account_3 ='" . $account . "' AND Agence_32 ='" . $guichet . "'");
                $this->db->order_by('Date_1 DESC');
                $this->db->limit(10);
                return $this->get_all();
        }

        public function get_prepayments_cbs_returns($id)
        {
                $this->set_table('logiref_prepayments_cbs_returns I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Sydonia_5' => $id), TRUE);
        }

        public function check_bulletin_sydonia()
        {

                $this->_table_name = '';

                $st = " Account_3='" . $this->session->userdata['account_id'] . "'";

                if (isset($_POST['Office'])) $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
                if (isset($_POST['Year']))   $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
                if (isset($_POST['Nif']))    $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
                if (isset($_POST['Series'])) $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
                if (isset($_POST['Number'])) $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
                if (isset($_POST['Amount'])) $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";

                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function check_bl_exist()
        {
                $this->_table_name = '';

                $st = " Account_3='44'";

                if (isset($_POST['Office'])) $st .= " AND Office_6 ='" . $_POST['Office'] . "'";
                if (isset($_POST['Year']))   $st .= " AND Year_5 ='" . $_POST['Year'] . "'";
                if (isset($_POST['Nif']))    $st .= " AND Nif_9 ='" . $_POST['Nif'] . "'";
                if (isset($_POST['Series'])) $st .= " AND Serie_7 ='" . $_POST['Series'] . "'";
                if (isset($_POST['Number'])) $st .= " AND Number_8 ='" . $_POST['Number'] . "'";
                if (isset($_POST['Amount'])) $st .= " AND Amount_12 ='" . $_POST['Amount'] . "'";
                if (isset($_POST['Bank'])) $st .= " AND Bank_11 ='" . $_POST['Bank'] . "'";
                if (isset($_POST['Agent'])) $st .= " AND Agent_10 ='" . $_POST['Agent'] . "'";

                #Query
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 DESC');
                $this->db->from('logiref_integration_sydonia');

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_all_payments_rbo($status)
        {

                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->userdata['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*');
                $this->db->from('logiref_integration_sydonia');

                $st = "Account_3='" . $account . "' AND Customercode_35 != '' AND Agence_32 ='" . $agence . "'";

                if ($status == "new") :

                        $st .= " AND Status_2 ='1' ";

                else :

                        $st .= " AND Status_2 = 2  ";

                endif;

                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                $payments = $this->get_all();

                $bureaux = array();
                $counts = array();
                $amounts = array();

                foreach ($payments as $line) :

                        $key = $line->Office_6 . $line->Customercode_35;

                        if (key_exists($key, $counts)) {
                                $counts[$key] += 1;
                                $amounts[$key] += $line->Amount_25;
                        } else {
                                $counts[$key] = 1;
                                $amounts[$key] = $line->Amount_25;
                        }

                        $line->total = $counts[$key];
                        $line->amounts = $amounts[$key];
                        $bureaux[$line->Office_6][$line->Customercode_35] = $line;

                endforeach;

                return $bureaux;
        }

        public function  get_payments_rbo_by_reference($data)
        {
                $account = $this->session->userdata['account_id'];
                $user = $this->session->userdata['user_id'];
                $agence = $this->session->userdata['Logiref_guichet'];
                $this->_table_name = '';
                $this->db->select('logiref_integration_sydonia.*', 'logiref_integration_sydonia.Id_0 ASC');
                $this->db->from('logiref_integration_sydonia');
                $st = "Status_2 ='1' AND Account_3='" . $account . "' AND Customercode_35 = '" . $data['reference'] . "' AND Agence_32 ='" . $agence . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0 DESC');
                return $this->get_all();
        }


        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */

        public function delete_bl($id)
        {
                $this->db->where('Id_0', $id);
                return $this->db->delete('logiref_integration_sydonia');
        }

        public function save_integrations_isys($data, $id)
        {
                $this->set_table('logiref_integration_isys', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        public function save_bulletin($data, $id)
        {
                $this->set_table('logiref_integration_sydonia', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_cbs_return($data, $id)
        {
                $this->set_table('logiref_cbs_returns', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function update_cbs_return($data, $id)
        {
                $this->set_table('logiref_cbs_returns', 'Sydonia_5', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Sydonia_5', $id);
                return $this->save($data, $id);
        }

        public function update_integrations($data, $ref)
        {
                $this->db->where("logiref_integrations.Reference_14 ='" . $ref . "'");
                return $this->db->update('logiref_integrations', $data);
        }
        public function update_log_info($data, $ids)
        {
                $this->db->where("logiref_log_branchless_retrieves.Id_0 IN (" . $ids . ")");
                return $this->db->update('logiref_log_branchless_retrieves', $data);
        }

        public function save_integrations($data, $id)
        {
                $this->set_table('logiref_integrations', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_declaration($data, $id)
        {
                $this->set_table('logiref_declarations', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_note($data, $id)
        {
                $this->set_table('logiref_notes', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_regularisations($data, $id)
        {
                $this->set_table('logiref_cbs_regularisations', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function update_note($data, $ids)
        {
                $this->db->where("logiref_notes.Id_0 IN ('" . $ids . "')");
                return $this->db->update('logiref_notes', $data);
        }

        public function save_token($data, $id)
        {
                $this->set_table('logiref_integration_tokens', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function update_declaration($data, $ids)
        {
                $this->db->where("logiref_declarations.Id_0 IN ('" . $ids . "')");
                return $this->db->update('logiref_declarations', $data);
        }

        public function update_prepayement($data, $ids)
        {
                $this->db->where("logiref_sydonia_prepayments.Id_0 IN (" . $ids . ")");
                return $this->db->update('logiref_sydonia_prepayments', $data);
        }

        public function update_bulletin($data, $ids)
        {
                $this->db->where("logiref_integration_sydonia.Id_0 IN (" . $ids . ")");
                return $this->db->update('logiref_integration_sydonia', $data);
        }

        public function update_paiement($data, $ids)
        {
                $this->db->where("logiref_bulletins.Declaration_12 IN ('" . $ids . "')");
                return $this->db->update('logiref_bulletins', $data);
        }

        public function update_sydonia_declaration($data, $ids)
        {
                $this->db->where("logiref_sydonia_declarations.Id_0 IN (" . $ids . ")");
                return $this->db->update('logiref_sydonia_declarations', $data);
        }

        public function save_isys_account($data, $id)
        {
                $this->set_table('logiref_isys_accounts', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_logs_branchless($data, $id)
        {
                $this->set_table('logiref_log_branchless_retrieves', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_sydonia_account($data, $id)
        {
                $this->set_table('logiref_sydonia_accounts', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_batch_bulletin($data, $id)
        {
                $this->set_table('logiref_integration_sydonia_batchs', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
}
