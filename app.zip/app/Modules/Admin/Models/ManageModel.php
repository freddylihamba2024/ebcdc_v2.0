<?php
namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Main;

class ManageModel extends MY_Main {
	
        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
    
        
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        
    
        public $languages = array(
                        'fr' =>array
                        (
                            '1' => 'Anglais',
                            '2' => 'Francais'
                            
                        ),
                        'en' =>array
                        (
                            '1' => 'English',
                            '2' => 'French'
                        )
                        
                );
        
        public $etat = array(
                        'fr' =>array
                        (
                            '1' => 'courant',
                            '2' => 'connect',
                            '3' => 'Non sold&eacute;'
                        ),
                        'en' =>array(
                            '1' => 'current',
                            '2' => 'connected',
                            '3' => 'Unpaid'
                        )    
                            
                );
        
        public $categories = array(
                            'fr'=>array(
                                ''=>'',
                                '101'=>'Business',
                                '202'=>'Entreprise',
                                '303'=>'Personnel'),
                            'en'=>array()
                );
        
        public $status = array(
                        'fr'=>array(
                            '0'=>'Supprim&eacute;',
                            '1'=>'Actif',
                            '2'=>'Expir&eacute;',
                            '3'=>'Innactif',
                            ),
                        'en'=>array()
                );
        
        public $color_status = array(
                            '0'=>'label-danger',
                            '1'=>'label-success',
                            '2'=>'label-warning',
                            '3'=>'label-warning',
                );
        
        
        public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        
        
        public function get_accounts_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1= gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Business_7='';
                        $obj->Category_8='';
                        $obj->Description_9='';
                        $obj->Activation_10= gmdate('Y-m-d H:i:s');
                        $obj->Expire_11= date('Y-m-d', strtotime("+60 day"));
                        $obj->Country_12='';
                        $obj->Currency_13='';
                        $obj->Dashboard_14='';
                        $obj->Telephone_15='';
                        $obj->Email_16='';
                        $obj->Logo_17='';
                        $obj->Website_18='';
                        $obj->State_19='';
                        $obj->City_20='';
                        $obj->Address_21='';
                        $obj->Address_22='';
                        $obj->Postal_23='';
                        $obj->Pageid_24='';
                        $obj->Restrictedto_25='';
                        $obj->Myapplication_26='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_accounts', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       return $result[0]; 
                }
        }
        
        public function get_profile_infos($id=NULL)
        {
                if($id==null)
                {
                        $obj = new stdClass();
                        $obj->Id_0= '';
                        $obj->Date_1='';
                        $obj->Status_2='';
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Identifier_7='';
                        $obj->Encryption_8='';
                        $obj->Firstname_9='';
                        $obj->Lastname_10='';
                        $obj->Middlename_11='';
                        $obj->Cellphone_12='';
                        $obj->Email_13='';
                        $obj->Language_14='';
                        $obj->Gender_15='';
                        $obj->Profile_16='';
                        $obj->Birthday_17='';
                        $obj->Position_18='';
                        $obj->Login_19='';
                        $obj->Logout_20='';
                        return $obj;
                }
                else
                {
                       $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                       $result = $this->get_by(array('Id_0' => $id));
                       //var_dump($id); die;
                       return $result[0]; 
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_account_stats() 
        {
                $return = array(
                        'current' => 0,
                        'expire' => 0,
                        'news'=>0,
                        'actif'=>0,
                        'inactif'=>0,
                        'deleted'=>0,
                        'total'=>0,
                    
                );

                $this->set_table('main_accounts', 'Id_0', 'Id_0 ASC');
                $return['accounts']= $this->get_by(array('Status_2 !=' => 0, 'Account_3 =' =>0));
                foreach ($return['accounts'] as $val) 
                {
                        if ($val->Status_2 == 1)
                            $return['current']++;
                        if($val->Expire_11 <= date('Y-m-d', strtotime("+60 day")))
                            $return['expire']++;
                        if ($val->Date_1 == gmdate('Y-m-d'))
                            $return['news']++;
                        if ($val->Status_2 == 0)
                            $return['deleted']++;
                        if ($val->Status_2 == 0 || $val->Status_2 == 1 || $val->Status_2 == 2 || $val->Status_2 == 3)
                            $return['total']++;
                            
                }
                return $return;
        }
        
        public function get_userconnect_stats($start = NULL) 
        {
                $return = array(
                        'connect' => 0,
                );

                $this->set_table('main_profiles', 'Id_0', 'Id_0 ASC');
                $return['connects']= $this->get_by(array('Status_2 !=' => 0, 'Account_3 !=' =>0));
                foreach ($return['connects'] as $val) 
                {
                        if ($val->Login_19  >= gmdate('Y-m-d'))
                            $return['connect']++;
                }
                return $return;
        }
        
        
        
        public function get_accounts($type=NULL) 
        {
                $this->_table_name = '';
                $this->db->select('main_accounts.*', 'main_accounts.Id_0 ASC');
                $this->db->from('main_accounts');
                $st = "Status_2 !='0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                if($type !="") $st .= " AND Category_8 =".$type;
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_login($start = NULL) 
        {
                $this->_table_name = '';
                $this->db->select('main_profiles.*', 'main_profiles.Id_0 DESC');
                $this->db->from('main_profiles');
                $st = "Status_2 !='0' AND Account_3 !='0'";
                $this->db->where($st, NULL, FALSE);
                if($start != NULL) $this->db->where('Login_19 >=', $start);
                #var_dump($start);die;
                $this->db->order_by('Id_0 ASC');
                return $this->get_all();
        }
        
        public function get_balance($end = NULL) 
        {
                $this->_table_name = '';
                $this->db->select('main_accounts.*', 'main_accounts.Id_0 DESC');
                $this->db->from('main_accounts');
                $st = "Status_2 !='0' AND Account_3 ='0'";
                $this->db->where($st, NULL, FALSE);
                if($end != NULL) $this->db->where('Expire_11 <=', $end);
                #var_dump($end);die;
                $this->db->order_by('Id_0 ASC');
                return $this->get_all();
        }
        
        

        public function get_details_accounts($details, $type=NULL) 
        {
                if($type == "visite")
                {
                    $st = "P.Status_2 !='0' AND R.Status_2 !='0' AND (R.Account_3 ='".$details."') AND (R.Type_10 ='400')"; 
                    $query = $this->db->select(' R.Id_0, R.Group_8, R.Branch_9, R.Type_10, P.Firstname_9, P.Lastname_10, P.Identifier_7, P.Cellphone_12, P.Email_13, P.Language_14, P.Gender_15, P.Position_18, P.Login_19, P.Logout_20, R.User_7')
                    ->from('main_profiles as P')
                    ->join('main_relations as R', 'P.Id_0 = R.User_7')   
                    ->where($st, NULL, FALSE)
                    ->get();
                    return $query->result();
                }
                else
                {
                    $st = "P.Status_2 !='0' AND R.Status_2 !='0' AND (R.Account_3 ='".$details."')"; 
                    $query = $this->db->select(' R.Id_0, R.Group_8, R.Branch_9, R.Type_10, P.Firstname_9, P.Lastname_10, P.Identifier_7, P.Cellphone_12, P.Email_13, P.Language_14, P.Gender_15, P.Position_18, P.Login_19, P.Logout_20, R.User_7')
                    ->from('main_profiles as P')
                    ->join('main_relations as R', 'P.Id_0 = R.User_7')   
                    ->where($st, NULL, FALSE)
                    ->get();
                    return $query->result();
                }
        }
        
        public function get_sites($details)
        {
                $this->_table_name = '';
                $this->db->select('main_branches.*, main_branches.Name_7');
                $this->db->from('main_branches');
                $this->db->where("main_branches.Status_2 ='1' AND main_branches.Account_3 ='" . $details . "'");
                $this->db->order_by('main_branches.Date_1 ASC');
                $queryResults = $this->get_all();
                return $queryResults;
        }
        
        public function get_groups($details)
        {
                $this->db->select('main_groups.*, main_groups.Name_7');
                $this->db->from('main_groups');
                $this->db->where("main_groups.Status_2 ='1' AND main_groups.Account_3 ='" . $details . "'");
                $this->db->order_by('main_groups.Date_1 ASC');
                $queryResults = $this->get_all();
                return $queryResults;
        }
        
        public function get_account_by_status($type=NULL)
        {       
                $expiration = date('Y-m-d', strtotime('+60 day'));
                $this->db->select('main_accounts.*', 'main_accounts.Id_0 ASC');
                $this->db->from('main_accounts');
                if($type == 'active') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'inactive') $st = "Status_2='3' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'delete') $st = "Status_2='0' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'expire') $st = "Expire_11	<='".$expiration."' AND (Account_3='".$this->session->userdata['account_id'] . "' OR Account_3='0')";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Id_0');
                return $this->get_all();
        }
        
        public function get_profil_by_status($type = NULL) 
        {
                $this->table = '';
                $expiration = date('Y-m-d', strtotime('+60 day'));
                
                if($type == 'active') $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'inactive') $st = "Status_2='2' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'delete') $st = "Status_2='0' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                if($type == 'expire') $st = "Expire_11	<='".$expiration."' AND (Account_3='".$this->session->userdata['account_id'] . "' OR Account_3='0')";
                
                
                $query = $this->db->table('main_profiles')
                                ->select('main_profiles.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                return $query->getResultArray();
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
            
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */
        
        public function save_account($data, $id)
        {
                $this->set_table('main_accounts', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        
        public function save_profile($data, $id)
        {
                $this->set_table('main_profiles', 'Id_0', 'Id_0 DESC');
                ($id >0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }
        

}