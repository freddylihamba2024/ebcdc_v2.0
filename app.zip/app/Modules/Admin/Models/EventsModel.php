<?php
namespace Modules\Admin\Models;

use App\Models\MY_Logiref_Sbbos_Main;
use stdClass;

class EventsModel extends MY_Logiref_Sbbos_Main {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'logiref_sbbos_events'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;

        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Name_7', 'Type_8', 'Location_9', 'Start_10', 'End_11', 'Time_12', 'Time_13', 'Partners_14', 'Description_15', 'Start_16', 'End_17', 'Time_18', 'Time_19'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
        public $type = array(
                            ''=>'', 
                            '1' => 'Concert', 
                            '2' => 'Kermesse', 
                            '3' => 'Transport'
                        );
	public $status_color = array(
            
                    '1' => 'label-ongoing',
                    '2'=>'label-upcoming',
                    '3' => 'label-completed',
                    '0' => 'label-cancelled',
        );
        
        public $status =  array(
                                '1' => 'Nouveau',
                                '2' => 'En cours',
                                '3' => 'Pass&eacute;',
                                '0' => 'Annul&eacute;',
                            );
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_event_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                        $obj->Name_7='';
                        $obj->Type_8='';
                        $obj->Location_9 ='';
                        $obj->Start_10='';
                        $obj->End_11 ='';
                        $obj->Time_12='';
                        $obj->Time_13='';
                        $obj->Partners_14='';
                        $obj->Description_15='';
                        $obj->Start_16='';
                        $obj->End_17='';
                        $obj->Time_18='';
                        $obj->Time_19='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('logiref_sbbos_events', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="event")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $query = $this->db->table('logiref_sbbos_events')
                                                ->where($where)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = "";
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                else if($item=="event_date_start")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        
                        $query = $this->db->table('logiref_sbbos_events')
                                                ->where($where)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = "";
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Start_10']." ".$row['Time_12'];
                        }
                        return $ddmenu;
                }
                else if($item=="event_date_end")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";

                        $query = $this->db->table('logiref_sbbos_events')
                                                ->where($where)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = "";
                        
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['End_11']." ".$row['Time_13'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_events($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                if($status != "")
                {
                        $account_id=$this->session->userdata['account_id'];
                        $query = $this->db->table('logiref_sbbos_events')
                                        ->select('logiref_sbbos_events.*')
                                        ->where("logiref_sbbos_events.Account_3 ='".$status."'")
                                        ->orderBy('Id_0', 'DESC')
                                        ->get();

                        return $query->getResult();
                }
                else 
                {
                        $account_id=$this->session->userdata['account_id'];
                        $query = $this->db->table('logiref_sbbos_events')
                                        ->select('logiref_sbbos_events.*')
                                        ->where("logiref_sbbos_events.Account_3 ='".$account_id."'")
                                        ->orderBy('Id_0', 'DESC')
                                        ->get();

                        return $query->getResult();
                }
	}
        
        
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_events($data, $id)
	{
		$this->set_table('logiref_sbbos_events', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        
        
}

