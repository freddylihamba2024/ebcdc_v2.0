<?php
namespace Modules\Admin\Models;

use App\Models\MY_Qleads;
use stdClass;

class QleadUsersModel extends MY_Qleads {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_users'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Userid_7', 'Authorization_8', 'Branchid_9', 'Tellercode_10', 'Makerid_11', 'Checkerid_12'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        

        public $types = array(
            'Token' => 'Token',
            'Request' => 'Request',
        );

        public function __construct()
        {
                parent::__construct();
        }
        
        
        /*
         * Get Information: returns an object
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_member_by_user_id()
        {
                $this->set_table('qleads_users', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Userid_7' => $this->session->userdata['user_id']));
                return $result;
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_users($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('qleads_users')
                        ->select('qleads_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_users_by_branchid()
        {
                $st = "Status_2 > '0' AND Account_3='" . $this->session->userdata['account_id'] . "'  AND Branchid_9 ='" . $_SESSION['Branchid'] . "'";
                $query = $this->db->table('qleads_users')
                        ->select('qleads_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        
        public function get_subcategorie_by_categorie($categorieId)
        {
                $st = "Status_2 !=0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('qleads_categories')
                        ->select('qleads_categories.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_categorie($data, $id) {
                $this->set_table('qleads_categories', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_objects_name($data, $id)
        {
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_users($data, $userid) 
        {
                $this->set_table('qleads_users', 'Userid_7', 'Userid_7 DESC');
                return $this->saveData($data, $userid);               
        }

        public function save_users($data, $id)
        {
                $this->set_table('qleads_users', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}