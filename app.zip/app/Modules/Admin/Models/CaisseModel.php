<?php
namespace Modules\Admin\Models;

use App\Models\MY_Logiref_Sbbos_Main;
use stdClass;

class CaisseModel extends MY_Logiref_Sbbos_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'logiref_sbbos_caisses'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Type_4', 'Beneficiaires_5', 'Service_6', 'Recette_7', 'Guichet_8', 'Value_9', 'Unite_10', 'Min_11', 'Max_12', 'Devise_13', 'Makerid_14', 'Checkerid_15', 'Validation_16', 'Typefacture_17', 'Rbo_18', 'Customer_19'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
        public $status_color = array(
            
                    '0'=>'label-ongoing',
                    '1' => 'label-new-order',
                    '2' => 'label-completed',
                    '3' => 'label-cancelled',
                    '4' => 'label-upcoming'
        );
        
        public $status =  array(
                                '0' => 'Supprim&eacute;e',
                                '1' => 'Ferm&eacute;e',
                                '2' => 'Ouverte', 
                                '3' => 'Fermeture en attente', 
                                "4"=>'Ouverture en attente'
                            );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_caisse_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Reference_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Compte_9 = '';
                        $obj->Name_10 = '';
                        $obj->Devise_11 = '';
                        $obj->Opener_12 = '';
                        $obj->Closer_13 = '';
                        $obj->Date_14 = '';
                        $obj->Agence_15 = '';

                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_caisses g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="caisses")
                {   
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('logiref_sbbos_caisses')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_10'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_caisses($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('logiref_sbbos_caisses')
                        ->select('logiref_sbbos_caisses.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_caisse_by_branchid($id =NULL, $currency= NULL)
        {
                if($currency == NULL)
                {
                        $this->set_table('logiref_sbbos_caisses I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Guichet_8' => $id), TRUE);
                }
                else
                {
                        $this->set_table('logiref_sbbos_caisses I', 'I.Id_0', 'I.Id_0 DESC');
                        return $this->get_by(array('Guichet_8' => $id, 'Devise_11'=>$currency), TRUE);
                }
                
        }
        
        public function get_caisses_by_agence()
        {
                $agence = $_SESSION['Logiref_guichet'];
                $st = "Status_2 !=0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Agence_15 ='" . $agence . "'";
                $query = $this->db->table('logiref_sbbos_caisses')
                        ->select('logiref_sbbos_caisses.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_movement_caisse_by_id($id=NULL)
        {
                $this->set_table('logiref_sbbos_guichet_movements g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Guichet_11' => $id), TRUE);
        }
        
        public function get_movement_caisse($id=NULL)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $guichet = $_SESSION['Logiref_branch'];
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_11 = '".$guichet."' AND Agence_13 = ".$agence;
                
                #Filtre d'affichage
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $end = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$end."' ";
                }
                

                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_guichets_status()
        {
                $agence = $_SESSION['Logiref_guichet'];
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_13 = ".$agence;
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        
        public function get_current_movement($id, $action)
        {
                $day = gmdate('Y-m-d');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_11 = '".$id."' AND Action_12 ='".$action."'";
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->like('Date_1',$day)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        #Checks if the book has already been created with the entered account
        public function get_caisse_exists($account = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_caisses ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3'=>$account_id,'Compte_9'=>$account), TRUE);
        }
        
        
        public function filter_caisses_status($data)
        {
                $user = $this->session->userdata['user_id'];
                $agence = $_SESSION['Logiref_guichet'];
                
                #Query
                $st = " Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_13 = '".$agence."'";
                
                #Filtre d'affichage
                if(isset($_POST['Guichet_11']) && $_POST['Guichet_11']!='') $st .= " AND Guichet_11='".$_POST['Guichet_11']."'";
                #if(isset($_POST['start']) && $_POST['start']!='') $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
              
                if(isset($_POST['start']) && $_POST['start']!='')
                {
                        $_POST['end'] = date('Y-m-d', strtotime($_POST['end']. ' +1 days'));
                        
                        $st .= " AND Date_1 BETWEEN '".$_POST['start']."' AND '".$_POST['end']."' ";
                }
                
                #Run
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
            
        }
        
        public function get_balances_stats()
        {
                $agence = $_SESSION['Logiref_guichet'];
                $day = gmdate('Y-m-d');
                $status = array(
                    
                            'opening' => 0, 
                            'closing' => 0,
                            'open' => 0,
                            'closed' => 0,
                            'toclose' => 0,
                            'toopen' => 0,
                            'cashrigesters'=> 0
                            );
                
                
                $this->db->select('logiref_sbbos_guichet_movements.*', 'logiref_sbbos_guichet_movements.Id_0 DESC');
                $this->db->from('logiref_sbbos_guichet_movements');
                $st = " Account_3='" . $this->session->userdata['account_id'] . "'  AND Agence_13 = '".$agence."'";
               
                #Run
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                $result = $query->getResult();
                
                // Monatnts d'ouvertures et des fermetures
                foreach($result as $row):
                    
                    if($row->Action_12 == "opening" && $row->Changer_6 != 0)
                    {
                        $status['opening'] += $row->Balance_10;
                    }
                    elseif($row->Action_12 == "closing" && $row->Changer_6 != 0)
                    {
                        $status['closing'] += $row->Balance_10;
                    }
                    
                endforeach;
                
                
                
                // Nombre des caisses fermées et nombre des caisses ouvertes
                foreach($result as $row):
                    
                    if($row->Status_2 == 1 && $row->Changer_6 != 0)
                    {
                        $status['open'] += 1;
                    }
                    elseif($row->Status_2 == 2 && $row->Changer_6 != 0)
                    {
                        $status['closed'] += 1;
                    }
                    
                endforeach;
                
                
                // Nombre des caisses en attente d'ouverture et nombre des caisses en attente de fermeture
                foreach($result as $row):
                    
                    if($row->Action_12 == "opening" && $row->Changer_6 == 0)
                    {
                        $status['toopen'] += 1;
                    }
                    elseif($row->Action_12 == "closing" && $row->Changer_6 == 0)
                    {
                        $status['toclose'] += 1;
                    }
                    
                endforeach;
              
          
                return $status;
                
                
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function update_caisses($data, $id)
	{
                $this->set_table('logiref_sbbos_caisses', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}	
	
        
        public function save_caisse($data, $id) {
                $this->set_table('logiref_sbbos_caisses', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}