<?php

namespace Modules\Admin\Models;

use App\Models\MY_Main;

class CurlModel extends MY_Main
{

        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';


        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        //LOGS 
        public function call_set_log($data, $type = NULL)
        {
                $url = $_SERVER["SERVER_NAME"] . $_SERVER["PHP_SELF"];
                $log['url'] = $url;
                $log['message'] = $data;
                $log['bank_name'] = $this->session->userdata['account_business'];

                if ($type == NULL) {
                        $url = base_url('api/logs/logiref/encaissement/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "sydonia") {
                        $url = base_url('api/logs/logiref/sydonia/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "isys") {
                        $url = base_url('api/logs/logiref/isys/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                } elseif ($type == "quittance") {
                        $url = base_url('api/logs/logiref/quittance/log.php');
                        $this->load->library('curl');
                        $this->curl->create($url);
                        $this->curl->post($log);
                        $response = $this->curl->execute();
                }
                $response = $this->curl->execute();
        }

        public function call_logirad($data)
        {
                //Fonction a activer apres integration avec la DGI
                //Ou apres integration du Internet banking
                /* 
                $url = base_url('api/endpoints/taxdeclaration/declaration.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                */
                return NULL;
        }

        //DGI 
        public function call_dgi_declaration($data)
        {
                $url = base_url('api/endpoints/taxdeclaration/declaration.php');

                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);

                $response = $this->curl->execute();

                return $response;
        }


        //DGRAD
        public function call_dgrad_notes($data)
        {
                $data['User'] = $this->session->userdata['user_id'];
                $data['Account'] = $this->session->userdata['account_id'];
                $data['Agence'] = $_SESSION['Logiref_guichet'];
                $url = base_url('api/endpoints/logirad/checknote.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //DGDA
        public function call_dgda_declaration($data)
        {
                $response = $data;
                return $response;
        }

        //DGDA
        public function call_dgda_prepayments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $apidata['bank'] = (isset($encryption->codebank)) ? $encryption->codebank : '';
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];

                $url = base_url('api/endpoints/sydonia/prepaymentsList.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_seguce_invoices($data)
        {
                //$data = array();
                //$data['agence'] = isset($_SESSION['Logiref_guichet']) ? $_SESSION['Logiref_guichet'] : "";

                $url = base_url('api/endpoints/seguce/get.invoice.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return trim($response);
        }

        public function call_seguce_invoices_paid()
        {
                $data = array();
                $data['agence'] = isset($_SESSION['Logiref_guichet']) ? $_SESSION['Logiref_guichet'] : "";
                $url = base_url('api/endpoints/seguce/get.invoices.paid.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return trim($response);
        }

        public function call_seguce_confirm_invoices($data)
        {
                $url = base_url('api/endpoints/seguce/confirm.invoice.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return trim($response);
        }

        public function call_bank_invoice_extourne_provision($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/invoice.provision.extourne.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }

        //BANK
        public function call_bank_invoice_partial_integration($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/invoice.partial_integration.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }

        //BANK
        //public function call_bank_verify_invoice_partial_integration($data)
        public function call_bank_verify_invoice_occ_regul($data)
        {
                set_time_limit(250);
                //$url = base_url('api/endpoints/bank/rawbank/invoice.occ.partial.verify.php');
                $url = base_url('api/endpoints/bank/rawbank/regularize.occ.verify.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                //var_dump($response); die;
                return $response;
        }

        public function call_bank_batch_invoice_partial_integration($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/batch.invoice.partial_integration.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }

        public function call_dgda_procurement($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $apidata['bank'] = (isset($encryption->codebank)) ? $encryption->codebank : '';
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['Office'] = $_POST['Office'];

                $url = base_url('api/endpoints/sydonia/prepaymentsList.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        //DGDA
        public function call_dgda_send_ack_prepayments($credentials)
        {
                $apidata = array();
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Account'] = $this->session->userdata['account_id'];

                $apidata['messageKey'] = $_POST['messageKey'];
                $apidata['codeTr'] = $_POST['codeTr'];

                $url = base_url('api/endpoints/sydonia/prepaymentsAck.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        //BANK
        public function call_bank_comptant($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/comptant.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_virement($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/virement.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_bank_virement_occ($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/virement.invoices.occ.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                var_dump($response);
                die;
                return $response;
        }

        public function call_bank_virement_provision($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/virement.provision.occ.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_bank_virement_provision_verify($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/virement.provision.verify.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //DGDA 
        public function call_single_recover($credentials)
        {

                if ($_POST['Taux'] == "") {
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];
                }

                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'];
                $apidata['Commission'] = $_POST['Commission'];
                $apidata['Devise_commission'] = $_POST['Devise_commission'];
                $apidata['Total_amount'] = $_POST['Total_amount'];
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['cGuichet'] = $_POST['cGuichet'];
                $apidata['Taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux;
                $apidata['bank_account'] = isset($_POST['bank_account']) ? $_POST['bank_account'] : "";
                $apidata['Devise_account'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                $apidata['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                $url = base_url('api/endpoints/sydonia/recover.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();

                return trim($response);
        }

        //DGDA
        public function call_batch_recover($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = $_POST;
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = $Amount;
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = base_url('api/endpoints/sydonia/check.batch.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        //BANK
        public function call_bank_checkbalance($data)
        {
                $response = '';
                $url = base_url('api/endpoints/bank/rawbank/check.balance.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_checkbalance_invoice($data)
        {
                $response = '';
                $url = base_url('api/endpoints/bank/rawbank/check.balance.invoice.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_account_info($data)
        {

                set_time_limit(250);
                $response = '';
                $url = base_url('api/endpoints/bank/rawbank/account.info.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }


        //DGDA
        public function call_dgda_checkbl_credit($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = base_url('api/endpoints/sydonia/checkblcredit.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                //$response = $this->curl->execute();
                $response = NULL;
                return trim($response);
        }

        public function call_dgda_checkbl($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = base_url('api/endpoints/sydonia/checkbl.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->option('CONNECTTIMEOUT', 0);
                $this->curl->option('TIMEOUT', 1800);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_dgda_check_batch($data)
        {
                $url = base_url('api/endpoints/sydonia/checkbl.batch.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_logiref_update_payment($data)
        {
                set_time_limit(250);

                $url = base_url('api/endpoints/rbo/update.payment.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }
        //BANK
        public function call_bank_comptant_single($credentials)
        {
                if ($_POST['Taux'] == "") {
                        $taux = json_decode($_SESSION['Bank_rates'], true);
                        $taux = $taux['Dollar_4'];
                }

                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['designation'] = $_POST['designation'];
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Devise'] = $_POST['devise'];
                $apidata['Compte_guichet'] = $_POST['Compte_guichet'];
                $apidata['Commission'] = $_POST['Commission'];
                $apidata['Devise_commission'] = $_POST['Devise_commission'];
                $apidata['Total_amount'] = $_POST['Total_amount'];
                $apidata['Mode'] = $_POST['Mode'];
                $apidata['ReferenceOp'] = $_POST['reference'];
                $apidata['Paiementid'] = isset($_POST['Paiementid']) ? $_POST['Paiementid'] : "";
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['DateL'] = $_POST['DateL'];
                $apidata['Taux'] = isset($_POST['Taux']) ? $_POST['Taux'] : $taux;
                $apidata['bank_account'] = isset($_POST['bank_account']) ? $_POST['bank_account'] : "";
                $apidata['Devise_account'] = isset($_POST['Devise_account']) ? $_POST['Devise_account'] : "";
                $apidata['account_name'] = isset($_POST['account_name']) ? str_replace(" V/C CDF", "", $_POST['account_name']) : "";
                $url = base_url('api/endpoints/sydonia/comptant.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();

                return trim($response);
        }


        public function call_dgda_getAmount_single($credentials)
        {
                $encryption = json_decode($credentials->Password_18);

                $notemontant = str_replace(' ', '', $_POST['Amount']);
                $Amount = str_replace(',', '.', $notemontant);
                $apidata = array();
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';
                $apidata['Amount'] = intval($Amount);
                $apidata['Year'] = $_POST['Year'];
                $apidata['Series'] = $_POST['Series'];
                $apidata['Number'] = $_POST['Number'];
                $apidata['Agent'] = $_POST['Agent'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Bank'] = $_POST['Bank'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $url = base_url('api/endpoints/sydonia/get.payment.amount.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->option('CONNECTTIMEOUT', 0);
                $this->curl->option('TIMEOUT', 1800);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_batch_reverse($data)
        {
                $url = base_url('api/endpoints/isys/paiements.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return trim($response);
        }

        //BANK
        public function call_bank_comptant_batch($data)
        {
                $url = base_url('api/endpoints/sydonia/comptant.batch.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_dgda_quittance($data)
        {
                $url = base_url('api/endpoints/sydonia/quittance.single.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_bank_licence_bcc($data)
        {
                $response = '';
                $url = base_url('api/endpoints/sydonia/declarationsList.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_regularization($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/regularize.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_regularize_invoice_occ($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/regularize.invoice.occ.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_reversepayment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/extourne.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_reversepayment_occ($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/extourne.invoice.occ.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }

        //BANK
        public function call_bank_verification($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/account.event.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_verify_invoice_occ($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/account.event.invoice.occ.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/reservation.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        //call_seguce_invoice_reservation
        public function call_bank_verify_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/verification.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        public function call_seguce_invoice_verify_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/seguce.invoice.verification.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_prepayment_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/prepayment.virement.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_seguce_invoice_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/seguce.invoice.reservation.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                //var_dump($response); die;
                return $response;
        }

        //BANK
        public function call_seguce_invoice_cancel_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/seguce.invoice.cancel.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_prepayement_verify_reservation($data)
        {

                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/prepayment.verification.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_cancel_reservation($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/cancel.reservation.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        //BANK
        public function call_bank_upload_virmul($filepath)
        {

                $data = array();
                $data['guichet'] = $_SESSION['Logiref_guichet'];
                $data['filepath'] = $filepath;
                set_time_limit(250);
                $url = base_url('api/endpoints/bank/rawbank/virmul.php');

                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }

        // DGDA
        public function call_dgda_payments($credentials)
        {
                $encryption = json_decode($credentials->Password_18);
                $apidata['login'] = (isset($credentials->Login_17)) ? $credentials->Login_17 : '';
                $apidata['password'] = (isset($encryption->encryption)) ? $encryption->encryption : '';

                $taux = json_decode($_SESSION['Bank_rates'], true);
                $taux = $taux['Dollar_4'];

                $apidata['guichet'] = $_POST['guichet'];
                $apidata['User'] = $this->session->userdata['user_id'];
                $apidata['Account'] = $this->session->userdata['account_id'];
                $apidata['Office'] = $_POST['Office'];
                $apidata['Agence'] = $_SESSION['Logiref_guichet'];
                $apidata['cGuichet'] = $_POST['cGuichet'];
                $apidata['Nif'] = $_POST['Nif'];
                $apidata['designation'] = $_POST['designation'];
                $apidata['taux'] = $taux;
                $apidata['Logirefid'] = $_POST['Logirefid'];
                $apidata['dateDebut'] = $_POST['dateDebut'];
                $apidata['dateFin'] = $_POST['dateFin'];
                $apidata['qserie'] = $_POST['qserie'];
                $apidata['qnumber'] = $_POST['qnumber'];
                $url = base_url('api/endpoints/sydonia/paymentsList.php');


                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($apidata);
                $response = $this->curl->execute();
                return trim($response);
        }

        public function call_illicocash_make_payment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }


        public function call_illicocash_confirm_payment($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/illicocash/payment.validate.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();
                return $response;
        }



        public function connection($data)
        {
                set_time_limit(250);
                $url = base_url('api/endpoints/cloud/login.php');
                $this->load->library('curl');
                $this->curl->create($url);
                $this->curl->post($data);
                $response = $this->curl->execute();

                return $response;
        }
}
