<?php
namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Main;

class accountModel extends MY_Main {
	
        /* Presentation: 
         * Last update
         * By Glodi  on the 12.10.2023
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        public $bank;
        
        
        
        
        public $type_service = array(
                            ''=>'',
                            'DGE' => 'Direction des grandes entreprises', 
                            'CDI' => 'Centre d\'imp&ocirc;t',
                            'CIS' => 'Centre d\'imp&ocirc;t synth&eacute;tique'
                        );
        public $banks = array(
                            ''=>'',
                            '44' => 'Rawbank', 
                            '45' => 'Tmb',
                            '46' => 'Ebcdc',
                            '9082'=> 'Boa',
                            '9083' => 'Solidaire',
                            '9084' => 'Sofibank'
                        );
	
	
	public function __construct()
	{
		parent::__construct();
                
                $this->bank = isset($this->session->userdata["account_pageid"])?$this->session->userdata["account_pageid"]:"";
                
                if($this->bank != "")
                {
                        # Enlever @ dans le pageid
                        # Tranformer la premiere lettre en majuscule
                        $this->bank = substr($this->bank, 1);
                        $this->bank = ucfirst($this->bank);
                }
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        public function get_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Type_4 = '';
                        $obj->Beneficiaires_5 = '';
                        $obj->Compte_6 = '';
                        $obj->Clef_7 = '';
                        $obj->Devise_8 = '';
                        $obj->Makerid_9 = '';
                        $obj->Validation_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Recette_13 = '';
                        $obj->Regie_14 = '';
                        $obj->Agenceid_15= '';
                        $obj->Serviceid_16= '';
                        $obj->Nif_17	= '';
                        $obj->Comptesydonia_18	= '';
                        $obj->Numericcode_19 = '';
                        $obj->Nivellement_20='';
                        $obj->Bank_21='';
                        $obj->Category_22='';
                        $obj->Numimportateur_23='';
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_comptes p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_prepaid_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Nifimportateur_7 = '';
                        $obj->Accountnumber_8 = '';
                        $obj->Refsydonia_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Makerid_11 = '';
                        $obj->Checkerid_12 = '';
                        $obj->Validation_13 = '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_prepaid_accounts p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_clientexonere_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Beneficiaires_7 = '';
                        $obj->Compte_8 = '';
                        $obj->Agenceid_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Montant_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Validation_13 = '';
                        $obj->Infos_14  = '';
                        $obj->Clef_15  = '';
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_client_regie_exonere l', 'l.Id_0', 'l.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "beneficiaire")
                {
                        $type = $arg;
                        $st = "Status_2='1'";
                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        if ($type != NULL) {
                                $st .= " AND Type_4='" . $type . "'";
                        } else {
                                $ddmenu['BKC'][''] = ''; // Banque commerciale

                        }

                        $query = $this->db->table('logiref_beneficiaries')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Type_4']][$row['Description_5']] = $row['Description_5'] . " (" . $row['Code_7'] . ")";
                        }
                        return $ddmenu;
                }
                elseif($item=="beneficiary_tax_others_banks")
                {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Nivellement_20 = '1' ";

                        $query = $this->db->table('logiref_comptes')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Recette_13']]['Agence_12'] = $row['Bank_21'];
                        }
                        return $ddmenu;
                }
                elseif($item=="OBJECT NAME")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('TABLE_NAME')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResult() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Userid_13'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_name_objects($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
	{
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !='0'";
                $query = $this->db->table('TABLE_NAME')
                                ->select('TABLE_NAME.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}
        
        public function get_latest_validated_accounts()
	{
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !='0'";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->limit(20)
                                ->get();
                return $query->getResult();
	}
        
        public function get_agence_accounts()
	{
                $guichet = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_12 = '".$guichet."' ";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
	}
        
        public function get_compte_parametrer($guichet)
        {
                $st = "Status_2='1' AND Checkerid_11 <> 0 AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_12 = '".$guichet."'";

                $query = $this->db->table('logiref_comptes')
                    ->select('logiref_comptes.*')
                    ->where($st)
                    ->orderBy('Date_1', 'ASC')
                    ->get();
                return $query->getResult();
        }
        
        public function get_others_banks_account_by_tax()
	{
                $guichet = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Agence_12 = '".$guichet."' AND Nivellement_20 = '1' ";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                
                return $query->getResult();
	}
        
        public function get_comptes($type = NULL)
        {
                $this->table = '';

                if ($type == 'cptes') {
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 ='0'";

                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        return $query->getResult();
                } else {
                        $st = "Status_2='1' AND Beneficiaires_5='" . $_SESSION['Logiref_regies'] . "'";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        return $query->getResult();
                }
        }

        public function get_count_comptes()
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id']."'";

                $query = $this->db->table('logiref_comptes')
                    ->select('logiref_comptes.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get()
                    ->getResultArray();
                return count($query);
        }

        public function get_client_exoneres($type=NULL)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id']."'";

                $query = $this->db->table('logiref_client_regie_exonere')
                    ->select('logiref_client_regie_exonere.*')
                    ->where($st)
                    ->orderBy('Date_1', 'DESC')
                    ->get();

                return $query->getResult();
        }

        public function get_customer_exemption_by_account($account, $devise)
        {
                $account_id = $this->session->userdata['account_id'];

                $st = "Status_2='1' AND Account_3='" . $account_id."' AND Compte_8='" . $account."' AND Devise_10='" . $devise."' AND Validation_13 != '0000-00-00 00:00:00' ";
                $query = $this->db->table('logiref_client_regie_exonere')
                        ->select('logiref_client_regie_exonere.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
        }

        
        public function get_filtered_accounts($data)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                if (isset($data['type']) && $data['type'] != "") $st .= " AND Type_4 ='" . $data['type'] . "'";
                if (isset($data['agence']) && $data['agence'] != "") $st .= " AND Agence_12 ='" . $data['agence'] . "'";
                if (isset($data['taxe']) && $data['taxe'] != "") $st .= " AND Recette_13 ='" . $data['taxe'] . "'";
                if (isset($data['bureau']) && $data['bureau']) $st .= " AND Serviceid_16 ='" . $data['bureau'] . "'";
                if (isset($data['devise']) && $data['devise']) $st .= " AND Devise_8 ='" . $data['devise'] . "'";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                return $query->getResult();
        }
        public function get_export_comptes()
        {
                $st = "Status_2 !='0' AND Account_3='" . $this->session->userdata['account_id'] . "'"; 
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                return $query->getResult();
        }
        
        #Recuperer la devise par rapport ? un compte
        public function get_comptes_by_parameters($compte = NULL, $devise = NULL, $type = NULL, $beneficiaire = NULL, $agence = NULL, $recette = NULL, $service = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                
                $array = array('Account_3'=>$account_id,'Type_4'=>$type,'Compte_6'=>$compte, 'Beneficiaires_5'=>$beneficiaire, 'Devise_8'=>$devise, 'Agence_12'=>$agence, 'Recette_13'=>$recette);
                if(isset($recette))$array["Recette_13"] = $recette;
                if(isset($service))$array["Serviceid_16"] = $service;
                
                return $this->get_by($array, TRUE);
        }
        
        public function get_compte_by_number($data=NULL) 
        {
                $account_id = $this->session->userdata['account_id'];
                
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Compte_6'=>$data,'Account_3' =>$account_id), TRUE);
        }
        
        public function get_comptes_inter_agence_array($liste=NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ")"; 
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Agenceid_15']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_array_for_banks($liste=NULL, $beneficiaire, $agence = NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $account = $this->session->userdata['account_id'];
                $st = "Status_2='1'AND Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 <>'0'";
                $st .= " AND Agence_12 =".$agence." AND Type_4 IN (" . $liste . ") AND Beneficiaires_5 IN (".$beneficiaire.") ";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                return $query->getResultArray();
        }
        


        public function get_comptes_array($liste=NULL, $agence_src=NULL, $agence_dst=NULL, $regie =NULL) 
        {
                $bank = $this->bank;
                
                $comptes = array();
                $comptes[''][''] = '';
                $account = $this->session->userdata['account_id'];
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";

                if($agence_dst!=NULL && $liste!='') $st .= " AND Agence_12 =".$agence_dst." AND Type_4 IN (" . $liste . ")";
                elseif($agence_src!=NULL) $st .= " AND Agence_12 =".$agence_src." ";
                elseif($liste!='') $st .= " AND Type_4 IN (" . $liste . ")"; 
                if($regie =='DGI') $st .= " AND Recette_13 NOT IN ('TVA', 'TVF', 'TVN', 'TVO')"; 
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                foreach ($query->getResultArray() as $row) 
                {
                        if (in_array($account, ['9084', '9086', '36']))
                        {
                                if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        }
                        else
                        {
                                if($row['Recette_13']!= '')
                                {
                                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        else $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }

                        }
                }
                
                return $comptes;
        }

        public function get_comptes_array_leveling($liste=NULL, $agence_src=NULL, $regie =NULL) 
        {
                $comptes = array();
                
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Agence_12 =".$agence_src." AND Type_4 IN (" . $liste . ")";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                foreach ($query->getResultArray() as $row) 
                {
                        $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                }
                return $comptes;
        }

        public function get_comptes_array_dgi($liste=NULL, $agence_src=NULL, $agence_dst=NULL, $regie =NULL, $service = NULL, $recette = NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $account = $this->session->userdata['account_id'];
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                if($agence_dst!=NULL && $liste!='') $st .= " AND Agence_12 =".$agence_dst." AND Type_4 IN (" . $liste . ")";
                elseif($agence_src!=NULL) $st .= " AND Agence_12 =".$agence_src." ";
                elseif($liste!='') $st .= " AND Type_4 IN (" . $liste . ")"; 
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
               
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Recette_13'] =='')
                        {
                                if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                        }
                }
                
                return $comptes;
        }
        
        public function get_comptes_array_dgrad($liste=NULL, $agence_src=NULL, $agence_dst=NULL, $regie =NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $account = $this->session->userdata['account_id'];
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                if($agence_dst!=NULL && $liste!='') $st .= " AND Agence_12 =".$agence_dst." AND Type_4 IN (" . $liste . ")";
                elseif($agence_src!=NULL) $st .= " AND Agence_12 =".$agence_src." ";
                elseif($liste!='') $st .= " AND Type_4 IN (" . $liste . ")"; 
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Recette_13'] =='')
                        {
                                if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                        }
                }
                return $comptes;
        }

        public function get_agence_comptes_array($agence, $liste=NULL)
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                foreach ($query->getResultArray() as $row)
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Devise_8'].' '.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }

                return $comptes;
        }

        public function get_comptes_recettes_agence_array($agence, $liste=NULL, $beneficiaire = NULL)
        {
                $comptes = array();
                $comptes[''][''] = '';
                $account = $this->session->userdata['account_id'];
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0' ";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                if($beneficiaire != "") $st .= " AND Beneficiaires_5 ='".$beneficiaire."' ";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Recette_13'] == 'TVA' && $row['Beneficiaires_5'] == 'DGDA')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Recette_13'] == 'TVA' && $row['Beneficiaires_5'] == 'DGI')
                        {
                                if($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                        elseif($row['Recette_13'] != 'TVA')
                        {
                                if($row['Agenceid_15']!="" && ($row['Recette_13'] == 'AT3' || $row['Recette_13'] == 'AT4'))
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']][$row['Serviceid_16']] .= "-".$row['Clef_7'];

                                }
                                elseif($row['Agenceid_15']!="")
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                                else
                                {
                                        $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Compte_6'];
                                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                }
                        }
                }
                return $comptes;
        }
        
        public function get_comptescfb_recette_array($recette, $instution, $liste=NULL) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 = '".$recette."'";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                $results = $query->getResult();
                
                if(empty($results))
                {
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Regie_14='' AND  Recette_13 = '".$recette."'";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13='' AND Regie_14 = '".$instution."'";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13 ='' AND Regie_14 = '".$instution."'";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 = '' AND Regie_14=''";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14='' ";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }

                foreach ($results as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
                
        }
        
        public function get_comptescfb_agence_array($instution, $liste=NULL) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13='' AND Regie_14 = '".$instution."'";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                
                $results = $query->getResult();
               
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13 ='' AND Regie_14 ='".$instution."'";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 ='' AND Regie_14=''";
                        
                        $$query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14=''";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                foreach ($results as $row) 
                {
                       
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
                
        }
        
        public function get_recette_comptes_array($agence, $liste=NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence."";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                foreach ($query->getResult() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Recette_13']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Recette_13']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function get_comptes_by_type_array($liste=NULL, $regie=NULL) 
        {
                $agence = $_SESSION['Logiref_guichet'];
                $comptes = array();
                $results = array();
                $comptes[''][''] = '';
                
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND  Regie_14 = '".$regie."'";
                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                $results = $query->getResult();
                if(empty($results))
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 =".$agence." AND Recette_13 ='' AND Regie_14=''";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                if(empty($results))
                {
                        
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')AND Checkerid_11 <>'0'";
                        $st .= " AND Type_4 IN (" . $liste . ") AND Agence_12 ='' AND Recette_13='' AND Regie_14=''";
                        
                        $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                        
                        $results = $query->getResult();
                }
                
                foreach ($results as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                        else  $comptes[$row['Beneficiaires_5']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
                return $comptes;
        }
        
        public function tcheck_prepaid_account($account=NULL, $devise=NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_prepaid_accounts ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' =>$account_id, 'Devise_10'=>$devise, 'Accountnumber_8'=>$account), TRUE);
        }
        
        public function get_prepaid_comptes($type=NULL) 
        {
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "')"; 
                
                $query = $this->db->table('logiref_prepaid_accounts')
                                ->select('logiref_prepaid_accounts.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                return $query->getResult();

        }
        
        public function get_prepaid_comptes_array($agence, $type=NULL) 
        {
                $comptes = array();
                $comptes[''][''] = '';
                $account_id = $this->session->userdata['account_id'] ?? null;

                $st = "Status_2='1' AND (Account_3='" . $account_id  . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 IN (" . $type . ") AND Agence_12 =".$agence."";
                
                $query = $this->db->table('logiref_comptes')
                        ->select('logiref_comptes.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();
                
                foreach ($query->getResultArray() as $row) 
                {
                        if($row['Agenceid_15']!="") $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] = ($account_id == "36" || $account_id == "9086" ) ? $row['Compte_6'] : $row['Agenceid_15']."-".$row['Compte_6'];
                        elseif($row['Agenceid_15']=="" && $row['Clef_7']=="" ) $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                        else $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] = $row['Devise_8'].''.$row['Compte_6'];
                        if($row['Clef_7']!="") $comptes[$row['Comptesydonia_18']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                }
               
                return $comptes;
        }
        
        public function get_prepaid_compte_by_refsydonia($account)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_prepaid_accounts ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' =>$account_id, 'Refsydonia_9'=>$account), TRUE);
        }
        
        
        ################################# New method ######################################
        #################################             ######################################
        
        public function get_comptes_array_by_channel($type){
                $comptes = array();
                $comptes[''][''] = '';
                //$st="Status_2='1' AND (Account_3='44' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                $st .= " AND Type_4 = '".$type."'"; 

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                             
                foreach ($query->getResultArray() as $row) 
                {
                        if(isset($row['Agenceid_15']) && $row['Agenceid_15'] != "")
                        {
                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Agenceid_15']."-".$row['Compte_6'];
                                if(isset($row['Clef_7']) && $row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                if(isset($row['Numericcode_19']) && $row['Numericcode_19']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Numeric_code_19'];
                        }
                        elseif(isset($row['Compte_6']) && $row['Compte_6'] != "")
                        {
                                $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] = $row['Compte_6'];
                                if(isset($row['Clef_7']) && $row['Clef_7']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Clef_7'];
                                if(isset($row['Numeric_code_19']) && $row['Numeric_code_19']!="") $comptes[$row['Beneficiaires_5']][$row['Type_4']][$row['Devise_8']] .= "-".$row['Numeric_code_19'];
                        }
                }
                return $comptes;
        }

        public function get_comptes_dgi($liste = NULL, $beneficiary=NULL, $agence=NULL, $code_agence = NULL) 
        {
                $account = $this->session->userdata['account_id'];

                $st = "Status_2 = '1'
                AND Checkerid_11 <> '0'
                AND (Account_3 = '" . $account . "' OR Account_3 = '0')";

                if (!empty($liste)) 
                {
                        $st .= " AND Type_4 IN (" . $liste . ")";
                }

                if (!empty($agence)) 
                {
                        $st .= " AND Agence_12 = '" . $agence . "'";
                }

                if (!empty($code_agence)) 
                {
                        $st .= " AND Agenceid_15 = '" . $code_agence . "'";
                }

                if (!empty($beneficiary)) 
                {
                        $st .= " AND Beneficiaires_5 IN (" . $beneficiary . ")";
                }

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                return $query->getResultArray();
        }

        public function get_comptes_dgrad($liste, $agence=NULL, $code_agence = NULL)
        {
                $account = $this->session->userdata['account_id'];
                $bank = $this->bank;

                if($agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Agence_12 =".$agence." AND Type_4 IN (" . $liste . ") AND Beneficiaires_5 IN ('DGRAD', '$bank') ";
                }
                elseif($code_agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") AND Beneficiaires_5 IN ('DGRAD', '$bank') AND Agenceid_15 = '".$code_agence."' ";
                }
                else
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") AND Beneficiaires_5 IN ('DGRAD', '$bank') ";
                }

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')   
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();
                
                return $query->getResultArray();
        }
        
        public function get_comptes_dgda($liste=NULL, $beneficiary = NULL, $agence = NULL, $code_agence = NULL) 
        {
                $account = $this->session->userdata['account_id'];
                $bank = $this->bank;
                
                if($agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Agence_12 =".$agence." AND Type_4 IN (" . $liste . ") ";
                }
                elseif($code_agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") AND Agenceid_15 = '".$code_agence."' ";
                }
                else
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") ";
                }
                
                if($beneficiary != NULL) $st .= " AND Beneficiaires_5 IN (".$beneficiary.") ";


                
                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                return $query->getResultArray();
        }

        public function get_comptes_seguce($liste=NULL, $beneficiary = NULL, $agence = NULL, $code_agence = NULL, $account_id = NULL) 
        {
                $account = $this->session->userdata['account_id'] ?? $account_id ?? "";
                
                if($agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Agence_12 =".$agence." AND Type_4 IN (" . $liste . ") ";
                }
                elseif($code_agence != NULL)
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") AND Agenceid_15 = '".$code_agence."' ";
                }
                else
                {
                        $st = "Status_2='1'AND (Account_3='" . $account . "' OR Account_3='0') AND Checkerid_11 <>'0' AND Type_4 IN (" . $liste . ") ";
                }
                
                if($beneficiary != NULL) $st .= " AND Beneficiaires_5 IN (".$beneficiary.") ";

                $query = $this->db->table('logiref_comptes')
                                ->select('logiref_comptes.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->get();

                return $query->getResultArray();
        }

        public function get_comptes_passport($liste=NULL)
        {
                $comptes = array();
                $comptes[''][''] = '';
                $st = "Status_2='1'AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Checkerid_11 <>'0'";
                if($liste!='') $st .= " AND Type_4 IN (" . $liste . ")";

                $builder = $this->db->table('logiref_comptes')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();

                return $builder->getResultArray();
        }

        public function get_filtered_tarifications($data)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                if(isset($data['agence']) && $data['agence'] !="") $st.= " AND Agence_12 ='".$data['agence']."'";
                if(isset($data['beneficiaires']) && $data['beneficiaires'] !="") $st.= " AND Beneficiaires_7 ='".$data['beneficiaires']."'";
                if(isset($data['devise']) && $data['devise']) $st.= " AND Devise_10 ='".$data['devise']."'";

                $builder = $this->db->table('logiref_client_exonore')
                        ->select('logiref_client_exonore.*')
                        ->where($st)
                        ->orderBy('Date_1','DESC')
                        ->get();

                return $builder->getResult();
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

	public function save_prepaid_accounts($data, $id) {
                $this->set_table('logiref_prepaid_accounts', 'Id_0', 'Id_0 DESC');
                ($id > 0) || $this->db->where('Id_0', $id);
                return $this->save($data, $id);
        }

        public function save_compte($data, $id)
        {
                $this->set_table('logiref_comptes', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_tarification_account($data, $id)
        {
                $this->set_table('logiref_client_regie_exonere', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

}