<?php
namespace Modules\Admin\Models;

use App\Models\MY_Qleads;
use stdClass;

class QleadQueueModel extends MY_Qleads {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_queues'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Branchid_7', 'Categorieslist_8', 'Tellerslist_9', 'Sequence_10', 'Opening_11', 'Served_12', 'Makerid_13', 'Checkerid_14'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        

        public $tellers = array(''=> '', 'A' => 'A','B' => 'B','C' => 'C', 'D' => 'D','E' => 'E','F' => 'F','G' => 'G','H' => 'H', 'I' => 'I','J' => 'J','K' => 'K','L' => 'L','M' => 'M','N' => 'N','O' => 'O','P' => 'P','Q' => 'Q','R' => 'R','S' => 'S','T' => 'T','U' => 'U','V' => 'V','W' => 'W','Y' => 'Y','Z' => 'Z');
        public $sequences = array(''=> '', 'A' => 'A','B' => 'B','C' => 'C', 'D' => 'D','E' => 'E','F' => 'F','G' => 'G','H' => 'H', 'I' => 'I','J' => 'J','K' => 'K','L' => 'L','M' => 'M','N' => 'N','O' => 'O','P' => 'P','Q' => 'Q','R' => 'R','S' => 'S','T' => 'T','U' => 'U','V' => 'V','W' => 'W','Y' => 'Y','Z' => 'Z');

        public $type_queues = array(''=> '', '0' => 'Ordinaire','1' => 'VIP');
        public $stauts = array(''=> '', '1' => 'File activée', '2' => 'File non activée');
        
        public $priorites = array(
                '' => '',
                'P0' => 'Priorit&eacute; 0',
                'P1' => 'Priorit&eacute; 1'
        );


        public function __construct()
        {
                parent::__construct();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_queue_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Branchid_7 = '';
                        $obj->Categorieslist_8 = '';
                        $obj->Tellerslist_9 = '';
                        $obj->Sequence_10 = '';
                        $obj->Opening_11 = '';
                        $obj->Served_12 = '';
                        $obj->Makerid_13 = '';
                        $obj->Checkerid_14 = '';
                        $obj->Vip_15 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('qleads_queues g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="teller_categories")
                {   
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('qleads_queues')
                                                ->where($st)
                                                ->orderBy('Branchid_7')
                                                ->get();
                        

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[][$row['Branchid_7']] = $row['Tellerslist_9'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="queue")
                {   
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('qleads_queues')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = "File ".$row['Id_0'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="queue_agence")
                {   
                        $guichet = $arg; 
                        $st = "Status_2 = '1' AND  Branchid_7='" . $guichet . "'";
                        $query = $this->db->table('qleads_queues')
                                            ->where($st)
                                            ->orderBy('Id_0')
                                            ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = "File ".$row['Id_0'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="sequence")
                {   
                        $guichet = $arg; 
                        $st = "Status_2 = '1' AND  Branchid_7='" . $guichet . "'";
                        $query = $this->db->table('qleads_queues')
                                            ->where($st)
                                            ->orderBy('Id_0')
                                            ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Sequence_10'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="queueid")
                {   
                        $guichet = $arg; 
                        $st = "Status_2 = '1' AND  Branchid_16='" . $guichet . "'";
                        $query = $this->db->table('qleads_queuing')
                                            ->where($st)
                                            ->orderBy('Id_0')
                                            ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Queueid_7'];
                        }
                        
                        return $ddmenu;
                }
                if($item=="user_queue")
                {   
                        $guichet = $arg; 
                        $st = "Status_2 = '1' AND  Branchid_9='" . $guichet . "'";
                        $query = $this->db->table('qleads_users')
                                            ->where($st)
                                            ->orderBy('Id_0')
                                            ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Queueid_11']][]= $row['Userid_7'];
                        }
                        
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_queues($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
              
        public function get_queues_by_branch($branche_id)
        {
                $st = "Status_2 ='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Branchid_7 ='" . $branche_id . "'";
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_type_queues_by_branch($brancheid, $type)
        {
                $st = "Status_2 !=0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Branchid_7 ='" . $brancheid . "' AND Vip_15 ='" . $type . "'";
                $query = $this->db->table('qleads_queues')
                        ->select('qleads_queues.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_queuing_by_id($id)
        {
                $this->set_table('qleads_queuing I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Id_0' => $id), TRUE);
        }
        
        public function get_queuing_by_queueid($queueid, $branchid)
        {
                $this->set_table('qleads_queuing I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Queueid_7' => $queueid, 'Opening_11' => gmdate('Y-m-d'), 'Branchid_16' => $branchid), TRUE);
        }

        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_queue($data, $id) {
                $this->set_table('qleads_queues', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function update_queuing($data, $id) {
                $this->set_table('qleads_queuing', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        
        public function delete_queue($data, $id)
	{
                $this->set_table('qleads_queues', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
        public function update_token($data, $id) {
                $this->set_table('qleads_tokens ', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
}