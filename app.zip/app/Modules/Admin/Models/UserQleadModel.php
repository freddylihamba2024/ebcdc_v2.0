<?php

namespace Modules\Admin\Models;

use App\Models\MY_Qleads;
use stdClass;

class UserQleadModel extends MY_Qleads
{

        /* Presentation: 
         * Last update
         * By Glodi on the 05.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_users'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Userid_7', 'Authorization_8', 'Branchid_9', 'Tellercode_10', 'Queueid_11', 'Makerid_12', 'Checkerid_13', 'Gender_14', 'Education_15', 'Education_15', 'Birthyear_16', 'Parent_18'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;

        public $role = array(
                ''  => '',
                '1' => 'Administrateurs',
                '2' => 'Superviseur',
                '3' => 'Validateur (Checkers)',
                '4' => 'Operateurs (Makers)',
                '5' => 'Consultation',
        );
        
        public $authorization = array(
                ''  => '',
                '1' => 'Operateurs (Makers)',
                '2' => 'Validateur (Checkers)',
                '3' => 'Superviseur',
                '4' => 'Advisor',
                '5' => 'Directeur'
        );

        public $fonction = array(
                '1' => 'Administrateurs',
                '2' => 'Directeur g&eacute;n&eacute;ral',
                '3' => 'Directeur',
                '4' => 'Controlleur',
        );

        public $status = array(
                '1' => 'Actif',
                '2' => 'Inactif',
                '3' => 'Suspendu'
        );
        
        public $studies_level = array(
                ''  => '',
                '1' => 'BAC',
                '2' => 'BAC+3',
                '3' => 'Bac+4',
                '4' => 'BAC+5',
                '5' => 'BAC+6'
        );
        
        public $status_marital = array(
               ''  => '',
                'O' => 'Non marié(e)',
                '1' => 'Marié(e)',
        );
        
        public $status_parental = array(
                ''  => '',
                'O' => 'Non parent',
                '1' => 'Parent'
        );
        
        public $gender = array(
                ''  => '',
                'O' => 'Masculin',
                '1' => 'Féminin'
        );
        
        public $tellers = array(''=> '', 'A' => 'A','B' => 'B','C' => 'C', 'D' => 'D','E' => 'E','F' => 'F','G' => 'G','H' => 'H', 'I' => 'I','J' => 'J','K' => 'K','L' => 'L','M' => 'M','N' => 'N','O' => 'O','P' => 'P','Q' => 'Q','R' => 'R','S' => 'S','T' => 'T','U' => 'U','V' => 'V','W' => 'W','Y' => 'Y','Z' => 'Z');

        
        public $state_Color = array('3' => 'label-danger', '2' => 'label-info', '1' => 'label-completed');
        

        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_user_info($id = NULL)
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Userid_7 = '';
                        $obj->Authorization_8 = '';
                        $obj->Branchid_9 = '';
                        $obj->Tellercode_10 = '';
                        $obj->Queueid_11 = '';
                        $obj->Makerid_12 = '';
                        $obj->Checkerid_13 = '';
                        $obj->Gender_14 = '';
                        $obj->Education_15 = '';
                        $obj->Birthyear_16 = '';
                        $obj->Married_17 = '';
                        $obj->Parent_18 = '';
                        return $obj;
                } else {
                        $this->set_table('qleads_users p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }


        public function get_user_by_profile_id($profile_id = NULL)
        {
                $this->set_table('qleads_users p', 'p.Id_0', 'p.Id_0 DESC');
                $response = $this->get_by(array('Userid_7' => $profile_id), TRUE);
                
                if ($response !== NULL) 
                {
                        return $response;
                } 
                else 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Userid_7 = '';
                        $obj->Authorization_8 = '';
                        $obj->Branchid_9 = '';
                        $obj->Tellercode_10 = '';
                        $obj->Queueid_11 = '';
                        $obj->Makerid_12 = '';
                        $obj->Checkerid_13 = '';
                        $obj->Gender_14 = '';
                        $obj->Education_15 = '';
                        $obj->Birthyear_16 = '';
                        $obj->Married_17 = '';
                        $obj->Parent_18 = '';
                        
                        return $obj;
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $data = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "users") 
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('qleads_users')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Userid_7'];
                        }
                        return $ddmenu;
                }

                elseif ($item == "OBJECT NAME") 
                {
                        $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                        $where = "Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE);
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_privilegies()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Userid_7='" . $user_id . "'";
                
                $query = $this->db->table('qleads_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();

                $privilegy = $query->getRow();

                if(!is_null($privilegy)){
                        $_SESSION['Logiref_role'] = $privilegy->Authorization_8;
                        $_SESSION['Logiref_privileges'] = $privilegy->Authorization_8;
                        $_SESSION['Logiref_province'] = 0;
                        $_SESSION['Logiref_ville'] = 0;
                        $_SESSION['Logiref_agence'] = 0;
                        $_SESSION['Logiref_guichet'] = $privilegy->Branchid_9;
                        $_SESSION['Logiref_groupe'] = 0;
                        $_SESSION['Logiref_service'] = 0;
                        $_SESSION['Logiref_regies'] = 0;
                        $_SESSION['Logiref_user'] = 0;
                        $_SESSION['Logiref_region'] = $privilegy->Region_19;

                        $_SESSION['Qlead_privileges'] = $privilegy->Authorization_8;
                        $_SESSION['Qlead_agence'] = $privilegy->Branchid_9;
                        $_SESSION['Qlead_guichet'] = $privilegy->Tellercode_10;
                        $_SESSION['Qlead_queue'] = $privilegy->Queueid_11;

                        $_SESSION['roles_banks'] = [
                                        '1'=> 'MAKER | OPERATEUR', 
                                        '2'=> 'VALIDATEUR', 
                                        '3'=> 'SUPERVISEUR', 
                                        '4'=> 'CONSEILLER',
                                        '5'=> 'DIRECTEUR'
                                ];
                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_20))?json_decode($privilegy->Option_20):Null;
                        
                }
                else{
                        $_SESSION['Qlead__privileges'] = 0;
                        $_SESSION['Logiref_privileges'] = 0;
                }
                
                return true;
        }

        public function get_users_stats()
        {
                $return = array(
                        'Inactifs' => 0,
                        'Suspendus' => 0,
                        'Actifs' => 0,
                        'Total' => 0
                );

                $this->set_table('qleads_users', 'Id_0', 'Id_0 ASC');
                $return['useres'] = $this->get_by(array('Status_2 !=' => 0, 'Account_3' => $this->session->userdata['account_id']));

                foreach ($return['useres'] as $val) {
                        if ($val->Status_2 == 1)
                                $return['Actifs']++;
                        if ($val->Status_2 == 2)
                                $return['Inactifs']++;
                        if ($val->Status_2 == 3)
                                $return['Suspendus']++;

                        $return['Total']++;
                }
                return $return;
        }

        public function get_members($id = NULL)
        {
                $st = " Userid_13= '" . $id . "' AND Account_3 ='" . $this->session->userdata['account_id'] . "' ";
                if (isset($_POST['Branchid_9']) && $_POST['Branchid_9'] != "") $st .= "AND Branchid_9= '" . $_POST['Branchid_9'] . "' ";

                $query = $this->db->table('qleads_users')
                        ->select('qleads_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_users_by_branchid()
        {
                $st = "Status_2 > '0' AND Account_3='" . $this->session->userdata['account_id'] . "'  AND Branchid_9 ='" . $_SESSION['Branchid'] . "'";
                $query = $this->db->table('qleads_users')
                        ->select('qleads_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }


        public function get_member_by_user_id()
        {
                $this->set_table('qleads_users', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Userid_7' => $this->session->userdata['user_id']));
                return $result;
        }
        
        public function get_usercode_by_agence($data)
        {
                
                $this->set_table('qleads_users g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Tellercode_10' => $data['tellercode'], 'Branchid_9' => $data['branchid']), TRUE);
        }
        
        public function get_usercode_by_userid($data)
        {
                
                $this->set_table('qleads_users g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Id_0' => $data['userid'], 'Tellercode_10' => $data['tellercode'], 'Branchid_9' => $data['branchid']), TRUE);
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        public function save_objects_name($data, $id)
        {
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_users($data, $userid) 
        {
                $this->set_table('qleads_users', 'Userid_7', 'Userid_7 DESC');
                return $this->saveData($data, $userid);               
        }

        public function save_users($data, $id)
        {
                $this->set_table('qleads_users', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        

}
