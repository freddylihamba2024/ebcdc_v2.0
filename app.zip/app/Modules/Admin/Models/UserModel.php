<?php

namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Main;

class UserModel extends MY_Main
{

        /* Presentation:
         * Last update
         * By Glodi on the 05.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';

        public $role = array(
                ''   => '',
                '1'  => 'Administrateurs',
                '2'  => 'Superviseur',
                '3'  => 'Validateur (Checkers)',
                '4'  => 'Operateur (Makers)',
                '5'  => 'Consultation',
                '6'  => 'Controleur',
                '7'  => 'Super Operateur',
                '8'  => 'Super Validateur',
                '9'  => 'Operateur de taux',
                '10' => 'Validateur de taux',
                '11' => 'Guichetier',
        );

        public $fonction = array(
                '1' => 'Administrateurs',
                '2' => 'Directeur g&eacute;n&eacute;ral',
                '3' => 'Directeur',
                '4' => 'Controlleur',
        );

        public $status = array(
                '1' => 'Actif',
                '2' => 'Inactif',
                '3' => 'Suspendu'
        );
        public $state_Color = array('3' => 'label-danger', '2' => 'label-info', '1' => 'label-completed');

        public $teller_codes = array(''=> '', 'A' => 'A','B' => 'B','C' => 'C', 'D' => 'D','E' => 'E','F' => 'F','G' => 'G','H' => 'H', 'I' => 'I','J' => 'J','K' => 'K','L' => 'L','M' => 'M','N' => 'N','O' => 'O','P' => 'P','Q' => 'Q','R' => 'R','S' => 'S','T' => 'T','U' => 'U','V' => 'V','W' => 'W','Y' => 'Y','Z' => 'Z');


        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_user_info($id = NULL)
        {
                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Role_4 = '';
                        $obj->Province_5 = '';
                        $obj->Ville_6 = '';
                        $obj->Agence_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Profile_9 = '';
                        $obj->Service_10 = '';
                        $obj->Regies_11 = '';
                        $obj->Code_12 = '';
                        $obj->Userid_13 = '';
                        $obj->Maker_14 = '';
                        $obj->Checker_15 = '';
                        $obj->Validation_16 = '';
                        $obj->Login_17 = '';
                        $obj->Password_18 = '';
                        $obj->Statusvalidate_19 = '';
                        return $obj;
                } else {
                        $this->set_table('logiref_users p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }


        public function get_user_by_profile_id($profile_id = NULL)
        {
                $this->set_table('logiref_users p', 'p.Id_0', 'p.Id_0 DESC');
                $response = $this->get_by(array('Userid_13' => $profile_id), TRUE);

                if ($response !== NULL) {
                        return $response;
                } else {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Role_4 = '';
                        $obj->Province_5 = '';
                        $obj->Ville_6 = '';
                        $obj->Agence_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Profile_9 = '';
                        $obj->Service_10 = '';
                        $obj->Regies_11 = '';
                        $obj->Code_12 = '';
                        $obj->Userid_13 = '';
                        $obj->Maker_14 = '';
                        $obj->Checker_15 = '';
                        $obj->Validation_16 = '';
                        $obj->Login_17 = '';
                        $obj->Password_18 = '';
                        $obj->Statusvalidate_19 = '';
                        return $obj;
                }
        }


        public function get_profile_info($id = NULL)
        {
                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Identifier_7 = '';
                        $obj->Encryption_8 = '';
                        $obj->Firstname_9 = '';
                        $obj->Lastname_10 = '';
                        $obj->Middlename_11 = '';
                        $obj->Cellphone_12 = '';
                        $obj->Language_14 = '';
                        $obj->Gender_15 = '';
                        $obj->Profile_16 = '';
                        $obj->Birthday_17 = '';
                        $obj->Position_18 = '';
                        $obj->Logout_20 = '';
                        $obj->Lastotp_21 = '';
                        $obj->Lastsession_23 = '';
                        $obj->Lastpassword_24 = '';
                        $obj->Environment_25 = '';
                        return $obj;
                } else {
                        $this->set_table('main_profiles p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $data = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "users") {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['Userid_13'];
                        }
                        return $ddmenu;
                }

                if ($item == "operators") {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Role_4 = 4 AND Guichet_8 = '" . $_SESSION['Logiref_guichet'] . "' ";
                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row) {
                                if (isset($data[$row['Userid_13']])) $ddmenu[$row['Userid_13']] = $data[$row['Userid_13']];
                        }
                        return $ddmenu;
                } elseif ($item == "OBJECT NAME") {
                        $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                        $where = "Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE);
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_privilegies()
        {
                if(isset($_SESSION['userdata']['account_id'])) $account_id = $this->session->userdata['account_id']; else $account_id = '';
                if(isset($_SESSION['userdata']['user_id'])) $user_id = $this->session->userdata['user_id']; else $user_id = '';
                
                
                $st = "Account_3 ='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                $privilegy = $query->getRow();
                
                if (!is_null($privilegy)) {
                        
                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                        $_SESSION['roles_banks'] = [
                                        '1' => 'ADMINISTRATEUR', 
                                        '2' => 'SUPERVISEUR', 
                                        '3' => 'VALIDATEUR', 
                                        '4' => 'OPERATEUR',
                                        '5' => 'CONSULTATION',
                                        '6' => 'CONTROLEUR',
                                        '7' => 'SUPER OPERATEUR',
                                        '8' => 'SUPER VALIDATEUR',
                                        '9' => 'OPERATEUR DE TAUX',
                                        '10' => 'VALIDATEUR DE TAUX',
                                        '11' => 'GUICHETIER'
                        ];
                        
                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_22))?json_decode($privilegy->Option_22):Null;
                         
                        //Get Guichet
                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                        $_SESSION['Guichet_code'] = "";

                        if ($guichet != NULL) {
                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                        }

                } 
                else {
                        $_SESSION['Logiref_privileges'] = 0;
                }

                return true;
        }

        public function get_user_connected()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $st = "Account_3='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();

                return $query->getRow();
        }

        public function get_users_stats()
        {
                $return = array(
                        'Inactifs' => 0,
                        'Suspendus' => 0,
                        'Actifs' => 0,
                        'Total' => 0
                );

                $this->set_table('logiref_users', 'Id_0', 'Id_0 ASC');
                $return['useres'] = $this->get_by(array('Status_2 !=' => 0, 'Account_3' => $this->session->userdata['account_id']));

                foreach ($return['useres'] as $val) {
                        if ($val->Status_2 == 1)
                                $return['Actifs']++;
                        if ($val->Status_2 == 2)
                                $return['Inactifs']++;
                        if ($val->Status_2 == 3)
                                $return['Suspendus']++;

                        $return['Total']++;
                }
                return $return;
        }

        public function get_members($id = NULL)
        {
                $st = " Userid_13= '" . $id . "' AND Account_3 ='" . $this->session->userdata['account_id'] . "' ";
                if (isset($_POST['agence']) && $_POST['agence'] != "") $st .= "AND Agence_7= '" . $_POST['agence'] . "' ";

                $query = $this->db->table('logiref_users')
                        ->select('logiref_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }

        public function get_members_array()
        {
                $query = $this->db->table('logiref_users')
                    ->where("Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
            
                /*$where = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($where, NULL, FALSE);
                $this->db->order_by('Firstname_4');
                $query = $this->db->get('logiref_users');
                $ddmenu = array();
                foreach ($query->result_array() as $row) {
                    $ddmenu[$row['Userid_7']] = $row['Firstname_4'] . ' ' . $row['Lastname_5'];
                }
                return $ddmenu;*/
                return $query;
        }
        
        public function get_users_inactif($guichet)
        {
                $query = $this->db->table('logiref_users')
                    ->where("Status_2=2 AND Guichet_8 = '".$guichet."' AND Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
                return $query;
        }
        
        public function get_users_actif($guichet)
        {
                $query = $this->db->table('logiref_users')
                    ->where("Status_2=1 AND Guichet_8 = '".$guichet."' AND Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
                return $query;
        }

        public function get_member_by_user_id()
        {
                $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Userid_13' => $this->session->userdata['user_id']));
                return $result;
        }

        public function get_sydoniaccount_by_accountid($param)
        {

                $this->set_table('logiref_users ', 'Userid_13', 'Userid_13 DESC');

                return $this->get_by(array('Userid_13 ' => $param), TRUE);
        }

        public function get_customer_subscription($customercode)
        {
                $this->set_table('logiref_rbo_souscriptions s', 's.Id_0', 's.Id_0 DESC');
                return $this->get_by(array('Customercode_8 ' => $customercode), TRUE);
        }



        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        public function save_objects_name($data, $id)
        {
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_users($data, $ids)
        {
                $this->db->where("logiref_users.Userid_13 IN (" . $ids . ")");
                return $this->db->update('logiref_users', $data);
        }

        public function save_users($data, $id)
        {
                $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_subscriptions($data, $id)
        {
                $this->set_table('logiref_rbo_souscriptions', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}