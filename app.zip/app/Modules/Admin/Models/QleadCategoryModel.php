<?php
namespace Modules\Admin\Models;

use App\Models\MY_Qleads;
use stdClass;

class QleadCategoryModel extends MY_Qleads {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_categories'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Object_7', 'Title_8', 'Description_9', 'Categoryid_10', 'Maxtime_11', 'Eform_12', 'Makerid_13', 'Checkerid_14'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        

        public $types = array(
            '' => '',
            'Token' => 'Token',
            'Request' => 'Request',
        );

        public function __construct()
        {
                parent::__construct();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_categorie_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Object_7 = '';
                        $obj->Title_8 = '';
                        $obj->Description_9 = '';
                        $obj->Categoryid_10 = '';
                        $obj->Maxtime_11 = '';
                        $obj->Eform_12 = '';
                        $obj->Makerid_13 = '';
                        $obj->Checkerid_14 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('qleads_categories g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="categories")
                {   
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('qleads_categories')
                                                ->where($st)
                                                ->orderBy('Title_8')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
                elseif($item=="category")
                {   
                        $st = "Status_2 > '0' AND Object_7 = 'Request'  AND Categoryid_10 = '0' ";
                        $query = $this->db->table('qleads_categories')
                                                ->where($st)
                                                ->orderBy('Title_8')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Title_8'];
                        }
                        return $ddmenu;
                }
                elseif($item=="subcategory")
                {
                        $st = " Status_2!='0' AND Object_7 = 'Request' AND Categoryid_10 != '0' ";

                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {

                                $ddmenu[$row['Categoryid_10']] = $row['Title_8'];

                        }
                        
                        return $ddmenu;
                }
                elseif($item=="sub_categories")
                {
                        //$st = " Status_2!='0' AND Object_7 = 'Request' AND Categoryid_10 != '0' ";
                        $st = " Status_2!='0' AND Object_7 = 'Request' ";

                        $query = $this->db->table('qleads_categories')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        
                        foreach ($query->getResultArray() as $row) 
                        {
                                    $ddmenu[$row['Id_0']] = $row['Title_8'];
//                                if ($row['Categoryid_10'] == 0):
//                                        $ddmenu[$row['Id_0']] = $row['Title_8'];
//                                else:
//                                       $ddmenu[$row['Id_0']] = $row['Title_8'];
//                                endif;
                        }
                        
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_categories($type=NULL)
        {
                $st = "Status_2 > '0' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('qleads_categories')
                        ->select('qleads_categories.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        
        
        public function get_subcategorie_by_categorie($categorieId = NULL)
        {
                $st = "Status_2 !=0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                
                if($categorieId != NULL)
                {
                        $st .= " AND Categoryid_10 ='" . $categorieId . "'";
                }
                
                $query = $this->db->table('qleads_categories')
                        ->select('qleads_categories.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_categorie($data, $id) {
                $this->set_table('qleads_categories', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function delete_categorie($data, $id)
	{
                $this->set_table('qleads_categories', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
}