<?php

namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Main;

class BankCustomersModel extends MY_Main
{

        /* Presentation:
         * Last update
         * By Glodi on the 05.10.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        protected $_table_name = '';
        protected $_primary_key = '';
        protected $_order_by = '';
        protected $_timestamps = FALSE;
        protected $_date_created = '';
        protected $_date_modified = '';

        public $role = array(
                ''  => '',
                '1' => 'Administrateurs',
                '2' => 'Superviseur',
                '3' => 'Validateur (Checkers)',
                '4' => 'Operateurs (Makers)',
                '5' => 'Consultation',
        );

        public $fonction = array(
                '1' => 'Administrateurs',
                '2' => 'Directeur g&eacute;n&eacute;ral',
                '3' => 'Directeur',
                '4' => 'Controlleur',
        );

        public $type_customers = array(
                '' => '',
                '1' => 'Retail',
                '2' => 'Corporate'
        );

        public $status = array(
                '1' => 'Actif',
                '2' => 'Inactif',
                '3' => 'Suspendu'
        );

        public $state_Color = array('3' => 'label-danger', '2' => 'label-info', '1' => 'label-completed');
        
        public $countries = [
                ''                        => '',
                'AFGHANISTAN'             => 'AFGHANISTAN',
                'RSA'                     => 'AFRIQUE DU SUD',
                'ALBANIE'                 => 'ALBANIE',
                'ALGERIE'                 => 'ALGERIE',
                'ALLEMAGNE'               => 'ALLEMAGNE',
                'ANDORRE'                 => 'ANDORRE',
                'ANGOLA'                  => 'ANGOLA',
                'ANGUILLA'                => 'ANGUILLA',
                'ARABIE SAOUDITE'         => 'ARABIE SAOUDITE',
                'ARGENTINE'               => 'ARGENTINE',
                'ARMENIE'                 => 'ARMENIE',
                'AUSTRALIE'               => 'AUSTRALIE',
                'AUTRICHE'                => 'AUTRICHE',
                'AZERBAIDJAN'             => 'AZERBAIDJAN',
                'BAHAMAS'                 => 'BAHAMAS',
                'BANGLADESH'              => 'BANGLADESH',
                'BARBADE'                 => 'BARBADE',
                'BAHREIN'                 => 'BAHREIN',
                'BELGIQUE'                => 'BELGIQUE',
                'BELIZE'                  => 'BELIZE',
                'BENIN'                   => 'BENIN',
                'BIELORUSSIE'             => 'BIELORUSSIE',
                'BOLIVIE'                 => 'BOLIVIE',
                'BOTSWANA'                => 'BOTSWANA',
                'BHOUTAN'                 => 'BHOUTAN',
                'BOZNIEHERZEGOVINE'       => 'BOZNIEHERZEGOVINE',
                'BRESIL'                  => 'BRESIL',
                'BRUNEI'                  => 'BRUNEI',
                'BULGARIE'                => 'BULGARIE',
                'BURKINA FASO'            => 'BURKINA FASO',
                'BURUNDI'                 => 'BURUNDI',
                'CAMBODGE'                => 'CAMBODGE',
                'CAMEROUN'                => 'CAMEROUN',
                'CANADA'                  => 'CANADA',
                'CAPVERT'                 => 'CAPVERT',
                'CHILI'                   => 'CHILI',
                'CHINE'                   => 'CHINE',
                'CHYPRE'                  => 'CHYPRE',
                'COLOMBIE'                => 'COLOMBIE',
                'COMORES'                 => 'COMORES',
                'REP.CONGO'               => 'REPUBLIQUE DU CONGO',
                'REP.DEM.CONGO'           => 'REPUBLIQUE DEMOCRATIQUE DU CONGO',
                'COREE DU NORD'           => 'COREE DU NORD',
                'COREE DU SUD'            => 'COREE DU SUD',
                'COSTA RICA'              => 'COSTA RICA',
                'COTE DIVOIRE'            => 'COTE DIVOIRE',
                'CROATIE'                 => 'CROATIE',
                'CUBA'                    => 'CUBA',
                'DANEMARK'                => 'DANEMARK',
                'DJIBOUTI'                => 'DJIBOUTI',
                'DOMINIQUE'               => 'DOMINIQUE',
                'EGYPTE'                  => 'EGYPTE',
                'EMIRATS ARABES UNIS'     => 'EMIRATS ARABES UNIS',
                'EQUATEUR'                => 'EQUATEUR',
                'ERYTHREE'                => 'ERYTHREE',
                'ESPAGNE'                 => 'ESPAGNE',
                'ESTONIE'                 => 'ESTONIE',
                'USA'                     => 'ETATSUNIS DAMERIQUE',
                'ETHIOPIE'                => 'ETHIOPIE',
                'FIDJI'                   => 'FIDJI',
                'FINLANDE'                => 'FINLANDE',
                'FRANCE'                  => 'FRANCE',
                'GABON'                   => 'GABON',
                'GAMBIE'                  => 'GAMBIE',
                'GEORGIE'                 => 'GEORGIE',
                'GHANA'                   => 'GHANA',
                'GRECE'                   => 'GRECE',
                'GRENADE'                 => 'GRENADE',
                'GUATEMALA'               => 'GUATEMALA',
                'GUINEE'                  => 'GUINEE',
                'GUINEE BISSAU'           => 'GUINEE BISSAU',
                'GUINEE EQUATORIALE'      => 'GUINEE EQUATORIALE',
                'GUYANA'                  => 'GUYANA',
                'HAITI'                   => 'HAITI',
                'HONDURAS'                => 'HONDURAS',
                'HONGRIE'                 => 'HONGRIE',
                'INDE'                    => 'INDE',
                'INDONESIE'               => 'INDONESIE',
                'IRAN'                    => 'IRAN',
                'IRAQ'                    => 'IRAQ',
                'IRLANDE'                 => 'IRLANDE',
                'ISLANDE'                 => 'ISLANDE',
                'ISRAEL'                  => 'ISRAEL',
                'ITALIE'                  => 'ITALIE',
                'JAMAIQUE'                => 'JAMAIQUE',
                'JAPON'                   => 'JAPON',
                'JORDANIE'                => 'JORDANIE',
                'KAZAKHSTAN'              => 'KAZAKHSTAN',
                'KENYA'                   => 'KENYA',
                'KIRGHIZISTAN'            => 'KIRGHIZISTAN',
                'KIRIBATI'                => 'KIRIBATI',
                'KOWEIT'                  => 'KOWEIT',
                'LAOS'                    => 'LAOS',
                'LESOTHO'                 => 'LESOTHO',
                'LETTONIE'                => 'LETTONIE',
                'LIBAN'                   => 'LIBAN',
                'LIBERIA'                 => 'LIBERIA',
                'LIECHTENSTEIN'           => 'LIECHTENSTEIN',
                'LITUANIE'                => 'LITUANIE',
                'LUXEMBOURG'              => 'LUXEMBOURG',
                'LYBIE'                   => 'LYBIE',
                'MACEDOINE'               => 'MACEDOINE',
                'MADAGASCAR'              => 'MADAGASCAR',
                'MALAISIE'                => 'MALAISIE',
                'MALAWI'                  => 'MALAWI',
                'MALDIVES'                => 'MALDIVES',
                'MALI'                    => 'MALI',
                'MALTE'                   => 'MALTE',
                'MAROC'                   => 'MAROC',
                'MARSHALL'                => 'MARSHALL',
                'MAURICE'                 => 'MAURICE',
                'MAURITANIE'              => 'MAURITANIE',
                'MEXIQUE'                 => 'MEXIQUE',
                'MICRONESIE'              => 'MICRONESIE',
                'MOLDAVIE'                => 'MOLDAVIE',
                'MONACO'                  => 'MONACO',
                'MONGOLIE'                => 'MONGOLIE',
                'MOZAMBIQUE'              => 'MOZAMBIQUE',
                'NAMIBIE'                 => 'NAMIBIE',
                'NAURU'                   => 'NAURU',
                'NEPAL'                   => 'NEPAL',
                'NICARAGUA'               => 'NICARAGUA',
                'NIGER'                   => 'NIGER',
                'NIGERIA'                 => 'NIGERIA',
                'NIOUE'                   => 'NIOUE',
                'NORVEGE'                 => 'NORVEGE',
                'NOUVELLE ZELANDE'        => 'NOUVELLE ZELANDE',
                'OMAN'                    => 'OMAN',
                'OUGANDA'                 => 'OUGANDA',
                'OUZBEKISTAN'             => 'OUZBEKISTAN',
                'PAKISTAN'                => 'PAKISTAN',
                'PALAU'                   => 'PALAU',
                'PALESTINE'               => 'PALESTINE',
                'PANAMA'                  => 'PANAMA',
                'PAPOUASIE NOUVELLE GUINEE'=> 'PAPOUASIE NOUVELLE GUINEE',
                'PARAGUAY'                => 'PARAGUAY',
                'PAYS BAS'                => 'PAYS BAS',
                'PEROU'                   => 'PEROU',
                'PHILIPPINES'             => 'PHILIPPINES',
                'POLOGNE'                 => 'POLOGNE',
                'PORTUGAL'                => 'PORTUGAL',
                'QATAR'                   => 'QATAR',
                'RCA'                     => 'REPUBLIQUE CENTRAFRICAINE',
                'REP DOMINICAINE'         => 'REPUBLIQUE DOMINICAINE',
                'REP TCHEQUE'             => 'REPUBLIQUE TCHEQUE',
                'ROUMANIE'                => 'ROUMANIE',
                'ROYAUME UNI'             => 'ROYAUME UNI',
                'RUSSIE'                  => 'RUSSIE',
                'RWANDA'                  => 'RWANDA',
                'SAINT CHRISTOPHE ET NIEVES'=> 'SAINT CHRISTOPHE ET NIEVES',
                'SAINTE LUCIE'            => 'SAINTE LUCIE',
                'SAINT MARIN'             => 'SAINT MARIN',
                'SAINT VINCENT ET LES GRENADINES'=> 'SAINT VINCENT ET LES GRENADINES',
                'ILES SALOMON'            => 'ILES SALOMON',
                'SALVADOR'                => 'SALVADOR',
                'SAMOA OCCIDENTALES'      => 'SAMOA OCCIDENTALES',
                'SAO TOME ET PRINCIPE'    => 'SAO TOME ET PRINCIPE',
                'SENEGAL'                 => 'SENEGAL',
                'SERBIE'                  => 'SERBIE',
                'SEYCHELLES'              => 'SEYCHELLES',
                'SIERRA LEONE'            => 'SIERRA LEONE',
                'SINGAPOUR'               => 'SINGAPOUR',
                'SLOVAQUIE'               => 'SLOVAQUIE',
                'SLOVENIE'                => 'SLOVENIE',
                'SOMALIE'                 => 'SOMALIE',
                'SOUDAN'                  => 'SOUDAN',
                'SRI LANKA'               => 'SRI LANKA',
                'SUEDE'                   => 'SUEDE',
                'SUISSE'                  => 'SUISSE',
                'SURINAME'                => 'SURINAME',
                'SWAZILAND'               => 'SWAZILAND',
                'SYRIE'                   => 'SYRIE',
                'TADJIKISTAN'             => 'TADJIKISTAN',
                'TAIWAN'                  => 'TAIWAN',
                'TANZANIE'                => 'TANZANIE',
                'TCHAD'                   => 'TCHAD',
                'THAILANDE'               => 'THAILANDE',
                'TIMOR ORIENTAL'          => 'TIMOR ORIENTAL',
                'TOGO'                    => 'TOGO',
                'TONGA'                   => 'TONGA',
                'TRINITE ET TOBAGO'       => 'TRINITE ET TOBAGO',
                'TUNISIE'                 => 'TUNISIE',
                'TURKMENISTAN'            => 'TURKMENISTAN',
                'TURQUIE'                 => 'TURQUIE',
                'TUVALU'                  => 'TUVALU',
                'UKRAINE'                 => 'UKRAINE',
                'URUGUAY'                 => 'URUGUAY',
                'VANUATU'                 => 'VANUATU',
                'VATICAN'                 => 'VATICAN',
                'VENEZUELA'               => 'VENEZUELA',
                'VIETNAM'                 => 'VIETNAM',
                'YEMEN'                   => 'YEMEN',
                'ZAMBIE'                  => 'ZAMBIE',
                'ZIMBABWE'                => 'ZIMBABWE'
        ];

        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_customer_info($id = NULL)
        {
                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Type_7 = '';
                        $obj->Cif_8 = '';
                        $obj->Company_9 = '';
                        $obj->City_10 = '';
                        $obj->Country_11 = '';
                        $obj->Corporateid_12 = '';
                        $obj->Address_13 = '';
                        $obj->Accounts_14 = '';
                        $obj->Language_15 = '';
                        return $obj;
                } else {
                        $this->set_table('logiref_bank_customers p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_user_info($id = NULL)
        {
                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Customerid_7 = '';
                        $obj->Userid_8 = '';
                        $obj->Firstname_9 = '';
                        $obj->Lastname_10 = '';
                        $obj->Middlename_11 = '';
                        $obj->Gender_12 = '';
                        $obj->Birthday_13 = '';
                        $obj->Nationality_14 = '';
                        $obj->Email_15 = '';
                        $obj->Cellphone_16 = '';
                        $obj->Cellphone_17 = '';
                        $obj->State_18 = '';
                        $obj->City_19 = '';
                        $obj->Address_20 = '';
                        $obj->Document_21 = '';
                        $obj->Documentnumber_22 = '';
                        $obj->Documentstart_23 = '';
                        $obj->Documentend_24 = '';
                        return $obj;
                } else {
                        $this->set_table('logiref_bank_users p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_user_by_customer_id($customer_id = NULL)
        {
                $this->set_table('logiref_bank_users p', 'p.Id_0', 'p.Id_0 DESC');
                $response = $this->get_by(array('Customerid_7' => $customer_id), TRUE);

                if ($response !== NULL)
                {
                        return $response;
                } 
                else 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Customerid_7 = '';
                        $obj->Userid_8 = '';
                        $obj->Firstname_9 = '';
                        $obj->Lastname_10 = '';
                        $obj->Middlename_11 = '';
                        $obj->Gender_12 = '';
                        $obj->Birthday_13 = '';
                        $obj->Nationality_14 = '';
                        $obj->Email_15 = '';
                        $obj->Cellphone_16 = '';
                        $obj->Cellphone_17 = '';
                        $obj->State_18 = '';
                        $obj->City_19 = '';
                        $obj->Address_20 = '';
                        $obj->Document_21 = '';
                        $obj->Documentnumber_22 = '';
                        $obj->Documentstart_23 = '';
                        $obj->Documentend_24 = '';
                        
                        return $obj;
                }
        }

        public function get_profile_info($id = NULL)
        {
                $this->set_table('logiref_bank_profiles  p', 'p.Id_0', 'p.Id_0 DESC');
                $response = $this->get_by(array('Id_0' => $id), TRUE);

                if ($response !== NULL)
                {
                        return $response;
                } 
                else 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Customerid_7 = '';
                        $obj->Role_8 = '';
                        $obj->Branchid_9 = '';
                        $obj->Account_10 = '';
                        $obj->Issignatory_11 = '';
                        $obj->Issignatory_11 = '';
                        $obj->Limitamount_12 = '';
                        $obj->Login_13 = '';
                        $obj->Accessstart_15 = '';
                        $obj->Accessend_16 = '';
                        $obj->Validationlevel_17 = '';
                        $obj->Lastlogin_18 = '';
                        $obj->Logout_19 = '';
                        $obj->Otp_21 = '';
                        $obj->Otptime_22 = '';
                        $obj->Lastotp_23 = '';
                        $obj->Lastpassword_24 = '';
                        $obj->Statutdefaultpwd_26 = '';
                        $obj->Deviceipaddress_27 = '';
                        $obj->Failedattempts_28 = '';
                        $obj->Islocked_29 = '';
                        
                        return $obj;
                }
        }

        public function get_relation_by_user_id($user_id = NULL)
        {
                $this->set_table('logiref_bank_profiles  p', 'p.Id_0', 'p.Id_0 DESC');
                $response = $this->get_by(array('Userid_8' => $user_id), TRUE);

                if ($response !== NULL)
                {
                        return $response;
                } 
                else 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Customerid_7 = '';
                        $obj->Role_8 = '';
                        $obj->Branchid_9 = '';
                        $obj->Account_10 = '';
                        $obj->Issignatory_11 = '';
                        $obj->Issignatory_11 = '';
                        $obj->Limitamount_12 = '';
                        $obj->Login_13 = '';
                        $obj->Accessstart_15 = '';
                        $obj->Accessend_16 = '';
                        $obj->Validationlevel_17 = '';
                        $obj->Lastlogin_18 = '';
                        $obj->Logout_19 = '';
                        $obj->Otp_21 = '';
                        $obj->Otptime_22 = '';
                        $obj->Lastotp_23 = '';
                        $obj->Lastpassword_24 = '';
                        $obj->Statutdefaultpwd_26 = '';
                        $obj->Deviceipaddress_27 = '';
                        $obj->Failedattempts_28 = '';
                        $obj->Islocked_29 = '';
                        
                        return $obj;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $data = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "customers_users") 
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                        $query = $this->db->table('logiref_bank_users')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Customerid_7'];
                        }

                        return $ddmenu;
                }
                elseif ($item == "users")
                {
                        $st = "Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "'";

                        $query = $this->db->table('logiref_bank_users')
                                ->where($st)
                                ->orderBy('Firstname_9')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Firstname_9'] . ' ' . $row['Lastname_10'];
                        }
                        return $ddmenu;
                }
                elseif ($item == "operators")
                {
                        $st = " Status_2!='0' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Role_4 = 4 AND Guichet_8 = '" . $_SESSION['Logiref_guichet'] . "' ";

                        $query = $this->db->table('logiref_users')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();
                        $ddmenu = array();
                        
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row) {
                                if (isset($data[$row['Userid_13']])) $ddmenu[$row['Userid_13']] = $data[$row['Userid_13']];
                        }
                        return $ddmenu;
                } 
                elseif ($item == "OBJECT NAME") 
                {
                        $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                        $where = "Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE);
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        // public function get_customers($uid = NULL, $in = NULL, $notIn = NULL, $role = NULL) {

        //         $account_id = $this->session->userdata['account_id'];
        //         $user_id = $this->session->userdata['user_id'];

        //         $builder = $builder = $this->db->table('logiref_bank_customers')
        //                 ->select('logiref_bank_customers.*, logiref_bank_customers.*, logiref_bank_customers.Id_0 as Id_0, logiref_bank_customers.Status_2 as Status_2, logiref_bank_customers.Id_0 as r_id')
        //                 ->join('logiref_bank_users', 'logiref_bank_customers.Id_0 = logiref_bank_users.Customerid_7', 'left')
        //                 ->where("logiref_bank_customers.Status_2 <>", '0')
        //                 ->where("logiref_bank_users.Status_2 <>", '0')
        //                 ->where("logiref_bank_customers.Account_3", $account_id);

        //         if (isset($_POST['search'])) {
        //                 $builder->like("CONCAT(Firstname_9, ' ', Lastname_10)", $_POST['search'], 'both');
        //         }

        //         if ($uid !== NULL)
        //         {
        //                 $builder->where("logiref_bank_customers.Id_0", $uid);
        //         }

        //         if ($in !== NULL)
        //         {
        //                 $builder->whereIn("logiref_bank_customers.Id_0", explode(',', $in));
        //         }

        //         if ($notIn !== NULL)
        //         {
        //                 $builder->whereNotIn("logiref_bank_customers.Id_0", explode(',', $notIn));
        //         }

        //         $builder->orderBy('logiref_bank_customers.Date_1', 'ASC');
        //         $queryResults = $builder->get()->getResult();

        //         return $queryResults;
        // }

        public function get_customers() 
        {
                $account_id = $this->session->userdata['account_id'];
                $st = " Status_2!='0' AND Account_3='" . $account_id . "' ";

                $query = $this->db->table('logiref_bank_customers')
                        ->select('logiref_bank_customers.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function check_if_customer_exist($bank_id) 
        {
                $this->set_table('logiref_bank_customers s', 's.Id_0', 's.Id_0 DESC');
                return $this->get_by(array('Cif_8 ' => $bank_id), TRUE);
        }

        public function get_relation_by_login($login)
        {
                $account_id = $this->session->userdata['account_id'];
                $st = " Status_2 != '0' AND Account_3='" . $account_id . "' AND Login_13='".$login."' ";

                $query  = $this->db->table('logiref_bank_profiles')
                                ->select('logiref_bank_profiles.*')
                                ->where($st)
                                ->orderBy('Id_0', 'DESC')
                                ->limit(1)
                                ->get();
                return $query->getResult();
        }

        public function get_privilegies()
        {
                if(isset($_SESSION['userdata']['account_id'])) $account_id = $this->session->userdata['account_id']; else $account_id = '';
                if(isset($_SESSION['userdata']['user_id'])) $user_id = $this->session->userdata['user_id']; else $user_id = '';
                
                
                $st = "Account_3 ='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                
                $privilegy = $query->getRow();
                
                if (!is_null($privilegy)) {
                        
                        $_SESSION['Logiref_role'] = $privilegy->Role_4;
                        $_SESSION['Logiref_privileges'] = $privilegy->Role_4;
                        $_SESSION['Logiref_province'] = $privilegy->Province_5;
                        $_SESSION['Logiref_ville'] = $privilegy->Ville_6;
                        $_SESSION['Logiref_agence'] = $privilegy->Agence_7;
                        $_SESSION['Logiref_guichet'] = $privilegy->Guichet_8;
                        $_SESSION['Logiref_groupe'] = strtolower($privilegy->Groupe_9);
                        $_SESSION['Logiref_service'] = $privilegy->Service_10;
                        $_SESSION['Logiref_regies'] = $privilegy->Regies_11;
                        $_SESSION['Logiref_user'] = $privilegy->Code_12;
                        $_SESSION['Logiref_region'] = $privilegy->Region_20;
                        $_SESSION['roles_banks'] = [
                                        '1' => 'ADMINISTRATEUR', 
                                        '2' => 'SUPERVISEUR', 
                                        '3' => 'VALIDATEUR', 
                                        '4' => 'OPERATEUR',
                                        '5' => 'CONSULTATION',
                                        '6' => 'CONTROLEUR',
                                        '7' => 'SUPER OPERATEUR',
                                        '8' => 'SUPER VALIDATEUR',
                                ];
                        $_SESSION['Logiref_option'] = (!is_null($privilegy->Option_22))?json_decode($privilegy->Option_22):Null;
                        
                        //Get Guichet
                        $this->set_table('logiref_guichets', 'Id_0', 'Id_0');
                        $guichet = $this->get_by(['Status_2' => 1, 'Account_3' => $account_id, 'Id_0' => $privilegy->Guichet_8], TRUE);
                        $_SESSION['Guichet_code'] = "";

                        if ($guichet != NULL) {
                                $_SESSION['Guichet_code'] = $guichet->Code_10;
                                $_SESSION['main_branch'] = $guichet->Agence_principale_15;
                        }

                } 
                else {
                        $_SESSION['Logiref_privileges'] = 0;
                }

                return true;
        }

        public function get_user_connected()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $st = "Account_3='" . $account_id . "' AND Userid_13='" . $user_id . "'";
                $query = $this->db->table('logiref_users')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();

                return $query->getRow();
        }

        public function get_users_stats()
        {
                $return = array(
                        'Inactifs' => 0,
                        'Suspendus' => 0,
                        'Actifs' => 0,
                        'Total' => 0
                );

                $this->set_table('logiref_users', 'Id_0', 'Id_0 ASC');
                $return['useres'] = $this->get_by(array('Status_2 !=' => 0, 'Account_3' => $this->session->userdata['account_id']));

                foreach ($return['useres'] as $val) {
                        if ($val->Status_2 == 1)
                                $return['Actifs']++;
                        if ($val->Status_2 == 2)
                                $return['Inactifs']++;
                        if ($val->Status_2 == 3)
                                $return['Suspendus']++;

                        $return['Total']++;
                }
                return $return;
        }

        public function get_members($id = NULL)
        {
                $st = " Userid_13= '" . $id . "' AND Account_3 ='" . $this->session->userdata['account_id'] . "' ";
                if (isset($_POST['agence']) && $_POST['agence'] != "") $st .= "AND Agence_7= '" . $_POST['agence'] . "' ";

                $query = $this->db->table('logiref_users')
                        ->select('logiref_users.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }

        public function get_members_array()
        {
                $query = $this->db->table('logiref_users')
                    ->where("Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
            
                /*$where = "Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($where, NULL, FALSE);
                $this->db->order_by('Firstname_4');
                $query = $this->db->get('logiref_users');
                $ddmenu = array();
                foreach ($query->result_array() as $row) {
                    $ddmenu[$row['Userid_7']] = $row['Firstname_4'] . ' ' . $row['Lastname_5'];
                }
                return $ddmenu;*/
                return $query;
        }
        
        public function get_users_inactif($guichet)
        {
                $query = $this->db->table('logiref_users')
                    ->where("Status_2=2 AND Guichet_8 = '".$guichet."' AND Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
                return $query;
        }
        
        public function get_users_actif($guichet)
        {
                $query = $this->db->table('logiref_users')
                    ->where("Status_2=1 AND Guichet_8 = '".$guichet."' AND Account_3='".$this->session->userdata['account_id'] . "'")
                    ->orderBy("Userid_13","DESC")
                    ->get()
                    ->getResultArray();
                return $query;
        }

        public function get_member_by_user_id()
        {
                $this->set_table('logiref_users', 'Id_0', 'Id_0 DESC');
                $result = $this->get_by(array('Userid_13' => $this->session->userdata['user_id']));
                return $result;
        }

        public function get_sydoniaccount_by_accountid($param)
        {

                $this->set_table('logiref_users ', 'Userid_13', 'Userid_13 DESC');

                return $this->get_by(array('Userid_13 ' => $param), TRUE);
        }

        public function get_customer_subscription($customercode)
        {
                $this->set_table('logiref_rbo_souscriptions s', 's.Id_0', 's.Id_0 DESC');
                return $this->get_by(array('Customercode_8 ' => $customercode), TRUE);
        }



        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        public function save_objects_name($data, $id)
        {
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function update_users($data, $ids)
        {
                $this->db->where("logiref_users.Userid_13 IN (" . $ids . ")");
                return $this->db->update('logiref_users', $data);
        }

        public function save_users($data, $id)
        {
                $this->set_table('logiref_bank_users', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_customers($data, $id)
        {
                $this->set_table('logiref_bank_customers', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_profile_users($data, $id)
        {
                $this->set_table('logiref_bank_profiles', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}