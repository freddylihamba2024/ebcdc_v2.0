<?php

namespace Modules\Admin\Models;
use App\Models\MY_Main;
use stdClass;

class SettingsModel extends MY_Main {
	
        /* Presentation: 
         * Last update
         * By
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
        */
    
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
        
        
        public $role = array(
                           ''  =>'',
                           '1' => 'Administrateurs', 
                           '2' => 'Superviseur',
                           '3' => 'Validateur (Checkers)', 
                           '4' => 'Operateurs (Makers)',
                           '5' => 'Consultation',
                       );
        
        public $fonction = array(
                            '1' => 'Administrateurs', 
                            '2' => 'Directeur g&eacute;n&eacute;ral',
                            '3' => 'Directeur', 
                            '4' => 'Controlleur', 
                        );
	
	
        
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * List:
         * *************************************************************************************************************************SCETION 2
        */
        public $status = array(
                            '1' => 'Actifs',
                            '2' => 'Inactifs',
                            '3' => 'Suspendus',
                            '4' => 'A valider',
                            
                        );
        public $state_Color = array('3' => 'label-danger', '2' => 'label-info', '1' => 'label-completed');
        
        public $priorites = array(
                            '1' => 'Priorit&eacute;1',
                            '2' => 'Priorit&eacute;2',
                            '3' => 'Priorit&eacute;3',
                            '4' => 'Priorit&eacute;4',
                            '5' => 'Priorit&eacute;5',
                            '6' => 'Priorit&eacute;6',
                            '7' => 'Priorit&eacute;7',
                            '8' => 'Priorit&eacute;8',
                            '9' => 'Priorit&eacute;9',
                            '10' => 'Priorit&eacute;10'
            
                        );
        
        public function get_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Type_4 = '';
                        $obj->Beneficiaires_5 = '';
                        $obj->Compte_6 = '';
                        $obj->Clef_7 = '';
                        $obj->Devise_8 = '';
                        $obj->Makerid_9 = '';
                        $obj->Validation_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Agence_12 = '';
                        $obj->Recette_13 = '';
                        $obj->Regie_14 = '';
                        $obj->Agenceid_15= '';
                        $obj->Serviceid_16= '';
                        $obj->Nif_17	= '';
                        $obj->Comptesydonia_18	= '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_comptes p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_prepaid_compte_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Nifimportateur_7 = '';
                        $obj->Accountnumber_8 = '';
                        $obj->Refsydonia_9 = '';
                        $obj->Devise_10 = '';
                        $obj->Makerid_11 = '';
                        $obj->Checkerid_12 = '';
                        $obj->Validation_13 = '';
                        
                        return $obj;
                } 
                else
                {
                        $this->set_table('logiref_prepaid_accounts p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_recette_info($oid = NULL) 
        {
                if ($oid == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = $this->session->userdata['account_id'];
                        $obj->Type_4= '';
                        $obj->Beneficiare_5 = '';
                        $obj->Recette_6= '';
                        $obj->Code_7 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_recettes', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_service_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Direction_4 = '';
                        $obj->Service_5 = '';
                        $obj->Description_6='';
                        $obj->Code_7='';
                        $obj->Province_8='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_services', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_beneficiarie_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Type_4 = '';
                        $obj->Description_5 = '';
                        $obj->Comments_6='';
                        $obj->Code_7='';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        public function get_penalite_info($oid= NULL) 
        {
                if($oid == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Priorite_4 = '';
                        $obj->Beneficiaire_5 = '';
                        $obj->Service_6= '';
                        $obj->Recette_7= '';
                        $obj->Guichet_8= '';
                        $obj->Value_9= '';
                        $obj->Unite_10= '';
                        $obj->Min_11= '0';
                        $obj->Max_12= '0';
                        $obj->Devise_13= 'CDF';
                        $obj->Makerid_14= '';
                        $obj->Checkerid_15= '';
                        $obj->Validation_16= '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_penalites', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }
        
        
        public function get_bank_info($id=NULL)
        {
                if($id == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  '';
                        $obj->Creator_4 =  '';
                        $obj->Changes_5 =  '';
                        $obj->Changer_6 =  '';
                        $obj->Denomination_7 =  '';
                        $obj->Itnitials_8 =  '';
                        $obj->Email_9 =  '';
                        $obj->Adresse_10 =  '';
                        $obj->Telephone_11 =  '';
                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_banques', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
    
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 3
        */
        
        public function get_users_stats() 
        {
                $return = array(
                        'Inactifs' => 0,
                        'Suspendus' => 0,
                        'Actifs' => 0,
                        'Total' => 0
                );

                $this->set_table('logiref_users', 'Id_0', 'Id_0 ASC');
                $return['useres']= $this->get_by(array('Status_2 !=' => 0, 'Account_3' => $this->session->userdata['account_id']));

                foreach ($return['useres'] as $val) 
                {
                        if ($val->Status_2 == 1)
                            $return['Actifs']++;
                        if ($val->Status_2 == 2)
                            $return['Inactifs']++;
                        if ($val->Status_2 == 3)
                            $return['Suspendus']++;

                        $return['Total']++;
                }
                return $return;

        }
        
       
        public function get_groups($type=NULL) 
        {
            $st = "Object_4='Role' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
            $builder = $this->db->table('logiref_categories')
                ->select('logiref_categories.*')
                ->where($st)
                ->orderBy('Id_0','ASC')
                ->get();
            return $builder->getResult();
        }
        
        public function get_penalites($type=NULL) 
        {
                if($type== 'toutes')
                {
                    $st ="Checkerid_15 !='0'";
                    $builder = $this->db->table('logiref_penalites')
                        ->select('logiref_penalites.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                    return $builder->getResult();
                }
                else
                {
                    $st = "Status_2='1' AND (Beneficiaire_5='0' OR Beneficiaire_5='" .$_SESSION['Logiref_regies']. "') ";
                    $builder = $this->db->table('logiref_penalites')
                        ->select('logiref_penalites.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                    return $builder->getResult();
                }
        }
        
        #Filtre les donnees dont l'Account n'est pas egale a zero
        public function get_taxes_codes($type=NULL) 
        {

                if($type== 'toutes')
                {
                        $builder = $this->db->table('logiref_recettes')
                                ->select('logiref_recettes.*')
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $st = "Status_2='1' AND (Beneficiare_5='" .$_SESSION['Logiref_regies'] ."')";
                        $builder = $this->db->table('logiref_recettes')
                                ->select('logiref_recettes.*')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
        }

        public function get_services($status=NULL, $param=NULL, $type=NULL, $arg=NULL)
        {
                if($type=='tous')
                {
                        $builder = $this->db->table('logiref_services')
                                ->select('logiref_services.*')
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
                else
                {
                        $st = " Status_2='1' AND (Direction_4='" .$_SESSION['Logiref_regies'] . "')";
                        $builder = $this->db->table('logiref_services')
                                ->select('logiref_services.*')
                                ->where($st)
                                ->orderBy('Id_0','ASC')
                                ->get();
                        return $builder->getResult();
                }
	}
    
        public function get_beneficiaries($type=NULL) 
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $builder = $this->db->table('logiref_beneficiaries')
                        ->select('logiref_beneficiaries.*')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                return $builder->getResult();
        }
        
        #Filtrer les donnees sans tenir comptes de l'Account_3
        public function get_comptes($type=NULL) 
        {
                if($type=='cptes')
                {
                        $st = "C.Status_2='1' AND ( C.Account_3='" . $this->session->userdata['account_id'] . "')"; 
                        $query = $this->db->table('logiref_comptes as C')
                                ->select(' B.Denomination_7, C.Id_0, C.Beneficiaires_5, C.Compte_6, C.Devise_8, C.Type_4, C.Type_4, C.Clef_7, C.Makerid_9, C.Validation_10, C.Checkerid_11, C.Agence_12, C.Recette_13, C.Agenceid_15')
                                ->join('logiref_banques as B', 'C.Account_3 = B.Account_3')   
                                ->where($st)
                                ->get();
                        return $query->result();
                }
                else
                {
                        $st = "C.Status_2='1' AND ( C.Beneficiaires_5='" .$_SESSION['Logiref_regies']. "') ";
                        $query = $this->db->table('logiref_comptes as C')
                                ->select(' B.Denomination_7, C.Id_0, C.Beneficiaires_5, C.Compte_6, C.Devise_8, C.Type_4, C.Type_4, C.Clef_7, C.Makerid_9, C.Validation_10, C.Checkerid_11, C.Agence_12, C.Recette_13, C.Agenceid_15')
                                ->join('logiref_banques as B', 'C.Account_3 = B.Account_3')
                                ->where($st)
                                ->get();
                        return $query->result();
                }

        }
        
        #Filtrer les donnees sans tenir comptes de l'Account_3
        public function get_prepaid_comptes($type=NULL) 
        {
                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "')"; 
                $query = $this->db->table('logiref_prepaid_accounts')
                        ->select('*')
                        ->where($st)
                        ->get();
                return $query->getResult();

        }
        
        #Recuperer la devise par rapport ? un compte
        public function get_comptes_by_parameters($compte = NULL, $devise = NULL, $type = NULL, $beneficiaire = NULL, $agence = NULL, $recette = NULL, $service = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                $array = array('Account_3'=>$account_id,'Type_4'=>$type,'Compte_6'=>$compte, 'Beneficiaires_5'=>$beneficiaire, 'Devise_8'=>$devise, 'Agence_12'=>$agence);
                if(isset($recette))$array["Recette_13"] = $recette;
                if(isset($service))$array["Serviceid_16"] = $service;
                
                return $this->get_by($array, TRUE);
        }
        
        public function get_compte_by_number($data=NULL) 
        {
                $account_id = $this->session->userdata['account_id'];
                
                $this->set_table('logiref_comptes ', 'Id_0', 'Id_0 DESC');
                
                return $this->get_by(array('Compte_6'=>$data,'Account_3' =>$account_id), TRUE);
        }
        public function get_guichets($type=NULL) 
        {
                if($type=='Guichet')
                {
                        $st = "G.Status_2='1' AND ( G.Account_3='" . $this->session->userdata['account_id'] . "')";

                        $query = $this->db->table('logiref_guichets as G')
                                ->select(' B.Denomination_7, G.Id_0, G.Nom_4, G.Agence_5, G.Province_6, G.Ville_7, G.Adresse_8, G.Status_2, G.Observation_9, G.Code_10, G.Checkerid_11, G.Validation_12, G.Makerid_13')
                                ->join('logiref_banques as B', 'G.Account_3 = B.Account_3')
                                ->where($st)
                                ->get();
                        return $query->getResult();
                }
                else
                {
                        $st = "G.Status_2='1' ";

                        $query = $this->db->table('logiref_guichets as G')
                                ->select(' B.Denomination_7, G.Id_0, G.Nom_4, G.Agence_5, G.Province_6, G.Ville_7, G.Adresse_8, G.Status_2, G.Observation_9, G.Code_10, G.Checkerid_11, G.Validation_12')
                                ->join('logiref_banques as B', 'G.Account_3 = B.Account_3')
                                ->where($st)
                                ->get();
                        return $query->getResult();
                }
            
        }
        
        public function get_regles($type=NULL)
        {
                if($type== "rgle")
                {
                        $st = "R.Status_2='1' AND ( R.Account_3='" . $this->session->userdata['account_id'] . "')"; 
                        $query = $this->db->table('logiref_regles as R')
                                ->select(' B.Denomination_7, R.Id_0, R.Priorite_4, R.Beneficiaire_5, R.Service_6, R.Recette_7, R.Guichet_8, R.Value_9, R.Unite_10, R.Min_11, R.Max_12, R.Devise_13,R.Makerid_14, R.Checkerid_15, R.Validation_16')
                                ->join('logiref_banques as B', 'R.Account_3 = B.Account_3')   
                                ->where($st)
                                ->get();
                        return $query->getResult();
                }
                else
                {
                        $st = "R.Status_2='1' AND ( R.Beneficiaire_5='0' OR R.Beneficiaire_5='" .$_SESSION['Logiref_regies']. "') AND (R.Checkerid_15 !='0')";
                        $query = $this->db ->table('logiref_regles as R')
                                ->select(' B.Denomination_7, R.Id_0, R.Priorite_4, R.Beneficiaire_5, R.Service_6, R.Recette_7, R.Guichet_8, R.Value_9, R.Unite_10, R.Min_11, R.Max_12, R.Devise_13,R.Makerid_14, R.Checkerid_15, R.Validation_16')
                                ->join('logiref_banques as B', 'R.Account_3 = B.Account_3')
                                ->where($st)
                                ->get();
                        return $query->getResult();
                }
        }
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * List
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                if($item=="services")
                {
                        $direction = $arg;
                        $province = $data;
                        $classer = $param;
                        $st = "Status_2='1'AND Direction_4='" .$_SESSION['Logiref_regies'] . "'";
                        if($direction != NULL) $st .= " AND Direction_4='" . $direction . "'";
                        if($province != NULL) $st .= " AND Province_8='" . $province . "'";
                        
                        $query = $this->db->table('logiref_services')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        if($classer)
                        {
                                $ddmenu[''][''] = '';
                                foreach ($query->getResultArray() as $row)
                                {
                                        $ddmenu[$row['Direction_4']][$row['Code_7']] = $row['Service_5'] . " (".$row['Code_7'].")";
                                }
                        }
                        else
                        {
                                $ddmenu[1] = 'DGI';
                                $ddmenu[2] = 'DGRAD';
                                $ddmenu[3] = 'DGDA';
                                $ddmenu[4] = 'ESES';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Code_7']] = $row['Service_5'] . " (".$row['Code_7'].")";
                                }
                        }
                        return $ddmenu;
                }
                elseif($item=="beneficiaries")
                {
                        $type = $arg;
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        if($type != NULL)
                        {
                                $st .= " AND Type_4='" . $type . "'";
                        }
                        else
                        {
                                $ddmenu['BKC'][''] = ''; // Banque commerciale
                                $ddmenu['RGF'][''] = ''; // Regies
                                $ddmenu['AIP'][''] = ''; // Autres Institutions Publiques
                        }
                        
                        $query = $this->db->table('logiref_beneficiaries')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $i=0;
                        foreach ($query->getResultArray() as $row) 
                        {
                                if($i==0 && $type=='RGF') $ddmenu['RGF'][''] = '';
                                $ddmenu[$row['Type_4']][$row['Code_7']] = $row['Description_5']." (".$row['Code_7'].")";
                        }
                        $i++;
                        
                        return $ddmenu;
                }
                elseif($item=="recettes")
                {
                        $direction = $arg;
                        #var_dump($direction);die;
                        $type = $data;
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "')";
                        if($direction != NULL) $st .= " AND Beneficiare_5='" . $direction . "'";
                        if($type != NULL) $st .= " AND Type_4='" . $type . "'";
                        
                       
                        $query = $this->db->table('logiref_recettes')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();


                        $ddmenu = array();
                        $ddmenu[''][''] = 'Toutes';
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'];
                        }
                        return $ddmenu;
                }
                elseif($item=="guichets")
                {
                        if($_SESSION['Logiref_groupe']=='banks')
                        {
                            $agence = $arg;
                            $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                            if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                            if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";
                            
                            $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                            $ddmenu = array();
                            $ddmenu[''] = '';
                            foreach ($query->getResultArray() as $row) 
                            {
                                    $ddmenu[$row['Id_0']] = $row['Nom_4'];
                            }
                            return $ddmenu;
                        }
                        else
                        {
                           
                            $st = "Status_2='1'";

                            $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                            $ddmenu = array();
                            $ddmenu[''] = '';
                            foreach ($query->getResultArray() as $row) 
                            {
                                    $ddmenu[$row['Id_0']] = $row['Nom_4'];
                            }
                            return $ddmenu;
                        }
                       
                }
                elseif($item=="groups")
                {
                        $st = "Object_4='Role' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_categories')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Id_0']] = $row['Category_5'];
                        }
                        return $ddmenu;
                }
                elseif($item =="banks")
                {
                        if($arg != NULL && $arg == "account")
                        {
                                $st = "Status_2='1'";

                                $query = $this->db->table('logiref_banques')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Account_3']] = $row['Itnitials_8'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                                $st = "Status_2='1'";
                                
                                $query = $this->db->table('logiref_banques')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Itnitials_8'];
                                }
                                return $ddmenu;
                        }
                        
                }
                elseif($item=="regies")
                {
                        $st = "Status_2='1' AND Type_4 = 'RGF'";

                        $query = $this->db->table('logiref_banques')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Code_7'];
                        }
                        return $ddmenu;
                }
        }
        
        
        public function get_bank_by_accountid($id = NULL)
        {
                $this->set_table('logiref_banques', 'Id_0', 'Id_0 DESC');
                $returns = $this->get_by(array('Account_3' => $id), TRUE);
                if(empty($returns))
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  '';
                        $obj->Creator_4 =  '';
                        $obj->Changes_5 =  '';
                        $obj->Changer_6 =  '';
                        $obj->Denomination_7 =  '';
                        $obj->Itnitials_8 =  '';
                        $obj->Email_9 =  '';
                        $obj->Adresse_10 =  '';
                        $obj->Telephone_11 =  '';
                        $obj->Regies_12 =  '';
                        return $obj;
                }
                else
                {
                        return $returns;
                }
        }
        
        public function get_regie_by_accountid($id = NULL)
        {
                $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                $returns =  $this->get_by(array('Account_3' => $id), TRUE);
                if(empty($returns))
                {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Type_4 = '';
                        $obj->Description_5 = '';
                        $obj->Comments_6='';
                        $obj->Code_7='';
                        return $obj;
                }
                else
                {
                        return $returns;
                }
        }
        
      
        
        public function tcheck_prepaid_account($account=NULL, $devise=NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_prepaid_accounts ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3' =>$account_id, 'Devise_10'=>$devise, 'Accountnumber_8'=>$account), TRUE);
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * List
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_taxe($data, $id)
	{
		$this->set_table('logiref_recettes', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}	
        
        public function save_service($data, $id) 
        {
                $this->set_table('logiref_services', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
        }
  
        public function save_beneficiairie($data, $id) 
        {
                $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);

        }

        public function save_penalite($data, $id)
        {
                $this->set_table('logiref_penalites', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function save_bank($data, $id)
        {
                $this->set_table('logiref_banques', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}