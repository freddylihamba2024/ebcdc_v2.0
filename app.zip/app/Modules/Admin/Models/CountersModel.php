<?php
namespace Modules\Admin\Models;
use App\Models\MY_Logiref_Sbbos_Main;
use stdClass;

class CountersModel extends MY_Logiref_Sbbos_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'logiref_sbbos_guichets'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Type_4', 'Beneficiaires_5', 'Service_6', 'Recette_7', 'Guichet_8', 'Value_9', 'Unite_10', 'Min_11', 'Max_12', 'Devise_13', 'Makerid_14', 'Checkerid_15', 'Validation_16', 'Typefacture_17', 'Rbo_18', 'Customer_19'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
        public $type = array(
                            ''=>'', 
                            '1' => 'P&eacute;age', 
                            '2' => 'Ev&egrave;nement'
                        );
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_guichet_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Name_7 = '';
                        $obj->Code_8 = '';
                        $obj->Location_9 = '';
                        $obj->Type_10 = '';
                        $obj->Agence_11 = '';
                        $obj->Province_12 = '';
                        $obj->Ville_13 = '';
                        $obj->Description_14 = '';
                        $obj->Credentials_15 = '';
                        
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_guichets p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_caisse_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Reference_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Compte_9 = '';
                        $obj->Name_10 = '';
                        
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_guichets g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="agences")
                {   
                        if($_SESSION['Logiref_groupe']=='banks')
                        {
                                $agence = $arg;
                                
                                if($data == 'ALL')
                                {
                                        $st = "Status_2='1'";
                                }
                                else
                                {
                                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                }
                                
                                if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";
                                
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                                $st = "Status_2='1'";
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="guichets")
                {
                        $province = $arg;
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        
                        if (isset($province) && $province != "") $st = " Province_12='".$province."' ";

                        $query = $this->db->table('logiref_sbbos_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Name_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="guichets_toll")
                {
                        if($arg != "")
                        {
                                $st = "Status_2='1' AND Type_10 = '1' AND (Account_3='" .$arg. "' OR Account_3='0')";
                                $query = $this->db->table('logiref_sbbos_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';

                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Name_7'];
                                }
                                return $ddmenu;
                        }
                        else 
                        {
                                $st = "Status_2='1' AND Type_10 = '1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                $query = $this->db->table('logiref_sbbos_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();

                                $ddmenu[''] = '';

                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Name_7'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="guichets_events")
                {
                        if($arg != "")
                        {
                                $st = "Status_2='1' AND Type_10 = '2' AND (Account_3='" .$arg. "' OR Account_3='0')";
                                $query = $this->db->table('logiref_sbbos_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Name_7'];
                                }
                                return $ddmenu;
                        }
                        else 
                        {
                                $st = "Status_2='1' AND Type_10 = '2' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                                $query = $this->db->table('logiref_sbbos_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->result_array() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Name_7'];
                                }
                                return $ddmenu;
                        }
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_agences($type=NULL)
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('logiref_agences')
                        ->select('logiref_agences.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_branches($type=NULL)
        {
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Agence_5='" . $_SESSION['Logiref_agence'] . "'";
                $query = $this->db->table('logiref_guichets')
                        ->select('logiref_guichets.*')
                        ->where($st)
                        ->orderBy('Id_0', 'ASC')
                        ->get();

                return $query->getResult();
        }
        
        
        
        public function get_guichets($type=NULL) 
        {
                $st = "Status_2='1' "; 
                $query = $this->db->table('logiref_sbbos_guichets')
                        ->select('logiref_sbbos_guichets.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        
        
        
        #Checks if an agency has already been created with the entered code
        public function get_code_exists($code = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_guichets ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3'=>$account_id,'Code_8'=>$code), TRUE);
        }
        
        #Checks if the book has already been created with the entered account
        public function get_caisse_exists($account = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_sbbos_guichets ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3'=>$account_id,'Compte_9'=>$account), TRUE);
        }
        
        public function get_credentials($counter)
        {
                $this->set_table('logiref_sbbos_guichets ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Id_0 '=>$counter), TRUE);
        }
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_branche($data, $id) 
        {
                $this->set_table('logiref_sbbos_guichets', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        
        public function save_caisse($data, $id) 
        {
                $this->set_table('logiref_sbbos_guichets', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}