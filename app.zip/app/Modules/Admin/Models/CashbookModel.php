<?php
namespace Modules\Admin\Models;
use App\Models\MY_Logiref_Sbbos_Main;
use stdClass;

class CashbookModel extends MY_Logiref_Sbbos_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'logiref_sbbos_cashbooks'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;

        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Beginning_7', 'End_8', 'Agence_9', 'Tickets_10', 'Guichet_11', 'User_12', 'Reference_13'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        
        
        public function get_cashbook_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Beginning_7 = '';
                        $obj->End_8 = '';
                        $obj->Agence_9 = '';
                        $obj->Tickets_10 = '';
                        $obj->Guichet_11 = '';
                        $obj->User_12 = '';
                        $obj->Reference_13 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_cashbooks c', 'p.Id_0', 'c.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        public function get_airport_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Name_7 = '';
                        $obj->Price_8 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('logiref_sbbos_airport c', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="cashbooks")
                {   
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_cashbooks')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                
                elseif($item=="cashbook")
                {   
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        $query = $this->db->table('logiref_sbbos_cashbooks')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Reference_13'];
                        }
                        return $ddmenu;
                }
                
        }
        
        
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_cashbooks($profile = NULL)
        {
                $agence = $_SESSION['Logiref_guichet'];
                $counter = $_SESSION['Logiref_branch'];
                
                $this->db->select('logiref_sbbos_cashbooks.*', 'logiref_sbbos_cashbooks.Id_0 ASC');
                $this->db->from('logiref_sbbos_cashbooks');
                
                if($_SESSION['Logiref_role'] < '3')
                {
                        $st = "Status_2='1' AND  Account_3='" . $_SESSION['account_id'] . "' ";
                }
                else
                {
                        $st = "Status_2='1' AND  Account_3='" . $_SESSION['account_id'] . "' AND  Guichet_11 = '".$counter."' ";
                }
                
                $query = $this->db->table('logiref_sbbos_cashbooks')
                        ->select('logiref_sbbos_cashbooks.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_cashbook_to_sell()
        {
                $counter = $_SESSION['Logiref_branch'];
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' AND  Guichet_11 = '".$counter."' AND Quantity_14 > 0 ";
                
                $query = $this->db->table('logiref_sbbos_cashbooks')
                        ->select('logiref_sbbos_cashbooks.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->limit(1)
                        ->get();

                return $query->getResult();
        }
        
        
        public function get_movements_gucihet()
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $day = gmdate('Y-m-d');
                $agence = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2='1' AND Account_3='" . $account_id . "' AND Date_1 LIKE '%" . $day. "%' AND Agence_13 ='" . $agence. "'";
                 
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
      
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
        public function save_cashbook($data, $id) {
                $this->set_table('logiref_sbbos_cashbooks', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function update_ticket_number($data, $id) {
                $this->set_table('logiref_sbbos_cashbooks', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
}