<?php
namespace Modules\Admin\Models;

use App\Models\MY_Qleads;
use stdClass;

class QleadEquipmentModel extends MY_Qleads {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $table            = 'qleads_devices'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Creator_4', 'Changes_5', 'Changer_6', 'Type_7', 'Code_8', 'Branchid_9', 'Tellercode_10', 'Queueid_11', 'Makerid_12', 'Checkerid_13'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;

        public $type_devices = [''=> '', '1' => 'Écran','2' => 'Kiosque'];

        public function __construct()
        {
                parent::__construct();
        }
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_equipment_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Type_7 = '';
                        $obj->Code_8 = '';
                        $obj->Branchid_9 = '';
                        $obj->Tellercode_10 = '';
                        $obj->Queueid_11 = '';
                        $obj->Makerid_12 = '';
                        $obj->Checkerid_13 = '';
                        return $obj;
                } 
                else 
                {
                        $this->set_table('qleads_devices g', 'g.Id_0', 'g.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                if($item=="equipments")
                {   
                        $st = "Status_2 = '1' AND Type_7='1' ";
                        $query = $this->db->table('qleads_devices')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Code_8'];
                        }
                        
                        return $ddmenu;
                }
                elseif($item=="equipment_branch")
                {   
                        $branch = $arg; 
                        
                        $st = "Status_2 = '1' AND Type_7='1' AND Branchid_9='".$branch."' ";
                        $query = $this->db->table('qleads_devices')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Code_8'];
                        }
                        
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_equipments($type=NULL)
        {
                $st = "Status_2 > 0 AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                $query = $this->db->table('qleads_devices')
                        ->select('qleads_devices.*')
                        ->where($st)
                        ->orderBy('Id_0', 'DESC')
                        ->get();

                return $query->getResult();
        }
        
        public function get_equipment_by_device($code)
        {
                $this->set_table('qleads_devices g', 'g.Id_0', 'g.Id_0 DESC');
                return $this->get_by(array('Code_8' => $code), TRUE);
        }
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_equipment($data, $id) {
                $this->set_table('qleads_devices', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        
        public function delete_equipment($data, $id)
	{
                $this->set_table('qleads_devices', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}
        
}