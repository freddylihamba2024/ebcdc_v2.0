<?php
namespace Modules\Admin\Models;
use App\Models\MY_Main;
use stdClass;

class BranchModel extends MY_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';

        protected $table            = 'logiref_guichets'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Nom_4', 'Agence_5', 'Province_6', 'Ville_7', 'Adresse_8', 'Observation_9', 'Code_10', 'Checkerid_11', 'Validation_12', 'Offices_13', 'Makerid_13', 'Offices_14'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_guichet_info($id = NULL)
        {
                if ($id == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Nom_4 = '';
                        $obj->Agence_5 = '';
                        $obj->Province_6 = '';
                        $obj->Ville_7 = '';
                        $obj->Adresse_8 = '';
                        $obj->Observation_9 = '';
                        $obj->Code_10 = '';
                        $obj->Checkerid_11 = '';
                        $obj->Validation_12 = '';
                        $obj->Region_14  = '';
                        $obj->Latitude_15  = '';
                        $obj->Longitude_16  = '';
                        $obj->Files_17  = '';
                        $obj->Agence_principale_15  = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_guichets p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="guichets")
                {   
                        if($arg=="force")
                        {
                                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                
                                return $ddmenu;
                        }
                        elseif($arg=="regions")
                        {
                                $regions = $data;
                                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Region_14='" .$regions. "' ";
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                
                                return $ddmenu;
                        }
                        elseif($arg=="ville")
                        {
                                $ville = $data;
                                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Ville_7='" .$ville. "' ";
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                
                                return $ddmenu;
                        }
                        elseif($_SESSION['Logiref_groupe']=='banks')
                        {
                                $agence = $arg;
                                $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "')";
                                if($agence != NULL) $st .= " AND Agence_5='" . $agence. "'";
                                if($data != "ALL") $st .= "  AND (Checkerid_11 !='0')";

                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                        else
                        {
                           
                                $st = "Status_2='1'";
                                $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();
                                $ddmenu = array();
                                $ddmenu[''] = '';
                                foreach ($query->getResultArray() as $row) 
                                {
                                        $ddmenu[$row['Id_0']] = $row['Nom_4'];
                                }
                                return $ddmenu;
                        }
                }
                elseif($item=="agences")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                        $query = $this->db->table('logiref_agences')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Nom_4'];
                        }
                        return $ddmenu;
                }
                elseif($item=="villes")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                        $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Ville_7'];
                        }
                        return $ddmenu;
                }
                elseif($item=="regions")
                {
                        $st = "Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";

                        $query = $this->db->table('logiref_guichets')
                                                ->where($st)
                                                ->orderBy('Id_0')
                                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu[$row['Id_0']] = $row['Region_14'];
                        }
                        return $ddmenu;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_agences($type=NULL)
        {
                // $this->_table_name = '';
                // $this->db->select('logiref_agences.*', 'logiref_agences.Id_0 ASC');
                // $this->db->from('logiref_agences');
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                // $this->db->where($st, NULL, FALSE);
                // $this->db->order_by('Id_0 DESC');
                // return $this->get_all();

                $query = $this->db->table('logiref_agences')
                                ->select('logiref_agences.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                return $query->getResult();
        }

        public function get_agence_by_id($id)
        {
                  
                $st = "(Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0') AND Id_0='" .$id. "'";

                $builder = $this->db->table('logiref_agences  as agence');
                $query= $builder->select('agence.Id_0, agence.Nom_4')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getRowArray();
        }
        
        public function get_branches($type=NULL)
        {
            
                // $this->_table_name = '';
                // $this->db->select('logiref_guichets.*', 'logiref_guichets.Id_0 ASC');
                // $this->db->from('logiref_guichets');
                $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "') AND Agence_5='" . $_SESSION['Logiref_agence'] . "'";
                // $this->db->where($st, NULL, FALSE);
                // $this->db->order_by('Id_0');
                // return $this->get_all();

                $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Id_0', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        public function get_guichets($type=NULL) 
        {
                $this->_table_name = '';
                
                if($type=='Guichet')
                {
                        // $this->db->select('logiref_guichets.*', 'logiref_guichets.Date_1 DESC');
                        // $this->db->from('logiref_guichets');
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' "; 
                        // $this->db->where($st, NULL, FALSE);
                        // $this->db->order_by('Date_1 DESC');
                        // return $this->get_all();

                        $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                        return $query->getResult();
                }
                else
                {
                        // $this->db->select('logiref_guichets.*', 'logiref_guichets.Date_1 DESC');
                        // $this->db->from('logiref_guichets');
                        $st = "Status_2='1' "; 
                        // $this->db->where($st, NULL, FALSE);
                        // $this->db->order_by('Date_1 DESC');
                        // return $this->get_all();

                        $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                        return $query->getResult();
                }
            
        }
        
        public function get_branches_by_localization($type=NULL) 
        {

                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Longitude_16 !='' AND Latitude_15!='' ";

                $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }
        
        public function get_branch_by_id($bankid, $id)
        {
                $today = gmdate('Y-m-d');
                  
                $st = "Account_3='" . $bankid . "' AND Id_0='" .$id. "'";

                $query = $this->db->table('logiref_guichets  as guichet')
                        ->select('guichet.Id_0, guichet.Nom_4, guichet.Province_6, guichet.Ville_7')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
	}
        
        
        
        #Checks if an agency has already been created with the entered code
        public function get_code_exists($code = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->set_table('logiref_guichets ', 'Id_0', 'Id_0 DESC');
                return $this->get_by(array('Account_3'=>$account_id,'Code_10 '=>$code), TRUE);
        }
        
        public function get_branche_by_service($service)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Offices_14 LIKE '%".$service."|%' ";
                
                $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                $return = $query->getResult();
                
                if(isset($return[0]->Id_0)) return $return[0]->Id_0;
                else return 0;
        }
        public function get_branche_by_service_2($service)
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Offices_14 LIKE '%".$service."%' ";
                
                $query = $this->db->table('logiref_guichets')
                                ->select('logiref_guichets.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                $result = $query->getResult();
                return $result; 
        }
        
        
        
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
		
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		// ($id >0) || $this->db->where('Id_0', $id);
		return $this->saveData($data, $id);
	}
        
        public function save_branche($data, $id) {
                $this->set_table('logiref_guichets', 'Id_0', 'Id_0 DESC');
                // ($id > 0) || $this->db->where('Id_0', $id);
                return $this->saveData($data, $id);
        }
        

        public function get_reporting_agencies()
        {
                $rows = $this->db->table('logiref_guichets')->select('Id_0, Nom_4')
                        ->where('Account_3', $this->session->userdata['account_id'])
                        ->orderBy('Nom_4', 'ASC')->get()->getResultArray();
                return array_column($rows, 'Nom_4', 'Id_0');
        }
}