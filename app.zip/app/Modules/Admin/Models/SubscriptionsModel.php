<?php

        namespace Modules\Admin\Models;

        use App\Models\MY_Main;
        use stdClass;

        class SubscriptionsModel extends MY_Main
        {
                public const TABLE_SUBSCRIPTIONS = 'logiref_branchless_subscription';
                public const TABLE_ACCOUNTS = 'logiref_branchless_subscription_ribs';
                public const TABLE_USERS = 'logiref_branchless_subscription_users';

                public $subscriptionTypes = array(
                        '' => '',
                        'PERSONAL' => 'Personnel',
                        'BUSINESS' => 'Entreprise',
                );

                public $profileTypes = array(
                        '' => '',
                        'MAKER' => 'Maker',
                        'CHECKER' => 'Checker',
                        'MAKER_CHECKER' => 'Maker & Checker',
                );

                public $statuses = array(
                        '0' => 'Supprime',
                        '1' => 'Actif',
                        '2' => 'Inactif',
                        '3' => 'Suspendu',
                        '4' => 'A valider',
                );

                public function get_subscription_info($id = null)
                {
                        if ($id == null) {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '1';
                                $obj->Account_3 = $this->session->userdata['account_id'] ?? '';
                                $obj->Creator_4 = $this->session->userdata['user_id'] ?? '';
                                $obj->Changes_5 = '';
                                $obj->Changer_6 = '';
                                $obj->Customer_name_7 = '';
                                $obj->Customer_code_8 = '';
                                $obj->Business_name_9 = '';
                                $obj->Nif_10 = '';
                                $obj->Rccm_11 = '';
                                $obj->Taxable_Event_12 = '';
                                $obj->Customer_phone_13 = '';
                                $obj->Customer_email_14 = '';
                                $obj->Country_15 = 'RDC';
                                $obj->Province_16 = '';
                                $obj->City_17 = '';
                                $obj->Address_18 = '';
                                $obj->Subscription_date_19 = gmdate('Y-m-d H:i:s');
                                $obj->Expiration_date_20 = '';
                                $obj->Is_active_21 = 1;
                                $obj->Is_authorized_22 = 0;
                                $obj->Description_23 = '';
                                return $obj;
                        }

                        $this->set_table(self::TABLE_SUBSCRIPTIONS, 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), true);
                }

                public function get_user_info($id = null, $customerId = null)
                {
                        if ($id == null) {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '1';
                                $obj->Account_3 = $this->session->userdata['account_id'] ?? '';
                                $obj->Creator_4 = $this->session->userdata['user_id'] ?? '';
                                $obj->Changes_5 = '';
                                $obj->Changer_6 = '';
                                $obj->Customer_id_7 = $customerId;
                                $obj->Customer_login_9 = '';
                                $obj->Firstname_10 = '';
                                $obj->Lastname_11 = '';
                                $obj->Fullname_12 = '';
                                $obj->Email_13 = '';
                                $obj->Phone_14 = '';
                                $obj->Job_title_15 = '';
                                $obj->Department_16 = '';
                                $obj->Profile_type_17 = 'MAKER';
                                $obj->Authorization_level_18 = 1;
                                $obj->Authorized_19 = 1;
                                $obj->Operation_limit_20 = '0.00';
                                $obj->Daily_limit_21 = '0.00';
                                $obj->Monthly_limit_22 = '0.00';
                                $obj->Max_validation_count_23 = 0;
                                $obj->User_status_24 = 'ACTIVE';
                                $obj->Last_login_25 = '';
                                $obj->Sync_date_26 = '';
                                $obj->Description_27 = '';
                                return $obj;
                        }

                        $this->set_table(self::TABLE_USERS, 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), true);
                }

                public function get_account_info($id = null, $customerId = null)
                {
                        if ($id == null) {
                                $obj = new stdClass();
                                $obj->Id_0 = '';
                                $obj->Date_1 = gmdate('Y-m-d H:i:s');
                                $obj->Status_2 = '1';
                                $obj->Account_3 = $this->session->userdata['account_id'] ?? '';
                                $obj->Creator_4 = $this->session->userdata['user_id'] ?? '';
                                $obj->Changes_5 = '';
                                $obj->Changer_6 = '';
                                $obj->Customer_id_7 = $customerId;
                                $obj->Account_number_9 = '';
                                $obj->Account_name_10 = '';
                                $obj->Account_holder_11 = '';
                                $obj->Currency_12 = 'CDF';
                                $obj->Bank_code_13 = '';
                                $obj->Bank_name_14 = '';
                                $obj->Branch_code_15 = '';
                                $obj->Branch_name_16 = '';
                                $obj->Iban_17 = '';
                                $obj->Swift_code_18 = '';
                                $obj->Account_type_19 = 'CURRENT';
                                $obj->Is_primary_account_20 = 0;
                                $obj->Opening_date_21 = '';
                                $obj->Account_status_22 = 'ACTIVE';
                                $obj->Sync_date_23 = '';
                                $obj->Description_24 = '';
                                return $obj;
                        }

                        $this->set_table(self::TABLE_ACCOUNTS, 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), true);
                }

                public function get_subscriptions()
                {
                        return $this->db->table(self::TABLE_SUBSCRIPTIONS)
                                ->where('Status_2 !=', 0)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getResult();
                }

                public function get_users($customerId)
                {
                        return $this->db->table(self::TABLE_USERS)
                                ->where('Customer_id_7', $customerId)
                                ->where('Status_2 !=', 0)
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getResult();
                }

                public function get_accounts($customerId)
                {
                        return $this->db->table(self::TABLE_ACCOUNTS)
                                ->where('Customer_id_7', $customerId)
                                ->where('Status_2 !=', 0)
                                ->orderBy('Is_primary_account_20', 'DESC')
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getResult();
                }

                public function get_counts($table)
                {
                        $rows = $this->db->table($table)
                                ->select('Customer_id_7, COUNT(Id_0) as total')
                                ->where('Status_2 !=', 0)
                                ->groupBy('Customer_id_7')
                                ->get()
                                ->getResult();

                        $counts = array();
                        foreach ($rows as $row) {
                                $counts[$row->Customer_id_7] = $row->total;
                        }
                        return $counts;
                }

                public function get_services()
                {
                        $query = $this->db->table('logiref_services')
                                ->where('Status_2', 1)
                                ->orderBy('Service_5')
                                ->get();

                        $ddmenu[''][''] = '';
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Direction_4']][$row['Code_7']] = $row['Service_5'] . " (" . $row['Code_7'] . ")";
                        }

                        return $ddmenu;
                }

                public function get_recettes()
                {
                        $query = $this->db->table('logiref_recettes')
                                ->where('Status_2', 1)
                                ->orderBy('Recette_6')
                                ->get();

                        $ddmenu[''][''] = '';
                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Beneficiare_5']][$row['Code_7']] = $row['Recette_6'] . " (" . $row['Code_7'] . ")";
                        }

                        return $ddmenu;
                }

                public function generate_customer_code()
                {
                        $row = $this->db->table(self::TABLE_SUBSCRIPTIONS)
                                ->select('Id_0')
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        $next = $row ? $row->Id_0 + 1 : 1;

                        $date = date('Ymd');

                        return $date . str_pad($next, 6, '0', STR_PAD_LEFT);
                }

                public function generate_customer_login($Customer_id_7)
                {
                        $subscription = $this->db->table(self::TABLE_SUBSCRIPTIONS)
                                ->where('Status_2 !=', 0)
                                ->where('Id_0', $Customer_id_7)
                                ->get()
                                ->getRow();

                        $row = $this->db->table(self::TABLE_USERS)
                                ->select('Id_0')
                                ->orderBy('Id_0', 'DESC')
                                ->get()
                                ->getRow();

                        $next = $row ? $row->Id_0 + 1 : 1;

                        return $subscription->Customer_code_8 . str_pad($next, 4, '0', STR_PAD_LEFT);
                }

                public function build_taxable_event(array $serviceIds, array $recetteIds)
                {
                        $services = $this->indexed_tax_items('logiref_services', 'Direction_4', 'Service_5', 'Code_7', $serviceIds);
                        $recettes = $this->indexed_tax_items('logiref_recettes', 'Beneficiare_5', 'Recette_6', 'Code_7', $recetteIds);

                        return json_encode(array(
                                'services' => $services,
                                'recettes' => $recettes,
                        ));
                }

                public function decode_taxable_event($json)
                {
                        $decoded = json_decode((string) $json, true);
                        if (!is_array($decoded)) {
                                $decoded = array();
                        }

                        return array(
                                'services' => isset($decoded['services']) && is_array($decoded['services']) ? $decoded['services'] : array(),
                                'recettes' => isset($decoded['recettes']) && is_array($decoded['recettes']) ? $decoded['recettes'] : array(),
                        );
                }

                public function get_payload($id)
                {
                        $subscription = $this->get_subscription_info($id);
                        if (empty($subscription)) {
                                return null;
                        }

                        return array(
                                'subscription' => $subscription,
                                'taxable_event' => $this->decode_taxable_event($subscription->Taxable_Event_12),
                                'users' => $this->get_users($id),
                                'accounts' => $this->get_accounts($id),
                        );
                }

                public function extract_codes(array $items): array
                {
                        $codes = [];

                        foreach ($items as $values)
                        {
                                $codes = array_merge($codes, array_keys($values));
                        }

                        return array_unique($codes);
                }

                public function save_subscription($data, $id = null)
                {
                        $this->set_table(self::TABLE_SUBSCRIPTIONS, 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id ?: null, false);
                }

                public function save_user($data, $id = null)
                {
                        $this->set_table(self::TABLE_USERS, 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id ?: null, false);
                }

                public function save_account($data, $id = null)
                {
                        $this->set_table(self::TABLE_ACCOUNTS, 'Id_0', 'Id_0 DESC');
                        return $this->saveData($data, $id ?: null, false);
                }

                public function soft_delete($table, $id)
                {
                        return $this->db->table($table)
                                ->where('Id_0', $id)
                                ->update(array(
                                        'Status_2' => 0,
                                        'Changes_5' => gmdate('Y-m-d H:i:s'),
                                        'Changer_6' => $this->session->userdata['user_id'] ?? 0,
                                ));
                }

                private function indexed_tax_items($table, $regie, $labelField, $codeField, array $ids)
                {
                        $ids = array_values(array_unique(array_filter($ids, static function ($id) {
                                return $id !== '' && $id !== null;
                        })));

                        if (empty($ids)) {
                                return array();
                        }

                        $rows = $this->db->table($table)
                                ->whereIn('Code_7', $ids)
                                ->get()
                                ->getResult();

                        $items = array();

                        foreach ($rows as $row)
                        {
                                $items[$row->{$regie}][$row->{$codeField}] = $row->{$labelField} . '('.$row->{$codeField}.')';
                        }

                        return $items;
                }
        }