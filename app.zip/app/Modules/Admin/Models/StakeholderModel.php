<?php

namespace Modules\Admin\Models;

use App\Models\MY_Main;
use stdClass;

class StakeholderModel extends MY_Main
{

        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        protected $table            = 'logiref_beneficiaries'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Type_4', 'Description_5', 'Comments_6', 'Code_7'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;


        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_beneficiarie_info($oid = NULL)
        {
                if ($oid == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = NULL;
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 =  $this->session->userdata['account_id'];
                        $obj->Type_4 = '';
                        $obj->Description_5 = '';
                        $obj->Comments_6 = '';
                        $obj->Code_7 = '';
                        return $obj;
                } else {
                        $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "beneficiaries") {
                        $type = $arg;
                        $st = "Status_2='1' AND Account_3= '".$account_id."' OR Account_3= 0 ";

                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        if ($type != NULL) {
                                $st .= " AND Type_4='" . $type . "'";
                        } else {
                                $ddmenu['BKC'][''] = ''; // Banque commerciale
                                $ddmenu['RGF'][''] = ''; // Regies
                                $ddmenu['AIP'][''] = ''; // Autres Institutions Publiques
                        }

                        $query = $this->db->table('logiref_beneficiaries')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();

                        // $this->db->where($st, NULL, FALSE);
                        // $this->db->order_by('Id_0');
                        // $query = $this->db->get('logiref_beneficiaries');

                        $i = 0;
                        foreach ($query->getResultArray() as $row) {
                                if ($i == 0 && $type == 'RGF') $ddmenu['RGF'][''] = '';
                                $ddmenu[$row['Type_4']][$row['Code_7']] = $row['Description_5'] . " (" . $row['Code_7'] . ")";
                        }
                        $i++;

                        return $ddmenu;
                } elseif ($item == "beneficiaires") {
                        $st = "Status_2='1'";
                        $query = $this->db->table('logiref_recettes')
                                        ->where($st)
                                        ->orderBy('Id_0')
                                        ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Code_7']] = $row['Beneficiare_5'];
                        }
                        return $ddmenu;
                } elseif ($item == "type_beneficaire") {
                        $category = $arg;

                        if ($category == 'typebenificaire') $st = "Type_4='AIP' || Type_4='RFP' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        if ($category == 'typeinstitut') $st = "Type_4='IPSS'  AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
                        
                        $query = $this->db->table('logiref_beneficiaries')
                                        ->where($st)
                                        ->orderBy('Code_7 ASC')
                                        ->get();


                        $ddmenu = array();
                        $ddmenu[''][''] = '';
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Type_4']][$row['Code_7']] = $row['Description_5'] . " (" . $row['Code_7'] . ")";
                        }
                        return $ddmenu;
                        #var_dump($ddmenu);die;
                } elseif ($item == "OBJECT NAME") {
                        $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                        $where = "Status_2 !='0'";

                        $query = $this->db->table('TABLE_NAME')
                                        ->where($where)
                                        ->orderBy('NAME ASC')
                                        ->get();

                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_beneficiaries($type = NULL)
        {
                if ($type == NULL) $st = "Status_2='1' AND (Account_3='0' OR Account_3='" . $this->session->userdata['account_id'] . "')";
                if ($type != "") $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                
                $query = $this->db->table('logiref_beneficiaries')
                                ->select('logiref_beneficiaries.*')
                                ->where($st)
                                ->orderBy('Date_1', 'ASC')
                                ->get();
                return $query->getResult();
        }



        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */

        //l'ancienne version
        // public function save_beneficiairie($data, $id) 
        // {
        //         $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
	// 	($id >0) || $this->db->where('Id_0', $id);
	// 	return $this->save($data, $id);
        // }

        //Nouvelle version
        public function save_beneficiairie($data, $id)
        {
                $this->set_table('logiref_beneficiaries', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        

        public function save_objects_name($data, $id)
        {
                $this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}
