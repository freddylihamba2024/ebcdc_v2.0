<?php
namespace Modules\Admin\Models;

use App\Models\MY_Main;
use stdClass;

class AuthorizationsModel extends MY_Main {
	
        /* Presentation: Gestion des points de perception (Guichets,..)
         * Last update
         * By Glodi  on the 02.05.2024
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	
        protected $DBGroup = 'mysql_directory';
        protected $table            = 'main_authorizations'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Modules_4', 'Functionnalities_5'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;
        
        public $status_color = array(
            
                    '0'=>'label-ongoing',
                    '1' => 'label-new-order',
                    '2' => 'label-completed',
                    '3' => 'label-cancelled',
                    '4' => 'label-upcoming'
        );
        
        public $status =  array(
                                '0' => 'Supprim&eacute;e',
                                '1' => 'Ferm&eacute;e',
                                '2' => 'Ouverte', 
                                '3' => 'Fermeture en attente', 
                                "4"=>'Ouverture en attente'
                            );
	public $modules =  array(
                                'logiref' => 'Logiref',
                                'etoll' => 'E-toll', 
                                'qleads' => 'Qleads',
                                'eticketing'=>'E-ticketing',
                                'mobile banking'=>'mobile banking',
                                'internet banking'=>'Internet Banking'
                            );

        public $functionnalities =  array(
                                'ops-validator-profile'=>'Operator-Validator profile',
                                'manuel-input-exchange-rate' => 'Manually input exchange rate',
                                'auto-fetch-exchange-rate' => 'Auto-fetch exchange rate',
                                'bcc-fees-deduction' => 'Bcc-fees-deduction', 
                                'Auto-fetch-clients-preferential-rate' => 'Auto-fetch clients preferential rate',
                                'Auto-fetch-clients-bank-fees'=>'Auto-fetch clients bank fees',
                                'change-exchange-rate'=>'Change exchange rate option',
                                'exempt-specific-clients-from-vat'=>'Option to exempt specific clients from VAT',
                                'rounding-for-cash-register-payments'=>'Rounding option for cash register payments'
                            );

        public $regies_financieres =  array(
                                'DGDA' => array(
                                            'pre-payment validation' => 'Pre-Payment Validation', 
                                            'Funds reservation' => 'Funds reservation',
                                            'bcc-fees-deduction-before-validation'=>'Bcc fees deduction before validation',
                                            'operator pre-payment validation'=> 'Operator pre-payment validation',
                                            'bcc-partner-share-compensation'=> 'BCC partner share compensation',
                                            'accounts-fetch-by-dgda-office'=> 'Accounts fetch by DGDA office',
                                            'product-accounts-fetch by the branch code'=>'Product accounts fetch by the branch code',
                                            'breakdown-accounting-by-web-service-validation'=> 'Prepayment accounting by web service',
                                            'breakdown-accounting-by-sftp-file-integration'=> 'Prepayment accounting by sftp file integration',
                                        ),
                                'DGI' => array(
                                            'product-accounts-fetch by the branch code'=>'Product-accounts-fetch by the branch code', 
                                            'license-plate-registration-sales' => 'License plate registration sales',
                                            'license-plate-payment-validation-by-web-service' => 'License plate payment validation by web service',
                                            'amr-b-and-amr-a-payment-processing' => 'AMR-B and AMR-A payment processing',
                                            'bcc-fees-deduction-for-usd-payment' => 'Bcc-fees-deduction for USD payment',
                                        ), 
                                'DGRAD' => array(
                                            'product-accounts-fetch by the branch code'=>'Product accounts fetch by the branch code', 
                                            'bcc-fees-deduction-for-usd-payment' => 'Bcc-fees-deduction for USD payment',
                                            'account-fetch-for-some-specific-taxes' => 'Account fetch for some specific taxes'
                                        )
                            );

	public function __construct()
	{
		parent::__construct();
	}

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_authorization_info($id = NULL) 
        {
                if ($id == NULL) 
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Bankid_7 = '';
                        $obj->Modules_8 = '';
                        $obj->Functionnalities_9 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('main_authorizations a', 'a.Id_0', 'a.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_option_info($id = NULL) 
        {
                if ($id == NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Object_7 = '';
                        $obj->Values_8 = '';
                        $obj->Beneficiaire_9 = '';
                        $obj->Description_10 = '';

                        return $obj;
                }
                else
                {
                        $this->set_table('logiref_options a', 'a.Id_0', 'a.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        /** Technical Oracle options are automatically applied when Oracle is selected. */
        public function get_oracle_options(): array
        {
                $options = \App\Libraries\OracleBankOptions::builtIn();
                $rows = $this->db->table('logiref_options')
                        ->where('Status_2', 1)
                        ->where('Object_7', 'option')
                        ->like('Values_8', 'oracle-', 'after')
                        ->get()->getResultArray();
                foreach ($rows as $row) {
                        if (\App\Libraries\OracleBankOptions::isManaged($row['Values_8'])) {
                                $options[$row['Values_8']] = $row['Description_10'];
                        }
                }
                return $options;
        }

        public function get_authorisations_by_bankid($bankid)
        {
                $this->set_table('main_authorizations a', 'a.Id_0', 'a.Id_0 DESC');
                return $this->get_by(array('Bankid_7' => $bankid), TRUE);
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg=NULL, $data=NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if($item=="accounts")
                {
                        $st = "Status_2 > '0'";
                        $query = $this->db->table('main_accounts')
                                ->where($st)
                                ->orderBy('Id_0')
                                ->get();

                        $ddmenu = array();
                        $ddmenu[''] = '';

                        foreach ($query->getResultArray() as $row)
                        {
                                if($row['Business_7'] != '')
                                {
                                        $ddmenu[$row['Id_0']] = $row['Business_7'];
                                }
                        }
                        return $ddmenu;
                }
                elseif($item=="modules")
                {
                        $st = "Status_2 = '1' AND Object_7 = 'module' ";
                        $query = $this->db->table('logiref_options')
                                ->where($st)
                                ->get();

                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Values_8']] = $row['Description_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="banques")
                {
                        $st = "Status_2 = '1' AND Object_7 = 'banque' ";
                        $query = $this->db->table('logiref_options')
                                ->where($st)
                                ->get();

                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Values_8']] = $row['Description_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="functionnalities")
                {
                        $st = "Status_2 = '1' AND Object_7 = 'option' AND Beneficiaire_9 = '' ";
                        $query = $this->db->table('logiref_options')
                                ->where($st)
                                ->get();

                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Values_8']] = $row['Description_10'];
                        }
                        return $ddmenu;
                }
                elseif($item=="functionnalities_of_bank")
                {
                        $st = "Status_2 = '1' AND (Object_7 = 'option' OR Object_7 = 'banque')";
                        $query = $this->db->table('logiref_options')
                        ->where($st)
                        ->orderBy("Date_1","DESC")
                        ->get();

                        $ddmenu = $query->getResult();
                        return $ddmenu;
                }
                elseif($item=="functionnalities_by_beneficiaries")
                {
                        $st = "Status_2 = '1' AND Object_7 = 'option' AND Beneficiaire_9 != '' ";
                        $query = $this->db->table('logiref_options')
                        ->where($st)
                        ->get();

                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                $ddmenu[$row['Beneficiaire_9']][$row['Values_8']] = $row['Description_10'];
                        }
                        return $ddmenu;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        public function get_bank_account_with_authorizations()
        {
                $builder = $this->db->table('main_accounts');
                $builder->select('main_accounts.*, main_authorizations.*, main_accounts.Id_0 as accountid, main_accounts.Status_2 as Status_2, main_authorizations.Id_0 as Id_0')
                        ->join('main_authorizations', 'main_accounts.Id_0 = main_authorizations.Bankid_7', 'left')
                        ->where("main_accounts.Status_2 !=", '0')
                        ->where("main_authorizations.Status_2 !=", '0');

                $builder->orderBy('main_accounts.Date_1', 'ASC');

                $queryResults = $builder->get()->getResult();

                return $queryResults;
        }

        public function get_logiref_options()
        {
                $st = "Status_2 = 1";

                $query = $this->db->table('logiref_options')
                        ->select('logiref_options.*')
                        ->where($st)
                        ->get();

                return $query->getResult();
        }

        /*
         * Save Information: insert or update an array
         * Use: inserting or updating
         * P.S: Ajoutez vos methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function update_auth($data, $id)
	{
                $this->set_table('main_authorizations', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}

        public function save_auth($data, $id)
	{
                $this->set_table('main_authorizations', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}

        public function save_option($data, $id)
	{
                $this->set_table('logiref_options', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
	}

        public function get_ext_auth_config($account_id): ?object
        {
                $rows = $this->db->table('logiref_options')
                        ->where('Status_2', 1)
                        ->where('Object_7', 'ext_auth_config')
                        ->where('Beneficiaire_9', (string) $account_id)
                        ->get()
                        ->getResult();

                return $this->mapExtAuthConfigRows($rows);
        }

        public function is_external_auth_available(): bool
        {
                $count = $this->db->table('logiref_options')
                        ->where('Status_2', 1)
                        ->where('Object_7', 'ext_auth_config')
                        ->where('Values_8', 'enabled')
                        ->where('Description_10', '1')
                        ->countAllResults();

                return $count > 0;
        }

        public function save_ext_auth_config(string $bankid, array $config): void
        {
                $enabled = !empty($config['enabled']);
                $driver  = strtolower(trim((string) ($config['driver'] ?? '')));

                $this->db->table('logiref_options')
                        ->where('Object_7', 'ext_auth_config')
                        ->where('Beneficiaire_9', $bankid)
                        ->delete();

                $this->db->table('logiref_options')
                        ->where('Object_7', 'ldap_config')
                        ->where('Beneficiaire_9', $bankid)
                        ->delete();

                if ($enabled) {
                        if (!in_array($driver, ['ldap', 'ldaps', 'gateway'])) {
                                throw new \RuntimeException('Driver externe invalide.');
                        }

                        $now = gmdate('Y-m-d H:i:s');
                        $rows = [
                                'enabled' => '1',
                                'driver'  => $driver,
                        ];

                        if (in_array($driver, ['ldap', 'ldaps'])) {
                                $rows['ldap_server'] = trim((string) ($config['ldap_server'] ?? ''));
                                $rows['ldap_port'] = (string) ((int) ($config['ldap_port'] ?? ($driver === 'ldaps' ? 636 : 389)));
                                $rows['ldap_basedn'] = trim((string) ($config['ldap_basedn'] ?? ''));
                                $rows['ldap_username_format'] = trim((string) ($config['ldap_username_format'] ?? 'upn'));
                                $rows['ldap_tls_cacert'] = trim((string) ($config['ldap_tls_cacert'] ?? ''));

                                if ($rows['ldap_server'] === '' || $rows['ldap_basedn'] === '') {
                                        throw new \RuntimeException('Configuration LDAP incomplète.');
                                }
                        }

                        if ($driver === 'gateway') {
                                $rows['gateway_base_url'] = trim((string) ($config['gateway_base_url'] ?? ''));
                                $rows['gateway_country_id'] = trim((string) ($config['gateway_country_id'] ?? ''));
                                $rows['gateway_validate_endpoint'] = trim((string) ($config['gateway_validate_endpoint'] ?? '/api/v1/user/validate-user'));
                                $rows['gateway_userinfo_endpoint'] = trim((string) ($config['gateway_userinfo_endpoint'] ?? '/api/v1/user/get-user-details'));
                                $rows['gateway_timeout'] = (string) ((int) ($config['gateway_timeout'] ?? 10));
                                $rows['gateway_ssl_verify'] = !empty($config['gateway_ssl_verify']) ? '1' : '0';
                                $rows['gateway_appid'] = $this->encryptSecret((string) ($config['gateway_appid'] ?? ''));
                                $rows['gateway_appkey'] = $this->encryptSecret((string) ($config['gateway_appkey'] ?? ''));

                                if (
                                        $rows['gateway_base_url'] === ''
                                        || $rows['gateway_country_id'] === ''
                                        || $rows['gateway_appid'] === ''
                                        || $rows['gateway_appkey'] === ''
                                ) {
                                        throw new \RuntimeException('Configuration Gateway incomplète.');
                                }

                                if (stripos($rows['gateway_base_url'], 'https://') !== 0) {
                                        throw new \RuntimeException('Gateway doit être en HTTPS.');
                                }
                        }

                        foreach ($rows as $key => $value) {
                                $this->db->table('logiref_options')->insert([
                                        'Date_1'         => $now,
                                        'Status_2'       => 1,
                                        'Object_7'       => 'ext_auth_config',
                                        'Values_8'       => $key,
                                        'Beneficiaire_9' => $bankid,
                                        'Description_10' => $value,
                                ]);
                        }
                }

                $auth = $this->db->table('main_authorizations')
                        ->where('Bankid_7', $bankid)
                        ->get()
                        ->getRow();

                if ($auth) {
                        $funcs = json_decode($auth->Functionnalities_9 ?? '{}', true) ?: [];

                        if (!isset($funcs['ALL']) || !is_array($funcs['ALL'])) {
                                $funcs['ALL'] = [];
                        }

                        unset($funcs['ALL']['ldap_auth']);

                        if ($enabled) {
                                $funcs['ALL']['ext_auth'] = [
                                        'enabled' => true,
                                        'driver'  => $driver,
                                ];
                        } else {
                                unset($funcs['ALL']['ext_auth']);
                        }

                        $this->db->table('main_authorizations')
                                ->where('Bankid_7', $bankid)
                                ->update(['Functionnalities_9' => json_encode($funcs)]);
                }
        }

        private function mapExtAuthConfigRows(array $rows): ?object
        {
                if (empty($rows)) {
                        return null;
                }

                $config = new \stdClass();
                $config->account_id = null;
                $config->enabled = false;
                $config->driver = '';
                $config->ldap_server = '';
                $config->ldap_port = 389;
                $config->ldap_basedn = '';
                $config->ldap_username_format = 'upn';
                $config->ldap_tls_cacert = '';
                $config->gateway_base_url = '';
                $config->gateway_country_id = '';
                $config->gateway_validate_endpoint = '/api/v1/user/validate-user';
                $config->gateway_userinfo_endpoint = '/api/v1/user/get-user-details';
                $config->gateway_timeout = 10;
                $config->gateway_ssl_verify = true;
                $config->gateway_appid = '';
                $config->gateway_appkey = '';

                foreach ($rows as $row) {
                        $config->account_id = $row->Beneficiaire_9;
                        switch ($row->Values_8) {
                                case 'enabled':
                                        $config->enabled = $row->Description_10 === '1';
                                        break;
                                case 'driver':
                                        $config->driver = strtolower((string) $row->Description_10);
                                        break;
                                case 'ldap_server':
                                        $config->ldap_server = (string) $row->Description_10;
                                        break;
                                case 'ldap_port':
                                        $config->ldap_port = (int) $row->Description_10;
                                        break;
                                case 'ldap_basedn':
                                        $config->ldap_basedn = (string) $row->Description_10;
                                        break;
                                case 'ldap_username_format':
                                        $config->ldap_username_format = (string) $row->Description_10;
                                        break;
                                case 'ldap_tls_cacert':
                                        $config->ldap_tls_cacert = (string) $row->Description_10;
                                        break;
                                case 'gateway_base_url':
                                        $config->gateway_base_url = (string) $row->Description_10;
                                        break;
                                case 'gateway_country_id':
                                        $config->gateway_country_id = (string) $row->Description_10;
                                        break;
                                case 'gateway_validate_endpoint':
                                        $config->gateway_validate_endpoint = (string) $row->Description_10;
                                        break;
                                case 'gateway_userinfo_endpoint':
                                        $config->gateway_userinfo_endpoint = (string) $row->Description_10;
                                        break;
                                case 'gateway_timeout':
                                        $config->gateway_timeout = (int) $row->Description_10;
                                        break;
                                case 'gateway_ssl_verify':
                                        $config->gateway_ssl_verify = $row->Description_10 === '1';
                                        break;
                                case 'gateway_appid':
                                        $config->gateway_appid = $this->decryptSecret((string) $row->Description_10);
                                        break;
                                case 'gateway_appkey':
                                        $config->gateway_appkey = $this->decryptSecret((string) $row->Description_10);
                                        break;
                        }
                }

                return $config;
        }

        private function encryptSecret(string $value): string
        {
                if ($value === '') {
                        return '';
                }

                $encrypter = \Config\Services::encrypter();
                return base64_encode($encrypter->encrypt($value));
        }

        private function decryptSecret(string $value): string
        {
                if ($value === '') {
                        return '';
                }

                try {
                        $encrypter = \Config\Services::encrypter();
                        return (string) $encrypter->decrypt(base64_decode($value));
                } catch (\Throwable $e) {
                        return '';
                }
        }
}
