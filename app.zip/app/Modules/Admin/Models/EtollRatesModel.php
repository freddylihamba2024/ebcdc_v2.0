<?php

namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Etoll;

class EtollRatesModel extends MY_Etoll {
	
        /* Presentation: 
         * Last update
         * By Papin  on the 25.12.2020
         *  *************************************************************************************************************************SECTION 1
        */
    
        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
	protected $_table_name = '';
	protected $_primary_key = '';
	protected $_order_by = '';
	protected $_timestamps = FALSE;
	protected $_date_created = '';
	protected $_date_modified = '';
	
	
	public function __construct()
	{
		parent::__construct();
	}
        
        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_OBJE_info($oid=NULL)
	{
		if($oid==NULL)
                {
                        $obj = new stdClass();
                        $obj->Id_0='';
                        $obj->Date_1=gmdate('Y-m-d H:i:s');
                        $obj->Status_2='';//0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3='';
                        $obj->Creator_4='';
                        $obj->Changes_5='';
                        $obj->Changer_6='';
                     
                        #Add more here
                        return $obj;
		}
                else
                {
                        $this->set_table('TABLE_OBJ_NAME', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
		}
	}
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item)
        {
                $account_id = $this->session->userdata['account_id'];
                
                if($item=="OBJECT NAME")
                {
                        $query = $this->db->table('main_countries')
                                ->orderBy('Id_0','ASC')
                                ->get();
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->getResultArray() as $row) 
                        {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                }
                
                elseif($item=="OBJECT NAME")
                {
                        $where ="(Account_3='".$account_id."' OR Account_3='0')";
                        $where ="Status_2 !='0'";
                        $query = $this->db->table('TABLE_NAME')
                                ->where($where)
                                ->orderBy('NAME','ASC')
                                ->get();
                        $ddmenu = array();
                        foreach ($query->getResultArray() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }
        
        
        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */
        
        public function get_all_taux($from = NULL, $to = NULL) 
        {
                $to = date('Y-m-d', strtotime($to. ' +1 days'));
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "' AND Checkerid_11 !=0 ";
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                $builder = $this->db->table('logiref_taux')
                        ->select('logiref_taux.*')
                        ->where($st)
                        ->orderBy('logiref_taux.Id_0','DESC')
                        ->limit('100')
                        ->get();
                if ($from != NULL) 
                {
                        $builder = $this->db->table('logiref_taux')
                            ->select('logiref_taux.*')
                            ->where($st)->where('Date_1 >=', $from)
                            ->orderBy('logiref_taux.Id_0','DESC')
                            ->limit('100')
                            ->get();
                }
                if ($to != NULL) {
                        $builder = $this->db->table('logiref_taux')
                            ->select('logiref_taux.*')
                            ->where($st)
                            ->where('Date_1 <=', $to)
                            ->orderBy('logiref_taux.Id_0','DESC')
                            ->limit('100')
                            ->get();
                }
                return $builder->getResult();
        }
        
        public function get_taux($from = NULL, $to = NULL) 
        {
                $month = gmdate('Y-m');
                $st = "Status_2='1' AND  Account_3='" . $this->session->userdata['account_id'] . "'";
                if($_SESSION['Logiref_role']>2)
                {
                        $st .= "AND Agence_8='".$_SESSION['Logiref_agence']."'";
                }
                
                if($from != NULL && $to != NULL)
                {
                        $st .= " AND (Day_9 BETWEEN '" . $from . " AND  '" . $to . "')";
                }
                $builder = $this->db->table('logiref_taux')
                        ->select('logiref_taux.*')
                        ->where($st)
                        ->where("DATE_FORMAT(Day_9,'%Y-%m')", $month)
                        ->orderBy('logiref_taux.Id_0','DESC')
                        ->limit('500')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_exchange_rates() 
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $day = gmdate('Y-m-d');

                $agence = $this->session->get('Logiref_guichet');
                $data_to_validate = false;
                
                # if(isset($_SESSION['Logiref_agence'])) $agence = $_SESSION['Logiref_agence'];
                
                if($_SESSION['Logiref_role'] == 3)
                {
                    $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Date_1 LIKE '%" .$day. "%' AND Agence_13='" .$agence. "' AND Action_12 = 'opening'";
                }
                else
                {
                    #$st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Date_1 LIKE '%" . $day. "%' AND Creator_4= '" . $user_id. "' AND Action_12 = 'opening' ";
                    $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Date_1 LIKE '%" . $day. "%' AND Agence_13= '" . $agence. "' AND Action_12 = 'opening' ";
                }
                
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                $results = $query->getResultArray();
                
                if(!empty($results))
                {
                        
                        $i = 0;
                        
                        foreach ($results as $row) 
                        {
                                //Données BCC
                                if($row['Account_3']==0 && $row['Creator_4']==0 && $row['Changer_6']==0)
                                {
                                        if(empty($_SESSION['Bcc_rates']) || $_SESSION['Bcc_rates'] == 0){
                                                $_SESSION['Bcc_rates'] = json_encode($row);
                                        }
                                        else{
                                                $Bcc_rates = json_decode($_SESSION['Bcc_rates']);
                                                if(!empty($Bcc_rates->Dollar_4)){
                                                        $row['Dollar_4'] = $Bcc_rates->Dollar_4;
                                                        $row['Euro_5'] = $Bcc_rates->Euro_5;
                                                        $row['Rand_6'] = $Bcc_rates->Rand_6;
                                                        $row['Pound_7'] = $Bcc_rates->Pound_7;
                                                }
                                                $row['Bcc_rates'] = json_encode($row);
                                        }
                                }
                                elseif($row['Account_3']==$account_id)
                                {
                                        if($_SESSION['Logiref_role'] == 3 && $row['Changer_6'] == 0)
                                        {
                                                $data_to_validate = true;
                                                $_SESSION['Exchange_rates_tampon'] = 1;
                                                $_SESSION['Bank_rates_not_validated_tampon'] = json_encode($row);
                                        }
                                        if($row['Changer_6']==0)
                                        {
                                                $_SESSION['Exchange_rates'] = 1;
                                                if(empty($_SESSION['Bank_rates_not_validated']) || $_SESSION['Bank_rates_not_validated'] == 0){
                                                        $_SESSION['Bank_rates_not_validated'] = json_encode($row);
                                                }
                                                else{
                                                        $Bank_rates_not_validated = json_decode($_SESSION['Bank_rates_not_validated']);
                                                        if(!empty($Bank_rates_not_validated->Dollar_4)){
                                                                $row['Dollar_4'] = $Bank_rates_not_validated->Dollar_4;
                                                                $row['Euro_5'] = $Bank_rates_not_validated->Euro_5;
                                                                $row['Rand_6'] = $Bank_rates_not_validated->Rand_6;
                                                                $row['Pound_7'] = $Bank_rates_not_validated->Pound_7;
                                                                $row['Id_2'] = $Bank_rates_not_validated->Id_0;
                                                                $_SESSION['Bank_rates_not_validated'] = json_encode($row);
                                                        }
                                                        if(!empty($_SESSION['Bank_rates'])){
                                                                $Bank_rates = json_decode($_SESSION['Bank_rates']);
                                                                if(!empty($Bank_rates->Dollar_4)){
                                                                        $_SESSION['Bank_rates_not_validated'] = 0;
                                                                        $_SESSION['Exchange_rates'] = 2;
                                                                        $Bank_rates->Dollar_7 = $row['Dollar_7'];
                                                                        $Bank_rates->Euro_8 = $row['Euro_8'];
                                                                        $_SESSION['Bank_rates'] = json_encode($Bank_rates);
                                                                }
                                                        }
                                                }
                                        }
                                        else
                                        {
                                                if(empty($_SESSION['Bank_rates']) || $_SESSION['Bank_rates'] == 0){
                                                        $_SESSION['Bank_rates'] = json_encode($row);
                                                }
                                                else{
                                                        $Bank_rates = json_decode($_SESSION['Bank_rates']);
                                                        if(!empty($Bank_rates->Dollar_4)){
                                                                $row['Dollar_4'] = $Bank_rates->Dollar_4;
                                                                $row['Euro_5'] = $Bank_rates->Euro_5;
                                                                $row['Rand_6'] = $Bank_rates->Rand_6;
                                                                $row['Pound_7'] = $Bank_rates->Pound_7;
                                                                $row['Checkerid_11'] = $Bank_rates->Checkerid_11;
                                                        }
                                                        $_SESSION['Bank_rates'] = json_encode($row);
                                                }
                                                $_SESSION['Bank_rates_not_validated'] = 0;
                                                $_SESSION['Exchange_rates'] = 2;
                                        }
                                }
                                
                                $i++;
                        }
                }
                else
                {       
                        $_SESSION['Bank_rates_not_validated'] = 0;
                        $_SESSION['Bcc_rates'] = 0;
                        $_SESSION['Bank_rates'] = 0;

                        if(!empty($_SESSION['Exchange_rates']) && $_SESSION['Exchange_rates'] != 1){
                                $_SESSION['Exchange_rates'] = 2;
                        }
                        else{
                                $_SESSION['Exchange_rates'] = 0;
                        }
                }
                
                if($data_to_validate)
                {
                        $_SESSION['Exchange_rates'] = $_SESSION['Exchange_rates_tampon'];
                        $_SESSION['Bank_rates_not_validated'] = $_SESSION['Bank_rates_not_validated_tampon'];
                }
                
                return true;
        }
        
        
        public function get_opening_exchange_rates_by_guichet($guichet) 
        {
                $account_id = $this->session->userdata['account_id'];
                $user_id = $this->session->userdata['user_id'];
                $day = gmdate('Y-m-d');
                $agence = $guichet;
                
                $st = "Status_2='1' AND (Account_3='" . $account_id . "' OR Account_3='0') AND Date_1 LIKE '%" . $day. "%' AND Guichet_11='" . $agence. "' AND Action_12 = 'opening'";
                $query = $this->db->table('logiref_sbbos_guichet_movements')
                        ->where($st)
                        ->orderBy('Id_0','ASC')
                        ->get();
                
                return $query->getResultArray();
               
        }
        
        public function get_taux_by_filter($agence = NULL, $date_start = NULL, $date_end = NULL)
        {   
            
                if(!empty($agence) || !empty($date_start) || !empty($date_end))
                {
                        if(!empty($agence) && !empty($date_start) && !empty($date_end))
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " AND Agence_8 ='".$agence."'";
                                $builder = $this->db->table('logiref_taux')
                                        ->select('logiref_taux.*')
                                        ->where($st1)
                                        ->where('Day_9 >=', $date_start)
                                        ->where('Day_9 <=', $date_end)
                                        ->order_by('Id_0','ASC')
                                        ->get();

                        }
                        elseif (!empty($agence)) 
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " AND Agence_8 ='".$agence."'";
                                $builder = $this->db->table('logiref_taux')
                                        ->select('logiref_taux.*')
                                        ->where($st1)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                        }
                        elseif (!empty($date_start) && !empty($date_end)) 
                        {
                                $st1 = "Status_2 != '0' AND Account_3=" . $this->session->userdata['account_id'] . " ";
                                $builder = $this->db->table('logiref_taux')
                                        ->select('logiref_taux.*')
                                        ->where($st1)
                                        ->where('Day_9 >=', $date_start)
                                        ->where('Day_9 <=', $date_end)
                                        ->orderBy('Id_0','ASC')
                                        ->get();
                        }
                        return $builder->getResult();
                }
            
        }
        
        public function get_rate_opened_by_userid($user_id)
        {
                $day = gmdate('Y-m-d');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Creator_4 = '".$user_id."' AND Date_1 LIKE '%" .$day. "%' AND Changer_6 = 0";
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        
        public function get_rate_closed_by_userid($user_id)
        {
                $day = gmdate('Y-m-d');
                $st = "Account_3='" . $this->session->userdata['account_id'] . "' AND Creator_4 = '".$user_id."' AND Date_1 LIKE '%" .$day. "%' AND Changer_6 <> 0";
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->select('logiref_sbbos_guichet_movements.*')
                        ->where($st)
                        ->orderBy('Id_0','DESC')
                        ->get();
                return $builder->getResult();
        }
        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
	public function save_taux($data, $id) {
                $this->set_table('logiref_sbbos_guichet_movements', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
        
        public function update_taux($data, $id)
        {
                
                $cond = "Guichet_11='".$id."'";
                $builder = $this->db->table('logiref_sbbos_guichet_movements')
                        ->where($cond)
                        ->like('Date_1', gmdate('Y-m-d'));
                return $builder->update($data);
                
        }
        
	public function save_objects_name($data, $id)
	{
		$this->set_table('TABLE_NAME', 'Id_0', 'Id_0 DESC');
		return $this->saveData($data, $id);
	}
        
}