<?php

namespace Modules\Admin\Models;

use stdClass;
use App\Models\MY_Main;

class FeesModel extends MY_Main
{


        /* Presentation: 
         * Last update
         * By Alvin  on the 10.09.2023
         *  *************************************************************************************************************************SECTION 1
        */

        /*
         * Protected and public variables 
         * Use: forms validation constraintes, dropdowns static array, contextual variable etc
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous variables ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */

        protected $table            = 'logiref_regles'; //Default table name for this model
        protected $primaryKey       = 'Id_0';
        protected $useAutoIncrement = true;
        protected $insertID         = 0;
        protected $returnType       = 'object';
        protected $useSoftDeletes   = false;
        protected $protectFields    = true;
        protected $allowedFields    = ['Date_1', 'Status_2', 'Account_3', 'Type_4', 'Beneficiaires_5', 'Service_6', 'Recette_7', 'Guichet_8', 'Value_9', 'Unite_10', 'Min_11', 'Max_12', 'Devise_13', 'Makerid_14', 'Checkerid_15', 'Validation_16', 'Typefacture_17', 'Customer_19'];

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        // Validation
        protected $validationRules      = [];
        protected $validationMessages   = [];
        protected $skipValidation       = false;
        protected $cleanValidationRules = true;

        public $priorites = array(
                '1' => 'Priorit&eacute;1',
                '2' => 'Priorit&eacute;2',
                '3' => 'Priorit&eacute;3',
                '4' => 'Priorit&eacute;4',
                '5' => 'Priorit&eacute;5',
                '6' => 'Priorit&eacute;6',
                '7' => 'Priorit&eacute;7',
                '8' => 'Priorit&eacute;8',
                '9' => 'Priorit&eacute;9',
                '10' => 'Priorit&eacute;10'

        );

        public $type_documents = array(

                '0' => "",
                'INVDIB' => "Facture banque",
                'GUICE' => "Facture de pr&eacute;d&eacute;douanement",
                'GUICELOG' => "Facture logistique",
                'NP' => "Note de perception ou note de cr&eacute;dit",
        );

        public $type_fees = [
                '' => '',
                'FB' => 'Frais relatifs aux opérations bancaires',
                'FIA' => 'Frais d’impression d’attestation',
                'FDA' => 'Frais de délivrance d’un duplicata d’attestation'
        ];

        public function __construct()
        {
                parent::__construct();
        }

        /*
         * Get Information: return a single item
         * Use: for creation, for display, for updates
         * P.S: Ajoutez vous methodes ci-dessous, si necessaire!!
         * *************************************************************************************************************************SCETION 2
        */
        public function get_regle_info($id = NULL)
        {
                if ($id == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = '';
                        $obj->Account_3 = '';
                        $obj->Priorite_4 = '';
                        $obj->Beneficiaire_5 = '';
                        $obj->Service_6 = '';
                        $obj->Recette_7 = '';
                        $obj->Guichet_8 = '';
                        $obj->Value_9 = '';
                        $obj->Unite_10 = '';
                        $obj->Min_11 = '0';
                        $obj->Max_12 = '0';
                        $obj->Devise_13 = 'CDF';
                        $obj->Makerid_14 = '';
                        $obj->Checkerid_15 = '';
                        $obj->Validation_16 = '';
                        $obj->Compte_20 = '';
                        $obj->Devise_21 = '';
                        $obj->Mode_22 = '';
                        $obj->Type_23 = '';
                        
                        return $obj;
                } else {
                        $this->set_table('logiref_regles p', 'p.Id_0', 'p.Id_0 DESC');
                        return $this->get_by(array('Id_0' => $id), TRUE);
                }
        }

        public function get_exemptcustomer_info($oid = NULL)
        {
                if ($oid == NULL) {
                        $obj = new stdClass();
                        $obj->Id_0 = '';
                        $obj->Date_1 = gmdate('Y-m-d H:i:s');
                        $obj->Status_2 = ''; //0: Deleted, 1: In Progress, 2: Completed
                        $obj->Account_3 = '';
                        $obj->Creator_4 = '';
                        $obj->Changes_5 = '';
                        $obj->Changer_6 = '';
                        $obj->Designation_7 = '';
                        $obj->Montant_8 = '';
                        $obj->Agence_9 = '';
                        $obj->Infos_10 = '';
                        $obj->Codeimport_11 = '';
                        $obj->Validation_12 = '';

                        #Add more here
                        return $obj;
                } else {
                        $this->set_table('logiref_client_exonore', 'Id_0', 'Id_0 DESC');
                        return $this->get_by(array('Id_0' => $oid), TRUE);
                }
        }



        public function get_regles($type = NULL)
        {
                $this->table = '';

                if ($type == "rgle") {
                        // $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        // $this->db->from('logiref_regles');
                        // $this->db->where($st, NULL, FALSE);
                        // $this->db->order_by('Date_1 DESC');
                        // return $this->get_all();

                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' ";
                        $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        return $query->getResult();

                } else {
                        // $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        // $this->db->from('logiref_regles');
                        // $this->db->where($st, NULL, FALSE);
                        // $this->db->order_by('Date_1 DESC');
                        // return $this->get_all();

                        $st = "Status_2='1' AND ( Beneficiaire_5='0' OR Beneficiaire_5='" . $_SESSION['Logiref_regies'] . "') AND Checkerid_15 !='0'";
                        $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Date_1', 'DESC')
                                ->get();
                        return $query->getResult();
                }
        }

        public function get_rbo_regle()
        {
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'  AND Rbo_18 != '0' ";
                $query = $this->db->table('logiref_regles')
                        ->select('logiref_regles.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                return $query->getResult();
        }

        public function get_bank_charges($regie, $service, $recette, $devise, $montant, $guichet)
        {
                $valeur = 0;
                $unite = 0;
                $fees_found = false;

                $account = $this->session->userdata['account_id'];
                
                $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "' AND (Mode_22 <> '5' OR Mode_22 is NULL) ";

                $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Priorite_4', 'DESC')
                                ->get();

                $ddmenu = array();

                foreach ($query->getResultArray() as $row) 
                {   
                       #Priorit� 1
                        if ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12'])) 
                        {
                               $valeur = $row['Value_9'];
                               $unite = $row['Unite_10'];
                               $fees_found = true;
                               
                               break;
                        }
                        #Priorit� 2
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] == 0 && $montant == 0)) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 3
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 4
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 5
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 6
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 7
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 8
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 9
                        elseif ($row['Beneficiaire_5'] == $regie && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 10
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) 
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif (($row['Beneficiaire_5'] == 0 || $row['Beneficiaire_5'] == '') && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                                #Priorit� 10
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 10
                        elseif (($row['Beneficiaire_5'] == 0 || $row['Beneficiaire_5'] == '') && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        else
                        {
                                $fees_found = false;
                        }
                }

                $ddmenu = array('Valeur' => $valeur, 'Unite' => $unite, 'fees_found'=> $fees_found);
             
                return $ddmenu;
        }
        
        public function get_correspondent_fees($regie, $service, $recette, $devise, $montant, $guichet)
        {
                $valeur = 0;
                $unite = 0;
                $fees_found = false;
                
                $account = $this->session->userdata['account_id'];
                
                $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "' AND Mode_22 <> '5' AND Type_23 = 'FCD' ";
                
                $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Priorite_4', 'DESC')
                                ->get();
                $ddmenu = array();
                
                foreach ($query->getResultArray() as $row) {
                    
                        #Priorit� 1
                        if ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12'])) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 2
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet && ($row['Min_11'] == 0 && $montant == 0)) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];

                                break;
                        }
                        #Priorit� 3
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 4
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 5
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && $row['Recette_7'] == $recette && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 6
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;
                                
                                break;
                        }
                        #Priorit� 7
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == $recette && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 8
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Service_6'] == $service && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];

                                break;
                        }
                        #Priorit� 9
                        elseif ($row['Beneficiaire_5'] == $regie && ($row['Min_11'] <= $montant) && ($montant < $row['Max_12']) && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif (($row['Beneficiaire_5'] == 0 || $row['Beneficiaire_5'] == '') && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif ($row['Beneficiaire_5'] == $regie && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        #Priorit� 10
                        elseif (($row['Beneficiaire_5'] == 0 || $row['Beneficiaire_5'] == '') && $row['Recette_7'] == '' && $row['Service_6'] == '' && $row['Min_11'] == 0 && $row['Max_12'] == 0 && $row['Guichet_8'] == $guichet) {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                $fees_found = true;

                                break;
                        }
                        else
                        {
                                $fees_found = false;
                        }
                }
                $ddmenu = array('Valeur' => $valeur, 'Unite' => $unite, 'fees_found'=>$fees_found);

                return $ddmenu;
        }
        
        public function get_customer_charges($regie, $service, $recette, $devise, $montant, $guichet, $compte)
        {
                $valeur = 0;
                $unite = 0;
                $fees_found = false;
                
                if($compte !="")
                {
                        $account = $this->session->userdata['account_id'];
                        $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "' AND Compte_20 = '".$compte."' AND Type_23 != 'FCD' ";

                        $query = $this->db->table('logiref_regles')
                                        ->select('logiref_regles.*')
                                        ->where($st)
                                        ->orderBy('Priorite_4', 'DESC')
                                        ->get();
                        $ddmenu = array();

                        foreach ($query->getResultArray() as $row)
                        {
                                if(isset($row['Value_9']))
                                {
                                        $valeur = $row['Value_9'];
                                        $unite = $row['Unite_10'];
                                        $fees_found = true; 
                                }
                        }
                }
                
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite, 'fees_found'=>$fees_found);
               
                return $ddmenu;
                
        }
        
        public function get_charges_by_paiement_method($regie, $service, $recette, $devise, $montant, $guichet, $mode)
        {
                $valeur = 0;
                $unite = 0;
                $fees_found = false;
                
                if($mode != '')
                {
                        $account = $this->session->userdata['account_id'];

                        $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Devise_13='" . $devise . "' AND Mode_22 = '".$mode."' AND Type_23 != 'FCD' ";

                        $query = $this->db->table('logiref_regles')
                                        ->select('logiref_regles.*')
                                        ->where($st)
                                        ->orderBy('Priorite_4', 'DESC')
                                        ->get();
                        $ddmenu = array();
                        $R = $query->getResultArray();

                        foreach ($query->getResultArray() as $row)
                        {
                                if(isset($row['Value_9']))
                                {
                                        $valeur = $row['Value_9'];
                                        $unite = $row['Unite_10'];
                                        $fees_found = true; 
                                }
                        }
                }
                
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite, 'fees_found'=>$fees_found);
               
                return $ddmenu;
        }

        public function get_charges_by_fees_bcc($regie, $service, $recette, $devise, $montant, $guichet, $type)
        {
                $valeur = 0;
                $unite = 0;
                $account = $this->session->userdata['account_id'];

                if (!empty($devise))
                {
                        //$st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Beneficiaire_5='" . $regie . "' AND Recette_7='" . $recette . "' AND Type_23 = '".$type."'";
                        $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0  AND Recette_7='" . $recette . "' AND Devise_13='".$devise."' AND  Type_23 = '".$type."'";
                }
                else
                {
                        $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Recette_7='" . $recette . "' AND Type_23 = '".$type."'";
                }
                
                
                $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Priorite_4', 'DESC')
                                ->get();
                $ddmenu = array();
                $R = $query->getResultArray();

                foreach ($query->getResultArray() as $row)
                {
                        $montant = (float) $montant;
                        $min = (float) $row['Min_11'];
                        $max = (float) $row['Max_12'];

                        if ($montant != null) 
                        {
                                if (($min <= $montant) && ($montant < $max)) 
                                {
                                        $valeur = $row['Value_9'];
                                        $unite = $row['Unite_10'];
                                        break;
                                }
                        }
                        else
                        {
                                $valeur = $row['Value_9'];
                                $unite = $row['Unite_10'];
                                break;
                        }
                }
                
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite);
               
                return $ddmenu;
        }

        public function get_charges_for_printed_payment($type)
        {
                $valeur = 0;
                $unite = 0;
                $account = $this->session->userdata['account_id'];
                
                $st = "(Account_3='0' OR Account_3='" . $account . "') AND Checkerid_15 <> 0 AND Type_23 = '".$type."'";
                
                $query = $this->db->table('logiref_regles')
                                ->select('logiref_regles.*')
                                ->where($st)
                                ->orderBy('Priorite_4', 'DESC')
                                ->get();
                $ddmenu = array();
                $result = $query->getResultArray();

                foreach ($result as $row)
                {
                        $valeur = $row['Value_9'];
                        $unite = $row['Unite_10'];
                }
                
                $ddmenu = array('Valeur' =>$valeur, 'Unite'=>$unite);
               
                return $ddmenu;
        }

        public function get_exempt_customers_by_clt($clt)
        {
                $account_id = $this->session->userdata['account_id'];

                $this->set_table('logiref_client_exonore I', 'I.Id_0', 'I.Id_0 DESC');
                return $this->get_by(array('Codeimport_11' => $clt, 'Account_3' => $account_id), TRUE);
                //return $this->get_by(array('Codeimport_11' => $clt), TRUE);
        }

        public function get_exempt_customers()
        {
                $account = $_SESSION['account_id'];
                $this->table = '';
                $this->db->select('logiref_client_exonore.*', 'logiref_client_exonore.Id_0 ASC');
                $this->db->from('logiref_client_exonore');
                $st = " Account_3='" . $account . "' AND Status_2='1' ";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('logiref_client_exonore.Id_0 ASC');
                return $this->get_all();
        }

        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * PS: A modifier si necessaire - sinon laissez rien faire ci-dessous !!
         *  *************************************************************************************************************************SECTION 3
        */
        public function get_dropdown($item, $arg = NULL, $data = NULL, $param = NULL)
        {
                $account_id = $this->session->userdata['account_id'];

                if ($item == "OBJECT NAME") {
                        $this->db->order_by('Id_0');
                        $query = $this->db->get('main_countries');
                        $ddmenu_country = array();
                        $ddmenu_country['0'] = ' ';
                        foreach ($query->result_array() as $row) {
                                $ddmenu_country[$row['Id_0']] = $row['Name_2'];
                        }
                        return $ddmenu_country;
                } elseif ($item == "OBJECT NAME") {
                        $where = "(Account_3='" . $account_id . "' OR Account_3='0')";
                        $where = "Status_2 !='0'";
                        $this->db->where($where, NULL, FALSE);
                        $this->db->order_by('NAME');
                        $query = $this->db->get('TABLE_NAME');
                        $ddmenu = array();
                        foreach ($query->result_array() as $row) {
                                $ddmenu[$row['Id_0']] = $row['COL_NAME'];
                        }
                        return $ddmenu;;
                }
        }


        /*
         * Get Information: returns an array
         * Use: for indexation, for dropdon etc
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 4
        */

        public function get_name_objects($status = NULL, $param = NULL, $type = NULL, $arg = NULL)
        {
                $account_id = $this->session->userdata['account_id'];
                $this->db->select('TABLE_NAME.*');
                $this->db->from('TABLE_NAME');
                $this->db->where("TABLE_NAME.Account_3 ='" . $account_id . "'");
                $this->db->order_by('TABLE_NAME.COL_NAME');
                return $this->get_all();
        }

        public function get_agence_regles()
        {
                
                $guichet = $_SESSION['Logiref_guichet'];
                
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_8='" . $guichet . "'";
                
                $query = $this->db->table('logiref_regles')
                        ->select('logiref_regles.*')
                        ->where($st)
                        ->orderBy('Date_1', 'DESC')
                        ->get();
                
                return $query->getResult();
        }

        public function get_agence_regles_filtered($data)
        {
                $guichet = $_SESSION['Logiref_guichet'];
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Guichet_8='" . $guichet . "'";

                if (isset($data['regie'])  &&  $data['regie'] != "") $st .=  " AND Beneficiaire_5 ='" . $data['regie'] . "'";

                $this->table = '';
                $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                $this->db->from('logiref_regles');
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }

        public function get_rbo_customers($type = NULL)
        {
                $this->table = '';
                $this->db->select('logiref_rbo_customers.*', 'logiref_rbo_customers.Date_1 DESC');
                $this->db->from('logiref_rbo_customers');
                $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'";
                $this->db->where($st, NULL, FALSE);
                $this->db->order_by('Date_1 DESC');
                return $this->get_all();
        }


        public function get_rbo_regles($type = NULL)
        {
                $this->table = '';

                if ($type == "rgle") {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "' AND Customer_19 !='0'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                } else {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND ( Beneficiaire_5='0' OR Beneficiaire_5='" . $_SESSION['Logiref_regies'] . "') AND Checkerid_15 !='0' AND Customer_19 !='0'";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
        }

        public function get_invoices_regles($type = NULL)
        {
                $this->table = '';

                if ($type == "rgle") {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND Account_3='" . $this->session->userdata['account_id'] . "'  AND Typefacture_17 != '0' ";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                } else {
                        $this->db->select('logiref_regles.*', 'logiref_regles.Date_1 DESC');
                        $this->db->from('logiref_regles');
                        $st = "Status_2='1' AND ( Beneficiaire_5='0' OR Beneficiaire_5='" . $_SESSION['Logiref_regies'] . "') AND Checkerid_15 !='0' AND Typefacture_17 != '0' ";
                        $this->db->where($st, NULL, FALSE);
                        $this->db->order_by('Date_1 DESC');
                        return $this->get_all();
                }
        }



        /*
         * Save Information: insert or update an array
         * Use: inserting or updating 
         * P.S: Ajoutez vous methodes ci-dessous!!
         *  *************************************************************************************************************************SECTION 5
        */
        public function save_rbo_customer($data, $id)
        {
                $this->set_table('logiref_rbo_customers', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_regle($data, $id)
        {
                $this->set_table('logiref_regles', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }

        public function save_exempt_customers($data, $id)
        {
                $this->set_table('logiref_client_exonore', 'Id_0', 'Id_0 DESC');
                return $this->saveData($data, $id);
        }
}
