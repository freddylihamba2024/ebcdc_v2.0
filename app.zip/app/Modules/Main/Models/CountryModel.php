<?php

namespace Modules\Main\Models;

use App\Models\MY_Main;
use CodeIgniter\Model;

class CountryModel extends MY_Main
{
    protected $DBGroup          = 'default';
    protected $table            = 'main_countries';
    protected $primaryKey       = 'Id_0';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

}