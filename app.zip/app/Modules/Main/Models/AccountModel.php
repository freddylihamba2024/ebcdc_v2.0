<?php

namespace Modules\Main\Models;

use App\Models\MY_Main;
use CodeIgniter\Model;

class AccountModel extends MY_Main
{
    protected $DBGroup          = 'default';
    protected $table            = 'main_accounts';
    protected $primaryKey       = 'Id_0';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'object';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'Date_1';
    protected $updatedField  = 'Changes_5';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;


}