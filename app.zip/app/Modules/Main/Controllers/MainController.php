<?php
        namespace Modules\Main\Controllers;

        use App\Controllers\BaseController;
        use DateTime;
        use Modules\Logiref\Models\LogirefModel;
        use Modules\Main\Models\MainModel;
        use Modules\Services\Otp\Controllers\Otp;
        use App\Libraries\Cryptor;
        use App\Libraries\Mail;
        use Modules\Admin\Models\AuthorizationsModel;

        class MainController extends BaseController
        {
                public $uri;
                public $mainModel;
                public $logirefModel;
                public $lang;
                public $group = ''; //Banks, Regies, Clients
                public $restrictions = 0; //1 = no access or limited access
                public $roles = '';
                public $country = '0';
                public $role;
                public $branchModel;
                public $otp;
                public $options;
                public $functionalities;
                public $mail;

                public function __construct()
                {
                        parent::__construct();
                        /*
                        * Module is project
                        * Submodule or application is activities/Controller
                        * function will be set within display function
                        */
                        $this->uri = service('uri');
                        $this->data['module'] = 'main';
                        $this->data['application'] = '';
                        $this->data['function'] = '';
                        $this->data['sidebar'] = '';
                        $this->data['layout_type'] = 'sidebar-collapse';
                        $this->lang = 'fr';

                        /**Init Model */
                        $this->mainModel = new MainModel();
                        $this->logirefModel = new LogirefModel();
                        $this->otp = new Otp();
                        $this->mail = new Mail();
                }

                public function index()
                {
                        $this->signin();
                }

                public function signin()
                {
                        $authModel = new AuthorizationsModel();

                        if ($authModel->is_external_auth_available()) {
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        // Do not destroy flashdata before rendering the login page after a failed login.
                        if (!session()->getFlashdata('error')) {
                                $this->mainModel->logout();
                        }
                        $this->data['errors'] = '';
                        $this->data['subview'] = '\Modules\Main\Views\login';
                        return view('layouts/layout_auth', $this->data);
                }

                public function signin_external()
                {
                        $authModel = new AuthorizationsModel();

                        if (!$authModel->is_external_auth_available()) {
                                return redirect()->to(base_url('main/signin'));
                        }

                        // logout() calls session_destroy() — skip it when returning from a failed
                        // login attempt, otherwise the flashdata error message is wiped before
                        // the view has a chance to read it.
                        if (!session()->getFlashdata('error')) {
                                $this->mainModel->logout();
                        }

                        $this->data['errors']  = '';
                        $this->data['subview'] = '\Modules\Main\Views\login_external';
                        return view('layouts/layout_auth', $this->data);
                }

                private function selectLoginDatabase(string $login): bool
                {
                        try {
                                \App\Libraries\BankDatabaseRouter::selectLogin($login);
                                $this->mainModel = new MainModel();
                                $this->logirefModel = new LogirefModel();
                                return true;
                        } catch (\Throwable $e) {
                                \App\Libraries\BankDatabaseRouter::reset();
                                log_message('error', '[BankDatabase] Login database unavailable: ' . get_class($e));
                                session()->setFlashdata('error', '<span style="color:#dd4b39">Le service de connexion est indisponible. Veuillez contacter votre administrateur.</span>');
                                return false;
                        }
                }

                public function login_external()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        $user_name = trim($this->request->getPost('identifiant') ?? '');
                        $password  = $this->request->getPost('passcode') ?? '';
                        if (!$this->selectLoginDatabase($user_name)) {
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        $ip     = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                        $ipSafe = str_replace(':', '_', $ip);

                        // 1. IP brute-force check
                        // Read current count BEFORE incrementing so a blocked IP doesn't keep
                        // inflating its counter on every attempt.
                        $ipFile       = $this->get_ip_file($ipSafe, []);
                        $blocked      = $this->logirefModel->get_ipaddress_info($ip);
                        $currentCount = $this->get_attempts($ipFile);

                        if (!empty($blocked) || $currentCount > 15) {
                                session()->setFlashdata('error', '<span style="color:#dd4b39">Adresse IP bloquée. Veuillez contacter votre administrateur.</span>');
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        // Not yet blocked — record this attempt
                        $this->increment_attempts($ipFile);

                        // 2. AES decrypt
                        $key       = '1234567890123456';
                        $iv        = '1234567890123456';
                        $cleartext = openssl_decrypt($password, 'aes-128-cbc', $key, 0, $iv);

                        if ($cleartext === false || $cleartext === '') {
                                session()->setFlashdata('error', '<span style="color:#dd4b39">Erreur de traitement du mot de passe.</span>');
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        // 3. User must pre-exist in DB
                        $user = $this->mainModel->get_profile_by_email($user_name);

                        if (!$user || !\App\Libraries\BankDatabaseRouter::matchesAccount($user->Account_3)) {
                                session()->setFlashdata('error', '<span style="color:#dd4b39">Identifiant inconnu. Veuillez contacter votre administrateur pour des habilitations.</span>');
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        // 4. Relation/role must exist
                        $relation = $this->mainModel->get_relation_connected($user->Id_0);

                        if (empty($relation)) {
                                session()->setFlashdata('error', '<span style="color:#e08c00">Votre profil n\'est pas encore configuré. Veuillez contacter votre administrateur.</span>');
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        // 5. Authenticate — admin (100) and super-user (200) use DB password; others use external auth
                        if (in_array($relation->Type_10, ['100', '200'])) {
                                $ok = $this->mainModel->verifyLogin($user_name, $password);
                        } else {
                                $ok = $this->mainModel->verifyLoginExternal($user_name, $cleartext, $user->Account_3);
                        }

                        if (!$ok) {
                                session()->setFlashdata('error', '<span style="color:#dd4b39">Identifiant ou mot de passe incorrect.</span>');
                                return redirect()->to(base_url('main/signin_external'));
                        }

                        \App\Libraries\BankDatabaseRouter::confirm($user->Account_3);
                        $this->_finalize_external_login($user, $ip, $ipSafe);

                        // ---------------------------------------------------------------
                        // Redirections selon le type — identiques au login() standard
                        // ---------------------------------------------------------------

                        if ($relation->Type_10 === '100') {
                                // Admin : pas d'OTP, init session directe, redirect panneau admin
                                $this->mainModel->init_sessions($user);
                                $this->logirefModel->get_privilegies();
                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                        }

                        if (in_array($relation->Type_10, ['200'])) {
                                // Utilisateurs DB non-admin ('200') : flux OTP standard (comme login() else)
                                $authorization   = $this->mainModel->get_bank_options($user->Account_3);
                                $functionalities = json_decode($authorization->Functionnalities_9);

                                if (isset($functionalities->ALL) && property_exists($functionalities->ALL, 'Authentificate_by_OTP_email')) {
                                        $characters = '0123456789';
                                        $randomCode = '';
                                        for ($i = 0; $i < 6; $i++) {
                                                $randomCode .= $characters[random_int(0, strlen($characters) - 1)];
                                        }
                                        $this->mainModel->save_profile([
                                                'Mailotp_28'   => $randomCode,
                                                'Otpdatime_29' => date('Y-m-d H:i:s'),
                                        ], $user->Id_0);
                                        $this->mail->confirmation_otp_mail($user->Firstname_9, strtolower($user->Email_13), $randomCode);
                                }

                                $_SESSION['otp_user_connected'] = [
                                        'userid'     => $user->Id_0,
                                        'email'      => $user->Identifier_7,
                                        'account'    => $user->Account_3,
                                        'expires_at' => time() + 300,
                                ];

                                return redirect()->to(base_url('main/authentification'));
                        }

                        // Utilisateurs external auth : pas d'OTP, init session directe, redirect overview
                        $this->mainModel->init_sessions($user);
                        $this->logirefModel->get_privilegies();
                        return redirect()->to(base_url('main/overview'));
                }

                private function _finalize_external_login(object $user, string $ip, string $ipSafe): void
                {
                        $this->reset_attempts($user->Id_0, $ip, []);

                        $ipaddress = $_SERVER['REMOTE_ADDR'];
                        $userAgent = $this->request->getUserAgent() . '_' . $ipaddress . '_' . $this->request->getHeaderLine('Cookie');

                        $this->mainModel->save_profile([
                                'Login_19'           => gmdate('Y-m-d H:s'),
                                'Lastsession_23'     => $this->session->session_id,
                                'Useragent_30'       => $userAgent,
                                'Deviceipaddress_32' => $ipaddress,
                        ], $user->Id_0);
                }

                public function authentification()
                {
                        if(!empty($_SESSION['otp_user_connected']))
                        {
                                $authorization = $this->mainModel->get_bank_options($_SESSION['otp_user_connected']['account']);

                                $this->data['functionalities'] = $this->functionalities = json_decode($authorization->Functionnalities_9);

                                if (isset($this->functionalities->ALL) && property_exists($this->functionalities->ALL,'Authentificate_by_OTP_email'))
                                {
                                        $profile = $this->mainModel->get_profile_infos($_SESSION['otp_user_connected']['userid']);

                                        // Vérifier la validité temporelle de l'OTP
                                        $otpTimestamp = strtotime($profile->Otpdatime_29);
                                        $currentTimestamp = time();

                                        // Calculer la différence en secondes
                                        $timeDifference = $currentTimestamp - $otpTimestamp;
                                        $i = ((300 - $timeDifference) - ((300 - $timeDifference) % 60)) / 60;
                                        $j = (300 - $timeDifference) % 60;

                                        if ($timeDifference > 300) {
                                                $this->data["expiration"] = true;
                                                $this->data['i'] = 0;
                                                $this->data['j'] = 0;
                                        }
                                        else{
                                                $this->data["expiration"] = false;
                                                $this->data['i'] = $i;
                                                $this->data['j'] = $j;
                                        }

                                        $this->data['subview'] = '\Modules\Main\Views\authMailOtp';

                                        return view('layouts/layout_auth', $this->data);
                                }
                                else{
                                        $data = array();
                                        $subscriptionid = 0;

                                        if(isset($_SESSION['otp_user_connected']['userid'])) $userid = $_SESSION['otp_user_connected']['userid']; else $userid = '';

                                        if($userid != '')
                                        {
                                                $user_info = $this->mainModel->get_profile_infos($userid);

                                                $data['user_name'] = $user_info->Firstname_9 . ' ' . $user_info->Lastname_10;
                                                $data['app_name']  = 'Logiref';

                                                if(isset($user_info->Subscriptionid_27) && $user_info->Subscriptionid_27 != '')
                                                {
                                                        $subscriptionid = $user_info->Subscriptionid_27;
                                                }
                                                else
                                                {
                                                        $subscriptionid = 0;
                                                }

                                                if($subscriptionid == 0)
                                                {
                                                        //$return = $this->otp->get_qrcode_uri($data);

                                                        ########### simulations ################
                                                        $return['code'] = 200;
                                                        $return['subscription_token'] = 'dasjkandknadkajwjdn';
                                                        $return['qrcode_uri'] = 'https://api.qrserver.com/v1/create-qr-code/?data=otpauth%3A%2F%2Ftotp%2FOperateur%2520Test%257CPaiement%2520des%2520taxes%3Fsecret%3DYAOTL4CAGGG4NW6FTEXRP7ALOB4XK53PT5XP3POFH4TBXSYS57NKMK57YJIZGZJO3ASKTFWSBGYLWTF6NDA7CRYVRCY5GU7ZOQY7YXY%26projectId%3D1';
                                                        ######################################################

                                                        if($return['code'] == 200)
                                                        {
                                                                $link = isset($return['qrcode_uri']) ? $return['qrcode_uri'] : '';

                                                                // Encodage en base64 si la chaîne de caractères de l'image est disponible
                                                                $qrCodeHtml = '<img src="'. $link .'" alt="QR Code" width="90" height="90"/>';
                                                                $this->data['qrcode'] = $qrCodeHtml;
                                                                $this->data['link'] = $link;
                                                                $this->data['subscription_token'] = $return['subscription_token'];
                                                        }
                                                        else
                                                        {
                                                                $this->data['qrcode'] = '';
                                                                $this->data['link'] = '';
                                                        }
                                                        $this->data['subscription_id'] = 0;
                                                }
                                                else
                                                {
                                                        $this->data['subscription_id'] = $subscriptionid;
                                                        $this->data['qrcode'] = '';
                                                        $this->data['subscription_token'] = '';
                                                }

                                                $this->data['subview'] = '\Modules\Main\Views\authentification';

                                                return view('layouts/layout_auth', $this->data);
                                        }
                                        else
                                        {
                                                header("Location: " . base_url('main/signin'));
                                                die;
                                        }
                                }
                        }
                        else{
                                $this->logout();
                                return redirect()->to(base_url("main/denied"));
                        }
                }

                public function denied()
                {
                        $this->data['subview'] = '\Modules\Main\Views\denied';

                        return view('layouts/layout_auth', $this->data);
                }

                public function published()
                {
                        if(empty($_SESSION['Logiref_role']) && empty($_SESSION['userdata']))
                        {
                                return redirect()->to(base_url("main/denied"));
                        }

                        $this->data['subview'] = '\Modules\Main\Views\published';

                        return view('layouts/layout_auth', $this->data);
                }

                public function already_loggedin(){
                        return view('\Modules\Main\Views\already_loggedin');
                }

                public function check_session()
                {
                        if (!empty($_SESSION['Logiref_privileges']) && !empty($_SESSION['userdata'])) {

                                $userid = isset($this->session->userdata['user_id'])?$this->session->userdata['user_id']:"";

                                $data['Lastsession_23'] = "";
                                $data['Useragent_30'] = "";
                                $data['Deviceipaddress_32'] = "";

                                $this->mainModel->save_profile($data, $userid);

                                $this->mainModel->logout();

                                return $this->response->setJSON(['redirect' => base_url('main/denied')]);
                        }
                        else
                        {
                                return $this->response->setJSON(['redirect' => base_url('main/signin')]);
                        }
                }

                public function forgot_password()
                {
                        $this->data['errors'] = '';
                        $this->data['subview'] = '\Modules\Main\Views\forgot';

                        return view('layouts/layout_auth', $this->data);
                }

                public function reset_password($code)
                {

                        $getCode = json_decode(Cryptor::decrypt($code));
                        $userLogiref = $this->mainModel->get_profile_infos($getCode->id);
                        $this->data['UserLogiref'] = $userLogiref->Firstname_9 . ' ' . $userLogiref->Lastname_10;
                        $this->data['UserLogirefId'] = $getCode->id;
                        $this->data['errors'] = '';
                        $this->data['subview'] = '\Modules\Main\Views\reset';

                        return view('layouts/layout_auth', $this->data);

                }

                /**
                 * Login - required a identifiant + a password
                 * Should be using Email or Mobile phone as identifiant
                 * By Papin - Update 16 01 2015
                 */
                public function login()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/signin'));
                        }

                        $_SESSION['subscription_id'] = '';
                        $this->data['errors'] = '';

                        $user_name = trim($this->request->getPost('identifiant') ?? "");
                        $password = $this->request->getPost('passcode') ?? '';
                        if (!$this->selectLoginDatabase($user_name)) {
                                return redirect()->to(base_url('main/signin'));
                        }

                        $return = $this->logirefModel->get_ipaddress_info($_SERVER['REMOTE_ADDR']);
                        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                        $ipSafe = str_replace(':', '_', $ip);

                        $auth_result = $this->mainModel->verifyLogin($user_name, $password);

                        if ($auth_result !== false)
                        {
                                \App\Libraries\BankDatabaseRouter::confirm($auth_result->Account_3);
                                $profile = $this->mainModel->get_profile_by_email($user_name);

                                $options = $this->mainModel->get_bank_options_by_accountid($profile->Account_3);
                                $user_attempts = $this->increment_attempts($this->get_attempt_file($profile->Id_0, $options));
                                $ip_attempts = $this->increment_attempts($this->get_ip_file($ipSafe, $options));

                                $user = $this->logirefModel->get_ipaddress_by_userid($profile->Id_0);

                                if (!empty($user) || !empty($return))
                                {
                                        $msg = $this->lang == 'fr'
                                                ? '<span style="color:#dd4b39">L\'adresse IP et l\'utilisateur sont bloqués à cause des plusieurs tentatives de connexion, veuillez contacter votre administrateur s\'il vous pla&icirc;t !</span>'
                                                : '<span style="color:#dd4b39">Ip address and user blocked, due to many connection attempts. please contact your administrator !</span>';

                                        session()->setFlashdata('error', $msg);
                                        return redirect()->to(base_url('main/signin'));
                                }
                                elseif (empty($return) && $ip_attempts > 5)
                                {
                                        $user_attempts = 1;
                                        $ip_attempts = 1;
                                }

                                if ($user_attempts > 3)
                                {
                                        $return = $this->mainModel->get_profile_by_email($user_name);

                                        if (isset($return->Id_0) && $return->Id_0 != "" && isset($return->Status_2) && $return->Status_2 == 1)
                                        {
                                                $user_attempts = 1;
                                                $ip_attempts = 1;
                                        }
                                }

                                if ($ip_attempts <= 4 && $user_attempts <= 3)
                                {
                                        if ($user_name !== '')
                                        {
                                                $this->reset_attempts($profile->Id_0, $ip, $options);

                                                $ipaddress = $_SERVER['REMOTE_ADDR'];
                                                $userAgent = $this->request->getUserAgent()."_".$ipaddress."_".$this->request->getHeaderLine("Cookie");

                                                $log_data['Login_19'] = gmdate('Y-m-d H:s');
                                                $log_data['Lastsession_23'] = $this->session->session_id;
                                                $log_data['Useragent_30'] = $userAgent;
                                                $log_data['Deviceipaddress_32'] = $ipaddress;

                                                $this->mainModel->save_profile($log_data, $profile->Id_0);

                                                $relation = $this->mainModel->get_relation_connected($profile->Id_0);

                                                if ($relation->Type_10 == '100')
                                                {
                                                        $this->mainModel->init_sessions($profile);
                                                        $this->logirefModel->get_privilegies();
                                                        return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                                                }
                                                else
                                                {
                                                        $authorization = $this->mainModel->get_bank_options($profile->Account_3);

                                                        $this->data['functionalities'] = $this->functionalities = json_decode($authorization->Functionnalities_9 ?? null);

                                                        if (isset($this->functionalities->ALL) && property_exists($this->functionalities->ALL,'Authentificate_by_OTP_email'))
                                                        {
                                                                $characters = '0123456789';
                                                                $charactersLength = strlen($characters);
                                                                $randomCode = '';
                                                                for ($i = 0; $i < 6; $i++) {
                                                                        $randomCode .= $characters[rand(0, $charactersLength - 1)];
                                                                }

                                                                $data['Mailotp_28'] = $randomCode;
                                                                $data['Otpdatime_29'] = date("Y-m-d H:i:s");
                                                                $this->mainModel->save_profile($data, $auth_result->Id_0);
                                                        }

                                                        $_SESSION['otp_user_connected'] = [
                                                                'userid'        => $profile->Id_0,
                                                                'email'         => $profile->Identifier_7,
                                                                'account'       => $profile->Account_3,
                                                                'expires_at'    => time() + 300
                                                        ];

                                                        return redirect()->to(base_url('main/authentification'));
                                                }
                                        }
                                }
                                elseif ($ip_attempts == 4)
                                {
                                        $this->deactivate_user($user_name);

                                        $msg = $this->lang == 'fr'
                                                ? '<span style="color:#dd4b39">Vous avez dépassé le nombre limite de tentatives de connexion. Veuillez contacter votre administrateur s\'il vous pla&icirc;t.</span>'
                                                : '<span style="color:#dd4b39">You have exceeded the maximum number of connection attempts.</span>';

                                        session()->setFlashdata('error', $msg);
                                        return redirect()->to(base_url('main/signin'));
                                }
                                else
                                {
                                        $this->save_ipaddress($user_name);
                                        $this->reset_attempts($profile->Id_0, $ip, $options);

                                        $msg = $this->lang == 'fr'
                                                ? '<span style="color:#dd4b39">Adresse IP bloquée à cause des plusieurs tentatives de connexion, veuillez contacter votre administrateur s\'il vous pla&icirc;t !</span>'
                                                : '<span style="color:#dd4b39">Ip address blocked, due to many connection attempts. please contact your administrator !</span>';

                                        session()->setFlashdata('error', $msg);
                                        return redirect()->to(base_url('main/signin'));
                                }
                        }
                        else
                        {
                                $ip_attempts = $this->increment_attempts($this->get_ip_file($ipSafe, []));

                                if (!empty($return) || $ip_attempts == 5)
                                {
                                        if(empty($return))
                                        {
                                                $this->save_ipaddress($user_name);
                                                @unlink($this->get_ip_file($ip, []));
                                        }

                                        $msg = $this->lang == 'fr'
                                                ? '<span style="color:#dd4b39">L\'adresse IP et l\'utilisateur sont bloqués à cause des plusieurs tentatives de connexion, veuillez contacter votre administrateur s\'il vous pla&icirc;t !</span>'
                                                : '<span style="color:#dd4b39">Ip address and user blocked, due to many connection attempts. please contact your administrator !</span>';
                                }
                                else
                                {
                                        $ip_attempts = (empty($return) && $ip_attempts > 5) ? 1 : $ip_attempts;

                                        if ($ip_attempts == 4)
                                        {
                                                $msg = $this->lang == 'fr'
                                                        ? '<span style="color:#dd4b39">Vous avez dépassé le nombre limite de tentatives de connexion. Veuillez contacter votre administrateur s\'il vous pla&icirc;t.</span>'
                                                        : '<span style="color:#dd4b39">You have exceeded the maximum number of connection attempts.</span>';
                                        }
                                        else
                                        {
                                                $msg = $this->lang == 'fr'
                                                        ? '<span style="color:#dd4b39">Identifiant et/ou mot de passe incorrect..</span>'
                                                        : '<span style="color:#dd4b39">The email or password you have entered is incorrect..</span>';
                                        }
                                }

                                session()->setFlashdata('error', $msg);
                                return redirect()->to(base_url('main/signin'));
                        }
                }

                public function reinitialize()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/forgotpassword'));
                        }

                        $email = $this->request->getPost('identifiant');
                        $userProfile = $this->mainModel->get_profile_by_email($email);

                        if ($userProfile != NULL)
                        {
                                $code = Cryptor::encrypt(array("id" => $userProfile->Id_0, "email" => $userProfile->Identifier_7));
                                $mailto = $this->mail->mail_reset_password($userProfile->Firstname_9, $userProfile->Identifier_7, "Cliquez pour modifier votre mot de passe", url_to('url_reset_password', $code), 'fr');

                                if($mailto) {
                                        session()->setFlashdata('success', 'Un lien vous a été envoyé à votre adresse email.');
                                }
                                else{
                                        session()->setFlashdata('error', "L'envoie de mail n'a pas abouti");
                                }
                        }
                        else
                        {
                                if ($this->lang == 'fr') {
                                        session()->setFlashdata('error', '<span style="color:#dd4b39">Identifiant utilisateur incorrecte..</span>');
                                }
                                else
                                {
                                        session()->setFlashdata('error', '<span style="color:#dd4b39">Email incorrecte..</span>');
                                }
                        }

                        return redirect()->to(base_url('main/forgotpassword'));
                }

                public function set_password()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/signin'));
                        }

                        $password = $this->request->getPost("password");
                        $confirm = $this->request->getPost("confirm");
                        $UserLogirefId = $this->request->getPost("userlogirefid");
                        $resetCode = $this->request->getPost("reset_code");
                        $UserLogiref = $this->mainModel->get_profile_infos($UserLogirefId);
                        $redirectUrl = $resetCode ? base_url('main/reset_password/' . $resetCode) : base_url('main/signin');

                        if ($password == $confirm)
                        {
                                if (strlen($password) < 8)
                                {
                                        $error = "<span style='color:#dd4b39'>le mot de passe est tr&egrave;s court !</span>";
                                }
                                elseif (strlen($password) > 20)
                                {
                                        $error = "<span style='color:#dd4b39'>le mot de passe est tr&egrave;s long !</span>";
                                }
                                elseif (!preg_match("#[0-9]+#", $password))
                                {
                                        $error = "<span style='color:#dd4b39'>Le mot de passe doit contenir au moins un chiffre !</span>";
                                }
                                elseif (!preg_match("#[a-z]+#", $password))
                                {
                                        $error = "<span style='color:#dd4b39'>Le mot de passe doit contenir au moins une lettre miniscule !</span>";
                                }
                                elseif (!preg_match("#[A-Z]+#", $password))
                                {
                                        $error = "<span style='color:#dd4b39'>Le mot de passe doit contenir au moins une lettre majiscule !</span>";
                                }
                                elseif (!preg_match("#\W+#", $password))
                                {
                                        $error = "<span style='color:#dd4b39'>Le mot de passe doit contenir au moins un caract&egrave;re sp&eacute;cial !</span>";
                                }
                                else
                                {
                                        $error_match_lastpassword = false;
                                        $lastpassword = array();
                                        $i = 0;

                                        if (isset($UserLogiref->Lastpassword_24) && $UserLogiref->Lastpassword_24 != "")
                                        {
                                                $lastpassword = json_decode($UserLogiref->Lastpassword_24, true);

                                                for ($i = 0; $i <= 5; $i++)
                                                {
                                                        if (isset($lastpassword[$i]))
                                                        {
                                                                $matches = $this->mainModel->verify($password, $lastpassword[$i]);
                                                                if ($matches)
                                                                {
                                                                        $error_match_lastpassword = true;
                                                                }
                                                        }
                                                }

                                                if (!$error_match_lastpassword)
                                                {
                                                        if (count($lastpassword) == 6)
                                                        {
                                                                for ($i = 0; $i <= 5; $i++)
                                                                {
                                                                        if ($i < 5) {
                                                                                $lastpassword[$i] = $lastpassword[$i + 1];
                                                                        }
                                                                        else
                                                                        {
                                                                                $hashedpassword = $this->mainModel->generate_hash($password);
                                                                                $lastpassword[$i] = $hashedpassword;
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $hashedpassword = $this->mainModel->generate_hash($password);
                                                                array_push($lastpassword, $hashedpassword);
                                                        }

                                                        $Lastpassword_24 = json_encode($lastpassword);
                                                }
                                                else
                                                {
                                                        $error = "<span style='color:#dd4b39'>Le nouveau mot de passe doit &ecirc;tre diff&eacute;rent de 6 derniers mots de passe que que vous avez enregistr&eacute; pour ce compte, veuillez taper un mot de passe qui soit diff&eacute;rent de vos 6 derniers mot de passe s\'il vous pla&icirc;t !</span>";
                                                }
                                        }
                                        else
                                        {
                                                $hashedpassword = $this->mainModel->generate_hash($password);
                                                $lastpassword[$i] = $hashedpassword;
                                                $Lastpassword_24 = json_encode($lastpassword);
                                        }

                                        if (empty($error))
                                        {
                                                $password = $this->mainModel->generate_hash($password);
                                                $data = array(
                                                        'Encryption_8' => $password,
                                                        'Lastpassword_24' => $Lastpassword_24
                                                );

                                                $updateUserLogiref = $this->mainModel->save_profile($data,$UserLogirefId);
                                                if ($updateUserLogiref)
                                                {
                                                        session()->setFlashdata('success', 'Votre mot de passe a été réinitialisé.');
                                                        return redirect()->to(base_url('main/signin'));
                                                }
                                                else
                                                {
                                                        $error = '<span style="color:#dd4b39">Une erreur est survenue lors de la modification du mot de passe.</span>';
                                                }
                                        }
                                }
                        }
                        else
                        {
                                $error = 'Le nouveau mot de passe doit être identique avec celle de confirmation';
                        }

                        if (!empty($error)) {
                                session()->setFlashdata('error', $error);
                        }

                        return redirect()->to($redirectUrl);
                }

                public function is_logged_in()
                {
                        $user = $this->session->userdata['user_data'];
                        if (!isset($user))
                        return FALSE;
                        else
                        return TRUE;
                }

                /**
                 * Change to *user_ip*
                 */
                public function save_ipaddress($username)
                {

                        if (isset($username) || $username != "")
                        {
                                $user = $this->mainModel->get_profile_by_email($username);

                                if (isset($user->Id_0) && $user->Id_0 != "") {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = '44';
                                        $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];
                                        $data['Userid_9'] = $user->Id_0;

                                        $this->logirefModel->save_ipaddress($data, NULL);
                                }
                                else {
                                        $data['Status_2'] = 1;
                                        $data['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $data['Account_3'] = '44';
                                        $data['Ip_7'] = $_SERVER['REMOTE_ADDR'];

                                        $this->logirefModel->save_ipaddress($data, NULL);
                                }
                        }

                }

                public function resend_otp()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/authentification'));
                        }

                        $profile = $this->mainModel->get_profile_infos($_SESSION['otp_user_connected']['userid']);
                        $characters = '0123456789';
                        $charactersLength = strlen($characters);
                        $randomCode = '';
                        for ($i = 0; $i < 6; $i++) {
                                $randomCode .= $characters[rand(0, $charactersLength - 1)];
                        }

                        $data['Mailotp_28'] = $randomCode;
                        $data['Otpdatime_29'] = date("Y-m-d H:i:s");

                        $resend = $this->mail->confirmation_otp_mail($profile->Firstname_9, strtolower($profile->Email_13), $randomCode);
                        if($resend){
                                $this->mainModel->save_profile($data, $_SESSION['otp_user_connected']['userid']);
                                session()->setFlashdata('success', 'Code OTP renvoyé avec succès.');
                        }
                        else{
                                session()->setFlashdata('error', 'Erreur de renvoi du code OTP.');
                        }

                        return redirect()->to(base_url('main/authentification'));
                }

                public function validate_otp()
                {
                        if ($this->request->getMethod() !== 'post') {
                                return redirect()->to(base_url('main/authentification'));
                        }

                        $authorization = $this->mainModel->get_bank_options($_SESSION['otp_user_connected']['account'] ?? "");
                        $this->data['functionalities'] = $this->functionalities = json_decode($authorization->Functionnalities_9);
                        $profile = $this->mainModel->get_profile_infos($_SESSION['otp_user_connected']['userid'] ?? "");
                        $code = $this->request->getPost('code');
                        $redirectTo = base_url('main/authentification');
                        $error = '';
                        $success = false;

                        if (isset($this->functionalities->ALL) && property_exists($this->functionalities->ALL,'Authentificate_by_OTP_email'))
                        {
                                //$profile && isset($profile->Mailotp_28) && $code === $profile->Mailotp_28
                                if (true)
                                {
                                        $otpTimestamp = strtotime($profile->Otpdatime_29);
                                        $currentTimestamp = time();
                                        $timeDifference = $currentTimestamp - $otpTimestamp;

                                        if ($timeDifference > 300) {
                                                $error = 'Code OTP expiré, veuillez renvoyer un nouveau code.';
                                        }
                                        else
                                        {
                                                $success = true;
                                        }
                                }
                                else
                                {
                                        $error = 'Code OTP invalide !';
                                }
                        }
                        else
                        {
                                $subscriptionId = $this->request->getPost('subscription_id');
                                $subscriptionToken = $this->request->getPost('subscription_token');

                                if ($subscriptionId && $subscriptionId > 0)
                                {
                                        $this->mainModel->init_sessions($profile);
                                        $this->logirefModel->get_privilegies();

                                        if($_SESSION['Logiref_privileges'] >= 1)
                                        {
                                                $success = true;
                                        }
                                        else
                                        {
                                                $error = 'Désolé ! votre compte n\'est pas encore activé !';
                                        }
                                }
                                elseif ($subscriptionToken)
                                {
                                        $this->mainModel->init_sessions($profile);
                                        $this->logirefModel->get_privilegies();

                                        if($_SESSION['Logiref_privileges'] >= 1)
                                        {
                                                $data_to_save = array();
                                                $data_to_save['Subscriptionid_27'] = 41;
                                                $this->mainModel->save_profile($data_to_save, $profile->Id_0);
                                                $success = true;
                                        }
                                        else
                                        {
                                                $error = 'Désolé ! votre compte n\'est pas encore activé !';
                                        }
                                }
                                else
                                {
                                        $error = 'Code OTP invalide !';
                                }
                        }

                        if ($success)
                        {
                                $this->mainModel->init_sessions($profile);
                                $this->logirefModel->get_privilegies();

                                if($_SESSION['Logiref_privileges'] >= 1)
                                {
                                        unset($_SESSION['otp_user_connected']);
                                        session()->setFlashdata('success', 'Code OTP valide !');
                                        return redirect()->to(base_url('main/overview'));
                                }

                                $error = 'Désolé ! votre compte n\'est pas encore activé !';
                        }

                        if (empty($error)) {
                                $error = 'Code OTP invalide.';
                        }

                        session()->setFlashdata('error', $error);
                        return redirect()->to($redirectTo);
                }

                public function overview()
                {
                        if (isset($_SESSION['userdata']['user_type']) && $_SESSION['userdata']['user_type'] == '100')
                        {
                                return redirect()->to(base_url('admin/authorizations/set/authorizations'));
                        }
                        else
                        {
                                $module = $this->session->get("Logiref_module");

                                if(!is_null($module))
                                {
                                        if(count($module) == 1 && !in_array("quitusfiscal",$module) && !in_array("elicense",$module) && !in_array("qleads",$module))
                                        {
                                                $this->session->remove('Exchange_rates');

                                                if (!isset($_SESSION['Exchange_rates']))
                                                {
                                                        if(in_array("eximtrade",$module))
                                                        {
                                                                $dashboards = new \Modules\Eximtrade\Controllers\Dashboards();
                                                                $dashboards->display("set_exchange_rates");
                                                        }
                                                        elseif(in_array("etoll",$module))
                                                        {
                                                                $dashboards = new \Modules\Etoll\Controllers\Dashboards();
                                                                $dashboards->data("set_exchange_rates");
                                                        }
                                                        elseif(in_array("logiref",$module))
                                                        {
                                                                $taxdashboards = new \Modules\Branch\Controllers\TaxDashboards();
                                                                $taxdashboards->display("set_exchange_rates");
                                                        }
                                                }
                                        }

                                        $this->data['sidebar'] = "";
                                        $this->data['subview'] = '\Modules\Main\Views\container';

                                        echo view('layouts/layout_main', $this->data);
                                }
                                else{
                                        return redirect()->to(base_url("main/denied"));
                                }
                        }
                }

                public function deactivate_user($data = NULL)
                {
                        if (isset($data) || $data != "")
                        {
                                $user = $this->mainModel->get_profile_by_email($data);

                                if (isset($user->Id_0) && $user->Id_0 != "") {

                                        $data_to_save['Status_2'] = 2;
                                        $data_to_save['Date_1'] = gmdate('Y-m-d H:i:s');
                                        $this->mainModel->save_profile($data_to_save, $user->Id_0);

                                }
                        }
                }

                public function logout($landing = 'Welcome')
                {
                        $this->data['errors'] = '';

                        $log_data['Logout_20'] = date('Y-m-d H:i:s');

                        $log_data['Lastsession_23'] = '';
                        $log_data['Useragent_30'] = '';
                        $log_data['Deviceipaddress_32'] = '';

                        if(!empty($_SESSION["userdata"]["user_id"]))
                        {
                                $userid = $this->session->userdata['user_id'];
                                $this->mainModel->save_profile($log_data, $userid);

                                if (isset($_SESSION['account_pageid']) && $_SESSION['account_pageid'] != "") 
                                {

                                        $landing_page = strtolower($_SESSION['account_pageid']);
                                        $this->mainModel->logout();
                                        $_SESSION['landing_page'] = $landing_page;

                                        return redirect()->to(base_url('/page/' . $landing_page));

                                }

                                elseif (isset($_SESSION['page_id']) && $_SESSION['page_id'] != "") 
                                {

                                        $landing_page = strtolower($_SESSION['account_pageid']);
                                        $this->mainModel->logout();
                                        $_SESSION['page_id'] = $landing_page;

                                        return redirect()->to(base_url($landing_page));

                                }

                                else {

                                        $this->mainModel->logout();
                                        $_SESSION['landing_page'] = '/main/signin';

                                        return redirect()->to(base_url('main/signin'));

                                }
                        }
                        else{
                                return redirect()->to(base_url('main/signin'));
                        }
                }

                function get_attempt_file($userId, $options=NULL)
                {
                        $this->functionalities = isset($options->Functionnalities_9) ? json_decode($options->Functionnalities_9, true) : array();

                        if (isset($this->functionalities['ALL']) && array_key_exists('windows-server-path', $this->functionalities['ALL']))
                        {
                               //$path = realpath(__DIR__ . "/../../../../drive/logiref/login_attempts_ip_{$ip}.txt");
                               //$path = "./drive/logiref/login_attempts_ip_{$ip}.txt";

                               $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file
                               $path = $baseDir . "/drive/logiref/login_attempts_ip_{$userId}.txt";

                               // Normalize path slashes for Windows
                               $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path);

                               // Ensure the directory exists
                               $dir = dirname($path);
                               if (!is_dir($dir)) {
                                        mkdir($dir, 0777, true); // create folders if needed
                               }
                        }
                        else
                        {
                               $path = "./drive/logiref/login_attempts_user_{$userId}.txt";
                        }

                        return $path;
                }

                function get_ip_file($ip, $options)
                {
                        $this->functionalities = isset($options->Functionnalities_9) ? json_decode($options->Functionnalities_9, true) : array();

                        if (isset($this->functionalities['ALL']) && array_key_exists('windows-server-path', $this->functionalities['ALL']))
                        {
                                //$path = realpath(__DIR__ . "/../../../../drive/logiref/login_attempts_ip_{$ip}.txt");
                                //$path = "./drive/logiref/login_attempts_ip_{$ip}.txt";

                                $baseDir = dirname(__DIR__, 4); // go up 4 levels from current file
                                $path = $baseDir . "/drive/logiref/login_attempts_ip_{$ip}.txt";

                                // Normalize path slashes for Windows
                                $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path);

                                // Ensure the directory exists
                                $dir = dirname($path);
                                if (!is_dir($dir)) {
                                        mkdir($dir, 0777, true); // create folders if needed
                                }
                        }
                        else
                        {
                                $path = "./drive/logiref/login_attempts_ip_{$ip}.txt";
                        }

                        return $path;
                }

                function get_attempts($file)
                {

                        if (!file_exists($file)) return 0;
                        $data = json_decode(file_get_contents($file), true);

                        return $data['count'] ?? 0;
                }

                function increment_attempts($file)
                {
                        $data = ['count' => $this->get_attempts($file) + 1, 'timestamp' => time()];
                        file_put_contents($file, json_encode($data));
                        return $data['count'];
                }

                function reset_attempts($userId, $ip, $options)
                {
                        @unlink($this->get_attempt_file($userId, $options));
                        @unlink($this->get_ip_file($ip, $options));
                }
        }