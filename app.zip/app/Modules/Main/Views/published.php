<div class="offset-md-1 col-md-10">
        <div class="row">
                <div class="offset-md-3 col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                                <div class="col-md-12 padding-20 text-center">
                                        <h3 class="text-blue">En attente de taux</h3>
                                        <span><i class="fa fa-exclamation-circle f100 text-blue"></i> <br/><br/></span>
                                        <span class='f12 text-blue'>Retourner à la page de login pour se connecter.</span><br/><br/>
                                        <a href="<?= base_url("main/signin") ?>" class="btn btn-danger text-white f12">Retourner</a>
                                </div>
                        </div>
                </div>
        </div>
</div>