<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="row w-100 d-flex justify-content-center align-items-center" style="height: 100%;border: 1px solid #e7eaec;">
        <div class="col-md-6 ">
            <div class="row justify-content-center w-100"></div>
            <div style="height: 100%; display:flex;justify-content: center;align-items:center;margin-bottom:150px;" >
                    <img class="img-fluid" width="40%" height="40%" src="<?php echo base_url('ikwook_files/logos/CRDB-bank.png'); ?>" alt="CRDB BANK">
            </div>
        </div>
        <div class="col-md-6 d-flex flex-column justify-content-center align-items-center" style="background-color: white; height: 100%;">
            <div class="col-md-9" style="margin-top: 120px;">
                <!--- Warning message --->
                <div class="col-md-12 pl-0 pr-0">
                    <?php if ($flashSuccess = session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $flashSuccess ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if ($flashError = session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $flashError ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>

                <h2 class="text-black f20" style="font-family:Roboto">Modifier le mot de passe <strong class="w400"><b>Logiref 4.01</b></strong></h2>
                <div class="">
                    <?= form_open('main/setpassword', array('id' => 'loginform')) ?>
                        <div>
                            <div style="margin-top:15px;">
                                <p class="f13 w100" style="color: rgba(0,0,0,.55);font-family:Roboto;margin-top:15px;">Veuillez saisir et confirmer <br/> votre nouveau mot de passe <br/> <b><strong><?= $UserLogiref ?></strong></b></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group" style="border:2px solid #43B02A;height:48px;">
                                    <div style="float:left;background:#43B02A;padding:12px;width:48px;height:44px;"><img src="<?php echo base_url('ikwook_files/images/lock.png'); ?>" style="height:22px;"/></div>
                                    <input type="password" name="password" id="password-unique" class="form-control form-control-lg f13" required autocomplete="false" placeholder="Nouveau mot de passe" style="border-radius:0;border:none !important;position:relative;width:calc(100% - 48px);padding:22px;font-family:Roboto;" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group" style="border:2px solid #43B02A;height:48px;">
                                    <div style="float:left;background:#43B02A;padding:12px;width:48px;height:44px;"><img src="<?php echo base_url('ikwook_files/images/lock.png'); ?>" style="height:22px;"/></div>
                                    <input type="password" name="confirm" id="confirm-password-unique" class="form-control form-control-lg f13" required autocomplete="false" placeholder="Confirmer le mot de passe" style="border-radius:0;border:none !important;position:relative;width:calc(100% - 48px);padding:22px;font-family:Roboto;" >
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="hidden" name="userlogirefid" value="<?= $UserLogirefId ?>">
                                    <input type="hidden" name="reset_code" value="<?= esc($reset_code ?? '') ?>">
                                    <button type="submit" class="btn btn-block btn-lg text-white" style="background-color: #43B02A !important;padding:14px;border-radius:0;font-family:Roboto;">&nbsp;&nbsp;Enregistrer le nouveau mot de passe&nbsp;&nbsp;</button>
                                </div>
                                <div class="pull-left">
                                    <a style="cursor:pointer" href="<?= base_url('main/signin') ?>">
                                        <span style="color: rgba(0,0,0,.55);font-family:Roboto;">Retourner à la page d’accueil.</span>
                                    </a>
                                    <br/><a href="" style='color: #43B02A;font-family:Roboto;'>Contactez votre administrateur.</a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="d-none" id="loader">
                                    <div class="row text-center pt-3 d-flex justify-content-center">
                                        <div class="spinner-border text-primary text-center" role="status">
                                            <span class="sr-only">Loading...</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        <div class="f14" style="width:100%;border-top:1px solid #e7eaec;background: white;border-top: 1px solid #e7eaec;bottom: 0;left: 0;padding:20px;padding-left:50px;font-family:Cambria;">Powered by iKwook Express Sarl &copy; 2023</div>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/aes.js"></script>
<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/md5.js"></script>

<script type="text/javascript">
    $('#loginform').submit(function() {
        $("#loader").removeClass("d-none");
        return true;
    });
</script>