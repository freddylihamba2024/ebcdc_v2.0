<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="row w-100 d-flex justify-content-center align-items-center" style="height: 100%;border: 1px solid #e7eaec;">
        <div class="col-md-6 ">
            <div class="row justify-content-center w-100"></div>
            <div style="height: 100%; display:flex;justify-content: center;align-items:center;margin-bottom:150px;" >
                <img class="img-fluid" width="40%" height="40%" src="<?php echo base_url('ikwook_files/logos/CRDB-bank.png'); ?>" alt="CRDB BANK">
            </div>
        </div>
        <div class="col-md-6 d-flex flex-column justify-content-center align-items-center" style="background-color: white; height: 100%;">
            <div class="col-md-9" style="margin-top: 120px;">
                <!--- Warning message --->
                <div class="col-md-12 pl-0 pr-0">
                    <?php if ($flashSuccess = session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $flashSuccess ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if ($flashError = session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $flashError ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="" id="loader-page"></div>
                <h2 class="text-black f18" style="font-family:Roboto;">Authentification par OTP Mail <strong class="w400"><b>Logiref 4.01</b></strong></h2>
                <div class="">
                    <?php echo form_open('main/validate_otp', array('id' => 'otp-form')); ?>
                        <div>
                            <div style="margin-top: 20px;">
                                <p class="f13 w100" style="color: rgba(0,0,0,.45);font-family:Roboto;margin-top:15px;">Veuillez saisir le code OTP pour vous connecter.</p>
                                <p class="f18 w100" style="color: #43B02A;font-family:Roboto;margin-top:15px;"><span id="i-countdown">05</span> : <span id="j-countdown">00</span></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6" style="display:flex;">
                                <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="1" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>

                                <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="2" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>

                                <div style="width:27%;height:50px;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="3" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>
                            </div>
                            <div class="col-6" style="display:flex;">
                                <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="4" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>

                                <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="5" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>

                                <div style="width:27%;height:50px;border:2px solid rgba(0,0,0,.25);">
                                    <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="6" style="margin-top: 5px;text-align: center;border:none !important;">
                                </div>
                            </div>

                            <div class="col-md-12 mt-4">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-block btn-lg text-white <?= ($expiration)?"d-none":"" ?>" id="validate" style="margin-top:0;background-color: #43B02A !important;padding:14px;border-radius:0;font-family:Roboto;">&nbsp;&nbsp;Confirmer le code OTP&nbsp;&nbsp;</button>
                                    <?= form_close(); ?>
                                    <?= form_open('main/resend_otp', ['id' => 'resend-form']) ?>
                                        <button type="button" class="btn btn-block btn-lg text-white <?= (!$expiration)?"d-none":"" ?>" id="resend" style="margin-top:0;background-color: #43B02A !important;padding:14px;border-radius:0;font-family:Roboto;">&nbsp;&nbsp;Renvoyer le code OTP&nbsp;&nbsp;</button>
                                    <?= form_close() ?>
                                </div>

                                <div class="pull-left">
                                    <a style="cursor:pointer" href="<?= base_url('main/signin') ?>">
                                        <span style="color: rgba(0,0,0,.55);font-family:Roboto;">Retourner à la page d’accueil.</span>
                                    </a>
                                    <br/><a href="" style='color: #43B02A;font-family:Roboto;'>Contactez votre administrateur.</a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="d-none" id="loader">
                                    <div class="row text-center pt-3 d-flex justify-content-center">
                                        <div class="spinner-border text-primary text-center" role="status">
                                            <span class="sr-only">Loading...</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="code" id="otp-hidden-code" value="" />
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
        <div class="f14" style="width:100%;border-top:1px solid #e7eaec;background: white;border-top: 1px solid #e7eaec;bottom: 0;left: 0;padding:20px;padding-left:50px;font-family:Cambria;">Powered by iKwook Express Sarl &copy; 2023</div>
    </div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/aes.js"></script>
<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/md5.js"></script>
<script type="text/javascript">

    // Référence aux éléments du DOM
    const icountdownElement = document.getElementById("i-countdown");
    const jcountdownElement = document.getElementById("j-countdown");
    icountdownElement.textContent = "0<?= $i ?>";
    jcountdownElement.textContent = "<?= $j ?>";

    <?php
        if($j < 10){
    ?>
        jcountdownElement.textContent = "0<?= $j ?>";
    <?php
        }
    ?>

    let icountdown = <?= $i ?>;
    let jcountdown = <?= $j ?>;
    let timerInterval = null;

    <?php
        if($expiration){
    ?>
        icountdown = 0;
        jcountdown = 0;
    <?php
        }
    ?>

    // Fonction pour démarrer le compte à rebours
    function startCountdown() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }

        timerInterval = setInterval(() => {
            if(icountdown == 0 && jcountdown == 0) {
                $("#validate").addClass("d-none");
                $("#resend").removeClass("d-none");
                if (timerInterval) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                }
                icountdownElement.textContent = "00";
                jcountdownElement.textContent = "00";
            } else {
                if (jcountdown > 0) {
                    jcountdown--;
                    if (jcountdown < 10) {
                        jcountdownElement.textContent = "0" + jcountdown;
                    } else {
                        jcountdownElement.textContent = jcountdown;
                    }
                } else if (icountdown > 0) {
                    // Passer à la minute précédente
                    icountdown--;
                    icountdownElement.textContent = "0" + icountdown;
                    jcountdown = 59; // Repartir avec 59 secondes
                    jcountdownElement.textContent = jcountdown;
                }
            }
        }, 1000);
    }

    $(".otp-input").on("keyup", function(e) {
        const value = $(this).val();
        const index = parseInt($(this).data("index"));

        // Vérifie si la valeur est un chiffre
        if (/^\d$/.test(value)) {
          // Déplace le curseur vers le champ suivant
          $(`.otp-input[data-index=${index + 1}]`).focus();
        } else {
          // Efface la valeur si ce n'est pas un chiffre
          $(this).val('');
        }
    });

    $(".otp-input").on("focus", function(e) {
        $(".otp-input").parent('div').css("border","2px solid rgba(0,0,0,.25)");
        $(this).parent('div').css("border","2px solid #43B02A");
    });

    $(".otp-input").on("blur", function(e) {
        $(".otp-input").parent('div').css("border","2px solid rgba(0,0,0,.25)");
    });

    $('#otp-form').submit(function(event) {
        var code = '';
        var allFilled = true;

        $(".otp-input").each(function() {
            const value = $(this).val();
            if (value === '') {
                allFilled = false;
            }
            code += value;
        });

        if (!allFilled || code.length !== 6) {
            event.preventDefault();
            $('#loader-page').html('<div class="alert alert-danger">Veuillez compléter les 6 chiffres du code OTP envoyé !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>');
            return false;
        }

        $('#otp-hidden-code').val(code);
        $("#loader").removeClass("d-none");
        return true;
    });

    window.addEventListener('beforeunload', function() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    });

    startCountdown();
</script>