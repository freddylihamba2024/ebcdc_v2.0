<?php
        if(empty($_SESSION['Logiref_role']) && empty($_SESSION['userdata'])){
?>
<div class="offset-md-1 col-md-10">
        <div class="row">
                <div class="offset-md-3 col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                                <div class="col-md-12 padding-20 text-center">
                                        <h3 class="text-blue">D&eacute;sol&eacute;! votre session a expiré</h3>
                                        <span><i class="fa fa-jsfiddle f100 text-blue"></i> <br/><br/></span>
                                        <span class='f12 text-blue'>Retourner à la page de login pour se connecter.</span><br/><br/>
                                        <a href="<?= base_url("main/signin") ?>" class="btn btn-danger text-white f12">Page de login</a>
                                </div>
                        </div>
                </div>
        </div>
</div>
<?php
        }
        else{
?>
<div class="offset-md-1 col-md-10">
        <div class="row">
                <div class="offset-md-3 col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                                <div class="col-md-12 padding-20 text-center">
                                        <h3 class="text-blue">D&eacute;sol&eacute;! votre compte n'est pas encore activé !</h3>
                                        <span><i class="fa fa-jsfiddle f100 text-blue"></i> <br/><br/></span>
                                        <span class='f12 text-blue'>Veuillez contacter l'administrateur pour obtenir de l'aide quant à ce.</span><br/><br/>
                                        <a href="<?= base_url("main/signin") ?>" class="btn btn-danger text-white f12">Se connecter à nouveau</a>
                                </div>
                        </div>
                </div>
        </div>
</div>
<?php
        }
?>