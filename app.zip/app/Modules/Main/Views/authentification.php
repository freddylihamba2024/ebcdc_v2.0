
<?php echo form_open('', array('id' => 'form')); ?>
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
            <div class="row w-100 d-flex justify-content-center align-items-center" style="height: 100%;border: 1px solid #e7eaec;">
                    <?= csrf_field() ?>
                    <div class="col-md-6 ">
                        <div class="row justify-content-center w-100">
                        </div>
                        <div style="height: 100%; display:flex;justify-content: center;align-items:center;margin-bottom:150px;" >
                            <img class="img-fluid" width="40%" height="40%" src="<?php echo base_url('ikwook_files/logos/CRDB-bank.png'); ?>" alt="CRDB BANK">
                        </div>
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-center align-items-center" style="background-color: white; height: 100%;">
                        <div class="col-md-9" <?= ($qrcode == '')?'style="margin-top:120px;"':'' ?>>
                        <h2 class="text-black f18" style="font-family:Roboto;">Authentifiez vous avec OTP <strong class="w400"><b>Logiref 4.01</b></strong></h2>
                            <?php if(isset($subscription_id) && $subscription_id == 0){ ?>
                                <div>
                                    <?php if(isset($subscription_id) && $subscription_id == 0){ ?>
                                        <p class="f13 w100" style="color: rgba(0,0,0,.45);font-family:Roboto;margin-top:15px;">
                                            Veuillez scanner le qrcode avec l'app mobile OTP <br/> pour obtenir l'OTP.
                                        </p>
                                    <?php
                                        }
                                        else
                                        {
                                    ?>
                                        <p class="f13 w100" style="color: rgba(0,0,0,.45);font-family:Roboto;margin-top:15px;">
                                            Veuillez saisir le code OTP pour vous connecter.
                                        </p>
                                    <?php
                                        }
                                    ?>
                                    <div class="col-md-12">
                                        <section id="cat_list" class="text-center">
                                            <br/>
                                            <div style="padding:15px;width:80%;margin-left:10%;border:1px solid #f3f2f1;"><?php echo $qrcode; ?></div>
                                            <input type="hidden" name="subscription_token" id="subscription_token" value="<?php echo $subscription_token; ?>" >
                                        </section>
                                    </div>
                                </div>
                                <br/> <br/>
                            <?php
                                }
                                else
                                {
                            ?>
                                <div></div>
                            <?php
                                }
                            ?>
                            <div class="">
                                <div>
                                    <div style="margin-top: 20px;">
                                        <p class="f13 w100" style="color: rgba(0,0,0,.45);font-family:Roboto;margin-top:15px;">Saisissez l'OTP pour vous authentifier.</p>
                                    </div>
                                    <br/>
                                </div>
                                <div class="row" >
                                    <div class="col-6" style="display:flex;">
                                        <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="1" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>

                                        <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="2" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>

                                        <div style="width:27%;height:50px;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="3" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>
                                    </div>
                                    <div class="col-6" style="display:flex;">
                                        <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="4" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>

                                        <div style="width:27%;height:50px;margin-right:9.5%;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="5" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>

                                        <div style="width:27%;height:50px;border:2px solid rgba(0,0,0,.25);">
                                            <input type="text" name="code" class="otp-input form-control form-control-lg f13" maxlength="1" autocomplete="off" data-index="6" style="margin-top: 5px;text-align: center;border:none !important;">
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-4">
                                        <div class="form-group">
                                            <input type="hidden" name="subscription_id" id="subscription_id" value="<?php echo $subscription_id; ?>">
                                            <button type="submit" class="btn btn-block btn-lg text-white" id="validate" style="background-color: #43B02A !important;padding:14px;border-radius:0;font-family:Roboto;">&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>
                                        </div>
                                        <div class="pull-left">
                                            <a style="cursor:pointer" href="<?= base_url('main/signin') ?>">
                                                <span style="color: rgba(0,0,0,.55);font-family:Roboto;">Retourner à la page d’accueil.</span>
                                            </a>
                                            <br/><a href="" style='color: #43B02A;font-family:Roboto;'>Contactez votre administrateur.</a>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="d-none" id="loader">
                                            <div class="row text-center pt-3 d-flex justify-content-center">
                                                <div class="spinner-border text-primary text-center" role="status">
                                                    <span class="sr-only">Loading...</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="f14" style="width:100%;border-top:1px solid #e7eaec;background: white;border-top: 1px solid #e7eaec;bottom: 0;left: 0;padding:20px;padding-left:50px;font-family:Cambria;">Powered by iKwook Express Sarl &copy; 2023</div>

            </div>
    </div>
<?php  echo form_close(); ?>

<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/aes.js"></script>
<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/md5.js"></script>
<script type="text/javascript">
    $(".otp-input").on("keyup", function(e) {
        const value = $(this).val();
        const index = parseInt($(this).data("index"));

        // Vérifie si la valeur est un chiffre
        if (/^\d$/.test(value)) {
          // Déplace le curseur vers le champ suivant
          $(`.otp-input[data-index=${index + 1}]`).focus();
        }
        else {
          // Efface la valeur si ce n'est pas un chiffre
          $(this).val('');
        }
    });

    $(".otp-input").on("focus", function(e) {
        $(".otp-input").parent('div').css("border","2px solid rgba(0,0,0,.25)");
        $(this).parent('div').css("border","2px solid #43B02A");
    });

    $(".otp-input").on("blur", function(e) {
        $(".otp-input").parent('div').css("border","2px solid rgba(0,0,0,.25)");
    });

    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        $("#loader").removeClass("d-none");

        var url = '<?= base_url('main/validate_otp') ?>', data = $(this).serialize(), code = '', allFilled = true;
        $(".otp-input").each(function() {
            const value = $(this).val();
            if (value === '') {
                allFilled = false;
            }
            code += value;
        });

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                subscription_id: $("#subscription_id").val(),
                subscription_token: $("#subscription_token").val(),
                code: code,
                csrf_name: $("input[name='csrf_name']").val()
            },
            dataType: 'html',
            encode: true,
            success: function(response) {
                var result = JSON.parse(response);
                $('#loader').html('');

                if (result.otp) {
                    $(location).attr('href', '<?php echo base_url('main/overview'); ?>');
                }
                else {
                    $('#loader-page').html(result.message);
                }
            },
            error: function(error) {
                alert('ERROR!' + error);
                $('#password-unique').val("");
                $("#error").removeClass('d-none').show();
                $('#error_message').html("Une erreur est survenue lors de la connexion au serveur");
                $("#loader").addClass("d-none");
            }
        });
    });
</script>