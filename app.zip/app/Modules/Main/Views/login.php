
<div class="row" style="height:100%; display:flex;justify-content: center;align-items:center;border: 1px solid #e7eaec;">
    <div class="col-md-6" >
        <div style="height: 100%; display:flex;justify-content: center;align-items:center;margin-bottom:100px;">
            <img class="img-fluid" width="40%" height="40%" src="<?php echo base_url('ikwook_files/logos/CRDB-bank.png'); ?>" alt="CRDB BANK">
        </div>
    </div>
    <div class="col-md-6 d-flex flex-column justify-content-center align-items-center" style="background-color: white; height: 100%;">
            <div class="col-md-9" style="margin-top: 120px;">
                <div id="show-error-message" class="col-md-12 pl-0 pr-0">
                    <?php if ($flashError = session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger pb-0 fade show">
                            <div class="d-flex justify-content-between">
                                <p style="display:flex;align-items:center;"> <strong><i class="fa fa-exclamation-circle text-red f25"></i></strong></p>
                                <p style="width:85%;display:flex;align-items:center;"> <?= $flashError ?> </p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div>
                    <?php echo form_open('main/login', array('id' => 'loginform')); ?>
                        <div>
                            <div>
                                <h2 class="text-black f20" style="font-family:Roboto">Se connecter à <strong class="w400"><b>Logiref 4.01</b></strong></h2>
                                <p class="f13 w100" style="color: rgba(0,0,0,.55);margin-top:15px;margin-bottom:20px;font-family:Roboto;">
                                    S'il ne s'agit pas de votre ordinateur,<br/>
                                    utilisez une fenêtre de navigation privée<br/>
                                    pour vous connecter.
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group" style="border:2px solid #43B02A;height:48px;">
                                    <div style="float:left;background:#43B02A;padding:12px;width:48px;height:44px;"><img src="<?php echo base_url('ikwook_files/images/user1.png'); ?>" style="height:22px;"/></div>
                                    <input type="email" name="identifiant" class="form-control form-control-lg f13" required placeholder="johndoe@exemple.com" autocomplete="off" style="border-radius:0;border:none !important;position:relative;width:calc(100% - 48px);padding:22px;font-family:Roboto;">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group" style="border:2px solid #43B02A;height:48px;">
                                    <div style="float:left;background:#43B02A;padding:12px;width:48px;height:44px;"><img src="<?php echo base_url('ikwook_files/images/lock.png'); ?>" style="height:22px;"/></div>
                                    <input type="password" name="passcode" id="password-unique" class="form-control form-control-lg f13" required autocomplete="false" placeholder="************" style="border-radius:0;border:none !important;position:relative;width:calc(100% - 48px);padding:22px;font-family:Roboto;" >
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-block btn-lg f13 text-white" style="background-color: #43B02A !important;padding:14px;border-radius:0;font-family:Roboto;">Se connecter</button>
                                </div>
                                <div class="pull-left">
                                    <a style="cursor:pointer" href="<?= base_url('main/forgotpassword') ?>">
                                        <span style="color: rgba(0,0,0,.55);font-family:Roboto;">Mot de passe oubli&eacute;?</span>
                                    </a>
                                    <br/><a href="" style='color: #43B02A;font-family:Roboto;'>Contactez votre administrateur.</a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="d-none" id="loader">
                                    <div class="row text-center pt-3 d-flex justify-content-center">
                                        <div class="spinner-border text-primary text-center" role="status">
                                            <span class="sr-only">Loading...</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
    </div>

    <div class="f14" style="width:100%;border-top:1px solid #e7eaec;background: white;border-top: 1px solid #e7eaec;bottom: 0;left: 0;padding:20px;padding-left:50px;font-family:Cambria;">Powered by iKwook Express Sarl &copy; 2023</div>
</div>

<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/aes.js"></script>
<script src="<?php echo base_url('ikwook_bootstraps'); ?>/cryptojs3.1.2/md5.js"></script>
<script type="text/javascript">
    var jsonData = {};

    $('#loginform').submit(function (event) {
        $("#show-error-message").html('');
        $("#loader").removeClass("d-none");

        var code = $('#password-unique').val();
        var pass = encrypt(code);
        $('#password-unique').val(pass);

        return true;
    });

    function encrypt(text) {
        var key = CryptoJS.enc.Utf8.parse("1234567890123456"); //To avoid bit filling, use the 16-bit secret key directly
        var iv = CryptoJS.enc.Utf8.parse("1234567890123456"); //16-bit initial vector
        var encrypted = CryptoJS.AES.encrypt(text, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return encrypted;
    }

    function convertFormDataToJSON(formData) {
        // Create an empty object to store the JSON data
        const jsonObject = {};

        // Split the form data string into key-value pairs
        const pairs = formData.split('&');

        pairs.forEach(pair => {
            // Split each pair into key and value
            const [key, value] = pair.split('=');

            // Decode URL-encoded key and value
            const decodedKey = decodeURIComponent(key);
            const decodedValue = decodeURIComponent(value);

            // Add the decoded key and value to the JSON object
            jsonObject[decodedKey] = decodedValue;
        });

        return jsonObject;
    }
</script>