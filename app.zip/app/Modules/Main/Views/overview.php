<?php
        if($_SESSION['Logiref_privileges'] != 0){
                if (isset($_SESSION['Bank_rates']) && $_SESSION['Bank_rates'] !== 0)
                {
                        $bank = json_decode($_SESSION['Bank_rates'], true);
                        if(in_array('logiref',$_SESSION['Logiref_module']) || in_array('eximtrade',$_SESSION['Logiref_module']))
                        {
                                $usd = $bank['Dollar_4'];
                                $eur = $bank['Euro_5'];
                                $rand = $bank['Rand_6'];
                                $pound = $bank['Pound_7'];
                        }
                        elseif(in_array('etoll',$_SESSION['Logiref_module'])){
                                $usd = $bank['Dollar_7'];
                                $eur = $bank['Euro_8'];
                                $rand = (!empty($bank['Rand_6']))?$bank['Rand_6']:0;
                                $pound = (!empty($bank['Pound_7']))?$bank['Pound_7']:0;
                        }
                        else{
                                $usd = 0;
                                $eur = 0;
                                $rand = 0;
                                $pound = 0;
                        }
                }
                else
                {
                        $usd = $eur = $rand = $pound = 0.0;
                }

                $modules = isset($_SESSION['userdata']['modules']) ? json_decode($_SESSION['userdata']['modules'], true) : '';
?>

<div class="row">
        <div class="col-md-1 text-center">

        </div>

        <div class="col-md-10 content">
                <div id="loader"></div>
                <?php if(!empty($modules)): ?>
                    <div class="row">
                            <div class="col-md-12 no-padding">
                                <div class="col-md-12 f24 text-black">
                                        <h1>Bo&icirc;te à Outils <b>iKwook Logiref</b></h1>
                                        <p class="page-header">Solutions logicielles intelligentes pour l'automatisation du traitement des paiements</p>
                                </div>
                            </div>

                            <div class="col-md-12">
                                    <div class="row">
                                            <div class="col-sm-8">
                                                    <div class="col-md-12">
                                                            <h1 class="m-b-xs text-blue">
                                                                    <b>CDF <?= number_format($usd,2,","," "); ?></b>
                                                            </h1>
                                                            <small class="m-b-xs text-blue">1 USD</small>
                                                            <div id="sparkline_1" class="m-b-sm"><canvas style="display: inline-block; width: 353.333px; height: 50px; vertical-align: top;" width="353" height="50"></canvas></div>
                                                    </div>
                                                    <div class="col-md-12">
                                                            <div class="row">
                                                                    <div class="col-md-4 text-orange">
                                                                            <small class="stats-label">1 EUR</small>
                                                                            <h4>CDF <?= number_format($eur,4,","," ") ?></h4>
                                                                    </div>
                                                                    <div class="col-md-4 text-red">
                                                                            <small class="stats-label">1 POUND</small>
                                                                            <h4>CDF <?= number_format($pound,4,","," ") ?></h4>
                                                                    </div>
                                                                    <div class="col-md-4 text-black">
                                                                            <small class="stats-label">1 RAND</small>
                                                                            <h4>CDF <?= number_format($rand,4,","," ") ?></h4>
                                                                    </div>
                                                            </div>
                                                    </div>
                                            </div>

                                            <div class="col-sm-4">
                                                    <div class="row m-t-xs">
                                                            <div class="col-md-12">
                                                                    <h5 class="m-b-xs">Bienvenue !</h5>
                                                                    <h1 class="no-margins"><?php echo $session->userdata['user_fname'] .' '. $session->userdata['user_sname']; ?></h1>
                                                                    <div class="font-bold text-navy">Account ID: <span class="text-blue"><?php echo $session->userdata['account_id']; ?></span> <i class="fa fa-bolt"></i> Dernière connexion: <span class="text-blue"><?php $lastlog = new DateTime($_SESSION['userdata']['user_logout']);$formatter = new IntlDateFormatter('fr_FR', IntlDateFormatter::FULL, IntlDateFormatter::NONE);$formatter->setPattern('EEEE, d MMMM yyyy à HH:mm:ss');echo ucfirst($formatter->format($lastlog)); ?></span></div>
                                                            </div>
                                                    </div>
                                                    <table class="table small m-t-sm">
                                                            <tbody>
                                                                    <tr>
                                                                            <td>Banque</td>
                                                                            <td><strong>: <?php echo $session->userdata['account_business']; ?></strong></td>
                                                                    </tr>
                                                                    <tr>
                                                                            <td>Région</td>
                                                                            <td><strong>: <?= $region ?></strong></td>
                                                                    </tr>
                                                                    <tr>
                                                                            <td>Agence</td>
                                                                            <td><strong>: <?= $agence ?></strong></td>
                                                                    </tr>
                                                                    <tr>
                                                                            <td>Guichet</td>
                                                                            <td><strong>: <?= strtoupper($guichet) ?></strong></td>
                                                                    </tr>
                                                                    <tr>
                                                                            <td>Profil</td>
                                                                            <td><strong>: <?= $role_user ?></strong></td>
                                                                    </tr>
                                                            </tbody>
                                                    </table>
                                            </div>
                                    </div>
                            </div>

                            <div class="col-md-12 no-padding">
                                    <div class="col-md-12 f24 text-blue">
                                            <p class="page-header"></p>
                                            <h3>Outils disponibles pour la <b><?php echo $session->userdata['account_business']; ?></b></h3>
                                            <p class="page-header">Les solutions visant à simplifier divers traitements de paiement sont centralisées et intégrées.</p>
                                    </div>

                                    <div class="col-md-12" id="alert"></div>
                            </div>

                    </div>

                    <div class="row">
                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('logiref', $modules) &&((count($_SESSION['Logiref_module']) > 1 && (in_array("logiref",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("logiref",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('logiref', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("logiref",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("logiref",$_SESSION['Logiref_module'])))))?"href='".base_url('branch/taxdashboards/set/etax')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                   <div class="card-body">
                                                            <h5 class="m-b-md">e-Tax</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-calculator"></i> Impôts & Taxes
                                                            </h2>
                                                            <small>Encaissement impôts et taxes </small>
                                                   </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('quitus-fiscal', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("quitusfiscal",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("quitusfiscal",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('quitus-fiscal', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("quitusfiscal",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("quitusfiscal",$_SESSION['Logiref_module'])))))?"href='".base_url('quitus/dashboards/set/quitus')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Quitus fiscal</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-quora"></i> Attestation fiscale
                                                            </h2>
                                                            <small>Attestation valant Quitus Fiscal</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                            <!--<div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('elicense', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("elicense",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("elicense",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('elicense', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("elicense",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("elicense",$_SESSION['Logiref_module'])))))?"href='".base_url('elicense/dashboards/set/start')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">e-License</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-calendar"></i> Suivi (IB, EB, IS, ES & RC)
                                                            </h2>
                                                            <small>Suivi des souscriptions et licences</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>-->

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('eximtrade', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("eximtrade",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("eximtrade",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('eximtrade', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("eximtrade",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("eximtrade",$_SESSION['Logiref_module'])))))?"href='".base_url('eximtrade/dashboards/set/seguce')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Eximtrade</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-plane"></i> Seguce, OCC & BIVAC
                                                            </h2>
                                                            <small>Encaissement factures export et import </small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('e-toll', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("etoll",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("etoll",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('e-toll', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("etoll",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("etoll",$_SESSION['Logiref_module'])))))?"href='".base_url('etoll/dashboards/set/points')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">e-Toll + e-tickets</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-taxi"></i> Points de ventes
                                                            </h2>
                                                            <small>Gestion des points (péages, tickets, etc.)</small>
                                                   </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('qleads', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("qleads",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("qleads",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('qleads', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("qleads",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("qleads",$_SESSION['Logiref_module'])))))?"href='".base_url('qleads/qleadsdashboard/set/qdash')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Qleads</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-users"></i> Files d'attente
                                                            </h2>
                                                            <small>Suivi de la clientèle et perfomance</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('2ibanking', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("2ibanking",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("2ibanking",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('2ibanking', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("2ibanking",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("2ibanking",$_SESSION['Logiref_module'])))))?"href='".base_url('2ibanking/dashboards/set/overview')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Internet banking</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-desktop"></i> Banque en ligne
                                                            </h2>
                                                            <small>Suivi des paiements en ligne</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('iabanking', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("iabanking",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("iabanking",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('iabanking', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("iabanking",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("iabanking",$_SESSION['Logiref_module'])))))?"href='".base_url('iabanking/dashboards/set/banking')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Agency Banking</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-globe"></i> Agents bancaires
                                                            </h2>
                                                            <small>Suivi et gestion des agents bancaires</small>
                                                   </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('debitorders', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("debitsorders",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("debitsorders",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a <?= (array_key_exists('debitsorders', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("debitsorders",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("debitsorders",$_SESSION['Logiref_module'])))))?"href='".base_url('debitorders/dashboards/set/orders')."'  class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                    <div class="card-body">
                                                            <h5 class="m-b-md">Debit Orders</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-eercast"></i> Ordres de débit
                                                            </h2>
                                                            <small>Automatisation des ordres de paiements</small>
                                                    </div>
                                           </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card <?= (array_key_exists('subscriptions', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("subscriptions",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("subscriptions",$_SESSION['Logiref_module'])))))?'cursor-pointer':'card-bg cursor-not-allowed' ?> text-center">
                                            <a  <?= (array_key_exists('subscriptions', $modules) && ((count($_SESSION['Logiref_module']) > 1 && (in_array("subscriptions",$_SESSION['Logiref_module']))) || (count($_SESSION['Logiref_module']) == 1 && ($_SESSION['Logiref_role'] == 1 || $_SESSION['Logiref_role'] == 2)) || (count($_SESSION['Logiref_module']) == 1 && (in_array("subscriptions",$_SESSION['Logiref_module'])))))?"href='".base_url('subscriptions/dashboards/set/subscriptions')."' class='text-blue'":"onclick='SweetMsg()' class='text-blue cursor-not-allowed'" ?>>
                                                   <div class="card-body">
                                                            <h5 class="m-b-md">Subscriptions</h5>
                                                            <h2 class="text-navy">
                                                                    <i class="fa fa fa-address-card-o"></i> Abonnements
                                                            </h2>
                                                            <small>Traitement des cotisations, abonnements ou souscriptions</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                            <div class="col col-lg-4 mb-4">
                                    <div class="card text-center">
                                            <a  href='<?=base_url('payroll/dashboards/set/overview')?>' class="text-blue">
                                                   <div class="card-body">
                                                            <h5 class="m-b-md">Payroll</h5>
                                                            <h2 class="text-navy">
                                                                    <img src="<?=base_url('ikwook_files/images/payroll.png')?>" width="30" height="30"/> Payroll
                                                            </h2>
                                                            <small>Traitement des salaires</small>
                                                    </div>
                                            </a>
                                    </div>
                            </div>

                    </div>

                    <div class="row">
                            <div class="col-md-12 f24 text-black text-center">
                                    <p class="page-header"></p>
                                    <p class="page-header">&copy; Powered by iKwook Express Sarl.</p>
                            </div>
                    </div>
                <?php else: ?>
                        <div class="row">
                                <div class="offset-md-3 col-md-6">
                                        <div class="col-md-12" style="padding-top: 30%;">
                                                <div class="col-md-12 padding-20 text-center">
                                                        <h3 class="text-blue">D&eacute;sol&eacute;! vous n'avez accès à aucun module !</h3>
                                                        <span><i class="fa fa-cloud-download f100 text-blue"></i> <br/><br/></span>
                                                        <span class='f12 text-blue'>Veuillez contacter l'administrateur ikwook pour obtenir de l'aide quant à ce.</span>
                                                </div>
                                        </div>
                                </div>
                        </div>
                <?php endif; ?>
        </div>
</div>
<?php
    }
    else{
?>
<div class="offset-md-1 col-md-10">
        <div class="row">
                <div class="offset-md-3 col-md-6">
                        <div class="col-md-12" style="padding-top: 30%;">
                                <div class="col-md-12 padding-20 text-center">
                                        <h3 class="text-blue">D&eacute;sol&eacute;! vous n'avez accès à aucun privilège !</h3>
                                        <span><i class="fa fa-jsfiddle f100 text-blue"></i> <br/><br/></span>
                                        <span class='f12 text-blue'>Veuillez contacter l'administrateur pour obtenir de l'aide quant à ce.</span>
                                </div>
                        </div>
                </div>
        </div>
</div>
<?php
    }
?>

<!-- Sparkline -->
<script src="<?= base_url('ikwook_bootstraps/inspinia/js/plugins/sparkline/jquery.sparkline.min.js') ?>"></script>

<script>
        function SweetMsg() {
                $("#alert").html('<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-d-none="true"><i class="fa fa-times pull-left"></i></button>Ce menu n\'est pas encore disponible, veuillez contacter votre administrateur.</div>');
        }

        var sparklineCharts = function(){
                $("#sparkline1").sparkline([34, 43, 43, 35, 44, 32, 44, 52], {
                        type: 'line',
                        width: '100%',
                        height: '50',
                        lineColor: '#1ab394',
                        fillColor: "transparent"
                });

                $("#sparkline2").sparkline([32, 11, 25, 37, 41, 32, 34, 42], {
                        type: 'line',
                        width: '100%',
                        height: '50',
                        lineColor: '#1ab394',
                        fillColor: "transparent"
                });

                $("#sparkline3").sparkline([34, 22, 24, 41, 10, 18, 16,8], {
                        type: 'line',
                        width: '100%',
                        height: '50',
                        lineColor: '#1C84C6',
                        fillColor: "transparent"
                });
        };

        var sparkResize;

        $(window).resize(function(e) {
                clearTimeout(sparkResize);
                sparkResize = setTimeout(sparklineCharts, 500);
        });

        sparklineCharts();

</script>