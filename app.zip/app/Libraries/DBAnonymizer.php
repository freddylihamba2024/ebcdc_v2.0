<?php

namespace App\Libraries;

use App\Models\MYTest;
use App\Libraries\Cryptor;

class DBAnonymizer
{
    private $my_test;
    private $data_to_return = [];
    public function __construct()
    {
        $this->my_test = new MYTest();
    }

    //this function anonymizes or crypt entire table data
    public function anonymize($data, $columns)
    {
        if (array_is_list($data)) {
            foreach ($data as $key => $value) {
                $array_keys = array_keys($value);
                foreach ($array_keys as $array_key) {
                    if (in_array($array_key, $columns)) {
                        foreach ($columns as $column) {
                            $encryptedData = Cryptor::encrypt($value[$column]);
                            $value[$column] = $encryptedData;
                        }
                    }
                }
                array_push($this->data_to_return, $value);
            }
            return $this->data_to_return;
        } else {
            $array_keys = array_keys($data);
            foreach ($array_keys as $array_key) {
                if (in_array($array_key, $columns)) {
                    foreach ($columns as $column) {
                        $encryptedData = Cryptor::encrypt($data[$column]);
                        $data[$column] = $encryptedData;
                    }
                }
            }
            return $data;
        }
    }

    //this function decrypt all table data
    public function reveal_data($data, $columns)
    {
        foreach ($data as $key => $value) {
            $array_keys = array_keys($value);
            foreach ($array_keys as $array_key) {
                if (in_array($array_key, $columns)) {
                    foreach ($columns as $column) {
                        $revealed_data = Cryptor::decrypt($value[$column]);
                        $value[$column] = $revealed_data;
                    }
                }
            }
            array_push($this->data_to_return, $value);
        }
        return $this->data_to_return;
    }
}
