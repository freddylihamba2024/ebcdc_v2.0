<?php

namespace App\Libraries;

use CodeIgniter\Email\Email;

class Mail{

	/**
         * New user
         * Should be using Email or Mobile phone as username
         * By Papin - Update 16 01 2015
        */

        protected $email;

        public function __construct()
        {
                $this->email = \Config\Services::email();
        }

        protected function initEmailCurl($subject, $mailRcpt, $message, $attachmentFilePath = null)
        {
                $smtpServer = "mail.tmb.cd";
                $smtpPort = 25;
                $smtpUser = "";
                $smtpPass = "";

                $mailFrom = "no-reply@ikwook.com";
                $mailCc = "support@ikwook.cd";

                $mimeBoundary = "==Multipart_Boundary_" . md5(time());
                $attachmentHeaders = '';

                if (!is_null($attachmentFilePath) && is_readable($attachmentFilePath)) {
                        $attachmentFileName = basename($attachmentFilePath);
                        $fileContent = file_get_contents($attachmentFilePath);
                        $fileEncoded = chunk_split(base64_encode($fileContent));
                        $attachmentHeaders = <<<ATTACHMENT
                        --$mimeBoundary
                        Content-Type: application/pdf; name="$attachmentFileName"
                        Content-Transfer-Encoding: base64
                        Content-Disposition: attachment; filename="$attachmentFileName"

                        $fileEncoded

                        ATTACHMENT;
                }

                $emailContent = <<<EMAIL
                From: $mailFrom
                To: $mailRcpt
                Cc: $mailCc
                Subject: $subject
                MIME-Version: 1.0
                Content-Type: multipart/mixed; boundary="$mimeBoundary"

                --$mimeBoundary
                Content-Type: text/html; charset=UTF-8
                Content-Transfer-Encoding: 7bit

                $message

                $attachmentHeaders
                --$mimeBoundary--
                EMAIL;

                $tempEmailFile = tempnam(sys_get_temp_dir(), 'email');
                file_put_contents($tempEmailFile, $emailContent);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, "smtp://$smtpServer:$smtpPort");
                curl_setopt($ch, CURLOPT_UPLOAD, true);
                curl_setopt($ch, CURLOPT_MAIL_FROM, $mailFrom);
                curl_setopt($ch, CURLOPT_MAIL_RCPT, [$mailRcpt, $mailCc]);
                curl_setopt($ch, CURLOPT_USERPWD, "$smtpUser:$smtpPass");

                $emailStream = fopen($tempEmailFile, 'r');
                curl_setopt($ch, CURLOPT_INFILE, $emailStream);
                curl_setopt($ch, CURLOPT_INFILESIZE, filesize($tempEmailFile));

                $response = curl_exec($ch);
                $error = curl_error($ch);

                fclose($emailStream);
                curl_close($ch);
                unlink($tempEmailFile);

                if ($response === false) {
                        error_log("Erreur d'envoi SMTP : " . $error);
                        return false;
                }

                return true;
        }

        public function send_mail_to($to, $subject, $message, $from_email, $from_name = null, $bcc = false, $attachment = null, $cc = null)
        {
                $status = $this->initEmailCurl($subject,$to,$message,$attachment);

                return $status;
        }

        public function send_mail($to, $subject, $msg, $from_email, $from_name = null, $bcc = false, $attachment = null, $cc = null)
        {
                $title = "Bienvenue sur la plateforme cloud iKwook";
                $subtitle = "Merci de garder ces informations très confidentielles";

                $message = 'Salutations, cher(e) client(e)';
                $message .= '<p>'.$msg.'</p>';
                $message .= '<p>Si besoin veuillez contacter votre '.addslashes("IT support").' pour plus d\'information.</p>';
                $message .= '<p>Bien cordialement,</p>';
                $message .= '<p>L\'équipe de support de Logiref</p>';

                $message = $this->format_mail($title, $subtitle, $message);

                $status = $this->initEmailCurl($subject,$to,$message,$attachment);

                return $status;
        }

        public function format_mail($title, $subtitle, $message)
	{
		$message = '
                        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                        <html xmlns="http://www.w3.org/1999/xhtml">
                                <head>
                                        <meta name="viewport" content="width=device-width" />
                                        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                                        <title></title>
                                        <style>
                                        /* -------------------------------------
                                                GLOBAL
                                                A very basic CSS reset
                                        ------------------------------------- */
                                        * {
                                                margin: 0;
                                                padding: 0;
                                                font-family: "Roboto", "Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif;
                                                box-sizing: border-box;
                                                font-size: 14px;
                                        }

                                        img {
                                                max-width: 100%;
                                        }

                                        body {
                                                -webkit-font-smoothing: antialiased;
                                                -webkit-text-size-adjust: none;
                                                width: 100% !important;
                                                height: 100%;
                                                line-height: 1.6;
                                        }

                                        /* Let\'s make sure all tables have defaults */
                                        table td {
                                                vertical-align: top;
                                        }

                                        /* -------------------------------------
                                                BODY & CONTAINER
                                        ------------------------------------- */
                                        body {
                                                background-color: #f6f6f6;
                                        }

                                        .body-wrap {
                                                background-color: #f6f6f6;
                                                width: 100%;
                                        }

                                        .container {
                                                display: block !important;
                                                max-width: 550px !important;
                                                margin: 0 auto !important;
                                                /* makes it centered */
                                                clear: both !important;
                                        }

                                        .content {
                                                max-width: 550px;
                                                margin: 0 auto;
                                                display: block;
                                                margin-top: 10px;
                                                /*padding: 20px;*/
                                        }

                                        /* -------------------------------------
                                                HEADER, FOOTER, MAIN
                                        ------------------------------------- */
                                        .main {
                                                background: #fff;
                                                /*border: 1px solid #e9e9e9;*/
                                                border-radius: 3px;
                                        }

                                        .content-wrap {
                                                padding: 15px 50px 0px 50px;
                                        }

                                        .content-block {
                                                padding: 0 0 20px;
                                        }

                                        .header {
                                                width: 100%;
                                                margin-bottom: 20px;
                                        }

                                        .footer {
                                                width: 100%;
                                                clear: both;
                                                color: #999;
                                                padding: 20px;
                                        }
                                        .footer a {
                                                color: #999;
                                        }
                                        .footer p, .footer a, .footer unsubscribe, .footer td {
                                                font-size: 12px;
                                        }

                                        /* -------------------------------------
                                                TYPOGRAPHY
                                        ------------------------------------- */
                                        h1, h2, h3 {
                                                font-family: "Roboto","Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
                                                color: #000;
                                                margin: 40px 0 0;
                                                line-height: 1.2;
                                                font-weight: 400;
                                        }

                                        h1 {
                                                font-size: 32px;
                                                font-weight: 500;
                                        }

                                        h2 {
                                                font-size: 24px;
                                        }

                                        h3 {
                                                font-size: 18px;
                                        }

                                        h4 {
                                                font-size: 14px;
                                                font-weight: 600;
                                        }

                                        p, ul, ol {
                                                margin-bottom: 10px;
                                                font-weight: normal;
                                        }
                                        p li, ul li, ol li {
                                                margin-left: 5px;
                                                list-style-position: inside;
                                        }

                                        /* -------------------------------------
                                                LINKS & BUTTONS
                                        ------------------------------------- */
                                        a {
                                                color: #1ab394;
                                                text-decoration: underline;
                                        }

                                        .btn-primary {
                                                text-decoration: none;
                                                color: #fafafa !important;
                                                background-color: #1ab394;
                                                border: solid #1ab394;
                                                border-width: 5px 10px;
                                                line-height: 2;
                                                font-weight: bold;
                                                text-align: center;
                                                cursor: pointer;
                                                display: inline-block;
                                                border-radius: 5px;
                                                text-transform: capitalize;
                                        }

                                        .btn-info {
                                                text-decoration: none;
                                                color: #fafafa !important;
                                                background-color: #29a7dc;
                                                border: solid #29a7dc;
                                                border-width: 5px 10px;
                                                line-height: 2;
                                                font-weight: bold;
                                                text-align: center;
                                                cursor: pointer;
                                                display: inline-block;
                                                border-radius: 5px;
                                                text-transform: capitalize;
                                        }

                                        .btn-info:hover,.btn-primary:hover {
                                                opacity: .85;
                                        }

                                        /* -------------------------------------
                                                OTHER STYLES THAT MIGHT BE USEFUL
                                        ------------------------------------- */
                                        .last {
                                                margin-bottom: 0;
                                        }

                                        .first {
                                                margin-top: 0;
                                        }

                                        .aligncenter {
                                                text-align: center;
                                        }

                                        .alignright {
                                                text-align: right;
                                        }

                                        .alignleft {
                                                text-align: left;
                                        }

                                        .clear {
                                                clear: both;
                                        }

                                        /* -------------------------------------
                                                RESPONSIVE AND MOBILE FRIENDLY STYLES
                                        ------------------------------------- */
                                        @media only screen and (max-width: 640px) {
                                                h1, h2, h3, h4 {
                                                font-weight: 600 !important;
                                                margin: 20px 0 5px !important;
                                                }

                                                h1 {
                                                font-size: 22px !important;
                                                }

                                                h2 {
                                                font-size: 18px !important;
                                                }

                                                h3 {
                                                font-size: 16px !important;
                                                }

                                                .container {
                                                width: 100% !important;
                                                }

                                                .content, .content-wrap {
                                                padding: 10px !important;
                                                }
                                        }
                                        </style>
                                </head>

                                <body>

                                        <table class="body-wrap">
                                                <tr>
                                                        <td class="container" width="600">
                                                                <div class="content">
                                                                        <table class="main" width="100%" cellpadding="0" cellspacing="0">
                                                                                <tr>
                                                                                        <td class="content-wrap">
                                                                                                <table width="100%" cellpadding="0" cellspacing="0">
                                                                                                        <tr>
                                                                                                                <td class="aligncenter">
                                                                                                                        <img class="img-fluid" style="width:100px;margin-bottom:13px;" src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAMEAAABGCAYAAAB19/D8AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAK6wAACusBgosNWgAAABZ0RVh0Q3JlYXRpb24gVGltZQAxMS8wOS8xOB7IGrMAAAAcdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3JrcyBDUzbovLKMAAAGGXByVld4nO2W/27aVhTHb0JDiwvNwli8hbaAa/tS1otNXFULapmmVv1v0rRVmrT/aMBZtPBDQEX6KH6ZPcDkd9kbzDvn2hibJJBQGipxTxJsX47v53zPPffk/vPf3/+SPul7aC78eK7rOY5n255leRbxiOUR4vLvXP7nOvDruDb82q5luRZxCXE8z4H38EsH3nb4xbFtx7Js17NdcPfwDX/M9SzXtRzPcuDTAQ/LdojrwizEgU+H2C6xnSI3pSHB58tBy67/+uZt8bxz1h3W4emV8udo1K8bxng8ro6tam9wYtSOjo4M89A4PGTgwYYfu6PmOesOn/iTTOZ50x4eD077o9Net4jPzfe9D6NXihL4+OaDzjv9ENQdVput3vt29bjXMc6bfaNWNY1wZpwcvOuvB+3mqDd41+udNX5C9+Lb00F73Bv8NSy+/u1Fsfz7abfVGw+fvjRm3S+bqf0G/hqHZu2ImRarPX9Xe1E3n9etH/6IvO87zbz+c691an9c8HrEaZIhYyZFy6audRxmrv9hcMYXqHVstM/anXZ3NITs1eLZax3X7d6g0xw1TjvNk7bR7568NKaDc+PzR6FAGhIIw2XrtEfNRiysuUZu2QRf8L8cvrRm/rr1byxf2nD9G8uf/c942/x16xd8wf9i+NKG699YvrTh+gVf8AVf8NfLlzZc/8bypRvyszmwzOr4N9WfQlsJfil+LrkI/xAz9Og6GVqCv4f43TkOu7mdBFx2Uo/meS3Lzy1Kfi78NpmbBqBUKvIq+Kg+uTcPHxG9Na3SomZcth435udSybnypdiXsASB6oJeXYX+LMq/clkz2VwqGxu5k0s94jcl7ekK+LuIz12JT+0mLo7u8ABA/8En87Op1L052c9ePixhUI8142b6E1Wj+iTunIHKv5vdnhviVjqSgkQmrDlZZwv0S3F+Wdd0M+6cxdpLkEw4a3iTkP27jFxRKkpQHxmlXKkoef/hOy3gH+TzkURcrZ9qukZjW2YX5CchxwVqbPkjjAaaaIlhFCaFoOHHfABPJlX5k5kP9H+L15KmR9fhaj68SdUYPxVsvbQaxCVT1fTvqAqBZJhKaZpIsq6xfMJQaSFN7hchBFzGfY2W8JU4fg6/gAFEXaeNj6oKXiRQyxR/hPJsTPypSpkWPujaAddfQj+9EJ2ThAt/sf4BHw01g/JzAY1ikckA1Cv8O5VhOGppMqsWCV5WaTmB+iFUho7X0z9je4jfm8xoyn4YssqwFKC5YMFM0wUJiD4YCtmnoJ9RGp91Hp+fMqQZ9cFy0wqfVyY8txmmZ6AYokhNnwot6LQMKaIKvYCfq38Hus3DYDf7tZdh/o5kqoFJp7i4Za6W18vTCDLysK/pVcw/pSqr3IBPUndTqYf8LufvfKZrfIIC7gBKGWbe4AuBuxJDCayEyIllMJj7sJtgv1DlJvyw2fMTl4Tv860PioCPBb1PIRKG+0F+FtNPp/mHAmQkjQUJaZlpafPrD1Vj98ATVzKBeYYJsARQK+NdoKQqkq6l+W6cSoZUT3sXxUhBP18uLb4C8/nBf7ssqsfah1lVigoonCZUvjulkgmZD2ROkiuhYwiChwTop2WeGC1/fT5PwF4Oiy8xmZcr2GdhLeOdf0t1esAb8xb0Puq3PTATqxOrlQbJiDbVBXw8amIMk53vZ0DBtE8WGBRNZoSeZyj5kgJXCVNtVvKlCjRl2Q+9EsxgRmpwAT/B6ZETFy6samI71YJmJ09bzWNgGlWD8t73DfYgk0060bYWbA8ozUgNTsnSZXziy09+FQ4AgqpP8Ho/DEkKjwQFyPv3tOR3LRluKS0ELYwWgoALhcfTElign2zdgx5w7+vpgIQLQPOzfsvaIj7ZxgREB+RnsOKGcsHxM/FxBeLnOlhAlZoXHZflS/P5d1IPZkb4Hpht5MvzF+i/5FSLRzN9NSVwDf5F2wf9GrvkqH9LfCKlJWlbWuz3ufirM8EXfMEvhl14bfx1699YvrTh+gVf8L8Y/krOVJ/AL946v91tvVLGyo+N2yYLEyZMmDBhwoQJEyZMmDBhwoStx34hTXJC2qRIausORdga7H+kLTVS14z2VAAAAEhta0JG+t7K/gAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKaQzoQAAOMJta1RTeJztfdtz20aWPjYTx5Esy3ayNfuwL6ra/dXvKR5cSfBRJEVJE0rikJQt58UFgkSsjSxnJVkZj4r/+/Y5p3FrNK4kJcqBlbBJXBvfOf31uQE4+rl9e/dmODq/c+Zvhkfnd9q8N+xEmuE/js/vzInR0hx9ftbveHfq/B01bw+73p3WMuYHh2PvrqnOh3sj1mqvW7ZhtZrz4ej0nG3W3mcH8vi/+aDfv71rD9hHZ3d8fad8r0wUV3mvtBVHuVbOFXd+eHzElm+x5Zds+QFbfqVMlR2lz9ZeKrP5sHsygcPuHuPRd1nfjZk9b3cPWUfn7SN2ETPW4CW1R3u40agH19IeHeCvdp+an7HpHPMD7PXw93CM2/ba+Ks3xOaYFo4GbFt33h7TyjEdfTyikxzR8ag53IVeHkOv1Hn3RIPudE90OEz3xMCmxxbqrNGpMaCZF8DmRQKbofJJ+cyWTZWZMl0UIe3xI+Rrz4jh4ik3i2iP5pmV9UdbEB1ttfoTorOg/ogYldGgB8Zoi2O0y/C5Yki02ednhtYHjtX3HKsQwyx0oN8ReBom4YPrc/GxzRg+agwfQ48jNF1wjOmEkE4ImYSQSQiZ89HgF5LqaMS+uBO24IQuYzQ6wQVlMHzGMRwz7fon07fPbH2enhm6TNGygdRaHEp94paA0rUJSly+MjD1VjEwtzmYHaZwF+zvXPmVweUovysflC8c0I2IUn5k3z8pnzLB1Pio1YzCtK+ppnzYqhnD1lIJSeQDQNJzCo9c3S6MpWHrhKWhTUtjlz2gm1OCznYJudmSDAo1a7rUK5JdMciqAvQPNk7PYasYQKZFAGkTQbc8DpFKGLlZAxXUIl+3kBAjOAGbAk6oVCsAKqlbwUCtOkCHbO0EB+hlppppreXq2XIn1dXo2Xcco7dsLriRotMUVEwwOrLsMtg1ho/+4PiMBm1i/1E7QfrPArw+oE3vMo1hyAna1MF5Eyj/SyG653hpuitFTCD8pltepcwGQeZwzIypWXjurD4o2Ql1yyEgYaopj+QAyf+GoXlRCknPLDBzev7MCfZEQSADbuNAok2yfBwBvpFvjQC5kVnifwFkyS7xvwxLQ/w07lyUgRfnjFx3AtW5NL4zbpnAzgBwq7FsgIcMV302I8zESSMbsyoGspwUdSvTQHb18mM8MI8tnaAjDIthp80KU2OgeLoXg24jgA5mkC84l1bxzeKuGboIFWMfRQaybnMrBZ2SgmgZugytBqHVILQaNJSJAOHLxBOGMswxw4MSOD4NrBVH+S0nRmITii1CEU20CIrqoiiahCKpmBRGyyEc9QwcLZWHAVo8DtDiSHLFa3DNa5hpYNKSCJjM6CynlGM20plKKr+VGcWFtLKY9SxXSxzMMFFPls5/OMHgGPaBHEZnGpp78tWzi4P5A/JfPFwVWVN40EujCGsQrtIqhqvSUXopRamLgb0JM8Gzh/W64qTfE05jNo7PmXvyWHEylo7TRoDTJ2aR3NxjYDiLx1quWdFJ41OCStCoBI1K0KgEjVoQmm2pCvFsTHn1iXO9ev/ZlywysgghixCyFqLsA/Reb3O813XNMHCU2IyNMFkEk0UwOQSTQzA5Utu/B+4mplvGwDUSZbpi5teOcsS/zZSrIqZYGdNBs2ZFkg2q1MkvPeTkhgM3Z22Cyibjn3IN6YGRbOwOMMD0gQeaPiBbxbEDqxHDluABoTTVmCFLflPCkJUORtTFohFxZ6XYFYfKH5H9AKJ0RRPjb65sRELUOpW2Qh+9QjBpZXoWtevDSBJYqhhJsmcl8HwaM/Mvl5tzL5jIEqbGeximAViAYxSs7zhYJ5Ay4BBtBu452FYQbsuzrpyqxQngzeTBZAiupe8K+aE2VOiEY6kVCGfAUrSwOFi6Tb4Pejq76LCh8jUa5PmY0GI4MRfDVxEMIWIExR4jtFMdbpVlzxGONMBWAFKIZGWkZlyHQNU5qK4uxNemPEZEE3eOh8lUl2C1Oa42AevaBKzLgXVt0V+HL0P/S2yA06rgix9gGgy5Tzoc+iHOUTJcJxOFH6S7F/iNaSH4hRBdgH5m3jUlVmJyu88k7JmBhNhja2CLSBOKUqRxEgeAUdGHpPhF4d0M4L3BmAoUo1wXsX/8pLZfbKE5swL4FrF/LIEx4swKfDvCirl0cBtmOXB94DQviJEggHo+U/wojyHzcoxi/NusyL+Fpike2vMcoUaAw2lOYvRryujXh1PkCYv7cRZ35FgbL7qgKNSQAB0NOTXz3wC05kkp2fdwBgzKS/Ytqa6a8hNbe84gz80lxfPklaPPWb5fCRsgrqh21cBBEpn/kCHD1HCXLb1hv39i38BQB88wN8mxXMyWazctETN/mu+wSf6C/e8P3eiWMncG3ZZUE9MpH1goYWAWn2IKAYXjFPgvObeA5QlrRtQWg9SfrveDwoNzmLBXUz7sFjfTS1WbCdYnpz+HgHQISDthqHPTM1ptFgM0CuBzDuBbtGhmPDWJOigkNIpFb4S6vcCvLhbAgRRjSW0MbB40mRZKS0qRDHLmYaINYxX+l+FJZNpWaTYRlLQ4xsWSRrot01MKAC0RYT9nZPh5X6s4wHKf0pDljHBkp439cjCWcco9bj16cevRcwqAWMTdXDQAJFdRXYYgeeVRLyhItokVkj5fDrmF/Un5KPAlTEGXigdFWTBdyzDULJMwbMQxdEpA2JDqodSoodRvFavG18I4YepcDbE1sKXR2+DDtzhovsJRkiTbXTFkg1Yok5TPLmpx6xr5NonVxMxPmge+ipA0B4JFvOiLQV/IvrZn3L6GLwMfw5Hv+g19jqSgRzFM/brAHrgwMkQnZsy59rWvjHedOV8jhrJiBLn/xzE1ZJi6ttxhafHoWosXdbQaFClCt8TPkbdDN8XPmQvR8XQQQ2/6fxmMDhqU2eppVbV9Sswo5PNFYm8lqrCYfyhVT1je48t7tDyAEmfrJp+sm6ShPqSooAfkGpYb7O8Qz+zZJT5DF6obLGNLcs2cSJOhgictnV3SAhNpFTLxCkyuiugxp9wLcsqgusSJ+jMa4L5Z/oSDaCjdCuVtzSL30RRxaYy4iRMHkKmKJBRRLGym25JY8AHN0WVw2gxxYn7gPpo5f2QjJp1git165EOm5eucK51gtJmMDLV7hWwrsGA+YJE0hB1midJ7EbZG1ZyDVjwLGPgqRqN8UaBvCOZ5fQe+6XyQNJ3zoHsVzLkXeNdH2TSDPEO4uOphPXkkz+BIrWlf+YpEYsWZWKp8vkUzDJIFSQOm6AA+YctvMOCVd/vpMgawVTwAK2DYyp80/PJUwZxe0vD1dRBq888xVrhyHUxUUhpSJWzZ8WSXJ5015PlDocDXlVOgzB4UwzhhmotbMdE4Nqkru8CmRdNyo5y2Pg8850/oynxgwPNbJLJ1dnkFcVnztC29RQ7iIBHE9TIZmDStJftmlHQC8xDcjiD4Twzi7GCkojSGGBgscbNrgKOZ70pXzg+Ar1xgEsIghNuUFKRjkQ8u8L/46ZcBNybhEikhG7EuxcxhnhT+yqXwBjNeLla/XmPyARgYYsQ7IcGUpxO6laqoYkvZJK7YgjWFobYkl5SyQA0eIzJ4aJ21yCVcPNH5bcCFEwtmorQiqTI7nikDe3/e63dv73rRJw14KJYRBuTOI0WkHorjGHMaH1FQp6lruDh6BEiPuKFHOPT2UIt7wy5uMhzSugNqzqCZ96JeHHWIP/YBPDahS9E1p6lrqnVJpy6xZj/o0SvWHzfIR0y5Nt5EUj7XARe7vOYDpj5X+Y3xiJ+96O2/YcAfd+jgh+z7/gCexdKjh6yo+G8eWaX5q/jzV2DdO1inLn4creIh/FXsN0I3j4nuGRddB58m4LIBfCER35CDmNSo6Jpq4jNIfEYtvgri2+biGzKAXHbREEX5VRDidiAq2TanBbapJliHBOvUgq0g2M1gXEKCAAycqLPjRZIH/rrTjHXVBGiSAM1agAuMTBLEDdpGVz5swsiUb3NaYJuFKFfTaslWkGxofjlYYhPei+jxLIC//DRleTWpWSQ1qxbaAkIboLnpRp445fE4iL/8NGV5NaE1SWjNWmgLCK2HwEwDWHzhhMtPU5ZXE5pNQrNroVUQ2nMutD3+LJrfkfSi9stzLibZFqe5W1QTaYtE2qpFWkGkT7lI25iLvQ4ytF7wQIirYAyKS6uJyyVxubW4KohrI3AKYeTQbdaiPx+uEf35cE010U1JdNNadAvMeG+x+HOWmPHC5acpy6sJbUZCm9VCW8BXH4S5s8Ap2AzsyOi604x11QTokQC9WMe2Am2aKROlixL5gKk9P4fva4+4/jRnfbVOajx6DG1XiwDb6+qxX0bslxn7NSYB7GNQvIq2vuTauodVC5jPwBT8PtZtsb0iOtuQKYquGm5cUdTXuu2v1SatpjaJrzWtYO3M9Niv2NqGv7LhzFxVi69sWukH1sQeiUPl8XV/eSN0Id1oY2nGDOOhU+UdVrdQUVCoG4a0iy1VnehxDAIIqJtpJCWV4KpO8sA4vxJwjiDsL0tD+nXYl4mqO04aDFOPrY6vbIl7ZqK95BM9MOIbHHFYAwYesHiIsCnrVKtpNjThso3gsidT2xWYwA7WNlx9pjWk1zPzphN3msT+YbqwJlIZ4cN/bwWpSOm7ZbTY+E+jb1OHvzT6nlgTYyIwdEjf+C+Nvqcz+JNiYavwV3D2WevuP7A2bHJtiDwwla3L0Qe68jRA4dLA+JUD2miQaSwFFHZsemmA0olTppkm+6+gPqx199dEH8gKSc6L0m5lzP++3SAKZoHjPDBCzwL+/J1nruFlCB/zx4zYMaZ00ZUJnQv7rTupKgf7iYe15xGNS7XLAjCKDJh17fsD68J2xMKZoFd3g89jEEeNFFVVNWwRm5CGGHItp5lGQ2wwNDJwTe7azNhVE3tUSCnWuvsPrBcvYiwaePl5fkbWeIsAkDowYC+Z/FZ1kgdG+U8YA1xIG6Fm9hPeM3OjnPBn8Pyaj5XeUh2rlWa3SEMICxxnTXQq0KRQu/Jw8gWe3bkiVlCR4ywxrrzX697e7fUi6dQZonWINdgQr2yzz1t8AI7vQ844v31WPPYHqZu9wej2rtvZg4+fEXN+Uxs+8QkyczcYz73mtX4u26fbecO2/DeFdSOy5zN2vs8Ynob6I9r7JnXrjeA8b/HGphvlQ+qWI9wS7Lax8gXaYMuG0IMR3mM2xeMGWsK3fqr8l6KGf7E9N0OsEv35RtESV3qAXjhpmuw8XvgnnAd6CL07YZbH/5Alyvd7wrYGW+SaXV/8bHt4JLJaj/B5c4dKl+/1/5Q7pYlrG6yfrKeKrvzEvjM54TdYNsWH/thsWZOtoeu3cMsm+9TYGvg1F1APERFRF7ELH165i9x0EWz7F3Z0Q7Fi27+IXc8hu166K+CcPw+b9vyWW+hxLJ6zfafAfvgsCbx7GvG8UKYpvXseuQ6/Mu6KvOZAvs1ED+nusNgYksp5yq5Dpk8vIjp7hNWxN/w51ucYufH7qsX22sYHFvzBLQ4Yq9PEWTfiWszQ9YTrPUC9zD5CRD8lRwjlKR/5f0E9E3EOZB+8wPAS5XMdXK0R22MLH3R6zeb/tO1FTPf4W9XYNkoP2T05+kR8xH7+f3aM39hRejiCZzhnXPGRfMJ6cMF0nZ7W9pHJ6xPqyhVbFtXZU7b9Md3Lys/6LMK6OxHeRZouwdBPOUP36Pa6R87OYg9qdq7ZuWbnmp0fOzsPsdT310fOzlbNzjU71+xcs/NXws4/cHYesWP7T0ug7TFbrtC7ch43Z+s1Z9ecXXN2zdlfCWdvcs7+BSXwCzvHr4zjHjdHmzVH1xxdc3TN0V8JR/tZw4hd/cgZWqsZumbomqFrhv7KGDpiRT9yhjZqhq4ZumbomqEfFUNLtKuuvKsZeokMrdUMXTN0zdAxhg41ZhGGrivvanau2blm55qd15md68q7mp1rdq7ZuWbndWLnuvKu5uyas2vOrjn78XB2XXlXc3TN0TVH1xy9vhxdV97VDF0zdM3QNUOvO0PXlXc1Q9cMXTN0zdAPw9BdthXoRoSthMwhRyTBztkMJ157I1H3lsckDhsLLcVkf1OGkb0UJllkvG/HrleujcDPuoRl/b3oeajhmLMz5owkfxns6FbG0bNrWValbb4G7cR0qKy2veDaFj7b9H1sq8W0z0lkIb5G7fs3pVlC97Jifl+T7m1z3YsytmiNfq/4VRIOIvvYa4zvo4otmdn7c1uiIu/Xlmhtia7CEtUTerOulujzkE8VePtbpKcLcDRUR8AR60rjmqPLcrRRc3TN0Y+EozVBg1bD0Vshn2Yy9IsYP+0grvRGz4uIF7cVu+tvmf6bWPmbxywW5wsPmQL4pMn+TLa9zywG+wbvsIE++OexkYs89PpAArX/tnrdk2lLFd17gaPxAmfA2NGU1/An0cA8HZooLaYFLvuEWWaGs5OJzOnrEMQFQIM8pmG+psLWNvsNmjdl28d16D/ZmdoMKw+RJKZ+zzC7QrYGjv2D/b4JcAbt+leA2BM88w58xo76RHEEiX/DzmwJ27g5fCoy4/fKtGCUazX6kSfRKlqyGdM5f93yLMks21AcsXn6pyM/2UyPGN7IV6BXoGkPw2FFLJJGZYskzb7Nn23Ne9BFud7ENXCL8e6U2cafUU92IldJuvdXhsBVYKHwq1D+JmJZma8MJnOD8c8EtYBmuhbTFy2mL7B+yo6iIqfB3NhCq2iKvCVa06vhq1esD0kk3iPinxh+l4FGJTMvroBWkb1WoxPl5FlOV76L3gVQQRemTK4W0weNy/cntIOmbHyKnpUdzFygC2AhTdn/KmrSfejCamQTx68c9q+YJwJvzP4bYxyIA3zGc8J1gVyXMzqnwejU1250bjJ9/ozb54+sV+yYSYyK7PkSZ/byDLDF9rjAbQN7RrgqeTRiNXpWRFfKad8G82L9efK6srbB3G+y9R6OcfJ/NHb1lmT86w86/p8xHQBEP7LP9+w7f3dkSqRhI7Y1bDtN2XIztuVEoTdRFjvqr8okZUvQ908oZRev8QPX4WTP/4IMbAk6H9+bLEXZVYtjJe2s8euSnXML+YRmSv98cdzi59qWbJ/XvxeRfcoh8iIFEVFeYswm2cfsPbZTzhOXddF90tGTo51+DvH6Q/SiZ5Eh91yKed5e29K98rUoq5/h1ZXpZ/Zeq2FrGbeWZecOonCL17QcW2AW2ALGGtoCqFF4pE/KOdq11/P9AQNsfzC+vTvrd+A9nO+omYfLdMuipfBlLjA+17elHnWTdGqpx9wKOWypx12Vdid1s5x2P2PrP2MWbCc6Uha2P7TA/jBr+6O2P2r7o7Y//pT2Rxq/lmPpzXAJW0s9vEhw9JPU/L4syroRybuCBz7NqFTI5/4pxp4czuSQI9GxnjIetwaLx4ll9TGnixWXsyXGrZ8yif2OWVeQ35dA6slc8KpixzJ5xWX+hB0fnv4xC6T8kscR/SeB7HC92WV7/w6ZjgqzMliQBvsE+TgYFXBZa2IeKzorW5hDKFZv8ZiigvmY5kllE3t0yeuZqKKjin3kYU2LivLwEHUPM4dhflpFScBIeFj7aFVjQoZjHP1vg5w3YR/+roK3xtZ5OHuYgT3q+17rZI+uBu8Qu2yMt7FmD/K+EEPd8dcuEIcE3A2sPzCRcXQ8PjCOibkpC+cHQBekY7F1LfSPQRIeIu/eC+4/IJL+lfs2yZU0Jv0N62F85vgxde//Za2jXMTmnm9Ax+5B6tnSzNaEl8o+2+szxuXPMeu9DG2IeoVq4BUaazcK/x09sujVR2Xqy/pzkIX+gfXxNfJ5+l/jXma4PKllS30j2HoHJXgluReiLNvqfzq2laGYx7uwnZ83WnykWQxBG222Bru6BtoXHs//migLD3lXQ361sNIJKnHBX7ZxCydhg69qpH2MXHl0lKVXH4k5yLQjJKuiWvfEu1nSzNaELeUXBZ5Z8nEJWtDi96+B3BtBTFnHcQj3tk1QC0BPGuivTVADPPTgdPTTwPK/n4qQf/GrLj93vpTuW2TWXlVdY5oE45J/yivWrrDa+jK47za+tLzUXeRU8Caggox8C6qgT/oWza+QfUUEi6C+FV+60OynYT2oh1Elqr1p4ShsJmY/v27v68I/HcsiknjBjniJd0fQmp2g/q8qC8atEXONrZG/Il+F1/4eMwLXeDf0TcH7Rn7MOMYy7Nas48s417oXzs3TGjGuc4y5PKgR8sf/Ls56O+Gayvo2Q81RsQZ3ghEdF3XKwFnX5f4OfFp4l5Ff1Qtz7QxnbPCF70PfXqI+QHb3MrjqYlL8UbrnZ96Kleb3W5OVLkuRf+iuw3iFuP9komM8H+h2Mra+DncaWsKW9TtN1uteQ1O4pvW611AT9lhlZX99r2G4V969huDdiPnz7PsfknfjrPM94d+m3Dsh52L/GUQHOOY/LcTD4rN2lsXDZs3DNQ/fKw+LLFrz8DrwsGiRPUYW/o717wJt/ym7Lv9OpOiyKt63hxFlinS4PPLYilQC0l20KhvfD3sX7aruRIriF2ct0KYvEn8JRmsLvUCoCmgJDOsGx0vfs4VZVKOAfF/huKEruMJRCHq6s6DUpxhlbiKHt1DqDczqtmJSn2DWoRWTOvzv4bb3k39Y1X1B+ag+rC78gJUXX3iv6G7pL+y7yaUBFWp7XEei8xLEtInTqmeBbeTkGY5wik/bmKeKxqcbWIVkYC4KPum3ifr0uHUjC83qMnoh5JzG2Bvo90PJiaoAH6+c8hCtLqsNtCWuyIZ8QPnAsscrHxmKcZn8iJV95wplIUasD+f8G1i34PFFpfJ9WIm2Ypk0mSSaWBHVxMoo+GzgXGmhdfR4ZZLEMC6RZ4j9DGtxwX/0q2H9JyQM0EO6QU78oNCzPcHCv8VxFT13FasEcj4z9Lk99CIhMzfDPXzpOGiLNnF8qPzeeJ1bri22BvLoVSqT0/zlb9FOcCP+nei/r+rZBWWQhn9HIybE+S/4Odgd3961O/3zOw//zXv0XcV/894gkPf3mHd7Hz7JJWBALxFlP01dM+yeTO7Yccftc2j2etiMjs7vdPZrfH6nzXvDLm4yHNK6A2rOoJmPz9q3d3TiJ8z1IRq/ZJf08+3d2wHbxlbnB7wdj35hx2NXMT5kVzE+7J7fNb2p6akAwvist5wDzffOBrd3vaMxXEKnP4Rm0McrGewixP1j6PoAVsFBBmP+myGhzXcHfWpGcNG7ux38tdvFZsQOM2NbdmGHfTioOv/74B/ndxa0I/p5Qs0A9t/vHULz9xFs47B2j36O4XB/H7UR2P4AET2Gzu2P+rCsPzqFpktNf4QS6IyOYLe9zggu5vjdCH71R/jrYHwEBzkYExV0kcJALf/AFsuy52c93PbsCPs/HuLh2J7QnHV38eC9M3YAZX58ZN7esY/zu8YcG48ajRpVaFjbg+2Z+lhzbBglHo9UOtZI463OWwPbveMObDfe7WN3Bm+hOYML0ead9ilu02mj1nXau7i0u4u/uke3d/3e2LtTX1vz8cmAvgwP+ZL2Cf8y75whxPOjY9a9o+MuHnM+2D9Gl22gOEioO4zAD49QYIPDPjWw6X+jw0SFWw5/8IvBS/jJ2W7whwcZeNPFT1iUMEMC9HhADR8axKTEejw/7JNw3zFJ93ffsYH+8z4sOB2izvX5KH3LDjFBznDQ6rma9/sI0dEItzvq4GG6h6gAnT5Qwh4csvMzLN/rw7nm8zeH7Jrf0EbzeeJ8Kj8fxDzpueBwVxdlJ6exM6qFznh4tB8sODvp4Z2b1MTv48TB7Go0mM0GDWY7OpZtVZtM7Tkf1y1PnTLaHu/iRRW+rKchfChfyQVpJSGc7w+7t3f7J2dwGfsn77AZsV9Gg7Xsp2m/blrzfZ+xkb/n+102l+538bT73Z8jq/a7BzDiu2/gXCcjZOCTEWr4fNDtsDMP2Xh15m+GR8TDnUgz/AdjLXNitDRHFxE+7Hp3WsuYH8CAaKrz4d6Itdrrlm1YreZ8ODqFc7T3O/4swzozAAza0ellgtNLG0NzbCIN0vmTIHFwhangPpp+M38qae8inbZ3Wd+NmT1vdw9ZR+ftoyPgzvYRXlJ7tIcbjZAp2jSntNt9an7GpnPMD0CTUnuIHN7uIU7tHvJC+5gWjhiFGu68TdNYe0xHH4/oJEd0PGoOd6GXx9ArptEnGnSne6LDYbonBjY9DSaNbk+nxoBmXgCbFwlshv6AUuDmvQUR0h4/Qr72+IHeBbRH88zK+qMtiI62Wv0J0VlQf0SMymjQA2O0xTHaZfjQ61ausAjmQ+BSElYhhlnoQL8j8DRMwgfX5+JjmzF81Bg+hh5HaLrgGNMJIZ0QMgkhkxAy56PBLyTVEcya7oQtOKHLGI1OcEEZDJ9xDMHF+adCj1jK0zNDlylaNpBai0OpT9wSULo2QYnLVwam3ioG5jYHs4PeJj1hC7wUuLvxS+B7hUpJGapPmWBqfNRqRmHa11RTPmzVjGFrqYQk8gEg6TmFR65uF8bSsHXC0tCmpbHLHtDNKUFnu4TcbEkGhZo1XeoVya4YZFUB+gcbpxTaiQJkWgSQNhF0y+MQqYSRmzVQQS3ydQsJMYITsCnghEq1AqCSuhUM1KoDdIhBJBigl5lqprWWq2fLnVRXo2ffcYzADb2RotMUVEwwOrLsMtg1ho/+4PiMBm1i/1E7QfrPAryo/NnF0OeFoE2dINrypRDdc7w03ZUiJhB+0y2vUsyvRsgcjpkxNQvPndUHJTuhbjkEJEw15ZEcUEkOJPBKIemZBWZOz585wZ4oCGTAbRxItEmWjyPAN/KtESA3Mkv8L4As2SX+l2FpiJ/GnYsy8OKcketOoDqXxnfGLRPYGQBuNZYN8JDhqs9mhJk4aWRjVsVAlpOibmUayK5efowH5rGlE3SEYTHstFlhagwUT/di0G0E0F1hpO1TcKNROd8s7pqhi1Ax9lFkIOs2t1LQKSmIlqHL0GoQWg1Cq0FDmQgQvkw8YSjDHDM8KIHj08BacZTfcmIkNqHYIhTRRIugqC6KokkokopJYbQcwlHPwNFSeRigxeMALY4kV7wG17yGmQYmLYmAyYzOcko5xmdVucpvZUZxIa0sZj3L1RIHM0zUk6XzH04wOIZ9IIfRmYbmnnz17OJg/oD8Fw9XRdYUHvTSKMIahKu0iuGqdJReSlHqYmCP8tiPESf9nnAaY0b+90eLk7F0nDYCnD7hXRb3FxjO4rGWa1Z00viUoBI0KkGjEjQqQaMWhGZbqkI8G1NefeJcr95/9iWLjCxCyCKErIUo+4DXCGR7r+uaYeAosRkbYbIIJotgcggmh2BypLZ/D+tFb7AOkXGNRJmumPm1w2vifsOMfAFTrIzpoFmzIskGVerklx5ycsOBm7M2QWWT8U+5hvTASDZ2B/wOkvB9FCJ2YDVi2BI8IJSmGjNkyW9KGLLSwYi6WDQi7qwUu+JQ+SMyvNkmXdHE+JsrG5EQtU6lrdBHrxBMWpmeRe36MJIElipGkuxZCTyfxsz8y+Xm3AsmsoSp8R6GaQAW4BgF6zsO1gmkDIInbfru+RW/ryvPunKqFieAN5MHkyG4lr4r5IfaUKETjqVWIJwBS9HC4mDpNvk+6OnsosOGytdokOdjQovhxFwMX0Uw/IR1r9Ha5yTPZSPq2oUhhUhWRmrGdQhUnYPq6kJ8bcpjRDRx53iYTHUJVpvjahOwrk3AuhxY1xb9dfgy9L/EBjitCr74AabBkPukUGZKIc5RMlwnE4UfpLsX+I1pIfiFEF2AfmbeNSVWYnK7zyTsmYGE2GNrYItIE4pSpHESB4BR0Yek+EXh3QzgpTtmL/EOqwL2j5/U9ostNGdWAN8i9o8lMEacWYFvR1gxlw5uwywHrg+c5gUxEgRQz2eKH+UxZF6OUYx/mxX5t9A0xUN7niPUCHA4zUmMfk0Z/fpwijxhcT/O4o4ca+NFFxSFGhKgoyGnZv4bgNY8KSX7Hs6A3wCYVFeo0B2w5f/MzyXF8+SVo89Zvl8JGyCuqHbVwEESmf+QIYOP6L7EW1x+4rf0OPhYn5wkx3IxW67dtETM/Gk+fMw8Dd3oljJ3Bt2WVBPTKR9YKGFgFp9iCgGF4xT4Lzm3gOUJa0bUFoPUn673g8IDvONmNeXDbnEzvVS1mWB9cvpzCEiHgLQThjo3PaPVZjFAowA+5wC+pcen8NRk9GUV3wdOdpHojVC3F/jVxQI4kGIsqY2BzYMm00JpSSmSQc48TLRhrML/MjyJTNsqzSaCkhbHuFjSSLdlekoBoCUi7OeMDD/vaxUHWO5TGrKcEY7stLFfDsYyTrnHrUcvbj16TgEQi7ibiwaA5CqqyxAkrzzqBQXJNrFC0ufLIbewPykfBb6kp9bA7Ujg4JzLMNQskzBsxDF0SkDYkOqh1Kih1G8Vq8bXwjhh6lwNsTWwpdHb4MO3OGi+wlGSJNtdMWSDViiTlM8uanHrGvk2idXEzE+aB76KkDQHgkW86ItBX8i+tmfcvoYvAx/Dke/6DX2OpKBHMUz9usAePlJbgujEjDnXvvaV8a4z52vEUFaMIPf/OKaGDFPXljssLR5da/GijlaDIkXolvg58nbopvg5cyE6ng5i6E3TE7jx2VWZ6mlVtX1KzCjk80VibyWqsJh/KFVPWN7jy3u0PIASZ+smn6ybpKE+pKigB+Qalhvs7xDP7NklPkMXqhssY0tyzZxIk6GCJy2dXdICE2kVMvEKTK6K6DGn3AsCD/O9VMIXavtm+RMOoqF0K5S3NYvcR1PEpTHiJk4cQKYqklBEsbCZbktiwQc0R5fBaTPEifmB/sO+MhGTTjDFbj3yIdPydc6VTjDaTEaG2r1CthVYMB/oSQn4tAWx9F6ErVE156AVzwIGvorRKF8U6BuCeV7fgW86HyRN5zzoXgVz7gXe9VE2zSDPEC6uelhPHskzOFJr2le+IpFYcSaWKp9v0QyDZEHSgCk6gOnZjhcFbj9dxgC2igdgBQxb+ZOGX54qmNNLGr6+Dg7okRyYcV2xDiYqKQ2pErbseLLLk84a8vyhUODryilQZg+KYZwwzcWtmGgcm9SVXWDTomm5UU5bnwee8yd0ZT7g+zavcyNm2vIK4rLmaVt6ixzEQSKI62UyMGlaS/bNKOkE5iG4HUHwnxjE2cFIRWkMMTBY4mbXAEcz35WunB8AX7nAJIRBCLcpKUjHIh9c4H/x0y8DbkzCJVJCNmJdipnDPCn8lUuBnuDkYvXrNX8/qP8UsYBgytMJ3UpVVLGlbBJXbMGawlBbkktKWaAGjxEZPLTOWuQSLp7o/DbgwokFM1FakVSZHc+Ugb0/7/W7t3dr95CoXtSLow7xxz6AxyZ0KbrmNHVNtS7p1CXW7Ac9esX64wb5iCnXxptIyuc64GKX13xc8CfmvA2yF739Nwx4eKARHPyQfd+HpxKx753I47siqzR/FX/+Cqx7B+vUxY+jVTyEv4r9RujmMdE946Lr4NMEXHycdVJ8kddiCuKLrqkmPoPEZ9TiqyC+bS6+IX/2HL3BLy7E7UBUsm1OC2xTTbAOCdapBVtBsJvBuIQEARg4UWfHiyQP/HWnGeuqCdAkAZq1ABcYmf57CT6h7cRhE0amfJvTAtssRLmaVku2gmRD88vBEpvwXkSPZwH85acpy6tJzSKpWbXQFhDaAM1NN/LEKY/HQfzlpynLqwmtSUJr1kJbQGg9egtMAIsvnHD5acryakKzSWh2LbQKQnvOhbbHn0XzO5Je1H55zsUk2+I0d4tqIm2RSFu1SCuI9CkXaRtzsddBhtYLHghxFYxBcWk1cbkkLrcWVwVxbQROIYwcus1a9OfDNaI/H66pJropiW5ai26BGe+tQo/3Fme8cPlpyvJqQpuR0Ga10Bbw1Qdh7ixwCjYDOzK67jRjXTUBeiRAL9axrUCb4NnjXZTIB0zt+Tl8X3vE9ac566t1UuPRY2i7WvQNCF099suI/TJjv8YkgH0MilfR1pdcW/ewagHzGZiC38e6LXizeqizDZmi6KrhxhVFfa3b/lpt0mpqk/ha0wrWzkyP/YqtbfgrG87MVbX4yqaVfmBN7JE4VB5f95c3QhfSjTaWZswwHjpV3mF1CxUFhbphSLvYUtWJHscggIC6mUZSUgmu6iQPjPMrAecIwv6yNKRfh32ZqLrjpMEw9djq+MqWuGcm2ks+0QMjvsER7+C7a35HFg8RNmWdajXNhiZcthFc9mRquwIT2MHahqvPtIb0embedOJOk9g/TBfWRCojfPjvrSAVKX23jBYb/2n0berwl0bfE2tiTASGDukb/6XR93QGf1IsbBX+Cs4+a939B9aGTa4NkQemsnU5+kBXngYoXBoYv3JAGw0yjaWAwo5NLw1QOnHKNNNk/xXUh7Xu/proA1khyXlR2q2M+d+3G0TBLHCcB0boWcCfv/PMNbwM4WP+mBE7xpQuujKhc2G/dSdV5WA/8bD2PKJxqXZZAEaRAbOufX9gXdiOWDgT9Opu8HkM4qiRoqqqhi1iE9IQQ67lNNNoiA2GRgauyV2bGbtqYo8KKcVad/+B9eJFjEUDLz/Pz8gabxEAUgcG7CWT36pO8sAo/wljgAtpI9TMfsJ7Zm6UE/4Mnl/zsdJbqmO10uwWaQhhgeOsiU4FmhRqVx5OvsCzO1fECipynCXGlfd63du7yBuAn6Nd8145xBpsiFcGb0MP8nCz4HYiR7lJvOf3lX9DGz7tCbJyNxjLveZ1fm7wltt/E96l+4yd6zOGpqH2iPa+Sd16IzjPW7yp6Ub5kLrlCLcEm22sfIE2tQcjvL9siscNNIRv/VT5L/62cPyL7bkZeWu82J/kW4Of4VMtL7iWyc7jhX/CeUb4PuA/2CieKP9DVmjOW4zz37zcxLUNfMsyvFEZ3kvO5ITf6M3LGr6i1MW3YNP1W7hlk33SS0pV4c3LGxFEslHfjDy4chd5KXwz81/wvehWhXc6f8ut8zgWz4M3YMNzJPDOacTzQpmm9O555Dr8qrgr8pgD+TYTPaQ7w2LjRypneNe1TJ9eRHT2CCtjb/gzrM8xauP3Nf7W8G18WMEf3NqAcTpNnHUjrsUMXU+43gPUy+wjRPRTcoRQnvKR/xfUMxHnQPbBywsvUT7XwdUasT228CGn12zuT9texHSPv1GNbcP4y0Edz8NH7Odq3vj9LMK4OxHOncfez57PzhucnX9BCfzCzvHrI2doo2bomqFrhq4Z+ith6M0kQyv6I+dos+bomqNrjq45+ivhaD/GMcTbMR67BW3V7Fyzc83ONTt/JezsxziGTGfgfDAeHjdDN2qGrhm6Zuiaob8Shv6BM/SIHdt/5hhtjzWnCr1x8nFztl5zds3ZNWfXnP2VcLZvVUc4+5EztFYzdM3QNUPXDP2oGFqiXXXlXc3OS2JnrWbnmp1rdo6xc6gxi7BzXXlXM3TN0DVD1wy9rgxdV97VHF1zdM3RNUevL0fXlXc1O9fsXLNzzc7ryM515V3N0DVD1wxdM/S6MnRdeVdzds3ZNWfXnP14OLuuvKsZumbomqFrhn5Yhu6yrUA3ImwVPEWRGDp82uT72FYiW2cznoiFk7Bo85jFYWOjpZjsb8ows5fCLIuM/+3Y9abNS00J5/r70NNRwxGYlddMspnBrsnKOHp27eGqdM/Xp52YrpTVPT8jwkfjgrrWSES8vkZdA9tAL6Ft9p9E27a5tkUZW7RGv+f6BjEDZvPUdcYFbNFkTOLPbYkawjXVlmhtia7CEtUTelPeEtUEDVoNP2+FfMoYOtLPBRh6yM5wjmxQM3TN0OUYWrSOaoauGXpdGfp+YgXPQz5Vppkc/SLGUDuILL3R8yLit23G7vrz1y2PqbO4V/Se89hHxzfY2GwUMb+JaRMwjc7+1IB9YBlsA1ftS8VGvvLQMwQOWp6PV2TENyqP+DS9ytdm8x70UK43VTRwK3akZcarxLrGPP2y+Jzl4WwFc1qT/Zls+4fRrzpelWahyrSliu69wDF0gcwUO5ryGv4kGpinQxOlxbTAZZ9g6czQQjJx9vZ1CGJToEEeMhdpKmwNXAaaN2Xbx3XoP9mZ2gwrD5Ek7njPMLtC/oB5/g/2+ybAGbTrXwFiT/DMO/AZO+oTxREk/g07syVs4+bM6SI7fa9MC8a6VqMfeRKNa8kW0/ops44/Y493Ipziv0lvF9n6E1vXD9j6uoJeADeYbL2H1rGG3KKxqzcTlrPN9cJBDgL2mbL/wf5q3YtePGM6AYh+ZJ/v2Xf//d9yS3IjtjVsO03ZcjO25USh94wVO+qvyiRly1fsqj4Bx6GN9h7fifQrVhOJPf8LQ9MS9PulsDdZKrKrVjP3C88avy7ZObeYPGeob+H54ripwiyQ3D6vfy8i+5RD5EUKIqK8RJs82cfsPbZTzhOXddF90tGTo51+DvH6Q/SiZ5Eh91yKed5e29K98rUoq5/h1ZXpZ/Zeq8oHyPm1HEv/lbHgVeBJcmtY+Ztok1ee0w3GwsC+E7T2yBpsMYy0mF0I6wFZFed94O4Weq9TnNvFqMdquPsV60MSifeIOWjLZeCZJPXeFdAqstdqtKKcPMvpymbkjXo7vN8XCZ14khprk3lkG5EYCCA2zYga5tsJoC8mWi0uerYORs9agg8C+ufEImwYX8Hs52yJPshTJsffMQICUv2SEZdZlZ8pk1c5mW+wJcCUt6hJy2GBWcACxtqxwCbNOnikT8o5jpnr+f6AAbY/GN/enfU78CbGd9TMw2W6ZdFS+DIXNJfPSUs96ibNO0s95lZo5yz1uKvRb5lultPuV8oByuVvzNuBLMhnPDPoDLDlcrR9Gmi7voba/oHrZf58Bd5CEqMie75En7L8vLrF9rjAbQNPWrgqeS5mNdpWRFfKad930bs2KvnFOs53GtednzD2NlUaEr/Yj5Y8jF+8GonE8Ss7r0Vs5sojPR6Z0IPIhFVHJurIRB2ZqCMTf8rIhIxb4+z8hB0d7lucBXz8knuo/j2MOzyyscuO8TtEoiuwM8yKBvsEi8pBdnZZa2IWIcrOFmahilVcPKb5MR/TPKlsYo8uebacajqqRPA9rGpRUR4eou5h3ibMDqooCfC/H3aeXJUnLsMxjv63QcaRsA9/V8FbY+s8ZBEzyJj4nvc62SWrwTvELhvjDf8369kRHj1ZaVcWbf1Ph7YMxWzcXyr77Aif0RM8x2znTnCM5djiamCLG2snhX9HOzh69b5tcIVztoN54M9BVcoPrI+vkT3T/xr3Mp/kSS1b6tsoN99jXlziFpOYjTN1g11rA2cVj/u/Jo5AD2PAGlYVWFhdABWYYC3buIWjiPHeVUn8Y+TKo9JOz/iL0Ze0IyQrEVr3El3OlmaeJgy5lkP8ZhljHxjYwKobYmAdj2+jJkC2yUJNgBHuoS5M0RYxkQ08HP3uvWjCD8H4hiuPy1GMh33DehiX5I+pe/8vax3lIpZp+AZ47l40IUua2ZqwpfyiwB3xH5egBS1+BxswQCOIseo4D8PdbRPkA2CMBmaJJsgFHuaNdIzKguV/P7nGf/GrLi/Dl9J9i2jPqqrK0iQYl/xTXlF0hfXWl8G9j/Gl5aXu4mwO3gTUuJJvQTX0Sd+i+RVaXyKCRVDfii9dyPrVsBrPw+gCRaFbOAqbCbvLr/z8uvBPx7KIJF6wI17i/RG0ZieoUK7KgnFvxFxjb+SvyFfhtb/HyPA13nt/U/DOkR8zjrEMSzrr+DLOte6Fc/O0RozrHGMmF/Jk/vjfxVlvJ1xTWd9mqDlQ+Q0zrItRNhVtrZ9wzYRXXRgMGw0tdrrvAObaGc7YYJPdh769RH2A3P5lcNXFpPijdM/PvBXrfO83L5kuy7gWfKd0sJef2bbXQQYyuqwK13joSRGvu9zOakUqc6liW2WyftiK7VVlIKP4xXNdMBq/SLQDqqFaqPMQA20JWTo3OF76ni30XYwC8n2Fdz7QFVzh7ASzws6CUp+iTd1EG6uFUm+gL9WKSX2C3nYrJnX438Nt78fvXlUlQD6qD6sLP2Cc+QvvFd2/8YV9N7k0oGJ0j+tI9E4ssODpzr3qnriN8ZYZjnCyxm2Mz0St8QbmXAyMwcAn/TZRnx63bmShWV1GGzi/X1HN4YPJZorLHq9sZChWl8kLIf41xl5Afx9OPtajnk3zEI3L6kfMY55zn2vE+nPOv8Ed3A7mO0NpfR/m3VYsnyaTShPjkE2MR8JnA+dKC62jxyufJIZxiTxD7GdY7wz2r19x7N9pMEBf7gY5Eb79jhI6R7bciZ27ilUCHu4M7XQP8/YQh5jhHr50HLRFmzhWVF4Tp3PLtcXWQNSwSvV3mr3/LdoJbsSvEKP6q7oHoAzSYpSCnk4Sv9fTf37pMfYBPOBk3f86PJHEEras3027Xs8kMYVrWq9nkmjCHqt8QkH9TJJwr7xnkkAORKy2zH6OQ/KO6XV+Lsm3Kc+AkHOx/7TIAxzznxbiYfGpiMviYbPm4ZqH75WHRRateXgdeFi0yB4NC88Hu+Pbu3anf37n4b95j76r+G/eGwQs/T3m2t6Hz84IbGYvYTOfpq4Zdk8md+y44/Y5NHs9bEZH53c6+zU+v9PmvWEXNxkOad0BNWfQzMdn7ds7OvETdiHkOF/Oj0Y/3969HbBtbHV+wNvx6Bd2PHYV40N2FePD7vld05uangoXPj7rLedA872zwe1d72gMl9DpD6EZ9PFKBrtsc/bjGLo+gFVwkMGY/2ZIaPPdQZ+aEVz07m4Hf+12sRmxw8zYll3YYR8Oqs7/PvjH+Z0F7Yh+nlAzgP33e4fQ/H0E2zis3aOfYzjc30dtBLY/QESPoXP7oz4s649OoelS0x+hBDqjI9htrzOCizl+N4Jf/RH+OhgfwUEOxuQQd5HiQM3+wBZLsednPdz27Aj7Px7i4die0Jx1d/HgvTN2AGV+fGTe3rGP87vGHBuPGo0aVWhY24PtmfpYc2wYQR2PVDrWSOOtzlsD273jDmw33u1jdwZvoTmDC9HmnfYpbtNpo9Z12ru4tLuLv7pHt3f93ti7U19b8/HJgL4MD/mS9gn/Mu+cIcTzo2PWvaPjLh5zPtg/vobExUBxcErYYXR6eIQCGxz2qYFN/xsnPp0HX0x05C2kzgmmnGZIJHS7t4ffmhge83DybGFyG1IQNpMS6/G8/46JuL/7jo3wn/fhNKdDkjYvem8r9Ah4uLWGUoPTeb+P6ByRXhx1sOkeouw7fWCDPTho52dYvtdnpzk82g8WnJ308KZZauK30OKocjUaVWaDRpUdHVS2qk2m9pwPsJanThkfjnfZlcC/N4cM0zfUk/k89bKeslnBwdjmFQItuSAt+4Lyz6Xxc20wRp4x4eyE54ydTysEYOJ88/0us3X3uwcwQLtvYIuTERLmyQgVcv5/nQ3Yb7fHjq4AAAC+bWtCU3icXU7LDoIwEOzN3/ATAIPgEcrDhq0aqBG8gbEJV02amM3+uy0gB+cyk5mdzcgqNVjUfESfWuAaPepmuolMYxDu6SiURj8KqM4bjY6b62gP0tK29AKCDgxC0hlMq3Kw8bUGR3CSb2QbBqxnH/ZkL7ZlPslmCjnYEs9dk1fOyEEaFLJcjfZcTJtm+lt4ae1sz6OjE/2DVHMfMfZICftRiWzESB+C2KdFh9HQ/3Qf7ParDuOQKFOJQVrwBaemX1kg7QRYAAAKtW1rQlT6zsr+AH9XugAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeJztnY2R2zgMRlNIGkkhKSSNpJAUkkZSSG6Qm3fz7gtIyVmvHdt4M57V6oekCBKiAJD6+XMYhmEYhmEYhmEYhmF4Sb5///7b78ePH/8duydVjnuX4dn58OHDb7+vX7/+qvfavmf9VzmqDMP7gbzP4vbwlv65u7aO1W8nf65HVw17Pn782NbVSv7u/2x/+vTp199v3779/PLly3/6ovYXta/yKSovzuUY55FO/Vyu2s+x2m/5k3adW2laX9WxYc9Kzp3+Lzr5f/78+dc29U//LbmUDJA5MmI/51T+yBSZ1/5sF/RrziU/txPaAuUb9uzkXzLy+K/o5M8x5EJ/tQyRc7UV91nkxzXgPr46hj4AymM9MezZyf+s/k/5d+8M6HnkXn+rLSDX2rYs/cxYyd96AOj7lZ51w9BzTfkj15JVXes+SF/3mMB5+FmSx3a6IduJ9YzlX23EaQz/UnXi/nO0H13NWJxtH6dfZ/spWVneKQ/6beZd13ksl7KsbdogeoYxyeqaYRiGYRiGYXhFGMffk0ew16f/828v71ny3foeXOprujb1rniEy+jtagfP5mdInfCW9r67lvfznfzP2PGPfIZ5nvd1vsQuvZX8/4b+8xZc/vSzYc/Dpo5NJv136dvDF+Rr6SOdz5D6JD/OXfkDTedvpIxcj/3IvizbL+3f2qWX8rcf4lHbQMrffjYfcz8pfYnOLLkgG2y+7Oec9AvYZ1ggI+x2BedR57QPk/Zntx3aDPdCnpkW8u7s2Zleyt919Kjjga7/A3VoveC+bT+OfXtdjNAufsh90HZf9/9KO+t452/MZ0r26/RZXZLes+t/QLbpAy7sqymZ4W9xf0OW/L+TP33fPkDH+1ifwM7fmPInLfwA5NPJ/yi9V5E/z/b6m7KxvIv0xdsX5/re6Qb0idsJusW6GHb+xpS/z+vkT5zKmfRS/pzX+cP+duxbSz9bQX2lPy39d/bt5bXUbdHVkf19PEfIY+VLhJW/MX2IvKd15fF45kx63qYeHlX+wzAMwzAMw1BjW+yb/Dw+v2dcPfaAGWO/H7Z98bNNvosLvRV/w/zDZ2dn0+r84NYJ6A7HhOfcwPQtQl7r82tfZz/M8qCvRj+co7OrIP+V3dd2MHx82I7QG9h/PcenSL9Qxu7bZ+dz7LfjL8doH9iR8UkNx3T93H4X13uR8uf6bl6nfYG271rm+A+6eUSe65fzz+y38zXoiOn/51jJf6X/V3bw9KWnTx0bKe0i+7FjMM4cy3ZZ4JPYxQsM/+da8u98fuC5XyUvzwUszvR/cFyAy8m5ec6w51ryL9DJ6TsveIYX1uHOc/X8X+kGtzk//x2rUMzcrzXdu1ztW73jeXze2QIYw+f1xI04ndTP3fifZwDk+7/LyrFMe+Q/DMMwDMMwDOcYX+BrM77A54Y+tJLj+AKfG9vcxhf4euQaq8n4Al+DnfzHF/j8XFP+4wt8PK4p/2J8gY/Fyuc3vsBhGIZhGIZheG4utZV064YcYX8SP2zE915D45XfEXZrrazYvSOu4P3cfmX7kO4p/7QzPDNe1wfbG7a5wmvwrGRs+WN/wSa3aksrm5zlb38iZfL6PC7jyp5gm8HqXigzeszyz/bodQqfwaZs2ys2u/rfdrTumzyZhtcQw6+HDb5rN13/L2zTYxtbYP1P2vb50G59vdfn8pqEq+8LkUfK3+uOsQaa18R6dJARuF523+QyKX8/O1dtxnL1NZ38HW/kY/Yfs5/+SXrsP/q+mI+RT+73enj3jHu5JtjHIfuFZbl6Lv6p/Lv9nfzTF9TFItGv0e2kf/QNud0x/BTW8+TB8Udn1//teyvSjwO3kn/XHmz7dzwB/T19R9297NpGxqiQXvopH/WdgbbsekkdcORHv5X8C6/jS+wArNacznvNe9nJ32XI7wv7mkeVf5ExMunH262vz3Gvp5lpdW1mF5eTPr8uv9X+3X2srs3r8pyufp5h7D8MwzAMwzAMsJpbdbS/myvwN/hTdnGsw+/s5tat9nnOhecKHb0/3oKRf499GLah5ZwaWPnnd+3FtpHadsw/3+Ww36nw90Tw/4GP+Vrbk/AtcS+WP9+z8T2/6jwRy8x+toybhyP939nmrf/Z5rs+ttPZRmv/jNsicf74erABcq2/UehvCTnGxHKmLPiI7q2nbs1ZWzsc7adv5joBKX9AD7gtYNenLdg3i/woe84bsd+vm1PS7afd+rtAr8K15d/1n0vk7zkf6O781qC/ybiTfz4POp9uwTPpFecKX1v/Xyp/6210sGNt7MNDPuRxpP9T/rSNTJP4EMcIPLI/5xI8bqKP0a9uIf/CPj3359088rw2x387+ePHq/Rz/Pfo/txhGIZhGIZhGIZ74HjLjJlcxX/eit376nAdeOe2PzDXi7wXI/81nt/g+Hrmx9GPmYNjv12ms7KheA5e+upsh/K8oJUP0McoE9dm+bH/On4fn6bL09mjXgFsoGkPxW7nNRo5r7OpF55Xx89+t1w7FNs/dv5ujpftu/bnkjZlzHKl39H9v/NVYlN+dvmn/qNeufdVDE83TyjpfDsr+VPP6Uf0/DR8P9hm7R+0/9D3tio/x3KOl/dXfs8yz2/FTv6W2Z/Kf6X/U/45/9d+ZI5hq+eY5/Lu1ofcyd9tFEiLNvbsbcBY/1v/3Ur+hf2Qfs5zLuMS2gN5nNH/kG2DNNm2T9zt7xV8Qh7/rWT8nvL3+C/n+NkHmP7BYjX+28m/yHn+3fjvVeQ/DMMwDMMwDMMwDMMwDMMwDMMwDMMwvC7EUBaXfg8EH/4q1s4xQEdc4p+/5NxLyvDeEN9yS1j/mLVzMn/isSjfpfLnuo5K6+y3Fro4lI6MJz7iklhA4pa8Ds5RrPtR/Rpio+DacfSOnfJ3eIkL7GL3KZO/6+64X8pLfJWPkXbOFyDe3DHnjtVNvDYQawhln2UtMseb7/o1+Z85l/MdP0tejkW6pH6JOfLPsVHvsa5ZrtdGuTiW638RD04/5X47Oj1KPJfv29/+oS3sdADxusSSeU5B3hvH6We7/kP+jglc4ftO/eJYykvql3MpJ+leS/9nXH7i5zJ9mzbtfdSzv7fh7ym5HtxuXU+7+3LeHV4bzPezaod+hiK37nsfcOa54vkyOXeANpQc1S/QLhyfei127Tr7K/3H/6Pzsk173leXHv2P+0pZua9a963K6rWiYCW3jA3t0qRsOY+FvBLnle2etpkc1a/PI0/PVXor6MFV/z877v0T+XOO59xkmn4edvHgTrebh0Sd5zcqLlnnqxsrdjrTeWU79Pg4y32mfun/3XyFt7Irw5HehU7+OX+j4N3AfZV7QsaeI3QGr+mY13jukOPVrXOPWMm/a6+MU6wfVu2b/C/V57t1Sj1v6gxH/b/wPIvVu0wn/6Oy80ys8joP5ERdsjbcaqxmnZnyZ0yY6wR6nS+vK9i9W3uOmd8dunLw3UP0Ta5Z13GmfuHoW7sce495i7yjrvLNeRoJYwXIekG/p970u/SR3jvT7nfvhKuxgMc5l6wTeslzele/lPtIrpzz7PNWh2F4M/8AoIL6IOC/JaMAAA7XbWtCVPrOyv4Af5KBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2djZEcKQyFHYgTcSAOxIk4EAfiRBzIXunqPte7Z0lAz8/+WK9qame7aRASCNCDnpeXwWAwGAwGg8FgMBgMBoPB4D/8+vXr5efPn3984jr3qufic6WsAGX498H/Uen5iv4zfP/+/eXTp09/fOI69zJ8+fLl388uvn379jvvsDdlBPT7R0bU+7SelZ5P9b8CNtH+rvZf9VH6dpWmk9ft3/mdXVTyrOQEXRq9XqXLrmftvHs+cGrnq3rr7B/la991ubRvex6aD3kFqv6veWX1jvufP3/+93voLdL9+PHj9714hrqoLwtEOr0e6TNE/p4m8oi8uRdlq15IF9f1eeqgaSMvT0cd9Hr8jc+q/8ffr1+//n7uCjr7c01l0fIjTZTPM1mfIz33Mvu7DFGe2wibx9/QmaaJ74xbXHM9RRqd8zi0fUU+pEcXyKnpVO74oAvassod11Qfqmctn/F91/76zBWs/H9WZtb/6X+dvIHM/upvqFNWd+wcelZ90S7igy/QPqh+gTxWcna6QD7KIT/3FVWd/fmQz8vfGf/vMRe4xf7oPPoj9e7kpf6V/X0d4sC22D3+Rlsgf/73foas9FHai0LzoU6ZLvC3LivtkbleZX9k1Oe9/ExvK1tcxS32px1ru+/kDWT2V3+H7836KH3d/Y/qNu5x3f0kviOzP3rQNpbpQtOpzWkXyO/2xz/yTPzlGc03riHjM+xPX1F90J8BdfXv6m8Z3xyaHpnpW/o9nqUPdGulyIv7+E3A/5HG7yEnfS8D9caHZLrQcjL5yV/HQ/qH/++yqPw6l6n06bodDAaDwWAwGAw6OPeX3X/N8m/BPbiEKzgt8zR9xduewmPlxKVYz2RxgXtiVf7q2RWf1nGYj8Kpzq7ouOJt7yGrxrarZyrOqvIfVVx6t/xb+bRHQeXWPRNepytydfH8e7XrTFbl1fz+CedVpT8p/1Y+rdKT84bOKfoeBed4kIV8nANZ6azSgcYVu2ceaX/045xcxXlp3F5j5lX60/Jv4dMqPRGjC8CzwvMh88r+xO1UFpWz01mlA7U/cmbyZ/7/yh6aE/tXnJdz1sq9VhzZbvnU9SqfVtkf7lj5I+UUPf/MRsjc/X+qA8+rkn+XK1uhGqvgRvR+xXkFSKtcTJd+t/xb+bTOT9KHo4xoD/Q1nt21v44ZnvZUB6f2vxXqb+AalHevfFNmF6773MHTn5R/K5/W6Smzt847GRe07MxGAeUWs7Q7OngN++vYycf34ikviE9Tzgt5sutV+pPyb+HTMt7OZQPKKVZlMyd3rpTnkWdHZ5mOPe9K/q5eg8FgMBgMBoPBCsS+iPmcgnUga5hVLKpLE3PbHf7nHtiRNYBuHlnmriz3BudiWHd7DH8F4h+sv3fWJt369Zn7GTOuUdeUgfhOrPBRZXbXHwmPXQeor8a3uvavZ2NIr/rLnucZ7mm9nfeKe+6X9MxBpjOe6fRJf/M4hsdos/J38spkzNJ113fLyPS4g1UcSffkV+dxlIPwOK3u1dfnSaM+B50rl6PxQOXslA9wmfQcUcWf4fPIR2P+Wpeq/J3yXMaqzOr6jrzEG1XGE6zs3523BF3M0vkv+Drt/+jKzzNk5zvJqzpnQjnIUp2NyPTvfEdXfpWX7td3Gasyq+s78mZ6PEHHj5Hfimfs7F/pf+dsEfn6p8sXedD9js/S/p7F4rPyPa+ds4RVmdX1HXkzPZ4gG/+VW/Q2X+37udr/M11V/V/L7uzvHPSq/2veXf+v5n9d/9eyqzKr6zvy3mr/gI4tPobhn3R86fgrl2k1/qvcbv+AnuGrzp9nulrNWXw89TFOecWsfEU3/mv6qszq+o6897A/9a7W/3ova5vc1z7kPJrP/z2NzpF9Tp/N5bsYgc6F+Z4BGfw+5XXlV3mtZKzKrK6v0mR6HAwGg8FgMBgMKujcXD9XOMBHo5LL1x8fAc/iAlm7+x7M1TqC/dLPRBVnq/Zjvmc8iwvM9jIrsriA7tnV/f8n61e1FbE2vZ5xbtife54Hcuh15yJ3uDzSVGv0zi6ZHvRcoHKklb5u5RtP4Pvv1T5V7I+YE35jhyNUP6PxK67rnnn273u8UfnCLI8sXp1xRh0vWMX7dji6LtapZxPh1zN97ci44gJPUPl/7I8Mfm4l42hVB95HNA6n5/goX/uFc258V31UZyZ4XmPr9JMsRu39hbbH+RWww9GtuA7yq/S1K+OKCzzByv8jK30v41V3OELOUmhfz8rv5NF8uzMzIQ9tlnJcN1U5jG3q3yh7xdGdcJ2ZvnZl3OUCd9DpW/us+niv6w5HqO+1zPq/jt9d/9+xP2c79Sznbt/SvQPab3c4ul2us9LXlf6vz99if/f/yO7jP/rHT1bpvD35uFrZX/POxv8d+6Mjv3Zl/D/h6Ha5zk5fV8b/nbOOFar1v3LeWUyA69pvO44Q+bCfzjGzZ7I5cFZelUe1fj6ZW1/h6Ha4Tk+3U/cdGZ8VMxgMBoPBYDAYvH/A5+ja71G4kre+W+Me777X2MAJdmV/T1wUa144ANaUj6gDdjwB61pierqvstsHXAGO4RQaT+xwpY6vBWIWvm4kfhbwfay+Dsdv6HqVMxjx0ZgNbUvjC+ir43ZVxs7+XV67abROug/e5bhXHUH2uyO093iO65Sr6QKR5mrfynTE9ewcC3ELjbM6B6O/z0U90A16JdaF33H5KUNj8dVZAbVFxdHtpHGZtK7KeVJH/S2hK3UMKA9LXA/7aKxQ0xEnpdwqXtihsr9er+yv8XHaPW0SPXl8S/Py+HbFq2X8idtc/ZhyyIqdNAG1n8cfPY6b8XtX6rj63THS+/sEnTs93bfl8ngc2usTcPs7b0A++puUyJjpBlRc1I79Kx5DsZMGPSrvmcmrfJi/R/BKHU+4Q8rlA1dd+ZYVeI4xLrOZ77WgDzlfRZ/QsaniDb39Vv1xx/4B9X/K4yl20ijnqOOgypF9z+y/W0flBPH5HXeonJ/ux7oCHdv043st4oNv9L0c3FMdZNeVX8ue787Xg8r++DLl1B07aVQmn3cq3853+oe3mZM6BtQGuqfHx2fXrbaTU/5PoeMHc8zs3mqP3eq67yVajVt+X8uvZOnWrrek8bIrnZzW8fS5zHdd2f83GAwGg8FgMPi7oOsYXc/cax7Z7UmMdZC+K2WnTF2rEu/O1oLvAW9BXo/nsO47PUdSobM/nADpduyvsRbWOzz3FvR5grcgbxaPJE7uMRvntIg9Ot+lUO5W4xUBnnWfozy0xyA8Jqv8v+ozS6t5E0OpuBgvF/k0lqMccscpaT21/iovfM6OXpBdy1G5TtCdMXGOR7kIjaV3PsO5e+WV4Qs8Rqr18/ONzsFW/p9ysjK9btnebG//2I3Yp8d8sW22b5u2AificWLsre2i04vL7nKdYGV/7OplZrH/FY/oNgowB6hsepKfc0HeX7K8qxiw7g/SeDex1uy3oyruVX2N7q1SriXzGSu9uL9DrhOs/L/bX+cJt9qffklc/VH2136xa3/8BnmpzyNft/9qbwd+RHlV5Q/Arl6q+p5gNf+jnnCMugflFvtrue6Hb7U/OqQc1cuu/clDxw61ue532ckHf678n8vrPj/TS3bP5TpBtv7zfUU6t8jOX6tuHCt70f51/8M97K/zv+rccqCzm/dxzZO+zLNdPj7/y2TRfRgrvfj8z+UafEy8hfXi4PUw9v+7Mfz+YDAYDO6FbP23imWAt/Su+Y5nOoWu17rxtoqdnmBX1/csM8tP4z+rvZEBXZe+BVw5+1CB+Nfufs1bsKNrT/8I+1f5aexHYxV+xinjCB3ELTyeDnemvC79jzNxzH2VD+Oefyd2qnXwdyRWsZKsbhqT0Xbh8iiycrK6wv+4rjWO7zKpvYhTO1e4i8r/a4xfz0vRz5TzrThCLwfdwZ1o+ehFz9WgH5cniznqdz9/SzvSeDryeBvwugU8lux8QLYP22OzxM+9rhWHp/lW+uB54sYVB7tjf/f/QNuWjlMed804QgcclfJxrsPu/137oxc9j+kyB/Rsj0LTZTZWfWX297mInq2r8lL9KLfY6cPL4d4JVv7fZcr2WlQcoeuENN37H+9hf2SirWUyB96S/Stu8Vn2z+Z/+EL1l7qPAp9UcYSuU/x/1/8Du/4O35TpPJvD7/h/rVsmzz38f2b/jlt8hv/3D/X3c7B67lDnKRlH6OXo2cGqfXta14XOM6uzmW43xWr+F3D7V/O/zndm5XT277hFv3fP+d9bx73XO4P3hbH/YGw/GAwGg8FgMBgMBoPBYDAYDAaDwWDw9+ERe9HZ+/SRwX4T/6z2vbPH0t9pEWBvTPZ5hD51b6nD32lccYnsS/N8ff8I7wDSD/s3nslTdnU5zUf37fGp7K+/Y8K+I/bZ6T63LM9qb/Ct8nd79dWG+h4Qh9Yb3bKHTPsE+T2rbVfo6vLIMnVfpPaNrP842K+W5emfam+eP7vaG7Jrf97LRPr439+xofZ/bbyG/f13B9Q+9MMO7COuoH2p28sW1/W3RTqs7E/boU87PP+s/3Od/HmXm+6h1H2bAdqbvmuJfX76jO6x1Xy1TZKG7yc4GUNUF/6uoaxvK6hbV576gsz2jL34hlWZ5Knv71GZ9f1yJ/b3ve5c53+tJ+eSdJxUWbjPd/SKzHouRPOlPajcV3zTyX5xPV+hvgB5qr5Nu9zx59nZAc3H95av5MePa/4BdKfvYlM9Mub7fKXSsc95tE7aX31Pr+5l1/mU5pG924/24P3wdEzgnFM2n3FgQ//tzGocZv20M5Yjy+ncsLM/etUxC//p7Ujtr/5d95qT54n99Vwi7VfLzN5d5fOsyv78Tzu+MidAvuzjQH50RxvO/Dq6q/yq53vl3XWByv7qNwFtMYsV6JlRXd9QV50fVucbMvtTro7lel3PpXqf0nMfnf2RydvXM9DFXXbnFpHuqtzdeHfSnvTdOtqXPtp5isFg8KHxD4gkaqLrd70WAAAQ3m1rQlT6zsr+AH+fDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeJztnAlQ1Feex901O5OYqCHGKwlKvA2exHtnNrU1O7NW7U6ymd2tbG2mZsdJJpPoxCTm1mgSg0erOxoVBLQ5RM7mam4BFUHkEpSjaWgauulu7qOhOZqmm/7ue//mEOW0dR+ZvF/5Ea1+/+5//T/v+L2jAXhM+RHDg70D7p9tsHbA/bMN1g64f7bB2gH3zzZYO+D+2QZrB9w/22DtgKn/rt5emO1/hj/kYO2Aqf9Yr/O4GheHvJIS6FpbYbRY7H+iP6xg7YCp/xtTpiBxxkyErF6FoD/9EUmkLqiaGtFj+dH0CqwdMPXfvtAJbVMfQz2pB4WEKAcHBLzzDm7m50Pf1WX/0538wdoBU/89LXoYMzLQ+dV+dCxdhlZSB/IIl9asRUJkBOoM7fY/4ckdrB0w9d8fVkJ3WysMh13ROfNpVJE6EDZnHmIDAh5KHbBarWhtaYKqTI6yogKUFt5BZVkJWpqbhdcYBmsHk8L/3dGVfxsG0v5r+upAYkQEWh7CWPCuWzSW7/aA88dirNhzHs47jiHpWgZstY9ZsHYwqfzTpkhtmGrr0OayATpSByTLVyI9OxPGnp4JP9y749XAW5hx7g5e9CuBo18pHvsiEmHJ1D/TXJO1g0nl/+7oqlLD4OiIUlIHgl57FTeKi6ElY0S72Yze8T3bIfG7WDlWhKqxNbYGm2NrMUuUgohr2aTCcf+MGDGsfX1yR2QU2on/oqlTEe7igsAdOyB1c0dOQSHq2tthsY6/JuyILcGSoApsluqwMboaDkeSEZqSST7Mvn7FzmDtYFL67w/aMpvf/K1QBxoJtC9IJQSvXAGJqysKlEq0m7rH81Z4J0GOxYE2/5uia/A08R+YdJO3/0nsn0ZPdzcMoSFoP3YU7W+8gY7Zc1BL6sB1Ok/81XbcyMpEW9fYdWBnQikWBygH/R+9Av/ETO5/kvun0Z+h097epNGgY++XMMyZjSKaG6xZg4zsbHSM0Q/sIu1/UYCt/W+OIf5FV+GbcJP3/z8A/8OFSatD++4PkE/nCD//GRS6apjNI+8fvJ9Uhhf7/ZP2P1N0Dd7xJP/v5f4Z8VDCmJSE5KemI/XgdxhtpWhPchmcLpUPtv9jqfCKSef+f+D+aRiKi5CwfTuaqqtHXM35IkUBJ/+h/t2k14l/08O8lYkGawd/Ff5p1BYWQJuTO+Lr+68piX/FoP/j13EqMhWwjG/+8IiCtYNJ57+3xwhTewv0dVpUVyigksugLCmCRilHU40GxrYWUoY6u3/uP9pS/jfXlVhwsQxbyNx/E2HGiTScCLtK/BtHvgi23NPaS/IKs5H8aScYyCUGWE1d5PMs6J3AGsQwwdrBpPDfazHDZGhBRUkxAqXJ2PN9EF496IO//1IMl088sf5jD2z7xAO/3uuJj477wD9YisK8HBiaatFrHt/4ffhGxaB/0v5n/O8NHA1JEbyOHr1QlCpw2i8KJ8QSHL8QKvwUeUkQFp9Gck675o+sHTD139vbCytpU7JCGT73iMCqLy7iyc/D8aRrEhxOZ2G+5x04iovwgrgQcz3yMfMvGXh8fyymve+Dle+dwYdHxLiZlgFDc+OYuzjHb1YK6/5bpDb/M0/exMGgK0DPaP6t6GptwT8di8CUj4LwxFdSTPsqBlM+j8DUHe6IuX57jE8dM1g7YOrfqK/HadIHL9gbjGmHr8DpohwvR9nG560xddgYXYv1ZK72srSWOKsV1u3pa2vC1XjOqwBTP4/EgrdP4YT7Jegqy2AZ5dzQ99lqOPqWkrlftW38P5WJAwHJZCI50t6iVXjtXb+rmH4qCxvJNRTnSC3muucgqbxuxM+aQLB2wNT/791j8Hdfx2FJgBJbYmuwjTzfDaR90nXaJf5ybAwpxS/Cy/FKuBIuweWkXDlWSjSkD6f1g5bVYZ7XbUz9kzd+f8AT5bICmEfYJ3TLqcILvnLB/1ZSjxy+z8Ze/6SR/Vt7cDw6C9PIPIF+Dr03l0id4F5SqBrZ6MSCtQOm/p84lo71Uq3wbKnPpcS7s18BviS5+vWqJtR3GGE0WdBhMqNK34loRT3eSqrA0ksKrI3QkGuqsYVctzKkAlM+DMZ/f+UOtaJEGFfujbM5arzgUyKM//Qah9PZ+Owibf+dw2ixQJJ+G9MPJWJtuBZbyTUuUVrMcsuFOEc5ttXxB2sHTP3TfTg6HlMf1M3rkgIoGtrGeGRWxCob4BJUCucwjTCfo9c7SyoxZXcQPvuLL5k76HDvuQ6PW8S/71D/n/olDfFv7fs7p1iBucT9iqBKoW5uJPf4jHseTqaXjnFvEw7WDpj630Lc0Xbv6CfHb4LzYBrnXh6N23V6rA2UYV2ErQ7Q91nsX4bp73ohOvYyzN1D27V3Pm3/MsE/LTvrbC72+CQC3R13lbJCo6vFKlE8mSuUCu7pXHGWx218nSIf971NIFg7YOqfenMOVWP1uQw0G+72MHr0t2ypooHkjKXYRNd0+tZ1niJjyq/3i9GgUQ255uIdDRzv6v+fJf7fFyeQJLR/1bgXnfoW/PL0ZcwmueU2ko9sIePLs56F2BNfhEd0Toy1A7btn7Yttxz4ZSqEhzHxo5hWvJ2oxNKQSuJfK4wlKyUqPPPRJSQkp8JqHlzbDSzUwdF70P9st1t4zysO1k6DrQDpB/7ocwUzSV5IvdM+Yu6FYvwhkszxrI/seymsHTD1vyqsCmvPpsLQZnjgB5ihacEiP1sfsKmvD3jSNQVfnAuDuaN1oJykuBov9Pmnbmefy8PbXvHoaWsW1gAPR90kfUeakJNsI/OD+WIZ/jPk1ojziYcUrB0w9T/vfCF2S7Iw3FrueKOLzA3+IURG5gNa4l8ruJ1D+u/th4LRWlc9UC6kUDsw/lPmeOTjbU/S/7c2IDA1H08dThJyCTrmO10sw78E5aHTONbaoN3B2gFT/w4nM+Bzha6h2Te27kpWYGmwyjYXIG6XBpVjxYEQKBWDc7XwEpJn3uN/pzget/Jv47nDCWQOqRLGhZdCVfiZOAv65hbhukd8Opy1A6b+5xy7gpScYtjT/mmcydWQfL1vb4+wNrwKz38didz8QvQbjJbXYoH3YP7v6F2ENy6k4JfuyVjgK7etJZDXnIn/Ra7RSLx8FV2G1tE/2P5g7YCp/+eOJOLmbfv9R8hqiMMS29ou8b8+Uos5B2ORmnVn4L3jy+qI/2Jh7ZCWWRdagRe98rDETyacB9oYRf3b+o9Z32di2c6zyE1PR0/3I/0eImsHbP27xuFGbgHs9R9XVo8FPsWCO+rWJUqH2a4JuJZN39vW/pOVDX3+q7EpSiuwIVKDDaTsqhAl1pP68DKpN7QO0DXon7pexvZPz6FSVohei333N0qwdsDU/+zv4pCQlkP023cGN1JWS/rzu/xH6jD/UDwy8mjfYvN/rbIBjuJCoY/o9y/MAz0LIEpXIl7ViBcvlgprfbSPWBdRhSmfhOKDoxfQpFM9qjyAtQOm/mceSsb5iBRYR92DHTs8clR4vm9st43/Giw8Eo/i0vKBMqmV9UP807UCOh94KzJ/oP59k1GFBf7lthyB1IFlQQr8dNcFePpK0NHSYNc9jhCsHbD1T/L/XWfC0KVvtOsh/jmuCAv9FYJT6n95cAVcTiSgqa5+oEy6uhFO4qKBHGFlSCXJ8zPRfdd3S00WC/4tSoFlIWphz4f2D/O97mDeO264nHCZlB3/GuU4g7UDpv5pzuayzx9K2YOvr3aberBZnI3VYeqBfYDnxTL81/mr9MsjA+UytQ1w8i4Ucj3avh1Jzv/auURYO4buN1U0t2NdgAxrhFzAdlZg+ol0bPrADbJb2TCbH+p5UdYOmPqnefrje8PgGSCFqWOsfb/hI66oCnPccgfaNT1H8PSpm/BJLRpS7pa2EYu9bf0/9brAT45fnJCiraF2oEz/+nNseT0WkvqxSWqbE9Ac8bG9MXjzgCdqKkrR+/B+ZwBrB0z9Uw9z3fPh8rEX5Pk5JM+e2FornZv94/nrwve6tvTN/VeHVWH5yWtobNIPKVtQrcdS4n9Tn3+6b/TKcSla6mqGfe/9N1TCmsKWvjUl59BK/M3uSzh41h/6+uphr3mAYO2AqX/bXE2Ln+yLxVvfnUeNsgSWYc5u3Bu9wnncLnwTmQ2HM7mDOV1MLRxIfTqYUHDfNcV1rYJ/W35fjUX+Zfj5MSmaa4d3aTL34PUo27pi/7qAk18JZrzriZCwGHS364e9boLB2gFz//S5vhRSgcc+DMT7hy6Q+fYdmIzDncmxhZV4segbcDQiDTNEV+DSt/9P32dxYDk2nMuAYZjfFyJvMGCZz6D/xQHl2HwsGo3V2hE/q0JPc4ESYW+hf3/5mbNZWLLzDDKvp5H+x+79AdYOmPpfG6Hry7OrsSJQgakfS/CrT88gPEIKTZkMXWTOZTZ2COfu6flwfY0amZm38OaZKEw/koI1JOejbZPmfC9J1HjudDqyVMOfy6xoasNK3wJhbUfYIwhUYoNIinrdyP5pxJQ3COdT+nMBOn487pqMf/7UDcriQltf9ODB2gFT/0v8ZcIZrq1S23x7TZgK049excxdYrxCnu+HJ3xw/HwoTvqEY597CP710CXM2yfBM6ez8XKkZuD80DIyl3N0z0JCycjjchVpyy/5Fgq5HPW/LEiJ9UelqNVoxpT0bYaKzC/LB/YO1kdU4W8/k2D3UW80aVX2/A4p1g6Y+k/TNGNbSCkWBlSSdmnbu6Xta2VwJZ49k40nvr2MafukmLY/GtNckzDHPQ+rSDvf3HdelJ4Vn+8jx2bffGSrm0Z90Dp9B5yp/778j64RrDkiRY26akxJJrMZv4kuw9IQ9UAdWB5Ujp/svACPi2HC2tAD1gHWDpj6p9HUYcSXaSo4B5TCidSD1eEabOw7370ltnbg3D39Nz23vYG8tkKiwvOkT15NfB64Xo62zrHHYZ2+DQu98rE8VCP0OfP9yrDkYBSa60Y/x99vtaLFgNWkv3IKVGEFqQcrwrSYdjYf0/7ghmvpObBMcO7SF6wdMPdvCyuUzR04kavDazEVWBskF876L7qkFOZ2lEWk/13sX4p1l0rw71I53PPU0LWOnCfeGy0dnfhtZAHejFfifxIr8R/RpXgv4AbMpvGv51xWNuB3cQrsSlFh11U1/pyqweviNHhE3hj3e9wTrB1MEv93RW8P1HoDrqgbESirh3dBLcQEibwe6ZomVOvpGuwj24/7/w7WDiaf/x9XsHYwqfybLZaB9R+6524Rfp/L+PIq+p2fHpKnjScPo2Xo97bpT+Hf5HNNZBwY7ntDjzhYO2CJiEKev/CTuBfpDW2izs5OEbEg6ugyivStepHFYhb1lx2O/uu7u7tFLa0tIlNPzxjlSVlSxtjZRTCKjCaTyNhuELU0NYg6jcZh33uk/xOyxit6hGDtgGMf++9XOqFgff8c+zh6v9IJBev753D/HO6fw/1zJs6R+5VOKFjfP8c+vr1f6YSC9f2z5MpfAer7lU4oWDtgCQ/2Drh/tsHaAffPNlg74P7ZBmsHHA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDmdy8n83DSU4RjOMdwAABHlta0JU+s7K/gB/ojYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7ZqJbeswEAVdSBpJISkkjaSQFJJGUog/NvhjPGxI2bFk+JoHDHSQ4rHLQyK13yullFJKKaWUUkr91/f39/7r62tKhd+Dsh6XTPsS6V9TVZ/dbjfl8/Nz//r6+nN+y3WnHlXWLVW+f3l5Odhj6/SvrfT/+/v7L0p1rHo/o/9p+8/g/5k+Pj5+2gBzAW2jriuMdsF1hdWR+BXOvVmadcw4s7T6s3VOGdI/pFdQPsoxSnOkildpVv/n/JH9X3VL8EUf/4nPuIgvcpzM+aPCiF/immdLlVdd17Gemc1FWR7yY2zK8yxbpp9UnFkbSLtUvs/g/w62m/n/7e3t8I6IfXim98dMI31BmyC80uKc9kf8nlYdyze8l5Fe930+k2nSnrqyLecc+Oj+n2nm/+w7fZ5MSviw7FjtJsdUylD3M/1U3iOv9N+oHWf/rvBKHx/W+WwOIB5l5P0n7z2K1vg/hc2Yb+nn+W6A7bFh9uvsm/S9fDcYjRX5Ppr9P8eQ9FWWJcs7q+8Sj6Kt/I8v8W32tZ5Ofy/o40mOtdn3ZvNR1oP8envI8TzTZMzpNulkmW75O+iv2sr/pbJRvgOWbft7e/c17ST9wPsEadGmeOYU/2c8xiTyIs1eviU96vyvlFJKKaWeU5fa581072Uv+daU6yCXsGF9G82+a/r31F+19nm1P6w51JrJbM16jdL/fW0jv/NH3/xLayGsm/TzayjLOepH/OMxu7+U3uh6ltcsrVG/Ju5szWlW5r+K/bLc+yNf1jzynPbCM7nOnm0k9145Zw2XezkmsHezJrzbOsuZ64l1j/Vm1pr6ulKF9zrWvUwrbVfH9BmQV16jHqfEeiX3SZe97qUyn6Pul2xvo/7PWhu2Zj++azT2V7zcxy3oI6zzrQk/Vi/sl2Ne/7ch9yEQexl1zLXKtFWm2fMa2bf/E0Gc0f2R/0dlPkd9/j/F/xl/9v6QduKcvRmO+DP/yVgTfmq9+pyXewL4elSn9EG3T17P8sqw0T4T97M/c515j8p8rrbwf99HKZ9QpjwvMdYxfjKW0Z7Xhp9SL8IYN/iPABvTvhBzbfd/H3Nyj/KY//l/IvMo9fvd/7Myn6tj/s+5HTv0fpJ1LfXxKX2Dv4jLPLZV+DG7Zxi25P0652HGcOJi57Q1e534M/coj5WDf2vxIW0nbcqe2cj/ozKf8y7IflvWKX1H3866Yo/RWEXcTK/n1/3Z+8GacMKW6pVh1IO5pPs35/LRNxjP9+dGefUw2kDfi0wbEz/znpW597VLaGm9QD2+9L9SSimllFJKKaWUUkpdTTsRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERkTvkH4eXjmrZO46cAAABU21rQlT6zsr+AH+lhQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeJzt1uFpg2AUhlEHcREHcRAXcRAHcREHsbyBC7emIf+KCeeBQ5tP++tNbM5TkiRJkiRJkiRJkiRJkiRJkiRJH9FxHOe+70/nOcu1d/e/uk/3b13XcxzHc5qmx8/sGP0s99S9dRbLsjxexzAMf76HdO+yY5V9s2F2rc37PbV/1Te//o3uX7bre1Y565/lep19+8bZv7pe0/3Lc77vX//X53l+2j/X7P99Zdt67tfv27b9+sz357/9v6/6Htf3q/dArtV3+5xF1Z8d12uSJEmSJEmSJEn69wYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPhAPwr5rLhS2ipmAAAqF21rQlT6zsr+AH/U8AAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeJztfSu47CjW9pJILBKJxCKRSCQWGYnEIiORWCQSGYmNjIyMjSyZf1H7nO6enun51P/UiFpz6T5Ve9cJsC7vuy5U5ud9Np4A2rORLcbXRmCHo8MCcF3FBWsA34V+w/NiHeCBChABtgob0J4kwXfdk9mxhMHxzXxz/PFDbwCVm91BK9VxM7a+bE8VFOB4nUDhKOkw8GG5rys/9wkSoNxULKRfjQOvN4G4c1yd297PmF5CbDEp/EMR85XSDw8r1GvbKO5GeU4iOPWWZFBDzF85FsjSPk8GMCZsqzS4j0ltK/7u626Qd+7bRxePcsWw+I2Z4AE8UaqDcQkP0RQJK6+XsoVIk30M+qGuwWWhtx1/cY+5rn5+glspLqM1Y4OJNizW+rjFwMGCbQ6eHQR1T6D476g5cFz40/08LxsPLz+8/Le4TsQ6Ep6TTcKbBXApthUgFfbEnC0c1R4ycMAnD4d1S3FgAr60zV+34NrmwB/VL7iZ+zb8NB08fgCFC7QeNzdT6huBx+FO3dVCUdfh1u3z66eolHVN4Pd7j477NcglLkKmTsmKCxhrOhgJa5tOwLxtgTnYD/znAiqndYFVxXwyqIbZJTvR7xGBm6sduF1G4WHXkinPC6pSRSVIV2MwTWcDxj67+CkvdGlok2aY9dUJ0bhYhj7KyhyoEstFy8Xy4ykVltQ8DyzpNvZzNMXhwH/WNZt64GLwP6SiSh/w4PZcGzwZTxxNJU8jKDfkNuA6pxY9CZ2q6v3TiwdZQaP3woNIDbarCJBMoHM2m84DTYNY6sj5QmNYnSbHmEq9E3QEZbsuyvYS/KjPCTMuGGplKJTPP9Q8P50tMekkcJ1PAT0A/X94FBoSjAv/2v0JH108SnTCobdWZ5uaYHxJLDzkuJV94EbzDlFqXdBvJVtQYdH9AYg2/RhYElm/zTzhF6o/EKhZb2gAgEaeF/wwNjfhga0fNkpG8ZdHW/CFBXd2KZrPNz8sHORAd44KjQZuTeDHpt0TbcwFyms+P/XoyUzaau8PsxU9gN0P2iV3g1qIaXpGVHgGgRD0hCQRga9rUPY4m0W3kG3y+AlqQU+Z8dTX+t6Aq54cPn7+kobl3ODYhpG6BulCOfq14gmGC9akAjhVratLHA5Dw3a0amLrD0wL6OXnQ7wC74B5rwWhC+cejTukbRdqC1Au1AUgl/jj70Rr8RXC6nf+oVX/RcLCgDP03KjBlJGVkjh461XAhUrK/LlzEo+jEomeXISzCA7oyZ+OKzsGfQcEc60YRhDjHVEoHktJre73pljdm4TGqAq5MQvL+v4rS4/6qOhkWIwfXTtKxKOO72MIiHgknadE0de33g8QnqITWGBp1x4g7Kjr0RBAbMyP+3JusG0kgajGXtc5zoTvekJHz56gUT0Vxm5mEORrhETq9qxlOwo8qP34FmHT/D4steKinptqxu9rhzBCn1twKPXiJL8dALqHx6CR2/bMcP00DG7LGctxYJRYxpP5Cfp2z7X26BjZLnj1SG6M+41vcp9KvoDPNazxweD/SOAcdamJ8errh5ePC2bgpxYM7dfXYewYlYaJW1oXGTo+PMdNQEqjOfMC/QKs4iTTcV0VAaEAfT1IhRYMawTQ/jPGyhi646/56bK6dL9Rkz1/ggEsCTfGxwa137v97Orncw3EPpDjojP4tu/e3DZbptFnlaiXDFJMjdiNqqj5Ea0/F7coDI0md90uN0MjfkJ7CIJdr9MK1+KXVdRXArIMN5nSMX9qa36CZZRjR7u/chbLx/kf0ONE2C4bEj30y0u03O7rCMVA3Vfdx7FNEgP7MOWAkAPj++3o5LwwzlwG2vJ4f5DzrnbPcd9OWqILPiMExg2DhIzgQkWXCZmlKZWCuiZ52EF9dOU/QvvqC1nsbSjCV0lw4YHJsfKA8Qu4fL0ylyvo/eBcMrf2IO3eKZBs3Di31nRsGAUcwUBaLkK9gKPvGASVZfGFi42DUlPf9IHGg20+ZJhJgen+bP708idODWGGZMSiRzO5JY2GvCOrKT/ovM8kBQFzHxzfCQNfNT0Tsu1ZHMdCUiMtayJxR1At0GUS/iLnZq3BCMLhJdapLc+TMx436tDkzMg41E05mRmBz4oZiiwbrOjkXypuO0iCwfrGRRZCxrGGHdZjbL9++M7usecNy51bg44vc2GfZ7hJFRdFCDLlLHoD0jHaF3SBGzqSa0zG0+fOwQahze0cyJkID+Wji0cp5hzUexI3ym/wy8VuZKj4pOi38OGVe0By9VCYPhDGa8J3jGvXvb6hCyO4D2tYF2Z5kRLWRcf3mshBqc1CwjnCdU0QsNveNFA9uV8E02ySkMZnV4+u2IfdTpUU1SOWX26Zh0fvpHADcAssWoUeEv9VdZs2yJP3w1amm9OwuOUwRUuRNyp8t/0YXa97nfw3NUZc6dS2u/p6UdgVoHoh4YLHBwl1FUiAPu7/86Z1cJqy2vb1VNmju28zUCmI+LRb4F7VNuPW2vPjYCAtmmQmEuEqPbYlxMDKZlmSPL9ekoPYt2BfNp2o38h8aB24zOsFM9ihPoCEMiAZULoQ+nH/1zcHFc+Oswv91Q78LE5zvmq7Rpk9QrWK/GALqO2Bs5VDp/L2BGmOVZIpAVLpkI9ATMXfBtKuhIv/iR0Ct8enbWI8MhNGSJNScbCyHMO5Rr0e5eP491gcummN5I6y9U9trEdB/d0Qt/TSfTq2Khq+yxN1DMRmBdg6HUDKq1JImS4D8tnvirA2wvG8scM2jmqQ5QGnY+ZHT3BPLQ0Q+q02HUgX0v363Mp/S53JSubbVcDO7BY6ukrHg76div3Jdjxneo7jjOgE8SDx/wgxRipxbZktO5MNSfKNFAA3DT8D3h7iT+woWXIN2WRlxwrPyUYGyhcN5ZkJ0vrRpf+WcsXYSJYQH8vBYezHx9uh6KU+GMYQACyhlbivM/+LG0TsWgiLuUXxysauAdJxcfDs2DdwG4E/uIPIjN5LrAaQ98UlDsinJIE7D+K8Px79UaxyGI02s3BQAzdgvGGZhrjpXj2EB4T9yVLntl8XhvWZsylto4THPsBEMyMewqMMvF8nDedJ/sIdya11D82LQ8HKLVKNbhBl46+Es7LP8x9zc5XA7kzPzDzIrS8TteAbUil8THRfMbvp8sE8dfV9RQpEyHpswvEkFEjTEQ4r704IHV8VMuy/cwdjAduvLfJySJFWLqAZs6WI9Br/ztTWjyeAke+MmYUofQvgbwmy7Tpd6Kyn2zanRmhsd7GGvECM0nrGeza6UF+ZPwwBtg1F6xvS3RjQaLOi9t+5o4PDdqLmS6sML/tC6SJN0v6yaDvA1/Hx+hfnBNCxoW+/6ylnUgJtIMMkrDW/LCCURYN4/Cg/qjoTtmfAVeu1hRdGvDSemerAIAno4BYI87XfucNFNIyBBiGWs3E/EGzkmAeQ9UGu9Q6InxZZdrTuczptUh6qKEcH/7Ba33naR3GEK3cwESlOevv25+F1iFn0LcUmlaeP6MAiolkQCT0nSYb9zh2DOPC36Bh7u5ltiBtML36EuY8Zg8Ih/o/H+/8u40LvruDY0cxBPaie+Oe8sVmZywx8egT08DpmiRsjwqx/b2i5MlhqgfjHvEl8MdbYaTMTQSh8+ad2EGYxxQMTpdYNTkuAiJpMwM2rGtoun+vT6z/Sctldw3FCU6BeI28W8v4ubIAlBHoC4uKBiw2vxPdZ0uN+aYjklINQrgCIcRAe63UmNyiEBRz5VTtCAqGSbCB6Rut4144Gs4Gii02b98vyCyx8UGYMVvXWoPZrgpEnm0669GLMlC+hJEVOlbmqCkgDQddp3vtRCz2CdS0fL1TmUUFEOZOjqNJn1exX7fDgJVla765cgJ/aYdSlpOM1kE+tanKoD8vR8an4dSI549ZC2Hpwg8ys1nZspa1sPQuDEI8eFcm4Wezox3mfFdy+NXQD/YWm0hEL121Fg4F6niv8qh3vTRuxvos+qEy/a8c9i3JyDDSNA/ns6qf8FC9n/Q+aRcByEv7AflCGGKZuQt9boK5cZ1sVe6Grh5JnGqPjWdsDdlKfVycbhocKe0ZlsG0x794BjHsLAt13vgcDTP/VO5AdN6gmJJHn/nj6Y9r4w9AwnwuBjp5u3faJ8+0mEfradcVANXND6BRD1bFtnPEfOEgYg+NlZvHvucZ0DJLOPFBKWv/0jrBAg4/vkPnI3P/oHaG7FjSdS3yujyNgDhd9F2GfaxFSTuL/oCeXfklVIcJr8lcBgIFMjJta1/VEmAROS5XBpQX3zKFV4wYMo5zPxPf93Tu0mmfMEu9MfmEoXeWv3iFCanboKNFm8sf1H6O/ufRct/NC5QV9kkF1SPdSoaSgEQbOAgDVZ+v3mO4aTR/uC6g8N4cMT4u3Osjtylv3bTZ17Xb2jt3HOzOO5rU9yPzudx3pp3eMbh7o+6//+PqPlwSkpDNwS/7OTaKktqWDqKt78y4AdAuuIqED8250mho/E+DrjWRp8bBizEM2s/M9sMpFCbMZoB6tHtUOhSyApRvRrk/ICrKc9TC5aP52h8tHF4+SOx49uu/1TVYlpRP295vKqohy/KcAwOTCNJ1IGA0dOHLk2dQGS+yNgMl4uu1BHPQ6yjIN2hFlwC6prAHX3Z8wTjxnnevkg/iZJ4imyu7NNqPphyXBw0fMMdbWt2197qFeaq5u7dK901P9MAxDegGLx+1MWIYz/ZzIVYP2hE07XgXi/l4VflhjsL2OgAFhARrodgNHSAV1IuHnDTGK82tO10v9VII/LIjZ53KDPe7cjoZYfTZDQhBXNtu7AJBG3xeoXO4zlm17NCFdOf/hu63X3Eo0bukU2BM1StNzhHeC3F4MqkSf92ioD4KN9Ix69oK7tqPf/Tj/leAcUOuUXZd6nRfw87oxtht4peJ+FwD8tUo4I2O+JYHPvhOut2NGe2Tzlxvd3wMdur1vHfeIQHfFMIlRc1Cv47kSml8VzIHOID8IM3lCMsSQe3y+/wU1s6e4h33LPnh7cShhv7Lb0YJhoT8FgI7Q/lGTJfKnzGzBrPY09IKkz4J4bVdJ14aAR+2vpkPoGtL07DES6hKSCNsSa9dR1v2MM2lKaBvcLMf/gPrj+okaS7qaUoj3xcTwohXEwsj2yE8BYPrI54XKsruGjzwh841bEJ64TnfZ9LZhxNz4tqJagI7AeIlcUnR2mgHSXlpK7d1hXCgByh7IWplQRZaP6//uIDGKmt6jBaFojuD3nex5BjD3UwCQTCHIeQ7NUQNQD8yeEO0jUkDTsSY0r2GfORACJzLJAZ7Ei+C2SRWsRcc4WMn4SXLVxAo0qBOWKnme/WIfz3+Ly7zTGi8jiQ14sN3R3DvGMlJ+FwCqiwH14hnW4U83z+2iaO+T1ZhVjvNeCKdrBPQNu5ql46co5L6gLKWInzIYh/zXKc9DB/c6KNmQO5ccUTM+vf404Sn6JYj51GI27hdCOAH9XKAUH7MAcLX1msnsq2U86rrtU+m5EJCC2OzaK9Nqc/DEcIyEuAjfJTwmGXR7Mz+MowisfE4GKXA3EWKZ1AJ/7uPpP9RhpGnkRBO1V2wIf5IWAaG98IhYl58CwFraPjt1+J0ppGtvAykjV+HIzVOabq5jUr149JR7W8BzWHYxpKw5NYkRX6warDBL6Rj1wRiKEbbVmTfaPp4AVHChNYeLuNm0pGwaM6VT/CLYnepM7r2IWJDqheedq1vhNW32ofgODLq/UQA9InV99pHGcM+YKniNYvbVibru45fjI2lNK7P5QLtaIZAJ/rfPrn5q4NJZlN2sFRiRobTSJB4/NYqVoG0GdOp1iF0ghyWOQI733YU6DjRoONuDuJihu3R17BczwDv6Cs6RT6QxQS9yi78EvpkFChvGEc9SKjXAx/v/y+xp3CZqIwRZHjI6uiRaCChhrWTmQN8+J3oKnhQGhNdMEKyvs6zbAhfrh7apvTZakNHAOHxgG8Y23SIC5YxYATHfX4APegUnEA3uRi2p97vRj/s/sPpYXgLyC0E6PzEIogc72MxoL0sYnlZCJ/UHDPx2T24SHxnPBEZT8oK8yQz1Bsak6rDvzN5Rez1raDeZwBdN5a/Ad1hR+XD8XHbvzZPOTy//ti7F9trxuQr0jU4zt81IS1LwyWyKS5Yim3EdD/KUHoleV9wEs2iBvDF3dPke46ALaEAHAqes0TPwZRIfNv5OfJaSF7bBqYtJO3nuj/M/HwM4dFsGg1vpIZEL+qW1JCwfzq5MrbdlliKPBXqm5SVJ3oZB6mvczBcRUuRsITN1+jjg2oF5E9/rPxNfnlfF6b0pg0FiQ9L16fVP+SFyer+EYaKkNVOxzW7Wl6OziBEjwhQ8/TQzeY/cNiKqFaDSUv3q0fTfg0OBglEE5b8mPrhbj7wjCkIASM3Hvd97dqFl4AXXa0/D11TJbHEoj1VIA/DNtWiPDwy73ZQ4ELosQHSwtfbIw9WCTNt7cAi0GZX8H4kv2CrLTCKNFGRfeQwf73+fayw07gtHzJb90WJEPizBzy5vaxIi/UQ7hnw3llsuFRy1RNZD7RdBnJ8R5COJacfm6Wz//K+Jz5+hSdas0BbyCOLz3h9Ev3G9XSveGGVFCZXyll+rLS2gmYOmC9qwY6kcm7Po54Be+L+lTPQSmHGxMX4R6xBDkN9Dk/+U+J5DkzmhjghnTo0R5PP9//sak/VIyAQ4QhZraOrnq0rBjiNapC1g+laBb6eZTcthIDlyGBEXJAAT7tW6FANaLbxo82to8h8KHz9DkyS3CftelvF0xI/3vzlkKJE4FlDdhV3atpqj13dbEqIBd2wY6c87tYxkldRul9eG9G/OS6vojWT5DEgapt6EKET6r4Wvn6FJbvxJzCBN7+P8XygA+YG8DhnwGpySGO7wNSk2Ekgv9vXMWc0xh7ggsVFS5oxrHyxuy9b7WEi9rQbKifAOkYPKyz8UPv8YmmRmkwQB5yY2s3/8/L1eRX8VSpZtixIUqul03sh7pUOXtZu9zEOsAmNgve7ZMMqFdh41HcPCeDzkg/NcOVkCt93/Y+H719DkfTHaMDYi17Qh1o/zn+s56mRsOieWDPsxSCLBPEhOtgImXQvENc/2jza2OcchFkntMTsikMke+O5ZeEHP10stl3n1f218aH8fmgxkHA2iIl3wz9f/2+u5CFW5LmFrq2diYncyNKyNpv2Yg8BqLbkgUQ6qzMIAT2SWLdYE1sE6TooUCWRHp5fLpU3Z/qXx5fj3oUkJVvhHPbNX+H8hAXI26Zt30Ugz87EYuxb70nAi8R3X24sXDAG5oYKjI2c2KnilOR/wroTva3tIkK48V5Co9gjt3EIWUd+NT+e/D01WBBH5hXtLaPWfXjzMRn8ViVcNHTzktUzAhsf9OnckfLBvWYCcLVFdPBPKq83aIeEh5Z65+/BGzx5xQBB9M2ahUvglHbuYjW8VxL8PTY6j0AZyr0T18vH+DyvLTnzsWc1Z/JmONv1qG5dyAzHRMRVrNPj6aSdYyRn8ZoNcOtxlrt689yDcfrlQOZrl0jHt342Pswr2H4YmN444UaFhcGX1x/Hvhuj2iDUgOW9zpk3aeZcJ9UsELdHbdYqkdRY55twHQmR4N0iHVpm+1tgmpl8PqK+dIUPyo2wBGGdMDiD/MDSJsX+3eVP3AqV9fP5x2bPea9Dw7AHZ+sxirnM6AWa6Jy/Q/ILADh3jvLNAIf5dJbmD3Hoj1z3ESqRzx2Azl39XIGV6PI1QSUfyD0OTgq77MKhA6DTtx/u/CwPV3h77NbgCNWe1lXj/Y47tVL9H9Nz7VRn0I69S1BtDQ8Y/dGR4xxz0hvhMYIzGgTin9evpZGdzVOI/D002fSwMAl+dmpMgH5ZcgmvZrATe+J5sdM6EbK9zoIs6bSIy1+M1t2IBZVxdCFzyDMub3OR7eGHfTG+5i1HTf2xQd0s3jezpPw9N7qWJAF5hLNUfX/5sYijUwDGHP/G/64MG7fMOzzOTHYTdjF43otv2OvAQhcveg8PDXrp1c6zPmnFCuTgqwY3oaIBHeIwfsFn+D0OTbTUCg01+7XtTH2fAOW7okVJYlh1DfVv5q4sXn2gHT850Q5uXMSNXM+gHKpr7Oju9Jl8Yh0cU29uCtCacSHyJ3dDgweg1gkyRif88NMmD7/JcYgWm+8f7v4YRl0Q/XWZNe1Y2KoJT5DyHm9nbZZmNMCygIavYDUG0y9i+vOf2heSh9oxLuAifbaScbZ3Bxt+Nw3KLnb1P929Dk62kmvy8MokKCB/3f9bhI4PDcCcktEaQy79AIdJ7MJ4XVoQRpllXqdjCb2WtLKmKJ6qLSCe6v/dg53L9Mc7i2ugVgyOazb8PTVJTlhrdEBNZuo/ff5JaQh3QaMR8lniyt0jzQA0221l6aVcfbIR3URPBDBEc4X2CeXEPF3PgreyzIWCrsx9+eSOiLU8Y3QvVkar2t6FJoliV95Bt1ssRFH+8/gfxqMx5z/GB0fWffO/8KjBvQKKBG13bk4leKGBQDxHKce2rwoN2tq1lZrcB6c927ieaT0E9QoD7HoyD3YJw5O9Dk0ojCryoEAzWnp6Pp/9xleY1sQ1S0cPuF7qA64F3VibthSkM1KmD2W5AcG/vjeeyXd3MezOsdrY6C/oOGMf6tYbew1mR6M1mKmFX79JfhyYnCkprMG6liaKvRLh46I/7fwuUXC9Ik9zMyUQM4XUDznEPWpZc2oxHK+WVtVgLf+xapVQ+eicRN/lRh4FxEZuEuY6+ucmM7QIjS+JSLvIvQ5O7B1bW3GfHUdfIrKjl6ePzH1wL4hDsYLi3P2Tc2xcxebOU5XVN2zbGtThaWF04w/hecIWqd1HrFkW+5w0mCO+Mh60xFmZyE1KaA8FLafvx59AkEEekFs4T0/DU3Zydj9vHAdCVGB6Mr/BoMyeBwK7C+JS3kwbHe7wcFAGxmh4eOzvWfkag9kvuMzfQa5oUlsx1PAhw9rVkyo7l6IgrQ6h/GZqkCJkMjVLhD5H3TXq5xo/nvzcbKW4A0oAIqeYE9tQgbEUDDkcdG3nNbL2HOhLMkf9Jjd7tkm8fsULsPEFcjoyaXDaPZPDo/Uam4HEf4M+hyYVRiVvitTE8a6ju3U7DPt7/l1MlfOuCztCV73MBVHXGbGXB9ZJimkF9Qbjr5u0Wns20/jHj/RswwEF7H8lL+ZPKmBsU07q8dGrRB/LH0GQWTEk9cp4JEQ+iUFJn8/vH819MYrhSs6PpDcWe6xBsP6vikJSeKSGw1luriUbC5ghv1ucLd2kmAmtelENWKHRAcPxXMtP3sg7ze2jSeIFIl0dSbrIEzYmMZREEQ2L6eAXUibCBquk2R8GzqfcdkayNUYXWZDI3XMzYq2ScU5EbyT1cu0YCp2YqvDDpkR0D26MA3A5PUAOQ+sc1KHKEWt+ZE3hRkRBaFj4IpX5HoEFlHk4t9eP5/2pZ9Nw3l9K+bjv6bj/TuSJQt6940n0Wh7eVGhYQHS/gTuT2GADeVzrdiia0l9e+htk6eCIM6q2l0YMQO4bEUucU7Y6UuRcMga5j5JuF0Zn1sfHcFf38/RdFbG1HwqdhPY8LF2gI8hbCqEJHX+Z1hbPXWW5a7KutRllzIPRV6bUiFXpNGybLOsvdR264Ac917S71RFiJGoPJNVhuFByawaH2Aps73n221KslWE8/vX4yJvnd2BzuuAdGcmpqohEYoh2FOIibC3lBysbkFyqxVxAJEaGzE4mAqdIQSZDSEZj3BJM5L7mndYJiKfWBWrNsGDrrDHPhvA65IDiyCDXAwEr1mj5+/2m0gZyBkNDzmEk8kGud7Q7Ctg2I2aTjXqJT13iaW4voB7LWcw6ArUdEF7jhFsDjKIYAK4mXIkWjubNIbtaGQV+b4VxGsAta+b3ZGSXSzBuLksTSP97/NGC1BKysd53XHl972TehHBwSuRAi9N0wq1ntBvGuQJNmfZiltsn/58VQRWqvbcjadjrvUcgeHYi/BO/S3nJOvq9bd8z0nXrgKvaxijUcCItjP6JqH5//5RiUrJRmnTe1tZc/S1/RGlCd0ScsIHNaKG9UDXyR6sOTXC0l6uiUkvtohJLseYPB+MXzylwJY0svFwnLp1lH1LvakP6GjRLReiZjIgwqxygs39F/3P+3ee1Fn3EomnkHmFv1vLIccWDlYaA3WMS83eB+EP/B/qS+Uq6l0C/myXtokmiF8cwipmf4wxoRPXcImI733aD71ZeIioQ/+tPp/8y2kXUSTh1oe9xnFw/z+j90caqeiG3tLOWidaJb91nC89pvdP8GoSv0gBQhq2hm2ucuMl3s3bk/hyaVnHdB4VKItL5Gw8S+67a+EVVlrYKrByX9nWTPy2wCG7Np+IGL2v5x/pdNcybnNplYm3cWLSbOHhZZ7b6FMyilrZlHOZGse2PXgczWrMe/D03m3Tujoq3pHHbe8PqAboEil84IAe1itR25KQS9PIPXvs3c8YdlX/AxthUd/Jxw6Oj35333qzEx9N1GI5HfWViDgXAVpHEUGl2X3HOOfx+aLFvCJSomHKEGsUCDHUS8ZvPD0rlBh9mZZnOUDL3LLKiD3j6//jNZzxzUlRcIO+c6I2hFTKzXnVsBUk9ki8oRXkfpmkGNy6lm335ZIf3L0ORF5eoY8QhuF7cO9Pwwr37F4C+rQQ7d8oEKlkvlbfeCAbEQPl7/3VdZonGGIrUBEhOl4jwYCNGGRoqyzusqYwe5vToaeNt3hHykzZ53rZcl/WVoUmew5dj6Aebc5mS/Oee0/MyVqsvDdp4zwHYNRGeZjWjnPj4///Iz6Ylon1lEa5BnQ+MoA8q5EMKDqtSVjfTXU8kBt4as1Jx86A0RMlHB/Dk0qSjxvT9PRxSVUTM0hQ1m62Njs7ZQb3ADVIBZYYOWVyijPh/H/0CtdONYNIhg8ExHptmecJUIi8mE42Hv45rFsGweXKRbOYJj+zI28+JVDn8MTTZmLLqK8rzLACebF6QRhQaeQ9DW8TT4aTxE924Esu+hI/h4/JfQsw1IejXnvg9bqgqyX6nPwbfoG7RRdJzBbYl2TstDX8zxYKCHeOjR/OJ+DU1iCA1zABbXFFBFeLuGx9iHO+LA92NXwReMKm5cApjWP5n/j9e/doM6Twj1sTNAZr4fg8LSUs8mxmXb8vXzHRXvx20Flltt2ZxDB4SH6jVmFyj8DE3W5NbZTmkDv45ZWNB40KgTpebVPac0CnnESBhPkTzknjB8mo/nfxwTM/SlzBAIzFv/9kIJOn9kMZEiWtlPJCtLePdpzJI973OY5Uq4/oDUZ6aIyAwFft9pW1J6J4YYvJoHxkcVniOvdpGXfdo+pT9XfnAfr3PPoD+e/2uz3kH310vDcsW1xMXOa0CWSfB8Pl548HO4P/1c1fBgLEQb6OT1zJIBqYywjvs1rwfpnVcDF4/b/MleoxPo+Od3C4BE0xm1TQeI4Rb4WGZfODwlfB4AEzhf7JmJcBJQ8zGGhePuhFf+wGxt34OYk4pmPzSe/by7Or3yzIEPk1+j1JR2IPuPHftN4DtrnjpwzdZ/sh8O4hyNX9b54XNq2I5xd10kRoejfRz/ohW7easN19f7LGIYJ9XosE6Hzv491G+59tb01DAsCvWox/+6u+J+lsZNix6DxPsKWZVStImlNOI2KyGPlH1AfnWHarBjdJ1D1Prg9VAuxVko/Xj/146PoL3XerU/NxIwxldYRtyjvm8bA4wbvbevizN6DouBioAwCH+wFq4QwWM4qFKj6kexomcfmzDg9hMMAqZUl1XrGvjyhL27BIudd60iLzSz3taPj/e/vu5DvlFgWwV7T7OTBLpjyG6vXZUDtiuVe9t7ree83tXOC04RIYEzlYE8rt7HVu2C7Hl46SwhQwrmmWKyLqDqCGxm1tflwfgnDoTSwVwg15/Oz+3j62d1LBDOvLe4mnctLxb03zPbpfm68e1OsO3iWCibYw2DjtPib/VNEUTwkXPKGaJhtyP8IzB7Yw3ByMDwJbV1RFdDQgETpVqAQenNWja7LNiP5/t4/QsoWiWHsbXY53eA0cDhikhiBmhUYjL5/jwk98YqY8C85ghua/ezlF/315CV8KvQ978je0QrQhA8mSHix/xTL7xn/wPDj2D4OZStLl4HXZ+Pw5+ZxkPtzCs+mewz74MrlQX9NcbrXaQGcZ2HhMRwpmonCnKvObW8RkTIrCl+Ogzj6BO6n5c5R23c7JN4MpKl+S0/cwaWcmFHInl2VbOBcGE7Ug8PAqvn4/j3xIOcFyDMQZ9cJhf6uZMK/z+NI8QH7G4J2+0w2mVljb20k2R+b5Jx5batryEAIceyUF5IKT6+b7XryJEursS8CJHUtj1IebsZN7RTtC1NAr0K4T/e//Q4eaNjts4Rmd+ncROEfNwjCN41Ivky0JELh2y1bSOX/VWJ0coOu+z9ZfzOpM5Whs7IYhdNkBSDpM2YBfdqQcxjNwa+Wh8K5F0+CzS9Z2L2CsQV/fH1cwkyV1JzFUtnA+023gjm5w0nczhxHxt68VRUW5RSm1t3xADNKUmLlzn4NXiljtxXav3aDSOUIW5OK3pQksTalBPiCcFLEGfissHeVEWMLAfCAcH5x+s/s6V76V5Sf6hE3aU9tARSpXVeesOuY6+Sp7PMB6UmRA68BIknaTc0+FMVy0q9HN+Uj+0mSKXmVakbR+C7HFsR+4LhY3IIw82mgYo8+pKLoR7Xv34e/ok0fdqFGJ7taKKwzjuv/PJscEFa8LQlkljUWhY7dK5RP4QTsff3HQ6e83mZ72sxK8azdTbCHVurqczW6IYM4UT1mWM0v8ac2vPQ3SpkhJVCIyF93v9lPsdzYW1oobn/6kczY17nHuaXOHU587y1lRviuIjfgs9V6XmHh0I7ZgsiWZBpPdZEpws9yuIcgsE0ke2KJqGOkt7XfL5D/ZPSM7vE95pnXdh+/P6bV2dqBmhTSVhVDpORIjFBNUYef3I0BtcSe/zh3OtB5JfpbGqfd7hU8M7hlt10Njwd7y9OwaAgjVz7pPXzq1KldMf7DphhfAzGaajMzT6JVC6aV28+Pv94jJXPr7xZvObIe+e3twBtLAdKsntnZ33Jdn4p6l0PF9HmcyE/d/jo91ibiYHm6JgeR5dGsKVsITeOhlWc1nxDbuEWZu+zhTouQG1xJa7B6IeUsX/c/9NSBhd1Pwculo86r+hhQuu81rrMzA9FI0ccg2cneVirROX/dYdTV7rkmceKRCmMmDIx19G1GYlWtYhhZ1es4FCOs7Jxjb3nq8/Iks8LA80Wc5QfP3/CtpVA5WciKartquepc1zWVPLi9HveAeqrZjNn94lvAtH+zx1eEHc6Xuu8IgCV3Xu5GKpkI7MVGCHPhnTgfaksbsZ5V0ZLdgiPwoRYlBI0loN8PPuNQisEoOiuwjiIaT2PLTu0CLNYCTUcbD0veGzq8453lZbl9x1us13sIAoZ4CtT29O8LHvVngCvL9CU4lYAofu7Kzw8DdjMCKSuwG8gHp/i3ufo1IdlTnD5Xk///ha82fmOT3YLcVK2IKMTd0gBRjP73YHfPW/9jzv8YH5rklLPA3dD38/tspR1wqbjGWuhakWYE3z7iXHPqY7UFASCS1Yszwvgzyo/3v/+eGvh3H1RkHjBVbnpEwacL03b/N4DxMLhgT2dC6TVsHD9vsrmPeeKkAgezl54+kIWy4/3F97aS3irp9NA8FuQ8s5Jmb7UWUJdFlSqpuKekAeZj+f/+tFLcQXJLgLhvYBQ1tt3G/+8w9NBR1z0mlfCz4uB2OI5+eMOzzJTHrOX5UFc6JNZXJzfeT3HqPBHave+zOnH9dWiwk3uQBrijHTUgraEdgNEf778gw56ziuy2cxCDsS6XLefrPy8w9WshffZ6zbL22uZNkz+uMqm2lLfX3L9bp1sfFVBz68QPBEKornLfKayIYK4O7oSwTiZXzHcZ+lz3o35xkOfh/+/5CALPupWQol+5iy2ua4ZoMuYX/8mZpnk1Wpw8S9X2dSNyndhAPlPILyasEgMEjPJ2/v+vgFJYJjI8nXY+RW79bgx6s2kyfu3CMjP9/9/5Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvIVgP8H3ZoZmXcppvcAAB5ZbWtCVPrOyv4AgBvYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO1dCVxTV9ZXcSsguFSt1gX3WrXaal3afp2ZdtpOv5m20+l803aWTjtTZ9pOnU7rdOrW6WKr4lrcF1BkFRAQxB1BVATZ17CEJCwhYQ+QEEJC8v/OvWFPQBQUte/4+/8Skpf77rvnnv28JyCQQAIJJJBAAgkkkED3O5lMMNCLlqBubCQYLcC+M9BxJoJA9xfpCVlJyTjt4oKTO7YTdrQglP4Oo9ewLVuQfOECGml/CHR/UbmqClELFiCmXz8kEhKaXjn690c8vQYNsEH2pai+nqpAvUhGmFBPr6kffIAy4jEcRwAODm0wHBjmiFL6rsTzKP/N/aT92bU0ELQmo9nuGX9cus1IyD3qjjzir2nYMJiGO8Lo2AoMH4Ea+k62/G/8WEb3Ov8byH+paNAhr0SJhMRERIaE4KyrK07t3ImTP/zQ19O7Y8T4qMjIQPqoUWgYOgQmx/a8Nw0fjgbS+dLHFkCr1vT1dHtGJN864rtCo0F8ZCROr1mDsJ/9FBfGT8BlmwG4Tns8vgk/FlLRWiQtW4pads3E67a8N5IeMNnaoWDoUFQmJPT1VHtEjUYTqgmpMTE4//bbiB7mABFdcyGh3M4eVXPnoeZnz0PzwkvQLF3a19O9I6QjpH3yKUqY3h/u0J73TO87OPLvinft7uup9ohYTFum1eHa5i2IGeHIeV5pMwhVr/8Gah9v6KRS6PUGbtsYfgzWn+n9PB8fiPv1h9F+mFW9z2y+5I3ftNj8e5HY3Mvq6hD9/l+RTddTRSh74QXUxsbc09fVU1JmZyNt9Gjohli3+fqBAyGZOgV1ZaV9PdVbJhP9qyV7H7f8feQzmae9XrL+G64PzN//OKlGW4+U/3mWy7eJfHsLvW9vj0IbG5SHX+DH36vrxPR4lssPkNF1sthV6ep2z15LbxHL8aX9eyUUPM4fbsl7QiV9l//VV/f8WpXl5CCb9je7Hvn69T9qfc+IyUPu8ePIZXJPMm7qwH+Qv19H3+U99zz092AOhM24jjZtlUEPBc0/6623Uc58GNJ1DaYfO/eBErEY6Q89RDZ/MLfx7Ww+7YVG8gVkY8agViLt66neFLF6VKVej9QsEcKPeuLUN9/g8ptvQkHXUzxwEEqjLvX1FPuUmB6vaWhA0nPPoZrbfEu9z/J+xcxGBgT09XS7TawGWUevubRfw//zOS5Mm4E4ugYW17M8NvNvsp79SYu/96MkkznOz1i1GvIm3nf095nNZ3FR/ooVZpt/Dxh+xntWs8gID0fUI49wm8b2dg1dn/qZZ1D74QcoJT+n/MqVvp5qnxJjpeREKLIHDLAa57OcX33//pAsXIh6bV1fT7fbxK4r/3Ik4uxsuW9fOWcuVFs3Q5uby33ce897uT1Ulp+PlIcnQTdoEJfz9jbfEY22D0DmYA9VWlpfT/WmqK66GgnjxqGAbHzFts1o0N5ltQnyP40NdWhQV0NfVwOToeGOT0FtMCDlpV9wvWiR23c013ZZfldx8OAdn1tPKWP5cqSR3tdmZPK/7xaTZWxshFZVgUtXr2PL4UCs3OaB1TuOIjjkFEqL8mG4A30zbC2YDhR9/Q23+R3lvrmmy2o++b//4z0XF9cU5CPur+9BRzqA0d3CezaT0mI5lu8MwqiVnnjgyxDYfnMOg1aH4IH3duGTTYdQLBXDaLydMzZxfkrPnEHOQBs0UpxvbBPnm5prujaDkDdzBuoqK2/jXG6VTLxWy2GFu5qyMtTXa63/zqCDXq1CbZkCpYUyKGR5UMrEqCjOh7qyDHqtmoT09kQEjTotXtt1BoM3XsKcgAIsDlVgSZgSi08q4OSVg35/O4ztrgHQ0fxuJ5XJ5Uh1ckL9wIEW/j5/b2eHgsGDUXb5Mj9er29AgZT8hMRExMfEcqQlpaCiovymzqui41MSkxFzNRrXrkQjOTEJVTe5v8pKSnD1agzCwyNx4UIEwi9GITMrBwaDmWfWJMdk0KNeVY7M1FR4B53Fqt2+eHv9Eby49jB+uuoQnl91AK+uPYDl3x3C5v3HcO5cOIolOdCRXe5N8o7NwQNbrmAJ8XtpaDGWnJBj8YkiLAmR4ynaB2P3J2PRF26kA/J69bxtSWM0IvnVV3g8Z2nzzbEei40Lv1vf8pvyqlos+s9RTPzUDVM+c8XEf7li2p834eKlaFrc7turjQFRGLl8HyZ86o6x/3TFjHc342r0dRLj7o/xrf8V2NMYYz7zwNiVHhj69hZsPxrapAvak5HGNWhUiI1LxIc7AzCTrsF+1XHYrj+H4duuYvTueIzZm4jRe+IxfMdV+vwsBn/uj1Ef7sfzn+3EviN+kIrSoesl3/H3/omYTHLOeM/43hZL6LO5x/Mxbo0/4hOYr937NoBJSOamTShgvHcw+3gdbT7P7/7iZejb2iBa21cDUjDaTYSZPmJMP5YHmzUh2OIeisZ6dbfObaJ99zO3axjnnoXZfjLMJAxcE4rN7sFo1HZvDLbXXvaMw/ij2ZgbkI8ZATKM2nABiVkStF0v/q7RgAp5EVYdPoXRq/1htzkK02jtn2BrfVJJKMGToUosJCwOLcEy+mxpmAILSRZn+ebCcesVDProKH76yQ6cPHkKNRUlbaZxa/bhV/6peMQvn8u7Bf/ps8eDi/DQtydxLSEdvc1/Jh35Fy8ie/AQGG1tLWu6BMPgoZCOGw91UZHF791S5GSjcrmeeupUCR7ck4DfbfaFulzZrfOLiivgtD+Or/0y0n9snAf3JuCX671RVVzQrTHyK6ox7UAc8c38++leefjfQ5dh1Nd3uFgDxGIpfrbhOIZ8dxGz/WVYxuZN/H0iuBhTvfMwwzMbT/iSLAbk4km/XDzqk4fpvlLigdy8F2iO847LYLsxAiP/sgu73fxQoSyCvkGHqpLibs23I31wJgdTfKSd8v+xwCI4bQyDVNq99egusZ1UrlAiefoMsvk2VvT+CJjsHXh+t+zkSatj5FbUYJZnBp6kuTL9Nc07F7PXeiE3MwPd2au7o3Mw9mAqlhHvFjeNMdtPivH/8UZsTFy3bIB/aj7GHkjmvGF7aNTuBDifTrA4f35BIRZ8F4wRtL+YrV3GbG1IMSZ75mKxVxrWR8sQVVCFQpUG5Zp6yKu1iFNU44fEYvw0UIxpPhIsJn5wG03zfehgCoa8vw+7DvtBkZWG3+461Y1Vt6RwaTkedqM1DFFY7AF2PeOPiPDaoUu0n3s3F6AhXZ7y+uvc5lvL7bP9wGu6Kz/rZAS2vka8cSIbj/iT/gqVczlxWBuE4DORzLG9wQyMeM03AdNpXdlvFwQW0jXL+RrbfRWGHZ6hMNbf2Mb+63Q6JnrkcH4uIn6O3RaJ+Kz2tagGbR1+vvsMRu0z7xNua+k841zT8PHZLJTVdp3DrK7X4b9XCzGVdN0itk/ZPqBxxrmmwulzL7zhEoqRO2NvONfO6NvofIw/nIU5x4nvIcV8HzDbz9b1wW1RiJWW3HiQmyAe5ztv4T1taPbvLfK7/SB5ahnqdbouJXlXQiFff8ZDtib2myLxxf4g8rGqu5xDfrkKU/fG0nrKMc9fildO0j4IKuBjjNoVh9c3eEOltLQ5bYndT/SsexzFTfmcpzNpLz2zJxINdbXtjttE+sBuW4yZ97S+7NixJL9fR4iAbmcyTHBJkGMK6QvGG7YHGJ+meWRiAu0jti9unYw4llmCl0/k4FHvHEync0x1F2HJ0SScyurJuNYpPyISoiGD0WhrZyn79Hfj0CHIp/hfJRLx47vif1qJCrOOZpK/VMz11TjS589/64NyeSf2qukewCNxEowmvc3s6vgDiTgUn4/nAvNIhhWY6SuB0xfeSIyPp8M7509KEelO2kOLQ8y6f/S+RKw7EdduxsVlKkzeHkF2tIDzi/F+EvmKvzsW3zKXG5Kp9c2KizJMo/mZdbWc25AlPG7rBT7RtYqr6nBNXo1EZTX0t+hTdkUVFCsnzZgOLbf5VnJ8DsN4n4/S/Wi3xjPSHH8VmEm6q7DFfk9c44f4uHju31snE/4YkIQp5C8w33rS9igUlVXi7VO5JMuF5MsVw+7LMOw9dprMSOc2YHe0mOxwGpdrtv8e3HoZEanidsdsDM/gep/tD8azhcGFmOQSjRxFWXeXrB0pajV43EdEPqOlv9bbVE/7s8bQiGq9nsfohk7Xs3vE+hpTfvtbbtetxvm0H1jeP//d97oVaTQfs4Hs12SyjcyPW0R2YNh/T8I18BxMDdbybUBpdS1mH4ihuKuYy/qy3ZFgOnDjtQJMIf+d8WqEy3W8uckbtaWd+9W/D0gm/8F8/KPkzy9wuYgaVWuezEBr9/ThGO7rs73J8PCRTLzjE4OexFJfXpZQvCBp56+x9z0hnUaNhKMeOOfigrCt2xC6eQtCnJ0RsnEjQr7/HoH0mpyccss6gf0qY8OGFpvflu+NTfldXf8BkDw2H9paNe+DNZD/1aCrv+HYV8lvnuKeYbaLxAvHbdH4x65ANNRYzwX6Jkp5joXFa2MOpOIjf7PvFC4pgxONw2zCdJ9cTFnljfSkJJa0sRijSq3BYwev4/Egs9/B9MAKv2toa8/T5eWYRDZhcVNuhR03kmTfPybzltawmWKKKjGVbMjitvwPvbX4r5n05Gddeeppfj9RSr8BSOrXH8kc/ZBKOEvw+/vfUVDdtV9ljdiKyMIvQDR4IBrtLON8vgdshyLf3h6q1FT+G5ZT/fR7V6QkJZMc6bscX0uxyf/4ZWB+EIvhFJjklo6nv/aBUiaxevy7gSlw8iB9EVaC4dujEXg9i39eWafFEu8M0gukp0k32K0NxUH/U1ZtwLls8uH2JbTo/pHbr+JkfE67Y/xSCzDuUBrFe8VNuRQ5Jm+LQIZYdtNr2JbUxKtnjqXz623lv6JHYzKqj4mGhtXcm+6nNDX55nB0gG7oUJwZMQKRZ89Ba+h+bpRpubJiBVKnTeM232qs13TPjnxP8z07Rqw+fgX9/rAX737nitL8vBs+u+GLSDGmki5m/Gd5uLGr/XD16nVe025LKo2W5DYWC4gX84MKMY34IS9pvV9g+ZkczDxmzs0M33ENf3ImG1DeZm2bprHmXAbFTCLOf5YjnfPDRZSWV7U719ZoCel7kTlmJ/4zOzB/2zkUW8ll3Sz9ISwbs/xkTT6gnOL3nsk/IyanlW+/BQOLyR2Ht/CfvWd911L6POCttyAu677voqH1Snn91+bcPuvXtJLbZzVdCY3bbFnCErIx3DkS0/0kGPRPT/zgdgyaqq7PeS6vBJPds8yxNfHE9uuz2O4dRjF8+zzu6Uw5yW0S5y/zw99wi+L1t2byzSzGRBqH2QYWb89a5QVRanK7XH6j0YAXPBPI18w350jcMvBnryusqNPuXOsic3l+Z2lTPM19hW2nUaHouax+dlGMKT5mH4CB6azeIHVGBlQUl7F6W7v6K0FHujvc1h7nAoNQewOdzIjn9jc78/tYrNXzmY7R29ggj3SDptxsqwsVpZix+Sz3y546peSx7UMf7sP5s+eh6yIfo9LWY6lvOpdrZr9HUgz/f86WueAVocmYcNTM35EusdgTntLu+1LSD/O9WDxdzGMD+7XB8Ag6D2NDqx+SW1qNqfvjeO6A2/Qd0fC9JrKY038u5MDJS2z2/UJYflKMp7aEoqK457xae0nKfd5m/i8I7h3/n6m3yhUrUN/ko7erw9LfzH87/uKLEMkLbzhO/qVLED3wAIwszrfCexPtsaLBg1BxxVzTNZK//sqBCIwlm9kcLzHbaU9x1TP/2oPs1CQ0duF/fnxBzPPl7LfTaa1nr/WGuE0uuI7s5pNu1ykWLyR5KcSEbZHILbCUxb+czW2xAcO2XsX7231J/7TaCK9EGa+LsvPMp7Fm7oiAQllhMc66iFzOfx73h7BYIw8LNgSjSNrzXvWV4eSfeopb+L+wF/R/M9WTfap+cAxMxLv2dXgHGOyHIWrQQIS5ukKl6zzHWlFaitSZM6G1scztm5pyfKwHsnB9a03XOSwRw7Zda/KXzH4N051P0N62WRWEjzYeRqW887ULFCnMNoD4wnytESS7J85eIkVkzl1HS0ownvtsStLLOXjNNarlu7bkm6ngtmFZmAJOpCvmrvOCJKvVZ18eYvYfmQ6ZeCQLb7pftppv3hYrxUQah+cmiT/zyE+Y/FUQkpLTrNaGb4beCc7ADF9pC/8Xn+w9/jNpqfrvV1wHdPTXmA1XUpx2/KllSJFY+mXsL5bNTnnzd6joJM5nY2roO+lLL/BnWjC6kl0Ih+8v8HpjxzoE05+zSHaG/OMwDnkEQqOylDVGJbVaLPDK4Lqb+eS2GyOxzjUEBo25Z2JjZA7GUWzAaoUjd17H7vBkq+MU19SZxyGePU7nd1wTaK4pGPXQk91b5h6HeST33Ed0iYFrZLrVcYKyaH+4t/p/zJ44fnUK3mERLOC6FdZwaqDfPuuZSHMoaOnXWNqL/Gekq6pE1aSJMJHf37EXp5H89dj+/fjztSra9DTxmJ1eRTt2cJtvchhuUc9nz2fQDx4M2UNjUVvYakMylVWY657KY5pm2W9fi1JSjJ2MSR/txeWISFo+671U75zK5nV8ppvHHEjGLzf4QqWU89r7y14JmHVMyn2liaT7cwo6WzMj3jtNcQDz78JYTeES/r0viBZeDZFSBacDidzHZHppMo0jKbReb5ZVqvHIUVafbI3/HciefPjDMdRV3vo9yqnyckzeH89rdr0V/1uj6l07uZxay9NVDhyIoLlzEJ+ejsYmGeY2/9pVZJK9Nzxgy2u4lvfpOkDO7mk+ccLifGck5ZhC+vtJptM68H8p6dDFBNsNF/HC53shzUyD0UpexjtdznUu081MZ0xfewyy7GxIyD5PPXCd6wVWQ3nF7ZJV3d9MPukUB5Duf5rGGe+ajme/8YGxqgSeSQW0D9P5+JM9svHrTmyIeUGM+HWwiOK+/BY9NsUzGzM+d0fy9etd5Ke7pnUs9qSYo23PztIe5v+skU6rReWcR9E4aLCF/WYxIcsNBa9bB6VabfYby8qRPPtRaGwGdFLTHWG+Z+fTTzvNfrJa5CTya5Z20o+wIKgAA/7tj8+3ki9gpT5XXKPFPC9zPZvJ+fAvQxAdkwi/xDyMP5SKp0n3j9gVi30XrevsZlLW1tE46byvY06ADONX+6GA9tHn5zJ5TMdsCKsTupxP6XIct2QFxRvZLflflp8eQjZg5XYPVJfcvM9eoCzDNJcoWgdLO9mbZGqCysOD64COdVr2vLWawUNw0skJl2OvQ052IOVPfzLn9h079nGxOGIE+RP9kbdkCXRd5HR1ej1+eSKL/O98q3uAreF07xzYf+QKL78T0NZa9qW+HcZ6Agp479SwjRE4dCIKn59JoXhJjIUnyLfbHgkx9/u7zin99azZBjxJPLP75iwCzsXijYAU3ie7kGzUeNL9qXldy52qrh7LfDPIVpv5xfoEplPc5vixG7z9af6qbvarsvqLphpvuEWQ7Ke3yD7P/TTlgG4HsXx/Jfl6jSTT7XuyHXjeLoP4HbpmDaK3b+OxocnBwUofF9mBobbIHzYM1RkZNzxnbkU1yZ6I+4Id+d/clzJmTwJm/GMv4q5egaGDL3Ugiewy68mg48buS8Sf3cPxK79kcy8T0/2ul7p1b0uAqBiTm2zJqD1xeNcjCj/xTeO54akUX/58fySMXdQHm/eXP8Ul446Y8/XMt2G+2pg98ZjwwW4EBISipkxu1Za1kEEHdakCf3M7D8cfYrkNW9Kk81lM8aifhPsit4tqTp1Cbb8BnLcdc3d19vZIG/sQpA+O7jS3z37HarrFhw93+5x+IiXpTVG7GkdbO8DWYMi3F/Da6n0ozBW1i0OyymrwiIeI97LP88vDrEPxmO9lztWO2HUd+yJSuzWHMrUWj3unc37PPZaHma40jm8O9/tH7WF9XondvBoTVkZKMNFDzP0YPn/CgzSXUX/fhzXbDiM19hqqSuW8d6SxQcv78hvUVbwPMTI6Di9sOcF9R6Z3ljbpkamkz57zSUOIuAzzvLO7vbY3Q2xVWQa94qWX0Mieu9SRv2TnDXZ2xHv7Tmy+I9Qsv/vOn/g4N1P1/FdEHqZ451ntTWTX/xjt/QGf+eLrnZ6oblOnZX17rwZn4tHjhfzY+cdlWBhUyGVk0vYI5BV1v5/pfbIBM45JudwuoPMtCi7k/um4rZcQl9X9nsgGgwF/OZuHSR559HtzjMPyAk7umRhI/swjH+/Be+sPYcsBXxzyOYF9Xifw1X4//Op7X4xcF4jR+5P4eXn/EO3jSWRDHjsUC5HCXHMIE99aP0F3qfbKFdTaDOT33FvIt6NlD1dznF9vYwPp7DmoU93s/SMm1NY34Hl/ER71L7DYA829NE6eWXD44CACgsJQr2m9N2JrDPmRHrktfVLMFkwm3/tV0v24iV5G/0xWJ2iN4dnrDB8Jnt59kc53cz347H6QVZelZFOyMLepX2UZjyMLMMEtDfbfX8TQ1SGw/+I47NcEw/a78xi7N4n2eQEdV4ynWL6R9WOT/X/ZNwn5FTVNK3X7iclu5VtNtSErcm65Jxx4freA5Xejr97CGc1XlSBXYQatP/PlO8aEzXXPES6xeOzjXUi9HkNrbOZtMsnFVPcM0pcKnqdnfryDy3Xsj7i5e4aVtRqyHRl4LKiY7ICc9+c7kO7/MiQet7ryoeJyvBgkpr0r5n7qIt4/puR5SdZ7xPJEi3g/o5LbmkWsF9OP9gj5EAuOpsIlVtryLPM7wfvmc9SlpaHa7gH+HJ4b8Z/5Biy/K9+yucfnZ/7cBIq1Wa+bNV9gEenSgf89hd9/eQAKmZjPmN1n80pAGmZ5ZeGJYzmYR3Z75vZwyMtvXg99fC4bsz0ysdRfjCUBYkyj+CFZ1rMans6gR2B2Gd45K8OTftmY4Z3L7wGY5is1g3QMqx1M88jC416Z+F1oNg4mFqG8D59nyzzUir8tR8MNdIBpxAhzfveVV3DjKmF3yES2k9X3peY8kJWYcC7Z+AErvLBlv09LrbhCUw9ZlQaF1XUoqNaipEaDW5GYBkMjyjVaVGl1qKB4rkrTm8+cMJKO0eJygQreGSXYmajA1jg57/X1TFciSlYBebUG3e8Tvr2klclQRfw12dp2oveHQz9oEKQTJ0GtaPbJeq6llLVqLPEVYU5goUVewGzfizHxSAZGf7APZ06f7/T+ONNddOf1vUqVFO/reI+IFf7bD0PRgAEoO3OOH9sb690c2kWSLEwhX4Dl09v5gyFFTbViBey3R+PJT/ZAlBSPRoP1WjGLFVtzryZ+b/vd9H/DmGg+xsa7Q96tUX2JEpUPT+C1oY42n9X8CtatvW3n3hhbSH69mNc7rNmBhfQ6cO1JvL/eFWUFko67jwVLm3X1Dc61NTXODY16Z4NR76xW1zmrazXOtAc46JiW17Zo+1ln37cdo+3nRqPR2aA3dPp963s412m1zpraWmdjo+U52h7fYZw7RmxNqzdv4vflmp/H6MD9AS2L8597Dg236VkFjFg+8rehuRSTW79nleUFWD5s8MdHsftwANRV7fKr2UaY2IPy70fcUdKTD1Q5cxZMFN8x3htIF8hGj0VNL/S23IgkKjUWeGeZayCd5IcfPpSGcR/uwYXzF9HQWqPOo73b/5JM0te8uuf5z0h16KC5T6zpPl1lYOAdO3dwThkmuWfz+xWtxYTMF7DbEoWfrNyD3PRk/owjIvYQi/4o7HNe3Rf85/edP/GEuab7ySf8szvnRZmwKorFyBKeE7XmC7B874AvgrBikxt/lg6a+J+UV93XvLov+M+oyuMIRPMXoKGLXsDbQybez/liUDbvr7DID3NfQMGfDTL4Ize4eQahvlZllv+8sr7m1X3Df119PdQlt97LdOtk1jSpJSo84pFptVbcnPcfsz8ZTh/uRvy1a2JDQ31f8+m+4v/dEDUfSZPzfl3Wr8lqZCzf3wx2XwzLqQ/5Lhyvfe2eWy4v7Gs+3Vf8vzvIiA/P52LiERHm+uRgXjtk85r9LC8RxYQe2j3HLkTQDy7eh/hRU71ej8zyWuRW1kHMUFWHvCot8lQaSKo0kFVrIS5Xo7C06saDCSSQQAIJJNC9Q33tfwoQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQIECAAAECBAgQcDfj/wHnzJuiuaOoDgAAMhhpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+Cjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBGaXJld29ya3MgQ1M2IChXaW5kb3dzKTwveG1wOkNyZWF0b3JUb29sPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAxOS0wMy0xNFQxNTo0OTozOFo8L3htcDpDcmVhdGVEYXRlPgogICAgICAgICA8eG1wOk1vZGlmeURhdGU+MjAxOS0wMy0xNFQxNjowNDo1N1o8L3htcDpNb2RpZnlEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz7Zi4tXAAAgAElEQVR4nO2dd5xeZZn3v/c55zlP79NbZiaZSa8QeocsCArsWl91UXQFQSyvrO7LisCKojRdQVcQsLC46CqiFOmhk4QSQkmAlMlMpten11Pu949nMpnJTHpCBPL7fCZlnufc5zrn3Nd9X+V3XUdIKSWHcAgfYCgHW4BDOISDjUNKcAgfeBxSgkP4wOOQEhzCBx7awRbgoEBKTCEwAMuyADHpK6qq4JASFRBi8ueH8P7BB1IJDCHY9OoaNj/7DJY9UQkkEgUBpkntokXMP/lkVFU9eMIewgHHB1IJEvEYA184n/CaNeiAZJwaCIEtJZ2Kinv58kMK8AHAB0oJbCRFBD2X/Tuz16yhPBgGaY37hgJSMpBKUP/bX1F54gkTFeQ9DgklE1DaWLYEASoCh6J8sCbCdviAXbug887f4r3lFsr8fqSwkeOmuCIEyXic7JcuoOGz5x1EOfcfilKSMorEYzHi3T2kurooDA5iZbPYto3wePHU1hBsaqKypoaoz4frA7b7iQ9KxlgCfWvXMnziibRm0jicLsZfuBACI5mie958qp5/DrfPe7BE3XdImwKCkWyW7pdeYvCxx7BXvIDznY04+3twWvZYWLAApANBEtPqsY85mujZ59Jy5BHUhkI41A/GGvmBUYJ4JsPmZacxY8VK/KEQ9vjLFiCKJp22he+554gcdtjBE3QfYdmSNNDx4ir6b7oJ7wMPEk4l8QFurw+1qQm1vAJV0yCVQPb2YXd1kbdM+oG2cJjMxz9O05e/zOxZswi53Qf5ig48PhBKUADWf+ObVPz0J1SEAkg50cpXJPQnE1g3/4yaS75ycITcDzCBWK7Axp/djPjh96mNJfCqDsTZH8Hx8Y/iOOpolLp6VEdphZeAHYtjvbUO+6GHkX/4A+aG9WwC3lqwkOh/XMniU5dR6fcdzMs64HjfK4EE2u6+G/npz9Ds8yFUZZIZlIrHGfroP9H4p3ves9lDGxjOZtnw9a8Rvf0OKgBz2TJcV38P75FH7fK6JFBMJij+/Geo197AUCLOSxVVuH5yI4d/5Ox9VgQpJcn4CLHBQYrFIlJKdKdOqKySUDh8UHMx73sl6HvnHQaPP57WZBLdNdkPMNNpOhvqqVq5Ek95xUGTc18gkaQlvH3hBVTcdjt+BMbVVxG9/Ao02OMIV+7VNZif/zzp11/jhYoqfLf8F0eccQbhfTSNLvqv+3nynR40hwNL2qixGD8571iWnXT0Hkq4f/FeXfh2C8lcnv4vXcC0wUF0t4fttV2YJn1SEvjlL/GUV0z6/L0CG0H3zTdRftvtuIHi7bdTMaoAsGfTS0pwLV6E85FH8C45nKMG+khd9h3WvvEaecPYJzl7wjX0zj6K7IKjySw8nncqW0iaANauDj2geN8qgQF0XHE5Fc8+QyAYQkp7wucKMJJOY19+OdFTTwPeu/mAkfXrEVf+BwHAuPpqKr74hb2+FiFK90GvqsRx758I1Ncz/5236Lrmh7yyfj1dyQRp08Te5UiTEQp4qYmGqIqGqIkGCYb9KJrGwV593pcxMAtov+ceXDfcSJXPN+keKwKy8QSxU06l4YrvvucmvwUUJBQsg7yikLjyKsriMeLHn0Ddd/59v6xsEom7YRqZm26m9h/PxXjgQdZ3drFl4UK8hy+l+rjjaGhuoszrQRW7d0YViWlZ2JaNLQS2LTEtm4OtBe9LJRjauJHCJZfQ4tRB0xjv9ggEVi7HQEUFFbfdhkN57ySGTClJmiZdmzYy+OIrFNrb8K9bx4y//IWi5sD3/e+h7+aE3BXE6NLgPPcckp/5LI2/u4uq1asZXr2avl//mrbZs+j4zGdp/dSnaK6vw6c7dzmmQxVsfRQCgQRM++Dn5N9XSiCBVLFIz4UX0tzXhx4KMcnvty36CwVcP/85/uamgyLnnkJKSU4Iuje3s+XWXyDv+QvBTRvwAWWAE+g54URmnHDifj+3BvjvuJ38OR/B1b6Z2ldepW75k6Teepv1l1/OG888R+p7VzJ/wWIC7p0rgoaACfkZBcs++Pvw+0cJJBQFdF55FRXLlxMIhSbecEp+QCyVwvjqV2n42Mf2PGxyECClpCAEm594guFLLqHh7bepAEQohDJvHnL+PHJeL2XnnHvAHqbD6UT7+CcQlEKxZmcn/lt+weLbbyfy6MO82deDuO02Fi5aiHcnO4JAjtFUhCj9YUnJIXNoP0EK6P7r/WjXXUu1zw9STri1ihDkEwlihx1GzbU/Kj2Kv3MFAEAI+p99iuw5ZzMrk0WbOw95/nnoZ5+L1tKCAvjfDTFG/1YAvb4e/QfXULzoKzRefz3GTT9l079eSvndf6CpshJNm9rEVMbnaCRISozdg70YvW+iQ0MdHaS+cgmNqjrxZlO6v1axQJ/fS+TXv8bl9hwsMfcYuUSCoU9+mkrTQr3xOnwvrSR06bdwt7TgAA6mR6PX1eL76X8y+9FHCb36Gj2/+hX5HSgAgEOwLUonRvM01t7EmfYv9l0JbAu7mKWYTmBkk0izuB/E2jOkTZOeC79MY/cWnF7vduE7iZCSoWwO5w0/JjR//rsu375g87e+hR4MUv7KaqLf/BYO998fsc+1bBlHrnyB3AvPU+jp2aFxowsxyfIx7PdwdMi2LAqpOC+u3cRL67voi2XQFckRzWUcs2Qukeo6tANMyZWU+DKdP7iGskceJhgMTiTGAYpQSSVi5D/9Weq/9KUDKs/+RnJLB1nbZMHKlTiDwYNtNewU/rnzWHTdteS6exA1NVN+x6EqMH6JEgLDlpN8t3cbe6kEkqH+Pi6/50X+3JEh6wkgtEqMfB7t9TYueKuHb3/iJKqmTUdRDtRjKzlZXQ8/jPr971Hl82Ej2LqqlGx+QTGVZqC1heqbf/p3aPuNmwAlT3HCp6rbw/yf/Rynq0RXGF8EilnEyOfI53Lk8gUsy0IgcegOnC4PTrcbh9MFyp4/YtvIYxZyZDMZspkcxaKBJW10XcPj8eL1+tDdHhSHg/HGRNX8BTudz6oCtpSI0eo9WwhMy2JXO4EEsC2EbWCaJoy614qigUNHIlD2ITS8V0pgFfJc8Oc3eCgToeWow/A6HQhFIKVkIDGLnz7zPNOWr+HiT5bh9IX2WridQzDc3U3qootoRYxmHic6w9Iw6FMFgdvvwBOJYBhFert6icWGMYolCoDT6aKmoZZotGy3zxwfHqKjo4tcLouU4Pa4mdY4jXAksttjDPb3s37jZvL5PFJKhKJSXVNF64xmNE1DAt7y8gnHSNOgkE7QtqWHNZt6eaMnRkcsz3BeUrQsVGy8KlS6FVrK/CxsKmPejHqiVVU4PYGdymNbJmY2RVdXD6s29PJy+xAbE3mGczY5w0RKiVtAVBfMCOssqY+wsKWaxmn1eINRFM0BjOryDqCr4z4UAoRS8gl2sREIbDZsaOPhVesomkbpfgmBZcH0ukrOWXY0ivYuK8Ef1nTyaN7H4nnTEVIibRtplwSrCQXILVnM/2xYzScHh6k5QEqQsW26L76Iae3tuLavD6C0ag5lMojvX0358ccDkEgX+OgtT9NvmGhCYtqgx4b45fnHc8oJYRC7Z77d8uQ6rn90HR6fG8MyCSRH+PWXTuSYow5D7Gby7ZZnNnDdY2/i8XsRAhI9/VxzxkzmzJwxJv9W2LaFnUvxyro2fruyjSe6svQoXmxvBN3jxRF2IhQFKW2MYoFiOo25KYn/tY0scq/jY/MrOf3IOdQ0NuHczqewbRtRzPL2hi3c+cI7PNieZrP0gj+KHgrgqnShaSoSiWGYrM3meCwWQ3l+kGlPb+H0hjf4xLGzmDe3FV+kbKfmmmN0odxq1wlFoWhP9hMmQpJLJLj4vjd5vLeA2+tBoJA1DNSBPv7y+Rlo2r4FOffq6Ae3pKmorkBIiW1vs/GklFi2TXlZmO4tfnpGstQ07X9L1gQ6rr+eyH33Ew4EsaU94RyKUMjGYyTP+BANl31n7PdlIS81SxfSkdQJux2oimDz62tZ3T7MiUfmUF27pgtL2+bRpAPnsSfhd7uwgLbX3uCFDT0ctXgOqns3KMfSYkXBSeC4k4l4XBSQmBs2cuIRzROWUgkIyyTW18cNj77OHRsyZMOVVC2ootXnGa38GjUtKNULq0IihcSwbNLZLC939/PMS20cu+ZxLj2tlROOPoxAtHJUDJNiaoTbnljLDasHGPKVUzFnNrMCfjRVQUHBlBITiSIFqjIqnpTkikWGhhPcvKmNP9/5El9bsplPnbGUqoZm1B1UpOmqUrIAR/lJQghM296JTyChmOebf13DKr2Gpac0AJA1LYZ6e/nvfzmGZTMqd32/d4G9UoIkGm6Hc3I2FkBKHKqKdLkxDoAbZwPdy5ejXnEldR4PcruAvwDMbI7+6hoqb/sljvE+iVA4p6WM19/MUhbwgRDEa2t5aWADuXQa324owdt9MTYbGg0VIRRKu99IXQ1Pd77Dv8RGCO+GEnSMpFmfhdrqAA5FMBDPcGS5k0XTayZei22ycXMnF/xxNS/YYZoXzyHkcSGQ5A3JYDKDapv4NYGuCSwbEpZCUSj4XToRn5/wTB+Zxjpe3LCZz927lu8NpPnUmccQiJSTjg3zzT+v5nf9CtPmHs6CoAdFQtGWDKVyCKtIWBdENBUTQcqQJC1w6E6CTp1p1eXUVEbp6m/k3155lTf7nuI7n8zT2DIbzeGYdN2aKKXLoJS3EUIZpU3sANLkhkde585+hTkz63AAedNmqLeXnx1Xvl8UAPZSCer8LtbGdhzftWxwOQRVkQD7cxeQwEhvH7ELv8ws20TR3duZQQpYFgPFPL5f3oqvrm7SGMfX+XG+EccwTVRFIRgK8EaPRe/AMC1llbuUd3n7MDnFiSIllm2hKArl0QivtsP6Lf0cUVW7S5Poxe44aRyUi9LuGYvHObHZg+KYmG3t6Orl4394jY5II4vqa1CkxLZs+pIZKkWe85v8nFAXoSmg43aoFExJT7bIC70Z/tKepTOlEPU68eo68+fOoiMa4dIVK5DiBT569Gy+9ngnD+ZCzFvSiFtRkRIGUzl0I80nGryc0VzOrKiXgMOBhWQ4W+S1wTR/bU/zzEAej8eFx6HSWF1J+JQT+c2Klyje/TzXnOegfvpMFGWinS5HAwGlzaTU7cKU24IZE2Hxp+fX8r034rTMmotDCPKWRUdPH9ctjfCx+Y07vcd7gr1Sgo/NjHD/k/3YXheKsCfsCIqiMJSMs7TMx7S6qv0mKEDWlnR/5WKmbdyAcwo/QBGSkXQS49JvUvPhD08xgqQl6mOeX2Nt0SLoEgQ8HjbhYe2WQVpmFkHdGf/F5rEtKfy+MDY2RUuiI/G7dLa4g6zY2MfSRXmEa+ex/Be6U+huD0JKDAlaIcUpTdMYr4DFXJZ/uX8tndFGZtZVgpRYUtI5OMJH6xxcccx0yv2Tk361QTdLq4N8fk6BH78ywF3tWSI+N5oQNFZXII46hhvfeoOnUu08KSqYN6seVZZ22K6hOEt9Btee1khL+WRH2qtrNIQ8fKSlnAc3DXHFSyMkbQ8+h0LQ42busUfwP8+uou6BF7ns0wFClRN3Nk1h0hqzvTVRMp4lL61t45Jn+qltbsWrqxi2pL1ngO8u8POFpdN3en/3FHvlUp/aVMaFs3x0DydIGxKEghACoSjEckWKI4NcduosFIe+3wQ1gC033Ejk3nsJB4OTeUFCkE/EiR9zNJU/uGYHvpYAFE6q85DJFwBwagq2P8zKjhhmPr9TGTqGkrwRMwl5nGTzRep1AzG6G7jKKnimM0UyHtvpGJZlsXogR8DtRALJTJ4WFyxomBid+slTb7GiEKKlrhJGTYaO/iEubNa4+fTWKRVgPIIuJ/9xbB1fn+VhOJVDCgG2TUN5FHX+YlZ5G2luqEWVEqEIukcSHOHO8fuzZ06pABMhOGt6OXecXIlWTFGwbKRtE3C5mL50Cb9YX+TZl9diFnITjtIVxp5bKcSpYG3nEwgknd39fOHBjTjrG4n4XJhS0tY7wFdbPXzjuJm7kG3Psddxpe8eU8+PjwzToGVJp9MMJ7MMjiQI5kb47ZnNHNm0f+y1reh58im44jvUeLxIISZOciGw8jn6AyEit9+By7lzNuOJdX480kSOEob9kQgvD+SJxxNTHzD6kJ7cPEJKdeJQVYZjMc6uUvFKA9OGaFmUVxPQ1tU3qYBnPN7sjbEpa+PVdYQQxBJxTqr1onu2+RI9g3F+8XaS6Y01SNsGAT2xFCcGDK48aRa79dgkgOBrh9Xw4RoHQ5k8cvRSyoIhaiuiqKNfS+aKhLIj3HbmTPTdoERvHX5RZYjvHV5OPJ0tFe3bNmUhP7J5Nret6iI2MDDhGE1RxijaW8MlE5NlNtl4nC/++XX6w7XURQLYSNp6h/lcg8ZVp+5/BYB9ok0ofHJOJX87ewZ//VAdd55cwR9Pr+HZz8znzFmTbfF9wXB/PyMXfolGy0LVtUlbqGJbDOQLOH/6U0KzZwM7t+znlvlo8UGmaCGlJBT0sz6v0t4zUJp026MUEuGJjgQ+n5eibaFl0pwxzU+lyyZXNAl6XQzqQVZtGsQu5iaPMYrntsSxNA+KApaUyEyGU5rCEyS+8/Vu0u4wXr3kXBqWBfFhrj5h2s4D8RNk3vaPy5aWE5AFDBtAImVp5ZaUIjR9gwP866JyIn7vbidvtw5/dksZp1VoxPJFQCJsSX1THc+nnbzyTscEGo2mKBPM/63cIbnVOS7k+MZfXuVFGWJ6dRlSwub+GGdXWNx4xmz2p385HvueRBUKM8Iejq4NsqQqiKWoJE2LhGGQse1SCGwfkJKSrksuYdqGjbh9frYPJigCEskUxc+fT+Xndt01TgKKqnFMlZd0Po9A4HXrxDUPr3WOgFmY8riBRJpXRgqEvV5S2QK1uk1deYgFYSfZQhFNCPSycp5uj5FN7GBHAV7oSePzeRBAOl+kzmFw2DhTyDQtHtiSoiIaGksK9cVTnFSu0Fq9+wm98aj2e/lwnZN4tjChq4MQgnTRpE5m+cc5VaO/29PRBefPiWDliyVWKJKAy0khWsXTG4ewxplEDmXbDi4AFIGBwDQNsPL88OHXuXvQQWtTHYpQaB+IcYI/z61nzd3tHM7eYJ+yDIVMmjfvuZfheAzDMLFtu2QK2KUfU1FoPuNDzJ0/d6+6mZnAlh/9iMif/kRkO16QpOQHFBJJhhcspPqmmwCJmc9iCxXd6ZpyzK3P+IS6ALdt6MFGogkFJRjh1Z4+jHwGXZ/cVWH5piGGLZ0ZmkJXMs1pFW5AYWmlm1vXpwAv0fIwL74OHd39zCurgu2iI7F0hjdjRfxlpa4XI/EUH69yEwhts8Hf7o/RWdCpKtOxbRtFVckl43z4iBD7shKe2RTid5sHkYwzd4RgKJbgE5Uu/IG9J+YtrvRT5+olYUmcamll9VaUs2ZwiEw6Q9AbBErmEqL0DLcqOFLgkBZ3P/cW16xLM2PWLBxC0DOSZIknz2/OnjtluHV/Yp+UQNEc5G69ldALz+NEYVtnT4kC9ALr29uJXHstDcHgHo1tA11PPI5y1RXUeKfoFAHYxTx9Xg+R/74Tt9/HYH8/P7zjAT73ocOYO38umrbjm7ek2kudG5KmjVtTCYYCrOnsYGQkSVVg8or7SHsSj8+PRFDMpDl1UYkisbjKR6VjgIJlEfR4eVv1s2JjL7PntKI6J06sl7oT9FsqTQ4FW0qK6ST/sLic8RvyuuEshuYYKzopmDZ+s8Ccsn2jf88r91Lj7CFlSZxjpxMU0ikWN3vYFwVz6xrzIw4eHTZxuR1IKQn6PbR3CYaSOYKj7qGmqZPOomuSV9q6+dcX+qmfPguXQyOeK1BnxLjrrFY8o21yDiRxcJ/MIYfTyeE3Xsdch4OFfi+LQgEWBgMsDAZZEAxwkstF4H//l7aVq8iZu99WQwLDPb0kL/wyjbZEceiTi+UlDGXzaNf+iNCCBYDNT57bwE/WFfnPv73CSPeWqZN5o3A7dI6pcJIajRIFAn42FlQ2dQ+BPVHWeCbH6uE8Ib+HbLFIVBY4clpJCSIeNwsiDtJ5A11TcJSV8ezmONlUcuIFAU93xFCdpcmcLRpUKwWOaJzID+pMmyiatnXBJG8YhDAIu/aNGuBzOpnmc5A3TECMkdgcRp56v4OpY/W7j1khF4VRPpaUEo+ukxI6sXR2bGyHEGPXJYTAqTsYljqXrRxCq2kk5NHH8gg9vQOsenkNuVTigDNn99kn0I86hsLHPoqZSsG49oYSBafTxcxYjKHf/Jru2Mhuj5mV0HPJxdRv2oTb65+cDwBSyQSZT32KyotLbRMffGUDv9hkMuPs0/ndgJO7n3iZbHxop+c5pd6PVTQAicelk3IGebFjsmO7omOEfquUkIqlsiwKqdRGt+1spzT4yOXzCCBSXsaLMUlXTz+MKyCxbJOXBvIEvSV/YCSR5vAynYroxLqweNEqcWGkLFGNTQsPFs79QEuvdKsULXvM7rekRLMMPPvB2qj1aGCbY06FoigYqoNMcVu9gKZsTYwJbNsm6vPwoh1ms7eG6kiQ0jpZyrsk/OV87a/rWPvaGxiFHQca9gf2WQkUQP/O5aQ9XqRpsK1iVCKR1Hg9hO97gLZnnyNl7rp5kwl03HAdoXv/QjgYZGLz9NI9NtJpBqZPp/Lmm9GAzt4B/u/ydioaGqjweahcsJAfvRzjhRfXUMhndniuI2qCVDtN8pZEReCKRljRlSKbTk/43kObBnF43CVnNh7nlGlB0LbZ1qdMCxPRDIqmTdjvoVv18vKmQWxjW2SkbSjDpoyN11liiOaTCc5ojoKYuMIXzVFbeXTVlFIibHObQu0D3KqKPW6Xs6UEy8Leg116R3BqKkh77FkJIZCKWspPjP62VE8ApQiVRNd1ouXlhIJBMrksZjGPYZVmUFNjAx01LXz3vjfp2rQR+wBWoO0Xir137lzsL36BYiZT4oTAmDLoDp3WbJrUrbfQ1d+303Ek0P3004grr6Le453sBwjAMOlXFUK/+TXesjLsYo6v3L+WZLiGqM+NZVrUVkZJT5/L9x7eQPv69ViWOeX5Qm4Xh5e5SI+G9yKRMG8mbfoGhtmqytlCgZWDRSI+L3nTwGPmWNYysV1jhdfNYWUukvkiuqoiwuU80z5MLrPNJHqxK0YGBw5VIVc0KaPAiU2T2z5upRtvNeVURZA1LHKFfa/Yy5smyrjdWlUUDAmpXKEUzNgHFE17YnhVgiYk+rhyS00plVeO/5qmaXT0D/PPNfCDpQFGUhksKdCEYPacWTwso/z0/heJ9W05YPVn+0UJBOD59rcplFUgC9uFGKVNtc9P+ZPLaXv4UeLbfz4OIwMDJC64gMZiEUV3TKoTFggGMxnkd68gelyJHn3DY2/xVNpFY1UU27ZGV05J6/QmVriquelva0j0de7wnCfXejEKBSTg97jpw8PaziEY3bXWdMfpLqp4dAfDqRyHBRVaaqKTxllW7yNfKACSaHmUlSMW/f3bzLGnuxK4Pd4S4S6ZYXFYo7p8Mtku7NFKLxMcnatOh0asIBlMpPd5NxhMFScUwasKFBWdrqEkcgcLxe6iP5PHHrdnW7aNrkDQ62TrxWyX4kQRCl1DpTzAt4+Zxocay/jcdDf9yZIf4dYctB62iFs64Z7HXyYbG9wnGXeE/VZs5ayrw774Igq53HZ0YIGmqrSaNvlf3UFHd9eUfJEs0PW1r1K7fj1u/2Q/ACHIxONkTl9G5XdK9Ojn3unkB6+NMKO5Hmw5thLZUqKrCjMWLuCOLvjz8lfJxIenlPvYuhBhzcK0JA5VUPCFeLkrgVkoUSie2ZJA6k4URZCKxVnWGABtMh3khLogEdXEsCThoI9O283r7QNgGximUQqNekuRjlQyzrJp4Sl5Sk1B96hZUWJc6g6NOE7e6t6mmHuDolGgPV3ApaujBW2lCB4eD2u64+Qz6V0NsVO8OZguhTLHOfRRh6BqXPhXVRS2xoeEECTyBRrtJD8/fdZYBdxlR9ayxC8ZyZV8tYjPR2Th4Vz5wgDPr3qVQm7H5u3eYr8pgQA83/gauYZ6GHUSt0IiKff7qVuxgi333cdIIT/hMwvo+M//JPSH/yUSCI3WB0wc3MxmGayqpOy2O0oF20Ak6KOhtmI0gTZRaWzbJuLzEl64mKtX9rP61akdrEq/iwVhjWShiCoEvkiIVweypFMpsEye6U4R8HrJGyZeIzvJFNqKmoCLxREHybyBS1OxAlGeb4+BWWDjUIbegopb1ygYJkEzz8nTp058La7w4RU2ll2aqA5FQfqDPLdxgGxqx0m4XeHtgRQdGRuX5hijM0sJwXCYFX05enr6Jt3D3UWhaPBSX5aAW0ciURSFdCZPa9BJNLItgKCpcjRPUIpOpXMFosUEur1NuXVV5cbjq/GYGTKlm0BDdQWZ1gV89+GNbFq3FnM/N3PYr2W3znAE5VvfIpvPs515iKpAi6ph3nEHmzduGm26BCDoXvE88juXU+v2THCkxoQ0JQNFA/ctt+Kvrx/7/ZyqMNcfX0MymcYeY6WMO6+0aKgqZ6huJlc/9FbJwZpk+wpOb/CRy5eyqeGAn3cygngiTdtggncyFkGPczQqJGit2VHWVmFZvY9cPoeCIFAW5cWBPHYmwyu9SfJCRxOC4VSGxUGF5uqpSzEbwx5mBRTSo+FGpCRaWcbj3XnWb2yfmtaxG/jj2n4MhxtVbHsyQkqiQT/rpJsn1rRRzKT2auwn1veyOa/gGaV5SAGZVILTW8phHD3cgRhtETNKohOQzhRIZbNj35ESmiM+vn9EGYlEGluCkDYzZzSx2tvANfetYXDL5smWwj5gv9eeu774LxTmzkFmJ666UkLY66PpzbV0/eEPJdseiA0OEfviBUwr5FCdOmzXMEURCrF0EvP/foOKc86ZdL4zmss4v8VNfzI36UUPti0RElpnzeAJWSNU7f0AAA4mSURBVMYvHnqZ+EDPpDFOaogQGjVlvG4XQ4qbnliGl3vi5BUXDlUlHh/hzMbolKbQVpw8LURINSnaJZNoY16layDO64NpnG4nCEE6keTkhuCOxxEKH2kMkcrlx/j40aCPLZ5y7nr+HZKDk+XfFbb0DXL328NUhIMTTFFbSpyqQrCumVtX99O2/h1sa89MLqOQ44aV7fhDYcTo2Jm8QaUs8OF5EzlkDkVDYdt+owiBKUuvmBq7/NFHeNaMCs6b4aIvkSk52Ypg5qK5/E/cy+0PvURysHeP78OOsF+VQAK6243yb/+PvFFkPH18dBOkWXei3XUXG9auoyefo/PSb9Lw1jq8Pv927EuBQCEfjzNy5JFU/fCaHSZNvr20hvl+k5GcibKdIkgpcWkazYsX8os2m4eeeYVcKj7hOzUBN/NCGqlCKeFlefys60/z8kAah9tD3rDxGzlOmxFlZyZDld/DEWU6iVwRj9NBwhXkxY44bUkDn8tJwTRwFjOc1LxzDtA/tYap100yRqlWw4GgvqWF29sMHnzmFXK7yH+MwbYxMwm++bc3yfkiuDRljK4gR00SKSW1NeW86arhhgdfo799Y4nevMuhLTBzXPPQG6zJeyjzlwqchKLSNTDMZ2ZFKItOrC9XxyJfpf8rQmDLyTUFW3H5kbUcFoDhUf/A73Iy7bAl3PBmlkefXU0hHZ/yuD2FetVVV121X0ZiawQH1HlzyT7+OPrmNtDHc3hKNqnR309vRQXFdWupuv56KgOBSS1HBAqyUKDH7SJy3314q6fuZQOgqSpLyx3cs34E6dBRt9MWKSU+t4u008vKl9/m+ApBZXUlyjg+03Amz5M9OQIuJ+migW5l2GK7KTgDxDNZFmhpLj6+FbGLFiZFo8BDW7KEvG4ShoEw8vQID7bTRyyTo1UmufSE6Ygd7igSl8NBQLX4c1uagLv0unGv20lK9/DkqrdoJkVduQ+H27fj1xyZBdLDQ3z93le5P+Wjua4KbBtFCLKGScEwUBQVVQg0RcEbDbN8/QD5zW3MKdPw+gOoO6CdSNNApmJc/8jrXLchz/TGBlQhUBSFwXSGmkKCX5wzF+d2nJ+RnMHvN8RxuT2l9viGiTM1xP+ZX4XHP7mGQVVUllY5uXf9MIaqownwedzEnW5WvLiOo6OCyqrK0ksI9wH7VQnGBlUUjOpqzLvuxul0jIsWCYQAn8OBfHMt0WeepU6AUNXJOQFp059Jo9xyC+X/8A+7PGfU4yLqsLh3cwK/e2ryXCjoZ33apnfd2xzfFCQQKRubRF4N7tmYQHe5cDpUOnKSrOLG4/XQ3dfPl2f6WTp9x4q4FeVujXs2DGFrLty6g/achaV7cbld9PQPcl6ji+NmTdvJCCV55pb76I0nWTVgEHA7kBJCAT+DTj8PrFxPvruDCrWAriuoQoC0kaaJmU+THBpk1do2LnngbR7JB2mZXo9GKYs7kMpRa2f4zuFRHm9PYqk6uiJw6hqe8nIeaYuz7rV1BPLD+FQLfbS43jaLmLkMqZEBXntrM//+8Fpu71VpmjEDl0NFURSSBYP0QA+/PWsGzeWTu4wk8wV+vyGOY1QJ8oaJnhjg0/Or8QamLuQJu3Tq3PCnTQl8LhcKknAwyIaspP2NtziuwUeorAzxbvcd2hUk4D3zTOKnL8N+5FFEcNsF2oBL05idTpUMHoc+uT5AQDqRJHfePzPt/PN3m0D1idlVrOjL8NfePBU+14RxpZSoQjBzTgv3vzDE4odf4RufDBKsKE3smVEvrX7JxqKJz+lECZehKSpF08JvZFjWsrOJuw3lPjeHRXWejheIuJ1oWjmaqmBaFnouzclNTbs1DgiuOa6B2BMdPD6QpzLoRAGmT6ul3+/jujfX8ue7XuXoyrXMqfAR8rsxbehLF3hl2OaFnI5a18TM6opSWFIRdCfShHIj/OysVmZXh1GBb6wcxHT7CThUwj4fc48+nBUbN7Pqic0sWtHF4koPtUEvmqYylDN5LWbwctZJsbKB1lnVOBQFIRSGs3lywwPccVozRzZOXVClqaNFNaOUECHAkiXfbWf48IxyVg9k+FVbluqgB1UIZs9p5bGVcW564GWuCPqJ1E7b65f/HZCdoFTECFZjI8add+LUtElEdUVRSr1ytj9WCAqpNP2z5lD1pz/idLn2gEAlObbax6Mbhxi2NJxTNGTSNRU1HGb56k3M0zM0N1Sh6U6EUOiJZ3m2v0DApaOpKpqmMpBMs0jLcPGxLbCb/J1C0eChzjQBt7sUG1cUYpkSM/JbJ7ag6btXdqoqCmc1BhhKp1jVl0OoDpyqgt/jpqyumlioktUZJ08MSB7rM3lsWPC8EWAo0kDN9BlUhQOoQiFr2XQPxVjgzPO7s1qZURFCAq0RL4vDKs9tSdCTB5cucDkcRMujOGvqaXeEWJF08NQwLI+rrDT8DEYaKJ8+g6ryCJqiYNiSzpEkVWaaXy9r4sSddIBI5w3ueieGw+NBAfKmhRIb4LPzqvCHds4yPrraxwudI7TnBG5NwaGqeKJRHn+jnWlmjNkN5Thcnr1ShAPamt1z3HEkPv4xrN//HnW7F2ZMpfsCCYbJgKoQuP1WPKE9b9zld+lce0w1/+eJXgw9wHh+pJQlzkplMEhi9gKuXv4SrbVR5ixZgqbpnDotwH+904OBDyFtbAmxkQRnzo/AHtRLH1/vJ/zqMFkTHEopwtUfi/Gp+gAu755RojVN44fHN3FM9RA/eyPO+gS4nDo+p4P6inLqKsqxpD3a3hA0oZb4VbZNLGuSzuYoUwpcNtfPVw5vQB01PbdOlePrI9wX8XDj6j7u68wwhI7fpeHzuAg11iObGsbC2eooJcawJYl8gVQ2T0QafKnZzaWHzybgmdoM3QaLdNHEzFtoCiQLJl5D4nTtvKRTArqmcf1x1Zz7YCd9lgeXKhAOF9qcJXzzqRXMbGrn+KNDqOqeswEPyE4Ao0UvgJw5k/ydv8EpmVRksj0UBIOpFPJHP6Lyk5/ai7OWHm1NwIXTLvBQZ4aAy8X2KieAUMjPG/Ei8fUbOG56BH8oTIVXZ/mmAXqzBg7bpFgs4k4O8oNls3bjAW+Dz+lgbV+MjbEcHiERVhExMsSVJzVRFdq7twnMjHj4RIufJjekc0WGMllGcgbpgknetMkbFvmiSSpfIJfNohdzzPFZnN/i5Zrjaji5uWIs5Lr9WunRNU6dFuT0WjcBxSCVKzKcyRLPW6TzBvmiQa5gkMkVyeZzOIo5ZnosPjfDzdXH1HH2zEqcjl2vp5Zlsa4vTo1Hpc4pqdIt5nvh3MOmo+xkl90qb9jtZLoXkukss/wKzR7JkkovFT4nIWmzdE7jXt3bA/4eYxuIXXgB/l/ehmOq1ydtFURRyMZiDHzkI9Tddx/7zu6VfPGRTTw1olLh0yfZnYqikC4WWff081w7V+GiT5yGN1zOcCZPqmihKqUwolPYVAb2vOikaFqlLLRSKqBRpE14D3eBHcOmL1VgQ6xAZ6rAcMGmaNk4FIg4VRp8DqaHXdQGS9Vvez68QUcyz6ZEgf6MTd4skd4CukKVV6XZ76ImtJdj/x3iXXmZd669nfySJYQKBeQUpXICgZnN0FVVTfmqFfiqa2C33eEdoy+V5twHO0nrPvyaMiHLKIRAUQRdQzHyq57lzrOnc/JJx0zq1QklasfkfPQhvF/wrqiyu7ERedFFFLPZqaeSZdFvWfh+eRu+6ppRbsu+TTopocrv40dHVZBNp7GkmOA0SSS2Lakpi5BrXcAVj2yg7e23sMzJbEpBKam0jbJQOvZdWD92G9KW+4Vzb1rWWLLMtmwsc9et07fCtm0M09yt+yKlxJb2mJ9mWxbFYnEKWsuBx7u2n3m+9lUytXWwHZW69FLtFPa/X0b5GaV8wP5YdbfO95Mao1ww01ei546PHGwtWJGSmc0NvOpr4McPvsZIz9S8dcuyKRaLWLaFLW1M08QoGmMPEabOfG4fpp3q8/FjbP9727J3+Pm2f4NpmZimsa19yQ7k2JmMpUlsYFsWEjBtm6JZ3GUIc/zxpmnsciJLWaJa26aFZZaUzrZMLNOYlK3e2XXvL7wr5hCMNnm6/loc3/5/uIMhJDZClGgRvaecQt1jj6DvxQsldgeGZfLpv23mtaxOxD25b5GqKCRyeTY++xw/XuLhc+eehC+8jdpgI1EOmUPvW7xrSgBgZLKkliwh3N4GHi9WPk+XP0hk1QoCu51E2ju0xdN89G9d4PbhVCZv8KqqsqVvCHv1s9z5j7M44fij0UffELPvxtkh/D3jXXXvHV4PyrcupVA0EKbNQD6P65b/OuAKANAc8nHl4VFGkhnkFCl227apqyoj2TyP7z/yNh0b38G2SrW3hxTg/Y13PcblPe88ckuWEEsnMb7+dar+6Z8OWO3o9ji3tYxPNzkYSOUnveNqzD+Y0cyzWjU3P7iaWH/XuyTZIRxMvOtK4NCd8I2v0rdwEdXXXgu8uyvtd4+spdVjkCgYk1Ls0rZxqiozFs7n1i3w1+Wryaf2D133EP5+8a76BFtRyOcxEkl8lVOXKh44lKz71/vjfPLRHtz+AI7tNFCMUoI3dffjee15/vjPS1h8+BJUx+51az6E9x4OSspPd7kOggLA1j1nQWWIf1sUZDiZwRYKUghsSj+WBNOWTKupoLd2Ft9/dD3Jkd1vHHYI7z0cFCX4e3A0Pz+/mrOqFfpHEuQyGQrZbT/5TIpiJk1jYw0PDSn88dm3Dra4h3AAcVDMob8X5A2DtkQehzLaCESMJuqEjZAlfpFpWDhtg/qK8MEW9xAOED7QSnAIhwDvFxrgIRzCPuCQEhzCBx7/H3pBO9LwarY7AAAAAElFTkSuQmCC"/>
                                                                                                                </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                                <td class="aligncenter content-block" style="padding:0 0 30px 20px;background-color: #37b1e4;">
                                                                                                                        <h3 style="font-size:20px;margin:20px 65px;color:#fff;font-weight:500;margin-bottom:20px;">'.$title.'</h3>
                                                                                                                        <span style="color:#fff;font-size:12px;">'.$subtitle.'</span>
                                                                                                                </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                                <td class="alignleft content-block" style="min-height:200px; padding:50px;">'.$message.'</td>
                                                                                                        </tr>
                                                                                                </table>
                                                                                        </td>
                                                                                </tr>
                                                                        </table>
                                                                </div>
                                                        </td>
                                                </tr>
                                                <tr>
                                                        <td>
                                                                <div style="width:100%;padding:18px 0 18px 0;background-color: #37b1e4;">
                                                                        <p style="width:80%;margin-left:10%;color:#fff;font-size:13px;">
                                                                                L\'équipe support de Logiref<br/>
                                                                                ​Powered by <a href="https://ikwook.cd" style="color:#fff;font-size:13px;">iKwook.com</a> - Our solutions are simple, smart and tailored to your needs. This is exactly why many <br/> professionals are using our cloud solutions than ever.
                                                                        </p>
                                                                </div>
                                                                <div class="footer">
                                                                        <table width="100%">
                                                                                <tr>
                                                                                        <td class="aligncenter content-block">Copyright <a href="https://ikwook.cd/">iKwook.cd</a> Express</td>
                                                                                </tr>
                                                                        </table>
                                                                </div>
                                                        </td>
                                                </tr>
                                        </table>

                                </body>
                        </html>
                ';

		return $message;
	}

        public function mail_profile_confirmation($firstname, $username, $password, $admin, $lang='en')
        {
                if($lang=='en')
                {
                        $subject = "Your username and password on the iKwook cloud platform";
                        $title = "Welcome to the iKwook cloud platform";
                        $subtitle = "Please keep this information very confidential.";

                        $message  ='Hi '.addslashes($firstname).',';
                        $message .='<p>A new account has been created for you and please find your credentials below:</p>';
                        $message .='<ul>';
                        $message .='<li>Application link : <a href="http://10.22.2.42"> Application Logiref</a></li>';
                        $message .='<li>User	         : '.$username.'</li>';
                        $message .='<li>Password	 : '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>We really hope you are going to love using iKwook Cloud Platform and that this is the start of a beautiful way of working.';
                        $message .='We\'re excited to have you with us, '.addslashes($firstname).'!.</p>';
                        $message .='<p>Should you require further assistance in this matter, please do not hesitate to contact '.addslashes($admin).'.</p>';
                        $message .='<p>Kind regards,</p>';

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
                }
                else
                {
                        $subject = "Votre identifiant et mot de passe sur la plateforme cloud iKwook";
                        $title = "Bienvenue sur la plateforme cloud iKwook";
                        $subtitle = "Merci de garder ces informations très confidentielles";

                        $message  ='Salut '.addslashes($firstname).',';
                        $message .='<p>Un nouveau compte a été créé pour vous et veuillez trouver vos identifiants ci-dessous:</p>';
                        $message .='<ul>';
                        $message .='<li>Lien application : <a href="http://10.22.2.42"> Application Logiref</a></li>';
                        $message .='<li>Utilisateur	 : '.$username.'</li>';
                        $message .='<li>Mot de passe	 : '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>Nous espérons vraiment que vous allez adorer utiliser iKwook Cloud Platform et que ce sera le début d\'une belle façon de travailler.';
                        $message .='Nous sommes ravis de vous avoir parmi nous, '.addslashes($firstname).'!.</p>';
                        $message .='<p>Si vous avez besoin d\'aide supplémentaire à ce sujet, n\'hésitez pas à contacter '.addslashes($admin).'.</p>';
                        $message .='<p>Cordialement,</p>';

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
                }


        }

        public function mail_bank_profile_confirmation($firstname, $username, $password, $admin, $lang='en')
        {
                if($lang=='en')
                {
                        $subject = "Your username and password on the iKwook netbanking";
                        $title = "Welcome to the iKwook net banking";
                        $subtitle = "Please keep this information very confidential.";

                        $message  ='Hi '.addslashes($firstname).',';
                        $message .='<p>A new account has been created for you and please find your credentials below:</p>';
                        $message .='<ul>';
                        $message .='<li>Application link : <a href="http://localhost/gitlab/logiref/bank4.x/logiref-v4.0.1/branchless"> Application Logiref</a></li>';
                        $message .='<li>User	         : '.$username.'</li>';
                        $message .='<li>Password	 : '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>We really hope you are going to love using iKwook Cloud Platform and that this is the start of a beautiful way of working.';
                        $message .='We\'re excited to have you with us, '.addslashes($firstname).'!.</p>';
                        $message .='<p>Should you require further assistance in this matter, please do not hesitate to contact '.addslashes($admin).'.</p>';
                        $message .='<p>Kind regards,</p>';

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);
                        $from_name = "iKwook Cloud";
                        $from_email = "alain.malengo@ikwook.cd";//no-reply@ikwook.com

                        //$email = \Config\Services::email();
                        /*$this->email->setTo($to);
                        $this->email->setFrom($from_email, $from_name);
                        $this->email->setSubject($subject);
                        $this->email->setMessage($message);

                        # Définition de la méthode d'envoi du mail (HTML par défaut)
                        $this->email->setMailType('html');

                        # Envoyer le mail
                        if ($this->email->send($to, $subject, $message, $from_email, $from_name, TRUE))
                        {
                                return true;
                        }
                        else
                        {
                                # En cas d'échec de l'envoi du mail, vous pouvez afficher ou enregistrer le message d'erreur
                                echo $this->email->printDebugger(['headers']);
                                return false;
                        }*/

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
                }
                else
                {
                        $subject = "Votre identifiant et mot de passe sur la plateforme Netbanking";
                        $title = "Bienvenue sur la plateforme Net Banking";
                        $subtitle = "Merci de garder ces informations très confidentielles";

                        $message  ='Salut '.addslashes($firstname).',';
                        $message .='<p>Un nouveau compte a été créé pour vous et veuillez trouver vos identifiants ci-dessous:</p>';
                        $message .='<ul>';
                        $message .='<li>Lien application : <a href="http://localhost/gitlab/logiref/bank4.x/logiref-v4.0.1/branchless"> Application Logiref</a></li>';
                        $message .='<li>Utilisateur	 : '.$username.'</li>';
                        $message .='<li>Mot de passe	 : '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>Nous espérons vraiment que vous allez adorer utiliser iKwook Cloud Platform et que ce sera le début d\'une belle façon de travailler.';
                        $message .='Nous sommes ravis de vous avoir parmi nous, '.addslashes($firstname).'!.</p>';
                        $message .='<p>Si vous avez besoin d\'aide supplémentaire à ce sujet, n\'hésitez pas à contacter '.addslashes($admin).'.</p>';
                        $message .='<p>Cordialement,</p>';

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);
                        $from_name = "iKwook Cloud";
                        $from_email = "alain.malengo@ikwook.cd";//no-reply@ikwook.com

                        //$email = \Config\Services::email();
                        /*$this->email->setTo($to);
                        $this->email->setFrom($from_email, $from_name);
                        $this->email->setSubject($subject);
                        $this->email->setMessage($message);

                        # Définition de la méthode d'envoi du mail (HTML par défaut)
                        $this->email->setMailType('html');

                        # Envoyer le mail
                        if ($this->email->send($to, $subject, $message, $from_email, $from_name, TRUE))
                        {
                                return true;
                        }
                        else
                        {
                                # En cas d'échec de l'envoi du mail, vous pouvez afficher ou enregistrer le message d'erreur
                                echo $this->email->printDebugger(['headers']);
                                return false;
                        }*/

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
                }


        }

        public function confirmation_otp_mail($firstname, $username, $otpCode)
        {
                $subject = "Code de sécurité Logiref (".$otpCode.")";
                $title = "Bienvenue sur la plateforme Logiref";
                $subtitle = "Merci de garder ces informations strictement confidentielles.";

                $message  = '<p>Bonjour '.addslashes($firstname).',</p>';
                $message .= '<p>Votre code de vérification (OTP) est le suivant :</p>';
                $message .= '<p>Code OTP : <strong style="color:#fd0f0f;font-size:19px;">'.$otpCode.'</strong></p>';
                $message .= '<p>Ce code est valable pour une durée limitée de 5 minutes. Veuillez l\'utiliser pour finaliser votre authentification.</p>';
                $message .= '<p>Si vous n\'avez pas demandé ce code, veuillez ignorer cet e-mail ou contacter immédiatement votre '.addslashes("IT support").' pour signaler le problème.</p>';
                $message .= '<p>Bien cordialement,</p>';
                $message .= '<p>L\'équipe support de Logiref</p>';

                $to = $username;
                $message = $this->format_mail($title, $subtitle, $message);

                $status = $this->initEmailCurl($subject,$to,$message);

                return $status;

        }

        public function mail_reset_password($firstname, $username, $ref_link, $link='http://10.22.2.42', $lang='en')
        {
               if($lang=='en')
               {
                        $subject = "iKwook password reset";
                        $title = "Password Reset";
                        $subtitle = " Please keep this information very confidential ";
                        $message  ='Dear '.addslashes($firstname).',';
                        $message .='<p>We have received a request to reset your password. If you did not request to change your password, please contact our support team as soon as possible. </p>';
                        $message .='<p><h3>Click the link to change your password:</h3></p>';
                        $message .='<p style="text-align:center;padding:10px;"><a style="text-decoration:none;background:#37b1e4;padding:10px;color:white;opacity:0.85;" href="'.$link.'">'.$ref_link.'</a></p>';
                        $message .='<ul>';
                        $message .='<li>Email   	: '.$username.'</li>';
                        $message .='</ul>';
                        $message .='<p>Should you require further assistance in this matter, please do not hesitate to contact us.</p>';
                        $message .='<p>Kind regards,</p>';
                        $message .="<p>Richard Deseize <br/>| Support Team <br/>| Email: support@ikwook.com<br/>| Phone: +27 10 500 6264<br/></p>";

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
               }
               else
               {
                        $subject = "Réinitialisation du mot de passe iKwook";
                        $title = "Réinitialisation du mot de passe";
                        $subtitle = " Veuillez garder ces informations très confidentielles ";
                        $message  ='Cher(e) '.addslashes($firstname).',';
                        $message .='<p>Nous avons reçu une demande de réinitialisation de votre mot de passe. Si vous n\'avez pas demandé de changement de mot de passe, veuillez contacter notre équipe d\'assistance dès que possible. </p>';
                        $message .='<p><h3>Cliquez sur le lien pour changer votre mot de passe:</h3></p>';
                        $message .='<p style="text-align:center;padding:10px;"><a style="text-decoration:none;background:#37b1e4;padding:10px;color:white;opacity:0.85;" href="'.$link.'">'.$ref_link.'</a></p>';
                        $message .='<ul>';
                        $message .='<li>Email    : '.$username.'</li>';
                        $message .='</ul>';
                        $message .='<p>Si vous avez besoin d\'aide supplémentaire à ce sujet, n\'hésitez pas à nous contacter.</p>';
                        $message .='<p>Cordialement,</p>';
                        $message .="<p>Richard Deseize <br/>| Support Team <br/>| Email: support@ikwook.com<br/>| Phone: +27 10 500 6264<br/></p>";

                        $to = $username;
                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$to,$message);

                        return $status;
                }
	}

        public function mail_reset_password_by_admin($firstname, $username, $password, $lang='en')
        {
                if($lang=='en')
                {
                        $subject = "iKwook password reset";
                        $title = "Password Reset";
                        $subtitle = "Please keep this information very confidential ";
                        $message  ='Dear '.addslashes($firstname).',';
                        $message .='<p>We have received a request to reset your password. If you did not request to change your password, please contact our support team as soon as possible. </p>';
                        $message .='<p><h3>Your password changed:</h3></p>';
                        $message .='<p style="text-align:center;padding:10px;"><a style="text-decoration:none;background:#37b1e4;padding:10px;color:white;opacity:0.85;" href="'.base_url("main/signin").'"> Logiref Application</a></p>';
                        $message .='<ul>';
                        $message .='<li>Username	: '.$username.'</li>';
                        $message .='<li>Password	: '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>Should you require further assistance in this matter, please do not hesitate to contact us.</p>';
                        $message .='<p>Kind regards,</p>';
                        $message .="<p>Richard Deseize <br/>| Support Team <br/>| Email: support@ikwook.com<br/>| Phone: +27 10 500 6264<br/></p>";

                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$username,$message);

                        return $status;
                }
                else
                {
                        $subject = "Réinitialisation du mot de passe iKwook";
                        $title = "Réinitialisation du mot de passe";
                        $subtitle = "Veuillez garder ces informations très confidentielles";
                        $message  ='Cher (chère) '.addslashes($firstname).',';
                        $message .='<p>Nous avons reçu une demande de réinitialisation de votre mot de passe. Si vous n\'avez pas demandé de changement de mot de passe, veuillez contacter notre équipe d\'assistance dès que possible. </p>';
                        $message .='<p><h3>Votre mot de passe a changé:</h3></p>';
                        $message .='<p style="text-align:center;padding:10px;"><a style="text-decoration:none;background:#37b1e4;padding:10px;color:white;opacity:0.85;" href="'.base_url("main/signin").'"> Application Logiref</a></p>';
                        $message .='<ul>';
                        $message .='<li>Utilisateur	: '.$username.'</li>';
                        $message .='<li>Mot de passe	: '.$password.'</li>';
                        $message .='</ul>';
                        $message .='<p>Si vous avez besoin d\'aide supplémentaire à ce sujet, n\'hésitez pas à nous contacter.</p>';
                        $message .='<p>Kind regards,</p>';
                        $message .="<p>Richard Deseize <br/>| Support Team <br/>| Email: support@ikwook.com<br/>| Phone: +27 10 500 6264<br/></p>";

                        $message = $this->format_mail($title, $subtitle, $message);

                        $status = $this->initEmailCurl($subject,$username,$message);

                        return $status;
                }
	}

        public function mail_login_attempt($user_data,$link,$lang="en"){
                if($lang=="en"){
                        $subject="Login Attempt from Another Device or Browser";
                        $title="Login Attempt from Another Device or Browser";
                        $subtitle="";
                        $message="<p>Hello, ".$user_data['firstname']."</p>";
                        $message.="<p>We have detected that you attempted to log into your Logiref account from a different device or browser.</p>";
                        $message.="<p>If this was you, you can now log in using the verification code (OTP) that we've sent to your email address</p>";
                        $message.="<p>Verification Code : <strong style='color:#fd0f0f;font-size:19px;'>".$user_data['otp']."</strong></p>";
                        $message.="<p>To reconnect, please enter the OTP in the app by clicking the button below:</p>";
                        $message.="<a href='".$link."'>Reconnect Now</a>";
                }
                else{
                        $subject="Tentative de connexion depuis un autre appareil ou navigateur";
                        $title="Tentative de connexion depuis un autre appareil ou navigateur";
                        $subtitle="";
                        $message="<p>Bonjour, ".$user_data['firstname']."</p>";
                        $message.="<p>Nous avons détecté que vous avez tenté de vous connecter à votre compte [Nom de l'application] depuis un autre appareil ou un navigateur différent.</p>";
                        $message.="<p>Si cela est bien de votre part, vous pouvez à nouveau vous connecter en utilisant le code de vérification (OTP) suivant, envoyé à votre adresse e-mail </p>";
                        $message.="<br/>";
                        $message.="<p>Code de vérification : <strong style='color:#fd0f0f;font-size:19px;'>".$user_data['otp']."</strong></p>";
                        $message.="<p>Pour vous reconnecter, entrez l'OTP dans l'application en utilisant le bouton ci-dessous :</p>";
                        $message.="<a href='".$link."'>Se reconnecter</a>";
                }

                $to = $user_data['user_mail'];
                $message = $this->format_mail($title, $subtitle, $message);

                $status = $this->initEmailCurl($subject,$to,$message);

                return $status;

        }
}
?>