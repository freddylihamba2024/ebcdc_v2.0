<?php

namespace App\Libraries;

use App\Libraries\ExternalAuth\ExternalAuthInterface;
use App\Libraries\ExternalAuth\GatewayDriver;
use App\Libraries\ExternalAuth\LdapDriver;

class ExternalAuthFactory
{
    public static function create(string $driver, array $config): ExternalAuthInterface
    {
        $normalized = strtolower(trim($driver));

        if ($normalized === 'ldap' || $normalized === 'ldaps') {
            $config['driver'] = $normalized;
            return new LdapDriver($config);
        }

        if ($normalized === 'gateway') {
            $config['driver'] = 'gateway';
            return new GatewayDriver($config);
        }

        throw new \InvalidArgumentException('Unsupported external auth driver: ' . $driver);
    }
}
