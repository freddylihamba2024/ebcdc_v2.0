<?php
namespace App\Libraries;

/** Optional Oracle exchange-rate persistence and confirmation. */
class OracleRateConfirmation
{
    public const OPTION = 'oracle-rate-save-confirmation';
    public const LABEL = 'Fiabiliser la confirmation des taux enregistrés avec Oracle';

    public static function enabled(string $driver, array $userdata, $accountId): bool
    {
        if ($driver !== 'OCI8' || (string) ($userdata['account_id'] ?? '') !== (string) $accountId || (string) $accountId === '') {
            return false;
        }
        $options = json_decode($userdata['options'] ?? '', true);
        $value = $options['ALL'][self::OPTION] ?? false;
        return in_array($value, [self::LABEL, true, 1, '1'], true);
    }

}
