<?php

namespace App\Libraries;

use App\Models\Mail_Model;
use Modules\Logs\Models\PaymentIssuesModel;

class MailLib
{
    private Infobip $infobip;
    private Mail_Model $mailModel;
    private object $config;

    public function __construct()
    {
        $this->infobip = new Infobip();
        $this->mailModel = new Mail_Model();
        $this->config = config('Infobip');
    }

    public function send_proof(array $payload): array
    {
        $channel = strtolower((string) ($payload['channel'] ?? 'passport'));
        $to = trim((string) ($payload['to'] ?? ''));
        $attachmentPath = (string) ($payload['attachment_path'] ?? '');

        if ($to === '') {
            return $this->failure('Missing recipient email address.');
        }

        if ($attachmentPath === '' || !is_file($attachmentPath) || !is_readable($attachmentPath)) {
            return $this->failure('Missing or unreadable attachment file.');
        }

        $mailContext = $this->build_proof_context($channel, $payload);
        $sendResult = $this->infobip->send_email(
            $mailContext['from'],
            [$to],
            $mailContext['subject'],
            strip_tags($mailContext['html']),
            $mailContext['html'],
            [$attachmentPath],
            [],
            $mailContext['bcc']
        );

        $ok = (bool) ($sendResult['ok'] ?? false);
        $logId = $this->mailModel->insert_email_log([
            'Module_1' => $payload['module'] ?? strtoupper('LOGIREF_' . $channel . '_PROOF'),
            'Reference_2' => $payload['reference'] ?? ($payload['note_reference'] ?? null),
            'RecipientEmail_3' => $to,
            'Subject_4' => $mailContext['subject'],
            'Message_5' => $mailContext['html'],
            'Provider_6' => 'INFOBIP',
            'ProviderMessageId_7' => $sendResult['messageId'] ?? null,
            'Status_8' => $ok ? 'SENT' : 'FAILED',
            'ErrorMessage_9' => $sendResult['error'] ?? null,
            'ResponsePayload_10' => $sendResult,
            'SentAt_11' => $ok ? date('Y-m-d H:i:s') : null,
            'PaymentId_14' => $payload['payment_id'] ?? null,
            'NoteNumbers_15' => $payload['note_reference'] ?? null,
            'AttachmentPath_16' => $attachmentPath,
        ]);

        $tracking = null;
        $immediateTracking = null;
        $autoTrack = !array_key_exists('auto_track', $payload) || (bool) $payload['auto_track'];

        if ($ok && $autoTrack && !empty($sendResult['messageId'])) {
            $immediateTracking = $this->track_delivery_immediately(
                (string) $sendResult['messageId'],
                $to
            );

            if (empty($immediateTracking['matched'])) {
                $tracking = $this->infobip->launch_delivery_tracking_worker(
                    (string) $sendResult['messageId'],
                    [],
                    [
                        'intervalSeconds' => (int) ($this->config->trackingIntervalSeconds ?? 15),
                        'maxLoops' => (int) ($this->config->trackingMaxLoops ?? 0),
                        'stopWhenFound' => (bool) ($this->config->trackingStopWhenFound ?? true),
                    ]
                );
            }
        }

        return [
            'ok' => $ok,
            'channel' => $channel,
            'subject' => $mailContext['subject'],
            'logId' => $logId,
            'send' => $sendResult,
            'immediateTracking' => $immediateTracking,
            'tracking' => $tracking,
        ];
    }

    public function send_support_notice(array $payload): array
    {
        $to = $this->resolve_support_alert_emails();
        if ($to === []) {
            return $this->failure('Missing support recipients.');
        }

        $subject = trim((string) ($payload['subject'] ?? 'Alerte support Logiref'));
        $html = (string) ($payload['html'] ?? '<p>Alerte support Logiref</p>');
        $text = trim((string) ($payload['text'] ?? strip_tags($html)));
        $module = trim((string) ($payload['module'] ?? 'LOGIREF_SUPPORT_NOTICE'));
        $reference = trim((string) ($payload['reference'] ?? ''));

        $sendResult = $this->infobip->send_email(
            (string) ($payload['from'] ?? $this->config->passportFrom ?? $this->config->defaultFrom),
            $to,
            $subject,
            $text,
            $this->build_equity_mail_wrapper($html)
        );

        $ok = (bool) ($sendResult['ok'] ?? false);
        $logId = $this->mailModel->insert_email_log([
            'Module_1' => $module,
            'Reference_2' => $reference !== '' ? $reference : null,
            'RecipientEmail_3' => implode(', ', $to),
            'Subject_4' => $subject,
            'Message_5' => $html,
            'Provider_6' => 'INFOBIP',
            'ProviderMessageId_7' => $sendResult['messageId'] ?? null,
            'Status_8' => $ok ? 'SENT' : 'FAILED',
            'ErrorMessage_9' => $sendResult['error'] ?? null,
            'ResponsePayload_10' => $sendResult,
            'SentAt_11' => $ok ? date('Y-m-d H:i:s') : null,
            'PaymentId_14' => $payload['payment_id'] ?? null,
            'NoteNumbers_15' => $payload['note_reference'] ?? null,
            'AttachmentPath_16' => null,
        ]);

        return [
            'ok' => $ok,
            'logId' => $logId,
            'send' => $sendResult,
        ];
    }

    public function resend_logged_mail(array $mail_log): array
    {
        $recipient = trim((string) ($mail_log['RecipientEmail_3'] ?? ''));
        $subject = trim((string) ($mail_log['Subject_4'] ?? ''));
        $html = (string) ($mail_log['Message_5'] ?? '');
        $attachment_path = (string) ($mail_log['AttachmentPath_16'] ?? '');
        $status = strtoupper(trim((string) ($mail_log['Status_8'] ?? '')));

        if ($recipient === '' || $subject === '') {
            return $this->failure('Missing recipient or subject for resend.');
        }

        if (!in_array($status, ['FAILED', 'UNDELIVERED'], true)) {
            return $this->failure('Only FAILED or UNDELIVERED mails can be resent.');
        }

        if ($attachment_path === '' || !is_file($attachment_path) || !is_readable($attachment_path)) {
            return $this->failure('Missing or unreadable attachment file.');
        }

        $channel = $this->resolve_logged_mail_channel($mail_log);
        $from = $channel === 'cashcloud'
            ? (string) ($this->config->cashcloudFrom ?? $this->config->defaultFrom)
            : (string) ($this->config->passportFrom ?? $this->config->defaultFrom);
        $bcc = $channel === 'cashcloud'
            ? ($this->config->cashcloudBccSuccess ?? [])
            : ($this->config->passportBccSuccess ?? []);

        $send_result = $this->infobip->send_email(
            $from,
            [$recipient],
            $subject,
            strip_tags($html),
            $html,
            [$attachment_path],
            [],
            is_array($bcc) ? $bcc : []
        );

        $ok = (bool) ($send_result['ok'] ?? false);
        $log_id = $this->mailModel->insert_email_log([
            'Module_1' => $this->build_resend_module_name((string) ($mail_log['Module_1'] ?? 'LOGIREF_MAIL')),
            'Reference_2' => $mail_log['Reference_2'] ?? null,
            'RecipientEmail_3' => $recipient,
            'Subject_4' => $subject,
            'Message_5' => $html,
            'Provider_6' => 'INFOBIP',
            'ProviderMessageId_7' => $send_result['messageId'] ?? null,
            'Status_8' => $ok ? 'SENT' : 'FAILED',
            'ErrorMessage_9' => $send_result['error'] ?? null,
            'ResponsePayload_10' => $send_result,
            'SentAt_11' => $ok ? date('Y-m-d H:i:s') : null,
            'PaymentId_14' => $mail_log['PaymentId_14'] ?? null,
            'NoteNumbers_15' => $mail_log['NoteNumbers_15'] ?? null,
            'AttachmentPath_16' => $attachment_path,
        ]);

        $tracking = null;
        $immediate_tracking = null;

        if ($ok && !empty($send_result['messageId'])) {
            $immediate_tracking = $this->track_delivery_immediately(
                (string) $send_result['messageId'],
                $recipient
            );

            if (empty($immediate_tracking['matched'])) {
                $tracking = $this->infobip->launch_delivery_tracking_worker(
                    (string) $send_result['messageId'],
                    [],
                    [
                        'intervalSeconds' => (int) ($this->config->trackingIntervalSeconds ?? 15),
                        'maxLoops' => (int) ($this->config->trackingMaxLoops ?? 0),
                        'stopWhenFound' => (bool) ($this->config->trackingStopWhenFound ?? true),
                    ]
                );
            }
        }

        return [
            'ok' => $ok,
            'channel' => $channel,
            'subject' => $subject,
            'logId' => $log_id,
            'send' => $send_result,
            'immediateTracking' => $immediate_tracking,
            'tracking' => $tracking,
        ];
    }

    public function notify_support_about_delivery(array $mailLog, array $report, string $status): array
    {
        $status = strtoupper(trim($status));
        $recipient = (string) ($mailLog['RecipientEmail_3'] ?? '');
        $reference = (string) ($mailLog['Reference_2'] ?? '');
        $messageId = (string) ($mailLog['ProviderMessageId_7'] ?? '');
        $providerDescription = (string) ($report['status']['description'] ?? '');
        $providerError = (string) ($report['error']['description'] ?? '');

        $subject = match ($status) {
            'DELIVERED' => '[MAIL DELIVERED] Proof passport remis au destinataire',
            'UNDELIVERED' => '[MAIL UNDELIVERED] Proof passport non remis au destinataire',
            default => '[MAIL FAILED] Proof passport en erreur de livraison',
        };

        $headline = match ($status) {
            'DELIVERED' => 'Le mail de preuve de paiement est bien arrive a destination.',
            'UNDELIVERED' => 'Le mail de preuve de paiement n est pas arrive au destinataire.',
            default => 'Le mail de preuve de paiement a echoue lors de la remise.',
        };

        $html = '<div class="section">'
            . '<p>' . esc($headline) . '</p>'
            . '<ul style="padding-left:20px;">'
            . '<li><strong>Destinataire :</strong> ' . esc($recipient) . '</li>'
            . ($reference !== '' ? '<li><strong>Reference :</strong> ' . esc($reference) . '</li>' : '')
            . ($messageId !== '' ? '<li><strong>Message ID Infobip :</strong> ' . esc($messageId) . '</li>' : '')
            . '<li><strong>Statut Logiref :</strong> ' . esc($status) . '</li>'
            . ($providerDescription !== '' ? '<li><strong>Statut fournisseur :</strong> ' . esc($providerDescription) . '</li>' : '')
            . ($providerError !== '' ? '<li><strong>Erreur fournisseur :</strong> ' . esc($providerError) . '</li>' : '')
            . '</ul>'
            . '</div>';

        return $this->send_support_notice([
            'subject' => $subject,
            'html' => $html,
            'module' => 'LOGIREF_SUPPORT_MAIL_STATUS',
            'reference' => $reference,
            'payment_id' => $mailLog['PaymentId_14'] ?? null,
            'note_reference' => $mailLog['NoteNumbers_15'] ?? null,
        ]);
    }

    public function notify_support_about_payment_issue(array $context): array
    {
        $stage = trim((string) ($context['stage'] ?? 'payment_issue'));
        $message = trim((string) ($context['message'] ?? 'Une erreur est survenue pendant le paiement.'));
        $payment = $context['payment'] ?? null;
        $payload = is_array($context['payload'] ?? null) ? $context['payload'] : [];
        $details = is_array($context['details'] ?? null) ? $context['details'] : [];

        $reference = '';
        $paymentId = null;
        $noteReference = '';
        $customerEmail = '';
        $customerName = '';

        if (is_object($payment)) {
            $reference = (string) ($payment->Logirefid_4 ?? '');
            $paymentId = $payment->Id_0 ?? null;
            $noteReference = (string) ($payment->Noteid_26 ?? '');
            $customerEmail = (string) ($payment->Email_54 ?? '');
            $customerName = (string) ($payment->Designation_14 ?? '');
        }

        $subject = '[PAYMENT ISSUE][' . strtoupper($stage) . '] Echec lors du paiement passport';
        $html = '<div class="section">'
            . '<p>Une erreur est survenue lors du paiement passport et le support doit intervenir.</p>'
            . '<ul style="padding-left:20px;">'
            . '<li><strong>Etape :</strong> ' . esc($stage) . '</li>'
            . '<li><strong>Message :</strong> ' . esc($message) . '</li>'
            . ($reference !== '' ? '<li><strong>Logiref ID :</strong> ' . esc($reference) . '</li>' : '')
            . ($noteReference !== '' ? '<li><strong>Reference note :</strong> ' . esc($noteReference) . '</li>' : '')
            . ($customerName !== '' ? '<li><strong>Client :</strong> ' . esc($customerName) . '</li>' : '')
            . ($customerEmail !== '' ? '<li><strong>Email client :</strong> ' . esc($customerEmail) . '</li>' : '')
            . (!empty($payload['payment_mode']) ? '<li><strong>Mode de paiement :</strong> ' . esc((string) $payload['payment_mode']) . '</li>' : '')
            . (!empty($payload['reference']) ? '<li><strong>Reference transaction :</strong> ' . esc((string) $payload['reference']) . '</li>' : '')
            . '</ul>'
            . '</div>';

        if ($details !== []) {
            $html .= '<div class="section"><p class="highlight">Details techniques</p><pre style="white-space:pre-wrap;">'
                . esc(json_encode($details, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '')
                . '</pre></div>';
        }

        $supportNotice = $this->send_support_notice([
            'subject' => $subject,
            'html' => $html,
            'module' => 'LOGIREF_SUPPORT_PAYMENT_ISSUE',
            'reference' => $reference,
            'payment_id' => $paymentId,
            'note_reference' => $noteReference,
        ]);

        $issueId = $this->create_payment_issue_record(
            $stage,
            $message,
            $subject,
            $payment,
            $payload,
            $details,
            $supportNotice
        );

        $supportNotice['issueId'] = $issueId;

        return $supportNotice;
    }

    private function track_delivery_immediately(string $messageId, string $recipientEmail): array
    {
        $attempts = max(1, (int) ($this->config->trackingImmediateAttempts ?? 3));
        $delayMs = max(0, (int) ($this->config->trackingImmediateDelayMs ?? 1000));
        $recipientEmail = strtolower(trim($recipientEmail));
        $history = [];

        for ($attempt = 1; $attempt <= $attempts; $attempt++) {
            $result = $this->infobip->get_email_delivery_reports(['messageId' => $messageId]);
            $reports = $this->infobip->extract_reports($result['json'] ?? null);
            $matched = null;

            foreach ($reports as $report) {
                $reportRecipient = strtolower(trim((string) ($report['to'] ?? '')));
                if ($reportRecipient !== $recipientEmail) {
                    continue;
                }

                $status = $this->infobip->normalize_delivery_status($report);
                $errorMessage = $report['error']['description'] ?? null;
                $updated = $this->mailModel->update_email_status_by_provider_message_id(
                    $messageId,
                    $status,
                    $report,
                    $errorMessage,
                    $reportRecipient
                );

                $matched = [
                    'status' => $status,
                    'updated' => $updated,
                    'report' => $report,
                ];

                if ($updated && in_array($status, ['UNDELIVERED', 'FAILED'], true)) {
                    $mailLog = $this->mailModel->get_email_log_by_provider_message_id_and_recipient(
                        $messageId,
                        $reportRecipient
                    );

                    if (is_array($mailLog)) {
                        $this->notify_support_about_delivery($mailLog, $report, $status);
                    }
                }
                break;
            }

            $history[] = [
                'attempt' => $attempt,
                'apiUrl' => $result['url'] ?? null,
                'ok' => $result['ok'] ?? false,
                'httpCode' => $result['httpCode'] ?? null,
                'error' => $result['error'] ?? null,
                'raw' => $result['raw'] ?? null,
                'matched' => $matched,
            ];

            if ($matched !== null) {
                return [
                    'matched' => true,
                    'attempts' => $attempt,
                    'history' => $history,
                ];
            }

            if ($attempt < $attempts && $delayMs > 0) {
                usleep($delayMs * 1000);
            }
        }

        return [
            'matched' => false,
            'attempts' => $attempts,
            'history' => $history,
        ];
    }

    private function build_proof_context(string $channel, array $payload): array
    {
        $customer = trim((string) ($payload['customer_name'] ?? 'Client'));
        $currency = trim((string) ($payload['currency'] ?? 'USD'));
        $amount = number_format((float) ($payload['amount'] ?? 0), 2, ',', ' ');
        $date = (string) ($payload['date'] ?? date('d/m/Y'));
        $noteReference = trim((string) ($payload['note_reference'] ?? ''));

        if ($channel === 'cashcloud') {
            $subject = (string) ($payload['subject'] ?? 'Votre preuve de paiement CashCloud');
            $html = $this->build_cashcloud_html($customer, $currency, $amount, $date, $noteReference, $payload);

            return [
                'from' => (string) ($payload['from'] ?? $this->config->cashcloudFrom),
                'bcc' => $this->resolve_bcc($payload, 'cashcloud'),
                'subject' => $subject,
                'html' => $html,
            ];
        }

        $subject = (string) ($payload['subject'] ?? 'Votre attestation de paiement passeport (TEST VERSION)');
        $html = $this->build_passport_html($customer, $currency, $amount, $date, $noteReference, $payload);

        return [
            'from' => (string) ($payload['from'] ?? $this->config->passportFrom),
            'bcc' => $this->resolve_bcc($payload, 'passport'),
            'subject' => $subject,
            'html' => $html,
        ];
    }

    private function resolve_bcc(array $payload, string $channel): array
    {
        if (!empty($payload['bcc']) && is_array($payload['bcc'])) {
            return $payload['bcc'];
        }

        if ($channel === 'cashcloud') {
            return !empty($payload['delivery_context']) && $payload['delivery_context'] === 'error'
                ? $this->config->cashcloudBccError
                : $this->config->cashcloudBccSuccess;
        }

        return !empty($payload['delivery_context']) && $payload['delivery_context'] === 'error'
            ? $this->config->passportBccError
            : $this->config->passportBccSuccess;
    }

    private function build_passport_html(
        string $customer,
        string $currency,
        string $amount,
        string $date,
        string $noteReference,
        array $payload = []
    ): string {
        $beneficiary = (string) ($payload['beneficiary'] ?? 'DGRAD');
        $mode = strtolower((string) ($payload['mode'] ?? $payload['payment_mode'] ?? ''));
        $commission = (float) ($payload['commission'] ?? 0);
        $commissionInLetter = trim((string) ($payload['commission_in_letter'] ?? ''));
        $amountInLetter = trim((string) ($payload['amount_in_letter'] ?? ''));
        $channelText = 'effectué via nos services en ligne.';

        if ($mode === 'agencybanking') {
            $channelText = 'effectué via nos Agents bancaires.';
        } elseif ($mode === 'agency' || $mode === 'branch') {
            $channelText = 'effectué via notre réseau d’agences.';
        }

        if ($amountInLetter === '') {
            $amountInLetter = $this->number_to_words_fr((float) str_replace(',', '.', str_replace(' ', '', $amount)));
        }

        if ($commission > 0 && $commissionInLetter === '') {
            $commissionInLetter = $this->number_to_words_fr($commission);
        }

        $commissionLine = '';
        if ($commission > 0) {
            $formattedCommission = number_format($commission, 2, ',', ' ');
            $commissionLine = '<li><strong>Commission + TVA :</strong> '
                . esc($formattedCommission) . ' ' . esc($currency);

            if ($commissionInLetter !== '') {
                $commissionLine .= ' (' . esc(trim($commissionInLetter)) . ')';
            }

            $commissionLine .= '</li>';
        }

        return $this->build_equity_mail_wrapper(
            '<div class="section">'
            . '<p>Madame, Monsieur,</p>'
            . '<p>Nous vous confirmons le règlement des frais de passeport pour le compte de la DGRAD ' . esc($channelText) . '</p>'
            . '</div>'
            . '<div class="section">'
            . '<p class="highlight">Détails de la transaction :</p>'
            . '<ul style="padding-left: 20px;">'
            . '<li><strong>Date :</strong> ' . esc($date) . '</li>'
            . '<li><strong>Montant :</strong> ' . esc($amount) . ' ' . esc($currency) . ($amountInLetter !== '' ? ' (' . esc(trim($amountInLetter)) . ')' : '') . '</li>'
            . $commissionLine
            . '<li><strong>Client :</strong> ' . esc($customer) . '</li>'
            . '<li><strong>Bénéficiaire :</strong> ' . esc($beneficiary) . '</li>'
            . ($noteReference !== '' ? '<li><strong>Référence :</strong> ' . esc($noteReference) . '</li>' : '')
            . '</ul>'
            . '</div>'
            . '<div class="section">'
            . '<p>Veuillez trouver votre attestation de paiement en pièce jointe à cet e-mail.</p>'
            . '<p>Equity BCDC agit en qualité d’intermédiaire pour le compte de la DGRAD dans la collecte de ces frais.</p>'
            . '</div>'
        );
    }

    private function build_cashcloud_html(
        string $customer,
        string $currency,
        string $amount,
        string $date,
        string $noteReference,
        array $payload = []
    ): string {
        $beneficiary = (string) ($payload['beneficiary'] ?? 'Guichet Unique DGDA');
        $proofLabel = (string) ($payload['proof_label'] ?? 'quittance');
        $operationLabel = (string) ($payload['operation_label'] ?? 'bulletin de liquidation');
        $channelText = (string) ($payload['channel_text'] ?? 'effectué via nos services en ligne.');

        return $this->build_equity_mail_wrapper(
            '<div class="section">'
            . '<p>Madame, Monsieur,</p>'
            . '<p>Nous vous confirmons le règlement de votre ' . esc($operationLabel) . ' pour le compte du ' . esc($beneficiary) . ' ' . esc($channelText) . '</p>'
            . '</div>'
            . '<div class="section">'
            . '<p class="highlight">Détails de la transaction :</p>'
            . '<ul style="padding-left: 20px;">'
            . '<li><strong>Date :</strong> ' . esc($date) . '</li>'
            . '<li><strong>Montant :</strong> ' . esc($amount) . ' ' . esc($currency) . '</li>'
            . '<li><strong>Client :</strong> ' . esc($customer) . '</li>'
            . '<li><strong>Bénéficiaire :</strong> ' . esc($beneficiary) . '</li>'
            . ($noteReference !== '' ? '<li><strong>Référence :</strong> ' . esc($noteReference) . '</li>' : '')
            . '</ul>'
            . '</div>'
            . '<div class="section">'
            . '<p>Veuillez trouver votre ' . esc($proofLabel) . ' comme preuve de paiement en pièce jointe à cet e-mail.</p>'
            . '</div>'
        );
    }

    private function build_equity_mail_wrapper(string $content): string
    {
        return '<!DOCTYPE html>'
            . '<html>'
            . '<head>'
            . '<meta charset="UTF-8">'
            . '<style>'
            . 'body{font-family:Arial,sans-serif;font-size:14px;color:#333;line-height:1.6;margin:0;padding:0;}'
            . '.container{padding:20px;max-width:600px;margin:auto;background-color:#ffffff;border:1px solid #ddd;}'
            . '.section{margin-bottom:20px;}'
            . '.footer{font-size:12px;color:#777;}'
            . '.highlight{font-weight:bold;}'
            . 'a{color:#0066cc;text-decoration:none;}'
            . '</style>'
            . '</head>'
            . '<body>'
            . '<div class="container">'
            . $content
            . '<div class="section">'
            . '<hr>'
            . '<p class="highlight">Besoin d’aide ?</p>'
            . '<p>'
            . '<a href="mailto:mail@equitybcdc.cd">mail@equitybcdc.cd</a><br>'
            . '+243 818 302 700 / Infoline : 41909<br>'
            . '<a href="https://equity.custhelp.com/">https://equity.custhelp.com/</a>'
            . '</p>'
            . '</div>'
            . '<div class="section">'
            . '<p class="highlight">Signaler une activité suspecte ?</p>'
            . '<p>'
            . '+243 818 302 700 / Infoline : 41909<br>'
            . '<a href="mailto:whistleblowing@equitygroupholdings.com">whistleblowing@equitygroupholdings.com</a>'
            . '</p>'
            . '</div>'
            . '<div class="section">'
            . '<p>Cordialement,<br>L’équipe Equity BCDC<br><em>Votre partenaire bancaire de référence</em></p>'
            . '</div>'
            . '<div class="footer">'
            . '<p><strong>Equity Banque Commerciale du Congo</strong><br>'
            . 'Siège social : 15, Boulevard du 30 Juin, Gombe, Kinshasa<br>'
            . '<a href="https://www.equitygroupholdings.com/cd/">www.equitygroupholdings.com/cd/</a></p>'
            . '<p>Ce message est confidentiel. En cas de réception par erreur, merci de le supprimer.</p>'
            . '</div>'
            . '</div>'
            . '</body>'
            . '</html>';
    }

    private function number_to_words_fr(float $number): string
    {
        $units = [
            0 => 'zero', 1 => 'un', 2 => 'deux', 3 => 'trois', 4 => 'quatre', 5 => 'cinq',
            6 => 'six', 7 => 'sept', 8 => 'huit', 9 => 'neuf', 10 => 'dix', 11 => 'onze',
            12 => 'douze', 13 => 'treize', 14 => 'quatorze', 15 => 'quinze', 16 => 'seize',
            17 => 'dix-sept', 18 => 'dix-huit', 19 => 'dix-neuf',
        ];
        $tens = [
            20 => 'vingt', 30 => 'trente', 40 => 'quarante', 50 => 'cinquante',
            60 => 'soixante',
        ];

        $integer = (int) round($number, 0);
        if ($integer < 20) {
            return $units[$integer] ?? (string) $integer;
        }

        if ($integer < 70) {
            $ten = ((int) floor($integer / 10)) * 10;
            $unit = $integer % 10;
            return $tens[$ten] . ($unit > 0 ? '-' . ($units[$unit] ?? (string) $unit) : '');
        }

        if ($integer < 80) {
            return 'soixante-' . $this->number_to_words_fr($integer - 60);
        }

        if ($integer < 100) {
            return 'quatre-vingt' . ($integer === 80 ? '' : '-' . $this->number_to_words_fr($integer - 80));
        }

        return (string) $integer;
    }

    private function failure(string $message): array
    {
        return [
            'ok' => false,
            'logId' => null,
            'send' => null,
            'tracking' => null,
            'message' => $message,
        ];
    }

    private function resolve_support_alert_emails(): array
    {
        $emails = $this->config->supportAlertEmails ?? [];
        return array_values(array_filter(array_map(
            static fn ($email) => trim((string) $email),
            is_array($emails) ? $emails : [$emails]
        ), static fn ($email) => $email !== ''));
    }

    private function create_payment_issue_record(
        string $stage,
        string $message,
        string $subject,
        $payment,
        array $payload,
        array $details,
        array $supportNotice
    ): ?int {
        try {
            $reference = '';
            $paymentId = null;
            $noteReference = '';
            $customerEmail = '';
            $customerName = '';

            if (is_object($payment)) {
                $reference = (string) ($payment->Logirefid_4 ?? '');
                $paymentId = $payment->Id_0 ?? null;
                $noteReference = (string) ($payment->Noteid_26 ?? '');
                $customerEmail = (string) ($payment->Email_54 ?? '');
                $customerName = (string) ($payment->Designation_14 ?? '');
            }

            $tracker = new PaymentIssuesModel();

            $issueId = $tracker->create_issue([
                'Channel_2' => 'passport',
                'Module_3' => 'LOGIREF_PASSPORT_PAYMENT',
                'Stage_4' => $stage,
                'Severity_5' => 'HIGH',
                'Status_6' => 'OPEN',
                'Title_7' => $subject,
                'Description_8' => $message,
                'Reference_9' => $reference,
                'PaymentId_10' => $paymentId,
                'NoteReference_11' => $noteReference,
                'CustomerEmail_12' => $customerEmail,
                'CustomerName_13' => $customerName,
                'PaymentMode_14' => (string) ($payload['payment_mode'] ?? ''),
                'TransactionReference_15' => (string) ($payload['reference'] ?? ''),
                'ContextPayload_16' => [
                    'payload' => $payload,
                    'details' => $details,
                ],
                'SupportNoticeStatus_17' => !empty($supportNotice['ok']) ? 'SENT' : 'FAILED',
                'SupportNoticeLogId_18' => $supportNotice['logId'] ?? null,
                'SupportNoticeMessageId_19' => $supportNotice['send']['messageId'] ?? null,
            ]);

            return is_int($issueId) ? $issueId : null;
        } catch (\Throwable $exception) {
            return null;
        }
    }

    private function resolve_logged_mail_channel(array $mail_log): string
    {
        $module = strtoupper(trim((string) ($mail_log['Module_1'] ?? '')));
        $subject = strtoupper(trim((string) ($mail_log['Subject_4'] ?? '')));

        if (str_contains($module, 'CASHCLOUD') || str_contains($subject, 'CASHCLOUD')) {
            return 'cashcloud';
        }

        return 'passport';
    }

    private function build_resend_module_name(string $module): string
    {
        $module = trim($module);
        if ($module === '') {
            return 'LOGIREF_MAIL_RESEND';
        }

        return str_ends_with($module, '_RESEND') ? $module : $module . '_RESEND';
    }


    private function build_immatriculation_html(array $payload): string
    {
        $customer = $this->escape((string) ($payload['customer_name'] ?? 'Client'));
        $bankName = $this->escape((string) ($payload['bank_name'] ?? 'Rawbank'));
        $reference = $this->escape((string) ($payload['note_reference'] ?? ''));
        $currency = $this->escape((string) ($payload['currency'] ?? ''));
        $amount = $this->format_amount($payload['amount'] ?? null);
        $commission = $this->format_amount($payload['commission'] ?? null);
        $date = $this->escape((string) ($payload['date'] ?? ''));
        $channel = $this->escape((string) ($payload['payment_channel'] ?? ''));
        $logoSource = $this->resolve_logo_source((string) ($payload['logo_url'] ?? ''));
        $title = $reference !== ''
            ? 'Paiement de la note de perception ' . $reference
            : 'Paiement de la note de perception';

        $detailRows = '';
        $detailRows .= $this->detail_row('Référence de la note', $reference);
        $detailRows .= $this->detail_row('Montant payé', trim($amount . ' ' . $currency));
        if ($commission !== '' && (float) str_replace(',', '.', str_replace(' ', '', $commission)) > 0) {
            $detailRows .= $this->detail_row('Commission', trim($commission . ' ' . $currency));
        }
        $detailRows .= $this->detail_row('Date du paiement', $date);
        $detailRows .= $this->detail_row('Canal de paiement', $channel);

        $logo = $logoSource !== ''
            ? '<img src="' . $this->escape($logoSource) . '" alt="' . $bankName . '" width="230" style="display:block;width:230px;max-width:100%;height:auto;border:0;">'
            : '<div style="font-size:28px;font-weight:700;color:#d71920;letter-spacing:1px;">' . strtoupper($bankName) . '</div>';

        return '<!doctype html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>'
            . '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;color:#252525;">'
            . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#f3f4f6;padding:28px 12px;"><tr><td align="center">'
            . '<table role="presentation" width="640" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;background:#ffffff;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb;">'
            . '<tr><td style="padding:26px 34px;border-top:7px solid #d71920;">' . $logo . '</td></tr>'
            . '<tr><td style="padding:4px 34px 30px;">'
            . '<h1 style="margin:0 0 20px;font-size:24px;line-height:1.3;color:#1f2937;">' . $title . '</h1>'
            . '<p style="margin:0 0 14px;font-size:15px;line-height:1.7;">Bonjour <strong>' . $customer . '</strong>,</p>'
            . '<p style="margin:0 0 22px;font-size:15px;line-height:1.7;">Nous vous confirmons que votre paiement relatif à votre demande de plaques d’immatriculation a été traité avec succès.</p>'
            . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;background:#f8fafc;border-left:4px solid #d71920;">'
            . $detailRows
            . '</table>'
            . '<p style="margin:22px 0 12px;font-size:15px;line-height:1.7;">Votre attestation de paiement est jointe à ce message. Veuillez la conserver comme justificatif.</p>'
            . '<p style="margin:20px 0 0;font-size:15px;line-height:1.7;">Merci d’avoir choisi ' . $bankName . '.</p>'
            . '</td></tr>'
            . '<tr><td style="padding:20px 34px;background:#202124;color:#ffffff;font-size:12px;line-height:1.6;">'
            . '<strong style="color:#ffffff;">' . strtoupper($bankName) . '</strong><br>Ce message automatique concerne exclusivement le paiement de plaques d’immatriculation effectué en ligne. Merci de ne pas y répondre.'
            . '</td></tr></table></td></tr></table></body></html>';
    }


    public function send_immatriculation_payment_proof(array $payload): array
    {
        $to = trim((string) ($payload['to'] ?? ''));
        $attachmentPath = trim((string) ($payload['attachment_path'] ?? ''));

        if (filter_var($to, FILTER_VALIDATE_EMAIL) === false) {
            return $this->immatriculation_failure('Adresse email du demandeur absente ou invalide.');
        }
        if ($attachmentPath === '' || !is_file($attachmentPath) || !is_readable($attachmentPath)) {
            return $this->immatriculation_failure('Attestation de paiement absente ou illisible.');
        }

        $subject = trim((string) ($payload['subject'] ?? 'Confirmation de paiement de vos plaques d’immatriculation'));
        $html = $this->build_immatriculation_html($payload);
        $bcc = isset($payload['bcc']) && is_array($payload['bcc'])
            ? $payload['bcc']
            : (array) ($this->config->immatriculationBcc ?? []);

        $send = $this->infobip->send_email(
            (string) ($payload['from'] ?? $this->config->immatriculationFrom ?? $this->config->defaultFrom),
            [$to],
            $subject,
            $this->html_to_text($html),
            $html,
            [$attachmentPath],
            [],
            $bcc,
            ['fromName' => (string) ($payload['from_name'] ?? $this->config->immatriculationFromName ?? 'Rawbank - Immatriculation')]
        );

        $logId = $this->mailModel->insert_email_log([
            'Module_1' => $payload['module'] ?? 'LOGIREF_IMMATRICULATION_PAYMENT_PROOF',
            'Reference_2' => $payload['note_reference'] ?? null,
            'RecipientEmail_3' => $to,
            'Subject_4' => $subject,
            'Message_5' => $html,
            'Provider_6' => 'INFOBIP',
            'ProviderMessageId_7' => $send['messageId'] ?? null,
            'Status_8' => !empty($send['ok']) ? 'SENT' : 'FAILED',
            'ErrorMessage_9' => $send['error'] ?? null,
            'ResponsePayload_10' => $send,
            'SentAt_11' => !empty($send['ok']) ? date('Y-m-d H:i:s') : null,
            'PaymentId_14' => $payload['payment_id'] ?? null,
            'NoteNumbers_15' => $payload['note_reference'] ?? null,
            'AttachmentPath_16' => $attachmentPath,
        ]);

        $tracking = null;
        $trackingWorker = null;
        if (!empty($send['ok']) && !empty($send['messageId']) && ($payload['auto_track'] ?? true)) {
            $tracking = $this->track_immatriculation_delivery_immediately((string) $send['messageId'], $to);
            if (empty($tracking['matched'])) {
                $trackingWorker = $this->infobip->launch_delivery_tracking_worker(
                    (string) $send['messageId'],
                    ['to' => $to],
                    [
                        'intervalSeconds' => (int) ($this->config->trackingIntervalSeconds ?? 10),
                        'maxLoops' => (int) ($this->config->trackingMaxLoops ?? 30),
                        'stopWhenFound' => true,
                    ]
                );
            }
        }
        $deliveryStatus = strtoupper((string) ($tracking['status'] ?? 'PENDING'));
        $deliveryFailed = in_array($deliveryStatus, ['UNDELIVERED', 'FAILED'], true);
        $ok = (bool) ($send['ok'] ?? false) && !$deliveryFailed;
        $trackingError = $deliveryFailed ? $this->extract_tracking_error($tracking) : null;

        return [
            'ok' => $ok,
            'provider' => 'INFOBIP',
            'subject' => $subject,
            'recipient' => $to,
            'attachmentPath' => $attachmentPath,
            'logId' => $logId,
            'send' => $send,
            'immediateTracking' => $tracking,
            'tracking' => $trackingWorker,
            'message' => $deliveryFailed
                ? 'Email rejeté après acceptation par Infobip : ' . ($trackingError ?? $deliveryStatus)
                : (!empty($send['ok'])
                    ? 'Email accepté par Infobip.'
                    : (string) ($send['error'] ?? 'Échec de l’envoi Infobip.')),
        ];
    }

    public function send_immatriculation_payment_proof_whatsapp(array $payload): array
    {
        $recipient = $this->normalize_whatsapp_number((string) ($payload['to'] ?? ''));
        $sender = preg_replace('/\D+/', '', (string) ($payload['from'] ?? $this->config->whatsappSender ?? ''));
        $template = trim((string) ($payload['template'] ?? $this->config->immatriculationWhatsappTemplate ?? ''));
        $language = trim((string) ($payload['language'] ?? $this->config->immatriculationWhatsappLanguage ?? 'fr'));
        $documentUrl = trim((string) ($payload['document_url'] ?? ''));
        $filename = basename((string) ($payload['filename'] ?? 'attestation-immatriculation.pdf'));

        if ($recipient === null) {
            return $this->whatsapp_failure('Numéro WhatsApp du demandeur absent ou invalide.');
        }
        if ($sender === '' || $template === '') {
            return $this->whatsapp_failure('Expéditeur ou modèle WhatsApp Infobip non configuré.');
        }
        if (filter_var($documentUrl, FILTER_VALIDATE_URL) === false) {
            return $this->whatsapp_failure('URL publique de l’attestation absente ou invalide.');
        }

        $bodyVariables = [];
        $bodyFields = (array) ($payload['body_fields'] ?? $this->config->immatriculationWhatsappBodyFields ?? []);
        foreach ($bodyFields as $field) {
            $bodyVariables[] = (string) ($payload[$field] ?? '');
        }

        $send = $this->infobip->send_whatsapp_document_template(
            $sender,
            $recipient,
            $template,
            $language,
            $documentUrl,
            $filename,
            $bodyVariables
        );
        $ok = (bool) ($send['ok'] ?? false);
        $module = (string) ($payload['module'] ?? 'LOGIREF_IMMATRICULATION_PAYMENT_PROOF_WHATSAPP');
        $reference = (string) ($payload['note_reference'] ?? '');
        $caption = 'Attestation de paiement des plaques d’immatriculation ' . $reference;

        $logId = $this->mailModel->insert_email_log([
            'Module_1' => $module,
            'Reference_2' => $reference !== '' ? $reference : null,
            'RecipientEmail_3' => $recipient,
            'Subject_4' => $caption,
            'Message_5' => $caption,
            'Provider_6' => 'INFOBIP_WHATSAPP',
            'ProviderMessageId_7' => $send['messageId'] ?? null,
            'Status_8' => $ok ? 'SENT' : 'FAILED',
            'ErrorMessage_9' => $send['error'] ?? null,
            'ResponsePayload_10' => $send,
            'SentAt_11' => $ok ? date('Y-m-d H:i:s') : null,
            'PaymentId_14' => $payload['payment_id'] ?? null,
            'NoteNumbers_15' => $reference !== '' ? $reference : null,
            'AttachmentPath_16' => $payload['attachment_path'] ?? null,
        ]);

        return [
            'ok' => $ok,
            'provider' => 'INFOBIP_WHATSAPP',
            'recipient' => $recipient,
            'logId' => $logId,
            'send' => $send,
            'message' => $ok
                ? 'Message WhatsApp accepté par Infobip.'
                : (string) ($send['error'] ?? 'Échec de l’envoi WhatsApp Infobip.'),
        ];
    }

    public function was_delivery_sent(string $module, string $reference, string $recipient): bool
    {
        return $this->mailModel->has_successful_delivery($module, $reference, $recipient);
    }

    public function normalize_whatsapp_recipient(string $number): ?string
    {
        return $this->normalize_whatsapp_number($number);
    }


    private function detail_row(string $label, string $value): string
    {
        if (trim($value) === '') {
            return '';
        }

        return '<tr><td style="padding:10px 14px;font-size:13px;color:#6b7280;border-bottom:1px solid #e5e7eb;width:45%;">'
            . $this->escape($label) . '</td><td style="padding:10px 14px;font-size:14px;font-weight:600;color:#111827;border-bottom:1px solid #e5e7eb;">'
            . $value . '</td></tr>';
    }


    private function extract_tracking_error(array $tracking): ?string
    {
        foreach (array_reverse((array) ($tracking['history'] ?? [])) as $entry) {
            $matched = $entry['matched'] ?? null;
            if (!is_array($matched)) {
                continue;
            }

            $description = $matched['providerError']['description']
                ?? $matched['providerStatus']['description']
                ?? null;
            if (is_string($description) && trim($description) !== '') {
                return trim($description);
            }
        }

        return null;
    }


    private function resolve_logo_source(string $logoUrl): string
    {
        if (filter_var($logoUrl, FILTER_VALIDATE_URL)) {
            return $logoUrl;
        }

        $configuredPath = trim((string) ($this->config->rawbankLogoPath ?? 'ikwook_files/logos/RAWBANK_New_Branding_Logo-01.png'));
        if ($configuredPath === '') {
            return '';
        }

        $logoPath = str_starts_with($configuredPath, DIRECTORY_SEPARATOR)
            ? $configuredPath
            : ROOTPATH . ltrim($configuredPath, '/\\');

        if (!is_file($logoPath) || !is_readable($logoPath)) {
            return '';
        }

        $logoContent = file_get_contents($logoPath);
        if ($logoContent === false) {
            return '';
        }

        $mimeType = function_exists('mime_content_type')
            ? mime_content_type($logoPath)
            : 'image/png';
        if (!is_string($mimeType) || !str_starts_with($mimeType, 'image/')) {
            $mimeType = 'image/png';
        }

        return 'data:' . $mimeType . ';base64,' . base64_encode($logoContent);
    }


    private function format_amount($amount): string
    {
        return $amount === null || $amount === '' ? '' : number_format((float) $amount, 2, ',', ' ');
    }


    private function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }


    private function html_to_text(string $html): string
    {
        return trim(html_entity_decode(strip_tags(str_replace(['</p>', '</tr>', '<br>', '<br/>', '<br />'], "\n", $html)), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }


    private function track_immatriculation_delivery_immediately(string $messageId, string $recipient): array
    {
        $attempts = max(1, (int) ($this->config->trackingImmediateAttempts ?? 3));
        $delayMs = max(0, (int) ($this->config->trackingImmediateDelayMs ?? 1000));
        $history = [];
        $recipient = strtolower(trim($recipient));

        for ($attempt = 1; $attempt <= $attempts; $attempt++) {
            $response = $this->infobip->get_email_delivery_reports(['messageId' => $messageId]);
            $matched = null;

            foreach ($this->infobip->extract_reports($response['json'] ?? null) as $report) {
                if (strtolower(trim((string) ($report['to'] ?? ''))) !== $recipient) {
                    continue;
                }

                $matched = [
                    'status' => $this->infobip->normalize_delivery_status($report),
                    'providerStatus' => $report['status'] ?? null,
                    'providerError' => $report['error'] ?? null,
                    'report' => $report,
                ];

                $this->mailModel->update_email_status_by_provider_message_id(
                    $messageId,
                    $matched['status'],
                    $report,
                    $report['error']['description'] ?? null,
                    $recipient
                );
                break;
            }

            $history[] = [
                'attempt' => $attempt,
                'ok' => (bool) ($response['ok'] ?? false),
                'httpCode' => $response['httpCode'] ?? null,
                'error' => $response['error'] ?? null,
                'matched' => $matched,
            ];

            if ($matched !== null) {
                return ['matched' => true, 'attempts' => $attempt, 'status' => $matched['status'], 'history' => $history];
            }
            if ($attempt < $attempts && $delayMs > 0) {
                usleep($delayMs * 1000);
            }
        }

        return ['matched' => false, 'attempts' => $attempts, 'status' => 'PENDING', 'history' => $history];
    }


    private function immatriculation_failure(string $message): array
    {
        return [
            'ok' => false,
            'provider' => 'INFOBIP',
            'subject' => null,
            'recipient' => null,
            'attachmentPath' => null,
            'logId' => null,
            'send' => ['ok' => false, 'messageId' => null, 'error' => $message],
            'immediateTracking' => null,
            'tracking' => null,
            'message' => $message,
        ];
    }

    private function normalize_whatsapp_number(string $number): ?string
    {
        $number = preg_replace('/\D+/', '', $number);
        if (!is_string($number) || $number === '') {
            return null;
        }

        if (str_starts_with($number, '00')) {
            $number = substr($number, 2);
        }

        $countryCode = preg_replace('/\D+/', '', (string) ($this->config->whatsappDefaultCountryCode ?? '243'));
        if (str_starts_with($number, '0') && $countryCode !== '') {
            $number = $countryCode . ltrim($number, '0');
        } elseif (strlen($number) === 9 && $countryCode !== '') {
            $number = $countryCode . $number;
        }

        return preg_match('/^[1-9]\d{8,14}$/', $number) ? $number : null;
    }

    private function whatsapp_failure(string $message): array
    {
        return [
            'ok' => false,
            'provider' => 'INFOBIP_WHATSAPP',
            'recipient' => null,
            'logId' => null,
            'send' => ['ok' => false, 'messageId' => null, 'error' => $message],
            'message' => $message,
        ];
    }
}
