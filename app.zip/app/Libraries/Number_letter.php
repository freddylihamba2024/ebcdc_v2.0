<?php

namespace App\Libraries;

class Number_letter {
        /*
         * CodeIgniter Library of:
         * Bootstrap form html
         *
         * Thanks to original author!
         *
         * By Papin d'Eve Mpengele
         *
         * Run as:
         * echo $this->formhtml->input($from_time, $to_time);
         *
         */

        function converter($nombre = NULL, $devise = NULL)
        {
                if($nombre !=NULL && $devise !="")
                {
                        $nb1 = Array('un','deux','trois','quatre','cinq','six','sept','huit','neuf','dix','onze','douze','treize','quatorze','quinze','seize','dix-sept','dix-huit','dix-neuf');

                        $nb2 = Array('vingt','trente','quarante','cinquante','soixante','soixante','quatre-vingt','quatre-vingt');

                        # Décomposition du chiffre
                        # Séparation du nombre entier et des décimales
                        if (preg_match("/\b,\b/i", $nombre)){
                            $nombre = explode(',',$nombre);
                        }else{
                            $nombre = explode('.',$nombre);
                        }
                        $nmb = $nmb_million = $nmb_milliard = $nombre[0];
                        
                        $nblet='';
                        
                        $i=2;
                        
                        while(strlen($nmb_milliard)>0){

                            $nbtmp_milliard[$i]=substr($nmb_milliard,-9);

                            if( strlen($nmb_milliard)>9  ){
                                $nmb_milliard =substr($nmb_milliard,0,strlen($nmb_milliard)-9);
                            }else{
                                $nmb_milliard='';
                            }
                            if($i==2)
                            {
                                $nmb_million = $nbtmp_milliard[$i];
                            }
                            $i++;
                        }
                        
                        $i=1;
                        
                        while(strlen($nmb_million)>0){

                            $nbtmp_else[$i]=substr($nmb_million,-6);

                            if( strlen($nmb_million)>6  ){
                                $nmb_million =substr($nmb_million,0,strlen($nmb_million)-6);
                            }else{
                                $nmb_million='';
                            }
                            if($i==1)
                            {
                                $nmb = $nbtmp_else[$i];
                            }
                            $i++;
                        }
                        
                        //var_dump($nmb); die;
                        # Décomposition du nombre entier par tranche de 3 nombre (centaine, dizaine, unitaire)
                        $i=0;
                        while(strlen($nmb)>0){
                            $nbtmp[$i]=substr($nmb,-3);
                            
                            if( strlen($nmb)>3  ){
                                $nmb=substr($nmb,0,strlen($nmb)-3);
                            }else{
                                $nmb='';
                            }
                            $i++;
                        }
                        
                        
                        $nblet='';
                        
                        if($devise == 'CDF')
                        {
                               $nblet.='FRANCS CONGOLAIS ';
                        }
                        elseif($devise == 'EUR') 
                        {
                                if( $nombre[0]>1 )$nblet.='euros ';
                                if( $nombre[0]==1 )$nblet.='euro ';
                        }
                        elseif($devise == 'USD')
                        {
                                $nblet.='DOLLARS AMERICAINS ';
                        }
                        ## Taitement du côté entier
                        for($i=3;$i>=0;$i--)
                        {
								
                                if(isset($nbtmp[$i]) && strlen(trim($nbtmp[$i]))==3 && $i!=2 && $i!=3)
                                {
                                    $ntmp=substr($nbtmp[$i],1);
									
                                    if(substr($nbtmp[$i],0,1)<>1 && substr($nbtmp[$i],0,1)<>0)
                                    {
                                            $nblet.=$nb1[substr($nbtmp[$i],0,1)-1];
                                            if( $ntmp<>0)
                                            {
                                                    $nblet.=' cent ';
                                            }
                                            else
                                            {
                                                    if(isset($nbtmp[$i-1]))
                                                    {
                                                                    $nblet.=' cent ';
                                                    }
                                                    else
                                                    {
                                                                    $nblet.=' cents ';
                                                    }
                                            }
                                    }
                                    elseif( substr($nbtmp[$i],0,1)<>0 )
                                    {
                                            $nblet.='cent ';
                                    }
                                    
                                }
                                elseif(isset($nbtmp_else[$i]) && strlen(trim($nbtmp_else[$i]))==3 && $i==2)
                                {
                                    $ntmp=substr($nbtmp_else[$i],1);

                                    if(substr($nbtmp_else[$i],0,1)<>1 && substr($nbtmp_else[$i],0,1)<>0)
                                    {
                                            $nblet.=$nb1[substr($nbtmp_else[$i],0,1)-1];
                                            if( $ntmp<>0 )
                                            {
                                                    $nblet.=' cent ';
                                            }
                                            else
                                            {
                                                    $nblet.=' cents ';
                                            }
                                    }
                                    elseif( substr($nbtmp_else[$i],0,1)<>0 )
                                    {
                                            $nblet.='cent ';
                                    }
                                    
                                }
                                elseif(isset($nbtmp_milliard[$i]) && strlen(trim($nbtmp_milliard[$i]))==3 && $i==3)
                                {
                                    $ntmp=substr($nbtmp_milliard[$i],1);

                                    if(substr($nbtmp_milliard[$i],0,1)<>1 && substr($nbtmp_milliard[$i],0,1)<>0)
                                    {
                                            $nblet.=$nb1[substr($nbtmp_milliard[$i],0,1)-1];
                                            if( $ntmp<>0 )
                                            {
                                                    $nblet.=' cent ';
                                            }
                                            else
                                            {
                                                    $nblet.=' cents ';
                                            }
                                    }
                                    elseif( substr($nbtmp_milliard[$i],0,1)<>0 )
                                    {
                                            $nblet.=' cent ';
                                    }
                                    
                                }
                                else
                                {
                                        if(isset($nbtmp_milliard[$i]) && $i==3)
                                        {
                                                
                                                $ntmp= isset($nbtmp_milliard[$i]) ? $nbtmp_milliard[$i] : "";
                                        }
                                        elseif(isset($nbtmp_else[$i]) && $i==2)
                                        {
                                                
                                                $ntmp= isset($nbtmp_else[$i]) ? $nbtmp_else[$i] : "";
                                        }
                                        else
                                        {
                                                
                                                $ntmp= isset($nbtmp[$i]) ? $nbtmp[$i] : "";
                                        }
                                }

                                if($ntmp>0 && $ntmp<20)
                                {
                                    if( !($i==1 && $nbtmp[$i]==1) )
                                    {
                                        $nblet.=$nb1[$ntmp-1].' ';
                                    }
                                }

                                if($ntmp>=20 && $ntmp<60){
                                    switch(substr($ntmp,1,1))
                                    {
                                        case 1 :    $sep=' et ';
                                                    break;
                                        case 0 :    $sep='';
                                                    break;
                                        default:    $sep='-';
                                    }
                                    if($sep =="")
                                    {
                                            $nblet.=$nb2[substr($ntmp,0,1)-2]." ";
                                    }
                                    else
                                    {
                                            $nblet.=$nb2[substr($ntmp,0,1)-2].$sep.$nb1[substr($ntmp,1,1)-1].' ';
                                    }
                                }

                                if($ntmp>=60 && $ntmp<80)
                                {
                                        $nblet.=$nb2[4];
                                        switch(substr($ntmp,1,1))
                                        {
                                                case 1 :    $sep=' et ';
                                                            break;
                                                case 0 :    $sep='';
                                                            break;
                                                default:    $sep='-';
                                        }

                                        if(substr($ntmp,0,1)<>7)
                                        {
                                                if($ntmp !='60')
                                                {
                                                        $nblet.=$sep.$nb1[substr($ntmp,1,1)-1].' ';
                                                }
                                        }
                                        else
                                        {
                                                if(substr($ntmp,1,1)+9==9)$sep='-';
                                                $nblet.=$sep.$nb1[substr($ntmp,1,1)+9].' ';
                                        }

                                }

                                if($ntmp>=80 && $ntmp<100)
                                {
                                        $nblet.=$nb2[6];
                                        switch(substr($ntmp,1,1))
                                        {
                                                case 1 :    $sep=' et ';
                                                            break;
                                                case 0 :    $sep='';
                                                            break;
                                                default:    $sep='-';
                                        }
                                        
                                        if($ntmp=='81') $sep = ' ';
                                            
                                        if(substr($ntmp,0,1)<>9)
                                        {
                                                $nblet.= isset($nb1[substr($ntmp,1,1)-1]) ? $sep.$nb1[substr($ntmp,1,1)-1] : "";
                                                if(substr($ntmp,1,1)==0)$nblet.='s';
                                        }
                                        else
                                        {
                                                if(substr($ntmp,1,1)==0)$sep='-';
                                                $nblet.= isset($nb1[substr($ntmp,1,1)+9]) ? $sep.$nb1[substr($ntmp,1,1)+9] : "";
                                        }
                                        $nblet.=' ';
                                }

                                if(isset($nbtmp[$i]) && $i==1 && $nbtmp[$i]<>0)
                                {
                                    if($nbtmp[$i]>1)
                                    {
                                            $nblet.=' milles ';
                                    }
                                    else
                                    {
                                            $nblet.=' mille ';
                                    }
                                }
                                
                                if(isset($nbtmp_else[$i]) && $i==2 && $nbtmp_else[$i]<>0)
                                {
                                    if($nbtmp_else[$i]>1)
                                    {
                                            $nblet.=' millions ';
                                    }
                                    else
                                    {
                                            $nblet.=' million ';
                                    }
                                }
                                
                                if(isset($nbtmp_milliard[$i]) && $i==3 && $nbtmp_milliard[$i]<>0)
                                {
                                    if($nbtmp_milliard[$i]>1)
                                    {
                                            $nblet.=' milliards ';
                                    }
                                    else
                                    {
                                            $nblet.=' milliard ';
                                    }
                                }
                        }
                        
                        ## Traitement du côté décimale
                        if( isset($nombre[0]) && isset($nombre[1]) && $nombre[0]>0 && $nombre[1]>0 )$nblet.=' et ';
                        $ntmp= isset($nombre[1]) ? substr($nombre[1],0,2) : "";
                        if( !empty($ntmp) )
                        {
                                if($ntmp>0 && $ntmp<20)
                                {
                                        $nblet.=$nb1[$ntmp-1].' ';
                                }

                                if($ntmp>=20 && $ntmp<60){
                                    switch(substr($ntmp,1,1)){
                                            case 1 :    $sep=' et ';
                                                        break;
                                            case 0 :    $sep='';
                                                        break;
                                            default:    $sep='-';
                                    }
                                    if($sep =="")
                                    {
                                            $nblet.=$nb2[substr($ntmp,0,1)-2]." ";
                                    }
                                    else
                                    {
                                            $nblet.=$nb2[substr($ntmp,0,1)-2].$sep.$nb1[substr($ntmp,1,1)-1].' ';
                                    }
                                }

                                if($ntmp>=60 && $ntmp<80)
                                {
                                    $nblet.=$nb2[4];
                                    switch(substr($ntmp,1,1))
                                    {
                                            case 1 :    $sep=' et ';
                                                        break;
                                            case 0 :    $sep='';
                                                        break;
                                            default:    $sep='-';
                                    }

                                    if(substr($ntmp,0,1)<>7)
                                    {
                                            $nblet.=$sep.$nb1[substr($ntmp,1,1)-1].' ';
                                    }
                                    else
                                    {
                                            if(substr($ntmp,1,1)+9==9)$sep='-';
                                            $nblet.=$sep.$nb1[substr($ntmp,1,1)+9].' ';
                                    }

                                }

                                if($ntmp>=80 && $ntmp<100)
                                {
                                    $nblet.=$nb2[6];
                                    switch(substr($ntmp,1,1))
                                    {
                                            case 0 :    $sep='';
                                                        break;
                                            default:    $sep='-';
                                    }

                                    if(substr($ntmp,0,1)<>9)
                                    {
                                            $nblet.=$sep.$nb1[substr($ntmp,1,1)-1];
                                            if(substr($ntmp,1,1)==0)$nblet.='s';
                                    }
                                    else
                                    {
                                            if(substr($ntmp,1,1)==0)$sep='-';
                                            $nblet.=$sep.$nb1[substr($ntmp,1,1)+9];
                                    }
                                    $nblet.=' ';

                                }

                                if($ntmp<>0 && !empty($ntmp) )
                                {
                                        if($ntmp == 01)
                                        {
                                                $nblet.=' centime ';
                                        }
                                        else
                                        {
                                                $nblet.=' centimes ';
                                        }
                                }
                        }
                        return $nblet;
                }
                return "";
        }
}

