<?php

namespace App\Libraries\PaymentGateway;

use App\Libraries\PaymentGateway\Drivers\MpgsDriver;
use App\Libraries\PaymentGateway\Drivers\ProxypayDriver;

class PaymentManager{

    public static function make($method)
    {
        switch($method)
        {
            case "CREDIT_CARD":
                return new MpgsDriver();
            case "WALLET":
                return new ProxypayDriver();
            case "IKWOOK_PAY":
                return null;
            default :
                return null;
        }
    }
}

?>