<?php

namespace App\Libraries\PaymentGateway\Contracts;

interface PaymentInterface{

    public function process_payment(array $body): array;

    public function handle_callback(array $body): array;

    public function verify_payment($ref): array;
}

?>