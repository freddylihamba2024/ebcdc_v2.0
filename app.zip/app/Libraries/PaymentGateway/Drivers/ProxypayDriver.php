<?php

namespace App\Libraries\PaymentGateway\Drivers;

use App\Libraries\PaymentGateway\Contracts\PaymentInterface;
use Config\Services;

class ProxypayDriver implements PaymentInterface{

    private $base_url=null;
    private $username=null;
    private $password=null;
    private $proxy_pay_page_id=null;
    private $proxy_pay_callback_url=null;
    private $curl_client=null;


    public function __construct()
    {
            $this->base_url=env("PROXYPAY_API_URL");
            $this->username=env("PROXYPAY_USERNAME");
            $this->password=env("PROXYPAY_PASSWORD");
            $this->proxy_pay_page_id=env("PROXYPAY_PAGE_ID");
            $this->proxy_pay_callback_url=env("PROXYPAY_CALLBACK_URL");

            $this->curl_client = Services::curlrequest();
    }

    public function login()
    {
        if ($this->base_url === '') return null;

        try 
        {
            $resp = $this->curl_client->post($this->base_url . '/login', [
                'headers'     => ['Accept' => 'application/json'],
                'json'        => ['emailAddress' => $this->username, 'password' => $this->password],
                'http_errors' => false,
                'timeout'     => 25,
                'verify'      => false // disables SSL verification
            ]);
            
            $code = $resp->getStatusCode();
       
            $body = json_decode((string)$resp->getBody(), true);
            if ($code >= 200 && $code < 300 && isset($body['token'])) {
                return $body['token'];
            }
            

        } catch (\Throwable $th) {
            //throw $th;
            throw new \Exception("Unable to connect to ProxyPay API");
        }
    }

    public function process_payment(array $body): array
    {
            // Normaliser entrées requises
            $order = $body['order'] ?? [];
            $channel = $body['paymentChannel'] ?? [];
            $originRef = $order['transactionReference'] ?? ('TRX-' . date('YmdHis') . rand(100, 999));

            // Si API indisponible, simuler
            $token = $this->login();
           
            if (!$token) {
                return [
                    'ok' => false,
                    'gateway' => 'PROXYPAY',
                    'originatingReference' => $originRef,
                    'gatewayReference' => null,
                    'transactionId' => null,
                    'status' => 'FAILED',
                    'raw' => ['error' => 'Unable to authenticate with ProxyPay API']
                ];
            }

            // Construire request body selon ProxyPay (fourni)
            $reqBody = [
                'order' => [
                    'paymentPageId'       => $order['paymentPageId'] ?? $this->proxy_pay_page_id,
                    'customerFullName'    => $order['customerFullName'] ?? '',
                    'customerPhoneNumber' => $order['customerPhoneNumber'] ?? '',
                    'customerEmailAddress' => $order['customerEmailAddress'] ?? '',
                    'transactionReference' => $originRef,
                    'amount'              => (float)($order['amount'] ?? 0),
                    'currency'            => $order['currency'] ?? 'USD',
                    'redirectURL'         => $order['redirectURL'] ?? $this->proxy_pay_callback_url,
                ],
                'paymentChannel' => [
                    'channel'  => $channel['channel'] ?? 'MOBILEMONEY',
                    'provider' => $channel['provider'] ?? 'AIRTEL',
                    'walletID' => $channel['walletID'] ?? ''
                ]
            ];

            try {
                $resp = $this->curl_client->post($this->base_url . '/pay/paymentrequest', [
                    'headers' => [
                        'Accept'        => 'application/json',
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'Bearer ' . $token,
                        'X-API-CALLBACK-MODE'=> 2
                    ],
                    'json' => $reqBody,
                    'http_errors' => false,
                    'timeout' => 420,
                    'verify'      => false // disables SSL verification
                ]);
                $code = $resp->getStatusCode();

                $body = json_decode((string)$resp->getBody(), true);

                if ($code >= 200 && $code < 300 && is_array($body)) {
                    return [
                        'ok' => true,
                        'gateway' => 'PROXYPAY',
                        'originatingReference' => $originRef,
                        'gatewayReference' => $body['transactionId'] ?? $body['originatingTransactionId'] ?? $originRef,
                        'transactionId' => (string)($body['transactionId'] ?? ''),
                        'status' => ($body['statusDescription'] ?? '') === 'ACCEPTED' ? 'PENDING' : 'PENDING',
                        'raw' => $body
                    ];
                }
            } catch (\Throwable $e) {
                // log si besoin
                throw new \Exception("Error processing payment with ProxyPay: " . $e->getMessage());
            }
            return [
                'ok' => false,
                'gateway' => 'PROXYPAY',
                'originatingReference' => $originRef,
                'gatewayReference' => null,
                'transactionId' => null,
                'status' => 'FAILED',
                'raw' => ['error' => 'Payment request failed or returned invalid response']
            ];
    }
    public function handle_callback(array $body): array
    {
         // Adapte selon ProxyPay (exemple basique)
        $status = strtoupper((string)($body['status'] ?? 'PENDING'));
        $map = [
            'ACCEPTED' => 'PENDING',
            'SUCCESS'  => 'PAID',
            'FAILED'   => 'FAILED',
            'REFUSED'  => 'REFUSED',
            'CANCELED' => 'CANCELED',
        ];
        $normalized = $map[$status] ?? 'PENDING';
        return [
            'status' => $normalized,
            'gatewayReference' => $body['transactionId'] ?? $body['originatingTransactionId'] ?? null,
            'raw' => $body
        ];
    }
    public function verify_payment($ref): array
    {
        $token = $this->login();
        if (!$token) {
            return [
                'ok' => false,
                'gateway' => 'PROXYPAY',
                'originatingReference' => $ref,
                'gatewayReference' => null,
                'transactionId' => null,
                'status' => 'FAILED',
                'raw' => ['error' => 'Unable to authenticate with ProxyPay API']
            ];
        }
        try {
            $resp = $this->curl_client->get($this->base_url . '/reporting/transactionstatus/' . urlencode($ref), [
                'headers' => [
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $token
                ],
                'http_errors' => false,
                'timeout' => 420,
                'verify'      => false //disables SSL verification
            ]);
            $code = $resp->getStatusCode();
          
            $body = json_decode((string)$resp->getBody(), true);
            
            if ($code >= 200 && $code < 300 && is_array($body)) {

                return [
                    'ok' => true,
                    'gateway' => 'PROXYPAY',
                    'originatingReference' => $ref,
                    'gatewayReference' => $body['transactionId'] ?? $body['originatingTransactionId'] ?? $ref,
                    'transactionId' => (string)($body['transactionId'] ?? ''),
                    'status' => strtoupper(($body['status'] ?? '') === 'ACCEPTED' ? 'PENDING' : ($body['status'] ?? 'PENDING')),
                    'statusCode'=> $body['statusCode'] ?? 300,
                    'raw' => $body
                ];
            }
        } catch (\Throwable $e) {
            throw new \Exception("Error verifying payment with ProxyPay: " . $e->getMessage());
        }
        return [
            'ok' => false,
            'gateway' => 'PROXYPAY',
            'originatingReference' => $ref,
            'gatewayReference' => null,
            'transactionId' => null,
            'status' => 'FAILED',
            'statusCode'=> $body['statusCode'] ?? 300,
            'raw' => ['error' => 'Verification request failed or returned invalid response']
        ];
    }
}


?>