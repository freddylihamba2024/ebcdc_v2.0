<?php

namespace App\Libraries\PaymentGateway\Drivers;

use App\Libraries\PaymentGateway\Contracts\PaymentInterface;
use Config\Services;

class MpgsDriver implements PaymentInterface{


	public function process_payment(array $body): array
	{
		$order = $body['order'];
        $merchant_id = env('MPGS_MERCHANT_ID');
        $api_password= env('MPGS_API_PASSWORD');
        $api_url = rtrim(env('MPGS_API_URL'), '/') . "/merchant/{$merchant_id}/session";

        // Construction du payload pour MPGS
        $mpgsPayload = [
            "apiOperation" => "INITIATE_CHECKOUT",
            "order" => [
                "id"       => $order['transactionReference'],
                "amount"   => number_format((float)$order['amount'], 2, '.', ''),
                "currency" => $order['currency'] ?? 'USD',
                "description" => $order['description'] ?? 'No description'
            ],
            "interaction" => [
                "operation" => "PURCHASE",
                "returnUrl" => '',
                "merchant" => [
                    "name" => $order['merchant_name']
                ]
            ]
        ];

        try {
            $client = Services::curlrequest();

            // Basic Auth : username = "merchant.<merchantId>", password = apiPassword
            $username = "merchant." . $merchant_id;

            $response = $client->request('POST', $api_url, [
                'auth'        => [$username, $api_password, 'basic'],
                'json'        => $mpgsPayload,
                'timeout'     => 120,
                'http_errors' => false, // Ne pas lancer d'exception sur 4xx/5xx
            ]);

            $statusCode = $response->getStatusCode();
            $body = $response->getBody();
            $result = json_decode($body, true);

            log_message('debug', 'MPGS API Response: HTTP {status} - {body}', [
                'status' => $statusCode,
                'body'   => $body,
            ]);

            // Gestion des erreurs : HTTP 4xx/5xx OU result=ERROR dans le JSON (MPGS peut renvoyer 200 avec erreur)
            if ($statusCode >= 400 || (isset($result['result']) && $result['result'] === 'ERROR')) {
                $errorCause = $result['error']['cause'] ?? 'UNKNOWN';
                $errorExplanation = $result['error']['explanation'] ?? 'No explanation provided';
                return [
                    'ok'     => false,
                    'status' => 'FAILED',
                    'raw'    => [
                        'message' => "MPGS API error: HTTP {$statusCode} - {$errorCause}: {$errorExplanation}",
                        'response' => $result
                    ],
                    'error'  => [
                        'httpStatus'  => $statusCode,
                        'cause'       => $errorCause,
                        'explanation' => $errorExplanation,
                    ]
                ];
            }

            if (isset($result['session']['id'])) {
                return [
                    'ok' => true,
                    'status' => 'PENDING',
                    'gatewayReference' => $result['successIndicator'], // On stocke le successIndicator ici
                    'transactionId' => $result['session']['id'],      // On passe le Session ID au front
                    'paymentEntryWebUrl' => null, // Non utilisé car on utilise Checkout.js
                    'raw' => $result
                ];
            }

            return ['ok' => false, 'status' => 'FAILED', 'raw' => $result];
        } catch (\Throwable $e) {
            return ['ok' => false, 'status' => 'ERROR', 'raw' => ['message' => $e->getMessage()]];
        }
	}

	public function handle_callback(array $body): array
	{
		// MPGS renvoie le resultIndicator dans l'URL (GET)
        $resultIndicator = $body['resultIndicator'] ?? null;
        $orderId = $body['order_id'] ?? null;

        // Note: La validation réelle se fera dans le contrôleur en comparant 
        // avec le successIndicator stocké en DB (GatewayReference_9)
        return [
            'status' => 'CHECK_REQUIRED', // On force une vérification manuelle
            'gatewayReference' => $resultIndicator,
            'raw' => $body
        ];
	}

	public function verify_payment($ref): array
	{

	}

}

?>