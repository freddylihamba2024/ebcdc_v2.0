<?php

namespace App\Libraries\PaymentGateway\Drivers;

use App\Libraries\PaymentGateway\Contracts\PaymentInterface;

class MaxicashDriver implements PaymentInterface{
    
    public function process_payment(array $body): array
    {
        
    }

    public function handle_callback(array $body): array
    {
    }

    public function verify_payment($ref): array
    {
    }

}
