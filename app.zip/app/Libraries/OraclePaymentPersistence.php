<?php
namespace App\Libraries;

use CodeIgniter\Database\RawSql;

/** Oracle insert identities, dates and absent optional fields. */
class OraclePaymentPersistence
{
    public const OPTION = 'oracle-payment-nullable-persistence';
    public const LABEL = 'Fiabiliser les sauvegardes Oracle et compléter les champs NOT NULL manquants';
    private const PREVIOUS_LABEL = 'Fiabiliser les paiements Oracle et compléter les champs optionnels absents selon leur type';
    private const LEGACY_LABEL = 'Fiabiliser les paiements Oracle et enregistrer les champs optionnels absents à NULL';
    private static array $columns = [];

    public static function enabled(string $driver, array $userdata): bool
    {
        $options = json_decode($userdata['options'] ?? '', true) ?? [];
        return $driver === 'OCI8' && in_array($options['ALL'][self::OPTION] ?? false, [self::LABEL, self::PREVIOUS_LABEL, self::LEGACY_LABEL, true, 1, '1'], true);
    }

    private static function missingValue(string $type, string $nullable = 'Y')
    {
        if (in_array($type, ['VARCHAR', 'VARCHAR2', 'NVARCHAR2'], true)) return 'N/A';
        if (in_array($type, ['NUMBER', 'FLOAT', 'BINARY_FLOAT', 'BINARY_DOUBLE', 'INTEGER', 'INT', 'DOUBLE', 'DOUBLE PRECISION', 'DECIMAL', 'NUMERIC', 'REAL'], true)) return 0;
        if ($type === 'DATE' && $nullable === 'N') {
            // Temporary sentinel until the column is migrated to accept NULL.
            return new RawSql("TO_DATE('1900-01-01', 'YYYY-MM-DD')");
        }
        return null;
    }

    public static function save($db, string $table, string $key, array $data, $id)
    {
        $table = strtoupper($table);
        $key = strtoupper(trim($key));
        if (!preg_match('/^[A-Z][A-Z0-9_$#]*$/D', $table . '') || !preg_match('/^[A-Z][A-Z0-9_$#]*$/D', $key)) {
            throw new \InvalidArgumentException('Invalid Oracle persistence identifier.');
        }
        $cacheKey = spl_object_id($db) . ':' . $table;
        if (!isset(self::$columns[$cacheKey])) {
            $result = $db->query('SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, IDENTITY_COLUMN, DATA_DEFAULT FROM USER_TAB_COLUMNS WHERE TABLE_NAME = ?', [$table]);
            if (!$result) return false;
            self::$columns[$cacheKey] = array_column($result->getResultArray(), null, 'COLUMN_NAME');
        }
        $columns = self::$columns[$cacheKey];
        if (!$columns) throw new \RuntimeException('Oracle table metadata unavailable: ' . $table);
        $values = [];
        foreach ($data as $field => $value) {
            $field = strtoupper(trim($field));
            if (!isset($columns[$field])) throw new \InvalidArgumentException('Unknown Oracle column: ' . $field);
            if ($field === $key) continue;
            if ($value === null || (is_string($value) && trim($value) === '')) {
                $value = self::missingValue($columns[$field]['DATA_TYPE'], $columns[$field]['NULLABLE']);
            }
            if ($value !== null && !($value instanceof RawSql) && $columns[$field]['DATA_TYPE'] === 'DATE') {
                $format = strlen((string) $value) === 10 ? 'YYYY-MM-DD' : 'YYYY-MM-DD HH24:MI:SS';
                $value = new RawSql('TO_DATE(' . $db->escape($value) . ", '" . $format . "')");
            }
            $values[$field] = $value;
        }
        if ($id !== null) {
            $existing = $db->table($table)->where($key, $id)->get();
            if (!$existing || !$existing->getRow()) return false;
            return OracleRequiredFields::write($db, $table, $key, $values, false, static fn ($repaired) => $db->table($table)->where($key, $id)->update($repaired)) ? $id : false;
        }
        // Preserve database defaults and identities; complete absent optional fields by type.
        foreach ($columns as $field => $column) {
            if ($field !== $key && $column['IDENTITY_COLUMN'] !== 'YES'
                && ($column['NULLABLE'] === 'Y' || $column['DATA_TYPE'] === 'DATE')
                && $column['DATA_DEFAULT'] === null && !array_key_exists($field, $values)) {
                $values[$field] = self::missingValue($column['DATA_TYPE'], $column['NULLABLE']);
            }
        }
        $identity = $db->query('SELECT SEQUENCE_NAME FROM USER_TAB_IDENTITY_COLS WHERE TABLE_NAME = ? AND COLUMN_NAME = ?', [$table, $key]);
        if (!$identity) return false;
        $sequence = $identity->getRowArray()['SEQUENCE_NAME'] ?? '';
        if (!preg_match('/^[A-Z][A-Z0-9_$#]*$/D', $sequence)) throw new \RuntimeException('Oracle identity unavailable: ' . $table);
        if (!OracleRequiredFields::write($db, $table, $key, $values, true, static fn ($repaired) => $db->table($table)->insert($repaired))) return false;
        $result = $db->query('SELECT "' . $sequence . '".CURRVAL AS INSERT_ID FROM DUAL');
        $insertId = $result ? ($result->getRowArray()['INSERT_ID'] ?? null) : null;
        if (!is_numeric($insertId) || $insertId <= 0) throw new \RuntimeException('Oracle insert identity unavailable.');
        $row = $db->table($table)->where($key, $insertId)->get();
        if (!$row || !$row->getRow()) return false;
        return (int) $insertId;
    }
}
