<?php
namespace App\Libraries;

use CodeIgniter\Database\RawSql;

/** Retry only Oracle missing NOT NULL values, using the active table's metadata. */
class OracleRequiredFields
{
    public static function write($db, string $table, string $key, array $values, bool $insert, callable $write): bool
    {
        return $db->retryMissingRequiredValues(
            static fn () => $write($values),
            static function () use ($db, $table, $key, $values, $insert, $write) {
                $result = $db->query(
                    'SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, IDENTITY_COLUMN, DATA_DEFAULT FROM USER_TAB_COLUMNS WHERE TABLE_NAME = ?',
                    [strtoupper($table)]
                );
                if (!$result) return false;
                $columns = $result->getResultArray();
                $byName = [];
                foreach ($values as $field => $value) $byName[strtoupper(trim($field))] = $field;
                $changed = false;
                foreach ($columns as $column) {
                    $name = $column['COLUMN_NAME'];
                    if ($column['NULLABLE'] !== 'N' || $column['IDENTITY_COLUMN'] === 'YES' || $name === strtoupper(trim($key))) continue;
                    $present = array_key_exists($name, $byName);
                    if (!$present && (!$insert || $column['DATA_DEFAULT'] !== null)) continue;
                    $field = $present ? $byName[$name] : $name;
                    $value = $present ? $values[$field] : null;
                    if ($value !== null && !(is_string($value) && trim($value) === '')) continue;
                    $replacement = self::replacement($column['DATA_TYPE']);
                    if ($replacement === null) continue;
                    $values[$field] = $replacement;
                    $changed = true;
                }
                // One retry fills all missing required values, without touching submitted values.
                return $changed ? $write($values) : false;
            }
        );
    }

    public static function replacement(string $type)
    {
        if (in_array($type, ['VARCHAR', 'VARCHAR2', 'NVARCHAR2', 'CHAR', 'NCHAR', 'CLOB', 'NCLOB'], true)) return 'N/A';
        if (in_array($type, ['NUMBER', 'FLOAT', 'BINARY_FLOAT', 'BINARY_DOUBLE', 'INTEGER', 'INT', 'DOUBLE', 'DOUBLE PRECISION', 'DECIMAL', 'NUMERIC', 'REAL'], true)) return 0;
        if ($type === 'DATE') return new RawSql("TO_DATE('1900-01-01', 'YYYY-MM-DD')");
        if (strpos($type, 'TIMESTAMP') === 0) {
            if (strpos($type, 'WITH TIME ZONE') !== false) return new RawSql("TO_TIMESTAMP_TZ('1900-01-01 00:00:00 +00:00', 'YYYY-MM-DD HH24:MI:SS TZH:TZM')");
            return new RawSql("TO_TIMESTAMP('1900-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS')");
        }
        return null;
    }
}
