<?php

namespace App\Libraries;

class Infobip
{
    private array $cfg;

    public function __construct(array $overrides = [])
    {
        $config = config('Infobip');
        $this->cfg = array_merge(get_object_vars($config), $overrides);
    }

    public function send_email(
        string $from,
        array $to,
        string $subject,
        string $text = '',
        string $html = '',
        array $attachments = [],
        array $cc = [],
        array $bcc = [],
        array $extraPayload = []
    ): array {
        if ($to === []) {
            return [
                'ok' => false,
                'httpCode' => 400,
                'error' => 'Missing email recipient.',
                'raw' => null,
                'json' => null,
                'messageId' => null,
            ];
        }

        if ($cc !== []) {
            $bcc = array_merge($bcc, $cc);
        }

        $resolvedFrom = $this->resolve_from_address($from);
        if ($resolvedFrom === null) {
            return [
                'ok' => false,
                'httpCode' => 400,
                'error' => 'Invalid sender email address.',
                'raw' => null,
                'json' => null,
                'messageId' => null,
            ];
        }

        $postFields = array_merge([
            'from' => $resolvedFrom,
            'subject' => $subject,
            'text' => $text,
            'html' => $html,
        ], $extraPayload);

        foreach (array_values($this->filter_emails($to)) as $index => $email) {
            $postFields["to[{$index}]"] = $email;
        }

        foreach (array_values($this->filter_emails($bcc)) as $index => $email) {
            $postFields["bcc[{$index}]"] = $email;
        }

        if ($attachments !== []) {
            $firstAttachment = $attachments[0] ?? null;
            if (is_string($firstAttachment) && is_file($firstAttachment) && is_readable($firstAttachment)) {
                $postFields['attachment'] = curl_file_create($firstAttachment);
            }
        }

        $response = $this->request('POST', (string) $this->cfg['sendPath'], [
            'postFields' => $postFields,
        ]);
        $response['messageId'] = $this->extract_message_id($response['json']);

        return $response;
    }

    public function get_email_delivery_reports(array $query = []): array
    {
        return $this->request('GET', (string) $this->cfg['reportsPath'], [
            'query' => $query,
        ]);
    }

    public function send_whatsapp_document_template(
        string $from,
        string $to,
        string $templateName,
        string $language,
        string $documentUrl,
        string $filename,
        array $bodyVariables = []
    ): array {
        $content = [
            'header' => [
                'type' => 'DOCUMENT',
                'url' => $documentUrl,
                'filename' => $filename,
            ],
        ];

        if ($bodyVariables !== []) {
            $content['body'] = ['type' => 'TEXT'];

            foreach (array_values($bodyVariables) as $index => $value) {
                $content['body'][(string) ($index + 1)] = (string) $value;
            }
        }

        $response = $this->request('POST', (string) ($this->cfg['messagesPath'] ?? '/messages-api/1/messages'), [
            'json' => [
                'messages' => [[
                    'channel' => 'WHATSAPP',
                    'sender' => $from,
                    'destinations' => [['to' => $to]],
                    'content' => $content,
                    'template' => [
                        'templateName' => $templateName,
                        'language' => $language,
                    ],
                ]],
            ],
        ]);
        $response['messageId'] = $this->extract_message_id($response['json']);

        return $response;
    }

    public function launch_delivery_tracking_worker(string $trackedMessageId = '', array $query = [], array $options = []): array
    {
        $phpBinary = $options['phpBinary'] ?? (PHP_BINARY ?: 'php');
        $interval = max(1, (int) ($options['intervalSeconds'] ?? 15));
        $maxLoops = max(0, (int) ($options['maxLoops'] ?? 0));
        $stopWhenFound = (bool) ($options['stopWhenFound'] ?? true);
        $dateSuffix = date('Y-m-d');
        $logDir = ROOTPATH . 'drive/logs/logiref/cli/spark';

        if (!is_dir($logDir)) {
            @mkdir($logDir, 0775, true);
        }

        $launcherLogFile = $options['launcherLogFile'] ?? ($logDir . '/' . $dateSuffix . '_infobip_email_reports_worker.logs');
        $spark = realpath(ROOTPATH . 'spark');

        if ($spark === false || !is_file($spark)) {
            return [
                'ok' => false,
                'pid' => null,
                'command' => null,
                'launcherLogFile' => $launcherLogFile,
                'error' => 'Spark file not found.',
                'trackedMessageId' => $trackedMessageId,
                'mode' => 'spark_worker',
            ];
        }

        $commandParts = [
            $phpBinary,
            $spark,
            'infobip:email-reports',
            '--interval=' . $interval,
            '--max-loops=' . $maxLoops,
        ];

        if ($trackedMessageId !== '') {
            $commandParts[] = '--tracked-message-id=' . $trackedMessageId;
        }

        if ($stopWhenFound) {
            $commandParts[] = '--stop-when-found';
        }

        if ($query !== []) {
            $encodedQuery = json_encode($query, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($encodedQuery !== false) {
                $commandParts[] = '--query=' . $encodedQuery;
            }
        }

        $command = implode(' ', array_map('escapeshellarg', $commandParts));
        $spawn = 'cd ' . escapeshellarg(ROOTPATH)
            . ' && nohup '
            . $command
            . ' >> '
            . escapeshellarg($launcherLogFile)
            . ' 2>&1 < /dev/null & echo $!';

        $pid = shell_exec('sh -c ' . escapeshellarg($spawn));
        $pid = is_string($pid) ? trim($pid) : '';

        return [
            'ok' => ctype_digit($pid),
            'pid' => ctype_digit($pid) ? (int) $pid : null,
            'command' => $spawn,
            'launcherLogFile' => $launcherLogFile,
            'error' => ctype_digit($pid) ? null : 'Failed to start worker.',
            'trackedMessageId' => $trackedMessageId,
            'mode' => 'spark_worker',
        ];
    }

    public function extract_reports($json): array
    {
        if (!is_array($json)) {
            return [];
        }

        foreach (['results', 'reports', 'items'] as $key) {
            if (isset($json[$key]) && is_array($json[$key])) {
                return $json[$key];
            }
        }

        if (isset($json[0]) && is_array($json[0])) {
            return $json;
        }

        return [];
    }

    public function normalize_delivery_status(array $report): string
    {
        $status = strtoupper((string) ($report['status']['groupName'] ?? $report['status']['name'] ?? 'PENDING'));

        if (str_contains($status, 'DELIVERED')) {
            return 'DELIVERED';
        }

        if (str_contains($status, 'UNDELIVER')) {
            return 'UNDELIVERED';
        }

        if (str_contains($status, 'REJECT') || str_contains($status, 'FAIL') || str_contains($status, 'ERROR')) {
            return 'FAILED';
        }

        return 'PENDING';
    }

    private function request(string $method, string $path, array $options = []): array
    {
        $url = rtrim((string) $this->cfg['baseUrl'], '/') . '/' . ltrim($path, '/');
        $query = $options['query'] ?? [];

        if ($query !== []) {
            $url .= '?' . http_build_query($query);
        }

        $ch = curl_init($url);
        $headers = [
            'Authorization: App ' . (string) $this->cfg['apiKey'],
            'Accept: application/json',
        ];

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_TIMEOUT, (int) $this->cfg['timeoutSeconds']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, (bool) $this->cfg['sslVerify']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, (bool) $this->cfg['sslVerify'] ? 2 : 0);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if (array_key_exists('json', $options)) {
                $headers[] = 'Content-Type: application/json';
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(
                    $options['json'],
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                ));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $options['postFields'] ?? []);
            }
        } else {
            $headers[] = 'Content-Type: application/json';
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $raw = curl_exec($ch);
        $error = curl_error($ch) ?: null;
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $json = null;
        if (is_string($raw) && trim($raw) !== '') {
            $decoded = json_decode($raw, true);
            $json = json_last_error() === JSON_ERROR_NONE ? $decoded : null;
        }

        return [
            'ok' => $error === null && $httpCode >= 200 && $httpCode < 300,
            'httpCode' => $httpCode,
            'error' => $error ?? ($httpCode >= 300 ? 'Infobip request failed.' : null),
            'raw' => $raw,
            'json' => $json,
            'url' => $url,
        ];
    }

    private function extract_message_id($json): ?string
    {
        if (!is_array($json)) {
            return null;
        }

        if (!empty($json['messages'][0]['messageId'])) {
            return (string) $json['messages'][0]['messageId'];
        }

        if (!empty($json['messageId'])) {
            return (string) $json['messageId'];
        }

        return null;
    }

    private function resolve_from_address(string $from): ?string
    {
        $candidates = [
            $from,
            (string) ($this->cfg['defaultFrom'] ?? ''),
        ];

        foreach ($candidates as $candidate) {
            $candidate = trim($candidate);
            if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_EMAIL)) {
                return $candidate;
            }
        }

        return null;
    }

    private function filter_emails(array $emails): array
    {
        return array_values(array_filter(array_map(
            static fn ($email) => trim((string) $email),
            $emails
        ), static fn ($email) => $email !== ''));
    }
}
