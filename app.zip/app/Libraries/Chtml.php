<?php 
namespace App\Libraries;

class Chtml {

	/*
	* CodeIgniter Library of:
	* Bootstrap form html
	*
	* Thanks to original author!
	*
	* By Papin d'Eve Mpengele
	*
	* Run as:
	* echo $this->formhtml->input($from_time, $to_time);
	*
	*/
	
	function box_body_opening($header = false, $padding = false, $closer=false) {
		echo '<div class="ibox box-solid">';
		if($header)  echo '<div class="ibox-header with-border">';
                if($closer)  echo '<button type="button" id="buttonCloseModal" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>';
                if($header)  echo '<h1 class="title">'.$header.'</h1></div>';
		if($padding) echo '<div class="ibox-content">';
		else         echo '<div class="ibox-content p-0">';
	}
	
	function box_body_closing() {
		echo '</div>';
		echo '</div>';
	}
        
        function box_modal_opening($header = false, $padding = false) {
            echo '<div class="modal-dialog">';
            echo '<div class="modal-content">';
                
            if($_SESSION['user_lang'] == 'en'){
                if($header){
			echo '<div class="modal-header">';
                        echo '<button type="button" id="buttonCloseModal" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>';
                        echo '<h1 class="title">'.$header.'</h1>';
                        echo '</div>';
                }
            }else{
                if($header){
			echo '<div class="modal-header">';
                        echo '<button type="button" id="buttonCloseModal" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>';
                        echo '<h1 class="title">'.$header.'</h1>';
                        echo '</div>';
                }
            }
            
            if($padding) echo '<div class="modal-bod">';
	    else echo '<div class="modal-bod no-padding">';
		
	}
	
	function box_modal_closing($footer = true) {
            echo '</div>';
            if($_SESSION['user_lang'] == 'en'){
                if($footer){
                    echo '<div class="modal-footer">';
                    echo '<button type="button" id="buttonClose" class="btn btn-default pull-left" data-dismiss="modal">Close</button>';
                    echo '<button type="submit" id="buttonSubmitModal" class="btn btn-primary">Save...</button>';
                }
            }else{
                if($footer){
                    echo '<div class="modal-footer">';
                    echo '<button type="button" id="buttonClose" class="btn btn-default pull-left" data-dismiss="modal">Quitter</button>';
                    echo '<button type="submit" id="buttonSubmitModal" class="btn btn-primary">Enregistrer...</button>';
                }
            }
            echo '</div>';
            echo '</div>';
            echo '</div>';
	}
	
	function right_side_content_opening() {
		echo '<!-- Right side column. Contains the navbar and content of the page -->';
		echo '<aside class="right-side">';
		echo '<!-- Main content -->';
		echo '<section class="content">';
	}
	
	function right_side_content_closing() {
		echo '</section>';
		echo '<!-- /.content -->';
		echo '</aside>';
		echo '<!-- /.right-side -->';
	}
	
	function form_dropdown($label,$name,$list,$val,$required=FALSE,$class=NULL) {
		if($required) $required='required'; else $required='';
		echo '<div class="form-group">';
		echo '<label for="'.$name.'">'.$label.'</label>';
		echo form_dropdown($name, $list, $val, 'class="form-control '.$class.'" id="'.$name.'" '.$required);
		echo '</div>';
	}
	
	function form_date($label,$name, $val,$required=FALSE,$class=NULL) {
		if($required) $required='required'; else $required='';
		echo '<div class="form-group">';
		echo '<label for="'.$name.'">'.$label.'</label>';
		echo '<div class="input-group"><div class="input-group-addon"><i class="fa fa-calendar"></i></div>';
		echo form_input($name, set_value($name, date('Y-m-d', strtotime($val))), ' id="datepicker" class="form-control' .$class.'" '.$required); 
		echo '</div></div>';
	}
	
	function form_input($label,$name, $val,$required=FALSE,$class=NULL,$placeholder=NULL,$max=86, $disabled=FALSE) {
		if($required) $required='required'; else $required='';
		if($disabled) $disabled='disabled'; else $disabled='';
		echo '<div class="form-group">';
		echo '<label for="'.$name.'">'.$label.'</label>';
		echo form_input($name, set_value($name, $val), ' id="'.$name.'" class="form-control' .$class.'" placeholder="'.$placeholder.'" maxlength="'.$max.'"'.$required.' '.$disabled); 
		echo '</div>';
	}
	
	function form_radio($label,$name,$data,$checked,$break=FALSE,$class=NULL) {
		if($break) $tag='<br/>'; else $tag='&nbsp;&nbsp;&nbsp;';
		
		echo '<div class="form-group '.$class.'">';
		echo '<label for="'.$name.'">'.$label.'</label><br/>';
		foreach($data as $val):
			if($val['val']==$checked) $ctag='checked'; else $ctag='';
			echo '<input type="radio" name="'.$name.'" value="'.$val['val'].'" checked="'.$ctag.'"> '.$val['label'].$tag;
		endforeach; 
		echo '</div>';
	}
	
	function form_textarea($label,$name, $val,$required=FALSE,$class=NULL,$placeholder=NULL,$max=86, $cols=40,$rows=5) {
		if($required) $required='required'; else $required='';
		echo '<div class="form-group">';
		echo '<label for="'.$name.'">'.$label.'</label>';
		echo form_textarea(array('name' => $name, 'cols' => $cols, 'rows' => $rows), set_value($name, $val), 'id="'.$name.'" class="form-control' .$class.'" placeholder="'.$placeholder.'" maxlength="'.$max.'"'.$required); 
		echo '<div style="clear:both"></div>';
		echo '</div>';
	}
	
	function form_uploadfile($label,$name, $val) {
		echo '<div style="height:40px;">';
		echo '<label for="'.$name.'">'.$label.'</label>';
		echo '<input type="file" name="fileToUpload" id="fileToUpload"/>'; 
		echo '</div>';
	}
	
	function form_footer($name, $goback=NULL, $style='btn-primary') {
		echo '<div class="box-footer" style="pending-left:1px;">';
		echo '<button type="submit" name="submit" class="btn '.$style.' pull-left" id="'.$name.'"><i class="fa fa-save"></i>  '.$name.' </button>&nbsp;';
		if($goback) echo anchor($goback, '<i class="fa fa-times"></i> Cancel', 'class="btn btn-danger"');
		echo '</div>';
	}
	
}
