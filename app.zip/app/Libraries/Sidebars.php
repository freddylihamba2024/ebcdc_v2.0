<?php

namespace App\Libraries;

use Config\Services;

class Sidebars
{
    /*
     * CodeIgniter Library of:
     * Bootstrap form html
     *
     * Thanks to original author!
     *
     * By Papin d'Eve Mpengele
     *
     * Run as:
     * echo $this->formhtml->input($from_time, $to_time);
     *
     */

    /*******************************************************************************************************************************/
    /************************************************  Core ************************************************************/
    /*******************************************************************************************************************************/

    function format($items, $skin = NULL)
    {
        $wrap_open = '<div class="sidebar-collapse bg-white">';
        $wrap_open .= '<ul class="nav metismenu  bg-white" id="side-menu">';
        $wrap_close = '</ul>';
        $wrap_close .= '</div>';
        $wrap_body = '';

        $uri_segments = current_url(false);

        foreach ($items as $item) {
            if ($uri_segments == base_url($item['url']))
                $is_active = 'class="active"';
            else
                $is_active = '';
            $wrap_body .= '<li ' . $is_active . '>';
            $wrap_body .= '<a href="' . base_url($item['url']) . '"><i class="fa ' . $item['icon'] . '"></i> ';
            $wrap_body .= '<span class="nav-label">' . strtoupper($item['label']) . '</span>';
            $wrap_body .= '</a>';
            $wrap_body .= '</li>';
        }
        return $wrap_open . $wrap_body . $wrap_close;
    }

    function format2levels($items, $submenu, $skin = NULL, $sideTitle = NULL, $sideColor = 'bg-blue', $sideIcon = 'fa fa-fw fa-tag')
    {
        $wrap_open = '<div class="sidebar-collapse bg-white">';
        $wrap_open .= '<ul class="nav metismenu bg-white" id="side-menu">';
        $wrap_close = '</ul>';
        $wrap_close .= '</div>';
        $wrap_body = '';

        $uri_segments = current_url(true);

        foreach ($items as $item) {
            $treeview = $item['treeview'];
            if ($treeview == '') {
                $id = '';
                $wrap_body .= '<li><a href="' . base_url($item['url']) . '"><span class="nav-label"><b>' . ($item['label']) . '</b></span></a></li>';
            } else {
                $sublist = $submenu[$treeview];
                $wrap_body .= '<li class="py-1"><a href="' . base_url($item['url']) . '"><span class="nav-label"><b>' . ($item['label']) . '</b></span> <span class="fa arrow"></span></a>';
                $wrap_body .= '<ul class="nav nav-second-level bg-white collapse in" style="margin-left: -20px">';
                foreach ($sublist as $subitem) {
                    if ($uri_segments == base_url($subitem['url']))
                        $is_active = 'active';
                    else
                        $is_active = '';
                    $id = str_replace(' ', '_', $subitem['label']);
                    $wrap_body .= '<li class="py-1 ' . $is_active . '"><a href="' . base_url($subitem['url']) . '"><i class="nav-icon fa ' . $subitem['icon'] . '"></i> <span class="nav-label">' . $subitem['label'] . '</span></a></li>';
                    $id = '';
                }
                $wrap_body .= '</ul></li>';
            }
            $id = '';
        }
        return $wrap_open . $wrap_body . $wrap_close;
    }

    function format3levels($items, $submenu, $subsubmenu)
    {
        $wrap_open = '<div class="sidebar-collapse bg-white">';
        $wrap_open .= '<ul class="nav metismenu bg-white" id="side-menu">';
        $wrap_close = '</ul></div>';
        $wrap_body = '';

        $uri_segments = current_url(true);

        foreach ($items as $item) {
            $treeview = $item['treeview'] ?? '';
            $hasSubmenu = $treeview != '' && isset($submenu[$treeview]);

            $wrap_body .= '<li>';
            $wrap_body .= '<a href="' . base_url($item['url']) . '" class="menu-item">';
            $wrap_body .= '<span class="nav-label"><b>' . $item['label'] . '</b></span>';
            if ($hasSubmenu) {
                $wrap_body .= ' <span class="fa arrow rotate"></span>';
            }
            $wrap_body .= '</a>';

            if ($hasSubmenu) {
                $wrap_body .= '<ul class="nav nav-second-level bg-white" style="display:block; margin-left:0;">';
                foreach ($submenu[$treeview] as $subitem) {
                    $subTree = $subitem['treeview'] ?? '';
                    $hasSubSub = $subTree != '' && isset($subsubmenu[$subTree]);

                    $third_level_html = '';
                    $third_level_active = false;

                    if ($hasSubSub) {
                        $third_level_html .= '<ul class="nav nav-third-level bg-white" style="display:none; padding-left:5px;">';
                        foreach ($subsubmenu[$subTree] as $subSubItem) {
                            $is_active_lvl3 = ($uri_segments == base_url($subSubItem['url']));
                            if ($is_active_lvl3) $third_level_active = true;

                            $third_level_html .= '<li class="py-1 ' . ($is_active_lvl3 ? 'active' : '') . '">';
                            $third_level_html .= '<a href="' . base_url($subSubItem['url']) . '" style="padding-left:50px;">';
                            $third_level_html .= '<i class="nav-icon f10 fa ' . $subSubItem['icon'] . '"></i> ' . $subSubItem['label'];
                            $third_level_html .= '</a></li>';
                        }
                        $third_level_html .= '</ul>';
                    }

                    if ($third_level_active) {
                        $third_level_html = str_replace('display:none', 'display:block', $third_level_html);
                    }

                    $is_active_lvl2 = ($uri_segments == base_url($subitem['url']) || $third_level_active) ? 'active' : '';

                    $wrap_body .= '<li class="py-1 ' . $is_active_lvl2 . '">';
                    $wrap_body .= '<a href="' . base_url($subitem['url']) . '" class="submenu-item" style="padding-left:30px;">';
                    $wrap_body .= '<i class="nav-icon fa ' . $subitem['icon'] . '"></i> ' . $subitem['label'];
                    if ($hasSubSub) {
                        $wrap_body .= ' <span class="fa arrow ' . ($third_level_active ? 'rotate' : '') . '"></span>';
                    }
                    $wrap_body .= '</a>';
                    $wrap_body .= $third_level_html;
                    $wrap_body .= '</li>';
                }
                $wrap_body .= '</ul>';
            }

            $wrap_body .= '</li>';
        }

        $wrap_body .= '
            <script>
                $(document).ready(function() {

                    // Niveau 3
                    $(".submenu-item").click(function(e){
                        var $next = $(this).next("ul.nav-third-level");
                        if($next.length){
                            e.preventDefault();

                            // Fermer tous les autres niveaux 3
                            $(".nav-third-level").not($next).slideUp();
                            $(".submenu-item").not(this).find(".fa.arrow").removeClass("rotate");

                            // Ouvrir ou fermer celui cliqué
                            $next.slideToggle();
                            $(this).find(".fa.arrow").toggleClass("rotate");
                        }
                    });

                    // Niveau 2
                    $(".menu-item").click(function(e){
                        var $next = $(this).next("ul.nav-second-level");
                        if($next.length){
                            e.preventDefault();
                            $next.slideToggle();
                            $(this).find(".fa.arrow").toggleClass("rotate");
                        }
                    });

                });
            </script>
            <style>
                .fa.arrow.rotate { transform: rotate(360deg); transition:0.3s; }
                .nav-second-level { margin-left:0; }
            </style>
        ';

        return $wrap_open . $wrap_body . $wrap_close;
    }

    function format4levels($items, $submenu, $subsubmenu, $subsubsubmenu)
    {
        $wrap_open = '<div class="sidebar-collapse bg-white">';
        $wrap_open .= '<ul class="nav metismenu bg-white" id="side-menu">';
        $wrap_close = '</ul></div>';
        $wrap_body = '';

        $uri_segments = current_url(true);

        foreach ($items as $item) {
            $treeview = $item['treeview'] ?? '';
            $hasSubmenu = $treeview != '' && isset($submenu[$treeview]);

            $wrap_body .= '<li>';
            $wrap_body .= '<a href="' . base_url($item['url']) . '" class="menu-item">';
            $wrap_body .= '<span class="nav-label"><b>' . $item['label'] . '</b></span>';
            if ($hasSubmenu) {
                $wrap_body .= ' <span class="fa arrow rotate"></span>';
            }
            $wrap_body .= '</a>';

            if ($hasSubmenu) {
                $wrap_body .= '<ul class="nav nav-second-level bg-white" style="display:block; margin-left:0;">';

                foreach ($submenu[$treeview] as $subitem) {
                    $subTree = $subitem['treeview'] ?? '';
                    $hasSubSub = $subTree != '' && isset($subsubmenu[$subTree]);

                    $third_level_html = '';
                    $third_level_active = false;

                    if ($hasSubSub) {
                        $third_level_html .= '<ul class="nav nav-third-level bg-white" style="display:none; padding-left:5px;">';

                        foreach ($subsubmenu[$subTree] as $subSubItem) {
                            $subSubTree = $subSubItem['treeview'] ?? '';
                            $hasLevel4 = $subSubTree != '' && isset($subsubsubmenu[$subSubTree]);

                            $fourth_level_html = '';
                            $fourth_level_active = false;

                            // ==== Niveau 4 ====
                            if ($hasLevel4) {
                                $fourth_level_html .= '<ul class="nav nav-fourth-level bg-white" style="display:none; padding-left:10px;">';
                                foreach ($subsubsubmenu[$subSubTree] as $lvl4Item) {
                                    $is_active_lvl4 = ($uri_segments == base_url($lvl4Item['url']));
                                    if ($is_active_lvl4) $fourth_level_active = true;

                                    $fourth_level_html .= '<li class="py-1 ' . ($is_active_lvl4 ? 'active' : '') . '" style="border-left:none;">';
                                    $fourth_level_html .= '<a href="' . base_url($lvl4Item['url']) . '" style="padding-left:55px;">';
                                    $fourth_level_html .= '<i class="nav-icon f10 fa ' . $lvl4Item['icon'] . '"></i> ' . $lvl4Item['label'];
                                    $fourth_level_html .= '</a></li>';
                                }
                                $fourth_level_html .= '</ul>';
                            }

                            if ($fourth_level_active) {
                                $fourth_level_html = str_replace('display:none', 'display:block', $fourth_level_html);
                            }

                            $is_active_lvl3 = ($uri_segments == base_url($subSubItem['url']) || $fourth_level_active);
                            if ($is_active_lvl3) $third_level_active = true;

                            $third_level_html .= '<li class="py-1 ' . ($is_active_lvl3 ? 'active' : '') . '">';
                            $third_level_html .= '<a href="' . base_url($subSubItem['url']) . '" class="subsubmenu-item" style="padding-left:50px;">';
                            $third_level_html .= '<i class="nav-icon f10 fa ' . $subSubItem['icon'] . '"></i> ' . $subSubItem['label'];
                            if ($hasLevel4) {
                                $third_level_html .= ' <span class="fa arrow ' . ($fourth_level_active ? 'rotate' : '') . '"></span>';
                            }
                            $third_level_html .= '</a>';
                            $third_level_html .= $fourth_level_html;
                            $third_level_html .= '</li>';
                        }

                        $third_level_html .= '</ul>';
                    }

                    if ($third_level_active) {
                        $third_level_html = str_replace('display:none', 'display:block', $third_level_html);
                    }

                    $is_active_lvl2 = ($uri_segments == base_url($subitem['url']) || $third_level_active) ? 'active' : '';

                    $wrap_body .= '<li class="py-1 ' . $is_active_lvl2 . '">';
                    $wrap_body .= '<a href="' . base_url($subitem['url']) . '" class="submenu-item" style="padding-left:30px;">';
                    $wrap_body .= '<i class="nav-icon fa ' . $subitem['icon'] . '"></i> ' . $subitem['label'];
                    if ($hasSubSub) {
                        $wrap_body .= ' <span class="fa arrow ' . ($third_level_active ? 'rotate' : '') . '"></span>';
                    }
                    $wrap_body .= '</a>';
                    $wrap_body .= $third_level_html;
                    $wrap_body .= '</li>';
                }

                $wrap_body .= '</ul>';
            }

            $wrap_body .= '</li>';
        }

        $wrap_body .= '
            <script>
                $(document).ready(function() {

                    // Niveau 4
                    $(".subsubmenu-item").click(function(e){
                        var $next = $(this).next("ul.nav-fourth-level");
                        if($next.length){
                            e.preventDefault();
                            $(".nav-fourth-level").not($next).slideUp();
                            $(".subsubmenu-item").not(this).find(".fa.arrow").removeClass("rotate");
                            $next.slideToggle();
                            $(this).find(".fa.arrow").toggleClass("rotate");
                        }
                    });

                    // Niveau 3
                    $(".submenu-item").click(function(e){
                        var $next = $(this).next("ul.nav-third-level");
                        if($next.length){
                            e.preventDefault();
                            $(".nav-third-level").not($next).slideUp();
                            $(".submenu-item").not(this).find(".fa.arrow").removeClass("rotate");
                            $next.slideToggle();
                            $(this).find(".fa.arrow").toggleClass("rotate");
                        }
                    });

                    // Niveau 2
                    $(".menu-item").click(function(e){
                        var $next = $(this).next("ul.nav-second-level");
                        if($next.length){
                            e.preventDefault();
                            $(".nav-second-level").not($next).slideUp();
                            $(".menu-item").not(this).find(".fa.arrow").removeClass("rotate");
                            $next.slideToggle();
                            $(this).find(".fa.arrow").toggleClass("rotate");
                        }
                    });

                });
            </script>
            <style>
                .fa.arrow.rotate { transform: rotate(360deg); transition:0.3s; }
                .nav-second-level { margin-left:0; }
                .nav-third-level { margin-left:0; }
                .nav-fourth-level { margin-left:0; }
            </style>
        ';

        return $wrap_open . $wrap_body . $wrap_close;
    }

    /*******************************************************************************************************************************/
    /************************************************  PAGE          ***************************************************************/
    /*******************************************************************************************************************************/
    function page()
    {

        if (isset($_SESSION['userdata']) && $_SESSION['userdata']['user_lang'] == 'fr') {
            $menu[] = array('label' => 'GERER MA PAGE', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'page');
            $menu[] = array('label' => 'PARAMETRES', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'settings');

            $submenu['page'][] = array('label' => 'Dashboard', 'icon' => 'fa fa-home', 'url' => 'page/manage/set/dashboard');
            // $submenu['page'][] = array('label' => 'Produits/Services', 'icon' => 'fa fa-list', 'url' => 'page/set/produits');

            $submenu['settings'][] = array('label' => 'Paramètres généraux', 'icon' => 'fa fa-cogs', 'url' => 'page/manage/set/setting');
            // $submenu['settings'][] = array('label' => 'Thème & Apparence', 'icon' => 'fa fa-image', 'url' => 'page/manage/set/theme');
        } else {
            $menu[] = array('label' => 'GERER MA PAGE', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'page');
            $menu[] = array('label' => 'PARAMETRES', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'settings');

            $submenu['page'][] = array('label' => 'Dashboard', 'icon' => 'fa fa-home', 'url' => 'page/manage/set/dashboard');
            // $submenu['page'][] = array('label' => 'Produits/Services', 'icon' => 'fa fa-list', 'url' => 'page/set/produits');

            $submenu['settings'][] = array('label' => 'Paramètres généraux', 'icon' => 'fa fa-cogs', 'url' => 'page/manage/set/setting');
            // $submenu['settings'][] = array('label' => 'Thème & Apparence', 'icon' => 'fa fa-image', 'url' => 'page/manage/set/theme');
        }

        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }


    /*******************************************************************************************************************************/
    /************************************************  MODULE ADMIN          *******************************************************/
    /*******************************************************************************************************************************/
    function admin()
    {

        $menu[] = array('label' => 'PARAMETRAGES', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'accounts');
        $menu[] = array('label' => 'MONITORING', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'monitoring');
        $menu[] = array('label' => 'REFERENTIELS', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'referentiel');
        $menu[] = array('label' => 'PEAGE', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'peage');
        $menu[] = array('label' => 'Q-LEADS', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'qleads');


        $submenu['accounts'][] = array('label' => 'Tableau de bord', 'icon' => 'fa fa-home', 'url' => 'admin/dashboard/set/dashboard');
        $submenu['accounts'][] = array('label' => 'Comptes utilisateurs', 'icon' => 'fa fa-users', 'url' => 'admin/users/set/users');
        $submenu['accounts'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa fa-home', 'url' => 'admin/accounts/set/comptes');
        $submenu['accounts'][] = array('label' => 'Frais bancaires', 'icon' => 'fa fa-cogs', 'url' => 'admin/fees/set/regles');
        $submenu['accounts'][] = array('label' => 'Agences bancaires', 'icon' => 'fa fa-cogs', 'url' => 'admin/branches/set/guichets');


        $submenu['referentiel'][] = array('label' => 'Bénéficiaire', 'icon' => 'fa fa-users', 'url' => 'admin/stakeholders/set/beneficiaries');
        $submenu['referentiel'][] = array('label' => 'Recettes', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/recettes');
        $submenu['referentiel'][] = array('label' => 'Services', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/services');
        $submenu['referentiel'][] = array('label' => 'Provinces/Ville', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/villes');

        // $submenu['referentiel'][] = array('label' => 'Gestion des accès', 'icon' => 'fa fa-users', 'url' => 'branch/rawbank/users/set/users');
        // $submenu['referentiel'][] = array('label' => 'Déblocage utilisateur', 'icon' => 'fa fa-users', 'url' => 'admin/account/set/unblocking');
        // $submenu['referentiel'][] = array('label' => 'Plateformes des régies', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/settings_regies');
        // $submenu['referentiel'][] = array('label' => 'Plateformes de la BCC', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/settings_bcc');

        $submenu['monitoring'][] = array('label' => 'Logs des intégrations', 'icon' => 'fa fa-users', 'url' => 'admin/admin/set/logs_integrations');
        $submenu['monitoring'][] = array('label' => 'Logs des opérations', 'icon' => 'fa fa-users', 'url' => 'admin/admin/set/logs_operations');

        $submenu['peage'][] = array('label' => 'Caisses', 'icon' => 'fa fa-cogs', 'url' => 'admin/caisses/set/caisses');
        $submenu['peage'][] = array('label' => 'Partenaires', 'icon' => 'fa fa-cogs', 'url' => 'admin/partners/set/partners');
        $submenu['peage'][] = array('label' => 'Events', 'icon' => 'fa fa-cogs', 'url' => 'admin/events/set/events');
        $submenu['peage'][] = array('label' => 'Cashbooks', 'icon' => 'fa fa-cogs', 'url' => 'admin/cashbooks/set/cashbooks');
        $submenu['peage'][] = array('label' => 'Pos', 'icon' => 'fa fa-cogs', 'url' => 'admin/pos/set/pos');
        $submenu['peage'][] = array('label' => 'Guichets', 'icon' => 'fa fa-cogs', 'url' => 'admin/counters/set/guichets');

        $submenu['qleads'][] = array('label' => 'Gestion de catégories', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/categories');
        $submenu['qleads'][] = array('label' => "Files d'attente", 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/queues');
        $submenu['qleads'][] = array('label' => 'Gestion équipements', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/equipments');
        $submenu['qleads'][] = array('label' => 'Utilisateurs autorisés', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/users');

        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function admin_logiref()
    {

        $functionalities = json_decode($_SESSION['userdata']['options'], true);

        $menu[] = array('label' => 'Accueil ...', 'icon' => 'fa-dashboard', 'url' => 'branch/taxdashboards/set/etax', 'treeview' => '');
        $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
        $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Suivi');
        //$menu[] = array('label' => 'Rapport ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Rapport');

        $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'branch/taxdashboards/set/etax');

        $submenu['Edition'][] = array('label' => 'Comptes utilisateurs', 'icon' => 'fa-circle', 'url' => 'admin/users/set/users');
        $submenu['Edition'][] = array('label' => 'Clients bancaires', 'icon' => 'fa fa-circle', 'url' => 'admin/bankcustomers/set/customers');
        $submenu['Edition'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-circle', 'url' => 'admin/accounts/set/comptes');
        $submenu['Edition'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-circle', 'url' => 'admin/fees/set/regles');
        $submenu['Edition'][] = array('label' => 'Frais pr&eacute;f&eacute;rentiels', 'icon' => 'fa-circle', 'url' => 'admin/accounts/set/tarification_accounts');
        $submenu['Edition'][] = array('label' => 'Agences bancaires', 'icon' => 'fa-circle', 'url' => 'admin/branches/set/guichets');
        $submenu['Edition'][] = array('label' => "Recettes", 'icon' => 'fa-circle', 'url' => 'admin/settings/set/recettes');
        $submenu['Edition'][] = array('label' => "Services", 'icon' => 'fa-circle', 'url' => 'admin/settings/set/services');
        $submenu['Edition'][] = array('label' => "Provinces/Villes", 'icon' => 'fa-circle', 'url' => 'admin/settings/set/villes');
        $submenu['Edition'][] = array('label' => 'Adresse IP bloqu&eacute;e', 'icon' => 'fa-circle', 'url' => 'admin/settings/set/ipaddress');
        $submenu['Edition'][] = array('label' => 'Fichier d\'intégration', 'icon' => 'fa-circle', 'url' => 'admin/admin/set/sftp');
        $submenu['Edition'][] = array('label' => 'Netbanking', 'icon' => 'fa-circle', 'url' => 'admin/subscriptions/set/subscriptions');

        if(array_key_exists('DGDA_payment_deletion_by_admin_user', $functionalities['ALL']))
        {
            $submenu['Suivi'][] = array('label' => 'Op&eacute;rations DGDA', 'icon' => 'fa-circle', 'url' => 'admin/admin/set/operations_dgda');
        }
        $submenu['Suivi'][] = array('label' => 'Logs des intégrations', 'icon' => 'fa-circle', 'url' => 'admin/admin/set/logs_integrations');
        $submenu['Suivi'][] = array('label' => 'Logs des opérations', 'icon' => 'fa-circle', 'url' => 'admin/admin/set/logs_operations');
        $submenu['Suivi'][] = array('label' => 'Logs des mails', 'icon' => 'fa-inbox', 'url' => 'monitoring/logs/mails');

        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function admin_etoll()
    {
        $menu[] = array('label' => 'Accueil', 'icon' => 'fa-caret-down', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
        $menu[] = array('label' => 'Edition', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Edition');
        $menu[] = array('label' => 'Suivis', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Suivis');
        $menu[] = array('label' => 'Monitoring', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'Monitoring');

        $submenu['Edition'][] = array('label' => 'Agences Bancaire', 'icon' => 'fa-circle', 'url' => 'etoll/branches/set/guichets');
        $submenu['Edition'][] = array('label' => 'Caisses Bancaire', 'icon' => 'fa-circle', 'url' => 'etoll/caisses/set/caisses');
        $submenu['Edition'][] = array('label' => 'Compte Bancaire', 'icon' => 'fa-circle', 'url' => 'etoll/accounts/set/comptes');
        $submenu['Edition'][] = array('label' => 'Gestion de partenaires', 'icon' => 'fa-circle', 'url' => 'etoll/partners/set/partners');
        $submenu['Edition'][] = array('label' => 'Gestion de Pos', 'icon' => 'fa-circle', 'url' => 'etoll/pos/set/pos');
        $submenu['Edition'][] = array('label' => 'Gestion de Tarif', 'icon' => 'fa-circle', 'url' => 'etoll/products/set/products');
        $submenu['Edition'][] = array('label' => 'Gestion Evenements', 'icon' => 'fa-circle', 'url' => 'etoll/events/set/events');
        $submenu['Edition'][] = array('label' => 'Gestion Carnets', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/cashbooks');
        $submenu['Edition'][] = array('label' => 'Points de vente', 'icon' => 'fa-circle', 'url' => 'etoll/counters/set/guichets');

        $submenu['Suivis'][] = array('label' => 'Habilitation', 'icon' => 'fa-circle', 'url' => 'etoll/users/set/privileges');

        $submenu['Monitoring'][] = array('label' => 'Logs des intégrations', 'icon' => 'fa-circle', 'url' => 'admin/etoll/set/logs_integrations');
        $submenu['Monitoring'][] = array('label' => 'Logs des opérations', 'icon' => 'fa-circle', 'url' => 'admin/etoll/set/logs_operations');

        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function admin_qleads()
    {

        $menu[] = array('label' => 'Q-LEADS', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'qleads');

        $submenu['qleads'][] = array('label' => 'Tableau de bord', 'icon' => 'fa fa-home', 'url' => 'admin/qleads/set/dashboard');
        $submenu['qleads'][] = array('label' => 'Gestion des catégories', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/categories');
        $submenu['qleads'][] = array('label' => "Files d'attente", 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/queues');
        $submenu['qleads'][] = array('label' => 'Gestion des équipements', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/equipments');
        $submenu['qleads'][] = array('label' => 'Gestion des multi-média', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/ads');
        $submenu['qleads'][] = array('label' => 'Géolocalisation des agences', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/localizations');
        $submenu['qleads'][] = array('label' => 'Gestion des surveys', 'icon' => 'fa fa-cogs', 'url' => 'admin/qleads/set/surveys');


        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function admin_referentiel()
    {

        $menu[] = array('label' => 'REFERENTIELS', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'referentiel');

        $submenu['referentiel'][] = array('label' => 'Tableau de bord', 'icon' => 'fa fa-home', 'url' => 'admin/referentiel/set/dashboard');
        $submenu['referentiel'][] = array('label' => 'Bénéficiaire', 'icon' => 'fa fa-users', 'url' => 'admin/stakeholders/set/beneficiaries');
        $submenu['referentiel'][] = array('label' => 'Recettes', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/recettes');
        $submenu['referentiel'][] = array('label' => 'Services', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/services');
        $submenu['referentiel'][] = array('label' => 'Provinces/Ville', 'icon' => 'fa fa-users', 'url' => 'admin/settings/set/villes');
        $submenu['referentiel'][] = array('label' => 'R&eacute;gions bancaires', 'icon' => 'fa fa-cogs', 'url' => 'admin/settings/set/regions');


        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function admin_auth()
    {
        $menu[] = array('label' => 'PARAMETRAGES', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'settings');
        $menu[] = array('label' => 'MONITORING', 'icon' => 'fa-caret-down', 'url' => '', 'treeview' => 'monitoring');

        $submenu['settings'][] = array('label' => 'Gestion habilitations', 'icon' => 'fa fa-circle', 'url' => 'admin/authorizations/set/authorizations');
        $submenu['settings'][] = array('label' => 'Gestion fonctionnalités', 'icon' => 'fa fa-circle', 'url' => 'admin/authorizations/set/functionnalities');

        $submenu['monitoring'][] = array('label' => 'Logs des intégrations', 'icon' => 'fa fa-cog', 'url' => 'admin/authorizations/set/logs_integrations');
        $submenu['monitoring'][] = array('label' => 'Logs des opérations', 'icon' => 'fa fa-cogs', 'url' => 'admin/authorizations/set/logs_operations');

        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
        return $html;
    }

    function logiref_quitus($role = NULL)
    {
        if ($role == 3 || $role == 2 || $role == 1)
        {
            $menu[] = array('label' => 'Accueil ...', 'icon' => 'fa fa-home', 'url' => 'quitus/dashboards/set/quitus', 'treeview' => '');
            $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Suivi');
            $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

            $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'quitus/dashboards/set/quitus');
            $submenu['Suivi'][] = array('label' => 'Quitus fiscal à valider', 'icon' => 'fa-circle', 'url' => 'quitus/quitus/set/nvalidated');

            $submenu['Rapport'][] = array('label' => 'Quitus fiscal en cours', 'icon' => 'fa-circle', 'url' => 'quitus/reports/set/quitus_current');
            $submenu['Rapport'][] = array('label' => 'Quitus fiscal expiré', 'icon' => 'fa fa-circle', 'url' => 'quitus/reports/set/quitus_expire');
        }
        elseif ($role == 4)
        {
            $menu[] = array('label' => 'Accueil ...', 'icon' => 'fa fa-home', 'url' => 'quitus/dashboards/set/quitus', 'treeview' => '');
            $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
            $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Suivi');
            $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

            $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'quitus/dashboards/set/quitus');
            $submenu['Edition'][] = array('label' => 'Contribuable', 'icon' => 'fa-circle', 'url' => 'quitus/quitus/set/client_fiscal');
            $submenu['Edition'][] = array('label' => 'Quitus fiscal', 'icon' => 'fa-circle', 'url' => 'quitus/quitus/set/quitus_fiscal');

            $submenu['Suivi'][] = array('label' => 'Quitus en attente', 'icon' => 'fa-circle', 'url' => 'quitus/quitus/set/nvalidated');

            $submenu['Rapport'][] = array('label' => 'Contribuable', 'icon' => 'fa-circle', 'url' => 'quitus/reports/set/client_fiscal');
            $submenu['Rapport'][] = array('label' => 'Quitus fiscal en cours', 'icon' => 'fa-circle', 'url' => 'quitus/reports/set/quitus_current');
            $submenu['Rapport'][] = array('label' => 'Quitus fiscal expiré', 'icon' => 'fa fa-circle', 'url' => 'quitus/reports/set/quitus_expire');
        }
        elseif ($role == 5 || $role == 6 || $role == 7 || $role == 8 || $role == 9 || $role == 10)
        {
            $menu[] = array('label' => 'Accueil ...', 'icon' => 'fa fa-home', 'url' => 'quitus/dashboards/set/quitus', 'treeview' => '');
            $menu[] = array('label' => 'Consultation ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Consultation');

            $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'quitus/dashboards/set/quitus');

            $submenu['Consultation'][] = array('label' => 'Contribuable', 'icon' => 'fa-circle', 'url' => 'quitus/reports/set/client_fiscal');
            $submenu['Consultation'][] = array('label' => 'Quitus fiscal en cours', 'icon' => 'fa-circle', 'url' => 'quitus/reports/set/quitus_current');
            $submenu['Consultation'][] = array('label' => 'Quitus fiscal expiré', 'icon' => 'fa fa-circle', 'url' => 'quitus/reports/set/quitus_expire');
        }

        $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-circle', 'url' => '/main/signout', 'treeview' => '');
        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");

        return $html;
    }

    function logiref_elicense()
    {
        $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'elicense/dashboards/set/start', 'treeview' => '');
        $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Edition');
        $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');

        $submenu['Edition'][] = array('label' => 'Paiement(s) Licence', 'icon' => 'fa-circle', 'url' => 'elicense/elicense/set/start');
        $submenu['Edition'][] = array('label' => 'Document(s) Licence', 'icon' => 'fa-circle', 'url' => 'elicense/elicense/set/document');

        $submenu['Suivi'][] = array('label' => 'Licences en cours', 'icon' => 'fa-circle', 'url' => 'elicense/reports/set/licences_current');
        $submenu['Suivi'][] = array('label' => 'Licences expir&eacute;es', 'icon' => 'fa-circle', 'url' => 'elicense/reports/set/licences_expire');

        $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-circle', 'url' => '/main/signout', 'treeview' => '');
        $html = $this->format2levels($menu, $submenu, NULL, "", "", "");

        return $html;
    }

    /*******************************************************************************************************************************/
    /************************************************  Sidebars Rawbank  *******************************************************/
    /*******************************************************************************************************************************/

    function logiref_etax($role = NULL)
    {
            $options = json_decode($_SESSION['userdata']['options'], true);

            $menu = array();
            $submenu = array();

            if ($role == 2)
            {
                    $menu[] = array('label' => 'Accueil ...', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/etax', 'treeview' => '');
                    //$menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'branch/taxdashboards/set/etax');

                    $submenu['Edition'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-circle', 'url' => 'admin/accounts/set/comptes');
                    $submenu['Edition'][] = array('label' => 'Frais bancaires', 'icon' => 'fa-circle', 'url' => 'admin/fees/set/regles');
                    $submenu['Edition'][] = array('label' => 'Frais pr&eacute;f&eacute;rentiels', 'icon' => 'fa-circle', 'url' => 'admin/accounts/set/tarification_accounts');
                    $submenu['Edition'][] = array('label' => 'Autres param&eacute;trages', 'icon' => 'fa-circle', 'url' => 'admin/settings/set/settings');

                    $submenu['Rapport'][] = array('label' => 'Autres rapports', 'icon' => 'fa-circle', 'url' => 'branch/taxreports/set/rapport');
                    $submenu['Rapport'][] = array('label' => 'Rapports r&eacute;f&eacute;rentiels', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/rapport');

            }
            elseif ($role == 3 || $role == 8)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Suivi'][] = array('label' => 'Paiements à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidated');

                    $immatriculationWebServiceValidation = isset($options['ALL']['license-plate-payment-validation-by-web-service'])
                            || isset($options['DGI']['license-plate-payment-validation-by-web-service']);

                    if(isset($options['ALL']['Validation-of-license-plate-payment-by-SIOP']) && !$immatriculationWebServiceValidation)
                    {
                        $submenu['Suivi'][] = array('label' => 'Intégration immatric', 'icon' => 'fa fa-circle', 'url' => 'branch/taximmatriculation/set/integration');
                    }

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Suivi'][] = array('label' => 'Bulletins prépayés', 'icon' => 'fa-circle', 'url' => 'branch/taxprepayments/set/integration');
                    }
                    else
                    {
                        $submenu['Suivi'][] = array('label' => 'Bulletins prépayés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxprepayments/set/prepayments');
                    }

                    $submenu['Suivi'][] = array('label' => 'Lot de bulletins', 'icon' => 'fa fa-circle', 'url' => 'branch/taxbulletin/set/batchs');

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Suivi'][] = array('label' => 'Bulletins comptants', 'icon' => 'fa fa-circle', 'url' => 'branch/taxbulletin/set/integration');
                    }

                    $submenu['Suivi'][] = array('label' => 'INV à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedimmatric');

                    $submenu['Suivi'][] = array('label' => 'Passeports à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedpassports');

                    if (array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                        $submenu['Suivi'][] = array('label' => 'Taxes provinciales', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedgnk');
                    }

                    if(isset($options['ALL']['bank-charges-attestation-printing'])):
                        $submenu['Suivi'][] = array('label' => 'Nouvelle impression', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/impressions');
                    endif;

                    if(isset($options['ALL']['dgda-payment-deletion-by-checker-user'])):
                        //$submenu['Suivi'][] = array('label' => 'Archivages DGDA', 'icon' => 'fa-circle', 'url' => 'admin/admin/set/operations_dgda');
                        $submenu['Suivi'][] = array('label' => 'Archivages DGDA', 'icon' => 'fa-circle', 'url' => 'branch/taxsettings/set/operations_dgda');
                    endif;

                    if(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions'])):
                       $submenu['Suivi'][] = array('label' => 'Bulletins en traitement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/treatments');
                    endif;

                    $submenu['Suivi'][] = array('label' => 'Reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated');
                    $submenu['Suivi'][] = array('label' => 'Reversements plaques', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated_plaques');
                    $submenu['Suivi'][] = array('label' => 'Regularisations', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/unequalized');
                    $submenu['Suivi'][] = array('label' => 'Regul. passeports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/unequalizedpassports');
                    $submenu['Suivi'][] = array('label' => 'ISYS passeports ', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validatedpassport');

                    $submenu['Rapport'][] = array('label' => 'Rapport des paiements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reports');
                    $submenu['Rapport'][] = array('label' => 'Rapport reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reversements');
                    $submenu['Rapport'][] = array('label' => 'Paiements reversés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');
                    $submenu['Rapport'][] = array('label' => 'Paiements régularisés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/equalized');
                    $submenu['Rapport'][] = array('label' => 'Rapport passports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/passports');

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Rapport'][] = array('label' => 'Paiements intégrés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/paiement_integrated');
                    }

            }
            elseif ($role == 4 || $role == 7)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    if(!array_key_exists('Enabling_rate_publishing_users', $options['ALL']))
                    {
                        $submenu['Edition'][] = array('label' => 'Editer un taux', 'icon' => 'fa fa-circle', 'url' => 'branch/taxrates/set/taux');
                    }
                    $submenu['Edition'][] = array('label' => 'Nouvel encaissement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxdashboards/set/etax');
                    if (array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                        $submenu['Edition'][] = array('label' => 'Taxes provinciales', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedgnk');
                    }
                    $submenu['Edition'][] = array('label' => 'Editer un encaissement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidated');
                    $submenu['Edition'][] = array('label' => 'Nouvelle impression', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/impressions');
                    $submenu['Edition'][] = array('label' => 'Pr&eacute;paiements extraits', 'icon' => 'fa fa-circle', 'url' => 'branch/taxprepayments/set/prepaymentlist');

                    $submenu['Suivi'][] = array('label' => 'Extraction paiements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxoffline/set/extractions');


                    if(!(isset($options['DGDA']['funds-reservation']) || isset($options['DGDA']['funds-reservation-with-instructions']))):
                        $submenu['Suivi'][] = array('label' => 'Bulletins en traitement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/treatments');
                    endif;

                    $submenu['Suivi'][] = array('label' => 'Bulletins en traitement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/batch_treatments_operator');

                    $submenu['Suivi'][] = array('label' => 'Bulletin non enregistré', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/unsaved');
                    $submenu['Suivi'][] = array('label' => 'Pr&eacute;paiements validés ', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/prepaidvalidated');
                    $submenu['Suivi'][] = array('label' => 'Paiements valid&eacute;s ', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/pending');
                    if (array_key_exists('provincial_tax_payments', $options['ALL'] ?? [])) {
                        $submenu['Suivi'][] = array('label' => 'Taxes provinciales', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/dgnkvalidated');
                    }
                    $submenu['Suivi'][] = array('label' => 'INV à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedimmatric');
                    $submenu['Suivi'][] = array('label' => 'Passeports valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validatedpassport');
                    $submenu['Suivi'][] = array('label' => 'Passeports non valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedpassports');
                    $submenu['Suivi'][] = array('label' => 'Reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated');

                    $submenu['Suivi'][] = array('label' => 'Paiements à regulariser', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/unequalized');
                    $submenu['Suivi'][] = array('label' => 'Comptabilisation du jour', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/situations');

                    $submenu['Rapport'][] = array('label' => 'Rapport des paiements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reports');
                    $submenu['Rapport'][] = array('label' => 'Rapport reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reversements');
                    $submenu['Rapport'][] = array('label' => 'Paiements reversés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');
                    $submenu['Rapport'][] = array('label' => 'Paiements régularisés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/equalized');
                    $submenu['Rapport'][] = array('label' => 'Paiements des passports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/paiements_passports');

            }
            elseif($role == 11)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Edition'][] = array('label' => 'Nouvel encaissement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxdashboards/set/etax');
                    $submenu['Edition'][] = array('label' => 'Editer un encaissement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidated');
                    $submenu['Edition'][] = array('label' => 'Nouvelle impression', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/impressions');

                    $submenu['Suivi'][] = array('label' => 'Passeports valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validatedpassport');
                    $submenu['Suivi'][] = array('label' => 'Passeports non valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedpassports');
                    $submenu['Rapport'][] = array('label' => 'Paiements des passports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/paiements_passports');
            }
            elseif ($role == 5)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Op&eacute;rations', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Consultation');
                    $menu[] = array('label' => 'Rapports', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Consultation'][] = array('label' => 'Paiements non valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidated');
                    $submenu['Consultation'][] = array('label' => 'Paiements valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/pending');
                    $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');

                    $submenu['Rapport'][] = array('label' => 'Rapport des paiements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reports');
                    $submenu['Rapport'][] = array('label' => 'Rapport taxes reversées', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/isysextract');
                    $submenu['Rapport'][] = array('label' => 'Paiement à reverser', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated');
                    $submenu['Rapport'][] = array('label' => 'Paiements régularisés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/equalized');

                    $submenu['Rapport'][] = array('label' => 'Rapport de commissions', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/commissions');
                    $submenu['Rapport'][] = array('label' => 'Retard de reversement', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/penalities');
                    $submenu['Rapport'][] = array('label' => 'Taux de change', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/list');
                    $submenu['Rapport'][] = array('label' => 'Autres rapports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/rapport');
            }
            elseif ($role == 6)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');

                    $menu[] = array('label' => 'Op&eacute;rations', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');
                    $menu[] = array('label' => 'Rapports', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Consultation'][] = array('label' => 'Paiements valid&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/pending');
                    $submenu['Consultation'][] = array('label' => 'Paiements revers&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');

                    $submenu['Rapport'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/comptes');
                    $submenu['Rapport'][] = array('label' => 'Grille tarifaire', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/commissions');
                    $submenu['Rapport'][] = array('label' => 'Utilisateurs', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/report_users');
                    $submenu['Rapport'][] = array('label' => 'Autres rapports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/rapport');
            }
            elseif ($role == 9 || $role == 10)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Edition'][] = array('label' => 'Editer un taux', 'icon' => 'fa fa-circle', 'url' => 'branch/taxrates/set/taux');
                    $submenu['Rapport'][] = array('label' => 'Taux publiés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxrates/set/list');
            }

            if (in_array((int) $role, [7, 8, 10], true)) {
                $submenu['Edition'][] = array('label' => 'Plaques a regulariser', 'icon' => 'fa fa-circle', 'url' => 'branch/taximmatriculationonline/set/payments_to_regularize');
                $submenu['Edition'][] = array('label' => 'Plaques a traiter', 'icon' => 'fa fa-circle', 'url' => 'branch/taximmatriculationonline/set/payments_to_treat');
                $submenu['Rapport'][] = array('label' => 'Inv a confirmer', 'icon' => 'fa fa-circle', 'url' => 'branch/taximmatriculation/set/inv_to_confirm');
            }
            $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
            return $html;
    }

    function logiref_etoll($role = NULL)
    {
            if ($role == 2)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Edition'][] = array('label' => 'Points de vente', 'icon' => 'fa-circle', 'url' => 'etoll/counters/set/guichets');
                    $submenu['Edition'][] = array('label' => 'Agences bancaires', 'icon' => 'fa-circle', 'url' => 'etoll/branches/set/guichets');
                    $submenu['Edition'][] = array('label' => 'Caisses bancaires', 'icon' => 'fa-circle', 'url' => 'etoll/caisses/set/caisses');
                    $submenu['Edition'][] = array('label' => 'Gestion tarif p&eacute;age', 'icon' => 'fa-circle', 'url' => 'etoll/products/set/products');
                    $submenu['Edition'][] = array('label' => 'Gestion des carnets', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/cashbooks');
                    $submenu['Edition'][] = array('label' => 'Gestion des &eacute;v&egrave;nement', 'icon' => 'fa-circle', 'url' => 'etoll/events/set/events');
                    $submenu['Edition'][] = array('label' => 'Gestion des tickets', 'icon' => 'fa-circle', 'url' => 'etoll/tickets/set/tickets');
                    $submenu['Edition'][] = array('label' => 'Autres param&eacute;trages', 'icon' => 'fa-circle', 'url' => 'etoll/settings/set/settings');
                    $submenu['Edition'][] = array('label' => 'Comptes bancaires', 'icon' => 'fa-circle', 'url' => 'etoll/accounts/set/comptes/settings');

                    $submenu['Rapport'][] = array('label' => 'Ventes des tickets', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/tickets');
                    $submenu['Rapport'][] = array('label' => 'Rapport de réconciliation', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/tolls');
                    $submenu['Rapport'][] = array('label' => 'Ventes des p&eacute;age Offline', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/toll_offline');
                    $submenu['Rapport'][] = array('label' => 'R&eacute;partition des partenaires', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/report_partners');
            }
            elseif ($role == 3)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Edition');

                    $submenu['Edition'][] = array('label' => 'Gestion des caisses', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/caisses_status');
                    $submenu['Edition'][] = array('label' => 'Suivi des paiements', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/tolls');
                    $submenu['Edition'][] = array('label' => 'Suivi des caisses', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/caisses_movements');
            }
            elseif ($role == 4)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Rapport');
                    $menu[] = array('label' => 'Param&egrave;trage ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Param&egrave;trage');

                    $submenu['Edition'][] = array('label' => 'P&eacute;age', 'icon' => 'fa-circle', 'url' => 'etoll/encaissement/set/toll');
                    $submenu['Edition'][] = array('label' => 'Nivellement (op&eacute;rations)', 'icon' => 'fa-circle', 'url' => 'etoll/encaissement/set/closing');

                    $submenu['Rapport'][] = array('label' => 'Ticket vendu (Esp&egrave;ce)', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/payment_toll');
                    $submenu['Rapport'][] = array('label' => 'Ticket vendu (Illicocash)', 'icon' => 'fa-circle', 'url' => 'etoll//reports/set/payment_toll/illicocash');
                    $submenu['Rapport'][] = array('label' => 'Ticket vendu (Carte)', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/payment_toll/carte');
                    $submenu['Rapport'][] = array('label' => 'R&eacute;gularisation', 'icon' => 'fa-circle', 'url' => 'etoll/equalize/set/toll_unequalized');
                    $submenu['Rapport'][] = array('label' => 'Rapport (Nivellement)', 'icon' => 'fa-circle', 'url' => 'etoll/reports/set/report_closing');

                    $submenu['Param&egrave;trage'][] = array('label' => 'Fermeture de la caisse', 'icon' => 'fa-circle', 'url' => 'etoll//rates/set/taux');
            }
            elseif ($role == 5)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Rapport', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Rapport'][] = array('label' => 'Ventes des tickets', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/tickets');
                    $submenu['Rapport'][] = array('label' => 'Rapport de réconciliation', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/tolls');
                    $submenu['Rapport'][] = array('label' => 'Ventes des p&eacute;age Offline', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/toll_offline');
                    $submenu['Rapport'][] = array('label' => 'R&eacute;partition des partenaires', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/report_partners');
            }
            elseif ($role == 6)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-circle', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Consultation', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Consultation');

                    $submenu['Consultation'][] = array('label' => 'Suivi des paiements', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/toll_partners');
            }
            elseif ($role == 7)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-circle', 'url' => 'etoll/dashboards/set/points', 'treeview' => '');
                    $menu[] = array('label' => 'Edition', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Consultation', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'Consultation');

                    $submenu['Edition'][] = array('label' => 'Annulation des paiements', 'icon' => 'fa fa-circle', 'url' => 'etoll/equalize/set/cancelling');

                    $submenu['Consultation'][] = array('label' => 'Gestion des caisses', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/caisses_status');
                    $submenu['Consultation'][] = array('label' => 'Suivi des paiements', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/tolls');
                    $submenu['Consultation'][] = array('label' => 'Suivi des caisses', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/caisses_movements');
                    $submenu['Consultation'][] = array('label' => 'Paiements annul&eacute;s', 'icon' => 'fa fa-circle', 'url' => 'etoll/reports/set/payment_cancelled');
            }

            $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-circle', 'url' => '/main/signout', 'treeview' => '');
            $html = $this->format2levels($menu, $submenu, NULL, "", "", "");

            return $html;
    }

    function logiref_seguce($role = NULL)
    {

            $functionalities = json_decode($_SESSION['userdata']['options'], true);

            if ($role == 3)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'eximtrade/dashboards/set/seguce', 'treeview' => '');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa-folder-open', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Rapport');
                    $subsubmenu = NULL;
                    $subsubsubmenu = NULL;

                    if(array_key_exists('eximtrade_new_facture_seguce', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Factures SEGUCE', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/nvalidated');
                    }

                    $submenu['Suivi'][] = array('label' => 'Provision des factures', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/provision');

                    if(!array_key_exists('eximtrade_provision_account',$functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Factures OCC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/nvalidated_occ');
                    }
                    else{
                        $submenu['Suivi'][] = array('label' => 'Factures OCC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/invoice_occ_batchs');
                    }

                    if(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Frais IS, ES, RC & EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }
                    elseif(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && !array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Frais IS, ES, RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }
                    elseif(!array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Prélèvement frais EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }

                    $submenu['Suivi'][] = array('label' => 'Regul des provisions', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/regul_provision');

                    if(!array_key_exists('eximtrade_transaction_on_cif_amount', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Extourne des provisions', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_provision');

                        if(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne (IS, RC, ES & EB)', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                        elseif(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && !array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne (IS, RC, ES)', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                        elseif(!array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                    }

                    $submenu['Suivi'][] = array('label' => 'Regularisation OCC', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/invoices_occ');

                    if(array_key_exists('eximtrade_new_facture_seguce', $functionalities['ALL']))
                    {
                        //$submenu['Suivi'][] = array('label' => 'Validation des factures', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/nvalidated_invoices');
                        $submenu['Suivi'][] = array('label' => 'Regularisation SEGUCE', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/seguce_invoices');
                        $submenu['Suivi'][] = array('label' => 'Regul. bordereaux', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/invoices');
                    }

                    $submenu['Rapport'][] = array('label' => 'Paiements factures OCC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_occ');

                    if(array_key_exists('eximtrade_new_facture_seguce', $functionalities['ALL']))
                    {
                        //$submenu['Suivi'][] = array('label' => 'Factures acquitées', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/invoices_paid');
                        $submenu['Rapport'][] = array('label' => 'F. SEGUCE non valid&eacute;es', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/report_invoices');
                        $submenu['Rapport'][] = array('label' => 'F. SEGUCE valid&eacute;es', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/validated_invoices');
                    }

                    if(array_key_exists('eximtrade_license_monitoring', $functionalities['ALL']))
                    {
                        $submenu['Rapport'][] = array('label' => 'Clients licence', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_customer');
                        $submenu['Rapport'][] = array('label' => 'Licences en cours', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'currentLicence');
                        $submenu['Rapport'][] = array('label' => 'Licences expir&eacute;es', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'expiredLicence');
                        $submenu['Rapport'][] = array('label' => 'Notifications licences', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicence');

                        $subsubmenu['currentLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current');
                        $subsubmenu['currentLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/is');
                        $subsubmenu['currentLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/es');
                        $subsubmenu['currentLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/rc');
                        $subsubmenu['currentLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/ib');
                        $subsubmenu['currentLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/eb');

                        $subsubmenu['expiredLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire');
                        $subsubmenu['expiredLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/is');
                        $subsubmenu['expiredLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/es');
                        $subsubmenu['expiredLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/rc');
                        $subsubmenu['expiredLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/ib');
                        $subsubmenu['expiredLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/eb');

                        $subsubmenu['notificationLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification');
                        $subsubmenu['notificationLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/is');
                        $subsubmenu['notificationLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/es');
                        $subsubmenu['notificationLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/rc');
                        $subsubmenu['notificationLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicenceIB');
                        $subsubmenu['notificationLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicenceEB');

                        $subsubsubmenu['notificationLicenceIB'][] = array('label' => 'Anticipatifs', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/ib/anticipatif');
                        $subsubsubmenu['notificationLicenceIB'][] = array('label' => 'Apurement', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/ib/apurement');

                        $subsubsubmenu['notificationLicenceEB'][] = array('label' => 'Rapatriements', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/eb/rapatriement');
                        $subsubsubmenu['notificationLicenceEB'][] = array('label' => 'Apurement', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/eb/apurement');
                    }
            }
            elseif ($role == 4)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa-dashboard', 'url' => 'eximtrade/dashboards/set/seguce', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Edition');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa-chevron-down', 'url' => '', 'treeview' => 'Rapport');
                    $subsubmenu = NULL;
                    $subsubsubmenu = NULL;


                    $submenu['Edition'][] = array('label' => 'Nouvel encaissement', 'icon' => 'fa fa-circle', 'url' => 'eximtrade/dashboards/set/invoices');
                    $submenu['Edition'][] = array('label' => 'Editer un encaissement', 'icon' => 'fa fa-circle', 'url' => 'eximtrade/reports/set/nvalidated');

                    if(array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        //$submenu['Edition'][] = array('label' => 'Frais EB & IB (Provision)', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/provision');
                    }
                    else{
                        //$submenu['Edition'][] = array('label' => 'Constitutions provisions', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/provision');
                    }

                    if(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']))
                    {
                        $submenu['Edition'][] = array('label' => 'Frais licence IS, ES et RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/prelevement');
                    }

                    //$submenu['Edition'][] = array('label' => 'Nouveau bordereau', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/invoice_occ_batch');

                    if(array_key_exists('eximtrade_new_facture_seguce', $functionalities['ALL']))
                    {
                        //$submenu['Edition'][] = array('label' => 'Facture SEGUCE', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/invoice');
                    }

                    #$submenu['Edition'][] = array('label' => 'Importation des provisions', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/provision_batch');

                    if(array_key_exists('eximtrade_license_monitoring', $functionalities['ALL']))
                    {
                        $submenu['Edition'][] = array('label' => 'Mise à jour licence', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/batchs');
                        $submenu['Edition'][] = array('label' => 'Nv. details licence', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/batch_details');
                        $submenu['Edition'][] = array('label' => 'Client licence', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/customer');
                        $submenu['Edition'][] = array('label' => 'Paiement|Rapatriement', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/elicense');
                        $submenu['Edition'][] = array('label' => 'Enreg. Documents', 'icon' => 'fa-circle', 'url' => 'eximtrade/elicense/set/document');
                    }

                    $submenu['Suivi'][] = array('label' => 'Provisions en cours', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/provision');

                    if(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Frais IS, ES, RC & EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }
                    elseif(!array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Prélèvement frais EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }
                    elseif(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && !array_key_exists('eximtrade_EB', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Frais IS, ES, RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/fees_licence');
                    }

                    if(array_key_exists('eximtrade_license_monitoring', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Clients licence', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_customer');
                        $submenu['Suivi'][] = array('label' => 'Licences en cours', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'currentLicence');
                        $submenu['Suivi'][] = array('label' => 'Licences expir&eacute;es', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'expiredLicence');
                        $submenu['Suivi'][] = array('label' => 'Notifications licences', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicence');

                        $subsubmenu['currentLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current');
                        $subsubmenu['currentLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/is');
                        $subsubmenu['currentLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/es');
                        $subsubmenu['currentLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/rc');
                        $subsubmenu['currentLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/ib');
                        $subsubmenu['currentLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_current/eb');

                        $subsubmenu['expiredLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire');
                        $subsubmenu['expiredLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/is');
                        $subsubmenu['expiredLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/es');
                        $subsubmenu['expiredLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/rc');
                        $subsubmenu['expiredLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/ib');
                        $subsubmenu['expiredLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/licences_expire/eb');

                        $subsubmenu['notificationLicence'][] = array('label' => 'TOUT', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification');
                        $subsubmenu['notificationLicence'][] = array('label' => 'IS', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/is');
                        $subsubmenu['notificationLicence'][] = array('label' => 'ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/es');
                        $subsubmenu['notificationLicence'][] = array('label' => 'RC', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/rc');
                        $subsubmenu['notificationLicence'][] = array('label' => 'IB', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicenceIB');
                        $subsubmenu['notificationLicence'][] = array('label' => 'EB', 'icon' => 'fa-circle', 'url' => '', 'treeview' => 'notificationLicenceEB');

                        $subsubsubmenu['notificationLicenceIB'][] = array('label' => 'Anticipatifs', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/ib/anticipatif');
                        $subsubsubmenu['notificationLicenceIB'][] = array('label' => 'Apurement', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/ib/apurement');

                        $subsubsubmenu['notificationLicenceEB'][] = array('label' => 'Rapatriements', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/eb/rapatriement');
                        $subsubsubmenu['notificationLicenceEB'][] = array('label' => 'Apurement', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_notification/eb/apurement');
                    }

                    $submenu['Suivi'][] = array('label' => 'Régularisations', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/regularize_invoices_occ');  
                    $submenu['Suivi'][] = array('label' => 'Regularisation factures', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/seguce_invoices');
                    if(!array_key_exists('eximtrade_transaction_on_cif_amount', $functionalities['ALL']))
                    {
                        $submenu['Suivi'][] = array('label' => 'Extourne des provisions', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_provision');

                        if(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne (IS,RC,ES & EB)', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                        elseif(array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && !array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne IS,RC,ES', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                        elseif(!array_key_exists('eximtrade_IS_ES_RC', $functionalities['ALL']) && array_key_exists('eximtrade_EB', $functionalities['ALL']))
                        {
                            $submenu['Suivi'][] = array('label' => 'Extourne EB', 'icon' => 'fa-circle', 'url' => 'eximtrade/equalize/set/extourne_fees');
                        }
                    }

                    $submenu['Suivi'][] = array('label' => 'Bordereaux factures', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/invoice_occ_batchs');

                    $submenu['Rapport'][] = array('label' => 'Factures', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/invoice_license');
                    $submenu['Rapport'][] = array('label' => 'Bordereau', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/report_occ');
                    $submenu['Rapport'][] = array('label' => 'Répartition (OCC & BIVAC)', 'icon' => 'fa-circle', 'url' => 'eximtrade/reports/set/invoice_occ');

                    if(array_key_exists('eximtrade_new_facture_seguce', $functionalities['ALL']))
                    {
                        $submenu['Rapport'][] = array('label' => 'F. SEGUCE non valid&eacute;es', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/report_invoices');
                        $submenu['Rapport'][] = array('label' => 'F. SEGUCE valid&eacute;es', 'icon' => 'fa-circle', 'url' => 'eximtrade/seguce/set/validated_invoices');
                    }
            }

            $menu[] = array('label' => 'Se d&eacute;connecter', 'icon' => 'fa-circle', 'url' => '/main/signout', 'treeview' => '');
            $html = $this->format4levels($menu, $submenu, $subsubmenu, $subsubsubmenu);

            return $html;
    }

    function logiref_payroll($role = NULL)
    {

            if ($role == 4)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'payroll/dashboards/set/overview', 'treeview' => 'Accueil');
                    $menu[] = array('label' => 'Nouveau ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Nouveau');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'payroll/dashboards/set/overview');

                    $submenu['Nouveau'][] = array('label' => 'R&eacute;cup&eacute;ration des fichiers', 'icon' => 'fa-circle', 'url' => 'payroll/bank/set/files');
                    $submenu['Rapport'][] = array('label' => 'Rapport des fichiers', 'icon' => 'fa-circle', 'url' => 'payroll/reports/set/files');
            }
            elseif($role==3)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'payroll/dashboards/set/overview', 'treeview' => 'Accueil');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Accueil'][] = array('label' => 'Tableau de bord', 'icon' => 'fa-circle', 'url' => 'payroll/dashboards/set/overview');

                    $submenu['Suivi'][] = array('label' => 'Fichiers à valider', 'icon' => 'fa-circle', 'url' => 'payroll/bank/set/nvalidated');
                    $submenu['Suivi'][] = array('label' => 'Fichiers en régularization', 'icon' => 'fa-circle', 'url' => 'payroll/bank/set/equalize');
                    $submenu['Rapport'][] = array('label' => 'Rapport des fichiers', 'icon' => 'fa-circle', 'url' => 'payroll/reports/set/files');
            }
            $html = $this->format2levels($menu, $submenu, NULL, "", "", "");
            return $html;
    }

    public function logiref_immatriculation($role=null)
    {
            $options = json_decode($_SESSION['userdata']['options'], true);

            if ($role == 3)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'branch/taxdashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Suivi'][] = array('label' => 'Paiements à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidated');

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Suivi'][] = array('label' => 'Bulletins prépayés', 'icon' => 'fa-circle', 'url' => 'branch/taxprepayments/set/integration');
                    }
                    else
                    {
                        $submenu['Suivi'][] = array('label' => 'Bulletins prépayés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxprepayments/set/prepayments');
                    }

                    $submenu['Suivi'][] = array('label' => 'Lot de bulletins', 'icon' => 'fa fa-circle', 'url' => 'branch/taxbulletin/set/batchs');

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Suivi'][] = array('label' => 'Bulletins comptants', 'icon' => 'fa fa-circle', 'url' => 'branch/taxbulletin/set/integration');
                    }

                    $submenu['Suivi'][] = array('label' => 'Passeports à valider', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/nvalidatedpassports');

                    if(array_key_exists('provincial_tax_payments', $options['ALL'])){
                        $submenu['Suivi'][] = array('label' => 'Note DGRK & DGPEK', 'icon' => 'fa-circle', 'url' => 'branch/taxreports/set/dgnkvalidated');
                    }

                    if(isset($options['ALL']['bank-charges-attestation-printing'])):
                        $submenu['Suivi'][] = array('label' => 'Nouvelle impression', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/impressions');
                    endif;

                    $submenu['Suivi'][] = array('label' => 'Reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated');
                    $submenu['Suivi'][] = array('label' => 'Reversements plaques', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validated_plaques');
                    $submenu['Suivi'][] = array('label' => 'Regularisations', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/unequalized');
                    $submenu['Suivi'][] = array('label' => 'Regul. passeports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/unequalizedpassports');
                    $submenu['Suivi'][] = array('label' => 'ISYS passeports ', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/validatedpassport');

                    $submenu['Rapport'][] = array('label' => 'Rapport des paiements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reports');
                    $submenu['Rapport'][] = array('label' => 'Rapport reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reversements');
                    $submenu['Rapport'][] = array('label' => 'Paiements reversés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');
                    $submenu['Rapport'][] = array('label' => 'Paiements régularisés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/equalized');
                    $submenu['Rapport'][] = array('label' => 'Rapport passports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/passports');

                    if(isset($options['DGDA']['breakdown-accounting-by-sftp-file-integration'])){
                        $submenu['Rapport'][] = array('label' => 'Paiements intégrés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/paiement_integrated');
                    }

            }
            elseif ($role == 4)
            {
                    $menu[] = array('label' => 'Accueil', 'icon' => 'fa fa-home', 'url' => 'immatriculation/dashboards/set/overview', 'treeview' => '');
                    $menu[] = array('label' => 'Edition ...', 'icon' => 'fa fa-pencil', 'url' => '', 'treeview' => 'Edition');
                    // $menu[] = array('label' => 'Suivi ...', 'icon' => 'fa fa-history', 'url' => '', 'treeview' => 'Suivi');
                    $menu[] = array('label' => 'Rapport ...', 'icon' => 'fa fa-list-alt', 'url' => '', 'treeview' => 'Rapport');

                    $submenu['Edition'][] = array('label' => 'Nouvel encaissement', 'icon' => 'fa fa-circle', 'url' => 'immatriculation/bank/set/encaissement');

                    $submenu['Rapport'][] = array('label' => 'Rapport des paiements', 'icon' => 'fa fa-circle', 'url' => 'immatriculation/bank/set/reports');
                    // $submenu['Rapport'][] = array('label' => 'Rapport reversements', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/reversements');
                    // $submenu['Rapport'][] = array('label' => 'Paiements reversés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/transferred');
                    // $submenu['Rapport'][] = array('label' => 'Paiements régularisés', 'icon' => 'fa fa-circle', 'url' => 'branch/taxequalize/set/equalized');
                    // $submenu['Rapport'][] = array('label' => 'Paiements des passports', 'icon' => 'fa fa-circle', 'url' => 'branch/taxreports/set/paiements_passports');

            }

            $html = $this->format2levels($menu, $submenu, NULL, "", "", "");

            return $html;
    }

}
