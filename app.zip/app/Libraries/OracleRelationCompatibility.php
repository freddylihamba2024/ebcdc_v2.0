<?php
namespace App\Libraries;

/** Optional Oracle CLOB comparison when loading a bank user's module privileges. */
class OracleRelationCompatibility
{
    public const OPTION = 'oracle-compatible-relation-modules';
    public const LABEL = 'Adapter la comparaison des modules des droits à Oracle';

    public static function enabled(string $driver, array $userdata, $accountId): bool
    {
        if ($driver !== 'OCI8' || (string) ($userdata['account_id'] ?? '') !== (string) $accountId || (string) $accountId === '') {
            return false;
        }
        $options = json_decode($userdata['options'] ?? '', true);
        $value = $options['ALL'][self::OPTION] ?? false;
        return in_array($value, [self::LABEL, true, 1, '1'], true);
    }

}
