<?php

namespace App\Libraries\ExternalAuth;

interface ExternalAuthInterface
{
    public function authenticate(string $username, string $password): bool;

    public function testConnection(): bool;

    public function getLastError(): ?string;
}
