<?php

namespace App\Libraries\ExternalAuth;

class GatewayDriver implements ExternalAuthInterface
{
    private array $config;
    private ?string $lastError = null;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function authenticate(string $username, string $password): bool
    {
        $this->lastError = null;

        if ($username === '' || $password === '') {
            $this->lastError = 'Username or password is empty.';
            return false;
        }

        $baseUrl  = rtrim((string) ($this->config['gateway_base_url'] ?? ''), '/');
        $endpoint = (string) ($this->config['gateway_validate_endpoint'] ?? '/api/v1/user/validate-user');
        $appId    = (string) ($this->config['gateway_appid'] ?? '');
        $appKey   = (string) ($this->config['gateway_appkey'] ?? '');
        $country  = (string) ($this->config['gateway_country_id'] ?? '');
        $timeout  = (int) ($this->config['gateway_timeout'] ?? 10);
        $verify   = ((string) ($this->config['gateway_ssl_verify'] ?? '1')) !== '0';

        if ($baseUrl === '' || $appId === '' || $appKey === '' || $country === '') {
            $this->lastError = 'Gateway config is incomplete.';
            return false;
        }

        if (!str_starts_with(strtolower($baseUrl), 'https://')) {
            $this->lastError = 'Gateway URL must use HTTPS.';
            return false;
        }

        $payload = [
            'RequestId' => bin2hex(random_bytes(8)),
            'CountryId' => $country,
            'Username'  => $username,
            'Password'  => base64_encode($password),
        ];

        $res = $this->postJson(
            $baseUrl . '/' . ltrim($endpoint, '/'),
            $payload,
            [
                'AppId: ' . $appId,
                'AppKey: ' . $appKey,
            ],
            $timeout,
            $verify
        );

        if (!$res['ok']) {
            $this->lastError = $res['error'];
            return false;
        }

        $body = $res['body'];
        if (!isset($body['ResponseCode'])) {
            $this->lastError = 'Invalid gateway response.';
            return false;
        }

        if ((string) $body['ResponseCode'] !== '00') {
            $this->lastError = (string) ($body['ResponseMessage'] ?? 'Authentication failed');
            return false;
        }

        return true;
    }

    public function testConnection(): bool
    {
        $this->lastError = null;

        $baseUrl  = rtrim((string) ($this->config['gateway_base_url'] ?? ''), '/');
        $endpoint = (string) ($this->config['gateway_validate_endpoint'] ?? '/api/v1/user/validate-user');
        $appId    = (string) ($this->config['gateway_appid'] ?? '');
        $appKey   = (string) ($this->config['gateway_appkey'] ?? '');
        $country  = (string) ($this->config['gateway_country_id'] ?? '');
        $timeout  = (int) ($this->config['gateway_timeout'] ?? 10);
        $verify   = ((string) ($this->config['gateway_ssl_verify'] ?? '1')) !== '0';

        if ($baseUrl === '' || $appId === '' || $appKey === '' || $country === '') {
            $this->lastError = 'Gateway config is incomplete.';
            return false;
        }

        if (!str_starts_with(strtolower($baseUrl), 'https://')) {
            $this->lastError = 'Gateway URL must use HTTPS.';
            return false;
        }

        $payload = [
            'RequestId' => bin2hex(random_bytes(8)),
            'CountryId' => $country,
            'Username'  => '__connectivity_check__',
            'Password'  => base64_encode('__invalid__'),
        ];

        $res = $this->postJson(
            $baseUrl . '/' . ltrim($endpoint, '/'),
            $payload,
            [
                'AppId: ' . $appId,
                'AppKey: ' . $appKey,
            ],
            $timeout,
            $verify
        );

        if (!$res['ok']) {
            $this->lastError = $res['error'];
            return false;
        }

        $body = $res['body'];
        if (!isset($body['ResponseCode'])) {
            $this->lastError = 'Gateway reachable but response format is invalid.';
            return false;
        }

        return true;
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    private function postJson(string $url, array $payload, array $headers, int $timeout, bool $verify): array
    {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'error' => 'cURL extension is not enabled.', 'body' => null];
        }

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge([
            'Content-Type: application/json',
            'Accept: application/json',
        ], $headers));
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $verify);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $verify ? 2 : 0);

        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($raw === false) {
            return ['ok' => false, 'error' => 'Gateway request failed: ' . $err, 'body' => null];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return ['ok' => false, 'error' => 'Gateway returned non-JSON response (HTTP ' . $code . ').', 'body' => null];
        }

        return ['ok' => true, 'error' => null, 'body' => $decoded];
    }
}
