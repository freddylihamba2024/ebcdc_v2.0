<?php

namespace App\Libraries\ExternalAuth;

class LdapDriver implements ExternalAuthInterface
{
    private array $config;
    private ?string $lastError = null;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function authenticate(string $username, string $password): bool
    {
        $this->lastError = null;

        if (!function_exists('ldap_connect')) {
            $this->lastError = 'php_ldap extension is not enabled.';
            return false;
        }

        if ($username === '' || $password === '') {
            $this->lastError = 'Username or password is empty.';
            return false;
        }

        $driver = strtolower((string) ($this->config['driver'] ?? 'ldap'));
        $scheme = $driver === 'ldaps' ? 'ldaps' : 'ldap';
        $server = trim((string) ($this->config['ldap_server'] ?? ''));
        $port   = (int) ($this->config['ldap_port'] ?? ($scheme === 'ldaps' ? 636 : 389));
        $baseDn = trim((string) ($this->config['ldap_basedn'] ?? ''));
        $format = trim((string) ($this->config['ldap_username_format'] ?? 'upn'));

        if ($server === '' || $baseDn === '') {
            $this->lastError = 'LDAP server or base DN is missing.';
            return false;
        }

        if (!preg_match('#^ldaps?://#i', $server)) {
            $server = $scheme . '://' . $server;
        }

        $uri = $this->buildUri($server, $port);

        try {
            if ($scheme === 'ldaps') {
                $this->configureTls();
            }

            $conn = @ldap_connect($uri);

            if ($conn === false || $conn === null) {
                $this->lastError = 'Could not connect to LDAP server.';
                return false;
            }

            ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, 8);

            $bindDn = $this->buildBindDn($username, $server, $baseDn, $format);
            $ok     = @ldap_bind($conn, $bindDn, $password);

            if (!$ok) {
                $this->lastError = ldap_error($conn);
                @ldap_unbind($conn);
                return false;
            }

            @ldap_unbind($conn);
            return true;
        } catch (\Throwable $e) {
            $this->lastError = $e->getMessage();
            return false;
        }
    }

    public function testConnection(): bool
    {
        $this->lastError = null;

        if (!function_exists('ldap_connect')) {
            $this->lastError = 'php_ldap extension is not enabled.';
            return false;
        }

        $driver = strtolower((string) ($this->config['driver'] ?? 'ldap'));
        $scheme = $driver === 'ldaps' ? 'ldaps' : 'ldap';
        $server = trim((string) ($this->config['ldap_server'] ?? ''));
        $port   = (int) ($this->config['ldap_port'] ?? ($scheme === 'ldaps' ? 636 : 389));

        if ($server === '') {
            $this->lastError = 'LDAP server is missing.';
            return false;
        }

        if (!preg_match('#^ldaps?://#i', $server)) {
            $server = $scheme . '://' . $server;
        }

        $uri = $this->buildUri($server, $port);

        try {
            if ($scheme === 'ldaps') {
                $this->configureTls();
            }

            $conn = @ldap_connect($uri);
            if ($conn === false || $conn === null) {
                $this->lastError = 'Could not reach LDAP server.';
                return false;
            }

            ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, 5);

            $bind  = @ldap_bind($conn);
            $errNo = ldap_errno($conn);
            @ldap_unbind($conn);

            return ($bind !== false || $errNo === 49);
        } catch (\Throwable $e) {
            $this->lastError = $e->getMessage();
            return false;
        }
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    private function configureTls(): void
    {
        $caCert = trim((string) ($this->config['ldap_tls_cacert'] ?? ''));
        if ($caCert !== '') {
            putenv('LDAPTLS_CACERT=' . $caCert);
            ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_DEMAND);
        } else {
            ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_HARD);
        }
    }

    private function buildUri(string $server, int $port): string
    {
        $server = rtrim($server, '/');
        $server = preg_replace('/:\\d+$/', '', $server);
        return $server . ':' . $port;
    }

    private function buildBindDn(string $username, string $server, string $baseDn, string $format): string
    {
        if ($format === 'upn') {
            if (strpos($username, '@') !== false) {
                return $username;
            }
            $domain = $this->extractDomainFromServer($server);
            return $username . ($domain ? '@' . $domain : '');
        }

        if ($format === 'uid') {
            return 'uid=' . $username . ',' . $baseDn;
        }

        $netbios = $this->extractNetbiosFromBaseDn($baseDn);
        if ($netbios) {
            return strtoupper($netbios) . '\\\\' . $username;
        }

        return $username;
    }

    private function extractDomainFromServer(string $server): ?string
    {
        $host = preg_replace('#^ldaps?://#i', '', $server);
        $host = strtok((string) $host, ':');
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return null;
        }
        return $host ?: null;
    }

    private function extractNetbiosFromBaseDn(string $baseDn): ?string
    {
        if (preg_match('/DC=([^,]+)/i', $baseDn, $m)) {
            return strtoupper($m[1]);
        }
        return null;
    }
}
