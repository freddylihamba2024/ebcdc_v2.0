<?php
namespace App\Libraries;

/** Oracle technical switches are managed by the bank's database selection. */
class OracleBankOptions
{
    public static function isManaged(string $key): bool
    {
        return strpos($key, 'oracle-') === 0;
    }

    public static function builtIn(): array
    {
        return [
            OracleRelationCompatibility::OPTION => OracleRelationCompatibility::LABEL,
            OracleRateConfirmation::OPTION => OracleRateConfirmation::LABEL,
            OraclePaymentPersistence::OPTION => OraclePaymentPersistence::LABEL,
        ];
    }

    public static function apply(string $engine, array $functions, array $catalogue = []): array
    {
        if (!in_array($engine, ['mysql', 'oracle'], true)) {
            throw new \InvalidArgumentException('Invalid database engine.');
        }
        foreach ($functions as &$group) {
            if (!is_array($group)) continue;
            foreach (array_keys($group) as $key) {
                if (self::isManaged((string) $key)) unset($group[$key]);
            }
        }
        unset($group);
        $functions['ALL']['database_engine'] = $engine;
        if ($engine === 'oracle') {
            foreach (array_replace($catalogue, self::builtIn()) as $key => $label) {
                if (self::isManaged((string) $key)) $functions['ALL'][$key] = $label;
            }
        }
        return $functions;
    }
}
