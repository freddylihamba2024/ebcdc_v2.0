<?php
namespace App\Libraries;

use Config\Database;

/** Select the server's database before any login/profile lookup. */
class BankDatabaseRouter
{
    private static ?array $context = null;

    public static function engine(): string
    {
        $engine = strtolower(trim((string) env('LOGIREF_DB_ENGINE', 'mysql')));
        if (!in_array($engine, ['mysql', 'oracle'], true)) {
            throw new \RuntimeException('Unsupported LOGIREF_DB_ENGINE: ' . $engine . '. Supported engines: mysql, oracle.');
        }
        return $engine;
    }

    public static function directory()
    {
        return Database::connect(self::group('ikwook_logiref_main'));
    }

    public static function reset(): void
    {
        self::$context = null;
        unset($_SESSION['bank_database'], $_SESSION['otp_user_connected']);
    }

    // Compatibility for callers of the previous per-bank selection API.
    public static function driverFromOptions(?string $json): string
    {
        return self::engine();
    }

    public static function selectLogin(string $login): bool
    {
        self::reset();
        unset($_SESSION['userdata']);
        $engine = self::engine();
        if ($engine === 'oracle' && !extension_loaded('oci8')) {
            throw new \RuntimeException('OCI8 is required for LOGIREF_DB_ENGINE=oracle.');
        }
        $profile = self::directory()->table('main_profiles')
            ->select('Account_3')->where('Identifier_7', $login)->get()->getRow();
        if (!$profile) return false;
        self::$context = ['account_id' => (string) $profile->Account_3, 'engine' => $engine];
        return true;
    }

    public static function matchesAccount($account): bool
    {
        $context = self::$context ?? ($_SESSION['bank_database'] ?? null);
        $expected = $context['account_id'] ?? ($_SESSION['userdata']['account_id'] ?? null);
        return $expected !== null && (string) $expected === (string) $account;
    }

    public static function confirm($account): void
    {
        if (!self::$context || self::$context['account_id'] !== (string) $account) {
            throw new \RuntimeException('Authenticated bank differs from the login directory.');
        }
        $_SESSION['bank_database'] = self::$context;
    }

    public static function group(string $group): string
    {
        $engine = self::engine();
        if ($group === 'mysql_directory') $group = 'ikwook_logiref_main';
        if (strpos($group, 'ikwook_') === 0) {
            if ($engine === 'mysql') return $group;
            $target = 'oracle_' . substr($group, strlen('ikwook_'));
            if (!isset(config(Database::class)->{$target})) {
                throw new \RuntimeException('Oracle connection group is not configured: ' . $target);
            }
            return $target;
        }
        if ($engine === 'mysql' && strpos($group, 'oracle_') === 0) {
            throw new \RuntimeException('Oracle connection requested while LOGIREF_DB_ENGINE=mysql.');
        }
        return $group;
    }

    public static function normalizeOptions($options)
    {
        if ($options && isset($options->Functionnalities_9)) {
            $functions = json_decode($options->Functionnalities_9 ?: '{}', true, 512, JSON_THROW_ON_ERROR);
            $options->Functionnalities_9 = json_encode(OracleBankOptions::apply(self::engine(), $functions));
        }
        return $options;
    }
}
