<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;
use App\Filters\BeforeLogiref;
use App\Filters\BeforeQleads;
use App\Filters\BeforeSbbos;
use App\Filters\BeforeQuitusFiscale;
use App\Filters\BeforeElicense;
use App\Filters\HttpRateLimit;
use App\Filters\TrackUserActions;

class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     */
    public array $aliases = [
        'cors'                  => \Fluent\Cors\Filters\CorsFilter::class,
        'csrf'                  => CSRF::class,
        'toolbar'               => DebugToolbar::class,
        'honeypot'              => Honeypot::class,
        'invalidchars'          => InvalidChars::class,
        'secureheaders'         => SecureHeaders::class,
        'beforelogiref'         => BeforeLogiref::class,
        'beforeqleads'          => BeforeQleads::class,
        'beforesbbos'           => BeforeSbbos::class,
        'beforequitusfiscale'   => BeforeQuitusFiscale::class,
        'trackuseractions'      => TrackUserActions::class,
        'beforeElicense'        => BeforeElicense::class
        //'ratelimit' => HttpRateLimit::class
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     */
    public array $globals = [
        'before' => [
            //'ratelimit'
            //'excludeServices',
            //'csrf',
            // 'honeypot',
            // 'invalidchars',
        ],
        'after' => [
            //'toolbar',
            // 'honeypot',
            // 'secureheaders',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     *
     * Example:
     * 'post' => ['foo', 'bar']
     *
     * If you use this, you should disable auto-routing because auto-routing
     * permits any HTTP method to access a controller. Accessing the controller
     * with a method you don't expect could bypass the filter.
     */
    public $methods = [
        // 'post' => ['csrf'],
        // 'put'  => ['csrf'],
        // 'delete' => ['csrf']
    ];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     *
     * Example:
     * 'isLoggedIn' => ['before' => ['account/*', 'profiles/*']]
     */
    public array $filters = [
        // 'csrf' => ['before'     => ['admin/*', 'branch/*', 'eximtrade/*', 'etoll/*']],
        'beforelogiref'         => ['before' => ['admin/*', 'branch/*', 'eximtrade/*']],
        'beforeqleads'          => ['before' => ['qleads/*']],
        'beforesbbos'           => ['before' => ['etoll/*']],
        'beforequitusfiscale'   => ['before' => ['quitus/*']],
        'beforeElicense'        => ['before' => ['elicense/*']],
        'trackuseractions'      => ['after' => ['main/*','admin/*','branch/*', 'eximtrade/*']],
        // 'authorization'       => ['before' => ['admin/*', 'branch/*']],
    ];
}