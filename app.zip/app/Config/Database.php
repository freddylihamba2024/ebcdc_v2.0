<?php

namespace Config;

use CodeIgniter\Database\Config;

/**
 * Database Configuration
 */
class Database extends Config
{
    /**
     * The directory that holds the Migrations
     * and Seeds directories.
     */
    public string $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    /**
     * Lets you choose which connection group to
     * use if no other is specified.
     */
    public string $defaultGroup = 'ikwook_logiref_main';

    /**
     * The default database connection.
     */
    public array $ikwook_logiref_main = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_main',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_transactions = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_transactions',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_reporting = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_reporting',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_payments_gateway = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_payments_gateway',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_etoll = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_etoll',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_elicence = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_elicence',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_qleads = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_qleads',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_quitus = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_quitus',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_logiref_payroll = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_logiref_payroll',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];

    public array $ikwook_mcf_gateway = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => 'root',
        'password' => 'root',
        'database' => 'ikwook_mcf_gateway',
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 3306,
    ];
    /**
     * This database connection is used when
     * running PHPUnit database tests.
     */
    public array $tests = [
        'DSN'         => '',
        'hostname'    => '127.0.0.1',
        'username'    => '',
        'password'    => '',
        'database'    => ':memory:',
        'DBDriver'    => 'SQLite3',
        'DBPrefix'    => 'db_',  // Needed to ensure we're working correctly with prefixes live. DO NOT REMOVE FOR CI DEVS
        'pConnect'    => false,
        'DBDebug'     => true,
        'charset'     => 'utf8',
        'DBCollat'    => 'utf8_general_ci',
        'swapPre'     => '',
        'encrypt'     => false,
        'compress'    => false,
        'strictOn'    => false,
        'failover'    => [],
        'port'        => 3306,
        'foreignKeys' => true,
        'busyTimeout' => 1000,
    ];

    /** Oracle credentials are supplied through database.oracle_logiref_*. entries in .env. */
    public array $oracle_logiref_main = [
        'DSN' => '', 'hostname' => '', 'username' => '', 'password' => '',
        'database' => '', 'DBDriver' => 'App\\Database\\Oracle', 'DBPrefix' => '',
        'pConnect' => false, 'DBDebug' => false, 'charset' => 'AL32UTF8',
        'port' => 1521, 'failover' => [],
    ];

    public array $oracle_logiref_transactions = [
        'DSN' => '', 'hostname' => '', 'username' => '', 'password' => '',
        'database' => '', 'DBDriver' => 'App\\Database\\Oracle', 'DBPrefix' => '',
        'pConnect' => false, 'DBDebug' => false, 'charset' => 'AL32UTF8',
        'port' => 1521, 'failover' => [],
    ];

    /** Auxiliary Oracle connections use the transactions schema unless overridden in .env. */
    public array $oracle_logiref_reporting = [];
    public array $oracle_payments_gateway = [];
    public array $oracle_logiref_etoll = [];
    public array $oracle_logiref_elicence = [];
    public array $oracle_logiref_qleads = [];
    public array $oracle_logiref_quitus = [];
    public array $oracle_logiref_payroll = [];
    public array $oracle_mcf_gateway = [];

    /** Legacy directory configuration; login now uses LOGIREF_DB_ENGINE. */
    public array $mysql_directory = [];

    public static function connect($group = null, bool $getShared = true)
    {
        if (ENVIRONMENT !== 'testing') {
            if ($group === 'mysql_directory') {
                $group = \App\Libraries\BankDatabaseRouter::directory();
                return $group;
            } elseif (is_string($group) || $group === null) {
                $group = \App\Libraries\BankDatabaseRouter::group($group ?? config(self::class)->defaultGroup);
            }
        }
        return parent::connect($group, $getShared);
    }

    public function __construct()
    {
        parent::__construct();

        foreach (['oracle_logiref_reporting','oracle_payments_gateway','oracle_logiref_etoll','oracle_logiref_elicence','oracle_logiref_qleads','oracle_logiref_quitus','oracle_logiref_payroll','oracle_mcf_gateway'] as $group) {
            $this->{$group} = $this->oracle_logiref_transactions;
            foreach ($this->{$group} as $field => $default) {
                $value = env('database.' . $group . '.' . $field, $default);
                if (is_bool($default)) $value = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                if (is_int($default)) $value = (int) $value;
                $this->{$group}[$field] = $value;
            }
        }

        $this->mysql_directory = $this->ikwook_logiref_main;
        $this->mysql_directory['DSN'] = '';
        $this->mysql_directory['database'] = env('database.mysql_directory.database', 'ikwook_logiref_main');

        // Ensure that we always set the database group to 'tests' if
        // we are currently running an automated test suite, so that
        // we don't overwrite live data on accident.
        if (ENVIRONMENT === 'testing') {
            $this->defaultGroup = 'tests';
        }
    }
}
