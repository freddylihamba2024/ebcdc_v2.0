<?php

namespace Config;

use CodeIgniter\Config\AutoloadConfig;

/**
 * -------------------------------------------------------------------
 * AUTOLOADER CONFIGURATION
 * -------------------------------------------------------------------
 *
 * This file defines the namespaces and class maps so the Autoloader
 * can find the files as needed.
 *
 * NOTE: If you use an identical key in $psr4 or $classmap, then
 *       the values in this file will overwrite the framework's values.
 *
 * NOTE: This class is required prior to Autoloader instantiation,
 *       and does not extend BaseConfig.
 */
class Autoload extends AutoloadConfig
{
    /**
     * -------------------------------------------------------------------
     * Namespaces
     * -------------------------------------------------------------------
     * This maps the locations of any namespaces in your application to
     * their location on the file system. These are used by the autoloader
     * to locate files the first time they have been instantiated.
     *
     * The '/app' and '/system' directories are already mapped for you.
     * you may change the name of the 'App' namespace if you wish,
     * but this should be done prior to creating any namespaced classes,
     * else you will need to modify all of those classes for this to work.
     *
     * Prototype:
     *   $psr4 = [
     *       'CodeIgniter' => SYSTEMPATH,
     *       'App'         => APPPATH
     *   ];
     *
     * @var array<string, array<int, string>|string>
     * @phpstan-var array<string, string|list<string>>
     */
    public $psr4 = [
        APP_NAMESPACE                       => APPPATH, // For custom app namespace
        'Config'                            => APPPATH . 'Config',
        'Modules\Api'                       => ROOTPATH . 'app/Modules/Api',
        'Modules\Main'                      => ROOTPATH . 'app/Modules/Main',
        'Modules\Admin'                     => ROOTPATH . 'app/Modules/Admin',
        'Modules\Logiref'                   => ROOTPATH . 'app/Modules/Logiref',
        'Modules\Branch'                    => ROOTPATH . 'app/Modules/Branch',
        'Modules\Qleads'                    => ROOTPATH . 'app/Modules/Qleads',
        'Modules\Services'                  => ROOTPATH . 'app/Modules/Services',
        'Modules\Sydonia'                   => ROOTPATH . 'app/Modules/Services/Sydonia',
        'Modules\Synergies'                 => ROOTPATH . 'app/Modules/Services/Synergies',
        'Modules\Services\Etoll'            => ROOTPATH . 'app/Modules/Services/Etoll',
        'Modules\Services\MCF'              => ROOTPATH . 'app/Modules/Services/MCF',
        'Modules\Services\LogirefCSRF'      => ROOTPATH . 'app/Modules/Services/LogirefCSRF',
        'Modules\Services\BsqrMiddleWare'   => ROOTPATH . 'app/Modules/Services/BsqrMiddleWare',
        'Modules\Services\Permis'           => ROOTPATH . 'app/Modules/Services/Permis',
        'Modules\Services\Seguce'           => ROOTPATH . 'app/Modules/Services/Seguce',
        'Modules\Services\Auth'             => ROOTPATH . 'app/Modules/Services/Auth',
        'Modules\Services\Chatbots'         => ROOTPATH . 'app/Modules/Services\Chatbots',
        'Modules\Igor'                      => ROOTPATH . 'app/Modules/Services/Igor',
        'Modules\Rbo'                       => ROOTPATH . 'app/Modules/Services/Rbo',
        'Modules\Branchless'                => ROOTPATH . 'app/Modules/Branchless',
        'Modules\Etoll'                     => ROOTPATH . 'app/Modules/Etoll',
        'Modules\Eximtrade'                 => ROOTPATH . 'app/Modules/Eximtrade',
        'Modules\Passeport'                 => ROOTPATH . 'app/Modules/Passeport',
        'Modules\Elicense'                  => ROOTPATH . 'app/Modules/Elicense',
        'Modules\Quitus'                    => ROOTPATH . 'app/Modules/Quitus',
        'Modules\Payroll'                   => ROOTPATH . 'app/Modules/Payroll',
        'Modules\Logs'                      => ROOTPATH . 'app/Modules/Logs',
        'Modules\Immatriculation'           => ROOTPATH . 'app/Modules/Immatriculation',
        'Modules\Inv'                       => ROOTPATH . 'app/Modules/Inv',
        'Modules\MigrateFlow'               => ROOTPATH . 'app/Modules/MigrateFlow',
        'Modules\Branchless\Main'           => ROOTPATH . 'app/Modules/Branchless/Main',
        'Modules\Branchless\Rbo'            => ROOTPATH . 'app/Modules/Branchless/Rbo',
        'Modules\Branchless\Tmb'            => ROOTPATH . 'app/Modules/Branchless/Tmb',
        'Modules\Branchless\Sofibanque'     => ROOTPATH . 'app/Modules/Branchless/Sofibanque',
    ];

    /**
     * -------------------------------------------------------------------
     * Class Map
     * -------------------------------------------------------------------
     * The class map provides a map of class names and their exact
     * location on the drive. Classes loaded in this manner will have
     * slightly faster performance because they will not have to be
     * searched for within one or more directories as they would if they
     * were being autoloaded through a namespace.
     *
     * Prototype:
     *   $classmap = [
     *       'MyClass'   => '/path/to/class/file.php'
     *   ];
     *
     * @var array<string, string>
     */
    public $classmap = [];

    /**
     * -------------------------------------------------------------------
     * Files
     * -------------------------------------------------------------------
     * The files array provides a list of paths to __non-class__ files
     * that will be autoloaded. This can be useful for bootstrap operations
     * or for loading functions.
     *
     * Prototype:
     *   $files = [
     *       '/path/to/my/file.php',
     *   ];
     *
     * @var string[]
     * @phpstan-var list<string>
     */
    public $files = [];

    /**
     * -------------------------------------------------------------------
     * Helpers
     * -------------------------------------------------------------------
     * Prototype:
     *   $helpers = [
     *       'form',
     *   ];
     *
     * @var string[]
     * @phpstan-var list<string>
     */
    public $helpers = ['currency_helper', 'sanitize_helper'];
}
