<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override(
    function () {
        $data['subview'] = '404';
        return view('layouts/layout_auth', $data);
    }
);
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');


/**
 * Routing for Main Module
 */

$routes->get('dbanonymizer/action/(:any)', "DBAnonymizerController::action/$1");


$routes->group('main', ['namespace' => 'Modules\Main\Controllers'], function ($routes) {
    $routes->match(['get'], 'signin', 'MainController::signin');
    $routes->match(['get'], 'signin_external', 'MainController::signin_external');
    $routes->match(['get'], 'denied', 'MainController::denied');
    $routes->match(['get'], 'published', 'MainController::published');
    $routes->match(['get'], 'checksession', 'MainController::check_session');
    $routes->match(['get'], 'already-logged-in', 'MainController::already_loggedin');
    $routes->match(['post', 'get'], 'login', 'MainController::login');
    $routes->match(['post'], 'login_external', 'MainController::login_external');
    $routes->match(['post', 'get'], 'verify_otp', 'MainController::verify_otp');
    $routes->match(['post', 'get'], 'validate_otp', 'MainController::validate_otp');
    $routes->match(['post'], 'resend_otp', 'MainController::resend_otp');
    $routes->match(['get'], 'forgotpassword', 'MainController::forgot_password');
    $routes->match(['get'], 'authentification', 'MainController::authentification');
    $routes->match(['get'], 'resetpassword/(:any)', 'MainController::reset_password/$1', array('as' => 'url_reset_password'));
    $routes->match(['post'], 'reinitialize', 'MainController::reinitialize');
    $routes->match(['post'], 'setpassword', 'MainController::set_password');
    $routes->match(['get', 'post'], 'signup', 'MainController::logout');
    $routes->match(['get'], 'services', 'MainController::services');
    $routes->match(['get'], 'profile', 'UserController::profile');
    $routes->match(['get'], 'signout', 'MainController::logout');
    $routes->match(['get'], 'overview', 'MainController::overview');
});

/** Routing for Auth Services */
$routes->group('services', ['namespace' => 'Modules\Services\Auth\Controllers'], function ($routes) {
        $routes->match(['post'], 'auth/login', 'Auth::login');
});

$routes->group('monitoring/logs', ['namespace' => 'Modules\Logs\Controllers'], function ($routes) {
    $routes->get('mails', 'MailLogs::index');
    $routes->get('mails/display', 'MailLogs::display');
    $routes->get('mails/display/(:any)', 'MailLogs::display/$1');
    $routes->get('mails/data', 'MailLogs::data/mails');
    $routes->get('mails/data/(:any)', 'MailLogs::data/$1');
    $routes->get('mails/data/(:any)/(:num)', 'MailLogs::data/$1/$2');
    $routes->match(['post', 'get'], 'mails/resend/(:num)', 'MailLogs::resend/$1');
    $routes->get('mails/(:num)', 'MailLogs::show/$1');
    $routes->get('payment-issues', 'PaymentIssues::index');
    $routes->get('payment-issues/display', 'PaymentIssues::display');
    $routes->get('payment-issues/display/(:any)', 'PaymentIssues::display/$1');
    $routes->get('payment-issues/data', 'PaymentIssues::data/issues');
    $routes->get('payment-issues/data/(:any)', 'PaymentIssues::data/$1');
    $routes->post('payment-issues/update/(:num)', 'PaymentIssues::update_ticket/$1');
    $routes->post('payment-issues/comment/(:num)', 'PaymentIssues::add_comment/$1');
    $routes->get('payment-issues/(:num)', 'PaymentIssues::show/$1');
    $routes->get('integrations', 'IntegrationLogs::index');
    $routes->get('integrations/display', 'IntegrationLogs::display');
    $routes->get('integrations/display/(:any)', 'IntegrationLogs::display/$1');
    $routes->get('integrations/data', 'IntegrationLogs::data/finacle');
    $routes->get('integrations/data/(:any)', 'IntegrationLogs::data/$1');
    $routes->get('integrations/(:any)', 'IntegrationLogs::show/$1');
    $routes->get('external-apis', 'ExternalApiLogs::index');
});

/**
 * Routing for Admin Module
 */
$routes->group('admin', ['namespace' => 'Modules\Admin\Controllers'], function ($routes) {

    /**Dashboard */
    $routes->get('dashboard/set/(:any)', 'Dashboard::set/$1');
    $routes->match(['post', 'get'], 'dashboard/display/(:any)', 'Dashboard::display/$1');

    /**Authorizations */
    $routes->get('authorizations/set/(:any)', 'Authorizations::set/$1');
    $routes->match(['post', 'get'], 'authorizations/display/(:any)', 'Authorizations::display/$1');
    $routes->match(['post', 'get'], 'authorizations/display/(:any)', 'Authorizations::display/$1/$2');
    $routes->match(['post', 'get'], 'authorizations/save/(:any)', 'Authorizations::save/$1');
    $routes->match(['post', 'get'], 'authorizations/save/(:any)', 'Authorizations::save/$1');
    $routes->match(['post', 'get'], 'authorizations/save/(:any)/(:any)', 'Authorizations::save/$1/$2');
    $routes->match(['post', 'get'], 'authorizations/save/(:any)/(:any)/(:any)', 'Authorizations::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'authorizations/data/(:any)', 'Authorizations::data/$1');

    /**Logiref*/
    $routes->get('logiref/set/(:any)', 'Logiref::set/$1');
    $routes->match(['post', 'get'], 'logiref/display/(:any)', 'Logiref::display/$1');

    /**E-toll*/
    $routes->get('etoll/set/(:any)', 'Etoll::set/$1');
    $routes->match(['post', 'get'], 'etoll/display/(:any)', 'Etoll::display/$1');
    $routes->match(['post', 'get'], 'etoll/save/(:any)', 'Etoll::save/$1');

    /**Eximtrade*/
    $routes->get('eximtrade/set/(:any)', 'Eximtrade::set/$1');
    $routes->match(['post', 'get'], 'eximtrade/display/(:any)', 'Eximtrade::display/$1');
    $routes->match(['post', 'get'], 'eximtrade/save/(:any)', 'Eximtrade::save/$1');

    /**Elicense*/
    $routes->get('elicense/set/(:any)', 'Elicense::set/$1');
    $routes->match(['post', 'get'], 'elicense/display/(:any)', 'Elicense::display/$1');
    $routes->match(['post', 'get'], 'elicense/save/(:any)', 'Elicense::save/$1');

    /**Referentiel*/
    $routes->get('referentiel/set/(:any)', 'Referentiel::set/$1');
    $routes->match(['post', 'get'], 'referentiel/display/(:any)', 'Referentiel::display/$1');

    /**Users Controller */
    $routes->get('users/set/(:any)', 'Users::set/$1');
    $routes->match(['post', 'get'], 'users/display/(:any)', 'Users::display/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)', 'Users::save/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)', 'Users::save/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)', 'Users::save/$1/$2');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)/(:any)', 'Users::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'users/data/(:any)', 'Users::data/$1');
    $routes->get('users/reinitialize/(:any)', 'Users::reinitialize/$1');
    $routes->get('users/reinitialize/(:any)/(:any)', 'Users::reinitialize/$1/$2');
    $routes->get('users/reinitialize/(:any)/(:any)/(:any)', 'Users::reinitialize/$1/$2/$3');
    $routes->get('users/activate/(:any)/(:any)/(:any)', 'Users::activate/$1/$2/$3');
    $routes->get('users/delete/(:any)/(:any)', 'Users::delete/$1/$2');
    $routes->get('users/change-guichet', 'Users::change_guichet');
    $routes->post('users/switch-guichet', 'Users::switch_guichet');
    $routes->get('users/confirm-guichet', 'Users::confirm_guichet');
    $routes->post('users/reconnect-guichet', 'Users::reconnect_guichet');

    /**Users BankCustomers */
    $routes->get('bankcustomers/set/(:any)', 'BankCustomers::set/$1');
    $routes->match(['post', 'get'], 'bankcustomers/display/(:any)', 'BankCustomers::display/$1');
    $routes->match(['post', 'get'], 'bankcustomers/save/(:any)', 'BankCustomers::save/$1');
    $routes->match(['post', 'get'], 'bankcustomers/save/(:any)', 'BankCustomers::save/$1');
    $routes->match(['post', 'get'], 'bankcustomers/save/(:any)/(:any)', 'BankCustomers::save/$1/$2');
    $routes->match(['post', 'get'], 'bankcustomers/save/(:any)/(:any)/(:any)', 'BankCustomers::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'bankcustomers/data/(:any)', 'BankCustomers::data/$1');

    $routes->get('bankcustomers/reinitialize/(:any)', 'BankCustomers::reinitialize/$1');
    $routes->get('bankcustomers/reinitialize/(:any)/(:any)', 'BankCustomers::reinitialize/$1/$2');
    $routes->get('bankcustomers/reinitialize/(:any)/(:any)/(:any)', 'BankCustomers::reinitialize/$1/$2/$3');
    $routes->get('bankcustomers/activate/(:any)/(:any)/(:any)', 'BankCustomers::activate/$1/$2/$3');
    $routes->get('bankcustomers/delete/(:any)/(:any)', 'BankCustomers::delete/$1/$2');

    /**Account Controller */
    $routes->get('accounts/set/(:any)', 'Accounts::set/$1');
    $routes->match(['post', 'get'], 'accounts/display/(:any)', 'Accounts::display/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)', 'Accounts::save/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)', 'Accounts::save/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)', 'Accounts::save/$1/$2');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');

    /**Fees Controller */
    $routes->get('fees/set/(:any)', 'Fees::set/$1');
    $routes->match(['post', 'get'], 'fees/display/(:any)', 'Fees::display/$1');
    $routes->match(['post', 'get'], 'fees/save/(:any)', 'Fees::save/$1');
    $routes->match(['post', 'get'], 'fees/save/(:any)', 'Fees::save/$1');
    $routes->match(['post', 'get'], 'fees/save/(:any)/(:any)', 'Fees::save/$1/$2');
    $routes->match(['post', 'get'], 'fees/save/(:any)/(:any)/(:any)', 'Fees::save/$1/$2/$3');

    /** Settings Controller */
    $routes->get('settings/set/(:any)', 'Settings::set/$1');
    $routes->match(['post', 'get'], 'settings/display/(:any)', 'Settings::display/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)', 'Settings::save/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)', 'Settings::save/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)', 'Settings::save/$1/$2');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)/(:any)', 'Settings::save/$1/$2/$3');

    /** Stakeholder Controller */
    $routes->get('stakeholders/set/(:any)', 'Stakeholders::set/$1');
    $routes->match(['post', 'get'], 'stakeholders/display/(:any)', 'Stakeholders::display/$1');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)', 'Stakeholders::save/$1');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)', 'Stakeholders::save/$1');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)/(:any)', 'Stakeholders::save/$1/$2');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)/(:any)/(:any)', 'Stakeholders::save/$1/$2/$3');

    /** Branch Controller */
    $routes->get('branches/set/(:any)', 'Branches::set/$1');
    $routes->match(['post', 'get'], 'branches/display/(:any)', 'Branches::display/$1');
    $routes->match(['post', 'get'], 'branches/save/(:any)', 'Branches::save/$1');
    $routes->match(['post', 'get'], 'branches/save/(:any)', 'Branches::save/$1');
    $routes->match(['post', 'get'], 'branches/save/(:any)/(:any)', 'Branches::save/$1/$2');
    $routes->match(['post', 'get'], 'branches/save/(:any)/(:any)/(:any)', 'Branches::save/$1/$2/$3');

    /** Account Controller */
    $routes->get('account/set/(:any)', 'Account::set/$1');
    $routes->match(['post', 'get'], 'account/display/(:any)', 'Account::display/$1');
    $routes->match(['post', 'get'], 'account/save/(:any)', 'Account::save/$1');
    $routes->match(['post', 'get'], 'account/save/(:any)', 'Account::save/$1');
    $routes->match(['post', 'get'], 'account/save/(:any)/(:any)', 'Account::save/$1/$2');
    $routes->match(['post', 'get'], 'account/save/(:any)/(:any)/(:any)', 'Account::save/$1/$2/$3');

    /** Users Controller */
    $routes->get('users/set/(:any)', 'users::set/$1');
    $routes->match(['post', 'get'], 'users/display/(:any)', 'Account::display/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)', 'Account::save/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)', 'Account::save/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)', 'Account::save/$1/$2');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)/(:any)', 'Account::save/$1/$2/$3');
    $routes->match(['post'], 'users/activate/(:any)/(:any)/(:any)', 'Users::activate/$1/$2/$3');
    $routes->match(['post'], 'users/desactivate/(:any)', 'Users::desactivate/$1');
    $routes->match(['post'], 'users/reinitialize/(:any)/(:any)/(:any)', 'Users::reinitialize/$1/$2/$3');
    $routes->match(['post'], 'users/delete/(:any)/(:any)', 'Users::delete/$1/$2');

    /** Admin Controller */
    $routes->get('admin/set/(:any)', 'Admin::set/$1');
    $routes->match(['post', 'get'], 'admin/display/(:any)', 'Admin::display/$1');
    $routes->match(['post', 'get'], 'admin/save/(:any)', 'Admin::save/$1');
    $routes->match(['post', 'get'], 'admin/save/(:any)', 'Admin::save/$1');
    $routes->match(['post', 'get'], 'admin/save/(:any)/(:any)', 'Admin::save/$1/$2');
    $routes->match(['post', 'get'], 'admin/save/(:any)/(:any)/(:any)', 'Admin::save/$1/$2/$3');

    /** Pos Controller */
    $routes->get('pos/set/(:any)', 'Pos::set/$1');
    $routes->match(['post', 'get'], 'pos/display/(:any)', 'Pos::display/$1');
    $routes->match(['post', 'get'], 'pos/save/(:any)', 'Pos::save/$1');
    $routes->match(['post', 'get'], 'pos/save/(:any)/(:any)', 'Pos::save/$1/$2');
    $routes->match(['post', 'get'], 'pos/save/(:any)/(:any)/(:any)', 'Pos::save/$1/$2/$3');

    /** Caisse Controller */
    $routes->get('caisses/set/(:any)', 'Caisses::set/$1');
    $routes->match(['post', 'get'], 'caisses/display/(:any)', 'Caisses::display/$1');
    $routes->match(['post', 'get'], 'caisses/save/(:any)', 'Caisses::save/$1');
    $routes->match(['post', 'get'], 'caisses/save/(:any)/(:any)', 'Caisses::save/$1/$2');
    $routes->match(['post', 'get'], 'caisses/save/(:any)/(:any)/(:any)', 'Caisses::save/$1/$2/$3');

    /** Partners Controller */
    $routes->get('partners/set/(:any)', 'Partners::set/$1');
    $routes->match(['post', 'get'], 'partners/display/(:any)', 'Partners::display/$1');
    $routes->match(['post', 'get'], 'partners/save/(:any)', 'Partners::save/$1');
    $routes->match(['post', 'get'], 'partners/save/(:any)/(:any)', 'Partners::save/$1/$2');
    $routes->match(['post', 'get'], 'partners/save/(:any)/(:any)/(:any)', 'Partners::save/$1/$2/$3');

    /** Events Controller */
    $routes->get('events/set/(:any)', 'Events::set/$1');
    $routes->match(['post', 'get'], 'events/display/(:any)', 'Events::display/$1');
    $routes->match(['post', 'get'], 'events/save/(:any)', 'Events::save/$1');
    $routes->match(['post', 'get'], 'events/save/(:any)/(:any)', 'Events::save/$1/$2');
    $routes->match(['post', 'get'], 'events/save/(:any)/(:any)/(:any)', 'Events::save/$1/$2/$3');

    /** Events Controller */
    $routes->get('cashbooks/set/(:any)', 'Cashbooks::set/$1');
    $routes->match(['post', 'get'], 'cashbooks/display/(:any)', 'Cashbooks::display/$1');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)', 'Cashbooks::save/$1');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)/(:any)', 'Cashbooks::save/$1/$2');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)/(:any)/(:any)', 'Cashbooks::save/$1/$2/$3');

    /** Events Controller */
    $routes->get('counters/set/(:any)', 'Counters::set/$1');
    $routes->match(['post', 'get'], 'counters/display/(:any)', 'Counters::display/$1');
    $routes->match(['post', 'get'], 'counters/save/(:any)', 'Counters::save/$1');
    $routes->match(['post', 'get'], 'counters/save/(:any)/(:any)', 'Counters::save/$1/$2');
    $routes->match(['post', 'get'], 'counters/save/(:any)/(:any)/(:any)', 'Counters::save/$1/$2/$3');

    /** QLeads Controller */
    $routes->get('qleads/set/(:any)', 'Qleads::set/$1');
    $routes->match(['post', 'get'], 'qleads/display/(:any)', 'Qleads::display/$1');
    $routes->match(['post', 'get'], 'qleads/save/(:any)', 'Qleads::save/$1');
    $routes->match(['post', 'get'], 'qleads/save/(:any)/(:any)', 'Qleads::save/$1/$2');
    $routes->match(['post', 'get'], 'qleads/save/(:any)/(:any)/(:any)', 'Qleads::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleads/data/(:any)', 'Qleads::data/$1');
    $routes->get('qleads/activate/(:any)/(:any)/(:any)', 'Qleads::activate/$1/$2/$3');

    /** Quitus Controller */
    $routes->get('quitus/set/(:any)', 'Quitus::set/$1');
    $routes->match(['post', 'get'], 'quitus/display/(:any)', 'Quitus::display/$1');
    $routes->match(['post', 'get'], 'quitus/save/(:any)', 'Quitus::save/$1');
    $routes->match(['post', 'get'], 'quitus/save/(:any)/(:any)', 'Quitus::save/$1/$2');
    $routes->match(['post', 'get'], 'quitus/save/(:any)/(:any)/(:any)', 'Quitus::save/$1/$2/$3');

    /** Souscription Netbanking */
    $routes->get('subscriptions/set/(:any)', 'Subscriptions::set/$1');
    $routes->match(['post', 'get'], 'subscriptions/display/(:any)', 'Subscriptions::display/$1');
    $routes->match(['post', 'get'], 'subscriptions/save/(:any)', 'Subscriptions::save/$1');
    $routes->match(['post', 'get'], 'subscriptions/save/(:any)/(:any)', 'Subscriptions::save/$1/$2');
    $routes->match(['post', 'get'], 'subscriptions/save/(:any)/(:any)/(:any)', 'Subscriptions::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'subscriptions/data/(:any)', 'Subscriptionss::data/$1');
});


/**
 * Routing for Branch Module
 */
$routes->group('branch', ['namespace' => 'Modules\Branch\Controllers'], function ($routes) {

    /** TaxDashboard */
    $routes->get('taxdashboards/set/(:any)', 'TaxDashboards::set/$1');
    $routes->match(['post', 'get'], 'taxdashboards/display/(:any)', 'TaxDashboards::display/$1');
    $routes->match(['post', 'get'], 'taxdashboards/save/(:any)', 'TaxDashboards::save/$1');
    $routes->match(['post', 'get'], 'taxdashboards/save/(:any)', 'TaxDashboards::save/$1');
    $routes->match(['post', 'get'], 'taxdashboards/save/(:any)/(:any)', 'TaxDashboards::save/$1/$2');
    $routes->match(['post', 'get'], 'taxdashboards/save/(:any)/(:any)/(:any)', 'TaxDashboards::save/$1/$2/$3');

    /** TaxRates */
    $routes->get('taxrates/set/(:any)', 'TaxRates::set/$1');
    $routes->match(['post', 'get'], 'taxrates/display/(:any)', 'TaxRates::display/$1');
    $routes->match(['post', 'get'], 'taxrates/save/(:any)', 'TaxRates::save/$1');
    $routes->match(['post', 'get'], 'taxrates/save/(:any)', 'TaxRates::save/$1');
    $routes->match(['post', 'get'], 'taxrates/save/(:any)/(:any)', 'TaxRates::save/$1/$2');
    $routes->match(['post', 'get'], 'taxrates/save/(:any)/(:any)/(:any)', 'TaxRates::save/$1/$2/$3');

    /** TaxDeclaration */
    $routes->get('taxdeclaration/set/(:any)', 'TaxDeclaration::set/$1');
    $routes->match(['post', 'get'], 'taxdeclaration/display/(:any)', 'TaxDeclaration::display/$1');
    $routes->match(['post', 'get'], 'taxdeclaration/save/(:any)', 'TaxDeclaration::save/$1');
    $routes->match(['post', 'get'], 'taxdeclaration/save/(:any)', 'TaxDeclaration::save/$1');
    $routes->match(['post', 'get'], 'taxdeclaration/save/(:any)/(:any)', 'TaxDeclaration::save/$1/$2');
    $routes->match(['post', 'get'], 'taxdeclaration/save/(:any)/(:any)/(:any)', 'TaxDeclaration::save/$1/$2/$3');

     /** TaxImmatriculation */
    $routes->get('taximmatriculation/set/(:any)', 'TaxImmatriculation::set/$1');
    $routes->match(['post', 'get'], 'taximmatriculation/display/(:any)', 'TaxImmatriculation::display/$1');
    $routes->match(['post', 'get'], 'taximmatriculation/save/(:any)', 'TaxImmatriculation::save/$1');
    $routes->match(['post', 'get'], 'taximmatriculation/save/(:any)', 'TaxImmatriculation::save/$1');
    $routes->match(['post', 'get'], 'taximmatriculation/save/(:any)/(:any)', 'TaxImmatriculation::save/$1/$2');
    $routes->match(['post', 'get'], 'taximmatriculation/save/(:any)/(:any)/(:any)', 'TaxImmatriculation::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taximmatriculation/data/(:any)', 'TaxImmatriculation::data/$1');

    /** TaxNotes */
    $routes->get('taxnotes/set/(:any)', 'TaxNotes::set/$1');
    $routes->match(['post', 'get'], 'taxnotes/display/(:any)', 'TaxNotes::display/$1');
    $routes->match(['post', 'get'], 'taxnotes/save/(:any)', 'TaxNotes::save/$1');
    $routes->match(['post', 'get'], 'taxnotes/save/(:any)', 'TaxNotes::save/$1');
    $routes->match(['post', 'get'], 'taxnotes/save/(:any)/(:any)', 'TaxNotes::save/$1/$2');
    $routes->match(['post', 'get'], 'taxnotes/save/(:any)/(:any)/(:any)', 'TaxNotes::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxnotes/data/(:any)', 'TaxNotes::data/$1');

    /** TaxPasseport */
    $routes->get('taxpasseport/set/(:any)', 'TaxPasseport::set/$1');
    $routes->match(['post', 'get'], 'taxpasseport/display/(:any)', 'TaxPasseport::display/$1');
    $routes->match(['post', 'get'], 'taxpasseport/save/(:any)', 'TaxPasseport::save/$1');
    $routes->match(['post', 'get'], 'taxpasseport/save/(:any)', 'TaxPasseport::save/$1');
    $routes->match(['post', 'get'], 'taxpasseport/save/(:any)/(:any)', 'TaxPasseport::save/$1/$2');
    $routes->match(['post', 'get'], 'taxpasseport/save/(:any)/(:any)/(:any)', 'TaxPasseport::save/$1/$2/$3');

    /** TaxPermis */
    $routes->get('taxpermis/set/(:any)', 'TaxPermis::set/$1');
    $routes->match(['post', 'get'], 'taxpermis/display/(:any)', 'TaxPermis::display/$1');
    $routes->match(['post', 'get'], 'taxpermis/save/(:any)', 'TaxPermis::save/$1');
    $routes->match(['post', 'get'], 'taxpermis/save/(:any)', 'TaxPermis::save/$1');
    $routes->match(['post', 'get'], 'taxpermis/save/(:any)/(:any)', 'TaxPermis::save/$1/$2');
    $routes->match(['post', 'get'], 'taxpermis/save/(:any)/(:any)/(:any)', 'TaxPermis::save/$1/$2/$3');

    /** TaxReports */
    $routes->get('taxreports/set/(:any)', 'TaxReports::set/$1');
    $routes->match(['post', 'get'], 'taxreports/display/(:any)/(:any)', 'TaxReports::display/$1/$2');
    $routes->match(['post', 'get'], 'taxreports/display/(:any)', 'TaxReports::display/$1');
    $routes->match(['post', 'get'], 'taxreports/save/(:any)', 'TaxReports::save/$1');
    $routes->match(['post', 'get'], 'taxreports/save/(:any)', 'TaxReports::save/$1');
    $routes->match(['post', 'get'], 'taxreports/save/(:any)/(:any)', 'TaxReports::save/$1/$2');
    $routes->match(['post', 'get'], 'taxreports/save/(:any)/(:any)/(:any)', 'TaxReports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxreports/data/(:any)', 'TaxReports::data/$1');

    /** TaxAccounts */
    $routes->get('taxaccounts/set/(:any)', 'TaxAccounts::set/$1');
    $routes->match(['post', 'get'], 'taxaccounts/display/(:any)', 'TaxAccounts::display/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)', 'TaxAccounts::save/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)', 'TaxAccounts::save/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)/(:any)', 'TaxAccounts::save/$1/$2');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)/(:any)/(:any)', 'TaxAccounts::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxaccounts/data/(:any)', 'TaxAccounts::data/$1');

    /** TaxComptabilisation */
    $routes->get('taxcomptabilisation/set/(:any)', 'TaxComptabilisation::set/$1');
    $routes->match(['post', 'get'], 'taxcomptabilisation/display/(:any)/(:any)', 'TaxComptabilisation::display/$1/$2');
    $routes->match(['post', 'get'], 'taxcomptabilisation/display/(:any)', 'TaxComptabilisation::display/$1');
    $routes->match(['post', 'get'], 'taxcomptabilisation/save/(:any)', 'TaxComptabilisation::save/$1');
    $routes->match(['post', 'get'], 'taxcomptabilisation/save/(:any)', 'TaxComptabilisation::save/$1');
    $routes->match(['post', 'get'], 'taxcomptabilisation/save/(:any)/(:any)', 'TaxComptabilisation::save/$1/$2');
    $routes->match(['post', 'get'], 'taxcomptabilisation/save/(:any)/(:any)/(:any)', 'TaxComptabilisation::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxcomptabilisation/data/(:any)', 'TaxComptabilisation::data/$1');

    /** TaxBulletin */
    $routes->get('taxbulletin/set/(:any)', 'TaxBulletin::set/$1');
    $routes->match(['post', 'get'], 'taxbulletin/display/(:any)', 'TaxBulletin::display/$1');
    $routes->match(['post', 'get'], 'taxbulletin/save/(:any)', 'TaxBulletin::save/$1');
    $routes->match(['post', 'get'], 'taxbulletin/save/(:any)', 'TaxBulletin::save/$1');
    $routes->match(['post', 'get'], 'taxbulletin/save/(:any)/(:any)', 'TaxBulletin::save/$1/$2');
    $routes->match(['post', 'get'], 'taxbulletin/save/(:any)/(:any)/(:any)', 'TaxBulletin::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxbulletin/data/(:any)', 'TaxBulletin::data/$1');

    /** TaxDgrk */
    $routes->get('taxdgrk/set/(:any)', 'TaxDgrk::set/$1');
    $routes->match(['post', 'get'], 'taxdgrk/display/(:any)', 'TaxDgrk::display/$1');
    $routes->match(['post', 'get'], 'taxdgrk/save/(:any)', 'TaxDgrk::save/$1');
    $routes->match(['post', 'get'], 'taxdgrk/save/(:any)/(:any)', 'TaxDgrk::save/$1/$2');
    $routes->match(['post', 'get'], 'taxdgrk/save/(:any)/(:any)/(:any)', 'TaxDgrk::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxdgrk/data/(:any)', 'TaxDgrk::data/$1');

    /** TaxDgpek */
    $routes->get('taxdgpek/set/(:any)', 'TaxDgpek::set/$1');
    $routes->match(['post', 'get'], 'taxdgpek/display/(:any)', 'TaxDgpek::display/$1');
    $routes->match(['post', 'get'], 'taxdgpek/save/(:any)', 'TaxDgpek::save/$1');
    $routes->match(['post', 'get'], 'taxdgpek/save/(:any)/(:any)', 'TaxDgpek::save/$1/$2');
    $routes->match(['post', 'get'], 'taxdgpek/save/(:any)/(:any)/(:any)', 'TaxDgpek::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxdgpek/data/(:any)', 'TaxDgpek::data/$1');

    /** TaxEqualize */
    $routes->get('taxequalize/set/(:any)', 'TaxEqualize::set/$1');
    $routes->match(['post', 'get'], 'taxequalize/display/(:any)', 'TaxEqualize::display/$1');
    $routes->match(['post', 'get'], 'taxequalize/save/(:any)', 'TaxEqualize::save/$1');
    $routes->match(['post', 'get'], 'taxequalize/save/(:any)', 'TaxEqualize::save/$1');
    $routes->match(['post', 'get'], 'taxequalize/save/(:any)/(:any)', 'TaxEqualize::save/$1/$2');
    $routes->match(['post', 'get'], 'taxequalize/save/(:any)/(:any)/(:any)', 'TaxEqualize::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxequalize/data/(:any)', 'TaxEqualize::data/$1');

    /** TaxPrepayments */
    $routes->get('taxprepayments/set/(:any)', 'TaxPrepayments::set/$1');
    $routes->match(['post', 'get'], 'taxprepayments/display/(:any)', 'TaxPrepayments::display/$1');
    $routes->match(['post', 'get'], 'taxprepayments/save/(:any)', 'TaxPrepayments::save/$1');
    $routes->match(['post', 'get'], 'taxprepayments/save/(:any)', 'TaxPrepayments::save/$1');
    $routes->match(['post', 'get'], 'taxprepayments/save/(:any)/(:any)', 'TaxPrepayments::save/$1/$2');
    $routes->match(['post', 'get'], 'taxprepayments/save/(:any)/(:any)/(:any)', 'TaxPrepayments::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxprepayments/data/(:any)', 'TaxPrepayments::data/$1');


    /** TaxOffline */
    $routes->get('taxoffline/set/(:any)', 'TaxOffline::set/$1');
    $routes->match(['post', 'get'], 'taxoffline/display/(:any)', 'TaxOffline::display/$1');
    $routes->match(['post', 'get'], 'taxoffline/save/(:any)', 'TaxOffline::save/$1');
    $routes->match(['post', 'get'], 'taxoffline/save/(:any)', 'TaxOffline::save/$1');
    $routes->match(['post', 'get'], 'taxoffline/save/(:any)/(:any)', 'TaxOffline::save/$1/$2');
    $routes->match(['post', 'get'], 'taxoffline/save/(:any)/(:any)/(:any)', 'TaxOffline::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxoffline/data/(:any)', 'TaxOffline::data/$1');

    /** TaxOthers */
    $routes->get('taxothers/set/(:any)', 'TaxOthers::set/$1');
    $routes->match(['post', 'get'], 'taxothers/display/(:any)', 'TaxOthers::display/$1');
    $routes->match(['post', 'get'], 'taxothers/save/(:any)', 'TaxOthers::save/$1');
    $routes->match(['post', 'get'], 'taxothers/save/(:any)', 'TaxOthers::save/$1');
    $routes->match(['post', 'get'], 'taxothers/save/(:any)/(:any)', 'TaxOthers::save/$1/$2');
    $routes->match(['post', 'get'], 'taxothers/save/(:any)/(:any)/(:any)', 'TaxOthers::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxothers/data/(:any)', 'TaxOthers::data/$1');

    /** TaxUsers */
    $routes->get('taxusers/set/(:any)', 'TaxUsers::set/$1');
    $routes->match(['post', 'get'], 'taxusers/display/(:any)', 'TaxUsers::display/$1');
    $routes->match(['post', 'get'], 'taxusers/save/(:any)', 'TaxUsers::save/$1');
    $routes->match(['post', 'get'], 'taxusers/save/(:any)', 'TaxUsers::save/$1');
    $routes->match(['post', 'get'], 'taxusers/save/(:any)/(:any)', 'TaxUsers::save/$1/$2');
    $routes->match(['post', 'get'], 'taxusers/save/(:any)/(:any)/(:any)', 'TaxUsers::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxusers/data/(:any)', 'TaxUsers::data/$1');

    /** TaxImpression */
    $routes->get('taximpression/set/(:any)', 'TaxImpression::set/$1');
    $routes->match(['post', 'get'], 'taximpression/display/(:any)', 'TaxImpression::display/$1');
    $routes->match(['post', 'get'], 'taximpression/display/(:any)/(:any)', 'TaxImpression::display/$1/$2');

    /** TaxReversement */
    $routes->get('taxreversement/set/(:any)', 'TaxReversement::set/$1');
    $routes->match(['post', 'get'], 'taxreversement/display/(:any)', 'TaxReversement::display/$1');
    $routes->match(['post', 'get'], 'taxreversement/save/(:any)', 'TaxReversement::save/$1');
    $routes->match(['post', 'get'], 'taxreversement/save/(:any)', 'TaxReversement::save/$1');
    $routes->match(['post', 'get'], 'taxreversement/save/(:any)/(:any)', 'TaxReversement::save/$1/$2');
    $routes->match(['post', 'get'], 'taxreversement/save/(:any)/(:any)/(:any)', 'TaxReversement::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'taxreversement/data/(:any)', 'TaxReversement::data/$1');

    /** TaxAccounts */
    $routes->get('taxaccounts/set/(:any)', 'TaxAccounts::set/$1');
    $routes->match(['post', 'get'], 'taxaccounts/display/(:any)', 'TaxAccounts::display/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)', 'TaxAccounts::save/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)', 'TaxAccounts::save/$1');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)/(:any)', 'TaxAccounts::save/$1/$2');
    $routes->match(['post', 'get'], 'taxaccounts/save/(:any)/(:any)/(:any)', 'TaxAccounts::save/$1/$2/$3');


    /** TaxDeclaration */
    $routes->get('taxfees/set/(:any)', 'TaxFees::set/$1');
    $routes->match(['post', 'get'], 'taxfees/display/(:any)', 'TaxFees::display/$1');
    $routes->match(['post', 'get'], 'taxfees/save/(:any)', 'TaxFees::save/$1');
    $routes->match(['post', 'get'], 'taxfees/save/(:any)', 'TaxFees::save/$1');
    $routes->match(['post', 'get'], 'taxfees/save/(:any)/(:any)', 'TaxFees::save/$1/$2');
    $routes->match(['post', 'get'], 'taxfees/save/(:any)/(:any)/(:any)', 'TaxFees::save/$1/$2/$3');

    /** TaxDeclaration */
    $routes->get('taxsettings/set/(:any)', 'TaxSettings::set/$1');
    $routes->match(['post', 'get'], 'taxsettings/display/(:any)', 'TaxSettings::display/$1');
    $routes->match(['post', 'get'], 'taxsettings/save/(:any)', 'TaxSettings::save/$1');
    $routes->match(['post', 'get'], 'taxsettings/save/(:any)', 'TaxSettings::save/$1');
    $routes->match(['post', 'get'], 'taxsettings/save/(:any)/(:any)', 'TaxSettings::save/$1/$2');
    $routes->match(['post', 'get'], 'taxsettings/save/(:any)/(:any)/(:any)', 'TaxSettings::save/$1/$2/$3');
});

/**
 * Routing for Passeport Module
 */

$routes->group('passeport', ['namespace' => 'Modules\Passeport\Controllers'], function ($routes) {

    /** Passeport */
    $routes->get('passeport/set/(:any)', 'Passeport::set/$1');
    $routes->match(['post', 'get'], 'passeport/display/(:any)', 'Passeport::display/$1');
    $routes->match(['post', 'get'], 'passeport/save/(:any)', 'Passeport::save/$1');
    $routes->match(['post', 'get'], 'passeport/save/(:any)', 'Passeport::save/$1');
    $routes->match(['post', 'get'], 'passeport/save/(:any)/(:any)', 'Passeport::save/$1/$2');
    $routes->match(['post', 'get'], 'passeport/save/(:any)/(:any)/(:any)', 'Passeport::save/$1/$2/$3');
});

/**
 * Routing for Elicense Module
 */

 $routes->group('elicense', ['namespace' => 'Modules\Elicense\Controllers'], function ($routes) {

    /** Dashboards */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');

    /** Accounts */
    $routes->get('accounts/set/(:any)', 'Accounts::set/$1');
    $routes->match(['post', 'get'], 'accounts/display/(:any)', 'Accounts::display/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)', 'Accounts::save/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)', 'Accounts::save/$1/$2');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'accounts/data/(:any)', 'Accounts::data/$1');

    /** Elicense */
    $routes->get('elicense/set/(:any)', 'Elicense::set/$1');
    $routes->match(['post', 'get'], 'elicense/display/(:any)', 'Elicense::display/$1');
    $routes->match(['post', 'get'], 'elicense/save/(:any)', 'Elicense::save/$1');
    $routes->match(['post', 'get'], 'elicense/save/(:any)/(:any)', 'Elicense::save/$1/$2');
    $routes->match(['post', 'get'], 'elicense/save/(:any)/(:any)/(:any)', 'Elicense::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'elicense/data/(:any)', 'Elicense::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');

    /** Impression */
    $routes->get('impression/set/(:any)', 'Impression::set/$1');
    $routes->match(['post', 'get'], 'impression/display/(:any)', 'Impression::display/$1');

});

/**
 * Routing for Qleads Module
 */
$routes->group('qleads', ['namespace' => 'Modules\Qleads\Controllers'], function ($routes) {

    /** QleadsDashboard */
    $routes->get('qleadsdashboard/set/(:any)', 'QleadsDashboard::set/$1');
    $routes->match(['post', 'get'], 'qleadsdashboard/display/(:any)', 'QleadsDashboard::display/$1');
    $routes->match(['post', 'get'], 'qleadsdashboard/save/(:any)', 'QleadsDashboard::save/$1');
    $routes->match(['post', 'get'], 'qleadsdashboard/save/(:any)', 'QleadsDashboard::save/$1');
    $routes->match(['post', 'get'], 'qleadsdashboard/save/(:any)/(:any)', 'QleadsDashboard::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsdashboard/save/(:any)/(:any)/(:any)', 'QleadsDashboard::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsdashboard/data/(:any)', 'QleadsDashboard::data/$1');

    /** QleadsTokens */
    $routes->get('qleadstokens/set/(:any)', 'QleadsTokens::set/$1');
    $routes->match(['post', 'get'], 'qleadstokens/display/(:any)', 'QleadsTokens::display/$1');
    $routes->match(['post', 'get'], 'qleadstokens/save/(:any)', 'QleadsTokens::save/$1');
    $routes->match(['post', 'get'], 'qleadstokens/save/(:any)', 'QleadsTokens::save/$1');
    $routes->match(['post', 'get'], 'qleadstokens/save/(:any)/(:any)', 'QleadsTokens::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadstokens/save/(:any)/(:any)/(:any)', 'QleadsTokens::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadstokens/data/(:any)', 'QleadsTokens::data/$1');

    /** QleadsReports */
    $routes->get('qleadsreports/set/(:any)', 'QleadsReports::set/$1');
    $routes->match(['post', 'get'], 'qleadsreports/display/(:any)', 'QleadsReports::display/$1');
    $routes->match(['post', 'get'], 'qleadsreports/save/(:any)', 'QleadsReports::save/$1');
    $routes->match(['post', 'get'], 'qleadsreports/save/(:any)', 'QleadsReports::save/$1');
    $routes->match(['post', 'get'], 'qleadsreports/save/(:any)/(:any)', 'QleadsReports::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsreports/save/(:any)/(:any)/(:any)', 'QleadsReports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsreports/data/(:any)', 'QleadsReports::data/$1');

    /** QleadsInquiries */
    $routes->get('qleadsinquiries/set/(:any)', 'QleadsInquiries::set/$1');
    $routes->match(['post', 'get'], 'qleadsinquiries/display/(:any)', 'QleadsInquiries::display/$1');
    $routes->match(['post', 'get'], 'qleadsinquiries/save/(:any)', 'QleadsInquiries::save/$1');
    $routes->match(['post', 'get'], 'qleadsinquiries/save/(:any)', 'QleadsInquiries::save/$1');
    $routes->match(['post', 'get'], 'qleadsinquiries/save/(:any)/(:any)', 'QleadsInquiries::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsinquiries/save/(:any)/(:any)/(:any)', 'QleadsInquiries::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsinquiries/data/(:any)', 'QleadsInquiries::data/$1');

    /** QleadsCustomers */
    $routes->get('qleadscustomers/set/(:any)', 'QleadsCustomers::set/$1');
    $routes->match(['post', 'get'], 'qleadscustomers/display/(:any)', 'QleadsCustomers::display/$1');
    $routes->match(['post', 'get'], 'qleadscustomers/save/(:any)', 'QleadsCustomers::save/$1');
    $routes->match(['post', 'get'], 'qleadscustomers/save/(:any)', 'QleadsCustomers::save/$1');
    $routes->match(['post', 'get'], 'qleadscustomers/save/(:any)/(:any)', 'QleadsCustomers::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadscustomers/save/(:any)/(:any)/(:any)', 'QleadsCustomers::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadscustomers/data/(:any)', 'QleadsCustomers::data/$1');

    /** QleadsSurvey */
    $routes->get('qleadssurvey/set/(:any)', 'QleadsSurvey::set/$1');
    $routes->match(['post', 'get'], 'qleadssurvey/display/(:any)', 'QleadsSurvey::display/$1');
    $routes->match(['post', 'get'], 'qleadssurvey/save/(:any)', 'QleadsSurvey::save/$1');
    $routes->match(['post', 'get'], 'qleadssurvey/save/(:any)', 'QleadsSurvey::save/$1');
    $routes->match(['post', 'get'], 'qleadssurvey/save/(:any)/(:any)', 'QleadsSurvey::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadssurvey/save/(:any)/(:any)/(:any)', 'QleadsSurvey::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadssurvey/data/(:any)', 'QleadsSurvey::data/$1');

    /** QleadsAppointment */
    $routes->get('qleadsappointment/set/(:any)', 'QleadsAppointment::set/$1');
    $routes->match(['post', 'get'], 'qleadsappointment/display/(:any)', 'QleadsAppointment::display/$1');
    $routes->match(['post', 'get'], 'qleadsappointment/save/(:any)', 'QleadsAppointment::save/$1');
    $routes->match(['post', 'get'], 'qleadsappointment/save/(:any)', 'QleadsAppointment::save/$1');
    $routes->match(['post', 'get'], 'qleadsappointment/save/(:any)/(:any)', 'QleadsAppointment::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsappointment/save/(:any)/(:any)/(:any)', 'QleadsAppointment::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsappointment/data/(:any)', 'QleadsAppointment::data/$1');

    /** QleadsQueue */
    $routes->get('qleadsqueue/set/(:any)', 'QleadsQueue::set/$1');
    $routes->match(['post', 'get'], 'qleadsqueue/display/(:any)', 'QleadsQueue::display/$1');
    $routes->match(['post', 'get'], 'qleadsqueue/save/(:any)', 'QleadsQueue::save/$1');
    $routes->match(['post', 'get'], 'qleadsqueue/save/(:any)', 'QleadsQueue::save/$1');
    $routes->match(['post', 'get'], 'qleadsqueue/save/(:any)/(:any)', 'QleadsQueue::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsqueue/save/(:any)/(:any)/(:any)', 'QleadsQueue::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsqueue/data/(:any)', 'QleadsQueue::data/$1');

    /** QleadsSettings */
    $routes->get('qleadssettings/set/(:any)', 'QleadsSettings::set/$1');
    $routes->match(['post', 'get'], 'qleadssettings/display/(:any)', 'QleadsSettings::display/$1');
    $routes->match(['post', 'get'], 'qleadssettings/save/(:any)', 'QleadsSettings::save/$1');
    $routes->match(['post', 'get'], 'qleadssettings/save/(:any)', 'QleadsSettings::save/$1');
    $routes->match(['post', 'get'], 'qleadssettings/save/(:any)/(:any)', 'QleadsSettings::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadssettings/save/(:any)/(:any)/(:any)', 'QleadsSettings::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadssettings/data/(:any)', 'QleadsSettings::data/$1');

    /** QleadsImpression */
    $routes->get('qleadsimpression/set/(:any)', 'QleadsImpression::set/$1');
    $routes->match(['post', 'get'], 'qleadsimpression/display/(:any)', 'QleadsImpression::display/$1');
});

/**
 * Routing for Quitus Module
 */

$routes->group('quitus', ['namespace' => 'Modules\Quitus\Controllers'], function ($routes) {

    /** Dashboards */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');

    /** Quitus */
    $routes->get('quitus/set/(:any)', 'Quitus::set/$1');
    $routes->match(['post', 'get'], 'quitus/display/(:any)', 'Quitus::display/$1');
    $routes->match(['post', 'get'], 'quitus/save/(:any)', 'Quitus::save/$1');
    $routes->match(['post', 'get'], 'quitus/save/(:any)/(:any)', 'Quitus::save/$1/$2');
    $routes->match(['post', 'get'], 'quitus/save/(:any)/(:any)/(:any)', 'Quitus::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'quitus/data/(:any)', 'Quitus::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');

    /** QuitusImpression */
    $routes->get('quitusimpression/set/(:any)', 'QuitusImpression::set/$1');
    $routes->match(['post', 'get'], 'quitusimpression/display/(:any)', 'QuitusImpression::display/$1');

});

/**
 * Routing for Services Module
 */

/** Qleads Endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Qleads\Controllers'], function ($routes) {
    /** Qleads */
    $routes->get('qleads/authorize/(:any)/(:any)/(:any)', 'Qleads::authorize/$1/$2/$3');
    $routes->get('qleads/getToken/(:any)', 'Qleads::get_token/$1/$2/$3');
    $routes->post('qleads/getToken/(:any)', 'Qleads::get_token/$1/$2/$3');
    $routes->get('qleads/getQueueInfo/(:any)', 'Qleads::get_queue_infos/$1/$2/$3/$4');
    $routes->get('qleads/save/(:any)', 'Qleads::authorize/$1/$2/$3');
    $routes->get('qleads/getCategories/(:any)', 'Qleads::get_categories/$1');
    $routes->get('qleads/getAppointmentsByPhone/(:any)', 'Qleads::get_appointments_by_phone/$1');
    $routes->get('qleads/getAds/(:any)', 'Qleads::get_ads/$1/$2/$3');
    $routes->get('qleads/getFormSurvey/(:any)', 'Qleads::get_form_survey/$1/$2');
    $routes->get('qleads/getBranchInfos/(:any)', 'Qleads::get_branch_infos/$1/$2');


    $routes->match(['post', 'get'], 'qleads/survey/(:any)', 'Qleads::save_survey/$1');
    $routes->match(['post', 'get'], 'qleads/survey_init', 'Qleads::init_survey');
    $routes->match(['post', 'get'], 'qleads/create_appointment', 'Qleads::create_appointment');
    $routes->match(['post', 'get'], 'qleads/confirm_appointment/(:any)', 'Qleads::confirm_appointment/$1');
    /** .... */


});

/** Etoll endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Etoll\Controllers'], ['filter' => 'excludeServices'], function ($routes) {
    /** Access link */
    $routes->get('etoll/endpoints', 'Access::index');

    /** Authentification endpoint */
    $routes->post('etoll/auth/login', 'Auth::login_post');
    /** etoll get endpoints */
    $routes->get('etoll/LogirefGetCashbooks', 'LogirefGetCashbooks::index_get');
    $routes->get('etoll/LogirefGetProducts', 'LogirefGetProducts::index_get');
    $routes->get('etoll/LogirefGetTicket', 'LogirefGetTicket::index_get');
    $routes->get('etoll/LogirefGetWeights', 'LogirefGetWeights::index_get');
    $routes->get('etoll/SbbosGetTickets', 'SbbosGetTickets::index_get');
    $routes->get('etoll/SbbosGetWeights', 'SbbosGetWeights::index_get');
    $routes->get('etoll/SbbosGetTolls', 'SbbosGetTolls::index_get');
    $routes->get('etoll/SbbosGetPaiements', 'LogirefGetpayments::index_get');

    /** etoll post endpoints */
    $routes->post('etoll/SbbosSubmitTolls', 'SbbosSubmitTolls::index_post');
    $routes->post('etoll/SbbosSubmitTickets', 'SbbosSubmitTickets::index_post');
    $routes->post('etoll/LogirefSavePaiement', 'LogirefSavePaiement::index_post');
    $routes->post('etoll/LogirefSaveTicket', 'LogirefSaveTicket::index_post');
    $routes->post('etoll/LogirefVerification', 'LogirefVerification::index_post');
    $routes->post('etoll/LogirefVerificationTicket', 'LogirefVerificationTicket::index_post');
    $routes->post('etoll/PayViaIllicocash', 'PayViaIllicocash::index_post');
    $routes->post('etoll/LogirefSynchronizePaiement', 'LogirefSynchronizePaiement::index_post');
    $routes->post('etoll/LogirefSynchronizeTicket', 'LogirefSynchronizeTicket::index_post');
    $routes->post('etoll/LogirefSynchronizeConfirmation', 'LogirefSynchronizeConfirmation::index_post');
    $routes->post('etoll/LogirefSynchronizeConfirmationTicket', 'LogirefSynchronizeConfirmationTicket::index_post');
});

/** MCF endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\MCF\Controllers'], ['filter' => 'excludeServices'], function ($routes) {
    /** Authentification endpoint */
    $routes->post('mcf/auth/login', 'Auth::login_post');

    $routes->post('mcf/invoiceQuery', 'InvoiceQuery::invoice_query');

    $routes->post('mcf/checkInvoice', 'CheckInvoice::check_invoice');
    $routes->post('mcf/confirmPayment', 'ConfirmPaiement::confirm_payment');
    $routes->post('mcf/cancelInvoice', 'CancelInvoice::cancel_invoice');

    $routes->post('mcf/payment/init', 'PaymentController::init_payment');
    $routes->get('mcf/payment/verify/(:any)/(:any)', 'PaymentController::check_payment_status/$1/$2');
});

/** Payments endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Payments\Controllers'], ['filter' => 'excludeServices'], function ($routes) {
    $routes->post('payments/auth/login', 'Authentication::login');
    $routes->post('payments/payment/init', 'PaymentController::init_payment');
    $routes->post('payments/payment/nowsynch', 'PaymentController::pay_now_synch');
    $routes->post('payments/payment/callback', 'PaymentController::handle_callback');
    $routes->get('payments/payment/verify', 'PaymentController::verify_payment');
});

/** generating CSRF Token */
$routes->get('services/generate_csrf', 'LogirefCsrf::getCSRF', ['namespace' => 'Modules\Services\LogirefCSRF\Controllers']);

/** Crons Endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Crons\Controllers'], function ($routes) {
    /** Crons */
    $routes->match(['post', 'get'], 'elicense/actualisation', 'Elicense::actualisation');
    $routes->match(['post', 'get'], 'elicense/miseAjourDeIsys', 'Elicense::miseAjourDeIsys');
    $routes->get('prepayments/prepaymentslist', 'Prepayments::prepaymentslist');
    $routes->get('prepayments/prepaymentslist/(:any)', 'Prepayments::prepaymentslist/$1');
    $routes->get('prepayments/prepaymentslist/(:any)/(:any)', 'Prepayments::prepaymentslist/$1/$2');

    $routes->get('etaxlogs/writing', 'EtaxLogs::writing');
});

/** Ussd Endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Ussd\Tmb\Controllers'], function ($routes) {
    /** Ussd */
    $routes->match(['post', 'get'], 'ussd/authentification', 'Ussd::authentification');

    //** Cashout Endpoints */
    $routes->post('ussd/cashout_transaction', 'Ussd::cashout_transaction');
    $routes->post('ussd/cashout_verify_otp', 'Ussd::cashout_verify_otp');

    //** Cashin Endpoints */
    $routes->match(['post', 'get'], 'ussd/cashin', 'Ussd::cashin');

});

/** Logiref Endpoints */
$routes->group('services', ['namespace' => 'Modules\Services\Logiref\Controllers'], function ($routes) {

    $routes->post('logiref/auth/login', 'Auth::login');

    /** document endpoints */
    $routes->post('logiref/checkDocument', 'LogirefCheckDocument::check_document');
    $routes->post('logiref/makePayment', 'LogirefMakePayment::make_payment');
    $routes->post('logiref/testInfobipEmail', 'TestInfobipEmail::send');

    $routes->post('logiref/v2/(:segment)/checkDocument', 'Logiref::check_document/$1');
    $routes->post('logiref/v2/(:segment)/makePayment', 'Logiref::make_payment/$1');

    /** passport endpoints */
    $routes->post('logiref/checkPassport', 'Logiref::check_passport');
    $routes->post('logiref/makePaymentPassport', 'Logiref::make_payment_passport');

    /** autres endpoints */
    $routes->post('logiref/register', 'LogirefRegister::register');
});

/** Permis services */
$routes->group('services',['namespace'=>'Modules\Services\Permis\Controllers'],function($routes){
    /** Make Payment Endpoint */
    $routes->post('permis/makePayment', 'MakePayment::make_payment_permis');
});

/** Immatriculation services */
$routes->group('services',['namespace'=>'Modules\Services\Immatriculation\Controllers'],function($routes){
    /** Make Payment Endpoint */
    $routes->post('immatriculation/makePayment', 'MakePayment::make_payment_immatriculation');
});

/** Seguce services */
$routes->group('services',['namespace'=>'Modules\Services\Seguce\Controllers'],function($routes){

    // GuiceService orchestration
    $routes->post('guiceService/verifyInvoice', 'GuiceServices::verify_invoice');
    $routes->post('guiceService/treatInvoice', 'GuiceServices::treat_invoice');
    $routes->post('guiceService/reservation', 'GuiceServices::reservation');
    $routes->post('guiceService/validateInvoice', 'GuiceServices::validate_invoice');

    $routes->post('InvoiceCheck/invoice', 'InvoiceCheck::invoice');
    $routes->post('InvoiceTreatment/invoice', 'InvoiceTreatment::treat_invoice');
    $routes->post('InvoiceReservation/invoice', 'InvoiceReservation::reserve_invoice');
    $routes->post('InvoiceValidation/invoice', 'InvoiceValidation::validate_invoice');

    // SEGUCE API endpoints
    $routes->post('seguce/invoiceQuery','InvoiceQuery::get_invoice');
    $routes->post('seguce/settleInvoice','SettleInvoice::confirm_invoice');
});

/** Passeport services */
$routes->group('services',['namespace'=>'Modules\Services\Pass\Controllers'],function($routes){

    // GuiceService orchestration
    $routes->post('guiceService/verifyInvoice', 'GuiceServices::verify_invoice');
    $routes->post('guiceService/treatInvoice', 'GuiceServices::treat_invoice');
    $routes->post('guiceService/reservation', 'GuiceServices::reservation');
    $routes->post('guiceService/validateInvoice', 'GuiceServices::validate_invoice');

    // SEGUCE API endpoints
    $routes->post('seguce/invoiceQuery','InvoiceQuery::get_invoice');
    $routes->post('seguce/settleInvoice','SettleInvoice::confirm_invoice');
});


/** Alias de compatibilité avec les anciennes URL en majuscule. */
$routes->group('Branch', ['namespace' => 'Modules\\Branch\\Controllers'], function ($routes) {
    $routes->match(['post', 'get'], 'taximpression/display/(:any)/(:any)', 'TaxImpression::display/$1/$2');
    $routes->match(['post', 'get'], 'taximpression/display/(:any)', 'TaxImpression::display/$1');
});

/** Routing for Branchless Module */
$routes->group('branchless', ['namespace' => 'Modules\Branchless\Controllers'], function ($routes) {

    // Redirection par défaut /branchless -> Main::home
    $routes->get('/', 'Main::home');

    /** Main */
    $routes->get('main/home', 'Main::home');
    $routes->get('main/set/(:any)', 'Main::set/$1');
    $routes->get('main', 'main::home');
    $routes->match(['get', 'post'], 'main/(:any)', 'Main::$1');
    $routes->match(['get'], 'checksession', 'Main::check_session');
    $routes->match(['get'], 'denied', 'Main::denied');

    /** Rbo */
    $routes->get('rbo/set/(:any)', 'Rbo::set/$1');
    $routes->get('rbo/(:any)', 'Rbo::$1');
    $routes->get('rbo', 'Rbo');
    $routes->get('rbo/set/(:any)', 'Rbo::set/$1');

    $routes->match(['post', 'get'], 'rbo/display/(:any)', 'Rbo::display/$1');
    $routes->match(['post', 'get'], 'rbo/save/(:any)', 'Rbo::save/$1');
    $routes->match(['post', 'get'], 'rbo/save/(:any)', 'Rbo::save/$1');
    $routes->match(['post', 'get'], 'rbo/save/(:any)/(:any)', 'Rbo::save/$1/$2');
    $routes->match(['post', 'get'], 'rbo/save/(:any)/(:any)/(:any)', 'Rbo::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'rbo/data/(:any)', 'Rbo::data/$1');

    /** Dashboards */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)', 'Dashboards::save/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)', 'Dashboards::save/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)', 'Dashboards::save/$1/$2');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)/(:any)', 'Dashboards::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'dashboards/data/(:any)', 'Dashboards::data/$1');

    /** Bulletin */
    $routes->get('bulletin/set/(:any)', 'Bulletin::set/$1');
    $routes->match(['post', 'get'], 'bulletin/display/(:any)', 'Bulletin::display/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)', 'Bulletin::save/$1/$2');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)/(:any)', 'Bulletin::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'bulletin/data/(:any)', 'Bulletin::data/$1');

    /** Declaration */
    $routes->get('declaration/set/(:any)', 'Declaration::set/$1');
    $routes->match(['post', 'get'], 'declaration/display/(:any)', 'Declaration::display/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)', 'Declaration::save/$1/$2');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)/(:any)', 'Declaration::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'declaration/data/(:any)', 'Declaration::data/$1');

    /** Notes */
    $routes->get('notes/set/(:any)', 'Notes::set/$1');
    $routes->match(['post', 'get'], 'notes/display/(:any)', 'Notes::display/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)', 'Notes::save/$1/$2');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)/(:any)', 'Notes::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'notes/data/(:any)', 'Notes::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');

    /** QleadsAppointement */
    $routes->get('qleadsappointement/set/(:any)', 'QleadsAppointement::set/$1');
    $routes->match(['post', 'get'], 'qleadsappointement/display/(:any)', 'QleadsAppointement::display/$1');
    $routes->match(['post', 'get'], 'qleadsappointement/save/(:any)', 'QleadsAppointement::save/$1');
    $routes->match(['post', 'get'], 'qleadsappointement/save/(:any)', 'QleadsAppointement::save/$1');
    $routes->match(['post', 'get'], 'qleadsappointement/save/(:any)/(:any)', 'QleadsAppointement::save/$1/$2');
    $routes->match(['post', 'get'], 'qleadsappointement/save/(:any)/(:any)/(:any)', 'QleadsAppointement::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'qleadsappointement/data/(:any)', 'QleadsAppointement::data/$1');
    /** .... */
});

/**
 * Routing for NetBank TMB
 */
$routes->group('branchless/tmb', ['namespace' => 'App\Modules\Branchless\Tmb\Controllers'], function ($routes) {

    /** Main */
    $routes->get('main/signin', 'Main::signin');
    $routes->get('main/set/(:any)', 'Main::set/$1');
    $routes->get('main/(:any)', 'Main::$1');

    // Rediriger vers 'signin' si aucune méthode spécifique n'est précisée
    $routes->get('main', 'Main::signin');

    $routes->match(['post', 'get'], 'main/validate_otp', 'Main::validate_otp');
    $routes->match(['get'], 'main/overview', 'Main::overview');
    $routes->match(['post', 'get'], 'main/display/(:any)', 'Main::display/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)', 'Main::save/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)', 'Main::save/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)/(:any)', 'Main::save/$1/$2');
    $routes->match(['post', 'get'], 'main/save/(:any)/(:any)/(:any)', 'Main::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'main/data/(:any)', 'Main::data/$1');


    /** Bulletin */
    $routes->get('bulletin/set/(:any)', 'Bulletin::set/$1');
    $routes->match(['post', 'get'], 'bulletin/display/(:any)', 'Bulletin::display/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)', 'Bulletin::save/$1/$2');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)/(:any)', 'Bulletin::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'bulletin/data/(:any)', 'Bulletin::data/$1');

    /** Declaration */
    $routes->get('declaration/set/(:any)', 'Declaration::set/$1');
    $routes->match(['post', 'get'], 'declaration/display/(:any)', 'Declaration::display/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)', 'Declaration::save/$1/$2');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)/(:any)', 'Declaration::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'declaration/data/(:any)', 'Declaration::data/$1');

    /** Notes */
    $routes->get('notes/set/(:any)', 'Notes::set/$1');
    $routes->match(['post', 'get'], 'notes/display/(:any)', 'Notes::display/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)', 'Notes::save/$1/$2');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)/(:any)', 'Notes::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'notes/data/(:any)', 'Notes::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');
});

/**
 * Routing for NetBank Sofibanque
 */
$routes->group('branchless/sofibanque', ['namespace' => 'App\Modules\Branchless\Sofibanque\Controllers'], function ($routes) {
    /** Main */
    $routes->get('main/signin', 'Main::signin');
    $routes->get('main/set/(:any)', 'Main::set/$1');
    $routes->get('main/(:any)', 'Main::$1');

    // Rediriger vers 'signin' si aucune méthode spécifique n'est précisée
    $routes->get('main', 'Main::signin');

    $routes->match(['post', 'get'], 'main/validate_otp', 'Main::validate_otp');
    $routes->match(['get'], 'main/overview', 'Main::overview');
    $routes->match(['post', 'get'], 'main/display/(:any)', 'Main::display/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)', 'Main::save/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)', 'Main::save/$1');
    $routes->match(['post', 'get'], 'main/save/(:any)/(:any)', 'Main::save/$1/$2');
    $routes->match(['post', 'get'], 'main/save/(:any)/(:any)/(:any)', 'Main::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'main/data/(:any)', 'Main::data/$1');

    /** Bulletin */
    $routes->get('bulletin/set/(:any)', 'Bulletin::set/$1');
    $routes->match(['post', 'get'], 'bulletin/display/(:any)', 'Bulletin::display/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)', 'Bulletin::save/$1');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)', 'Bulletin::save/$1/$2');
    $routes->match(['post', 'get'], 'bulletin/save/(:any)/(:any)/(:any)', 'Bulletin::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'bulletin/data/(:any)', 'Bulletin::data/$1');

    /** Declaration */
    $routes->get('declaration/set/(:any)', 'Declaration::set/$1');
    $routes->match(['post', 'get'], 'declaration/display/(:any)', 'Declaration::display/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)', 'Declaration::save/$1');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)', 'Declaration::save/$1/$2');
    $routes->match(['post', 'get'], 'declaration/save/(:any)/(:any)/(:any)', 'Declaration::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'declaration/data/(:any)', 'Declaration::data/$1');

    /** Notes */
    $routes->get('notes/set/(:any)', 'Notes::set/$1');
    $routes->match(['post', 'get'], 'notes/display/(:any)', 'Notes::display/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)', 'Notes::save/$1');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)', 'Notes::save/$1/$2');
    $routes->match(['post', 'get'], 'notes/save/(:any)/(:any)/(:any)', 'Notes::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'notes/data/(:any)', 'Notes::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');
});

/**
 * Routing for Eximtrade Module
 */
$routes->group('eximtrade', ['namespace' => 'Modules\Eximtrade\Controllers'], function ($routes) {

    /** Dashboard */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)', 'Dashboards::save/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)', 'Dashboards::save/$1/$2');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)/(:any)', 'Dashboards::save/$1/$2/$3');

    /** Seguce */
    $routes->get('seguce/set/(:any)', 'Seguce::set/$1');
    $routes->match(['post', 'get'], 'seguce/display/(:any)', 'Seguce::display/$1');
    $routes->match(['post', 'get'], 'seguce/save/(:any)', 'Seguce::save/$1');
    $routes->match(['post', 'get'], 'seguce/save/(:any)/(:any)', 'Seguce::save/$1/$2');
    $routes->match(['post', 'get'], 'seguce/save/(:any)/(:any)/(:any)', 'Seguce::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'seguce/data/(:any)', 'Seguce::data/$1');


    /** Guice */
    $routes->get('guice/set/(:any)', 'Guice::set/$1');
    $routes->match(['post', 'get'], 'guice/display/(:any)', 'Guice::display/$1');
    $routes->match(['post', 'get'], 'guice/save/(:any)', 'Guice::save/$1');
    $routes->match(['post', 'get'], 'guice/save/(:any)/(:any)', 'Guice::save/$1/$2');
    $routes->match(['post', 'get'], 'guice/save/(:any)/(:any)/(:any)', 'Guice::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'guice/data/(:any)', 'Guice::data/$1');

    /** Equalize */
    $routes->get('equalize/set/(:any)', 'Equalize::set/$1');
    $routes->match(['post', 'get'], 'equalize/display/(:any)', 'Equalize::display/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)', 'Equalize::save/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)', 'Equalize::save/$1/$2');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)/(:any)', 'Equalize::save/$1/$2/$3');

    /** elecense */
    $routes->get('elicense/set/(:any)', 'Elicense::set/$1');
    $routes->match(['post', 'get'], 'elicense/display/(:any)', 'Elicense::display/$1');
    $routes->match(['post', 'get'], 'elicense/data/(:any)', 'Elicense::data/$1');
    $routes->match(['post', 'get'], 'elicense/save/(:any)', 'Elicense::save/$1');
    $routes->match(['post', 'get'], 'elicense/save/(:any)/(:any)', 'Elicense::save/$1/$2');
    $routes->match(['post', 'get'], 'elicense/save/(:any)/(:any)/(:any)', 'Elicense::save/$1/$2/$3');

    /** reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['get','post'], 'reports/data/(:any)', 'Reports::data/$1');
    $routes->match(['get','post'], 'reports/data/(:any)/(:any)', 'Reports::data/$1/$2');
    $routes->match(['get','post'], 'reports/data/(:any)/(:any)/(:any)', 'Reports::data/$1/$2/$3');
    $routes->match(['get','post'], 'reports/data/(:any)/(:any)/(:any)/(:any)', 'Reports::data/$1/$2/$3/$4');

    /** TaxImpression */
    $routes->get('impression/set/(:any)', 'Impression::set/$1');
    $routes->match(['post', 'get'], 'impression/display/(:any)', 'Impression::display/$1');

    /** Accounts */
    $routes->get('accounts/set/(:any)', 'Accounts::set/$1');
    $routes->match(['post', 'get'], 'accounts/display/(:any)', 'Accounts::display/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)', 'Accounts::save/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)', 'Accounts::save/$1/$2');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'accounts/data/(:any)', 'Accounts::data/$1');

    /** reports */
    $routes->get('comptabilisation/set/(:any)', 'Comptabilisation::set/$1');
    $routes->match(['post', 'get'], 'comptabilisation/display/(:any)', 'Comptabilisation::display/$1');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)', 'Comptabilisation::save/$1');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)/(:any)', 'Comptabilisation::save/$1/$2');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)/(:any)/(:any)', 'Comptabilisation::save/$1/$2/$3');

    /** Settings */
    $routes->get('settings/set/(:any)', 'Settings::set/$1');
    $routes->match(['post', 'get'], 'settings/display/(:any)', 'Settings::display/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)', 'Settings::save/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)', 'Settings::save/$1/$2');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)/(:any)', 'Settings::data/$1/$2/$3');
    $routes->match(['post', 'get'], 'settings/data/(:any)', 'Settings::data/$1');
});

/** Routing for Etoll Module */
$routes->group('etoll', ['namespace' => 'Modules\Etoll\Controllers'], function ($routes) {
    /** EtollScanning */
    $routes->get('scanningQrCode', 'scanningQrCode::init_scan');
    /** .... */

    /** Dashboard */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)', 'Dashboards::save/$1');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)', 'Dashboards::save/$1/$2');
    $routes->match(['post', 'get'], 'dashboards/save/(:any)/(:any)/(:any)', 'Dashboards::save/$1/$2/$3');

    /** Accounts */
    $routes->get('accounts/set/(:any)', 'Accounts::set/$1');
    $routes->match(['post', 'get'], 'accounts/display/(:any)', 'Accounts::display/$1');
    $routes->match(['post', 'get'], 'accounts/data/(:any)', 'Accounts::data/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)', 'Accounts::save/$1');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)', 'Accounts::save/$1/$2');
    $routes->match(['post', 'get'], 'accounts/save/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');

    /** Branches */
    $routes->get('branches/set/(:any)', 'Branches::set/$1');
    $routes->match(['post', 'get'], 'branches/display/(:any)', 'Branches::display/$1');
    $routes->match(['post', 'get'], 'branches/save/(:any)', 'Branches::save/$1');
    $routes->match(['post', 'get'], 'branches/save/(:any)/(:any)', 'Branches::save/$1/$2');
    $routes->match(['post', 'get'], 'branches/save/(:any)/(:any)/(:any)', 'Branches::save/$1/$2/$3');

    /** Caisses */
    $routes->get('caisses/set/(:any)', 'Caisses::set/$1');
    $routes->match(['post', 'get'], 'caisses/display/(:any)', 'Caisses::display/$1');
    $routes->match(['post', 'get'], 'caisses/save/(:any)', 'Caisses::save/$1');
    $routes->match(['post', 'get'], 'caisses/save/(:any)/(:any)', 'Caisses::save/$1/$2');
    $routes->match(['post', 'get'], 'caisses/save/(:any)/(:any)/(:any)', 'Caisses::save/$1/$2/$3');

    /** Cashbooks */
    $routes->get('cashbooks/set/(:any)', 'Cashbooks::set/$1');
    $routes->match(['post', 'get'], 'cashbooks/display/(:any)', 'Cashbooks::display/$1');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)', 'Cashbooks::save/$1');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)/(:any)', 'Cashbooks::save/$1/$2');
    $routes->match(['post', 'get'], 'cashbooks/save/(:any)/(:any)/(:any)', 'Cashbooks::save/$1/$2/$3');

    /** Comptabilisation */
    $routes->get('comptabilisation/set/(:any)', 'Comptabilisation::set/$1');
    $routes->match(['post', 'get'], 'comptabilisation/display/(:any)', 'Comptabilisation::display/$1');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)', 'Comptabilisation::save/$1');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)/(:any)', 'Comptabilisation::save/$1/$2');
    $routes->match(['post', 'get'], 'comptabilisation/save/(:any)/(:any)/(:any)', 'Comptabilisation::save/$1/$2/$3');

    /** Counters */
    $routes->get('counters/set/(:any)', 'Counters::set/$1');
    $routes->match(['post', 'get'], 'counters/display/(:any)', 'Counters::display/$1');
    $routes->match(['post', 'get'], 'counters/save/(:any)', 'Counters::save/$1');
    $routes->match(['post', 'get'], 'counters/save/(:any)/(:any)', 'Counters::save/$1/$2');
    $routes->match(['post', 'get'], 'counters/save/(:any)/(:any)/(:any)', 'Counters::save/$1/$2/$3');

    /** Encaissement */
    $routes->get('encaissement/set/(:any)', 'Encaissement::set/$1');
    $routes->match(['post', 'get'], 'encaissement/display/(:any)', 'Encaissement::display/$1');
    $routes->match(['post', 'get'], 'encaissement/save/(:any)', 'Encaissement::save/$1');
    $routes->match(['post', 'get'], 'encaissement/save/(:any)/(:any)', 'Encaissement::save/$1/$2');
    $routes->match(['post', 'get'], 'encaissement/save/(:any)/(:any)/(:any)', 'Encaissement::save/$1/$2/$3');

    /** Equalize */
    $routes->get('equalize/set/(:any)', 'Equalize::set/$1');
    $routes->match(['post', 'get'], 'equalize/display/(:any)', 'Equalize::display/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)', 'Equalize::save/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)', 'Equalize::save/$1/$2');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)/(:any)', 'Equalize::save/$1/$2/$3');

    /** Events */
    $routes->get('events/set/(:any)', 'Events::set/$1');
    $routes->match(['post', 'get'], 'events/display/(:any)', 'Events::display/$1');
    $routes->match(['post', 'get'], 'events/save/(:any)', 'Events::save/$1');
    $routes->match(['post', 'get'], 'events/save/(:any)/(:any)', 'Events::save/$1/$2');
    $routes->match(['post', 'get'], 'events/save/(:any)/(:any)/(:any)', 'Events::save/$1/$2/$3');

    /** Impression */
    $routes->get('impression/set/(:any)', 'Impression::set/$1');
    $routes->match(['post', 'get'], 'impression/display/(:any)', 'Impression::display/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)', 'Impression::save/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)', 'Impression::save/$1/$2');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)/(:any)', 'Impression::save/$1/$2/$3');

    /** Logs */
    $routes->get('logs/set/(:any)', 'Logs::set/$1');
    $routes->match(['post', 'get'], 'logs/display/(:any)', 'Logs::display/$1');
    $routes->match(['post', 'get'], 'logs/save/(:any)', 'Logs::save/$1');
    $routes->match(['post', 'get'], 'logs/save/(:any)/(:any)', 'Logs::save/$1/$2');
    $routes->match(['post', 'get'], 'logs/save/(:any)/(:any)/(:any)', 'Logs::save/$1/$2/$3');

    /** Partners */
    $routes->get('partners/set/(:any)', 'Partners::set/$1');
    $routes->match(['post', 'get'], 'partners/display/(:any)', 'Partners::display/$1');
    $routes->match(['post', 'get'], 'partners/save/(:any)', 'Partners::save/$1');
    $routes->match(['post', 'get'], 'partners/save/(:any)/(:any)', 'Partners::save/$1/$2');
    $routes->match(['post', 'get'], 'partners/save/(:any)/(:any)/(:any)', 'Partners::save/$1/$2/$3');

    /** Pos */
    $routes->get('pos/set/(:any)', 'Pos::set/$1');
    $routes->match(['post', 'get'], 'pos/display/(:any)', 'Pos::display/$1');
    $routes->match(['post', 'get'], 'pos/save/(:any)', 'Pos::save/$1');
    $routes->match(['post', 'get'], 'pos/save/(:any)/(:any)', 'Pos::save/$1/$2');
    $routes->match(['post', 'get'], 'pos/save/(:any)/(:any)/(:any)', 'Pos::save/$1/$2/$3');

    /** Products */
    $routes->get('products/set/(:any)', 'Products::set/$1');
    $routes->match(['post', 'get'], 'products/display/(:any)', 'Products::display/$1');
    $routes->match(['post', 'get'], 'products/save/(:any)', 'Products::save/$1');
    $routes->match(['post', 'get'], 'products/save/(:any)/(:any)', 'Products::save/$1/$2');
    $routes->match(['post', 'get'], 'products/save/(:any)/(:any)/(:any)', 'Products::save/$1/$2/$3');

    /** Rates */
    $routes->get('rates/set/(:any)', 'Rates::set/$1');
    $routes->match(['post', 'get'], 'rates/display/(:any)', 'Rates::display/$1');
    $routes->match(['post', 'get'], 'rates/save/(:any)', 'Rates::save/$1');
    $routes->match(['post', 'get'], 'rates/save/(:any)/(:any)', 'Rates::save/$1/$2');
    $routes->match(['post', 'get'], 'rates/save/(:any)/(:any)/(:any)', 'Rates::save/$1/$2/$3');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)/(:any)', 'Reports::display/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');

    /** Settings */
    $routes->get('settings/set/(:any)', 'Settings::set/$1');
    $routes->match(['post', 'get'], 'settings/display/(:any)', 'Settings::display/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)', 'Settings::save/$1');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)', 'Settings::save/$1/$2');
    $routes->match(['post', 'get'], 'settings/save/(:any)/(:any)/(:any)', 'Settings::save/$1/$2/$3');

    /** Stakeholders */
    $routes->get('stakeholders/set/(:any)', 'Stakeholders::set/$1');
    $routes->match(['post', 'get'], 'stakeholders/display/(:any)', 'Stakeholders::display/$1');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)', 'Stakeholders::save/$1');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)/(:any)', 'Stakeholders::save/$1/$2');
    $routes->match(['post', 'get'], 'stakeholders/save/(:any)/(:any)/(:any)', 'Stakeholders::save/$1/$2/$3');

    /** Tickets */
    $routes->get('tickets/set/(:any)', 'Tickets::set/$1');
    $routes->match(['post', 'get'], 'tickets/display/(:any)', 'Tickets::display/$1');
    $routes->match(['post', 'get'], 'tickets/save/(:any)', 'Tickets::save/$1');
    $routes->match(['post', 'get'], 'tickets/save/(:any)/(:any)', 'Tickets::save/$1/$2');
    $routes->match(['post', 'get'], 'tickets/save/(:any)/(:any)/(:any)', 'Tickets::save/$1/$2/$3');

    /** Tolls */
    $routes->get('tolls/set/(:any)', 'Tolls::set/$1');
    $routes->match(['post', 'get'], 'tolls/display/(:any)', 'Tolls::display/$1');
    $routes->match(['post', 'get'], 'tolls/save/(:any)', 'Tolls::save/$1');
    $routes->match(['post', 'get'], 'tolls/save/(:any)/(:any)', 'Tolls::save/$1/$2');
    $routes->match(['post', 'get'], 'tolls/save/(:any)/(:any)/(:any)', 'Tolls::save/$1/$2/$3');

    /** Users */
    $routes->get('users/set/(:any)', 'Users::set/$1');
    $routes->match(['post', 'get'], 'users/display/(:any)', 'Users::display/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)', 'Users::save/$1');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)', 'Users::save/$1/$2');
    $routes->match(['post', 'get'], 'users/save/(:any)/(:any)/(:any)', 'Users::save/$1/$2/$3');
});

$routes->group('payroll', ['namespace' => 'Modules\Payroll\Controllers'], function ($routes) {

     /** Dashboards */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');
    
    $routes->get('bank/set/(:any)', 'Payroll::set/$1');
    $routes->match(['post', 'get'], 'bank/display/(:any)', 'Payroll::display/$1');
    $routes->match(['post', 'get'], 'bank/save/(:any)', 'Payroll::save/$1');
    $routes->match(['post', 'get'], 'bank/save/(:any)/(:any)', 'Payroll::save/$1/$2');
    $routes->match(['post', 'get'], 'bank/save/(:any)/(:any)/(:any)', 'Payroll::data/$1/$2/$3');
    $routes->match(['post', 'get'], 'bank/data/(:any)', 'Payroll::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');
});

$routes->group('immatriculation', ['namespace' => 'Modules\Immatriculation\Controllers'], function ($routes) {
     /** Dashboards */
    $routes->get('dashboards/set/(:any)', 'Dashboards::set/$1');
    $routes->match(['post', 'get'], 'dashboards/display/(:any)', 'Dashboards::display/$1');
    
    // Encaissement
    $routes->get('bank/set/(:any)', 'Encaissement::set/$1');
    $routes->match(['post', 'get'], 'bank/display/(:any)', 'Encaissement::display/$1');
    $routes->match(['post', 'get'], 'bank/save/(:any)', 'Encaissement::save/$1');
    $routes->match(['post', 'get'], 'bank/save/(:any)/(:any)', 'Encaissement::save/$1/$2');
    $routes->match(['post', 'get'], 'bank/save/(:any)/(:any)/(:any)', 'Encaissement::data/$1/$2/$3');
    $routes->match(['post', 'get'], 'bank/data/(:any)', 'Encaissement::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');
});


$routes->group('migrateflow', ['namespace' => 'Modules\MigrateFlow\Controllers'], function ($routes) {
    $routes->get('/', 'MigrateFlow::index');
    $routes->get('backup/(:any)', 'MigrateFlow::backup_data/$1');
    $routes->get('backup/(:any)/(:any)', 'MigrateFlow::backup_data/$1/$2');
    $routes->get('test_connection', 'MigrateFlow::test_connection');
    $routes->match(['get', 'post'], 'action/(:any)', 'MigrateFlow::action/$1');
    $routes->match(['get', 'post'], 'action/(:any)/(:any)', 'MigrateFlow::action/$1/$2');
});

$routes->group('bsqr-middle-ware', ['namespace' => 'Modules\Services\BsqrMiddleWare\Controllers'], function ($routes) {
    $routes->get('api/authenticate', 'BsqrMiddleWare::authentification');
    $routes->get('api/accountInfo/(:any)', 'BsqrMiddleWare::account_info/$1');
    $routes->get('api/exchangeRates/(:any)', 'BsqrMiddleWare::exchange_rate/$1');
    $routes->post('api/transferMoney/(:any)', 'BsqrMiddleWare::payment_transfer/$1');
});

$routes->group('services', ['namespace' => 'Modules\Services\Chatbots\Controllers'], function ($routes) {
    $routes->post('chatbots/users/create', 'Users::create');
});

/** *
 *  --------------------------------------------------------------------
 * API Externe - Bulletin (v1)
 * --------------------------------------------------------------------
 */
$routes->group('api/bulletin', ['namespace' => 'Modules\Services\Bulletin\Controllers\Api'], function($routes) {
    $routes->get('credentials/(:segment)', 'BulletinRest::get_credentials/$1');
    $routes->post('check-single', 'BulletinRest::check_single');
    $routes->post('confirm-single', 'BulletinRest::confirm_single');
    $routes->post('check-batch', 'BulletinRest::check_batch');
    $routes->post('confirm-batch', 'BulletinRest::confirm_batch');
});

// $routes->group('services',['namespace'=>'Modules\Services\Sydonia\Controllers'],function($routes){
//     $routes->match(['get','post'], 'comptant-single', 'SimulationComptant::comptant');
// });

// Inclure les routes du module Bulletin
if (is_file(ROOTPATH . 'Modules/Services/Bulletin/Config/Routes.php')) {
    require ROOTPATH . 'Modules/Services/Bulletin/Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Routes pour le module Branch - Batch Processing
 * --------------------------------------------------------------------
 */
$routes->group('branch', ['namespace' => 'App\Modules\Branch\Controllers'], function ($routes) {
    /** BatchController - Traitement batch des bulletins */
    $routes->get('batch/set/(:any)', 'BatchController::set/$1');
    $routes->match(['post', 'get'], 'batch/display/(:any)', 'BatchController::display/$1');
    $routes->match(['post', 'get'], 'batch/save/(:any)', 'BatchController::save/$1');
    $routes->match(['post', 'get'], 'batch/save/(:any)/(:any)', 'BatchController::save/$1/$2');
    $routes->match(['post', 'get'], 'batch/save/(:any)/(:any)/(:any)', 'BatchController::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'batch/data/(:any)', 'BatchController::data/$1');
});

/**
 * Routing for Inv Module APIs
 */
$routes->group('api/inv', ['namespace' => 'Modules\Services\Inv\Controllers'], function ($routes) {
    $routes->post('confirm-payment', 'InvConfirmPayment::confirm_payment');
    $routes->post('delete-payment', 'InvDeletePayment::delete_payment');
    $routes->get('unequalized', 'InvEqualize::unequalized');
    $routes->get('regularisation-dgi-immatriculation', 'InvEqualize::regularisation_dgi_immatriculation');
    $routes->get('details-immatriculation/(:any)', 'InvEqualize::get_details_immatriculation/$1');
    $routes->post('regularize-payment-immatriculation', 'InvEqualize::regularize_payment_immatriculation');
    $routes->post('validate-immatriculation', 'InvEqualize::validate_immatriculation');
    $routes->post('attestation', 'InvImpression::attestation');
    $routes->post('mail', 'InvImpression::mail');
    $routes->post('schema-immatriculation', 'InvImpression::schema_immatriculation');
    $routes->post('integration-sftp', 'InvIntegrationSFTP::integration_sftp');
    $routes->get('nvalidated-immatriculation', 'InvReports::nvalidated_immatriculation');
    $routes->get('validated-immatriculation', 'InvReports::validated_immatriculation');
    $routes->post('save-cbs-journalisation', 'InvSaveCbsJournalisation::save_cbs_journalisation');
    $routes->post('save-payment', 'InvSavePayment::save_payment');
    $routes->post('treatment-payment', 'InvTreatmentPayment::treatement_payment');
    $routes->post('update-payment', 'InvUpdatePayment::index');
    $routes->post('validate-payment', 'InvValidationPayment::validate_payment');
    $routes->post('verification-note', 'InvVerificationPayment::verification_note');
    $routes->post('instructions-immatriculation', 'InvComptabisation::instructions_immatric');
    $routes->post('accountname', 'InvAccounts::get_accountname');
    $routes->post('customeraccounts', 'InvAccounts::get_customeraccounts');
    $routes->post('accountinternal', 'InvAccounts::get_accountinternal');
    $routes->post('accountname_internal', 'InvAccounts::get_accountname_internal');
    $routes->post('account_balance', 'InvAccounts::get_account_balance');
    $routes->post('account_exemption', 'InvAccounts::get_account_exemption');
});

/**
 * Routing for Inv Module Web Interface
 */
$routes->group('inv', ['namespace' => 'Modules\Inv\Controllers'], function ($routes) {
    /** Accounts */
    $routes->match(['post', 'get'], 'accounts/data/(:any)/(:any)/(:any)', 'Accounts::save/$1/$2/$3');

    /** Comptabilisation */
    $routes->match(['post', 'get'], 'comptabilisation/display/(:any)/(:any)/(:any)', 'Comptabilisation::display/$1/$2/$3');

    /** Equalize */
    $routes->get('equalize/set/(:any)', 'Equalize::set/$1');
    $routes->match(['post', 'get'], 'equalize/display/(:any)', 'Equalize::display/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)', 'Equalize::save/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)', 'Equalize::save/$1/$2');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)/(:any)', 'Equalize::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'equalize/data/(:any)', 'Equalize::data/$1');

    /** Immatriculation */
    $routes->match(['post', 'get'], 'immatriculation/set/(:any)', 'Immatriculation::set/$1');
    $routes->match(['post', 'get'], 'immatriculation/display/(:any)', 'Immatriculation::display/$1');
    $routes->match(['post', 'get'], 'immatriculation/save/(:any)', 'Immatriculation::save/$1');
    $routes->match(['post', 'get'], 'immatriculation/save/(:any)/(:any)', 'Immatriculation::save/$1/$2');
    $routes->match(['post', 'get'], 'immatriculation/save/(:any)/(:any)/(:any)', 'Immatriculation::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'immatriculation/data/(:any)', 'Immatriculation::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');

    /** Impression */
    $routes->get('impression/set/(:any)', 'Impression::set/$1');
    $routes->match(['post', 'get'], 'impression/display/(:any)', 'Impression::display/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)', 'Impression::save/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)', 'Impression::save/$1/$2');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)/(:any)', 'Impression::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'impression/data/(:any)', 'Impression::data/$1');
});

/**
 * Routing for Passeport Module APIs
 */
$routes->group('api/passeport', ['namespace' => 'Modules\Services\Passeport\Controllers'], function ($routes) {
    $routes->post('confirm-payment', 'PasseportConfirmPayment::confirm_payment');
    $routes->post('delete-payment', 'PasseportDeletePayment::delete_payment');
    $routes->get('unequalized', 'PasseportEqualize::unequalized');
    $routes->get('regularisation', 'PasseportEqualize::regularisation');
    $routes->get('details-passeport/(:any)', 'PasseportEqualize::get_details_passeport/$1');
    $routes->post('regularize-payment-passeport', 'PasseportEqualize::regularize_payment_passeport');
    $routes->post('validate-passeport', 'PasseportEqualize::validate_passeport');
    $routes->post('attestation', 'PasseportImpression::attestation');
    $routes->post('mail', 'PasseportImpression::mail');
    $routes->post('schema-passeport', 'PasseportImpression::schema_passeport');
    $routes->post('save-payment', 'PasseportSavePayment::save_payment');
    $routes->post('update-payment', 'PasseportUpdatePayment::update_payment');
    $routes->post('validate-payment', 'PasseportValidation::validate_payment');
    $routes->post('verification-note', 'PasseportVerification::verification_notes');
    $routes->post('instructions-passeport', 'PasseportComptabilisation::instructions_passeport');
    $routes->post('accountname', 'PasseportAccounts::get_accountname');
    $routes->post('customeraccounts', 'PasseportAccounts::get_customeraccounts');
    $routes->post('accountinternal', 'PasseportAccounts::get_accountinternal');
    $routes->post('accountname_internal', 'PasseportAccounts::get_accountname_internal');
    $routes->post('account_balance', 'PasseportAccounts::get_account_balance');
    $routes->post('account_exemption', 'PasseportAccounts::get_account_exemption');
    $routes->get('reporting', 'PasseportReports::get_reporting');
});

/**
 * Routing for Passeport Module Web Interface
 */
$routes->group('passeport', ['namespace' => 'Modules\Passeport\Controllers'], function ($routes) {
    /** Accounts */
    $routes->match(['post', 'get'], 'accounts/data/(:any)/(:any)/(:any)', 'Accounts::data/$1/$2/$3');

    /** Comptabilisation */
    $routes->match(['post', 'get'], 'comptabilisation/display/(:any)/(:any)/(:any)', 'Comptabilisation::display/$1/$2/$3');

    /** Equalize */
    $routes->get('equalize/set/(:any)', 'Equalize::set/$1');
    $routes->match(['post', 'get'], 'equalize/display/(:any)', 'Equalize::display/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)', 'Equalize::save/$1');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)', 'Equalize::save/$1/$2');
    $routes->match(['post', 'get'], 'equalize/save/(:any)/(:any)/(:any)', 'Equalize::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'equalize/data/(:any)', 'Equalize::data/$1');

    /** Reports */
    $routes->get('reports/set/(:any)', 'Reports::set/$1');
    $routes->match(['post', 'get'], 'reports/display/(:any)', 'Reports::display/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)', 'Reports::save/$1');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)', 'Reports::save/$1/$2');
    $routes->match(['post', 'get'], 'reports/save/(:any)/(:any)/(:any)', 'Reports::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'reports/data/(:any)', 'Reports::data/$1');

    /** Impression */
    $routes->get('impression/set/(:any)', 'Impression::set/$1');
    $routes->match(['post', 'get'], 'impression/display/(:any)', 'Impression::display/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)', 'Impression::save/$1');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)', 'Impression::save/$1/$2');
    $routes->match(['post', 'get'], 'impression/save/(:any)/(:any)/(:any)', 'Impression::save/$1/$2/$3');
    $routes->match(['post', 'get'], 'impression/data/(:any)', 'Impression::data/$1');
});

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

// Plaques d'immatriculation: suivi en ligne et regularisation.
$routes->group('branch', ['namespace' => 'Modules\Branch\Controllers'], function ($routes) {
    $routes->match(['get'], 'taximmatriculationonline/set/(:any)', 'TaxImmatriculationOnline::set/$1');
    $routes->match(['post', 'get'], 'taximmatriculationonline/display/(:any)', 'TaxImmatriculationOnline::display/$1');
    $routes->match(['post', 'get'], 'taximmatriculationonline/save/(:any)', 'TaxImmatriculationOnline::save/$1');
    $routes->match(['get'], 'taxequalizeinv/set/(:any)', 'TaxEqualizeInv::set/$1');
    $routes->match(['post', 'get'], 'taxequalizeinv/display/(:any)', 'TaxEqualizeInv::display/$1');
    $routes->match(['post', 'get'], 'taxequalizeinv/save/(:any)', 'TaxEqualizeInv::save/$1');
});
