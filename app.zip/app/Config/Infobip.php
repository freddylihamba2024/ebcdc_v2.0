<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Infobip extends BaseConfig
{
    public string $baseUrl = 'https://x9v6e.api.infobip.com';
    public string $apiKey = 'e617326d2cb7b579d25b4d4efdf51361-3ce9210d-fe20-4858-8368-99790ee6979d';
    public string $defaultFrom = 'passeport@equitybcdc.cd';
    public string $passportFrom = 'passeport@equitybcdc.cd';
    public string $cashcloudFrom = 'dgda@equitybcdc.cd';
    public int $timeoutSeconds = 180;
    public bool $sslVerify = false;
    public string $sendPath = '/email/3/send';
    public string $reportsPath = '/email/1/reports';
    public string $messagesPath = '/messages-api/1/messages';
    public string $whatsappSender = '';
    public string $immatriculationWhatsappTemplate = '';
    public string $immatriculationWhatsappLanguage = 'fr';
    public string $whatsappDefaultCountryCode = '243';
    public string $publicAttestationBaseUrl = '';
    public array $immatriculationWhatsappBodyFields = [
        'customer_name',
        'note_reference',
    ];
    public array $supportAlertEmails = [
        'support@ikwook.cd',
        'freddy.lihamba@ikwook.cd',
    ];
    public int $trackingImmediateAttempts = 3;
    public int $trackingImmediateDelayMs = 1000;
    public int $trackingIntervalSeconds = 10;
    public int $trackingMaxLoops = 0;
    public bool $trackingStopWhenFound = true;
    public array $passportBccSuccess = [
        // 'Emmanuel.Nditukulu@equitybcdc.cd',
        // 'jose.mabuaka@equitybcdc.cd',
        // 'junior.baba@equitybcdc.cd',
        // 'Grace.Monzele@equitybcdc.cd',
        // 'tharcisse.mutombo@equitybcdc.cd',
        // 'olivier.muissa@equitybcdc.cd',
        // 'patrick.nkongolo@equitybcdc.cd',
        // 'support@ikwook.cd',
        // 'bruno.makembi@equitybcdc.cd',
        // 'bethy.mulanga@equitybcdc.cd',
        // 'niclette.kibundila@equitybcdc.cd',
        'freddy.lihamba@ikwook.cd'
    ];
    public array $passportBccError = [
        // 'patrick.nkongolo@equitybcdc.cd',
    ];
    public array $cashcloudBccSuccess = [
        // 'sarah.bileke@equitybcdc.cd',
        // 'olivier.muissa@equitybcdc.cd',
        // 'patrick.nkongolo@equitybcdc.cd',
        // 'jonathan.mwamba@equitybcdc.cd',
        // 'joel.mutombo2@equitybcdc.cd',
        // 'vinny.masi@equitybcdc.cd',
        // 'no-reply@ikwook.cd',
    ];
    public array $cashcloudBccError = [
        // 'patrick.nkongolo@equitybcdc.cd',
    ];
}
