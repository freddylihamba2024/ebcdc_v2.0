<?php

        namespace App\Commands;

        use CodeIgniter\CLI\BaseCommand;
        use CodeIgniter\CLI\CLI;
        use Modules\Eximtrade\Models\LicenceModel;

        class TreatLicenses extends BaseCommand
        {
                protected $group       = 'Custom';
                protected $name        = 'licenses:treat';
                protected $description = 'Traitement batch des licences ISYS en CLI';

                public function run(array $params)
                {
                        helper('license');
                        ini_set('memory_limit', '1024M');
                        ini_set('max_execution_time', 0);

                        $licenceModel = new LicenceModel();
                        $batchSize = 500;
                        $offset = 0;
                        $totalProcessed = 0;

                        do {
                                $batch = $licenceModel->get_licenses_isys_DDR_batch($batchSize, $offset);

                                if (empty($batch)) {
                                        break;
                                }

                                foreach ($batch as $licenseVal) {

                                        $elicense = treat_single_license($licenseVal, $licenceModel);

                                        if ($elicense !== null) {

                                                $licenceModel->save_elicense_declarations($elicense);

                                        }

                                        unset($elicense);
                                }

                                $offset += $batchSize;
                                $totalProcessed += count($batch);
                                CLI::write("Traitement de {$totalProcessed} licences effectué...", 'green');

                        } while (count($batch) === $batchSize);

                        CLI::write("✅ Traitement terminé. Total : {$totalProcessed} licences", 'green');
                }
        }