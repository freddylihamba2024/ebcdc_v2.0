<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Modules\Services\Crons\Controllers\AckRetriever;

class Ack extends BaseCommand
{
    protected $group       = 'ack';
    protected $name        = 'ack:retrieve';
    protected $description = 'Récupération et traitement des fichiers ACK via SFTP';

    public function run(array $params)
    {
        $processor = new AckRetriever();
        $processor->process($params);

        CLI::write('✅ ACK processing executed successfully.', 'green');
    }
}

