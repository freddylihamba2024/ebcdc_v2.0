<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Modules\Services\Bulletin\Services\BulletinBatchVerificationService;

class BulletinVerification extends BaseCommand
{
    protected $group = 'bulletin';
    protected $name = 'bulletin:verification';
    protected $description = 'Verification asynchrone des bulletins en lot';

    public function run(array $params)
    {
        $payload = json_decode($params[0] ?? '{}', true);
        $verificationId = (int) ($payload['verification_id'] ?? 0);

        if ($verificationId <= 0) {
            CLI::error('verification_id manquant');
            return;
        }

        $service = new BulletinBatchVerificationService();
        $service->run_verification($verificationId);

        CLI::write('Verification batch terminee', 'green');
    }
}
