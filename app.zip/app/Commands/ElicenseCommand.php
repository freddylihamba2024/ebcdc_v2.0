<?php

        namespace App\Commands;

        use CodeIgniter\CLI\BaseCommand;
        use CodeIgniter\CLI\CLI;
        use Modules\Services\Crons\Controllers\Elicense;

        class ElicenseCommand extends BaseCommand
        {
                protected $group = 'Services';
                protected $name = 'elicense:actualisation';
                protected $description = 'Actualise les licences Elicense';

                public function run(array $params)
                {
                        $controller = new Elicense();
                        $controller->actualisation();
                        CLI::write('✔ Actualisation terminée', 'green');
                }
        }