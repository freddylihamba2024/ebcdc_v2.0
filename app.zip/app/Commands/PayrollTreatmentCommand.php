<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use CodeIgniter\CLI\Commands;
use Modules\Payroll\Models\PayrollModel;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Sftp\Payroll\Controllers\SftpPayroll;
use Modules\Services\Temenos\Controllers\Temenos;
use Psr\Log\LoggerInterface;

class PayrollTreatmentCommand extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'Services';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'payroll:files-treatment';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'A command to validate payroll files before processing.';

    /**
     * The Command's Usage
     *
     * @var string
     */
    // protected $usage = 'command:name [arguments] [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [];

    private $payrollModel;
    private $sftpPayroll;
    private $temenosGateway;
    private $comptabilisation;
    private $comptabilisationModel;

    /**
     * Actually execute a command.
     *
     * @param array $params
     */

    public function __construct(LoggerInterface $logger, Commands $commands)
    {
        parent::__construct($logger, $commands);

        $this->payrollModel = new PayrollModel();
        $this->sftpPayroll = new SftpPayroll();
        $this->temenosGateway = new Temenos();
        $this->comptabilisation = new Comptabilisation();
        $this->comptabilisationModel=new ComptabilisationModel();
    }

    public function run(array $params)
    {
         $files_treatment = $this->treat_files();

         CLI::write("Début de traitement...\n",'green');

         if(isset($files_treatment['file_data']) && !empty($files_treatment['file_data']))
         {
                $file_data = $files_treatment['file_data'];
                
                for($i = 0; $i < count($file_data); $i++)
                {
                        $file_lines = $files_treatment['file_details'][$file_data[$i]['Id_0']];
                       
                        if(!empty($file_lines))
                        {

                                CLI::write('Début du traitement du fichier : '.$file_data[$i]['File_id_7'],'white');
                                CLI::write('Nombres des fichiers à traiter et à valider : '.count($file_lines).'','green');
                                
                                $lines_validated = $this->validate_file_details($file_lines, $file_data[$i]); 
                                
                                $succeeded_lines = $lines_validated['succeeded_lines'];

                                if(count($succeeded_lines) == count($file_lines))
                                {
                                        $file_confirmation = $this->confirm_file($file_data[$i]);
                                        if(isset($file_confirmation['code']) && $file_confirmation['code'] == 200)
                                        {
                                                CLI::write('Le fichier '.$file_data[$i]['File_id_7'].' est validé ou confirmé avec succès','green');
                                        }
                                        else
                                        {
                                                CLI::write('La confirmation du fichier '.$file_data[$i]['File_id_7'].' a échoué','yellow');
                                        }
                                }
                                elseif(count($succeeded_lines) < count($file_lines) && count($succeeded_lines) !=0)
                                {
                                        CLI::write('La validation du fichier '.$file_data[$i]['File_id_7'].' est effectuée partiellement','red');
                                }
                                else
                                {
                                        CLI::write('Echec lors de la validation du fichier '.$file_data[$i]['File_id_7'].'','red');
                                }
                                CLI::newLine(2);

                        }
                        else
                        {
                                CLI::write('Aucune ligne trouvée pour le fichier N° : '.$file_data[$i]['File_id_7'],'yellow');
                        }

                }
                
         }


    }

    private function sftp_get_files()
    {
        $files=[];
        $data=[];
       
        $data['is_processed']=0;
        $data['file_id']='';
        $data['start_date']='';
        $data['end_date']='';

        $payroll_api=$this->sftpPayroll->sftp_get_files($data);
        
        $result=json_decode($payroll_api,true);

        if(isset($result['code']) && $result['code']==200)
        {
                $response_data['code']=200;
                $response_data['message']=$result['message'];

                if(isset($result['data']))
                {
                        if(isset($result['data']['file_id']))
                        {
                                
                                $file=$this->payrollModel->migrate_files_data($result['data'],TRUE);
                                $files[]=$file;
                                
                        }
                        else
                        {
                                
                                $files=$this->payrollModel->migrate_files_data($result['data'],FALSE);
                                
                        }

                }

                $response_data['files']=$files;
                                                
        }
        elseif(isset($result['code']) && $result['code']==401)
        {
                        $response_data['code']=401;
                        $response_data['message']="Échec d’authentification";
        }    
        elseif(isset($result['code']) && $result['code']==403)
        {
                        $response_data['code']=403;
                        $response_data['message']="Identifiants invalides";
        }  
        elseif(isset($result['code']) && $result['code']==404)
        {
                        $response_data['code']=404;
                        $response_data['message']="Le point de terminaison demandé n’est pas disponible.";
        }  
        elseif(isset($result['code']) && ($result['code']==506 || $result['code']==500 || $result['code']==305))
        {
                        $response_data['code']=$result['code'];
                        $response_data['message']=$result['message'];
        }     
        
        return $response_data;

    }

    public function sftp_get_file_details($data)
    {
        
        if(!empty($data))
        {
                $payroll_api=$this->sftpPayroll->sftp_get_file_details($data);
                $result=json_decode($payroll_api,true);
                                        
                if(isset($result['code']) && $result['code']==200)
                {
                        $response_data['code']=200;
                        $response_data['message']=$result['message'];
                        $response_data['lines']=$result['data'];
                        $response_data['fileInfo']=$data;

                        $file=$this->payrollModel->check_if_file_exists($data['File_id_7']);

                        if($file==NULL || empty($file))
                        {
                                $data_to_save=(array)$data;
                                $data_to_save['Results_17']=json_encode($result['data']);
                                $id=$this->payrollModel->save_file($data_to_save);
                        }
                        else
                        {
                                $data_to_save['Results_17']=json_encode($result['data']);
                                $this->payrollModel->save_file($data_to_save,$data['File_id_7']);
                                                                        
                                $response_data['fileInfo']=(array)$file;
                        }
                }
                elseif(isset($result['code']) && $result['code']==401)
                {
                                $response_data['code']=401;
                                $response_data['message']="Échec d’authentification";
                }    
                elseif(isset($result['code']) && $result['code']==403)
                {
                                $response_data['code']=403;
                                $response_data['message']="Identifiants invalides";
                }  
                elseif(isset($result['code']) && $result['code']==404)
                {
                                $response_data['code']=404;
                                $response_data['message']="Le point de terminaison demandé n’est pas disponible.";
                }  
                elseif(isset($result['code']) && ($result['code']==506 || $result['code']==500 || $result['code']==305))
                {
                                $response_data['code']=$result['code'];
                                $response_data['message']=$result['message'];
                }     
                return $response_data;
        }
        else
        {
                $response_data['code']='305';
                $response_data['message']= 'Le fichier n\'est pas trouvé ou est vide';
                return $response_data;
        }
    }

    public function treat_files()
    {
        $response_get_files=$this->sftp_get_files();
       
        $treatment_file=[];
        $file_details=[];
        $response_data=[];

        if(isset($response_get_files['code']) && $response_get_files['code']==200)
        {
                if(isset($response_get_files['files']) && !empty($response_get_files['files']))
                {
                        $files=$response_get_files['files'];

                        foreach($files as $fileinfo)
                        {

                                $file=(array)$fileinfo;
                         
                                //Appel à l'API de Vérification du statut de fichier avant la traitement ou enregistrement dans la BD de Logiref
                                $file_status_api=$this->sftpPayroll->verify_file_status($file);
                                $file_status_result=json_decode($file_status_api,true);
                               
                                if(isset($file_status_result['code']) && $file_status_result['code']==200)
                                {
                                        if(isset($file_status_result['status']) && $file_status_result['status']==true)
                                        {
                                                $file['Status_2']=2;
                                                $file['Is_processed_13']=1;
                                        }
                                        else
                                        {
                                                $file['Status_2']=1;
                                        }
                                }
                                else
                                {
                                        //Retour au cas où il y a une erreur lors de la vérification
                                        $response_data['code']=400;
                                        $response_data['message']="Une erreur est survenue lors de la vérification du statut du fichier";
                                        return $this->response->setJSON($response_data);
                                }

                                if($file['Status_2']==1)
                                {
                                        

                                        $response_get_file_details=$this->sftp_get_file_details($file);

                                        if(isset($response_get_file_details['code']) && $response_get_file_details['code']== 200)
                                        {
                                                $file_lines=isset($response_get_file_details['lines'])?$response_get_file_details['lines']:[];
                                        }
                                        else
                                        {
                                                $file_lines=[];
                                        }

                                        if(!empty($file_lines))
                                        {

                                                //Récupération du fichier 
                                                $file_data = $this->payrollModel->get_file_by_fileid($file['File_id_7']);
                                                if(!empty($file_data))
                                                {
                                                        $file['Id_0']=$file_data->Id_0;
                                                }

                                                $instructions_payroll = $this->comptabilisation->generate_instructions_sftp_payroll($file,$file_lines);
                                        
                                                if(!empty($instructions_payroll))
                                                {
                                                        //check if instructions already exist
                                                        $existent_instructions=$this->comptabilisationModel->get_instructions_sftp_payroll($file['Id_0']);
                                                        
                                                        if(empty($existent_instructions))
                                                        {
                                                                //Delete existent instructions before saving new ones
                                                                $this->comptabilisationModel->save_instructions_sftp_payroll($file,$instructions_payroll);
                                                        }

                                                        //updating files informations
                                                        $data_to_update['Status_2']=2;
                                                        $result=$this->payrollModel->update_file_by_fileid($data_to_update,$file['File_id_7']);

                                                        if($result > 0)
                                                        {
                                                                $response_data['code']=200;
                                                                $response_data['message']="Enregistrement effectué avec succès";
                                                        }
                                                        else
                                                        {
                                                                $response_data['code']=400;
                                                                $response_data['message']="Une erreur est survenue lors de l'enregistrement";
                                                        }
                                                }
                                                
                                                if(isset($response_data['code']) && $response_data['code']==200)
                                                {
                                                        //check if file details already exist
                                                        $existent_lines = $this->payrollModel->get_file_details($file['File_id_7']);
                                                        if(empty($existent_lines))
                                                        {
                                                                foreach($file_lines as $file_line)
                                                                {
                                                                        $data_line=$this->payrollModel->migrate_file_details_data($file_line);
                                                                        $this->payrollModel->save_file_details($data_line);
                                                                }
                                                        } 

                                                        $treatment_file[]=$file;
                                                        // Récupération des détails du fichier
                                                        $instructions_payroll =$this->comptabilisationModel->get_instructions_sftp_payroll($file['Id_0']);
                                                        //This is for returning all the payroll instructions
                                                        if(!empty($instructions_payroll))
                                                        {
                                                                foreach($instructions_payroll as $instruction)
                                                                {
                                                                        $file_detail[$file['Id_0']][]=$instruction;
                                                                }    
                                                        }

                                                }
                                                else
                                                {
                                                        $response_data['code']=400;
                                                        $response_data['message']="Une erreur est survenue lors de l'enregistrement des détails du fichier";
                                                }
                                        }
                                        else
                                        {
                                                $response_data["code"]= 400;
                                                $response_data["message"]= "Aucun détail du fichier n'a été trouvé";
                                        }

                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==1)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Le fichier a été déjà traité";
                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==0)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Ce fichier existe déjà mais son traitement est incomplet. Veuillez procéder à la validation des détails du fichier.";
                                }
                                elseif($file['Status_2'] == 2 && $file['Is_processed_13']==5)
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Le traitement ou la validation de ce fichier a échoué précédemment. Veuillez contacter le validateur pour la régularisation.";
                                }
                                else
                                {
                                        $response_data['code']=400;
                                        $response_data['message']="Statut du fichier inconnu. Veuillez contacter l'administrateur.";
                                }  
                        }
                        $response_data["file_data"]=$treatment_file;
                        $response_data["file_details"]=$file_detail;
                }
                else
                {
                        $response_data["code"]= 400;
                        $response_data["message"]= "Aucun fichier non traité se trouve dans le serveur...";
                }
        }
        else
        {
                $response_data["code"]= 400;    
                $response_data["message"]= "Une erreur est survenue lors de la récupération des fichiers";
        }
        return $response_data;
    }


    public function validate_file_details($file_details,$file)
    {
                $file_details_succeeded=[];
                $file_details_failed=[];
                $return_file_detailes=[];

                if(!empty($file_details))
                {
                        foreach($file_details as $file_detail_data)
                        {
                                $file_detail=(array)$file_detail_data;
                                //Appel de l'API Temenos pour intégration des informations dans le coreBanking  
                                $result = $this->temenosGateway->virement_payroll_single($file_detail);
                                // $result=json_decode($temenos_api,true);
                                if(isset($result["code"]) && $result["code"]==200)
                                {
                                                $file_detail_to_confirm['is_processed']=1;
                                                $file_detail_to_confirm['is_errored']= 0;
                                                $file_detail_to_confirm['error_text']= "";
                                                $file_detail_to_confirm['line_id']= $file_detail['Line_14'];

                                                $confirm_file_detail=$this->sftpPayroll->sftp_update_file_details($file_detail_to_confirm);

                                                $result1=json_decode($confirm_file_detail,true);
                                                
                                                if(isset($result1['code']) && $result1['code']== 200)
                                                {
                                                        $line_to_update['Status_2']=2;
                                                        $line_to_update['Is_processed_14']=1;

                                                        $line_id=$file_detail['Line_14'];
                                                        $file_id=isset($file['File_id_7'])?$file['File_id_7']:"";
                                                        
                                                        $file_details_succeeded[]=$file_detail;

                                                        $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);
                                                }
                                                else
                                                {
                                                        $line_to_update['Status_2']=3;
                                                        $line_to_update['Is_processed_14']=0;

                                                        $line_id=$file_detail['Line_14'];
                                                        $file_id=isset($file['File_id_7'])?$file['File_id_7']:"";
                                                        $file_details_failed[]=$file_detail;

                                                        $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);
                                                }
                                }

                        }
                        $return_file_details['succeeded_lines']= $file_details_succeeded;
                        $return_file_details['failed_lines']= $file_details_failed;
                }
                else
                {
                        $return_file_details=[];
                }
                return $return_file_details;
    }

    public function confirm_file($file)
    {
                if(!empty($file))
                {
                        $api_data['is_processed']=1;
                        $api_data['file_id']=$file['File_id_7'];

                        $update_file_api = $this->sftpPayroll->sftp_update_file($api_data);
                        $result_file_api=json_decode($update_file_api,true);

                        if(isset($result_file_api['code']) && $result_file_api['code']==200)
                        {

                                $response_data['code']=200;
                                $response_data['message']="Le fichier est validé avec succès";

                                $file_to_update['Status_2']=2;
                                $file_to_update['Is_processed_13']=1;

                                $this->payrollModel->save_file($file_to_update,$file['Id_0']);
                        }
                        else
                        {
                                $file_to_update['Is_processed_13']=5;
                                $this->payrollModel->save_file($file_to_update,$file['Id_0']);

                                $response_data['code']=300;
                                $response_data['message']="Une erreur est survenue lors de la confirmation du fichier";
                        }
                }
                else
                {
                        $response_data["code"]= 400;
                        $response_data["message"]= "Le fichier n'existe pas.";
                }
                return $response_data;
    }

    public function data($obj = NULL, $data = NULL, $arg = NULL, $param = NULL)
    {
        if ($obj == "file-detail")
        {
                $file_results=json_decode($data['Results_17'],true);
                $index=array_search($arg,array_column($file_results,'line_id'));
                return $index!==false ? $file_results[$index]:null;
        }  
    }
}
