<?php

namespace App\Commands;

use App\Libraries\Infobip;
use App\Libraries\MailLib;
use App\Models\Mail_Model;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class InfobipEmailReportsCommand extends BaseCommand
{
    protected $group = 'mail';
    protected $name = 'infobip:email-reports';
    protected $description = 'Recupere les accuses de reception Infobip et met a jour les logs email.';
    protected $usage = 'infobip:email-reports [--interval=15] [--max-loops=0] [--tracked-message-id=ID] [--query=\'{"messageId":"..."}\']';
    protected $options = [
        '--interval' => 'Intervalle entre deux interrogations en secondes.',
        '--max-loops' => 'Nombre de boucles. 0 = execution continue.',
        '--tracked-message-id' => 'MessageId Infobip cible.',
        '--query' => 'JSON de filtre passe a Infobip.',
        '--once' => 'Force une seule iteration.',
        '--stop-when-found' => 'Arrete la commande des que le message suivi est retrouve.',
    ];

    public function run(array $params)
    {
        $interval = max(1, (int) (CLI::getOption('interval') ?? 15));
        $maxLoops = max(0, (int) (CLI::getOption('max-loops') ?? 0));
        $trackedMessageId = trim((string) (CLI::getOption('tracked-message-id') ?? ''));
        $query = $this->decodeQuery((string) (CLI::getOption('query') ?? ''));
        $once = CLI::getOption('once') !== null;
        $stopWhenFound = CLI::getOption('stop-when-found') !== null || $trackedMessageId !== '';

        if ($trackedMessageId !== '' && !isset($query['messageId'])) {
            $query['messageId'] = $trackedMessageId;
        }

        $logDir = ROOTPATH . 'drive/logs/logiref/cli/spark';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0775, true);
        }

        $logFile = $logDir . '/' . date('Y-m-d') . '_infobip_email_reports.logs';
        $infobip = new Infobip();
        $mailLib = new MailLib();
        $mailModel = new Mail_Model();
        $loop = 0;

        do {
            $loop++;
            $result = $infobip->get_email_delivery_reports($query);
            $reports = $infobip->extract_reports($result['json'] ?? null);
            $updated = 0;
            $trackedFound = false;
            $trackedStatus = null;
            $trackedLog = null;
            $reportLogs = [];

            foreach ($reports as $report) {
                $messageId = (string) ($report['messageId'] ?? '');
                $recipientEmail = trim((string) ($report['to'] ?? ''));
                if ($messageId === '') {
                    continue;
                }

                $status = $infobip->normalize_delivery_status($report);
                $errorMessage = $report['error']['description'] ?? null;
                $existingLog = $recipientEmail !== ''
                    ? $mailModel->get_email_log_by_provider_message_id_and_recipient($messageId, $recipientEmail)
                    : $mailModel->get_email_log_by_provider_message_id($messageId);
                $previousStatus = strtoupper(trim((string) ($existingLog['Status_8'] ?? '')));
                $wasUpdated = $mailModel->update_email_status_by_provider_message_id(
                    $messageId,
                    $status,
                    $report,
                    $errorMessage,
                    $recipientEmail
                );
                $supportNotice = null;

                if ($wasUpdated && in_array($status, ['UNDELIVERED', 'FAILED'], true) && $previousStatus !== $status) {
                    try {
                        $updatedLog = $recipientEmail !== ''
                            ? $mailModel->get_email_log_by_provider_message_id_and_recipient($messageId, $recipientEmail)
                            : $mailModel->get_email_log_by_provider_message_id($messageId);

                        if (is_array($updatedLog)) {
                            $supportResult = $mailLib->notify_support_about_delivery($updatedLog, $report, $status);
                            $supportNotice = [
                                'attempted' => true,
                                'ok' => (bool) ($supportResult['ok'] ?? false),
                                'logId' => $supportResult['logId'] ?? null,
                                'messageId' => $supportResult['send']['messageId'] ?? null,
                                'error' => $supportResult['send']['error'] ?? null,
                            ];
                        } else {
                            $supportNotice = [
                                'attempted' => false,
                                'ok' => false,
                                'error' => 'Updated email log not found for support notification.',
                            ];
                        }
                    } catch (\Throwable $exception) {
                        $supportNotice = [
                            'attempted' => true,
                            'ok' => false,
                            'error' => $exception->getMessage(),
                        ];
                    }
                }

                $reportLogs[] = [
                    'messageId' => $messageId,
                    'to' => $recipientEmail,
                    'status' => $status,
                    'previousStatus' => $previousStatus,
                    'providerStatus' => $report['status'] ?? null,
                    'error' => $report['error'] ?? null,
                    'updated' => $wasUpdated,
                    'supportNotice' => $supportNotice,
                    'report' => $report,
                ];

                if (
                    $trackedMessageId !== ''
                    && $messageId === $trackedMessageId
                    && $this->is_terminal_status($status)
                ) {
                    $trackedFound = true;
                    $trackedStatus = $status;
                }

                if ($wasUpdated) {
                    $updated++;
                    if ($trackedMessageId !== '' && $messageId === $trackedMessageId) {
                        $trackedFound = true;
                        $trackedStatus = $status;
                    }
                }
            }

            if ($trackedMessageId !== '') {
                $trackedLog = $mailModel->get_email_log_by_provider_message_id($trackedMessageId);
                if (!$trackedFound && $this->is_terminal_status($trackedLog['Status_8'] ?? null)) {
                    $trackedFound = true;
                    $trackedStatus = (string) $trackedLog['Status_8'];
                }
            }

            $this->appendLog($logFile, [
                'ts' => date('c'),
                'loop' => $loop,
                'trackedMessageId' => $trackedMessageId,
                'ok' => $result['ok'] ?? false,
                'httpCode' => $result['httpCode'] ?? null,
                'reports' => count($reports),
                'updated' => $updated,
                'trackedFound' => $trackedFound,
                'trackedStatus' => $trackedStatus,
                'trackedLogId' => $trackedLog['Id'] ?? null,
                'error' => $result['error'] ?? null,
                'query' => $query,
                'apiUrl' => $result['url'] ?? null,
                'apiRawResponse' => $result['raw'] ?? null,
                'apiJsonResponse' => $result['json'] ?? null,
                'reportsDetail' => $reportLogs,
            ]);

            CLI::write('Loop ' . $loop . ': ' . count($reports) . ' report(s), ' . $updated . ' log(s) updated.', 'green');

            if ($trackedFound && $stopWhenFound) {
                CLI::write(
                    'Tracked message ' . $trackedMessageId . ' found with status ' . ($trackedStatus ?? 'UNKNOWN') . '. Stopping worker.',
                    'yellow'
                );
                break;
            }

            if ($once || $maxLoops === 1) {
                break;
            }

            if ($maxLoops > 0 && $loop >= $maxLoops) {
                break;
            }

            sleep($interval);
        } while (true);
    }

    private function is_terminal_status(?string $status): bool
    {
        $status = strtoupper(trim((string) $status));

        return in_array($status, ['DELIVERED', 'FAILED', 'UNDELIVERED'], true);
    }

    private function decodeQuery(string $raw): array
    {
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function appendLog(string $file, array $payload): void
    {
        $line = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($line === false) {
            return;
        }

        @file_put_contents($file, $line . PHP_EOL, FILE_APPEND);
    }
}
