<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
Use Modules\Services\Crons\Controllers\Bulletins;


class Bulletin extends BaseCommand
{
    protected $group = 'bulletin';
    protected $name = 'bulletin:confirmation';
    protected $description = 'Confirmation des bulletins en arrière plan';

    public function run(array $params)
    {
            $bulletin = new Bulletins();
            $bulletin->confirmation($params);
            CLI::write('✅ Commande exécutée depuis le module !', 'green');
    }
}
