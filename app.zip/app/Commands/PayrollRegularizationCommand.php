<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use CodeIgniter\CLI\Commands;
use Modules\Payroll\Models\PayrollModel;
use Modules\Services\Comptabilisation\Controllers\Comptabilisation;
use Modules\Services\Comptabilisation\Models\ComptabilisationModel;
use Modules\Services\Sftp\Payroll\Controllers\SftpPayroll;
use Modules\Services\Temenos\Controllers\Temenos;
use Psr\Log\LoggerInterface;

class PayrollRegularizationCommand extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'CodeIgniter';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'payroll:file-regularization';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'A command for regularizing failed files treatment';

    /**
     * The Command's Usage
     *
     * @var string
     */
    // protected $usage = 'command:name [arguments] [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */

    private $payrollModel;
    private $sftpPayroll;
    private $temenosGateway;
    private $comptabilisation;
    private $comptabilisationModel;

    /**
     * Actually execute a command.
     *
     * @param array $params
     */

    public function __construct(LoggerInterface $logger, Commands $commands)
    {
        parent::__construct($logger, $commands);

        $this->payrollModel = new PayrollModel();
        $this->sftpPayroll = new SftpPayroll();
        $this->temenosGateway = new Temenos();
        $this->comptabilisation = new Comptabilisation();
        $this->comptabilisationModel=new ComptabilisationModel();
    }

    public function run(array $params)
    {
        //
    }
    public function get_files_to_regularize()
    {
            $files=[];
            $files_to_regularize = $this->payrollModel->get_files_equalize();
            if(!empty($files_to_regularize))
            {
                    foreach($files_to_regularize as $file_to_regularize)
                    {
                            $instructions_payroll = $this->comptabilisationModel->get_instructions_sftp_payroll($file_to_regularize['Id_0']);
                            $file_lines = $this->payrollModel->get_file_details($file_to_regularize['File_id_7']);

                            $files['files']=$file_to_regularize;
                            $files[$file_to_regularize['Id_0']]['instructions'] = $instructions_payroll;
                            $files[$file_to_regularize['Id_0']]['lines'] = $file_lines;
                    }

            }
            return $files;
    }

    public function regularize_file_details($instructions=[],$file_details=[],$file=null)
    {
            $succeeded_details=[];
            $failed_details=[];
            $response_data=[];
            
            if(!empty($instructions))
            {
                    foreach($instructions as $instruction)
                    {
                            $temenosGateway = $this->temenosGateway->virement_payroll_single($instruction,'regularize');

                            if(isset($temenosGateway['code']) && $temenosGateway['code']==200)
                            {
                                    $file_line = $this->get_file_detail($file,$file_details);
                                    if(!empty($file_line))
                                    {
                                            $confirm_detail = $this->confirm_file_detail($file_line,$file_line['Line_id_8']);
                                            if(isset($confirm_detail['code']) && $confirm_detail['code']== 200)
                                            {
                                                    $succeeded_details[] = $file_line;
                                            }
                                            else
                                            {
                                                    $failed_details[] = $file_line;
                                            }
                                    }
                            }

                    }
                    $response_data['succeeded_file_details']= $succeeded_details;
                    $response_data['failed_file_details']= $failed_details;
            }
            return $response_data;
    }

    public function regularize_file($file)
    {

    }

    public function confirm_file_detail($file_detail,$line_id=null)
    {
            $response_data=array();
                
            if($file_detail!=NULL)
            {

                    $file_detail['is_processed']=1;
                    $file_detail['is_errored']=0;
                    $file_detail['line_id'] = $file_detail['Line_id_8'];
                    $file_id = $file_detail['File_id_7'];

                    $update_line_api = $this->sftpPayroll->sftp_update_file_details($file_detail);
                    $result_line_api=json_decode($update_line_api,true);

                    if(isset($result_line_api['code']) && $result_line_api['code']==200)
                    {
                            $response_data['code']=200;
                            $response_data['message']="Le détail du fichier est validé avec succès";
                            $response_data['line']=$file_detail['Id_0'];

                            $line_to_update['Status_2']=2;
                            $line_to_update['Is_processed_14']=1;

                            $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);
                    }
                    else
                    {
                            $line_to_update['Is_processed_14']=5;
                            $this->payrollModel->update_file_details_by_lineid($line_to_update,$line_id,$file_id);

                            $response_data['code']=300;
                            $response_data['message']="Une erreur est survenue lors de la confirmation du détail du fichier";
                            $response_data['line']=$file_detail['Id_0'];
                    }
            }
            else
            {
                    $response_data['code']=404;
                    $response_data['message']="Le détail du fichier n'existe plus";
            }
            return $response_data;
    }

    public function get_file_detail($file_id,$file_details=[])
    {
            foreach($file_details as $file_detail)
            {
                    if($file_detail["File_id_7"] == $file_id)
                    {
                            return $file_detail;
                    }
            } 
    }

}
