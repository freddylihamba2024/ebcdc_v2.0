<?php

    namespace App\Controllers;

    use Mpdf\Mpdf;
    use App\Libraries\Curl;
    use App\Libraries\Mail;
    use App\Libraries\Chtml;
    use App\Libraries\Sidebars;
    use CodeIgniter\Controller;
    use Psr\Log\LoggerInterface;
    use App\Libraries\Number_letter;
    use CodeIgniter\HTTP\CLIRequest;
    use Endroid\QrCode\Builder\Builder;
    use CodeIgniter\HTTP\IncomingRequest;
    use Endroid\QrCode\Encoding\Encoding;
    use CodeIgniter\HTTP\RequestInterface;
    use CodeIgniter\HTTP\ResponseInterface;
    use CurlHandle;
    use PhpOffice\PhpSpreadsheet\IOFactory;
    use Modules\Logiref\Models\LogirefModel;
    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use phpseclib3\Net\SFTP;

    /**
     * Class BaseController
     *
     * BaseController provides a convenient place for loading components
     * and performing functions that are needed by all your controllers.
     * Extend this class in any new controllers:
     *     class Home extends BaseController
     *
     * For security be sure to declare any new methods as protected or private.
     */
    abstract class BaseController extends Controller {

        /**
         * Instance of the main Request object.
         *
         * @var CLIRequest|IncomingRequest
         */
        protected $request;

        /**
         * An array of helpers to be loaded automatically upon
         * class instantiation. These helpers will be available
         * to all other controllers that extend BaseController.
         *
         * @var array
         */
        protected $helpers = ['form'];

        /**
         * Be sure to declare properties for any property fetch you initialized.
         * The creation of dynamic property is deprecated in PHP 8.2.
         */
        // protected $session;

        public  $sidebars;
        public  $session;
        public  $portals = array('logiref');
        public  $uri;
        public  $data;
        public  $chtml;
        public  $curl;

        public  $qrCodeEncoding;
        public  $qrCodeBuilder;
        public  $spreadsheet;
        public  $mpdf;
        public  $number_letter;
        public  $mail;
        public  $alertModel;
        public  $phpseclib;
        private $mainModel;

        /**
         * Constructor.
         */
        public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger) 
        {
                // Do Not Edit This Line
                parent::initController($request, $response, $logger);

                // Preload any models, libraries, etc, here.
                //$this->sidebars = new Sidebars();

                $this->session = \Config\Services::session();
                //var_dump($_SESSION); die;

                // Nettoyage automatique des POST
                // Nettoyage automatique des POST
                if ($this->request->is('post')) 
                {
                        $_POST = $this->sanitizeInput($_POST);
                }

                // Nettoyage automatique des GET
                $_GET = $this->sanitizeInput($_GET);

                header('Access-Control-Allow-Origin: *');
                header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
                header('Access-Control-Allow-Headers: Content-Type, Authorization');

                //$this->response->setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self';");
        }

        public function __construct() {
            // Preload any models, libraries, etc, here.
            $this->session = $this->data['session'] = \Config\Services::session();
            $this->sidebars = new Sidebars();
            $this->number_letter = new Number_letter();
            $this->mpdf = new Mpdf();
            $this->spreadsheet = new Spreadsheet();
            $this->qrCodeBuilder = new Builder();
            $this->qrCodeEncoding = new Encoding('UTF-8');
            $this->mail = new Mail();
            $this->alertModel = new \Modules\Branch\Models\IntegrationModel();
            $this->mainModel = new \Modules\Main\Models\MainModel();

            $this->chtml = $this->data['chtml'] = new Chtml();
            $this->curl = $this->data['curl'] = new Curl();

            $this->uri = $this->data['uri'] = service('uri');
            $this->uri->setSilent();
            ini_set('display_errors', 0);
            // Some global variables to use in the entire application
            $this->data['errors'] = array();

            if (isset($_SESSION['Logiref_guichet'])) {
                $this->data['alerts'] = $this->alertModel->get_logs_branchless();
            } else {
                $this->data['alerts'] = array();
            }

            if (!is_cli()) 
            {
                $server_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
                $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
            } 
            else 
            {
                // Valeurs par défaut quand on exécute en CLI (spark)
                $server_ip = '127.0.0.1';
                $user_agent = 'CLI';
            }

            // Session Sidejacking bulletproof
        //     $ikwook_bullet = isset($this->session->userdata) && !empty($this->session->userdata['ikwook_bullet']) ? $this->session->userdata['ikwook_bullet'] : '';
        //     $chaine_ikwook = $server_ip . $user_agent;

        //     if ($ikwook_bullet != "" && $ikwook_bullet != $chaine_ikwook)
        //     {
        //         session_destroy();
        //         redirect('');
        //     }
            if (isset($this->session->userdata) && !empty($this->session->userdata['user_id']) && $this->session->userdata['user_id']) 
            {
                $logirefModel = new LogirefModel();
                $logirefModel->get_privilegies();

                $this->data['user_id'] = $this->session->userdata['user_id'];
                $this->data['user_email1'] = $this->session->userdata['user_email'];
                $this->data['user_role'] = $this->session->userdata['user_roles'];
                $this->data['user_site'] = $this->session->userdata['user_site'];
                $this->data['account_id'] = $this->session->userdata['account_id'];
                $this->data['user_fname'] = $this->session->userdata['user_fname'];
                $this->data['role'] = $this->session->userdata['user_roles'];

                //Frontend pages and portals
            }
            elseif ($this->iSfrontendPage())
            {
                $segment = $this->uri->getSegment(1);
                if ($segment == '@') {
                    redirect('page/' . $segment, 'refresh');
                }
                elseif (in_array($segment, $this->portals) && $this->uri->getSegment(2) == '' && !isset($_SESSION['account_id']))
                {
                    redirect('page/@' . $segment, 'refresh');
                }
                #Login not required
            }
            else
            {
                if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && $this->uri->getSegment(2) != "reinitialize" && $this->uri->getSegment(2) != "setpassword" && $this->uri->getSegment(2) != "resend_otp" && $this->uri->getSegment(2) != "verify_otp" && $this->uri->getSegment(2) != "validate_otp") {
                    /* special ajax here */
                    echo '<script type="text/javascript">';
                    echo 'alert(<div class="col-md-8">';
                    echo '<div class="alert alert-danger alert-dismissable">';
                    echo '     <button type="button" class="close" data-dismiss="alertX" aria-hidden="true">×</button>';
                    echo '     <h4><i class="icon fa fa-ban"></i> Alert!</h4>';
                    echo '     Sorry, your session has expired. Please logout and sign in again.';
                    echo '</div>';
                    echo '</div>);';
                    echo '</Script>';
                    die;
                }
                else{
                    return redirect()->to(base_url('main/signin'));
                    die;
                    // echo "bien"; die;
                    // return redirect()->to('/main/login');
                    // exit;
                    // return redirect()->route('/');
                }
            }
        }

        protected function sanitizeInput(array $input): array
        {
                $clean = [];
                foreach ($input as $key => $value) {
                if (is_array($value)) {
                        // Nettoyer récursivement si c'est un tableau
                        $clean[$key] = $this->sanitizeInput($value);
                } else {
                        // Convertit les caractères spéciaux pour éviter XSS
                        $clean[$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                }
                }
                return $clean;
        }

        public function initializeSFTP($host, $port)
        {
            $this->phpseclib = new SFTP($host, $port);

            if (!$this->phpseclib) {
                throw new \Exception('Erreur : Impossible d’instancier SFTP.');
            }
        }

        public function curl($url, $method = 'GET', $data = [], $headers = [], $http_code_return =false, $ssl_verif =true)
        {
                $curl = curl_init();

                $http_code='';

                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

                if (!empty($headers))
                {
                        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                }

                if (strpos($url, 'https://') === 0)
                {
                        if($ssl_verif){
                                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
                                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
                        }
                        else{
                                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
                        }
                }

                switch (strtoupper($method))
                {
                        case 'POST':
                            curl_setopt($curl, CURLOPT_POST, true);
                            curl_setopt($curl, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
                            break;

                        case 'GET':
                            if (!empty($data)) {
                                $url .= is_array($data) ? '?' . http_build_query($data) : '?' . $data;
                                curl_setopt($curl, CURLOPT_URL, $url);
                            }
                            break;
                        case 'PATCH':
                            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PATCH');
                            curl_setopt($curl, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
                            break;
                        case 'PUT':
                        case 'DELETE':
                            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, strtoupper($method));
                            curl_setopt($curl, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
                            break;
                }

                $response = curl_exec($curl);

                //var_dump($response); die;

                $error = null;
                $http_code = null;

                if ($response === false)
                {
                        $error = curl_error($curl);
                }
                if($http_code_return)
                {
                        # Récupérer le code HTTP
                        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                }

                curl_close($curl);

                // ------------------------
                // Écriture du log
                // ------------------------

                $log_dir = ROOTPATH . 'drive/logs/curl/';
                if (!is_dir($log_dir))
                {
                        mkdir($log_dir, 0755, true);
                }

                $log_file = $log_dir . 'curl_' . date('Y-m-d') . '.log';
                $log_entry = [
                        'date'     => date('Y-m-d H:i:s'),
                        'url'      => $url,
                        'method'   => strtoupper($method),
                        'headers'  => $headers,
                        'data'     => $data,
                        'response' => $response,
                        'error'    => $error,
                        'http_code'=> $http_code,
                ];
                file_put_contents($log_file, json_encode($log_entry, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
                // ------------------------

                if($http_code_return)
                {
                        return ['response' => $response, 'http_code' => $http_code];
                }
                else
                {
                        return isset($error) ? json_encode(['Code'=>500,'Message'=>$error]) : $response;
                }
        }

        public function file_get_contents($label, $model, $url, $method = 'POST', $data = [], $namespaceURIs = [], $action = '', $elements = [], $headers = [], $verify_peer = false, $wrapCDATA = [], $return_raw = false)
        {
                if (!empty($namespaceURIs))
                {
                        $keys = array_keys($namespaceURIs);
                        $prefixEnv = $keys[0];
                        $prefixData = $keys[1];

                        $uriEnvelope = $namespaceURIs[$prefixEnv];
                        $uriData     = $namespaceURIs[$prefixData];

                        $dom = new \DOMDocument('1.0', 'UTF-8');
                        $envelope = $dom->createElementNS($uriEnvelope, "$prefixEnv:Envelope");
                        $dom->appendChild($envelope);

                        $envelope->appendChild($dom->createElement("$prefixEnv:Header"));
                        $body = $dom->createElement("$prefixEnv:Body");
                        $envelope->appendChild($body);

                        $bodyContent = $dom->createElementNS($uriData, "$prefixData:$action");

                        $this->buildXmlElements($dom, $bodyContent, $elements, $uriData, $prefixData, $wrapCDATA);

                        $body->appendChild($bodyContent);

                        $dom->preserveWhiteSpace = false;
                        $dom->formatOutput = true;
                        $xmlRequest = $dom->saveXML();
                        $xmlRequest = preg_replace('/<\?xml.*?\?>/', '', $xmlRequest);

                        $options = [
                                'http' => [
                                        'method'  => $method,
                                        'header'  => implode("\r\n", $headers),
                                        'content' => $xmlRequest,
                                        'timeout' => 120,
                                ],
                                'ssl' => [
                                        'verify_peer'      => $verify_peer,
                                        'verify_peer_name' => $verify_peer,
                                        'allow_self_signed' => true,
                                ]
                        ];

                        $context = stream_context_create($options);
                        $model->save_log($xmlRequest, $label);

                        try {
                                $response = @file_get_contents($url, false, $context);
                                if ($response === false)
                                {
                                        $error = error_get_last();
                                        $message = $error['message'] ?? 'Aucune réponse obtenue';
                                        $model->save_log('Erreur file_get_contents : ' . $message, $label);
                                        return ['error' => '408', 'message' => $message];
                                }

                                $model->save_log($response, $label);
                                if ($return_raw) return $response;

                                libxml_use_internal_errors(true);
                                $xml = simplexml_load_string($response);
                                if ($xml === false) {
                                        $errors = libxml_get_errors();
                                        libxml_clear_errors();
                                        $model->save_log('Erreur parsing XML', $label);
                                        return ['error' => '409', 'message' => 'Erreur de parsing XML', 'details' => $errors];
                                }

                                return $this->parse_soap_response($response);

                        }
                        catch (\Exception $e)
                        {
                                $model->save_log('Exception : ' . $e->getMessage(), $label);
                                return ['error' => '406', 'message' => $e->getMessage()];
                        }
                }

                if (!empty($data))
                {
                        $options = [
                            'http' => [
                                'method'  => $method,
                                'header'  => implode("\r\n", $headers),
                                'content' => http_build_query($data),
                            ],
                            'ssl' => [
                                'verify_peer'      => $verify_peer,
                                'verify_peer_name' => $verify_peer,
                                'allow_self_signed' => true,
                            ]
                        ];

                        $context = stream_context_create($options);
                        $model->save_log(json_encode($options), $label);

                        $result = @file_get_contents($url, false, $context);
                        $model->save_log($result !== false ? $result : 'Réponse vide ou invalide', $label);

                        if ($result === false)
                        {
                                $error = error_get_last();
                                return ['error' => '408', 'message' => $error['message'] ?? 'Erreur HTTP'];
                        }

                        if ($return_raw) return $result;

                        $json = json_decode($result, true);
                        if (json_last_error() === JSON_ERROR_NONE) return $json;

                        libxml_use_internal_errors(true);
                        if ($xml = simplexml_load_string($result)) return $this->parse_soap_response($result);

                        return $result;
                }

                return ['error' => '400', 'message' => 'Requête invalide'];
        }

        private function parse_soap_response($xmlString)
        {
                libxml_use_internal_errors(true);
                $xml = simplexml_load_string($xmlString, 'SimpleXMLElement', LIBXML_NOCDATA);

                if ($xml === false) {
                        return ['error' => '409', 'message' => 'Erreur parsing XML', 'details' => libxml_get_errors()];
                }

                $namespaces = $xml->getNamespaces(true);
                $data = [];

                $body = $xml->children($namespaces['soapenv'])->Body;

                foreach ($body->children() as $responseElement) {
                        $responseName = $responseElement->getName();
                        $data[$responseName] = $this->simplexml_to_array($responseElement);
                }

                return ['Envelope' => ['Body' => $data]];
        }

        private function buildXmlElements(\DOMDocument $dom, \DOMElement $parent, array $elements, string $namespace, string $prefix, array $wrapCDATA = [])
        {
                foreach ($elements as $key => $value)
                {
                        $element = $dom->createElementNS($namespace, "$prefix:$key");

                        if (is_array($value))
                        {
                                $this->buildXmlElements($dom, $element, $value, $namespace, $prefix, $wrapCDATA);
                        }
                        else
                        {
                                if (in_array($key, $wrapCDATA))
                                {
                                        $cdata = $dom->createCDATASection($value);
                                        $element->appendChild($cdata);
                                }
                                else {
                                        $element->nodeValue = $value;
                                }
                        }

                        $parent->appendChild($element);
                }
        }

        private function simplexml_to_array($xml)
        {
                $arr = [];

                foreach ((array)$xml as $key => $value)
                {
                        if ($value instanceof \SimpleXMLElement || is_array($value))
                        {
                                $arr[$key] = $this->simplexml_to_array($value);
                        }
                        else {
                                $arr[$key] = $value;
                        }
                }

                return $arr;
        }

        function buildSoapXml(array $elements, string $rootElementName, array $namespaceURIs): string
        {
                $envelopeXml = <<<XML
                <?xml version="1.0" encoding="UTF-8"?>
                        <soapenv:Envelope xmlns:soapenv="{$namespaceURIs['soapenv']}" xmlns:amp="{$namespaceURIs['amp']}">
                </soapenv:Envelope>
                XML;

                $xml = new \SimpleXMLElement($envelopeXml);

                $header = $xml->addChild('soapenv:Header', null, $namespaceURIs['soapenv']);

                if (isset($elements['requestHeader']))
                {
                        $this->arrayToXml($elements['requestHeader'], $header, 'amp', $namespaceURIs['amp']);
                        unset($elements['requestHeader']);
                }

                $body = $xml->addChild('soapenv:Body', null, $namespaceURIs['soapenv']);

                $request = $body->addChild("amp:$rootElementName", null, $namespaceURIs['amp']);

                $this->arrayToXml($elements[$rootElementName] ?? $elements, $request, 'amp', $namespaceURIs['amp']);

                return $xml->asXML();
        }


        function arrayToXml(array $data, \SimpleXMLElement $xmlElement, string $namespacePrefix)
        {
                foreach ($data as $key => $value)
                {
                        $keyClean = str_replace(' ', '_', $key);

                        if (is_string($value) && str_starts_with(trim($value), '<![CDATA['))
                        {
                                $child = $xmlElement->addChild("$namespacePrefix:$keyClean");

                                $cdataContent = preg_replace('/^<!\[CDATA\[|\]\]>$/', '', trim($value));

                                $node = dom_import_simplexml($child);
                                $dom = $node->ownerDocument;
                                $cdataSection = $dom->createCDATASection($cdataContent);
                                $node->appendChild($cdataSection);
                        }
                        elseif (is_array($value))
                        {
                                $child = $xmlElement->addChild("$namespacePrefix:$keyClean");
                                $this->arrayToXml($value, $child, $namespacePrefix);
                        }
                        else {
                                $xmlElement->addChild("$namespacePrefix:$keyClean", htmlspecialchars($value));
                        }
                }
        }

        public function iSfrontendPage()
        {
                $return = FALSE;
                $segment1 = $this->uri->getSegment(1);
                $segment2 = $this->uri->getSegment(2);
                //$segment3 = $this->uri->getSegment(3);
                //Sites page
                $sitePages = array('', 'services', 'branchless');
                if (in_array($segment1, $sitePages))
                    $return = TRUE;

                //Sign in page
                $pages = array('user', 'signup', 'login', 'signin', 'verify_otp', 'authentification');
                if (($segment1 == 'main' && in_array($segment2, $pages)) || $segment1 == "pagefrotend")
                    $return = TRUE;

                //Ikwook Pages
                // if ($segment1 == 'page' && $segment2 != 'manage') $return = TRUE;
                //Countries portals
                if (in_array($segment1, $this->portals) && $segment2 == '')
                    $return = TRUE;

                //Ikwook Pages: starting with a @
                if (substr($segment1, 0, 1) === '@')
                    $return = TRUE;

                return $return;
        }

        public function save_audit_log($controller,$action,$userdata)
        {
                // Définir le chemin du répertoire de logs
                $dir = ROOTPATH."/drive/audit_logs";

                if (!is_dir($dir))
                {
                        if (!mkdir($dir, 0777, true))
                        {
                                die('Erreur : Impossible de créer le répertoire de logs.');
                        }
                }

                $name = date('dmY_h:i');
                $filePath = $name . "_" . $controller;

                // Tenter d'ouvrir le fichier en mode ajout
                $handle = fopen($filePath, 'a+');

                // Vérifier si le fichier a été ouvert correctement
                if ($handle === false)
                {
                        die('Erreur : Impossible d\'ouvrir ou de créer le fichier de log.');
                }

                // Formater les données avec la date et heure
                $data_to_save['Controller']=$controller;
                $data_to_save['Action']=$action;
                $data_to_save['IpAdress']=$this->request->getIPAddress();
                $data_to_save['User']=$userdata['nom']." ".$userdata['postnom']." ".$userdata['prenom'];
                $data = json_encode($data_to_save);

                // Écrire les données dans le fichier
                fwrite($handle, $data.";\n");

                // Fermer le fichier après écriture
                fclose($handle);
        }
        public function check_request($request,$required_fields)
        {
                foreach($required_fields as $field)
                {
                        if(!isset($request[$field]) || empty($request[$field]))
                        {
                                return ['Code'=>400,'Message'=>'Le champ '.$field.' est manquant ou vide'];
                        }
                }
                return ['Code'=>200,'Message'=>'OK'];
        }

        /**
         * Vérifie l'autorisation de l'utilisateur pour accéder à une fonctionnalité
         * Cette méthode est utilisée dans tous les contrôleurs pour vérifier l'accès
         * 
         * Elle s'appuie sur la clé 'deny' définie dans le constructeur de chaque contrôleur
         * - Si deny = true : redirection vers la page d'accès refusé
         * - Si deny = false : accès autorisé, continuation de l'exécution
         */
        protected function _checkAuthorization()
        {
                if (isset($this->data['deny']) && $this->data['deny']) {
                        $this->display('deny');
                        exit; // Arrête l'exécution pour empêcher tout accès non autorisé
                }
        }

}
