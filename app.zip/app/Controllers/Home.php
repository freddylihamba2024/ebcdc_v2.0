<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return redirect('main/signin');
        // return view('welcome_message');
    }
}
