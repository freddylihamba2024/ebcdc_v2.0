<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Libraries\DBAnonymizer;
use App\Models\MYTest;

class DBAnonymizerController extends BaseController {

    private $anonymizer = null;
    private $my_test = null;

    public function __construct() {
        $this->anonymizer = new DBAnonymizer();
    }

    public function index() {
        return view('dbanonymizer');
    }

    public function action($type, $table_data = null) {
        if ($type == "search_tables") {
            $this->my_test = new MYTest($table_data);
            $tables = $this->my_test->getTables();

            $metaData = [];

            foreach ($tables as $key => $table) {
                $fields = $this->my_test->getFields($table);
                $response['table']['table_name'] = $table;
                $response['table']['fields'] = $fields;
                array_push($metaData, $response);
            }
            return $this->response->setJSON($metaData);
        } else if ($type == "crypter") {
            
            $db = $this->request->getPost('db_select');
            $this->my_test = new MYTest($db);
            $tables = $this->request->getPost('table_name');

            for ($i = 0; $i < count($tables); $i++) {
                $data = $this->my_test->getAllData($db, $tables[$i]);
                $fields = $this->request->getPost('fields_' . $tables[$i]);
                $tabs[$tables[$i]]['columns'] = $fields;
                $tabs[$tables[$i]]['data'] = array();
                foreach ($data as $d) {
                    array_push($tabs[$tables[$i]]['data'], $d);
                }
                $anonymized_data = $this->anonymizer->anonymize($tabs, null);
                $success = $this->my_test->saveEncryptedData($tabs, $anonymized_data);
            }
            if ($success) {
                $response['code'] = 'OK';
                $response['message'] = 'data crypted successfully';
            } else {
                $response['code'] = 'KO';
                $response['message'] = 'not crypted';
            }
            return $this->response->setJSON($response);
        } else if ($type == "reveal") {
            $data = $this->anonymizer->reveal_data($this->my_test->getAllData(), array('data'));
            var_dump($data);
        }
    }
}
