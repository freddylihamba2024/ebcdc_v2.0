<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\RawSql;

class Mail_Model extends Model
{
    protected $DBGroup          = 'ikwook_logiref_main';
    protected $table            = 'logiref_email_logs';
    protected $primaryKey       = 'Id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'Module_1',
        'Reference_2',
        'RecipientEmail_3',
        'Subject_4',
        'Message_5',
        'Provider_6',
        'ProviderMessageId_7',
        'Status_8',
        'ErrorMessage_9',
        'ResponsePayload_10',
        'SentAt_11',
        'PaymentId_14',
        'NoteNumbers_15',
        'AttachmentPath_16',
    ];

    protected array $allowedStatuses = ['PENDING', 'SENT', 'FAILED', 'DELIVERED', 'UNDELIVERED'];
    private ?array $existingFields = null;

    private function array_get(array $data, string $key, $default = null)
    {
        return array_key_exists($key, $data) ? $data[$key] : $default;
    }

    public function insert_email_log(array $data)
    {
        if (!$this->db->tableExists($this->table)) {
            return false;
        }

        $payload = [
            'Module_1' => $this->limit((string) $this->array_get($data, 'Module_1', ''), 100) ?: null,
            'Reference_2' => $this->limit((string) $this->array_get($data, 'Reference_2', ''), 100) ?: null,
            'RecipientEmail_3' => $this->limit((string) $this->array_get($data, 'RecipientEmail_3', ''), 150),
            'Subject_4' => $this->limit((string) $this->array_get($data, 'Subject_4', ''), 255),
            'Message_5' => $this->array_get($data, 'Message_5'),
            'Provider_6' => $this->limit((string) $this->array_get($data, 'Provider_6', 'INFOBIP'), 100),
            'ProviderMessageId_7' => $this->limit((string) $this->array_get($data, 'ProviderMessageId_7', ''), 150) ?: null,
            'Status_8' => $this->normalize_status((string) $this->array_get($data, 'Status_8', 'PENDING')),
            'ErrorMessage_9' => $this->array_get($data, 'ErrorMessage_9'),
            'ResponsePayload_10' => $this->normalize_payload($this->array_get($data, 'ResponsePayload_10')),
            'SentAt_11' => $this->array_get($data, 'SentAt_11'),
            'PaymentId_14' => $this->normalize_bigint($this->array_get($data, 'PaymentId_14')),
            'NoteNumbers_15' => $this->array_get($data, 'NoteNumbers_15'),
            'AttachmentPath_16' => $this->array_get($data, 'AttachmentPath_16'),
        ];
        $payload = $this->filter_existing_fields($payload);

        if ($payload['RecipientEmail_3'] === '' || $payload['Subject_4'] === '') {
            return false;
        }

        if (!$this->insert($payload, true)) {
            return false;
        }

        return (int) $this->getInsertID();
    }

    public function update_email_status_by_provider_message_id(
        string $providerMessageId,
        string $status,
        $responsePayload = null,
        ?string $errorMessage = null,
        ?string $recipientEmail = null
    ): bool {
        if ($providerMessageId === '' || !$this->db->tableExists($this->table)) {
            return false;
        }

        $update = [
            'Status_8' => $this->normalize_status($status),
            'ResponsePayload_10' => $this->normalize_payload($responsePayload),
            'ErrorMessage_9' => $errorMessage,
        ];

        if ($update['Status_8'] === 'DELIVERED') {
            $update['SentAt_11'] = date('Y-m-d H:i:s');
        }

        $targetRow = $this->builder()
            ->select('Id')
            ->where('ProviderMessageId_7', $providerMessageId);

        $recipientEmail = trim((string) $recipientEmail);
        if ($recipientEmail !== '') {
            $recipientWhere = new RawSql(
                'LOWER(RecipientEmail_3) = ' . $this->db->escape(strtolower($recipientEmail))
            );
            $targetRow->where($recipientWhere);
        }

        $row = $targetRow->get()->getRowArray();
        if ($row === null) {
            return false;
        }

        $builder = $this->builder()
            ->where('Id', $row['Id']);

        return (bool) $builder->update($update);
    }

    public function get_email_log_by_provider_message_id(string $providerMessageId): ?array
    {
        if ($providerMessageId === '' || !$this->db->tableExists($this->table)) {
            return null;
        }

        $row = $this->builder()
            ->where('ProviderMessageId_7', $providerMessageId)
            ->get()
            ->getRowArray();

        return $row ?: null;
    }

    public function get_email_log_by_provider_message_id_and_recipient(
        string $providerMessageId,
        string $recipientEmail
    ): ?array {
        $recipientEmail = strtolower(trim($recipientEmail));

        if ($providerMessageId === '' || $recipientEmail === '' || !$this->db->tableExists($this->table)) {
            return null;
        }

        $row = $this->builder()
            ->where('ProviderMessageId_7', $providerMessageId)
            ->where(new RawSql(
                'LOWER(RecipientEmail_3) = ' . $this->db->escape($recipientEmail)
            ))
            ->get()
            ->getRowArray();

        return $row ?: null;
    }

    public function has_successful_delivery(string $module, string $reference, string $recipient): bool
    {
        if ($module === '' || $reference === '' || $recipient === '' || !$this->db->tableExists($this->table)) {
            return false;
        }

        return $this->builder()
            ->where('Module_1', $module)
            ->where('Reference_2', $reference)
            ->where('RecipientEmail_3', $recipient)
            ->whereIn('Status_8', ['SENT', 'DELIVERED'])
            ->countAllResults() > 0;
    }

    private function normalize_status(string $status): string
    {
        $status = strtoupper(trim($status));

        if (in_array($status, $this->allowedStatuses, true)) {
            return $status;
        }

        if ($status === 'NOT_DELIVERED') {
            return 'UNDELIVERED';
        }

        return 'PENDING';
    }

    private function normalize_payload($payload): ?string
    {
        if ($payload === null || $payload === '') {
            return null;
        }

        if (is_string($payload)) {
            return $payload;
        }

        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return $encoded === false ? null : $encoded;
    }

    private function normalize_bigint($value): ?int
    {
        return is_numeric($value) ? (int) $value : null;
    }

    private function limit(string $value, int $length): string
    {
        return mb_substr(trim($value), 0, $length);
    }

    private function filter_existing_fields(array $payload): array
    {
        $existingFields = $this->get_existing_fields();

        if ($existingFields === []) {
            return $payload;
        }

        return array_intersect_key($payload, array_flip($existingFields));
    }

    private function get_existing_fields(): array
    {
        if ($this->existingFields !== null) {
            return $this->existingFields;
        }

        try {
            $this->existingFields = $this->db->getFieldNames($this->table);
        } catch (\Throwable $exception) {
            $this->existingFields = [];
        }

        return $this->existingFields;
    }
}
