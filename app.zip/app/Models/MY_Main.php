<?php

namespace App\Models;

use Config\Database;

class MY_Main extends MY_Model
{
        protected $DBGroup = 'ikwook_logiref_main';
        public function __construct()
        {
                parent::__construct();
                $this->db = Database::connect($this->DBGroup);
        }
}
