<?php
namespace App\Models;
use CodeIgniter\Model;

class MY_Model extends Model
{
        protected $DBGroup = '';
        protected $table     = '';
        protected $returnType     = 'object';

        // Dates
        protected $useTimestamps = false;
        protected $dateFormat    = 'datetime';
        protected $createdField  = 'Date_1';
        protected $updatedField  = '';

        //Config
        public $session;
        protected $db;
        protected $builder;
        public $curl;

        public function __construct()
        {
                parent::__construct();
                $this->session = \Config\Services::session();
                $this->curl = \Config\Services::curlrequest();
        }

        public function set_session_variables()
        {
                $data = array(
                        'user_id' => '',
                        'user_status' => '',
                        'user_email' => '',
                        'user_role' => '',
                        'user_log' => '',
                        'account_expire' => '',
                        'account_key' => '',
                        'user_tel' => '',
                        'user_fname' => '',
                        'user_sname' => '',
                        'user_lang' => '',
                        'user_presence' => '',
                        'loggedin' => TRUE
                );
                $this->session->set(['userdata' => $data]);

                return true;
        }

        //Log and timeline
        // public function save_log($data, $id)
        // {
        //         $data['Date_1'] = gmdate('Y-m-d');
        //         $data['Time_2'] = gmdate('H:s');
        //         $data['Account_3'] = $this->session->userdata['account_id'];
        //         $data['Fullname_4'] = $this->session->userdata['user_fname'] . " " . $this->session->userdata['user_sname'];
        //         $data['Userid_5'] = $this->session->userdata['user_id'];
        //         $this->set_table('sys_logs', 'Id_0', 'Id_0 DESC');
        //         ($id > 0) || $this->db->where('Id_0', $id);
        //         return $this->save($data, $id);
        // }

        //Task
        // public function count_my_tasks()
        // {
        //         $this->db->select('COUNT(Id_0) as Total');
        //         $this->db->from('project_tasks');
        //         $this->db->order_by('Id_0 DESC');
        //         $result = $this->get_by(array('Status_2 =' => '6', 'Deadline_15 <=' => date('Y-m-d'), 'Userid_9' => $this->session->userdata['user_id']));
        //         return $result[0]->Total;
        // }

        // //
        // public function count_my_routines_daily()
        // {
        //         $this->db->select('COUNT(Id_0) as Total');
        //         $this->db->from('todos_tasks');
        //         $this->db->order_by('Id_0 DESC');
        //         $this->db->where("Userid_5 ='" . $this->session->userdata['user_id'] . "'");
        //         $this->db->where("Frequency_4 ='7'");
        //         $result =  $this->get_all();
        //         return $result[0]->Total;
        // }




        //Dropdown Menu
        // public function get_dropdown_menu($menu)
        // {
        //         if ($menu == "group") {
        //                 $this->db->where('Status_2', '5');
        //                 $this->db->where('Account_3', $this->session->userdata['account_id']);
        //                 $this->db->order_by('Name_4');
        //                 $query = $this->db->get('sys_groups');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a group here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Name_4'];
        //                 }
        //         } elseif ($menu == "site") {
        //                 $this->db->where('Status_2', '5');
        //                 $this->db->where('Account_3', $this->session->userdata['account_id']);
        //                 $this->db->order_by('Name_4');
        //                 $query = $this->db->get('sys_sites');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a site here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Name_4'];
        //                 }
        //         } elseif ($menu == "frequency") {
        //                 $st = "Object_3='Frequency' AND Status_2='1'";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Value_4');
        //                 $query = $this->db->get('sys_categories');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a frequency--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Value_4'];
        //                 }
        //         } elseif ($menu == "countries") {
        //                 $st = " Id_0 !='' AND Name_2 != ''";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Name_2');
        //                 $query = $this->db->get('sys_countries');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a country--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Name_2'];
        //                 }
        //         } elseif ($menu == "manager") {
        //                 $where = "Account_3='" . $this->session->userdata['account_id'] . "'";
        //                 $this->db->where($where, NULL, FALSE);
        //                 $this->db->order_by('Firstname_4');
        //                 $query = $this->db->get('sys_profiles');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a member here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Userid_14']] = $row['Firstname_4'] . " " . $row['Lastname_5'];
        //                 }
        //         } elseif ($menu == "user") {
        //                 $where = "Account_3='" . $this->session->userdata['account_id'] . "'";
        //                 $this->db->where($where, NULL, FALSE);
        //                 $this->db->order_by('Firstname_4');
        //                 $query = $this->db->get('sys_profiles');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a user here --';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Userid_14']] = $row['Firstname_4'] . " " . $row['Lastname_5'];
        //                 }
        //         } elseif ($menu == "currency") {
        //                 $this->db->where('Status_2', '5');
        //                 $this->db->where('Account_3', 0);
        //                 $this->db->order_by('Name_4');
        //                 $query = $this->db->get('sys_currency');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select --';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Name_4'];
        //                 }
        //         } elseif ($menu == "privacy") {
        //                 $st = "Object_3='Privacy' AND Status_2='1'";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Value_4');
        //                 $query = $this->db->get('sys_categories');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a privacy--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Value_4'];
        //                 }
        //         } elseif ($menu == "days") {
        //                 $st = "Object_3='Days' AND Status_2='1'";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Id_0');
        //                 $query = $this->db->get('sys_categories');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a day--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Value_4'];
        //                 }
        //         } elseif ($menu == "months") {
        //                 $st = "Object_3='Months' AND Status_2='1'";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Id_0');
        //                 $query = $this->db->get('sys_categories');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a month--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Value_4'];
        //                 }
        //         } elseif ($menu == "project_category") {
        //                 $st = "Object_4='Project' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Category_5');
        //                 $query = $this->db->get('project_category');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a category here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Category_5'];
        //                 }
        //         } elseif ($menu == "sales_category") {
        //                 $st = "Object_4='Lead' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Category_5');
        //                 $query = $this->db->get('sales_category');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a category here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Category_5'];
        //                 }
        //         } elseif ($menu == "contact_category") {
        //                 $st = "Object_4='List' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Title_5');
        //                 $query = $this->db->get('contact_categories');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a category here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Title_5'];
        //                 }
        //         } elseif ($menu == "contact_company") {
        //                 $st = " Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Name_4');
        //                 $query = $this->db->get('contact_companies');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a category--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Name_4'];
        //                 }
        //         } elseif ($menu == "project_type") {
        //                 $st = "Object_4='Task' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Category_5');
        //                 $query = $this->db->get('project_category');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a type here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Category_5'];
        //                 }
        //         } elseif ($menu == "project_status") {
        //                 $st = "Object_4='Project' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Id_0');
        //                 $query = $this->db->get('project_status');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a status here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Title_5'];
        //                 }
        //         } elseif ($menu == "sales_status") {
        //                 $st = "Object_4='Lead' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Id_0');
        //                 $query = $this->db->get('sales_status');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a status here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Title_5'];
        //                 }
        //         } elseif ($menu == "task_status") {
        //                 $st = "Object_4='Task' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Title_5');
        //                 $query = $this->db->get('project_status');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a status here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Title_5'];
        //                 }
        //         } elseif ($menu == "task_mark") {
        //                 $st = "Object_4='Task' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Note_5');
        //                 $query = $this->db->get('project_satisfaction');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a mark here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Note_5'];
        //                 }
        //         } elseif ($menu == "project_mark") {
        //                 $st = "Object_4='Project' AND Status_2='1' AND (Account_3='" . $this->session->userdata['account_id'] . "' OR Account_3='0')";
        //                 $this->db->where($st, NULL, FALSE);
        //                 $this->db->order_by('Note_5');
        //                 $query = $this->db->get('project_satisfaction');
        //                 $ddmenu = array();
        //                 $ddmenu[''] = '--Select a mark here--';
        //                 foreach ($query->result_array() as $row) {
        //                         $ddmenu[$row['Id_0']] = $row['Note_5'];
        //                 }
        //         }

        //         return $ddmenu;
        // }


        public function get_all($id = NULL, $single = FALSE)
        {
                if ($id != NULL) {
                        $this->db->table($this->table)->where($this->primaryKey, $id)->get()->getRow();
                }

                if ($single == TRUE) {
                        return $this->db->table($this->table)->limit(1)->get()->getRow();
                } else {
                        return $this->db->table($this->table)->get()->getResult();
                }
        }

        public function get_by($where, $single = FALSE)
        {
                if ($single == TRUE) {
                        return $this->db->table($this->table)->where($where)->limit(1)->get()->getRow();
                } else {
                        return $this->db->table($this->table)->where($where)->get()->getResult();
                }
        }

        // Cover CodeIgniter save()/insert()/update() as well as the historical saveData().
        protected function doInsert(array $data)
        {
                if (!\App\Libraries\OraclePaymentPersistence::enabled($this->db->DBDriver, $this->session->userdata ?? [])) return parent::doInsert($data);
                if (!$this->useAutoIncrement && $this->tempPrimaryKeyValue !== null) $data[$this->primaryKey] = $this->tempPrimaryKeyValue;
                $escape = $this->escape;
                return \App\Libraries\OracleRequiredFields::write($this->db, $this->table, $this->primaryKey, $data, true, function ($values) use ($escape) {
                        $this->escape = $escape;
                        return parent::doInsert($values);
                });
        }

        protected function doUpdate($id = null, $data = null): bool
        {
                if (!\App\Libraries\OraclePaymentPersistence::enabled($this->db->DBDriver, $this->session->userdata ?? [])) return parent::doUpdate($id, $data);
                $escape = $this->escape;
                return \App\Libraries\OracleRequiredFields::write($this->db, $this->table, $this->primaryKey, $data, false, function ($values) use ($id, $escape) {
                        $this->escape = $escape;
                        return parent::doUpdate($id, $values);
                });
        }

        public function persistenceConnection()
        {
                return $this->db;
        }

        public function saveData($data, $id = NULL, $escape = TRUE)
        {
                //Set timestamps
                if ($this->useTimestamps == TRUE) {
                        $now = date('Y-m-d H:i:s');
                        $id || $data[$this->createdField] = $now;
                        (empty($this->updatedField)) || $data[$this->updatedField] = $now;
                }

                // Échapper les données
                /*if ($escape) {
                        foreach ($data as $key => $value) {

                                if(!$this->is_json($value))
                                {
                                        $data[$key] = htmlentities($value, ENT_QUOTES, 'UTF-8');
                                }
                        }
                }*/

                if ($escape) {
                        foreach ($data as $key => $value) {

                                if (is_string($value) && !$this->is_json($value)) {

                                        // Supprimer les balises HTML (anti XSS)
                                        $value = strip_tags($value);

                                        // Supprimer caractères invisibles dangereux
                                        $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);

                                        // Nettoyage espaces
                                        $value = trim($value);

                                        $data[$key] = $value;
                                }
                        }
                }

                if (in_array(strtolower($this->table), ['logiref_paiements_tresor', 'logiref_cbs_instructions_dgi'], true) && \App\Libraries\OraclePaymentPersistence::enabled($this->db->DBDriver, $this->session->userdata ?? [])) {
                        return \App\Libraries\OraclePaymentPersistence::save($this->db, $this->table, $this->primaryKey, $data, $id);
                }

                // The Oracle NOT NULL recovery applies to every table saved here.
                $recoverMissing = \App\Libraries\OraclePaymentPersistence::enabled($this->db->DBDriver, $this->session->userdata ?? []);
                if ($id === NULL) {
                        !isset($data[$this->primaryKey]) || $data[$this->primaryKey] = NULL;
                        $write = fn ($values) => $this->db->table($this->table)->insert($values);
                        $saved = $recoverMissing
                                ? \App\Libraries\OracleRequiredFields::write($this->db, $this->table, $this->primaryKey, $data, true, $write)
                                : $write($data);
                        if (!$saved) return false;
                        $id = $this->db->insertID();
                } else {
                        unset($data[$this->primaryKey]);
                        $write = fn ($values) => $this->db->table($this->table)->update($values, [$this->primaryKey => $id]);
                        $saved = $recoverMissing
                                ? \App\Libraries\OracleRequiredFields::write($this->db, $this->table, $this->primaryKey, $data, false, $write)
                                : $write($data);
                        if (!$saved) return false;
                }

                //return ($id > 0);
                return $id;
        }

        // public function delete($id)
        // {
        //         $filter = $this->_primary_filter;
        //         $id = $filter($id);

        //         if (!$id) {
        //                 return FALSE;
        //         }
        //         $this->db->where($this->_primary_key, $id);
        //         $this->db->limit(1);
        //         $this->db->delete($this->_table_name);
        // }

        public function set_table($tableName, $primaryKey, $orderby, $timestamp = FALSE, $date_created = NULL, $date_modified = NULL)
        {
                // Rebind models created before the login resolved the bank.
                if ($this->DBGroup) {
                        $group = $this->DBGroup;
                        if ($group === 'ikwook_logiref_main' && preg_match('/^main_authorizations(?:\s|$)/i', $tableName)) {
                                $group = 'mysql_directory';
                        }
                        $this->db = \Config\Database::connect($group);
                        $this->builder = null;
                }
                $this->table = $tableName;
                $this->primaryKey = $primaryKey;
                $this->useTimestamps = $timestamp;
//                $this->builder = $this->db->table($tableName);
                // $this->_order_by = $orderby;
                if (!empty($date_created)) $this->createdField = $date_created;
                if (!empty($date_modified)) $this->updatedField = $date_modified;
        }

        public function send_curl($fields, $url)
        {
                $i = 0;
                $fields_string = '';

                //url-ify the data for the POST
                foreach ($fields as $key => $value) {
                        if ($i < count($fields)) $fields_string .= $key . '=' . $value . '&';
                        else $fields_string .= $key . '=' . $value;
                        $i++;
                }
                rtrim($fields_string, '&');

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                /*curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
			'Content-Type: application/json',                                                                                
			'Content-Length: ' . strlen($data_string))                                                                       
		);*/

                $result = curl_exec($ch);
                curl_close($ch);

                return $result;
        }

        public function array_from_post($fields)
        {
                $data = array();
                foreach ($fields as $field => $value) {
                        $data[$field] = $this->input->post($value);
                }
                return $data;
        }

        public function array_msort($array, $cols)
        {
                $colarr = array();
                foreach ($cols as $col => $order) {
                        $colarr[$col] = array();
                        foreach ($array as $k => $row) {
                                $colarr[$col]['_' . $k] = strtolower($row[$col]);
                        }
                }
                $eval = 'array_multisort(';
                foreach ($cols as $col => $order) {
                        $eval .= '$colarr[\'' . $col . '\'],' . $order . ',';
                }
                $eval = substr($eval, 0, -1) . ');';
                eval($eval);
                $ret = array();
                foreach ($colarr as $col => $arr) {
                        foreach ($arr as $k => $v) {
                                $k = substr($k, 1);
                                if (!isset($ret[$k])) $ret[$k] = $array[$k];
                                $ret[$k][$col] = $array[$k][$col];
                        }
                }
                return $ret;
        }

        // public function get_table_data($columns, $table, $where = NULL)
        // {
        //         /* Array of database columns which should be read and sent back to DataTables. Use a space where
        //  * you want to insert a non-database field (for example a counter or static image)
        //  */
        //         //$aColumns = array('id', 'first_name', 'last_name');
        //         $aColumns = $columns;

        //         // DB table to use
        //         //$sTable = 'data_table';
        //         $sTable = $table;

        //         $iDisplayStart = $this->input->get_post('iDisplayStart', true);
        //         $iDisplayLength = $this->input->get_post('iDisplayLength', true);
        //         $iSortCol_0 = $this->input->get_post('iSortCol_0', true);
        //         $iSortingCols = $this->input->get_post('iSortingCols', true);
        //         $sSearch = $this->input->get_post('sSearch', true);
        //         $sEcho = $this->input->get_post('sEcho', true);

        //         // Paging
        //         if (isset($iDisplayStart) && $iDisplayLength != '-1') {
        //                 $this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
        //         }

        //         // Ordering
        //         if (isset($iSortCol_0)) {
        //                 for ($i = 0; $i < intval($iSortingCols); $i++) {
        //                         $iSortCol = $this->input->get_post('iSortCol_' . $i, true);
        //                         $bSortable = $this->input->get_post('bSortable_' . intval($iSortCol), true);
        //                         $sSortDir = $this->input->get_post('sSortDir_' . $i, true);

        //                         if ($bSortable == 'true') {
        //                                 $this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
        //                         }
        //                 }
        //         }

        //         /* 
        //  * Filtering
        //  * NOTE this does not match the built-in DataTables filtering which does it
        //  * word by word on any field. It's possible to do here, but concerned about efficiency
        //  * on very large tables, and MySQL's regex functionality is very limited
        //  */
        //         if (isset($sSearch) && !empty($sSearch)) {
        //                 for ($i = 0; $i < count($aColumns); $i++) {
        //                         $bSearchable = $this->input->get_post('bSearchable_' . $i, true);

        //                         // Individual column filtering
        //                         if (isset($bSearchable) && $bSearchable == 'true') {
        //                                 $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
        //                         }
        //                 }
        //         }

        //         // Select Data
        //         if ($where) $this->db->where($where);
        //         $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $aColumns)), false);
        //         $rResult = $this->db->get($sTable);

        //         // Data set length after filtering
        //         $this->db->select('FOUND_ROWS() AS found_rows');
        //         $iFilteredTotal = $this->db->get()->row()->found_rows;

        //         // Total data set length
        //         if ($where) $this->db->where($where);
        //         $iTotal = $this->db->count_all_results($sTable);

        //         // Output
        //         $output = array(
        //                 'sEcho' => intval($sEcho),
        //                 'iTotalRecords' => $iTotal,
        //                 'iTotalDisplayRecords' => $iFilteredTotal,
        //                 'aaData' => array()
        //         );

        //         foreach ($rResult->result_array() as $aRow) {
        //                 $row = array();

        //                 foreach ($aColumns as $col) {
        //                         $row[] = $aRow[$col];
        //                 }

        //                 $output['aaData'][] = $row;
        //         }

        //         return json_encode($output);
        // }
        
        function is_json($string) 
        {
                json_decode($string);
                return (json_last_error() === JSON_ERROR_NONE);
        }
}
