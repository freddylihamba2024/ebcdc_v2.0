<?php

namespace App\Models;

use Config\Database;

class MY_Transaction extends MY_Model
{
        protected $DBGroup = 'ikwook_logiref_transactions';
        public function __construct()
        {
                parent::__construct();
                $this->db = Database::connect($this->DBGroup);
        }
}
