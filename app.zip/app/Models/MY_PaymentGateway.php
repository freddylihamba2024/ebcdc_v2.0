<?php

namespace App\Models;

use Config\Database;

class MY_PaymentGateway extends MY_Model
{
    protected $DBGroup = 'ikwook_payments_gateway';

    public function __construct()
    {
        parent::__construct();

        if (isset($this->db)) {
            $this->db->close();
            $this->db = null;
        }

        $this->db = Database::connect($this->DBGroup);
    }
}
