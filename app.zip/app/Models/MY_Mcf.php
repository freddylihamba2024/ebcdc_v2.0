<?php

namespace App\Models;

use CodeIgniter\Model;
use Config\Database;

class MY_Mcf extends MY_Model
{
        protected $DBGroup = 'ikwook_mcf_gateway';
        public function __construct()
        {
                parent::__construct();
                if (isset($this->db)) {
                        $this->db->close();
                        $this->db = NULL;
                }
                $this->db = Database::connect($this->DBGroup);
        }
}
