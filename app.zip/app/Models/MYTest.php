<?php

namespace App\Models;

use CodeIgniter\Model;
use Config\Database;

class MYTest extends Model {

    // protected $DBGroup          = 'ikwook_conciliation_test';
    protected $table = '';
    protected $returnType = 'array';
    protected $tempReturnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [];
    // Dates
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';
    private $database = null;

    public function __construct($dbName = null) {
        if (isset($this->database)) {
            $this->database->close();
            $this->database = null;
        }
        $this->database = Database::connect($dbName);
    }

    public function getAllData($dbGroup, $tableName = null) {
        $this->DBGroup = $dbGroup;
        $this->table = $tableName;
        $tables = [];
        array_push($tables, $this->table);
        if (count($tables) > 0) {
            foreach ($tables as $key => $table) {
                $result = $this->database->table($table)->limit(30)->get()->getResult();
            }
        }
        return $result;
    }

    public function saveEncryptedData($table, $data) {
        $success = false;
        $this->primaryKey = 'Id_0';
        foreach ($table as $key => $tab) {
            $this->table = $key;
            $this->allowedFields = $tab['columns'];
            for ($i = 0; $i < count($data); $i++) {
                $success = $this->save($data[$i]['data'][$i]);
            }
        }
        return $success;
    }

    public function getTables() {
        $tables = $this->database->listTables();
        return $tables;
    }

    public function getFields($table = null) {
        $fields = $this->database->getFieldNames($table);
        return $fields;
    }
}
